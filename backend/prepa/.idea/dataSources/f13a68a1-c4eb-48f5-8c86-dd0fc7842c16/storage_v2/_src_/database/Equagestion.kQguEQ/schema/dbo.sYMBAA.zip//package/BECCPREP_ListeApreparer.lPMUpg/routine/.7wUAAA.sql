/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.BECCPREP_Boite
grant execute on BECCPREP_Boite to public
*/

CREATE PROCEDURE dbo.BECCPREP_ListeApreparer(@cc varchar(10),@depot varchar(10))

AS
begin

        declare @STAR varchar(50),
                @STQTE int,
                @STLETTRE varchar(4),
                @STDEPOT varchar(50),
                @ST_QTE_RSRV int,
                @id numeric(18,0),
                @lettre varchar(4),
                @dispo int,
                @qte int,
                @id_user varchar(255)
                
                select @id_user=newID()
        

        create table #resultTmp (
                STEMPID numeric(18,0) null,
                STEMPAR char(50) null,
                STEMPLETTRE char(4) null,
                STEMPDEPOT char(10) null,
                STEMPQTE int null,
        )
        
        
        /*LIGNE COMMANDE*/
        select CCLSEQ, CCLCODE, CCLARTICLE, CCLQTE, CCLDATE, CCLR1, CCLR2, CCLR3, CCLR4, CCLR5, CCLPHT, CCLORDRE, CCLUNITFACT, CCLTV, CCLTYPE, CCLLIBRE, CCLNUM, CCLQTEEXP, CCLRESTE, CCLCL, CCLTOTALHT, CCLECHSPE, CCLTYPEMV, CCLDATEMDF, CCLUSERMDF, CCLFACTMAN, CCLOFFERT, CCLDATECRE, CCLUSERCRE, CCLDEV, CCLCOURSDEV, CCLPHTDEV, CCLTOTALHTDEV, CCLATTACHE, CCLENT, CCLQTERES, CCLDATERESFIN, CCLDEPOTRES, CCLREP, CCLREPDIV, CCLWEBCODE, CCLWEBNUM, CCLQTEPREP, CCLCF, CCLMARCHE, CCLFACT, CCLLOT, CCLFRAIS, CCLCOLIS, CCLPAHT, CCLDATEINIT, CCLTOTALHTORG, CCLNUMARM1, CCL_LIBSEQ, CCLATTETRANSFERT, CCL_COMMENT_MAG, CCLCOLISAGE, CCLNBCOLIS, CCLPACK 
        into #FCCL
        from FCCL
        where CCLCODE=@cc
        and (isnull(CCLRESTE,0)-isnull(CCLQTEPREP,0))>0
        
        create index FCCL_idx0001 on #FCCL(CCLARTICLE)

        select CCLCODE,CCLARTICLE,sum(CCLQTE) as QTE_CDE,sum(CCLRESTE-(isnull(CCLQTEPREP,0))) as QTE_A_PREPARER,isnull(ARFRANCOFO,0) as COLISAGE,(case when (isnull(ARFRANCOFO,0)<>0) then (sum(CCLRESTE-(isnull(CCLQTEPREP,0))))/isnull(ARFRANCOFO,0)  else 0 end * isnull(ARFRANCOFO,0)) as QTE_PREPARER_COLIS,ARTYPE
        into #FCCL_GROUPE
        from #FCCL,VIEW_FAR
        where ARCODE=CCLARTICLE
        group by CCLCODE,CCLARTICLE,isnull(ARFRANCOFO,0),ARTYPE
        
        delete from #FCCL_GROUPE where QTE_A_PREPARER<=0
        
        create index FCCL_GROUPE_idx0001 on #FCCL_GROUPE(CCLARTICLE)
        create index FCCL_GROUPE_idx0002 on #FCCL_GROUPE(QTE_PREPARER_COLIS)
        create index FCCL_GROUPE_idx0003 on #FCCL_GROUPE(QTE_A_PREPARER)
        
        /*VIEW_STOCK_LOT_EMPLACEMENT*/        
        select STEMPID, STEMPAR, STEMPDEPOT, STEMPEMP, STLOT, NLOTDATEPER, xDPVTE, xDPCENTRAL, STFO, STDATEENTR, STLETTRE, STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS, ARLIB, ARQTEPALETTE, ARFO, ARREFFOUR, ARPRM, ARUNITACHAT, ARNUMEROTE, ARFRANCOFO, STEMPQTE, VALEUR, ARESSEMP, ST_UG, ARPVHT, xARTP_STATSPEC, xARTP_FROID, #FCCL_GROUPE.CCLCODE, #FCCL_GROUPE.CCLARTICLE, #FCCL_GROUPE.QTE_CDE, #FCCL_GROUPE.QTE_A_PREPARER, #FCCL_GROUPE.COLISAGE, #FCCL_GROUPE.QTE_PREPARER_COLIS, #FCCL_GROUPE.ARTYPE
        into #VIEW_STOCK_LOT_EMPLACEMENT
        from VIEW_STOCK_LOT_EMPLACEMENT,#FCCL_GROUPE
        where STEMPDEPOT=@depot
        and STEMPAR=CCLARTICLE
        
        create index STOCK_idx0001 on #VIEW_STOCK_LOT_EMPLACEMENT(STEMPAR)
        create index STOCK_idx0002 on #VIEW_STOCK_LOT_EMPLACEMENT(STEMPDEPOT)
        create index STOCK_idx0003 on #VIEW_STOCK_LOT_EMPLACEMENT(STLETTRE)



        /*GSETION DE RESERVATION DANS LA TABLE FSTOCK*/
        select STAR,STQTE,STLETTRE,STDEPOT,ST_QTE_RSRV
        into #STOCK_RESERVE
        from VIEW_FSTOCK
        where isnull(ST_QTE_RSRV,0)>0


        /*parcourir le reservatio FSTOCK*/
        declare reservation cursor for select STAR,STQTE,STLETTRE,STDEPOT,ST_QTE_RSRV from #STOCK_RESERVE
        open reservation
        fetch reservation into @STAR,@STQTE,@STLETTRE,@STDEPOT,@ST_QTE_RSRV
        while (@@sqlstatus=0)
        begin
                /*parcourir #result pou avoir les ligne de stock concerné*/
                declare ligneStock cursor  for select STEMPID,STLETTRE,STEMPDEPOT,STEMPQTE from #VIEW_STOCK_LOT_EMPLACEMENT where STEMPAR=@STAR and STEMPDEPOT=@STDEPOT and STLETTRE=@STLETTRE
                open ligneStock
                fetch ligneStock into @id,@lettre,@depot,@qte
                while (@@sqlstatus=0)
                begin
                        select @dispo=@qte-@ST_QTE_RSRV
                        
                        if @dispo<=0
                        begin
                                insert into #resultTmp values (@id,@STAR,@lettre,@depot,0)
                        end
                        else
                        begin
                                insert into #resultTmp values (@id,@STAR,@lettre,@depot,@dispo)
                        end
                        select @ST_QTE_RSRV=@ST_QTE_RSRV-@qte
                        
                        fetch ligneStock into @id,@lettre,@depot,@qte
                end
                close ligneStock
                deallocate cursor ligneStock

                fetch reservation into @STAR,@STQTE,@STLETTRE,@STDEPOT,@ST_QTE_RSRV
        end
        close reservation
        deallocate cursor reservation

       update #VIEW_STOCK_LOT_EMPLACEMENT set STEMPQTE=#resultTmp.STEMPQTE
       from #VIEW_STOCK_LOT_EMPLACEMENT,#resultTmp
       where #resultTmp.STEMPID=#VIEW_STOCK_LOT_EMPLACEMENT.STEMPID

         /*prendre toutes les reservation dejà en preparation pour GROS et DET et puis enlever ces qté pour les lignes de stock correspondantes pour avoir le stock PROPRE*/
        select RBPARTICLE, RBPDEPOT, RBPLETTRE, RBPEMP, RBPQTE 
        into  #FRBP
        from VIEW_FRBP_DEPOT_LETTRE
        
        /*Enlever les stock dejà en commande au niveau GROS*/
        update #VIEW_STOCK_LOT_EMPLACEMENT set STEMPQTE=STEMPQTE-isnull(RBPQTE,0)
        from #VIEW_STOCK_LOT_EMPLACEMENT,#FRBP
        where RBPDEPOT=STEMPDEPOT
        and RBPARTICLE=STEMPAR
        and RBPLETTRE=STLETTRE
        and RBPEMP=STEMPEMP
        
        delete from #VIEW_STOCK_LOT_EMPLACEMENT where STEMPQTE<=0
 
        --insert into STOCK_LOT_EMPLACEMENT_REAPPRO
        select STEMPID, STEMPAR, STEMPDEPOT, STEMPEMP, STLOT, NLOTDATEPER, xDPVTE, xDPCENTRAL, STFO, STDATEENTR, STLETTRE, STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS, ARLIB, ARQTEPALETTE, ARFO, ARREFFOUR, ARPRM, ARUNITACHAT, ARNUMEROTE, ARFRANCOFO, STEMPQTE, VALEUR, ARESSEMP, ST_UG, ARPVHT, xARTP_STATSPEC, xARTP_FROID,@id_user as ID 
        from #VIEW_STOCK_LOT_EMPLACEMENT

        drop table #FCCL
        drop table #FCCL_GROUPE
        drop table #VIEW_STOCK_LOT_EMPLACEMENT

end
go

