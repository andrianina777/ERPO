


/* Procedure utilisee pour tester la validite de la RFA dans les lignes de factures
	d''un client pour l''annee indiquee */


create procedure RFA_FACL_Comp (@ent	char(5) = null,
								@client	char(12),
							  	@an		smallint = null)
with recompile
as
begin

set arithabort numeric_truncation off


if @an is null
select @an=datepart(yy,getdate())
		
declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime


select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))


create table #FFAL
(
FALSEQ			int				not null,
FALARTICLE		char(15)		not null,
ARFO			char(12)		not null,
ARFAM			char(8)			not null,
ARGRFAM			char(8)			not null,
CLTARIF			char(8)			not null,
ARSANSRFA		tinyint			not null,
FALTOTALHT		numeric(14,2)	not null,
FALCODE			char(10)		not null,
FALNUM			int				not null,
FALCARFA_old	numeric(14,2)	not null,
FALCARFA_new	numeric(14,2)	not null,
FALRFACT_old	numeric(14,2)	not null,
FALRFACT_new	numeric(14,2)	not null
)


declare @lignes		int,
		@labase		varchar(30)
select  @labase = db_name(),
		@lignes = 0


declare @article	char(15),
		@totalht	numeric(14,2),
		@arfo		char(12),
		@arfam		char(8),
		@argrfam	char(8),
		@cltarif	char(8),
		@arsansrfa	tinyint,
		@code		char(10),
		@num		int,
		@carfa_old	numeric(14,2),
		@carfa_new	numeric(14,2),
		@rfact_old	numeric(14,2),
		@rfact_new	numeric(14,2),
		@seq		int


declare factures cursor 
for select FALSEQ,FALARTICLE,ARFO,ARFAM,ARGRFAM,CLTARIF,ARSANSRFA,FALTOTALHT,FALCODE,FALNUM,FALCARFA,FALRFACT
from FFAL,FAR,FCL
where ARCODE=FALARTICLE
and FALDATE between @smalldate1 and @smalldate2
and FALCL=@client
and CLCODE=FALCL
and (@ent is null or FALENT=@ent)
order by FALSEQ
for read only

open factures

fetch factures
into @seq,@article,@arfo,@arfam,@argrfam,@cltarif,@arsansrfa,@totalht,@code,@num,@carfa_old,@rfact_old


while (@@sqlstatus = 0)
	begin
	
	select @lignes=@lignes+1
	
	if isnull(@article,'') != ''
	begin
	  exec RFA_CL @ent,@client,@an,@article,@totalht,@carfa_new output,@rfact_new output
	  
	  insert into #FFAL (FALSEQ,FALARTICLE,ARFO,ARFAM,ARGRFAM,CLTARIF,ARSANSRFA,FALTOTALHT,FALCODE,FALNUM,FALCARFA_old,FALCARFA_new,FALRFACT_old,FALRFACT_new)
	  select  @seq,@article,@arfo,@arfam,@argrfam,@cltarif,@arsansrfa,@totalht,@code,@num,@carfa_old,@carfa_new,@rfact_old,@rfact_new
	end

	
	fetch factures
	into @seq,@article,@arfo,@arfam,@argrfam,@cltarif,@arsansrfa,@totalht,@code,@num,@carfa_old,@rfact_old
	
end

close factures
deallocate cursor factures

select FALSEQ,FALARTICLE,ARFO,ARFAM,ARGRFAM,CLTARIF,ARSANSRFA,FALTOTALHT,FALCODE,FALNUM,FALCARFA_old,FALCARFA_new,FALRFACT_old,FALRFACT_new
from #FFAL
where (FALCARFA_old != FALCARFA_new) or(FALRFACT_old != FALRFACT_new)
order by FALSEQ

drop table #FFAL


end



go

