


/* Procedure renvoyant les chiffres d''affaires, qtes livrees par les fournisseurs
	et commandes pour les annees N-2, N-1, annee en cours */

create procedure CAFO (	@fourn	char(12) = null,
					   	@An 	smallint)
with recompile
as
begin

 set arithabort numeric_truncation off


 create table #CA
 (
 FAM	char(8)		not null,
 AN		smallint		null,
 QteBL	int				null,
 CABL	numeric(14,2)	null,
 QteCF	int				null,
 CACF	numeric(14,2)	null
 )


	if @fourn is null
	begin
	  insert into #CA
	  select SFFAM,SFAN,sum(SFQTEBL),sum(SFCABL),sum(SFQTECF),sum(SFCACF)
	  from FSF
	  where SFAN >= @An-2
	  group by SFFAM,SFAN
	end
	else
	begin
	  insert into #CA
	  select SFFAM,SFAN,sum(SFQTEBL),sum(SFCABL),sum(SFQTECF),sum(SFCACF)
	  from FSF
	  where SFAN >= @An-2
	  and SFFO=@fourn
	  group by SFFAM,SFAN
	end


	select FAM,FPLIB,
			 QteBLN2=sum(QteBL*(1-sign(abs(AN-@An+2)))),CABLN2=sum(CABL*(1-sign(abs(AN-@An+2)))),
			 QteBLN1=sum(QteBL*(1-sign(abs(AN-@An+1)))),CABLN1=sum(CABL*(1-sign(abs(AN-@An+1)))),
			 QteBLN0=sum(QteBL*(1-sign(abs(AN-@An)))),CABLN0=sum(CABL*(1-sign(abs(AN-@An)))),
			 QteCFN0=sum(QteCF),CACFN0=sum(CACF)
	from #CA,FFP
	where FPCODE=FAM
	group by FAM,FPLIB
	order by FAM

	drop table #CA
	
end



go

