


/* Procedure permettant de recuperer les stocks constates sur une annee
	pour un article dans le fichier FMS  */
	
	
create procedure A_StockMens (	@Article	char(15),
						   	  	@Annee		smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @AvantQte	int
declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int

declare @AvantVal	int
declare @Janval		int
declare @Fevval		int
declare @Marval		int
declare @Avrval		int
declare @Maival		int
declare @Junval		int
declare @Juival		int
declare @Aouval		int
declare @Sepval		int
declare @Octval		int
declare @Novval		int
declare @Decval		int


select 	@AvantQte=sum(MOISQTE),
		@AvantVal=sum(MOISTOTPR)
from FMOIS
where MOISARTICLE=@Article
and MOISANNEE=@Annee-1
and MOISMOIS=12

select  @Janvier=0,
		@Janval=0

select	@Fevrier=sum(case when MSMOIS=1 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end), 
		@Fevval=sum(case when MSMOIS=1 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Mars=sum(case when MSMOIS between 1 and 2 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Marval=sum(case when MSMOIS between 1 and 2 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Avril=sum(case when MSMOIS between 1 and 3 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Avrval=sum(case when MSMOIS between 1 and 3 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Mai=sum(case when MSMOIS between 1 and 4 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Maival=sum(case when MSMOIS between 1 and 4 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Juin=sum(case when MSMOIS between 1 and 5 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Junval=sum(case when MSMOIS between 1 and 5 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Juillet=sum(case when MSMOIS between 1 and 6 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Juival=sum(case when MSMOIS between 1 and 6 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Aout=sum(case when MSMOIS between 1 and 7 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Aouval=sum(case when MSMOIS between 1 and 7 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Septembre=sum(case when MSMOIS between 1 and 8 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Sepval=sum(case when MSMOIS between 1 and 8 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Octobre=sum(case when MSMOIS between 1 and 9 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Octval=sum(case when MSMOIS between 1 and 9 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Novembre=sum(case when MSMOIS between 1 and 10 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Novval=sum(case when MSMOIS between 1 and 10 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end),
		@Decembre=sum(case when MSMOIS between 1 and 11 then (case when MSTYPE != 'S' then MSQTE else -MSQTE end) else 0 end),
		@Decval=sum(case when MSMOIS between 1 and 11 then (case when MSTYPE != 'S' then MSTOTPR else -MSTOTPR end) else 0 end)
from FMS
where MSARTICLE=@Article
and MSANNEE=@Annee

select 	isnull(@AvantQte,0)+isnull(@Janvier,0),isnull(@AvantQte,0)+isnull(@Fevrier,0),isnull(@AvantQte,0)+isnull(@Mars,0),
		isnull(@AvantQte,0)+isnull(@Avril,0),isnull(@AvantQte,0)+isnull(@Mai,0),isnull(@AvantQte,0)+isnull(@Juin,0),
		isnull(@AvantQte,0)+isnull(@Juillet,0),isnull(@AvantQte,0)+isnull(@Aout,0),isnull(@AvantQte,0)+isnull(@Septembre,0),
		isnull(@AvantQte,0)+isnull(@Octobre,0),isnull(@AvantQte,0)+isnull(@Novembre,0),isnull(@AvantQte,0)+isnull(@Decembre,0),
		isnull(@AvantVal,0)+isnull(@Janval,0),isnull(@AvantVal,0)+isnull(@Fevval,0),isnull(@AvantVal,0)+isnull(@Marval,0),
		isnull(@AvantVal,0)+isnull(@Avrval,0),isnull(@AvantVal,0)+isnull(@Maival,0),isnull(@AvantVal,0)+isnull(@Junval,0),
		isnull(@AvantVal,0)+isnull(@Juival,0),isnull(@AvantVal,0)+isnull(@Aouval,0),isnull(@AvantVal,0)+isnull(@Sepval,0),
		isnull(@AvantVal,0)+isnull(@Octval,0),isnull(@AvantVal,0)+isnull(@Novval,0),isnull(@AvantVal,0)+isnull(@Decval,0)
end



go

