




create procedure Stock (@ent			char(5)	= null, 
						@date1			datetime = null, 
						@date2			datetime = null, 
						@depot1			char(4) = null, 
						@depot2			char(4) = null, 
						@article1		char(15) = null, 
						@article2		char(15) = null, 
						@famille1		char(8) = null, 
						@famille2		char(8) = null, 
						@fournisseur1	char(12) = null, 
						@fournisseur2	char(12) = null, 
						@emplace1		char(8) = null, 
						@emplace2		char(8) = null, 
						@numero			tinyint = null, 
						@modevalo		tinyint = 0,		/* 0 = FIFO, 1 = PRM Global, 2 = PUMP, 3 = PRM Mensuel, 4 = DPA unitaire, 5 = Px Vte HT principal*/
						@nonstock		tinyint = 0
						) 
with recompile 
as 
begin 
 
set arithabort numeric_truncation off 
 
create table #Final 
( 
ARFAM				char(8)			not null, 
ARCODE				char(15)		not null, 
ARLIB				char(80)			null, 
ARUNITACHAT			tinyint			not null, 
ARFO				char(12)		not null, 
STLETTRE			char(4)			not null, 
STQTE				int				not null, 
STDATEENTR			smalldatetime	not null, 
AREEMP				char(8)				null, 
STPAHT				numeric(14,2)	not null, 
STNUMARM1			char(12)			null, 
STNUMARM2			char(12)			null, 
STDEPOT				char(4)			not null, 
PrixAchatLigne		numeric(14,2)	not null, 
PrixRevient			numeric(14,4)	not null, 
PrixRevientLigne	numeric(14,2)	not null, 
PrixVente			numeric(14,2)	not null, 
PrixVenteLigne		numeric(14,2)	not null, 
Seq					numeric(14,0)	identity 
) 
 
 
declare @article			char(15), 
		@articleprecedent	char(15), 
		@qte				int, 
		@PrixRevient		numeric(14,4), 
		@PrixRevientLigne	numeric(14,2), 
		@seq				int 
select  @articleprecedent = "" 
 
declare stock cursor  
for select ARCODE,STQTE,Seq 
from #Final 
order by Seq 
for read only 
 
 
if @emplace1 is null 
  begin 
	if @modevalo in (0,1,5)								/*--------------------- FIFO ou PRM PVHT*/ 
  	  begin 
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT, 
		STNUMARM1,STNUMARM2,STDEPOT, 
		PrixAchatLigne=(STPAHT/a.CVLOT)*STQTE, 
		PrixRevient=(case when @modevalo=0 then (STPAHT+STFRAIS) 
				  when @modevalo=1 then isnull(ARPRM,0) 
				  when @modevalo=5 then isnull(ARPVHT,0)/b.CVLOT
				  else (STPAHT+STFRAIS) end), 
		PrixRevientLigne=(case when @modevalo=0 then ((STPAHT+STFRAIS)/a.CVLOT)*STQTE 
				       when @modevalo=1 then isnull(ARPRM,0)*STQTE 
				       when @modevalo=5 then isnull(ARPVHT,0)/b.CVLOT*STQTE 
				       else ((STPAHT+STFRAIS)/a.CVLOT)*STQTE end), 
		PrixVente=isnull(ARPVHT,0), 
		PrixVenteLigne=round((isnull(ARPVHT,0)/a.CVLOT),2)*STQTE 
		from FAR,FSTOCK,FCV a, FCV b,FARE,FDP 
		where ARCODE=STAR 
		and AREAR=*ARCODE 
		and ARELIGNE=1 
		and ARUNITACHAT=a.CVUNIF 
		and ARUNITFACT=b.CVUNIF
	  	and (@nonstock = 1 or ARTYPE = 0)
		and (@date1 is null or STDATEENTR between @date1 and @date2) 
		and (@depot1 is null or STDEPOT between @depot1 and @depot2) 
		and (@article1 is null or ARCODE between @article1 and @article2) 
		and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		and (@fournisseur1 is null or ARFO between @fournisseur1 and @fournisseur2) 
		and (@numero is null or ARNUMEROTE=1) 
		and STQTE > 0 
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
		order by ARFO,ARFAM,ARCODE,STDEPOT 
  	  end 
	else if @modevalo in (2,3,4) 
  	  begin 
		insert into #Final (ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,STNUMARM1, 
						STNUMARM2,STDEPOT,PrixAchatLigne,PrixRevient,PrixRevientLigne,PrixVente,PrixVenteLigne) 
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT, 
				STNUMARM1,STNUMARM2,STDEPOT, 
				PrixAchatLigne=(STPAHT/CVLOT)*STQTE, 
				0,0, 
				PrixVente=ARPVHT, 
		PrixVenteLigne=round((ARPVHT/CVLOT),2)*STQTE 
		from FAR,FSTOCK,FCV,FARE,FDP 
		where ARCODE=STAR 
		and AREAR=*ARCODE 
		and ARELIGNE=1 
		and ARUNITACHAT=CVUNIF
	  	and (@nonstock = 1 or ARTYPE = 0) 
		and (@date1 is null or STDATEENTR between @date1 and @date2) 
		and (@depot1 is null or STDEPOT between @depot1 and @depot2) 
		and (@article1 is null or ARCODE between @article1 and @article2) 
		and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		and (@fournisseur1 is null or ARFO between @fournisseur1 and @fournisseur2) 
		and (@numero is null or ARNUMEROTE=1) 
		and STQTE>0 
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
		order by ARFO,ARFAM,ARCODE,STDEPOT 
		 
		create unique index seq on #Final (Seq) 
		 
 
		open stock 
		 
		fetch stock 
		into @article,@qte,@seq 
		 
		while (@@sqlstatus = 0) 
			begin 
			 
		  if @articleprecedent != @article 
		  begin 
			select 	@PrixRevient = 0, 
					@PrixRevientLigne = 0 
			 
			if @modevalo = 2									/*--------------------- PUMP */ 
			begin 
			  select @PrixRevient=isnull(PUMP,0) 
			  from FPUM 
			  where PUMAR = @article 
			  and PUMDATE <= convert (smalldatetime, getdate()) 
			  having PUMAR = @article 
			  and PUMDATE <= convert (smalldatetime, getdate()) 
			  and PUMDATE = max(PUMDATE) 
			   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
			end 
			else if @modevalo = 3								/*--------------------- PRM Mensuel */ 
			begin 
			  set rowcount 1 
			   
			  select @PrixRevient=isnull(PRM,0) 
			  from FPRM 
			  where PRMAR = @article 
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate())) 
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate())) 
			  and PRMAR = @article 
			  order by PRMAN desc,PRMMOIS desc 
			   
			  set rowcount 0 
			   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
			end 
			else  if @modevalo = 4								/*--------------------- DPA unitaire */ 
			begin 
			  set rowcount 1			 
			 
			  select @PrixRevient = (BLLPAHT+BLLFRAIS)/CVLOT
			  from FBLL,FCV 
			  where BLLAR=@article 
			  and CVUNIF=BLLUA 
			  having BLLAR=@article 
			  and CVUNIF=BLLUA 
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end)) 
			 
			  if isnull(@PrixRevient,0)=0 
			  begin 
				select @PrixRevient = (SILPAHT+SILFRAIS)/CVLOT 
				from FSIL,FAR,FCV 
				where SILARTICLE=@article 
				and ARCODE = SILARTICLE 
				and ARUNITACHAT = CVUNIF 
				having SILARTICLE=@article 
				and ARCODE = SILARTICLE 
				and ARUNITACHAT = CVUNIF 
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end)) 
			  end 
			   
			  set rowcount 0 
			   
			  if @PrixRevient is null 
				select @PrixRevient = 0 
	   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
			end 
		  end 
		  else if @articleprecedent = @article 
		  begin 
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
		  end 
 
 
			update #Final set PrixRevient = @PrixRevient, PrixRevientLigne = @PrixRevientLigne 
			where Seq = @seq 
		 
			select  @articleprecedent = @article 
			 
			fetch stock 
			into @article,@qte,@seq 
			 
		end 
 
		close stock 
  		deallocate cursor stock 
	 
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,STNUMARM1, 
						STNUMARM2,STDEPOT,PrixAchatLigne,PrixRevient,PrixRevientLigne,PrixVente,PrixVenteLigne 
		from #Final 
		order by Seq 
		 
		drop table #Final 
	  end 
  	end 
else if @emplace1 is not null 
  begin 
	if @modevalo in (0,1,5) 
	begin 
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT, 
		STNUMARM1,STNUMARM2,STDEPOT, 
		PrixAchatLigne=(STPAHT/a.CVLOT)*STQTE, 
		PrixRevient=(case when @modevalo=0 then (STPAHT+STFRAIS) 
				  when @modevalo=1 then isnull(ARPRM,0) 
				  when @modevalo=5 then isnull(ARPVHT,0)/b.CVLOT
				  else (STPAHT+STFRAIS) end), 
		PrixRevientLigne=(case when @modevalo=0 then ((STPAHT+STFRAIS)/a.CVLOT)*STQTE 
				       when @modevalo=1 then isnull(ARPRM,0)*STQTE 
				       when @modevalo=5 then isnull(ARPVHT,0)/b.CVLOT*STQTE 
				       else ((STPAHT+STFRAIS)/a.CVLOT)*STQTE end), 
		PrixVente=ARPVHT, 
		PrixVenteLigne=round((ARPVHT/a.CVLOT),2)*STQTE 
		from FAR,FSTOCK,FCV a, FCV b,FARE,FDP 
		where ARCODE=STAR 
		and AREAR=ARCODE 
		and ARELIGNE=1 
		and ARUNITACHAT=a.CVUNIF 
		and ARUNITFACT=b.CVUNIF
	  	and (@nonstock = 1 or ARTYPE = 0)
		and AREEMP between @emplace1 and @emplace2 
		and (@date1 is null or STDATEENTR between @date1 and @date2) 
		and (@depot1 is null or STDEPOT between @depot1 and @depot2) 
		and (@article1 is null or ARCODE between @article1 and @article2) 
		and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		and (@fournisseur1 is null or ARFO between @fournisseur1 and @fournisseur2) 
		and (@numero is null or ARNUMEROTE=1) 
		and STQTE>0 
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
		order by AREEMP,ARCODE 
	end 
	else if @modevalo in (2,3,4) 
  	  begin 
		insert into #Final (ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,STNUMARM1, 
						STNUMARM2,STDEPOT,PrixAchatLigne,PrixRevient,PrixRevientLigne,PrixVente,PrixVenteLigne) 
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT, 
				STNUMARM1,STNUMARM2,STDEPOT, 
				PrixAchatLigne=(STPAHT/CVLOT)*STQTE, 
				0,0, 
				PrixVente=ARPVHT, 
		PrixVenteLigne=round((ARPVHT/CVLOT),2)*STQTE 
		from FAR,FSTOCK,FCV,FARE,FDP 
		where ARCODE=STAR
		and AREAR=ARCODE 
		and ARELIGNE=1 
		and ARUNITACHAT=CVUNIF
	  	and (@nonstock = 1 or ARTYPE = 0)
		and AREEMP between @emplace1 and @emplace2 
		and (@date1 is null or STDATEENTR between @date1 and @date2) 
		and (@depot1 is null or STDEPOT between @depot1 and @depot2) 
		and (@article1 is null or ARCODE between @article1 and @article2) 
		and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		and (@fournisseur1 is null or ARFO between @fournisseur1 and @fournisseur2) 
		and (@numero is null or ARNUMEROTE=1) 
		and STQTE>0 
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
		order by AREEMP,ARCODE 
		 
		create unique index seq on #Final (Seq) 
		 
		 
		open stock 
		 
		fetch stock 
		into @article,@qte,@seq 
		 
		while (@@sqlstatus = 0) 
			begin 
 
		  if @articleprecedent != @article 
		  begin 
			select 	@PrixRevient = 0, 
					@PrixRevientLigne = 0 
			 
			if @modevalo = 2									/*--------------------- PUMP */ 
			begin 
			  select @PrixRevient=isnull(PUMP,0) 
			  from FPUM 
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
			end 
			else if @modevalo = 3								/*--------------------- PRM Mensuel */ 
			begin 
			  set rowcount 1 
			   
			  select @PrixRevient=isnull(PRM,0) 
			  from FPRM 
			  where PRMAR = @article 
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate())) 
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate())) 
			  and PRMAR = @article 
			  order by PRMAN desc,PRMMOIS desc 
			   
			  set rowcount 0 
			   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
			end 
			else  if @modevalo = 4								/*--------------------- DPA unitaire */ 
			begin 
			  set rowcount 1 
			 
			  select @PrixRevient = (BLLPAHT+BLLFRAIS)/CVLOT 
			  from FBLL,FCV 
			  where BLLAR=@article 
			  and CVUNIF=BLLUA 
			  having BLLAR=@article 
			  and CVUNIF=BLLUA 
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end)) 
			 
			  if isnull(@PrixRevient,0)=0 
			  begin 
				select @PrixRevient = (SILPAHT+SILFRAIS)/CVLOT 
				from FSIL,FAR,FCV 
				where SILARTICLE=@article 
				and ARCODE = SILARTICLE 
				and ARUNITACHAT = CVUNIF 
				having SILARTICLE=@article 
				and ARCODE = SILARTICLE 
				and ARUNITACHAT = CVUNIF 
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end)) 
			  end 
			   
			  set rowcount 0 
			   
			  if @PrixRevient is null 
				select @PrixRevient = 0 
	   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
			end 
		  end 
		  else if @articleprecedent = @article 
		  begin 
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
		  end 
 
 
			update #Final set PrixRevient = @PrixRevient, PrixRevientLigne = @PrixRevientLigne 
			where Seq = @seq 
		 
			select  @articleprecedent = @article 
			 
			fetch stock 
			into @article,@qte,@seq 
			 
		end 
		 
		close stock 
  		deallocate cursor stock 
		 
	 
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,STNUMARM1, 
						STNUMARM2,STDEPOT,PrixAchatLigne,PrixRevient,PrixRevientLigne,PrixVente,PrixVenteLigne 
		from #Final 
		order by Seq 
		 
		drop table #Final 
	  end 
  	end 
   
 
end	 
                                                                                                                                                                                                                   




go

