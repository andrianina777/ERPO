


create procedure CA_Clients_Comp (@ent	char(5)	= null,
								  @an	smallint)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Finale
(
client		char(12)	not null,
numcompta	char(12)	not null,
nom			varchar(35)	not null,
adr1		varchar(50)		null,
adr2		varchar(50)		null,
cp			varchar(12)		null,
ville		varchar(30)		null,
pays		varchar(30)		null,
ca_1		numeric(14,2)	null,
ca			numeric(14,2)	null
)

declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@client			char(12)


select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))



insert into #Finale (client,numcompta,nom,adr1,adr2,cp,ville,pays,ca_1,ca)
select STCL,CLNUMCOMPTABLE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLPAYS,
			sum(case when STAN=@an-1 then STCAFA else 0 end),
			sum(case when STAN=@an then STCAFA else 0 end)
from FST,FCL,FAR
where CLCODE=STCL
and ARCODE=START
and STAN between @an-1 and @an
and ARTYPE != 6
and (@ent is null or (STENT=@ent and CLENT=STENT))
group by STCL,CLNUMCOMPTABLE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLPAYS



select client,numcompta,nom,adr1,adr2,cp,ville,pays,CA_N_1=isnull(ca_1,0),CA_N=isnull(ca,0)
from #Finale
order by client
compute sum(isnull(ca_1,0)),sum(isnull(ca,0))


drop table #Finale

end



go

