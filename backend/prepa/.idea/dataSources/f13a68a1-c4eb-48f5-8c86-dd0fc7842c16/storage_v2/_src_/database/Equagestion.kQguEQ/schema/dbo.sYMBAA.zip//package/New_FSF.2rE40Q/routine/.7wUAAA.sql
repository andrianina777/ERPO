


/* Procedure permettant la creation des lignes groupees par familles
	du tableau de bord fournisseurs pour N, N-1, N-2 */


create procedure New_FSF (@an	int)
with recompile
as
begin

set arithabort numeric_truncation off

declare @labase		varchar(30)	
select  @labase = db_name()	



create table #Far
(
ARCODE		char(15)	not null,
ARFAM		char(8)		not null,
ARTYPE		tinyint		not null
)

create table #SF
(
fournisseur		char(12)		not null,
famille			char(8)			not null,
annee			int				not null,
mois			int				not null,
qtebl			int				not null,
cabl			numeric(14,2)	not null,
qtecf			int				not null,
cacf			numeric(14,2)	not null
)

create table #FromCFL
(
CFLFO			char(12)		not null,
ARFAM			char(8)			not null,
annee			int				not null,
mois			int				not null,
CFLRESTE		int				not null,
CALigne			numeric(14,2)	not null
)

create table #SCF
(
FO				char(12)		not null,
FAM				char(8)			not null,
AN				int				not null,
MOIS			int				not null,
QTE				int				not null,
CA				numeric(14,2)	not null
)

declare @date			datetime
declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime
		
select  @smalldate1 = convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
select  @smalldate2 = convert(smalldatetime,'12/31/'+convert(varchar(4),@an))


insert into #Far (ARCODE,ARFAM,ARTYPE)
select ARCODE,ARFAM,isnull(ARTYPE,0)
from FAR

create unique clustered index article on #Far (ARCODE)


   delete FSF
   where SFAN = @an
   
   dump tran @labase with truncate_only	

  insert into #SF (fournisseur,famille,annee,mois,qtebl,cabl,qtecf,cacf)
	select BLLFO,ARFAM,datepart(yy,BLLDATE),datepart(mm,BLLDATE),SFQTEBL=sum(BLLQTE),SFCABL=convert(numeric(14,2),sum(BLLTOTHT)),0,0
	from FBLL,#Far
	where ARCODE=BLLAR
	and BLLDATE between @smalldate1 and @smalldate2
	and ARTYPE in (0,1)
	and substring(BLLLIENCODE,1,2)!="CS"
	group by BLLFO,ARFAM,datepart(yy,BLLDATE),datepart(mm,BLLDATE)
	

  insert into #SF (fournisseur,famille,annee,mois,qtebl,cabl,qtecf,cacf)
	select RFLFO,ARFAM,datepart(yy,RFLDATE),datepart(mm,RFLDATE),SFQTEBL=-sum(RFLQTE),SFCABL=convert(numeric(14,2),-sum(RFLTOTALHT)),0,0
	from FRFL,#Far
	where ARCODE=RFLARTICLE
	and RFLDATE between @smalldate1 and @smalldate2
	and ARTYPE in (0,1)
	group by RFLFO,ARFAM,datepart(yy,RFLDATE),datepart(mm,RFLDATE)

	
   insert into FSF(SFFO,SFFAM,SFAN,SFMOIS,SFQTEBL,SFCABL,SFQTECF,SFCACF,SFDATEMDF)
   select fournisseur,famille,annee,mois,sum(qtebl),convert(numeric(14,2),sum(cabl)),sum(qtecf),convert(numeric(14,2),sum(cacf)),getdate()
   from #SF
   group by fournisseur,famille,annee,mois
   
   drop table #SF
   
   insert into #FromCFL (CFLFO,ARFAM,annee,mois	,CFLRESTE,CALigne)
   select CFLFO,ARFAM,datepart(yy,CFLDATEP),
   			datepart(mm,CFLDATEP),CFLRESTE,
			round((CFLTOTALHT/CFLQTE),2)*CFLRESTE
	from FRCF,FCFL,#Far
	where RCFSEQ=CFLSEQ
	and RCFARTICLE=ARCODE
	and CFLQTE != 0
	and ARTYPE in (0,1)
	and RCFDATE between @smalldate1 and @smalldate2

   
   insert into #SCF (FO,FAM,AN,MOIS,QTE,CA)
   select CFLFO,ARFAM,annee,mois,sum(CFLRESTE),sum(CALigne)
	from #FromCFL
	group by CFLFO,ARFAM,annee,mois
	
	create unique clustered index code on #SCF (FO,FAM,AN,MOIS)

   
    insert into FSF (SFFO,SFFAM,SFAN,SFMOIS,SFQTEBL,SFCABL,SFQTECF,SFCACF,SFDATEMDF)
	select FO,FAM,AN,MOIS,0,0,0,0,getdate()
	from #SCF
	where not exists (select * from FSF where SFFO=#SCF.FO and SFFAM=#SCF.FAM and SFAN=#SCF.AN and SFMOIS=#SCF.MOIS)

   update FSF
	set SFQTECF=QTE,SFCACF=convert(numeric(14,2),CA)
	from #SCF
	where SFFO=FO
	and SFFAM=FAM
	and SFAN=AN
	and SFMOIS=MOIS

	
  dump tran @labase with truncate_only
   
   drop table #FromCFL
   drop table #SCF
   drop table #Far

end



go

