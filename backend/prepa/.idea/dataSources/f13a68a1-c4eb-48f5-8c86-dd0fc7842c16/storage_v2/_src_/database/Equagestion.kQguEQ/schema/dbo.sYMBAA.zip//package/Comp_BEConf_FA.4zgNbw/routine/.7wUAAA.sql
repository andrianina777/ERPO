



create procedure Comp_BEConf_FA (@marque	char(12),
								 @datedeb	datetime,
							     @datefin	datetime
							 	)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Final
(
article		char(15)	not null,
arreffour	char(20)	not null,
arlib		varchar(80)		null,
codeBE		char(10)	not null,
ligneBE		int			not null,
qteBE		int				null,
qteFA		int				null,
valFA		numeric(14,2)	null
)


select ARCODE,ARREFFOUR,ARLIB,codeBE=BELCODE,ligneBE=BELNUM,QteBE=BELQTE
into #Bel
from FAR,FBEL
where ARCODE=BELARTICLE
and ARFO=@marque
and BELSTADE > 1
and BELDATE between @datedeb and @datefin


select ARCODE,ARREFFOUR,ARLIB,FALLIENCODE,FALLIENNUM,FALQTE,FALTOTALHT
into #Fal
from FFAL,#Bel
where FALLIENCODE=codeBE
and FALLIENNUM=ligneBE
and FALARTICLE=ARCODE


insert into #Final (article,arreffour,arlib,codeBE,ligneBE,qteBE,qteFA,valFA)
select ARCODE,ARREFFOUR,ARLIB,codeBE,ligneBE,QteBE,0,0
from #Bel


insert into #Final (article,arreffour,arlib,codeBE,ligneBE,qteBE,qteFA,valFA)
select ARCODE,ARREFFOUR,ARLIB,FALLIENCODE,FALLIENNUM,0,FALQTE,FALTOTALHT
from #Fal



select article,arreffour,arlib,codeBE,ligneBE,QteBE=sum(qteBE),QteFA=sum(qteFA),ValeurFA=sum(valFA)
from #Final
group by article,arreffour,arlib,codeBE,ligneBE
order by article,arreffour,arlib,codeBE,ligneBE
compute sum(sum(valFA))


drop table #Bel
drop table #Fal
drop table #Final


end



go

