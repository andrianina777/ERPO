


create procedure Previsions_Exp	(	@ent		char(5) = null,
									@datedeb	datetime,
								 	@datefin	datetime,
								 	@article	char(15) = null,
								 	@depart		char(8) = null,
								 	@marque		char(12) = null,
								 	@famille	char(8) = null,
								 	@rep		char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off

declare	@les_mois	int,
		@date_org	datetime

declare @an_prec	int,
		@an			int,
		@an_1		int,
		@an_2		int,
		@an_3		int,
		@an_4		int,
		@an_5		int,
		@an_6		int,
		@an_7		int,
		@an_8		int,
		@an_9		int,
		@an_10		int,
		@mois_prec	tinyint,
		@mois		tinyint,
		@mois_1		tinyint,
		@mois_2		tinyint,
		@mois_3		tinyint,
		@mois_4		tinyint,
		@mois_5		tinyint,
		@mois_6		tinyint,
		@mois_7		tinyint,
		@mois_8		tinyint,
		@mois_9		tinyint,
		@mois_10	tinyint
		
declare @multient	tinyint

select @multient=KIMULTIENTITE from KInfos

select 	@an = datepart(yy,@datedeb),
		@mois = datepart(mm,@datedeb)

select	@les_mois = (@an * 12) + @mois

declare @type		tinyint,
		@division	char(8)

select  @type = 0

if @rep is not null
	select  @type=RETYPE, @division=REDIV from FREP where RECODE=@rep



/* calcul des mois - annees relatifs au mois en cours */
select @les_mois = @les_mois - 1
exec periode @les_mois, @an_prec output, @mois_prec output
select @les_mois = @les_mois + 2
exec periode @les_mois, @an_1 output, @mois_1 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_2 output, @mois_2 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_3 output, @mois_3 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_4 output, @mois_4 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_5 output, @mois_5 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_6 output, @mois_6 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_7 output, @mois_7 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_8 output, @mois_8 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_9 output, @mois_9 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_10 output, @mois_10 output

select @date_org = convert(datetime,convert(varchar(4),@mois_prec)+'/01/'+convert(varchar(4),@an_prec))

create table #Final
(
article			char(15)		not null,
recep_prec		int				null,
cde_prec		int				null,
valeur_prec		numeric(14,2)	null,
recep_mois		int				null,
cde_mois		int				null,
valeur_mois		numeric(14,2)	null,
recep_mois_1	int				null,
cde_mois_1		int				null,
valeur_mois_1	numeric(14,2)	null,
recep_mois_2	int				null,
cde_mois_2		int				null,
valeur_mois_2	numeric(14,2)	null,
recep_mois_3	int				null,
cde_mois_3		int				null,
valeur_mois_3	numeric(14,2)	null,
recep_mois_4	int				null,
cde_mois_4		int				null,
valeur_mois_4	numeric(14,2)	null,
recep_mois_5	int				null,
cde_mois_5		int				null,
valeur_mois_5	numeric(14,2)	null,
recep_mois_6	int				null,
cde_mois_6		int				null,
valeur_mois_6	numeric(14,2)	null,
recep_mois_7	int				null,
cde_mois_7		int				null,
valeur_mois_7	numeric(14,2)	null,
recep_mois_8	int				null,
cde_mois_8		int				null,
valeur_mois_8	numeric(14,2)	null,
recep_mois_9	int				null,
cde_mois_9		int				null,
valeur_mois_9	numeric(14,2)	null,
recep_mois_10	int				null,
cde_mois_10		int				null,
valeur_mois_10	numeric(14,2)	null
)

create table #Sortie
(
article			char(15)		not null,
recep_prec		int				null,
cde_prec		int				null,
valeur_prec		numeric(14,2)	null,
recep_mois		int				null,
cde_mois		int				null,
valeur_mois		numeric(14,2)	null,
recep_mois_1	int				null,
cde_mois_1		int				null,
valeur_mois_1	numeric(14,2)	null,
recep_mois_2	int				null,
cde_mois_2		int				null,
valeur_mois_2	numeric(14,2)	null,
recep_mois_3	int				null,
cde_mois_3		int				null,
valeur_mois_3	numeric(14,2)	null,
recep_mois_4	int				null,
cde_mois_4		int				null,
valeur_mois_4	numeric(14,2)	null,
recep_mois_5	int				null,
cde_mois_5		int				null,
valeur_mois_5	numeric(14,2)	null,
recep_mois_6	int				null,
cde_mois_6		int				null,
valeur_mois_6	numeric(14,2)	null,
recep_mois_7	int				null,
cde_mois_7		int				null,
valeur_mois_7	numeric(14,2)	null,
recep_mois_8	int				null,
cde_mois_8		int				null,
valeur_mois_8	numeric(14,2)	null,
recep_mois_9	int				null,
cde_mois_9		int				null,
valeur_mois_9	numeric(14,2)	null,
recep_mois_10	int				null,
cde_mois_10		int				null,
valeur_mois_10	numeric(14,2)	null
)

/* Commandes Clients de la periode, en partant de mois-1 */

select RCCARTICLE,RCCAN,RCCMOIS,qte=isnull(sum(RCCQTE),0),valeur=isnull(sum(round(RCCQTE*CCLTOTALHT/CCLQTE,2)),0)
into #Cdes
from FRCC,FCCL,FCL,FAR,FCC
where ARCODE=RCCARTICLE
and ARTYPE in (0,1)
and CLCODE=RCCCL
and CLPAYEUR in (0,1)
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and RCCDATE between @date_org and @datefin
and (@article is null or ARCODE=@article)
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@rep is null or @type = 2 or CCLREP = @rep)
and (@rep is null or @type != 2 or CCLREPDIV = @rep)
and (@multient = 0 or (@ent is null or (RCCENT=@ent and CCLENT=@ent and CLENT=@ent and CCENT=@ent)))
group by RCCARTICLE,RCCAN,RCCMOIS
order by RCCARTICLE,RCCAN,RCCMOIS

/* Liste des articles en commandes */

select ARCODE,ARLIB
into #Far
from FAR,#Cdes
where ARCODE=RCCARTICLE
group by ARCODE,ARLIB


/* Stock pour expeditions et sous douanes+autres des produits en commandes Clients */

select STAR,STQTE_LOC=isnull(sum(case when DPLOC=1 then STQTE else 0 end),0),
		STQTE_DOUA=isnull(sum(case when DPLOC != 1 then STQTE else 0 end),0)
into #Stock
from FSTOCK,#Far,FDP
where STAR=ARCODE
and STQTE != 0
and DPCODE=STDEPOT and (@multient = 0 or (@ent is null or (DPENT=@ent and DPCENTRAL=0)))
group by STAR


/* Reliquats de commandes Fournisseurs (avant mois-1) */

select RCFARTICLE,RCFQTE_old=isnull(sum(RCFQTE),0)
into #Recep_old
from FRCF,#Far
where RCFARTICLE=ARCODE
and RCFDATE < @date_org
and (@multient = 0 or (@ent is null or RCFENT=@ent))
group by RCFARTICLE

/* Reliquats de commandes Clients (avant mois-1) */

select RCCARTICLE,RCCQTE=isnull(sum(RCCQTE),0),RCCVAL=isnull(sum(round(RCCQTE*CCLTOTALHT/CCLQTE,2)),0)
into #Reliq
from FRCC,FCCL,FCL,#Far,FCC
where RCCARTICLE=ARCODE
and CLCODE=RCCCL
and CLPAYEUR in (0,1)
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and RCCDATE < @date_org
and (@multient = 0 or (@ent is null or (RCCENT=@ent and CCLENT=@ent and CLENT=@ent and CCENT=@ent)))
group by RCCARTICLE
order by RCCARTICLE

/* Commandes Fournisseurs a partir de mois-1 */

select RCFARTICLE,RCFAN,RCFMOIS=datepart(mm,dateadd(dd,5,RCFDATE)),RCFQTE=isnull(sum(RCFQTE),0)
into #Recep
from FRCF,#Far
where RCFARTICLE=ARCODE
and RCFDATE between @date_org and @datefin
and (@multient = 0 or (@ent is null or RCFENT=@ent))
group by RCFARTICLE,RCFAN,datepart(mm,dateadd(dd,5,RCFDATE))
order by RCFARTICLE,RCFAN,datepart(mm,dateadd(dd,5,RCFDATE))


/* Mise en place des valeurs de commandes Clients sur la periode */


insert into #Final (article,
					cde_prec, valeur_prec,
					cde_mois, valeur_mois,
					cde_mois_1, valeur_mois_1,
					cde_mois_2, valeur_mois_2,
					cde_mois_3, valeur_mois_3,
					cde_mois_4, valeur_mois_4, 
					cde_mois_5, valeur_mois_5,
					cde_mois_6, valeur_mois_6,
					cde_mois_7, valeur_mois_7,
					cde_mois_8, valeur_mois_8,
					cde_mois_9, valeur_mois_9,
					cde_mois_10, valeur_mois_10)
select ARCODE,
		isnull(sum(case when RCCAN=@an_prec and RCCMOIS=@mois_prec then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_prec and RCCMOIS=@mois_prec then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an and RCCMOIS=@mois then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an and RCCMOIS=@mois then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_1 and RCCMOIS=@mois_1 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_1 and RCCMOIS=@mois_1 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_2 and RCCMOIS=@mois_2 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_2 and RCCMOIS=@mois_2 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_3 and RCCMOIS=@mois_3 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_3 and RCCMOIS=@mois_3 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_4 and RCCMOIS=@mois_4 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_4 and RCCMOIS=@mois_4 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_5 and RCCMOIS=@mois_5 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_5 and RCCMOIS=@mois_5 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_6 and RCCMOIS=@mois_6 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_6 and RCCMOIS=@mois_6 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_7 and RCCMOIS=@mois_7 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_7 and RCCMOIS=@mois_7 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_8 and RCCMOIS=@mois_8 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_8 and RCCMOIS=@mois_8 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_9 and RCCMOIS=@mois_9 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_9 and RCCMOIS=@mois_9 then valeur else 0 end),0),
		isnull(sum(case when RCCAN=@an_10 and RCCMOIS=@mois_10 then qte else 0 end),0),
		isnull(sum(case when RCCAN=@an_10 and RCCMOIS=@mois_10 then valeur else 0 end),0)
from #Far,#Cdes
where ARCODE=RCCARTICLE
group by ARCODE


/* Mise en place des valeurs de commandes Fournisseurs sur la periode */

insert into #Final (article,
					recep_prec, recep_mois, recep_mois_1,
					recep_mois_2, recep_mois_3, recep_mois_4,
					recep_mois_5, recep_mois_6, recep_mois_7,
					recep_mois_8, recep_mois_9, recep_mois_10)
select ARCODE,
		isnull(sum(case when RCFAN=@an_prec and RCFMOIS=@mois_prec then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an and RCFMOIS=@mois then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_1 and RCFMOIS=@mois_1 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_2 and RCFMOIS=@mois_2 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_3 and RCFMOIS=@mois_3 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_4 and RCFMOIS=@mois_4 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_5 and RCFMOIS=@mois_5 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_6 and RCFMOIS=@mois_6 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_7 and RCFMOIS=@mois_7 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_8 and RCFMOIS=@mois_8 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_9 and RCFMOIS=@mois_9 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_10 and RCFMOIS=@mois_10 then RCFQTE else 0 end),0)
from #Far,#Recep
where ARCODE=RCFARTICLE
group by ARCODE


/* Aggregation des commandes Clients et Fournisseurs */

insert into #Sortie
select article,
	   isnull(sum(recep_prec),0), isnull(sum(cde_prec),0), isnull(sum(valeur_prec),0),
	   isnull(sum(recep_mois),0), isnull(sum(cde_mois),0), isnull(sum(valeur_mois),0),
	   isnull(sum(recep_mois_1),0), isnull(sum(cde_mois_1),0), isnull(sum(valeur_mois_1),0),
	   isnull(sum(recep_mois_2),0), isnull(sum(cde_mois_2),0), isnull(sum(valeur_mois_2),0),
	   isnull(sum(recep_mois_3),0), isnull(sum(cde_mois_3),0), isnull(sum(valeur_mois_3),0),
	   isnull(sum(recep_mois_4),0), isnull(sum(cde_mois_4),0), isnull(sum(valeur_mois_4),0), 
	   isnull(sum(recep_mois_5),0), isnull(sum(cde_mois_5),0), isnull(sum(valeur_mois_5),0),
	   isnull(sum(recep_mois_6),0), isnull(sum(cde_mois_6),0), isnull(sum(valeur_mois_6),0),
	   isnull(sum(recep_mois_7),0), isnull(sum(cde_mois_7),0), isnull(sum(valeur_mois_7),0),
	   isnull(sum(recep_mois_8),0), isnull(sum(cde_mois_8),0), isnull(sum(valeur_mois_8),0),
	   isnull(sum(recep_mois_9),0), isnull(sum(cde_mois_9),0), isnull(sum(valeur_mois_9),0),
	   isnull(sum(recep_mois_10),0), isnull(sum(cde_mois_10),0), isnull(sum(valeur_mois_10),0)
from #Final
group by article


/* select final */


select ARCODE,ARLIB,
		isnull(STQTE_LOC,0),isnull(STQTE_DOUA,0),isnull(RCFQTE_old,0),isnull(RCCQTE,0),isnull(RCCVAL,0),
		recep_prec,cde_prec,valeur_prec,
		recep_mois,isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois)
							- cde_prec,
						cde_mois,valeur_mois,
		recep_mois_1, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1)
								- (cde_prec + cde_mois),
						cde_mois_1,valeur_mois_1,
		recep_mois_2, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2)
								- (cde_prec + cde_mois + cde_mois_1),
						cde_mois_2,valeur_mois_2,
		recep_mois_3, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2),
						cde_mois_3,valeur_mois_3,
		recep_mois_4, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3 
									+ recep_mois_4)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3),
						cde_mois_4,valeur_mois_4,
		recep_mois_5, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3
									+ recep_mois_4 + recep_mois_5)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3 + cde_mois_4),
						cde_mois_5,valeur_mois_5,
		recep_mois_6, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3
									+ recep_mois_4 + recep_mois_5 + recep_mois_6)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3 + cde_mois_4 
									+ cde_mois_5),
						cde_mois_6,valeur_mois_6,
		recep_mois_7, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3
									+ recep_mois_4 + recep_mois_5 + recep_mois_6 + recep_mois_7)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3 + cde_mois_4 
									+ cde_mois_5 + cde_mois_6),
						cde_mois_7,valeur_mois_7,
		recep_mois_8, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3
									+ recep_mois_4 + recep_mois_5 + recep_mois_6 + recep_mois_7 + recep_mois_8)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3 + cde_mois_4 
									+ cde_mois_5 + cde_mois_6 + cde_mois_7),
						cde_mois_8,valeur_mois_8,
		recep_mois_9, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3
									+ recep_mois_4 + recep_mois_5 + recep_mois_6 + recep_mois_7 + recep_mois_8
									+ recep_mois_9)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3 + cde_mois_4 
									+ cde_mois_5 + cde_mois_6 + cde_mois_7 + cde_mois_8),
						cde_mois_9,valeur_mois_9,
		recep_mois_10, isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) - isnull(RCCQTE,0) + (recep_prec + recep_mois + recep_mois_1 + recep_mois_2 + recep_mois_3
									+ recep_mois_4 + recep_mois_5 + recep_mois_6 + recep_mois_7 + recep_mois_8
									+ recep_mois_9 + recep_mois_10)
								- (cde_prec + cde_mois + cde_mois_1 + cde_mois_2 + cde_mois_3 + cde_mois_4 
									+ cde_mois_5 + cde_mois_6 + cde_mois_7 + cde_mois_8 + cde_mois_9),
						cde_mois_10,valeur_mois_10
from #Sortie,#Far,#Stock,#Recep_old,#Reliq
where ARCODE = article
and ARCODE *= STAR
and ARCODE *= RCFARTICLE
and ARCODE *= RCCARTICLE
order by ARCODE,ARLIB


drop table #Far
drop table #Cdes
drop table #Stock
drop table #Recep
drop table #Recep_old
drop table #Reliq
drop table #Final
drop table #Sortie

end



go

