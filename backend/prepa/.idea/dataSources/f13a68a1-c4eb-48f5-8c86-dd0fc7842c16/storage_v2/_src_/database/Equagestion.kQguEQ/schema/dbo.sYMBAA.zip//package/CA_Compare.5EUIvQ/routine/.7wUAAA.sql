



create procedure CA_Compare
with recompile
as
begin
	
	set arithabort numeric_truncation off


	set nocount on
	
	declare @date 		smalldatetime,
			@date1 		smalldatetime,
			@date2 		smalldatetime,
			@FactY_1	numeric(14,2),
			@FactY		numeric(14,2),
			@FactM_1	numeric(14,2),
			@FactM		numeric(14,2),
			@BEY_1		numeric(14,2),
			@BEY		numeric(14,2),
			@BEM_1		numeric(14,2),
			@BEM		numeric(14,2),
			@total		numeric(14,2),
			@ladate1	varchar(20),
			@ladate2	varchar(20),
			@text1		varchar(20),
			@text2		varchar(20),
			@text3		varchar(20)
	
	select @date = getdate()
	
	/***** Annee en cours - Depuis le debut de l''annee *****/
	
	select @date1 = convert (datetime,"01/01/" + convert(varchar(4),datepart(yy,@date)))
	select @date2 = @date
	
	select @FactY=isnull(sum(FATOTALHT),0)
	from FFA
	where FADATE between @date1 and @date2
	
	select @BEY=isnull(sum(BELTOTALHT),0)
	from FRBE,FBEL
	where RBESEQ=BELSEQ
	and RBEDEMO=0
	and RBEDATE between @date1 and @date2
	
	select @ladate1 = convert(varchar(2),datepart(dd,@date1))+'/'+convert(varchar(2),datepart(mm,@date1))+'/'+convert(varchar(4),datepart(yy,@date1))
	select @ladate2 = convert(varchar(2),datepart(dd,@date2))+'/'+convert(varchar(2),datepart(mm,@date2))+'/'+convert(varchar(4),datepart(yy,@date2))
	select @total	= @FactY + @BEY
	select @text1   = convert(varchar(20),@FactY),
		   @text2	= convert(varchar(20),@BEY),
		   @text3	= convert(varchar(20),@total)
	
	exec Milliers @text1 output
	exec Milliers @text2 output
	exec Milliers @text3 output
	
	
	print "---- CA Annee en cours entre le  %1!  et le  %2!",@ladate1,@ladate2
	print ""
	print "TotalFactures_An ---------- TotalExpeditions_An ---------- Total_General_An"
	print "%1! --------------- %2! --------------- %3!",@text1,@text2,@text3
	print ""
	print ""
	
	/***** Annee N-1 - Depuis le debut de l''annee *****/
	
	select @date1 = convert (datetime,"01/01/" + convert(varchar(4),datepart(yy,dateadd(yy,-1,@date))))
	
	if (datepart(mm,@date)=2) and (datepart(dd,@date)=29)
		select @date2 = convert (datetime,convert(varchar,datepart(mm,@date)) + "/" + "28" + "/" + convert(varchar(4),datepart(yy,dateadd(yy,-1,@date))))
	else
		select @date2 = convert (datetime,convert(varchar,datepart(mm,@date)) + "/" + convert(varchar,datepart(dd,@date)) + "/" + convert(varchar(4),datepart(yy,dateadd(yy,-1,@date))))
	
	select @FactY_1=isnull(sum(FATOTALHT),0)
	from FFA
	where FADATE between @date1 and @date2
	
	select @BEY_1=isnull(sum(BELTOTALHT),0)
	from FRBE,FBEL
	where RBESEQ=BELSEQ
	and RBEDEMO=0
	and RBEDATE between @date1 and @date2
	
	select @ladate1 = convert(varchar(2),datepart(dd,@date1))+'/'+convert(varchar(2),datepart(mm,@date1))+'/'+convert(varchar(4),datepart(yy,@date1))
	select @ladate2 = convert(varchar(2),datepart(dd,@date2))+'/'+convert(varchar(2),datepart(mm,@date2))+'/'+convert(varchar(4),datepart(yy,@date2))
	select @total	= @FactY_1 + @BEY_1
	select @text1   = convert(varchar(20),@FactY_1),
		   @text2	= convert(varchar(20),@BEY_1),
		   @text3	= convert(varchar(20),@total)
	
	exec Milliers @text1 output
	exec Milliers @text2 output
	exec Milliers @text3 output

	
	print "---- CA Annee N-1 entre le  %1!  et le  %2!",@ladate1,@ladate2
	print ""
	print "TotalFactures_An_1 -------- TotalExpeditions_An_1 -------- Total_General_An_1"
	print "%1! ----------------- %2! ----------------- %3!",@text1,@text2,@text3
	print ""
	print ""
	
	/***** Annee en cours - Mois en cours *****/
	
	select @date1 = convert (datetime,convert(varchar,datepart(mm,@date)) + "/01/" + convert(varchar(4),datepart(yy,@date)))
	select @date2 = @date
	
	select @FactM=isnull(sum(FATOTALHT),0)
	from FFA
	where FADATE between @date1 and @date2
	
	select @BEM=isnull(sum(BELTOTALHT),0)
	from FRBE,FBEL
	where RBESEQ=BELSEQ
	and RBEDEMO=0
	and RBEDATE between @date1 and @date2
	
	select @ladate1 = convert(varchar(2),datepart(dd,@date1))+'/'+convert(varchar(2),datepart(mm,@date1))+'/'+convert(varchar(4),datepart(yy,@date1))
	select @ladate2 = convert(varchar(2),datepart(dd,@date2))+'/'+convert(varchar(2),datepart(mm,@date2))+'/'+convert(varchar(4),datepart(yy,@date2))
	select @total	= @FactM + @BEM
	select @text1   = convert(varchar(20),@FactM),
		   @text2	= convert(varchar(20),@BEM),
		   @text3	= convert(varchar(20),@total)
	
	exec Milliers @text1 output
	exec Milliers @text2 output
	exec Milliers @text3 output

	
	print "---- CA Mois en cours entre le  %1!  et le  %2!",@ladate1,@ladate2
	print ""
	print "TotalFactures_Mois -------- TotalExpeditions_Mois -------- Total_General_Mois"
	print "%1! --------------- %2! --------------- %3!",@text1,@text2,@text3
	print ""
	print ""
	
	/***** Annee N-1 - Mois en cours *****/
	
	select @date1 = convert (datetime,convert(varchar,datepart(mm,@date)) + "/01/" + convert(varchar(4),datepart(yy,dateadd(yy,-1,@date))))
	if (datepart(mm,@date)=2) and (datepart(dd,@date)=29)
		select @date2 = convert (datetime,convert(varchar,datepart(mm,@date)) + "/" + "28" + "/" + convert(varchar(4),datepart(yy,dateadd(yy,-1,@date))))
	else
		select @date2 = convert (datetime,convert(varchar,datepart(mm,@date)) + "/" + convert(varchar,datepart(dd,@date)) + "/" + convert(varchar(4),datepart(yy,dateadd(yy,-1,@date))))
	
	select @FactM_1=isnull(sum(FATOTALHT),0)
	from FFA
	where FADATE between @date1 and @date2
	
	select @BEM_1=isnull(sum(BELTOTALHT),0)
	from FRBE,FBEL
	where RBESEQ=BELSEQ
	and RBEDEMO=0
	and RBEDATE between @date1 and @date2
	
	select @ladate1 = convert(varchar(2),datepart(dd,@date1))+'/'+convert(varchar(2),datepart(mm,@date1))+'/'+convert(varchar(4),datepart(yy,@date1))
	select @ladate2 = convert(varchar(2),datepart(dd,@date2))+'/'+convert(varchar(2),datepart(mm,@date2))+'/'+convert(varchar(4),datepart(yy,@date2))
	select @total	= @FactM_1 + @BEM_1
	select @text1   = convert(varchar(20),@FactM_1),
		   @text2	= convert(varchar(20),@BEM_1),
		   @text3	= convert(varchar(20),@total)
	
	exec Milliers @text1 output
	exec Milliers @text2 output
	exec Milliers @text3 output

	
	print "---- CA Mois N-1 entre le  %1!  et le  %2!",@ladate1,@ladate2
	print ""
	print "TotalFactures_Mois_1 ------ TotalExpeditions_Mois_1 ------ Total_General_Mois_1"
	print "%1! ----------------- %2! ----------------- %3!",@text1,@text2,@text3
	print ""
	print ""
	
	
end



go

