


/* ? franco ? recommande ? ligne BE ? ECHSPE ? EXCOLISAGE */
create procedure Photo_FEX_insert
	@DATE		smalldatetime,	/* date traitement chronopost */
	@CL			varchar(7),		/* code client (7) */
	@ADR		varchar(8),		/* code adresse */
	@NOM1		varchar(35),
	@NOM2		varchar(35),
	@ADR1		varchar(35),
	@ADR2		varchar(35),
	@CP			varchar(9),
	@VILLE		varchar(30),
	@PY			char(2),
	@TOTALHT	numeric(14,2),	/* Chronopost = HT non compris assurance */
	@TOTCOLIS	int,
	@TOTPOIDS	real,
	@ASSUR		numeric(14,2),	/* Montant assure */
	@CC			char(10)		/* code commande */

/* creee le 29/07/2006 par xmp
   modifiee le       par  
   
   creation d''une fiche d''expedition selon fichier recapitulatif quotidien Chronopost */
   
as 
begin
	/* sequentiel */
	declare @seq int
	execute eq_GetSeq_proc 'FEX', 1, @seq output
	if @@error != 0
		return
	
	/* code */
	declare @an int, @mois int, @num int, @codeex char(10)
	select @an = datepart(yy,@DATE), @mois = datepart(mm,@DATE)
	execute eq_GetNum_proc 'FR', 'FEX', @an, @mois, 1, @num output
	if @@error != 0
		return
	select @codeex = 'EX' + right(convert(char(4),@an),2)
		+ replicate('0',2-char_length(convert(varchar(2),@mois))) + convert(varchar(2),@mois)
		+ replicate('0',4-char_length(convert(varchar(4),@num))) + convert(varchar(4),@num)

	/* elements divers */
	declare @samedi tinyint, @pays varchar(30), @franco tinyint, @echspe tinyint
	select @samedi = CLSAMEDI from FCL where CLCODE = @CL
	select 
		@NOM1 = (case when isnull(@NOM1,'') = '' then ADRNOM else @NOM1 end),
		@NOM2 = (case when isnull(@NOM2,'') = '' then ADRPRENOM else @NOM2 end),
		@ADR1 = (case when isnull(@ADR1,'') = '' then ADRADR1 else @ADR1 end),
		@ADR2 = (case when isnull(@ADR2,'') = '' then ADRADR2 else @ADR2 end),
		@CP = (case when isnull(@CP,'') = '' then ADRCP else @CP end),
		@VILLE = (case when isnull(@VILLE,'') = '' then ADRVILLE else @VILLE end),
		@PY = (case when isnull(@PY,'') = '' then ADRPY else @PY end)
	from FADR where ADRTYPEFIC = 'CL' and ADRTYPEADR in ('PR','LI') 
		and ADRCODELI = @CL and ADRCODEADR = @ADR
	select @pays = PYNOM from FPY where PYCODE = @PY
	select @franco = isnull(CCFRANCO,0), @echspe = isnull(CCECHSPE,0) from FCC where CCCODE = @CC
	select @ASSUR = round(@ASSUR * 0.7 / 100 , 2)	/* si 0.7 % = cout assurance */
	
	/* insertion */
	insert into FEX (EXSEQ,EXCODE,EXDATE,EXTRANSP,EXCL,EXNOM,EXADR1,EXADR2,EXCP,EXVILLE,EXPAYS,
		EXREMB,EXOBS,EXTOTALHT,EXTOTCOLIS,EXTOTPOIDS,EXRECOM,EXASSUR,EXTOTALTR,EXFRANCO,EXBE,
		EXECHSPE,EXSAMEDI,EXDATECRE,EXUSERCRE,EXDATEMDF,EXUSERMDF,EXPY,EXENT,EXCOLISAGE)
	values (@seq,@codeex,@DATE,'CHRONOPO',@CL,@NOM1,@ADR1,@ADR2,@CP,@VILLE,@pays,
		0,'Creation automatique a partir du recapitulatif quotidien Chronopost',
		(case @franco when 0 then @TOTALHT else 0 end),@TOTCOLIS,@TOTPOIDS,1,@ASSUR,
		(case @franco when 0 then 0 else @TOTALHT end),@franco,@CC,
		@echspe,@samedi,getdate(),suser_id(),getdate(),suser_id(),@PY,'FR',0)
	if @@error != 0
		return

	select @codeex
end



go

