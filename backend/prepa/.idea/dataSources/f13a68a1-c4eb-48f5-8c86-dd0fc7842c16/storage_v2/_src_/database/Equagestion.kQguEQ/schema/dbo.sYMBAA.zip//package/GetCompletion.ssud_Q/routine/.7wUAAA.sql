


create procedure GetCompletion (
				@cclcode	char(10),
				@qteAdd	int = 0,
				@ValAdd	numeric(14,2) = 0
				)
as
begin

set arithabort numeric_truncation off


declare @completion numeric(12,2)

/* Recherche d''une valeur offerte */
if exists
 (select * from FCCL where CCLCODE=@cclcode and (isnull(CCLOFFERT,0)=1 or CCLTOTALHT=0))
	/* Calcul du taux de completion sur les quantites */
	select @completion=convert(numeric(12,2),convert(numeric(12,2),sum(CCLQTEEXP)+@qteAdd)/convert(numeric(12,2),sum(CCLQTE))*100)
	from FCCL,FAR where CCLCODE=@cclcode and ARCODE=CCLARTICLE and isnull(ARTYPE,0)=0
else
	/* calcul du taux de completion sur la valeur */
	select @completion=round((sum(convert(numeric(12,2),isnull(CCLQTEEXP,0))/convert(numeric(12,2),isnull(CCLQTE,0))*isnull(CCLTOTALHT,0))+@ValAdd)/sum(isnull(CCLTOTALHT,0)),2)*100
	from FCCL,FAR where CCLCODE=@cclcode and ARCODE=CCLARTICLE and isnull(ARTYPE,0)=0

if @completion is null select @completion=0
select @completion /* pourcentage */

end



go

