

create procedure DeprecNoMover (@depot		char(4),
							 	@codephoto	char(16),
							 	@datephoto	smalldatetime,
							 	@activite	char(6) = ""
							   )
with recompile						
as
begin

set arithabort numeric_truncation off

declare @article			char(15), 
		@qte				int, 
		@PrixRevient		numeric(14,4),
		@j1deb				int,
		@j1fin				int,
		@pc1				numeric(8,4),
		@j2deb				int,
		@j2fin				int,
		@pc2				numeric(8,4),
		@j3deb				int,
		@pc3				numeric(8,4),
		@derniermouv		smalldatetime,
		@art				char(15),
		@qtegroupe			int
		
		
select  @j1deb = P2NMJFACT1DEB, @j1fin = P2NMJFACT1FIN, @pc1 = P2NMJFACT1PC,
		@j2deb = P2NMJFACT2DEB, @j2fin = P2NMJFACT2FIN, @pc2 = P2NMJFACT2PC,
		@j3deb = P2NMJFACT3DEB, @pc3 = P2NMJFACT3PC
from KParam2


create table #Articles
(
article		char(15)	not null,
qte			int			not null
)

create table #Finale
(
article		char(15)		not null,
depot		char(4)			not null,
qte			int				not null,
derniermouv	smalldatetime		null,
jourstock	float				null,
pump		numeric(14,4)		null,
valavant	numeric(14,2)		null,
taux		float			not null,
valapres	numeric(14,2)		null,
depgroupe	numeric(14,2)		null
)


insert into #Articles (article,qte)
select PSAR,sum(PSQTE)
from FPS
where PSCODE = @codephoto
and PSDATE = @datephoto
and PSDEPOT = @depot
group by PSAR



declare articles cursor 
for select article,qte
from #Articles
for read only


open articles

fetch articles
into @article, @qte

while (@@sqlstatus = 0)
	begin
	
	  select @qtegroupe = 0

	  select @PrixRevient=isnull(PUMP,0) 
	  from FPUM 
	  where PUMAR = @article 
	  and PUMDATE <= convert (smalldatetime, @datephoto) 
	  having PUMAR = @article 
	  and PUMDATE <= convert (smalldatetime, @datephoto) 
	  and PUMDATE = max(PUMDATE)
	  
	  select @art = FALARTICLE, @derniermouv = FALDATE
	  from FFAL
	  where FALARTICLE = @article
	  and FALTOTALHT > 0
	  group by FALARTICLE
	  having FALDATE = max(FALDATE)
	  
	  if @derniermouv is null
	  select @derniermouv = "19000101"
	  
	  
	  if @activite != ""
	  begin
		  select  @qtegroupe = sum(PSQTE)
		  from FPS,FFO
		  where PSCODE = @codephoto
		  and PSDATE = @datephoto
		  and PSAR = @article
		  and PSFO = FOCODE
		  and FOSA = @activite
		  and PSDEPOT = @depot
	  end
	  else
	  begin
	  	  select @qtegroupe = 0
	  end

	  
	  if ((datediff(dd,@derniermouv,@datephoto) > @j1deb) and (datediff(dd,@derniermouv,@datephoto) <= @j1fin))
	  begin
	  	insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  	values (@article,@depot,@qte,@derniermouv,null,@PrixRevient,@PrixRevient*@qte,@pc1,@PrixRevient*@qte*(@pc1/100),@PrixRevient*@qtegroupe*(@pc1/100))
	  end
	  else
	  if ((datediff(dd,@derniermouv,@datephoto) > @j2deb) and (datediff(dd,@derniermouv,@datephoto) <= @j2fin))
	  begin
	  	insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  	values (@article,@depot,@qte,@derniermouv,null,@PrixRevient,@PrixRevient*@qte,@pc2,@PrixRevient*@qte*(@pc2/100),@PrixRevient*@qtegroupe*(@pc2/100))
	  end
	  if (datediff(dd,@derniermouv,@datephoto) > @j3deb)
	  begin
	  	insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  	values (@article,@depot,@qte,@derniermouv,null,@PrixRevient,@PrixRevient*@qte,@pc3,@PrixRevient*@qte*(@pc3/100),@PrixRevient*@qtegroupe*(@pc3/100))
	  end
	  
	
	fetch articles
	into @article, @qte
	
end

close articles
deallocate cursor articles

delete from TEMP_MOVER
where MOVERSPID = @@spid

insert into TEMP_MOVER (MOVERSPID,MOVERARTICLE,MOVERDEPOT,MOVERCODEPHOTO,MOVERDATEPHOTO,MOVERACTIVITE)
select @@spid, article, @depot, @codephoto, @datephoto, @activite
from #Finale

select article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe,ARLIB,ARFAM
from #Finale,FAR
where ARCODE = article
order by article

drop table #Articles
drop table #Finale


end
go

