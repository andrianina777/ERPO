



create procedure Milliers_int (@nombre	varchar(50) output)
with recompile
as
begin

set arithabort numeric_truncation off


declare @long	int,
		@separe	numeric(14,2)


select @separe = convert(numeric(14,2),(char_length (@nombre)))/3


if @separe > 1
begin
  select @long = char_length (@nombre)
  select @nombre = substring(@nombre,1,@long-3) +' '+ substring(@nombre,@long-2,@long)
end

if @separe > 2
begin
  select @long = char_length (@nombre)
  select @nombre = substring(@nombre,1,@long-7) +' '+ substring(@nombre,@long-6,@long)
end

if @separe > 3
begin
  select @long = char_length (@nombre)
  select @nombre = substring(@nombre,1,@long-11) +' '+ substring(@nombre,@long-10,@long)
end

if @separe > 4
begin
select @long = char_length (@nombre)
select @nombre = substring(@nombre,1,@long-15) +' '+ substring(@nombre,@long-14,@long)
end

if @separe > 5
begin
select @long = char_length (@nombre)
select @nombre = substring(@nombre,1,@long-19) +' '+ substring(@nombre,@long-18,@long)
end

select @nombre = ltrim(@nombre)

end



go

