


/* Procedure utilisee par le Tableau de Bord Client pour les delais de reglement moyen du client */


create procedure Delai_moyen (@ent		char(5),
							  @rep 		char(8),			/* VRP general */
							  @an		smallint	= null,
							  @client	char(12)	= null
						   	 )
with recompile
as
begin

set arithabort numeric_truncation off

if @an is null
select @an = datepart(yy,getdate())

declare @date1	smalldatetime
declare @date2	smalldatetime
select @date1 = convert (datetime,"01/01/" + convert(varchar(4),@an))
select @date2 = convert (datetime,"12/31/" + convert(varchar(4),@an))


create table #Delais
(
seq			numeric(14,0)	identity,
vrp			char(8)			not null,
client		char(12)		not null,
nbrfact		int				not null,
nbrech		int				not null,
totech		numeric(14,2)	not null,
moyennech	numeric(14,2)	not null,
delaimoyen	numeric(14,2)	not null
)


create table #Temp
(
facode		char(10)		not null,
reglement	numeric(14,2)	not null,
delai		numeric(14,2)	not null
)


declare delais cursor 
for select CLCODE
from FCL
where CLREP=@rep
and (@client is null or CLCODE=@client)
order by CLCODE
for read only


declare @leclient		char(12),
		@nbrfact		int,
		@nbrech			int,
		@totech			numeric(14,2),
		@moyennech		numeric(14,2),
		@delaimoyen		numeric(14,2)

open delais

fetch delais
into @leclient

while (@@sqlstatus = 0)
	begin
	
	select 	@nbrfact = 0,
			@nbrech = 0,
			@totech = 0,
			@moyennech = 0,
			@delaimoyen = 0
	
	delete from #Temp
		
	insert into #Temp (facode,reglement,delai)
	select FACODE,FAREGL1,datediff(dd,FADATE,FATRDATE1)
	from FFA,FCL,FMR
	where FADATE between @date1 and @date2
	and FACL=@leclient
	and CLCODE=FACL
	and MRCODE=FAMODEREG1
	and FAREGL1 != 0
	and (@ent is null or(FAENT=@ent and CLENT=@ent))
	 union
	select FACODE,FAREGL2, datediff(dd,FADATE,FATRDATE2)
	from FFA,FCL,FMR
	where FADATE between @date1 and @date2
	and FACL=@leclient
	and CLCODE=FACL
	and MRCODE=FAMODEREG2
	and FAREGL2 != 0
	and isnull(FATR2,"")<>""
	and (@ent is null or(FAENT=@ent and CLENT=@ent))
	 union
	select FACODE,FAREGL3,datediff(dd,FADATE,FATRDATE3)
	from FFA,FCL,FMR
	where FADATE between @date1 and @date2
	and FACL=@leclient
	and CLCODE=FACL
	and MRCODE=FAMODEREG3
	and FAREGL3 != 0
	and isnull(FATR3,"")<>""
	and (@ent is null or(FAENT=@ent and CLENT=@ent))
	 union
	select FACODE,FAREGL4,datediff(dd,FADATE,FATRDATE4)
	from FFA,FCL,FMR
	where FADATE between @date1 and @date2
	and FACL=@leclient
	and CLCODE=FACL
	and MRCODE=FAMODEREG4
	and FAREGL4 != 0
	and isnull(FATR4,"")<>""
	and (@ent is null or(FAENT=@ent and CLENT=@ent))

	select @nbrech=count(*) from #Temp

	if (@nbrech > 0)
	begin
	  select @nbrfact = count(distinct facode) from #Temp
	  select @totech = sum(reglement) from #Temp
	  select @moyennech = avg(reglement), @delaimoyen=avg(delai) from #Temp
  
	  insert into #Delais (vrp,client,nbrfact,nbrech,totech,moyennech,delaimoyen)
	  values (@rep,@leclient,isnull(@nbrfact,0),isnull(@nbrech,0),isnull(@totech,0),
	  			isnull(@moyennech,0),isnull(@delaimoyen,0))
	end
	
	fetch delais
into @leclient
	
end

close delais
deallocate cursor delais


select VRP=vrp,Client=client,Nbre_Factures=nbrfact,Nbre_Echeances=nbrech,
	   Total_Echeances=totech,Moyenne_Echeances=moyennech,Delai_moyen=delaimoyen
from #Delais
order by seq

drop table #Temp
drop table #Delais

end



go

