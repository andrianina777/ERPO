


/* Procedure utilisee par la requÃÂªte DAM ""A Recevoir"" 
		Donne le reste a recevoir Fournisseurs */


create procedure ARecevoir (@Fournisseur	char(12) = null,
							@ent			char(5)	 = null)
with recompile
as
begin

if (@Fournisseur is null)
  begin
	select CFLFO,CFLARTICLE,ARLIB,CFLREF,sum(CFLRESTE),CFLCODE
	from FRCF,FCFL,FAR
	where RCFSEQ=CFLSEQ
	and RCFARTICLE=ARCODE
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,CFLARTICLE,ARLIB,CFLREF,CFLCODE
	order by CFLFO,CFLARTICLE
  end
else
  begin
	select CFLFO,CFLARTICLE,ARLIB,CFLREF,sum(CFLRESTE),CFLCODE
	from FRCF,FCFL,FAR
	where RCFSEQ=CFLSEQ
	and RCFARTICLE=ARCODE
	and RCFFO=@Fournisseur
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,CFLARTICLE,ARLIB,CFLREF,CFLCODE
	order by CFLFO,CFLARTICLE
  end
end



go

