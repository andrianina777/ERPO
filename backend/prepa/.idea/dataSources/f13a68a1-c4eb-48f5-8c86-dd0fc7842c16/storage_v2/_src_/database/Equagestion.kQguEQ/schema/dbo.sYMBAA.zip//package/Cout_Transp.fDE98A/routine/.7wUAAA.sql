


/* Procedure utilisee par le module ""Cout Transport"" */


create procedure Cout_Transp(	@ent		char(5) = null,
								@an			smallint,
								@marque 	char(12) = null,
								@famille	char(8) = null,
								@article	char(15) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off

delete from FCOUT where CTSPID=@@spid

declare @mois		tinyint,
		@encours	tinyint

create table #Cout
(
article		char(15)		not null,
mois		int				not null,
poids		numeric(10,3)	not null,
belcode		char(10)		not null,
qte			int				not null,
pvtotal		numeric(14,2)	not null,
prixkg		numeric(14,2)		null,
couttotal	numeric(14,2)		null
)


select @mois=1

if @an=datepart(yy,getdate())
	select @encours=datepart(mm,getdate())
else
	select @encours=12


if ((@marque is null) and (@famille is null) and (@article is null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		
		select @mois = @mois + 1
	end
else if ((@marque is null) and (@famille is null) and (@article is not null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARCODE=@article
		
		select @mois = @mois + 1
	end
else if ((@marque is null) and (@famille is not null) and (@article is null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARFAM=@famille
		
		select @mois = @mois + 1
	end
else if ((@marque is null) and (@famille is not null) and (@article is not null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARFAM=@famille
		and ARCODE=@article
		
		select @mois = @mois + 1
	end		
else if ((@marque is not null) and (@famille is null) and (@article is null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARFO=@marque
		
		select @mois = @mois + 1
	end
else if ((@marque is not null) and (@famille is null) and (@article is not null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARFO=@marque
		and ARCODE=@article
		
		select @mois = @mois + 1
	end
else if ((@marque is not null) and (@famille is not null) and (@article is null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARFO=@marque
		and ARFAM=@famille
		
		select @mois = @mois + 1
	end
else if ((@marque is not null) and (@famille is not null) and (@article is not null))
	while @mois<=@encours
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,@mois,ARPOIDS,'',0,0,0,0
		from FAR
		where ARTYPE in (0,1)
		and ARFO=@marque
		and ARFAM=@famille
		and ARCODE=@article
		
		select @mois = @mois + 1
	end


if ((@marque is null) and (@famille is null) and (@article is null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end
else if ((@marque is null) and (@famille is null) and (@article is not null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARCODE=@article		
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end
else if ((@marque is null) and (@famille is not null) and (@article is null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARFAM=@famille
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end	
else if ((@marque is null) and (@famille is not null) and (@article is not null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARFAM=@famille
		and ARCODE=@article
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end		
else if ((@marque is not null) and (@famille is null) and (@article is null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARFO=@marque
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end
else if ((@marque is not null) and (@famille is null) and (@article is not null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARFO=@marque
		and ARCODE=@article
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end
else if ((@marque is not null) and (@famille is not null) and (@article is null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARFO=@marque
		and ARFAM=@famille
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end
else if ((@marque is not null) and (@famille is not null) and (@article is not null))
	begin
		insert into #Cout (article,mois,poids,belcode,qte,pvtotal,prixkg,couttotal)
		select ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE,sum(BELQTE),sum(BELTOTALHT),0,0
		from FAR,FBEL
		where BELARTICLE=ARCODE
		and datepart(yy,BELDATE)= @an
		and BELQTE > 0
		and ARTYPE in (0,1)
		and ARFO=@marque
		and ARFAM=@famille
		and ARCODE=@article
		and (@ent is null or BELENT=@ent)
		group by ARCODE,datepart(mm,BELDATE),ARPOIDS,BELCODE
	end


declare cout cursor 
for select article,poids,belcode,qte
from #Cout
where belcode != ''
for update of prixkg,couttotal

declare @art		char(15),
		@poids		numeric(10,3),
		@belcode	char(10),
		@qte		int,
		@prixkg		numeric(14,2),
		@couttotal	numeric(14,2)

open cout

fetch cout
into @art,@poids,@belcode,@qte

while (@@sqlstatus = 0)
	begin
	
	select @prixkg=0
	
	select @prixkg=round(sum(EXTOTALTR)/sum(EXTOTPOIDS),2)
	from FEX
	where EXBE=@belcode
	and (@ent is null or EXENT=@ent)
	having sum(EXTOTPOIDS) != 0
	
	update #Cout
	set prixkg=@prixkg, couttotal = @prixkg * @poids * @qte
	where current of cout

	fetch cout
	into @art,@poids,@belcode,@qte
	
	end

close cout
deallocate cursor cout


insert into FCOUT (CTAR,CTDES,CTMOIS,CTQTE,CTPV,CTCOUT,CTSPID)
select article,ARLIB,mois,sum(qte),sum(pvtotal),sum(couttotal),@@spid
from #Cout,FAR
where ARCODE=article
group by article,ARLIB,mois
order by article


drop table #Cout


end



go

