



create procedure Dispo_Composants (@date	smalldatetime)
as
begin

create table #Compose
(
Compose		char(15)		not null,
A_livrer	int				not null,
Seq			numeric(14,0)	identity
)

create table #Final
(
Compose			char(15)		not null,
A_livrer		int				not null,
Composant		char(15)		not null,
Qte_necessaire	int					null,
Depot			char(4)			not null,
Qte_Stock		int					null
)

insert into #Compose (Compose,A_livrer)
select RCCARTICLE,sum(RCCQTE)
from FRCC,FAR
where ARCODE=RCCARTICLE
and ARCOMP=2
and RCCDATE >= @date
group by RCCARTICLE


declare articles cursor
for
select Compose,A_livrer
from #Compose

declare @compose	char(15),
		@a_livrer	int

open articles

fetch articles into @compose,@a_livrer

while (@@sqlstatus = 0)
	begin
	

	insert into #Final (Compose,A_livrer,Composant,Qte_necessaire,Depot,Qte_Stock)
	select @compose,@a_livrer,ARCCOMP,@a_livrer*ARCQTE,
			STDEPOT,sum(STQTE)
	from FARC, FSTOCK, FDP
	where ARCCODE=@compose
	and STAR=ARCCOMP
	and STDEPOT=DPCODE
	and DPLOC=1
	group by ARCCOMP,ARCQTE,STDEPOT

	
	fetch articles into @compose,@a_livrer
	
end

close articles
deallocate cursor articles

select Compose,a.ARLIB,A_livrer,Composant,b.ARLIB,Qte_necessaire,Depot,Qte_Stock
from #Final,FAR a, FAR b
where a.ARCODE=Compose
and b.ARCODE=Composant
order by Compose,Composant

drop table #Final

end



go

