



create procedure Saisonnal	(@date1		smalldatetime,
							 @date2		smalldatetime,
							 @marque	char(12)	= null,
							 @famille	char(8)		= null,
							 @article	char(8)		= null,
							 @ent		char(5)		= null
							)
with recompile
as
begin

create table #Cdes
(
article		char(8)		not null,
commandes	int			not null,
livraisons	int			not null
)

insert into #Cdes (article,commandes,livraisons)
select CCLARTICLE,sum(CCLQTE),sum(CCLQTEEXP)
from FCCL,FCC,FAR
where CCCODE=CCLCODE
and CCDATECOM between @date1 and @date2
and ARCODE=CCLARTICLE
and (@marque is null or ARFO = @marque)
and (@famille is null or ARFAM = @famille)
and (@article is null or ARCODE = @article)
and (@ent is null or (CCENT = @ent and CCLENT = @ent))
group by CCLARTICLE


create unique index art on #Cdes (article)


select STAR,STQTE=sum(STQTE),STVALEUR=sum(round((STPAHT+STFRAIS)/CVLOT,2)*STQTE)
into #Stock
from FSTOCK,FCV,FAR,#Cdes
where STAR=article
and ARCODE=STAR
and CVUNIF=ARUNITACHAT
and STQTE>0
group by STAR

create unique index star on #Stock (STAR)


select Produit=ARCODE,PAHT=ARFPADEV*DECOURS
into #Achat
from FARF,FDE,FAR,#Cdes
where DECODE=ARFDEV
and ARCODE=ARFCODE
and ARFO=ARFFO
and ARCODE=article

create unique index prod on #Achat (Produit)


select RCFARTICLE,RCFQTE=sum(RCFQTE),RCFVALEUR=sum(round(CFLTOTALHT/CFLQTE,2)*RCFQTE)
into #CFourn
from FRCF,FCFL,#Cdes
where RCFARTICLE=article
and CFLSEQ=RCFSEQ
and CFLQTE>0
and (@ent is null or (CFLENT = @ent and RCFENT = @ent))
group by RCFARTICLE


create unique index arti on #CFourn (RCFARTICLE)



select Marque=ARFO, Famille=ARFAM, Article=article, Designation=ARLIB, Qte_Cdes=commandes,
		Prix_vente_Unit_Standard=round(isnull(ARPVHT,0),2),
		Unite_Vente=convert(varchar,a.CVLOT),
		Prix_Unit_Achat=round(isnull(PAHT,0),2),
		Unite_Achat=convert(varchar,b.CVLOT),
		Qte_livree=livraisons,
		Qte_Stock=isnull(STQTE,0), Valeur_Stock=round(isnull(STVALEUR,0),2),
		Qte_Cdes_FO=isnull(RCFQTE,0),Valeur_Cdes_FO=round(isnull(RCFVALEUR,0),2)
from #Cdes,#Stock,#Achat,#CFourn,FAR,FCV a,FCV b
where ARCODE=article
and a.CVUNIF=ARUNITFACT
and b.CVUNIF=ARUNITACHAT
and STAR=*article
and Produit=*article
and RCFARTICLE=*article
order by ARFO,ARFAM,article


drop table #Cdes
drop table #Stock
drop table #Achat
drop table #CFourn


end



go

