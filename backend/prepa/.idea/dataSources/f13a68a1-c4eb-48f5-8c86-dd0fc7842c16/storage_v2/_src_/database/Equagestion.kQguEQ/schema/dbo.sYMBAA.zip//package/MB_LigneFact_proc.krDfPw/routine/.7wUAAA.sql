





create procedure MB_LigneFact_proc
	@facture	char(10),
	@ligne		int,
	@marge		numeric(5,2)	output
with recompile
as
begin

declare @modevalo 			tinyint,
		@date 				datetime,
		@article			char(15),
		@lettre				char(4),
		@qte				int,
		@totalht			numeric(14,2),
		@valeur				numeric(14,2),
		@PrixRevient		numeric(14,4),
		@PrixRevientLigne	numeric(14,2),
		@seq				int


select @modevalo=PMODEVALO from KParam


create table #Final
(
FALARTICLE	char(15)		not null,
FALLETTRE	char(4)				null,
FALQTE		int					null,
FALDATE		smalldatetime		null,
FALTOTALHT	numeric(14,2)		null,
VALEURFINAL	numeric(14,2)		null,
Seq			numeric(14,0)	identity
)


declare facture cursor 
for select FALARTICLE,FALLETTRE,FALQTE,FALDATE,FALTOTALHT,VALEURFINAL,Seq
from #Final
order by Seq
for read only


if @modevalo=0
begin
	insert into #Final (FALARTICLE,FALLETTRE,FALQTE,FALTOTALHT,VALEURFINAL)
	select FALARTICLE,FALLETTRE,FALQTE,FALTOTALHT,round((STPAHT+STFRAIS)/CVLOT,2)*FALQTE
	from FFAL,FAR,FCV,FSTOCK 
	where ARCODE=FALARTICLE 
	and CVUNIF=ARUNITACHAT 
	and STAR=FALARTICLE 
	and STLETTRE=FALLETTRE
	and FALCODE=@facture
	and FALNUM=@ligne
	and FALLETTRE != ""
	union
	select FALARTICLE,FALLETTRE,FALQTE,FALTOTALHT,0
	from FFAL 
	where FALCODE=@facture
	and FALNUM=@ligne
	and FALLETTRE = ""
end	

else if @modevalo=1
begin
	insert into #Final (FALARTICLE,FALQTE,FALTOTALHT,VALEURFINAL)
	select FALARTICLE,FALQTE,FALTOTALHT,isnull(ARPRM,0)*FALQTE
	from FFAL,FAR,FCV,FSTOCK 
	where ARCODE=FALARTICLE 
	and CVUNIF=ARUNITACHAT 
	and STAR=FALARTICLE 
	and STLETTRE=FALLETTRE
	and FALCODE=@facture
	and FALNUM=@ligne
	and FALLETTRE != ""
	union
	select FALARTICLE,FALQTE,FALTOTALHT,0
	from FFAL 
	where FALCODE=@facture
	and FALNUM=@ligne
	and FALLETTRE = ""
end

else
begin
	insert into #Final (FALARTICLE,FALLETTRE,FALQTE,FALDATE,FALTOTALHT,VALEURFINAL)
	select FALARTICLE,FALLETTRE,FALQTE,FALDATE,FALTOTALHT,0
	from FFAL
	where FALCODE=@facture
	and FALNUM=@ligne
						
	 create unique index seq on #Final (Seq)
	 
	 open facture
	 
	 fetch facture
	 into @article,@lettre,@qte,@date,@totalht,@valeur,@seq
			 
			 
	 while (@@sqlstatus = 0)
	   begin
		 select 	@PrixRevient = 0
		 
		 if @modevalo = 2			/*--------------------- PUMP */
		 begin
			 if @lettre != ""
			 begin
			   select @PrixRevient=isnull(PUMP,0)
			   from FPUM
			   where PUMAR = @article
			   and PUMDATE <= convert (smalldatetime, @date)
			   having PUMAR = @article
			   and PUMDATE <= convert (smalldatetime, @date)
			   and PUMDATE = max(PUMDATE)
			   
			   select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			 end
			 else if @lettre = ""
			 begin
			   select @PrixRevientLigne = 0
			 end
		 end
		 
		 else if @modevalo = 3			/*--------------------- PRM Mensuel */
		 
		 begin
			 if @lettre != ""
			 begin
			   set rowcount 1
			   
			   select @PrixRevient=isnull(PRM,0)
			   from FPRM
			   where PRMAR = @article
			   and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			   having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			   and PRMAR = @article
			   order by PRMAN desc,PRMMOIS desc
			   
			   set rowcount 0
			   
			   select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			 end
			 else if @lettre = ""
			 begin
			   select @PrixRevientLigne = 0
			 end
		   
		 end
		 
		 else  if @modevalo = 4 			/*--------------------- DPA unitaire */
		 
		 begin
			 if @lettre != ""
			 begin
			   set rowcount 1			
			 
			   select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			   from FBLL,FCV
			   where BLLAR=@article
			   and CVUNIF=BLLUA
			   having BLLAR=@article
			   and CVUNIF=BLLUA
			   and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			 
			   if isnull(@PrixRevient,0)=0
			   begin
				 select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				 from FSIL,FAR,FCV
				 where SILARTICLE=@article
				 and ARCODE = SILARTICLE
				 and ARUNITACHAT = CVUNIF
				 having SILARTICLE=@article
				 and ARCODE = SILARTICLE
				 and ARUNITACHAT = CVUNIF
				 and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			   end
			   
			   set rowcount 0
			   
			   if @PrixRevient is null
				 select @PrixRevient = 0
	   
			   select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			 end
			 else if @lettre = ""
			 begin
			   select @PrixRevientLigne = 0
			 end			
		 end


		 update #Final set VALEURFINAL = @PrixRevientLigne
		 where Seq = @seq
		 
		 fetch facture
		 into @article,@lettre,@qte,@date,@totalht,@valeur,@seq
		 
	 end
                	
	 close facture
	 deallocate cursor facture
                           
            	
	end

/*--- renvoi les lignes --*/

   select @marge = (case isnull(sum(FALTOTALHT),0)
   						when 0 then (case isnull(sum(VALEURFINAL),0) when 0 then 0 else 100 end)
   						else convert(numeric(5,2),(sum(FALTOTALHT) - isnull(sum(VALEURFINAL),0))*100/sum(FALTOTALHT)) end)
   from #Final
   

drop table #Final	

end	




go

