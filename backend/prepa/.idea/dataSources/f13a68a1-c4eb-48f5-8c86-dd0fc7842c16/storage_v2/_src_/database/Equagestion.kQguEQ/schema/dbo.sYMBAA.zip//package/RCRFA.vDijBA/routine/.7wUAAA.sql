


/* Procedure utilisee pour le calcul des remises et du droit a la RFA d''un client
	sur une ligne de facture a partir de la procedure RFA_CL */
	
/* renvoie @carfa = CA donnant droit a la RFA standard */
/* renvoie @rfact = RFA calculee a partir du fichier des remises clients (en principe contrat) */


create procedure RCRFA (@ent		char(5) = null,
						@client		char(12),
						@annee		smallint,
						@fo			char(12),
						@fam		char(8),
						@rcpr1		tinyint output,
						@rcr1		numeric(8,4) output,
						@rcpr2		tinyint output,
						@rcr2		numeric(8,4) output,
						@rcpr3		tinyint output,
						@rcr3		numeric(8,4) output,
						@rcprfa		tinyint output,
						@rcrfa		numeric(8,4) output,
						@tarif		char(8),
						@depart		char(8),
						@categ		char(8),
						@article	char(15)
						)
with recompile
as
begin

set arithabort numeric_truncation off

declare @count	int

select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
where RCCL=@client and RCARTICLE=@article and RCAN=@annee and RCTARIF=@tarif and (@ent is null or RCENT=@ent)
select @count=@@rowcount
if @count <= 0
 begin
 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
 where RCCL=@client and RCARTICLE=@article and RCAN=@annee and RCTARIF='' and (@ent is null or RCENT=@ent)
 select @count=@@rowcount
 if @count <= 0
  begin
  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
  where RCCL=@client and RCARTICLE=@article and RCAN=0 and RCTARIF=@tarif and (@ent is null or RCENT=@ent)
  select @count=@@rowcount
  if @count <= 0
   begin
   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
   where RCCL=@client and RCARTICLE=@article and RCAN=0 and RCTARIF='' and (@ent is null or RCENT=@ent)
   select @count=@@rowcount
	 if @count <= 0
	  begin
	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  select @count=@@rowcount
	  if @count <= 0
	   begin
	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	   where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	   select @count=@@rowcount
	   if @count <= 0
	    begin
		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	    where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
		select @count=@@rowcount
		if @count <= 0
		 begin
		 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	     where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	     and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
		 select @count=@@rowcount
		 if @count <= 0
		  begin
		  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  	  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	      and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	      select @count=@@rowcount
	      if @count <= 0
	       begin
	       select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  	   where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	       and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	       select @count=@@rowcount
	       if @count <= 0
	        begin
	        select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	  		and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	 		select @count=@@rowcount
	  		if @count <= 0
	   		 begin	
	         select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		 where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	  		 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		 select @count=@@rowcount
/**/	  	 if @count <= 0
	 		  begin
	  		  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  select @count=@@rowcount
	          if @count <= 0
	 		   begin
	  		   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		   where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		   select @count=@@rowcount
	           if @count <= 0
	 		    begin
	  		    select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		    where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		    select @count=@@rowcount
	        	if @count <= 0
	 		     begin
	  		     select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		     where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		     and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		     select @count=@@rowcount
	        	 if @count <= 0
	 		  	  begin
	  		      select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		      where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		      and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		      select @count=@@rowcount
	        	  if @count <= 0
	 		  	   begin
	  		       select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		       where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		       and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		       select @count=@@rowcount
	        	   if @count <= 0
	 		  		begin
	  		  		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		  		and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		select @count=@@rowcount
	        		if @count <= 0
	 		  		 begin
	  		  		 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		 where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		  		 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		 select @count=@@rowcount
					 if @count <= 0
	 		  		  begin
/**/	  		  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  		  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  select @count=@@rowcount
	  		  		  if @count <= 0
	  		  		   begin
	  		  		   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		   where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  		   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		   select @count=@@rowcount
	  		  		   if @count <= 0
	  		  		  	begin
	  		  		  	select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		    where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  		    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		    select @count=@@rowcount
	  		  		    if @count <= 0
	  		  		  	 begin
	  		  		  	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  	 where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  		  	 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  	 select @count=@@rowcount
	  		  		  	 if @count <= 0
	  		  		  	  begin
	  		  		  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  	  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  		  	  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  	  select @count=@@rowcount
	  		  		  	  if @count <= 0
	  		  		  	   begin
	  		  		  	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  	   where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  		  	   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  	   select @count=@@rowcount
	  		  		  	   if @count <= 0
	  		  		  		begin
	  		  		  		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  		  		and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  		select @count=@@rowcount
	  		  		  		if @count <= 0
	  		  		  		 begin
	  		  		  		 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		 where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  		  		 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  		 select @count=@@rowcount
	  		  		  		 if @count <= 0
	  		  		  		  begin	
	/**/  		  		  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  		  		  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  		  select @count=@@rowcount
	  		  		  		  if @count <= 0
	  		  		  		   begin	
	  		  		  		   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		   where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  		  		   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  		   select @count=@@rowcount
	  		  		  		   if @count <= 0
	  		  		  		 	begin	
	  		  		  		    select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		    where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  		  		    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  		    select @count=@@rowcount
	  		  		  		    if @count <= 0
	  		  		  		 	 begin	
	  		  		  		  	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		  	 where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  		  		  	 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  		  	 select @count=@@rowcount
	  		  		  		  	 if @count <= 0
	  		  		  		  	  begin	
	  		  		  		  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		  	  where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  		  		  	  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  		  	  select @count=@@rowcount
	  		  		  		  	  if @count <= 0
	  		  		  		  	   begin	
	  		  		  		  	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		       where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  		  		       and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  		       select @count=@@rowcount
	  		  		  		       if @count <= 0
	  		  		  		  	    begin	
	  		  		  		  		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		  		where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  		  		  		and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  		  		  		select @count=@@rowcount
	  		  		  		  		if @count <= 0
	  		  		  		  	     begin	
	  		  		  		 		 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  		  		  		 where RCCL=@client and RCARTICLE='' and RCAN=@annee and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  		  		  		 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  		  		 		 select @count=@@rowcount
	  		  		  		  		 if @count <= 0
	  		  		  		  	      begin
/**/	  		  					  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	  		  						  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						  select @count=@@rowcount
	          						  if @count <= 0
	  		  		  		  	 	   begin
  		  		  					   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	  		  						   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						   select @count=@@rowcount
	          						   if @count <= 0
	          						    begin
		  		  					    select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						    where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	  		  						    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						    select @count=@@rowcount
	          						    if @count <= 0
	          						     begin
		  		  					  	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  	 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam
	  		  						  	 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						  	 select @count=@@rowcount
	          						  	 if @count <= 0
	          						      begin
		  		  					  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  	  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	  		  						  	  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						  	  select @count=@@rowcount
	          						  	  if @count <= 0
	          						       begin
		  		  					  	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  	   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	  		  						  	   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						  	   select @count=@@rowcount
	          						  	   if @count <= 0
	          						   		begin
		  		  					  		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	  		  						  		and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						  		select @count=@@rowcount
	          						  		if @count <= 0
	  		  		  		  	 			 begin
		  		  					  		 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=''
	  		  						  		 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						  		 select @count=@@rowcount
	          						  		 if @count <= 0
	  		  		  		  	 			  begin
/**/		  		  					 	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		  						 		  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  select @count=@@rowcount
	          						  		  if @count <= 0
	  		  		  		  	 			   begin
		  		  					 		   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		  						 		   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		   select @count=@@rowcount
	          						  		   if @count <= 0
	  		  		  		  	 				begin
		  		  					 		    select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		    where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		  						 		    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		    select @count=@@rowcount
	          						  		    if @count <= 0
	          						  		     begin
		  		  					 		  	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		  	 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam
	  		  						 		  	 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  	 select @count=@@rowcount
	          						  		  	 if @count <= 0
	          						  		  	  begin
		  		  					 		  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		  	  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		  						 		  	  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  	  select @count=@@rowcount
	          						  		  	  if @count <= 0
	          						  		  	   begin
		  		  					 		  	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		  	   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		  						 		  	   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  	   select @count=@@rowcount
	          						  		  	   if @count <= 0
	  		  		  		  	 					begin
		  		  					 		  		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		 		where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		  						 		  		and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		select @count=@@rowcount
	          						  		  		if @count <= 0
	          						  		  		 begin
		  		  					 		  		 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  		  		 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF=@tarif and RCCATEG='' and RCFAM=''
	  		  						 		  		 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		 select @count=@@rowcount
	          						  		  		 if @count <= 0
	          						  		  		  begin
/**/		  		  					 		  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  						  				  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		  select @count=@@rowcount
	          						  		  		  if @count <= 0
	          						  		  		   begin
		  		  					 		  	  	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  						  				   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		   select @count=@@rowcount
	          						  		  		   if @count <= 0
	          						  		  		    begin
		  		  					 		  	  	    select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				    where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  						  				    and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		    select @count=@@rowcount
	          						  		  		    if @count <= 0
	          						  		  		     begin
		  		  					 		  	  	  	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  	 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam
	  		  						  				  	 and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  	 select @count=@@rowcount
	          						  		  		  	 if @count <= 0
	          						  		  		      begin
		  		  					 		  	  	  	  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  	  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  						  				  	  and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		  	  select @count=@@rowcount
	          						  		  		  	  if @count <= 0
	          						  		  		  	   begin
		  		  					 		  	  	  	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  	   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  						  				  	   and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  	   select @count=@@rowcount
	          						  		  		  	   if @count <= 0
	          						  		  		  		begin
		  		  					 		  	  	  		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG=@categ and RCFAM=''
	  		  						  				  		and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  		select @count=@@rowcount
	          						  		  		  		if @count <= 0
	          						  		  		  		 begin
 /**/   		  		  					 		  	  	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  						  				  		 and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		  		 select @count=@@rowcount
	          						  		  		  		 if @count <= 0
	          						  		  		  		  begin
    		  		  					 		  	  		  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  						  				  		  and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  		  select @count=@@rowcount
	          						  		  		  		  if @count <= 0
	          						  		  		  		   begin
    		  		  					 		  	  		   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  						  				  		   and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		  		   select @count=@@rowcount
	          						  		  		  		   if @count <= 0
	          						  		  		  			begin
    		  		  					 		  	  		 	select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		 	where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=@fam
	  		  						  				  		 	and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  		 	select @count=@@rowcount
	          						  		  		  			if @count <= 0
	          						  		  		  			 begin
    		  		  					 		  	  		 	 select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		 	 where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  						  				  		 	 and RCFO=@fo and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		  		 	 select @count=@@rowcount
	          						  		  		  		 	 if @count <= 0
	          						  		  		  			  begin
    		  		  					 		  	  			  select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		 	  where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  						  				  		 	  and RCFO=@fo and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  		 	  select @count=@@rowcount
	          						  		  		  		 	  if @count <= 0
	          						  		  		  		 	   begin
    		  		  					 		  	  		 	   select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		 	   where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  						  				  		 	   and RCFO='' and RCDEPART=@depart and (@ent is null or RCENT=@ent)
	  		  						 		  		  		 	   select @count=@@rowcount
	          						  		  		  		 	   if @count <= 0
	          						  		  		  				begin
    		  		  					 		  	  		 		select @rcpr1=isnull(RCPR1,0),@rcr1=isnull(RCR1,0),@rcpr2=isnull(RCPR2,0),@rcr2=isnull(RCR2,0),
		@rcpr3=isnull(RCPR3,0),@rcr3=isnull(RCR3,0),@rcprfa=isnull(RCPRFA,0),@rcrfa=isnull(RCRFA,0) from FRC
	  		  						  				  		 		where RCCL=@client and RCARTICLE='' and RCAN=0 and RCTARIF='' and RCCATEG='' and RCFAM=''
	  		  						  				  		 		and RCFO='' and RCDEPART='' and (@ent is null or RCENT=@ent)
	  		  						 		  		  		 		select @count=@@rowcount
																 end
																end        	
															   end
															  end
															 end
															end	 	  		  		  		  	 
														   end
														  end
														 end
														end        	
													   end
													  end
													 end
													end	 	  		  		  		  	 
												   end
											      end
												 end
												end        	
											   end
											  end
											 end
											end	 	  		  		  		  	 
										   end	  		  		  		  	 
										  end
										 end
										end
									   end        	
									  end
									 end
									end
								   end	 	  		  		  		  	 
								  end
								 end
								end
							   end        	
							  end
							 end
							end
						   end	 	  		  		  		  	 
						  end
						 end
						end
					   end        	
					  end
					 end
					end
				   end	  		  		  		 	
				  end
				 end
				end
			   end        	
			  end
			 end
			end
		   end
		  end
		 end
		end
       end
      end        	
     end
    end
   end
  end
 end
end
 
if @count <= 0
begin
select @rcpr1=0,@rcr1=0,@rcpr2=0,@rcr2=0,
		@rcpr3=0,@rcr3=0,@rcprfa=0,@rcrfa=0
return (1)
end
else return (0)

end



go

