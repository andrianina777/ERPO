


/* Procedure utilisee pour la mise a jour de la RFA dans les lignes de factures
	d''un client pour l''annee indiquee - TBCL et fiche client */


create procedure MajRFA_FACL (	@ent	char(5) = null,
								@client	char(12),
							  	@an		smallint = null)
with recompile
as
begin

set arithabort numeric_truncation off


if @an is null
select @an=datepart(yy,getdate())
		
declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime


select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))


declare @lignes		int,
		@labase		varchar(30)
select  @labase = db_name(),
		@lignes = 0


declare @article	char(15),
		@totalht	numeric(14,2),
		@carfa		numeric(14,2),
		@rfact		numeric(14,2),
		@seq		int

declare factures cursor 
for select FALSEQ,FALARTICLE,FALTOTALHT
from FFAL
where FALDATE between @smalldate1 and @smalldate2
and FALCL=@client
and (@ent is null or FALENT=@ent)
for update of FALCARFA,FALRFACT

open factures

fetch factures
into @seq,@article,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @lignes=@lignes+1
	
	if isnull(@article,'') != ''
	begin
	  exec RFA_CL @ent,@client,@an,@article,@totalht,@carfa output,@rfact output
	  
	  update FFAL
	  set FALCARFA=@carfa,FALRFACT=@rfact
	  where current of factures
	end

	if (@lignes >= 100)
	begin
		select @lignes = 0
	end
	
	fetch factures
	into @seq,@article,@totalht
	
end

close factures
deallocate cursor factures

end



go

