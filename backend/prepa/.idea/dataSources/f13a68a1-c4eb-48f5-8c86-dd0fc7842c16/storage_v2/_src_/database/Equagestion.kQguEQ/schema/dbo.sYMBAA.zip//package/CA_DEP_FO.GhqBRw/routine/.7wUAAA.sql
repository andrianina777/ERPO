


create procedure CA_DEP_FO	(@ent		char(5)	 = null,
							 @date1 	datetime,
							 @date2 	datetime,
							 @depart	char(8)  = null,
							 @fourn		char(12) = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date_1 datetime,
		@date_2 datetime

select @date_1=convert(datetime,convert(varchar(2),datepart(mm,@date1))+"/"
								+convert(varchar(2),datepart(dd,@date1))+"/"
								+convert(varchar(4),datepart(yy,@date1)-1))
select @date_2=convert(datetime,convert(varchar(2),datepart(mm,@date2))+"/"
								+convert(varchar(2),datepart(dd,@date2))+"/"
								+convert(varchar(4),datepart(yy,@date2)-1))

create table #Lignes
(
depart		char(8)		not null,
fourn		char(12)	not null,
ventes_1	numeric(14,2)	null,
ventes		numeric(14,2)	null
)


insert into #Lignes (depart,fourn,ventes_1)
select ARDEPART,STFO,sum(FALTOTALHT)
from FFAL(4),FSTOCK,FAR,FDP
where ARCODE=FALARTICLE
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and (@depart is null or ARDEPART=@depart)
and (@fourn is null or STFO=@fourn)
and FALDATE between @date_1 and @date_2
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and (DPENT=@ent and DPCENTRAL=0)))
group by ARDEPART,STFO

insert into #Lignes (depart,fourn,ventes)
select ARDEPART,STFO,sum(FALTOTALHT)
from FFAL(4),FSTOCK,FAR,FDP
where ARCODE=FALARTICLE
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and (@depart is null or ARDEPART=@depart)
and (@fourn is null or STFO=@fourn)
and FALDATE between @date1 and @date2
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and (DPENT=@ent and DPCENTRAL=0)))
group by ARDEPART,STFO


select "Departement","Fournisseur","Ventes N-1","Ventes"
select depart,fourn,isnull(sum(ventes_1),0),isnull(sum(ventes),0)
from #Lignes
group by depart,fourn
order by depart,fourn

drop table #Lignes

end



go

