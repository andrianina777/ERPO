



create procedure MajContrats	(@an		smallint,
								 @client	char(12)	= null
								)
with recompile
as
begin

  set arithabort numeric_truncation off
  
  create table #contrats
  (
  contrat		char(10)	not null
  )
  
 
  declare client	cursor
  for select RCCL
  from FRC
  where (@client is null or RCCL=@client)
  and RCAN=@an
  and isnull(RCCONTRAT,'') != ''
  and isnull(RCCL,'') != ''
  group by RCCL
  for read only
  
  declare contratsCL	cursor
  for select contrat
  from #contrats
  group by contrat
  for read only
  
  declare @contrat	char(10),
		  @leclient	char(12),
		  @seq		int,
		  @COCODE		char(10),
		  @CODEPART 	char(8),
		  @COFO		char(12),
		  @COFAM		char(8),
		  @COCATEG 	char(8),
		  @COARTICLE 	char(15),
		  @COTARIF 	char(8),
		  @COPR1		tinyint,
		  @COR1		numeric(8,4),
		  @COPR2		tinyint,
		  @COR2		numeric(8,4),
		  @COPR3		tinyint,
		  @COR3		numeric(8,4),
		  @COPRFA		tinyint,
		  @CORFA		numeric(8,4)
		  
  
  declare contrats cursor
  for select isnull(COCODE,''),isnull(CODEPART,''),isnull(COFO,''),isnull(COFAM,''),
  				isnull(COCATEG,''),isnull(COARTICLE,''),isnull(COTARIF,''),
				isnull(COPR1,0),isnull(COR1,0),isnull(COPR2,0),isnull(COR2,0),
				isnull(COPR3,0),isnull(COR3,0),isnull(COPRFA,0),isnull(CORFA,0)
  from FCO
  where COCODE=@contrat
  order by CODEPART,COFO,COFAM,COCATEG,COARTICLE,COTARIF
  
  
  open client 
  
  fetch client into @leclient
  
  while (@@sqlstatus = 0)
  begin
  
	  delete from #contrats
	  
	  insert into #contrats (contrat)
	  select RCCONTRAT from FRC where RCCL=@leclient and isnull(RCCONTRAT,'') != '' group by RCCONTRAT
  
	  delete from FRC
	  where RCCL=@leclient
	  and isnull(RCCONTRAT,'') != ''
  
	  open contratsCL
	  
	  fetch contratsCL into @contrat
	  
	  while (@@sqlstatus = 0)
		begin
  
			open contrats
			
			fetch contrats into @COCODE,@CODEPART,@COFO,@COFAM,@COCATEG,@COARTICLE,@COTARIF,
								  @COPR1,@COR1,@COPR2,@COR2,@COPR3,@COR3,@COPRFA,@CORFA
	  
			while (@@sqlstatus = 0)
			  begin
	  
	  
			  exec eq_GetSeq_proc "FRC",1,@seq output
	  
			  insert into FRC (RCSEQ,RCCL,RCCONTRAT,RCAN,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,
								  RCCT,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,
								  RCENT,RCQTE,RCMONTANT,RCSTOCK,RCDATEMDF,RCUSERMDF)
			  values(@seq,@leclient,@COCODE,@an,@CODEPART,@COFO,@COFAM,@COCATEG,@COARTICLE,@COTARIF,
								  1,@COPR1,@COR1,@COPR2,@COR2,@COPR3,@COR3,@COPRFA,@CORFA,
								  'FR',0,0,'',getdate(),1)
	  
			  fetch contrats into @COCODE,@CODEPART,@COFO,@COFAM,@COCATEG,@COARTICLE,@COTARIF,
									@COPR1,@COR1,@COPR2,@COR2,@COPR3,@COR3,@COPRFA,@CORFA
			  end
		  
		  close contrats  
  
		  fetch contratsCL into @contrat
		
	     end
	
	close contratsCL
  
	fetch client into @leclient
  end
  
  close client
  deallocate cursor client
  
  deallocate cursor contratsCL
  deallocate cursor contrats


end



go

