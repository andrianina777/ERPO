


/* Procedure permettant de comparer les commandes et la facturation entre 2 dates */
/* Il faudra prendre en compte le decalage entre la commande et la facturation pour
	une analyse pointue */
	

create procedure CompCCFA ( @ent		char(5)	= null,
							@datedeb	datetime,
							@datefin	datetime)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Finale
(
article		char(15)		null,
qtecc		int				null,
qtefa		int				null,
cacc		numeric(14,2)	null,
cafa		numeric(14,2)	null
)

insert into #Finale (article,qtecc,cacc)
select CCLARTICLE,sum(CCLQTE),sum(CCLTOTALHT)
from FCCL,FCC
where CCLDATE between @datedeb and @datefin
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@ent is null or (CCLENT=@ent and CCENT=CCLENT))
group by CCLARTICLE 


insert into #Finale (article,qtefa,cafa)
select FALARTICLE,sum(FALQTE),sum(FALTOTALHT)
from FFAL
where FALDATE between @datedeb and @datefin
and isnull(FALLETTRE,'') != ''
and (@ent is null or FALENT=@ent)
group by FALARTICLE


select Code=article,Designation=isnull(ARLIB,"Lignes libres"),qte_Cdes=sum(isnull(qtecc,0)),qte_Fact=sum(isnull(qtefa,0)),
		CA_Cdes=sum(isnull(cacc,0)),CA_Fact=sum(isnull(cafa,0)),Difference=sum(isnull(cafa,0))-sum(isnull(cacc,0))
from #Finale,FAR
where ARCODE=*isnull(article,"")
group by article,ARLIB
order by article
compute sum(sum(isnull(qtecc,0))),sum(sum(isnull(qtefa,0))),sum(sum(isnull(cacc,0))),sum(sum(isnull(cafa,0))),
		sum(sum(isnull(cafa,0))-sum(isnull(cacc,0)))

drop table #Finale

end



go

