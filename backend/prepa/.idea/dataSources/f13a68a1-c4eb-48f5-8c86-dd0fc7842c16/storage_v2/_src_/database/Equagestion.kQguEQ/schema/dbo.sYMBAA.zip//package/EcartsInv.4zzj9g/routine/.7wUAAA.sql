





create procedure EcartsInv (@ent			char(5) 	= null, 
							@code_inv		char(8), 
							@date_photo		datetime, 
							@code_photo		char(16), 
							@type			tinyint 	= 0, 
							@mode_valo		tinyint,			 
							@ecart_qte		int 		= null, 
							@ecart_val		numeric(14,2)	= null, 
							@selectmarque	char(12)	= null,	 
							@selectfamille	char(8)		= null, 
							@selectarticle	char(15)	= null,			 
							@selectdepot	char(4)		= null, 
							@selectemp      char(9)     = null 
							) 
 
with recompile 
as 
begin 
 
set arithabort numeric_truncation off 
 
if isnull(@selectemp,'')<>'' select @selectemp=rtrim(@selectemp)+'%' 
 
/* ------------------------------ CREATION TABLES TEMPORAIRES ----------------------------- */ 
 
create table #ecarts 
( 
article		char(15)	not null, 
lettre		char(4)		not null, 
qte_inv		int			not null, 
qte_stock	int			not null, 
depot		char(4)		not null, 
emp			char(8)		not null 
) 
 
create table #final 
( 
article		char(15)	not null, 
lettre		char(4)		not null, 
qte_inv		int			not null, 
qte_stock	int			not null, 
depot		char(4)		not null, 
emp			char(8)		not null 
) 
 
 
/* ------------------------------ RECUP DES ARTICLES SUIVANT LE TYPE DE JOURNAL ----------------------------- */ 
 
 
if (@type = 0) /* Journal global */ 
begin 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select INSAR,"",sum(INSQTE),0,isnull(INSDEPOT,''),isnull(INSEMP,"") 
	from FINS,FDP,FAR 
	where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=INSAR 
	and AROLD=0 
	and ARTYPE=0 
	and INSCODE=@code_inv 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or INSDEPOT=@selectdepot) 
	and (@selectemp is null or INSEMP like @selectemp) 
	group by INSAR,INSDEPOT,INSEMP 
	 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select PSEMPAR,"",0,sum(PSEMPQTE),PSEMPDEPOT,PSEMPEMP 
	from FPSEMP,FDP,FAR 
	where DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=PSEMPAR 
	and AROLD=0 
	and ARTYPE=0 
	and PSEMPDATE=@date_photo 
	and PSEMPCODE=@code_photo 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or PSEMPDEPOT=@selectdepot) 
	and (@selectemp is null or PSEMPEMP like @selectemp) 
	group by PSEMPAR,PSEMPDEPOT,PSEMPEMP 
end 
else if (@type = 1) /* Journal des articles non numerotes */ 
begin 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select INSAR,"",sum(INSQTE),0,isnull(INSDEPOT,''),isnull(INSEMP,"") 
	from FINS,FDP,FAR 
	where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=INSAR 
	and AROLD=0 
	and ARTYPE=0 
	and ARNUMEROTE=0 and ARLOT=0 	/* articles non numerotes ou sans numero lot */ 
	and INSCODE=@code_inv 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or INSDEPOT=@selectdepot) 
	and (@selectemp is null or INSEMP like @selectemp) 
	group by INSAR,INSDEPOT,INSEMP 
	 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select PSEMPAR,"",0,sum(PSEMPQTE),PSEMPDEPOT,PSEMPEMP 
	from FPSEMP,FDP,FAR 
	where DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=PSEMPAR 
	and AROLD=0 
	and ARTYPE=0 
	and ARNUMEROTE=0 and ARLOT=0 	/* articles non numerotes ou sans numero lot */ 
	and PSEMPDATE=@date_photo 
	and PSEMPCODE=@code_photo 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or PSEMPDEPOT=@selectdepot) 
	and (@selectemp is null or PSEMPEMP like @selectemp) 
	group by PSEMPAR,PSEMPDEPOT,PSEMPEMP 
end 
else if (@type = 2) /* Journal des articles numerotes */ 
begin 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select INSAR,INSLETTRE,sum(INSQTE),0,isnull(INSDEPOT,''),isnull(INSEMP,"") 
	from FINS,FDP,FAR 
	where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=INSAR 
	and AROLD=0 
	and ARTYPE=0 
	and (ARNUMEROTE=1 or ARLOT=1)	/* articles numerotes ou avec numero lot  */ 
	and INSCODE=@code_inv 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or INSDEPOT=@selectdepot) 
	and (@selectemp is null or INSEMP like @selectemp) 
	group by INSAR,INSLETTRE,INSDEPOT,INSEMP 
	 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select PSEMPAR,PSEMPLETTRE,0,sum(PSEMPQTE),PSEMPDEPOT,PSEMPEMP 
	from FPSEMP,FDP,FAR 
	where DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=PSEMPAR 
	and AROLD=0 
	and ARTYPE=0 
	and (ARNUMEROTE=1 or ARLOT=1)	/* articles numerotes ou avec numero lot  */ 
	and PSEMPDATE=@date_photo 
	and PSEMPCODE=@code_photo 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or PSEMPDEPOT=@selectdepot) 
	and (@selectemp is null or PSEMPEMP like @selectemp) 
	group by PSEMPAR,PSEMPLETTRE,PSEMPDEPOT,PSEMPEMP 
end 
else if (@type = 3) /* Journal des articles numerotes ou avec numero lot groupes */ 
begin 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select INSAR,"",sum(INSQTE),0,isnull(INSDEPOT,'') ,isnull(INSEMP,"") 
	from FINS,FDP,FAR 
	where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=INSAR 
	and AROLD=0 
	and ARTYPE=0 
	and (ARNUMEROTE=1 or ARLOT=1)	/* articles numerotes ou avec numero lot  */ 
	and INSCODE=@code_inv 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or INSDEPOT=@selectdepot) 
	and (@selectemp is null or INSEMP like @selectemp) 
	group by INSAR,INSDEPOT,INSEMP 
	 
	insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp) 
	select PSEMPAR,"",0,sum(PSEMPQTE),PSEMPDEPOT,PSEMPEMP 
	from FPSEMP,FDP,FAR 
	where DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	and ARCODE=PSEMPAR 
	and AROLD=0 
	and ARTYPE=0 
	and (ARNUMEROTE=1 or ARLOT=1)	/* articles numerotes ou avec numero lot  */ 
	and PSEMPDATE=@date_photo 
	and PSEMPCODE=@code_photo 
	and (@selectmarque is null or ARFO=@selectmarque) 
	and (@selectfamille is null or ARFAM=@selectfamille) 
	and (@selectarticle is null or ARCODE=@selectarticle) 
	and (@selectdepot is null or PSEMPDEPOT=@selectdepot) 
	and (@selectemp is null or PSEMPEMP like @selectemp) 
	group by PSEMPAR,PSEMPDEPOT,PSEMPEMP 
end 
 
 
/* ------------------------------ CALCULS SUIVANT LE MODE DE VALO ----------------------------- */ 
 
insert into #final (article,lettre,qte_inv,qte_stock,depot,emp) 
select article,lettre,sum(qte_inv),sum(qte_stock),depot,emp 
from #ecarts 
group by article,lettre,depot,emp 
 
drop table #ecarts 
 
/* FIFO : cas non traite pour le moment --- paragraphe de procedure a verifier */ 
/* 
if @mode_valo=0  
begin 
	 
	create table #Prix 
	( 
	ArticlePrix	char(15)		not null, 
	Prix		numeric(14,4)		null 
	) 
	 
	insert into #Prix (ArticlePrix,Prix) 
	select article,round((STPAHT+STFRAIS)/CVLOT,4) 
		  from FSTOCK,#final,FCV,FAR 
		  where STAR=*article 
		  and STLETTRE=lettre 
		  and ARCODE=*article 
		  and ARUNITACHAT=CVUNIF 
		 
	select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,(qte_inv-qte_stock)*Prix 
	from #final,FAR,#Prix 
	where ARCODE=article 
	and ARCODE=ArticlePrix 
	and qte_inv != qte_stock 
	and (@ecart_qte is null or abs(qte_inv - qte_stock) >= @ecart_qte) 
	and (@ecart_val is null or abs(qte_inv - qte_stock)*Prix >= @ecart_val) 
	order by ARFO,ARFAM,article,lettre,depot,emp 
 
	drop table #Prix	 
	drop table #final 
end  
*/ 
 
if @mode_valo=1 /* PRMU Global */ 
begin 
	select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,(qte_inv-qte_stock)*ARPRM 
	from #final,FAR 
	where ARCODE=article 
	and qte_inv != qte_stock 
	and (@ecart_qte is null or abs(qte_inv - qte_stock) >= @ecart_qte) 
	and (@ecart_val is null or abs(qte_inv - qte_stock)*ARPRM >= @ecart_val) 
	order by ARFO,ARFAM,article,lettre,depot,emp 
	 
	drop table #final 
end  
 
 
else if @mode_valo = 2	/* PUMP */  
begin 
	 
	/* Recuperation du dernier PUMP avant la date photo inventaire */ 
	 
	create table #DateMax 
	( 
	ArticleDate	char(15)		not null, 
	DateM		smalldatetime		null 
	) 
	 
	insert into #DateMax (ArticleDate,DateM) 
	select article,max(PUMDATE) 
	from #final,FPUM 
	where PUMAR=*article 
	and PUMDATE<=@date_photo 
	group by article		 
	 
	create table #Prix2 
	( 
	ArticlePrix	char(15)		not null, 
	Prix		numeric(14,4)		null 
	) 
	 
	insert into #Prix2 (ArticlePrix,Prix) 
	select ArticleDate,isnull(PUMP,0) 
	from #DateMax,FPUM 
	where PUMAR=ArticleDate and PUMDATE=DateM	 
	 
	drop table #DateMax 
		 
	/* select */ 
	 
	select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,(qte_inv-qte_stock)*Prix 
	from #final,FAR,#Prix2 
	where ARCODE=article 
	and ARCODE=ArticlePrix 
	and qte_inv != qte_stock 
	and (@ecart_qte is null or abs(qte_inv - qte_stock) >= @ecart_qte) 
	and (@ecart_val is null or abs(qte_inv - qte_stock)*Prix >= @ecart_val) 
	order by ARFO,ARFAM,article,lettre,depot,emp 
	 
	drop table #Prix2	 
	drop table #final 
end 
 
 
else if @mode_valo=3  /* PRMU mensuel */   
begin 
		 
	/* Recuperation du prix */ 
	 
	create table #Prix3 
	( 
	ArticlePrix	char(15)		not null, 
	Prix		numeric(14,4)		null 
	) 
	 
	declare curseurprix3 cursor  
	for select article 
	from #final 
	for read only 
 
	declare @ar3	char(15) 
	declare @prix3	numeric(14,4)	 
		 
  	open curseurprix3   
  	fetch curseurprix3 into @ar3 
   
  	while (@@sqlstatus = 0) 
	begin 
	  	 
		set rowcount 1 
 
		select @prix3=isnull(PRM,0) 
		from FPRM 
		where PRMAR = @ar3 
		and ((PRMAN = datepart(yy,@date_photo) and PRMMOIS <= datepart(mm,@date_photo)) or PRMAN < datepart(yy,@date_photo)) 
		having ((PRMAN = datepart(yy,@date_photo) and PRMMOIS <= datepart(mm,@date_photo)) or PRMAN < datepart(yy,@date_photo)) 
		and PRMAR = @ar3 
		order by PRMAN desc,PRMMOIS desc 
	 
		set rowcount 0 
	  	 
	  	insert into #Prix3 (ArticlePrix,Prix) values (@ar3,@prix3) 
	  	 
	    
      		fetch curseurprix3 into @ar3  
	end 
	 
	close curseurprix3 
	deallocate cursor curseurprix3 
	 
	/* select */ 
	 
	select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,(qte_inv-qte_stock)*Prix 
	from #final,FAR,#Prix3 
	where ARCODE=article 
	and ARCODE=ArticlePrix 
	and qte_inv != qte_stock 
	and (@ecart_qte is null or abs(qte_inv-qte_stock) >= @ecart_qte) 
	and (@ecart_val is null or abs(qte_inv-qte_stock)*Prix >= @ecart_val) 
	order by ARFO,ARFAM,article,lettre,depot,emp 
 
	drop table #Prix3	 
	drop table #final 
 
end 
 
 
 
else if @mode_valo=4 /* DPA Unitaire */ 
begin	 
 
	create table #Far 
	( 
	articledpa	char(15)	not null, 
	cvlot		int			not null, 
	dpa		numeric(14,2)	not null, 
	seq		numeric(14,0)	identity 
	) 
 
	insert into #Far (articledpa,cvlot,dpa) 
	select article,CVLOT,0.00 
	from #final,FAR,FCV 
	where ARCODE=article 
	and ARUNITACHAT=CVUNIF 
	group by article,CVLOT 
 
 
	declare stock cursor  
	for select articledpa,cvlot,seq,dpa 
	from #Far 
	order by seq 
	for read only 
 
	declare @articledpa	char(15), 
		@cvlot		int, 
		@dpa		numeric(14,2), 
		@seq		numeric(14,0), 
		@date4		smalldatetime 
 
		 
  	open stock 
   
  	fetch stock into @articledpa,@cvlot,@seq,@dpa 
   
  	while (@@sqlstatus = 0) 
	begin 
	   
		create table #maxdate 
		( 
		maxar 	char(15) 		not null, 
		maxdate smalldatetime 		null 
		) 
					 
		insert into #maxdate  
		select BLLAR,max(BLLDATECRE) 
		from FBLL 
		where BLLAR=@articledpa 
		and BLLDATECRE<=@date_photo 
		group by BLLAR 
 
		select @date4=maxdate from #maxdate  
		 
		drop table #maxdate  
		 
		 
		select @dpa = 0 
	   
	  	set rowcount 1 
	 
	 	select @dpa = round((BLLPAHT+BLLFRAIS)/CVLOT,4) 
	  	from FBLL,FCV 
	  	where BLLAR=@articledpa 
	  	and BLLDATECRE=@date4  
	  	and CVUNIF=BLLUA 
	  	having BLLAR=@articledpa 
	  	and CVUNIF=BLLUA 
	  	and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end)) 
	 
	  	if isnull(@dpa,0)=0 
	  	begin 
			/* Recuperation de la derniere date avant la date photo inventaire */ 
			 
			create table #maxdate2 
			( 
			maxar2 	char(15) 		not null, 
			maxdate2 smalldatetime 		null 
			) 
			 
			insert into #maxdate2  
			select SILARTICLE,max(SILDATEENTR) 
			from FSIL 
			where SILARTICLE=@articledpa 
			and SILDATEENTR<=@date_photo 
			group by SILARTICLE 
 
			select @date4=maxdate2 from #maxdate2  
 
			drop table #maxdate2  
					 
			select @dpa = round((SILPAHT+SILFRAIS)/@cvlot,4) 
			from FSIL 
			where SILARTICLE=@articledpa 
			and SILDATEENTR=@date4  
			having SILARTICLE=@articledpa 
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end)) 
	  	end 
	   
	  	set rowcount 0 
 
	  	update #Far 
	  	set dpa = @dpa 
	  	where seq = @seq 
	    
      		fetch stock into @articledpa,@cvlot,@seq,@dpa 
	   
	end 
	 
	close stock 
	deallocate cursor stock 
 
	create unique index art on #Far (articledpa) 
 
	/* select */ 
 
	select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,(qte_inv-qte_stock)*dpa 
	from #final,FAR,#Far 
	where ARCODE=article 
	and articledpa=article 
	and qte_inv != qte_stock 
	and (@ecart_qte is null or abs(qte_inv-qte_stock) >= @ecart_qte) 
	and (@ecart_val is null or abs(qte_inv-qte_stock)*dpa >= @ecart_val) 
	order by ARFO,ARFAM,article,lettre,depot,emp 
	 
	drop table #final 
end 
 
 
/* ---------------------------------------------------------------------------------------------- */ 
 
end 




go

