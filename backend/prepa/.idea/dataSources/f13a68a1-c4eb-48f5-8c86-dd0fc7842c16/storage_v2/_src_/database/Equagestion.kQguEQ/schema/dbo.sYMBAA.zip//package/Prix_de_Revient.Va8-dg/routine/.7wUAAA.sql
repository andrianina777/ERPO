


create procedure Prix_de_Revient (	@date			datetime = null,
									@article		char(15) = null,
									@lettre			char(4) = "",
									@modevalo		tinyint = 0		/* 0 = FIFO, 1 = PRM Global, 2 = PUMP, 3 = PRM Mensuel, 4 = DPA unitaire */
					)
with recompile
as
begin

set arithabort numeric_truncation off

declare @PrixRevient		numeric(14,4)

select 	@PrixRevient = 0

if @modevalo=0							/*--------------------- FIFO ou PRM */
  	  begin
		select @PrixRevient=round(((STPAHT+STFRAIS)/CVLOT),2)
		from FAR,FSTOCK,FCV
		where STAR=@article and STLETTRE=@lettre
		and ARUNITACHAT=CVUNIF
		and ARCODE=STAR
		and STQTE>0
  	  end
  
 if @modevalo=1		  
  	  begin
		select @PrixRevient=isnull(ARPRM,0)
		from FAR
		where ARCODE=@article		
  	  end
  	 
if @modevalo = 2									/*--------------------- PUMP */
	begin
		select @PrixRevient=isnull(PUMP,0)
		from FPUM
		where PUMAR = @article
		and PUMDATE <= convert (smalldatetime, @date)
		having PUMAR = @article
		and PUMDATE <= convert (smalldatetime, @date)
		and PUMDATE = max(PUMDATE)		  
	end

 if @modevalo = 3								/*--------------------- PRM Mensuel */
	begin
		set rowcount 1
			  
		select @PrixRevient=isnull(PRM,0)
		from FPRM
		where PRMAR = @article
		and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		and PRMAR = @article
		order by PRMAN desc,PRMMOIS desc
			  
		set rowcount 0
			  		
	end
		
if @modevalo = 4								/*--------------------- DPA unitaire */
	begin
		set rowcount 1			
			
		 select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
		from FBLL,FCV
		where BLLAR=@article
		and CVUNIF=BLLUA
		having BLLAR=@article
		and CVUNIF=BLLUA
		and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
		if isnull(@PrixRevient,0)=0
			begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
		set rowcount 0
			  
		if @PrixRevient is null
				select @PrixRevient = 0

	end
		 
	
select @PrixRevient
	 
end
 



go

