


create procedure RecapFOFAM (@ent	char(5)	 = null,
							 @date1	datetime,
							 @date2	datetime,
							 @fourn	char(12) = null)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Tab
	(
	Fourn	 	char(12)		not null,
	Fam			char(8)			not null,
	Livre		numeric(14,2)		null,
	CdeMois_	numeric(14,2)		null,
	CdeMois0	numeric(14,2)		null,
	CdeMois1	numeric(14,2)		null,
	CdeMois2	numeric(14,2)		null,
	CdeMois3	numeric(14,2)		null,
	CdeMois4	numeric(14,2)		null,
	CdeMois5	numeric(14,2)		null,
	CdeMois6	numeric(14,2)		null,
	CdeMois7	numeric(14,2)		null,
	CdeMois8	numeric(14,2)		null
	)
	
	declare @an		smallint,
			@mois	smallint
	
	
	/* Livraisons */
	
	insert into #Tab (Fourn,Fam,Livre)
	select BLLFO,ARFAM,sum(BLLTOTHT)
	from FBLL,FAR
	where ARCODE=BLLAR
	and BLLDATE between @date1 and @date2
	and ((@fourn is null) or (BLLFO=@fourn))
	and (@ent is null or BLLENT=@ent)
	group by BLLFO,ARFAM
	
	
	
	/* Commandes */
	
	select 	@an   = datepart(yy,getdate()),
			@mois = datepart(mm,getdate())
	
	/**** periode anterieure ****/
	
	insert into #Tab (Fourn,Fam,CdeMois_)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and ((datepart(yy,CFLDATEP) < @an) or (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) < @mois))
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois en cours ****/
	
	insert into #Tab (Fourn,Fam,CdeMois0)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 1 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	
	
	insert into #Tab (Fourn,Fam,CdeMois1)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	
	/**** mois + 2 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois2)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 3 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois3)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 4 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois4)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 5 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois5)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 6 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois6)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 7 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois7)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 8 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Fourn,Fam,CdeMois8)
	select CFLFO,ARFAM,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLFO,ARFAM
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
		
	/* Resultat */
	
	select Fourn,Fam,sum(isnull(Livre,0)),sum(isnull(CdeMois_,0)),
			sum(isnull(CdeMois0,0)),sum(isnull(CdeMois1,0)),sum(isnull(CdeMois2,0)),
			sum(isnull(CdeMois3,0)),sum(isnull(CdeMois4,0)),sum(isnull(CdeMois5,0)),
			sum(isnull(CdeMois6,0)),sum(isnull(CdeMois7,0)),sum(isnull(CdeMois8,0))
	from #Tab
	group by Fourn,Fam
	order by Fourn,Fam
	compute sum(sum(isnull(Livre,0))),sum(sum(isnull(CdeMois_,0))),
			sum(sum(isnull(CdeMois0,0))),sum(sum(isnull(CdeMois1,0))),
			sum(sum(isnull(CdeMois2,0))),sum(sum(isnull(CdeMois3,0))),
			sum(sum(isnull(CdeMois4,0))),sum(sum(isnull(CdeMois5,0))),
			sum(sum(isnull(CdeMois6,0))),sum(sum(isnull(CdeMois7,0))),
			sum(sum(isnull(CdeMois8,0)))
	
	drop table #Tab
	
end



go

