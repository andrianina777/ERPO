
create procedure BEBP_GenBE     (   @Depot                  char(4),                         
                                    @ent                    char(5) = null, 
                                    @result                 tinyint = 0,         /* = 1 si affiche nb de BE Traites    */ 
                                    @debug                  tinyint = 0          /* = 0 sans debug  = 1 avec message pour debug    */ 
                                )    
with recompile                         
as 
begin 
 
set arithabort numeric_truncation off 
 
/* ************************************************************************************************ */ 
/*        base - VGSPID - VGSITE - VGENT                                                                */ 
/* ************************************************************************************************ */ 
 
declare @base  varchar(50) 
select @base=db_name() 
 
declare @vgsite    int 
select @vgsite = KISITE from KInfos 
 
/*    dump tran @base with truncate_only    */ 
 
declare @vgspid    int 
select @vgspid = @@spid 
 
declare @vprefbeport    int, 
        @Autoris        int     
execute eqGetAutorisations_out "EquaGestion","Expeditions_Clients","BEPORT",@Autoris = @Autoris output 
select @vprefbeport = @Autoris 
 
declare @Pfrancobe		int, 
        @Pcodeport		varchar(15), 
        @Pforfait1		numeric(14,2), 
        @Pdevref    	char(3), 
        @Pcours			numeric(16,10), 
        @vgent			char(5) 
                 
select @Pfrancobe=PFRANCOBE, @Pcodeport=PCODEPORT, @Pforfait1=PFORFAIT1, @Pdevref=PDEVREF, @Pcours = PCOURS, @vgent = PENT 
from KParam 
 
declare @vastade tinyint 
select @vastade=DPSTADEBE from FDP where DPCODE=@Depot 
 
declare @be_prepares    int, 
                @saut_bloc    tinyint 
                 
select     @be_prepares = 0, 
                @saut_bloc = 0 
 
declare @countligne    int 
select @countligne = count(*) from PREP_TEMP where TEMP_ID=@vgspid and TEMP_VATEST2=1 
if @countligne=0 
begin 
    if @result = 1 
        select @be_prepares,"AUCUNE LIGNE A EXPEDIER"                        /*    pas de lignes a expedier    */ 
         
    return 
end 
 
/* Table PORT              */ 
/* **************** */ 
create table #Liste_port_variable (CODEMARQUE                        varchar(30)    null, 
                                   CODEARTICLE                      varchar(15)    null, 
                                   POURCENTAGE_OU_FIXE        numeric(14,2)     null     
                                  ) 
 
declare LignePort cursor 
for select    CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE 
from #Liste_port_variable 
for read only 
 
declare @codemarque                        varchar(30), 
                @codearticle                  varchar(15), 
                @pourcentage_ou_fixe    numeric(14,2) 
 
declare     @seq                int, 
            @vatest2            numeric(14,2), 
            @vaqte                int, 
            @cclcl                char(12), 
            @cclcode            char(10), 
            @ccldev                char(3), 
            @cclcoursdev        numeric(16,10), 
            @ccnom                varchar(35), 
            @ccnom2                varchar(50), 
            @ccprenom            varchar(35), 
            @ccadr1                varchar(50), 
            @ccadr2                varchar(50), 
            @cccp                varchar(12), 
            @ccville            varchar(30), 
            @ccpy                char(8), 
            @ccpays                varchar(30) 
                     
declare     @beseq                int, 
            @becode                char(10), 
            @bedate                smalldatetime, 
            @yy                    char(4), 
            @mm                    char(2), 
            @jj                    char(2), 
            @bean                char(2), 
            @bemois                char(2), 
            @numint                int, 
            @numchar            char(4), 
            @an                    int, 
            @mois                int, 
            @becl                char(12), 
            @becoursdev            numeric(16,10), 
            @bedev                char(3), 
            @bestade            tinyint, 
            @client                char(12), 
            @nom                varchar(35), 
            @adr1                varchar(50), 
            @cp                    varchar(12), 
            @devise                varchar(3), 
            @commande            char(10), 
            @artype                int, 
            @beregle            int, 
            @becc                char(10), 
            @beechspe            tinyint, 
            @betotalht            numeric(14,2), 
            @betotalhtdev        numeric(14,2), 
            @beobservations        varchar(255), 
            @betarif            char(8), 
            @beent                char(5), 
            @belent                char(5) 
 
declare     @beltypemv            char(2), 
            @belseq                int, 
            @belcode            char(10), 
            @beldate            smalldatetime, 
            @belcl                char(12), 
            @belusercre            int, 
            @beldatecre            smalldatetime, 
            @belusermdf            int, 
            @beldatemdf            smalldatetime, 
            @beldev                char(3), 
            @belcoursdev        numeric(16,10), 
            @belstade            tinyint, 
            @belarticle            char(15), 
            @belprixht            numeric(14,2), 
            @beltotalht            numeric(14,2), 
            @belunitfact        tinyint, 
            @beltypeve            char(4), 
            @beltype            tinyint, 
            @bellibre            varchar(255), 
            @beldemo            int, 
            @belliencode        char(10), 
            @belliennum            int, 
            @belechspe            tinyint, 
            @belremise1            real, 
            @belremise2            real, 
            @belremise3            real, 
            @belremise4         real, 
            @belremise5            real, 
            @belfactman            tinyint, 
            @bel_factman        tinyint, 
            @beloffert            tinyint, 
            @belmotif            char(8), 
            @beldotation        tinyint, 
            @belprixhtdev        numeric(14,2), 
            @beltotalhtdev        numeric(14,2), 
            @belqte                int, 
            @bellettre            char(4), 
            @belreste            int, 
            @nbfranco            int,        /* Il suffit qu  1 seule commande ne soit pas franco pour appliquer les frais de Port    */ 
            @numcde                char(10), 
            @belmarche            char(12), 
            @bel_num            int, 
            @belnum                int, 
            @belordre            int, 
            @bel_ordre            int, 
            @belemp                char(8) 
 
declare     @cclarticle            char(15), 
            @clccbe                tinyint, 
            @cclpht                numeric(14,2), 
            @ccltotalht            numeric(14,2), 
            @cclunitfact        tinyint, 
            @ccltv                char(4), 
            @ccltype            tinyint, 
            @ccllibre            varchar(255), 
            @ccechspe            int, 
            @cclr1                real, 
            @cclr2                real, 
            @cclr3                real, 
            @cclfactman            tinyint, 
            @ccloffert            tinyint, 
            @cclphtdev            numeric(14,2), 
            @ccltotalhtdev        numeric(14,2), 
            @ccfranco            int, 
            @ccfrancobe            int, 
            @cclmarche            char(12), 
            @arcomp                tinyint, 
            @cclnum                int, 
            @cccommentaires        varchar(255), 
            @cctarif            char(8), 
            @ccescompte            real 
 
 
declare     @vp3n1                numeric(14,3) 
declare        @passage            tinyint 
declare        @num                     int 
 
declare     @clchoixport        int, 
            @clport                numeric(14,2) 
 
declare     @stempar            char(15), 
            @stemplettre        char(4), 
            @stempqte            int, 
            @stempdepot            char(4), 
            @stempemp            char(8) 
 
declare LigneStock cursor 
for select STEMPAR,STEMPLETTRE,
STEMPQTE 
	- isnull((select sum(BPLQTE) from FBPL where 
	BPLARTICLE=FSTEMP.STEMPAR and BPLDEPOT=FSTEMP.STEMPDEPOT and BPLEMP=FSTEMP.STEMPEMP and BPLLETTRE=FSTEMP.STEMPLETTRE
	and BPLSTADE < 4),0),
STEMPDEPOT,STEMPEMP 
from FSTEMP,FDP,FARE 
where STEMPAR = @belarticle 
and AREAR=STEMPAR 
and AREDEPOT=STEMPDEPOT 
and AREEMP=STEMPEMP 
and DPLOC=1 and DPCODE=@Depot 
and STEMPQTE
	- isnull((select sum(BPLQTE) from FBPL where 
	BPLARTICLE=FSTEMP.STEMPAR and BPLDEPOT=FSTEMP.STEMPDEPOT and BPLEMP=FSTEMP.STEMPEMP and BPLLETTRE=FSTEMP.STEMPLETTRE
	and BPLSTADE < 4),0)> 0 
and STEMPDEPOT=DPCODE and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
order by AREPICK desc, ltrim(case when charindex(' ',STEMPLETTRE) != 0 then ("*"+STEMPLETTRE) else STEMPLETTRE end) 
for read only 
 
declare LigneCde cursor 
for select    TEMP_CCLSEQ,TEMP_CCLCL, TEMP_CCNOM, TEMP_CCADR1, TEMP_CCCP, TEMP_CCLDEV, TEMP_CCLCODE,TEMP_VATEST2, TEMP_VAQTE, 
                        TEMP_CCLDEV,TEMP_CCLCOURSDEV,TEMP_CCNOM2,TEMP_CCPRENOM,TEMP_CCADR1,TEMP_CCADR2,TEMP_CCCP,TEMP_CCVILLE,TEMP_CCPY,TEMP_CCPAYS, 
                        TEMP_CCLARTICLE,TEMP_CCLPHT,TEMP_CCLTOTALHT,TEMP_CCLUNITFACT,TEMP_CCLTV,TEMP_CCLTYPE,TEMP_CCLLIBRE,TEMP_CCECHSPE, 
                        TEMP_CCLR1,TEMP_CCLR2,TEMP_CCLR3,TEMP_CCLFACTMAN,TEMP_CCLOFFERT,TEMP_CCLPHTDEV,TEMP_CCLTOTALHTDEV, 
                        TEMP_CCFRANCO,TEMP_CCFRANCOBE,TEMP_CCLMARCHE,TEMP_ARCOMP,TEMP_CCLNUM,TEMP_CLCCBE,TEMP_CCCOMMENTAIRES,TEMP_CCTARIF, 
                        CCESCOMPTE 
from PREP_TEMP, FCC 
where TEMP_ID = @vgspid 
and CCCODE = TEMP_CCLCODE 
order by TEMP_CCLCL, TEMP_CCNOM, TEMP_CCPAYS, TEMP_CCVILLE, TEMP_CCCP, TEMP_CCADR1, TEMP_CCLDEV, TEMP_CCLCODE, TEMP_CCLNUM 
for read only 
 
select @client = '-' 
select @nom = '-' 
select @adr1 = '-' 
select @cp = '-' 
select @devise = '-' 
select @commande = '-' 
 
select @becode = '', @passage = 0, @be_prepares = 0 
 
if @debug = 1 
    select 'debug','DEBUT ', @Depot, @ent, @vgent 
 
/* ********************************************************************************************************* */ 
/*                                     DEBUT         TRAITEMENT                                                   */ 
/* ********************************************************************************************************* */ 
 
open LigneCde 
fetch LigneCde into     @seq, @cclcl, @ccnom, @ccadr1, @cccp, @ccldev, @cclcode, @vatest2, @vaqte, 
                        @ccldev, @cclcoursdev,@ccnom2,@ccprenom,@ccadr1,@ccadr2,@cccp,@ccville,@ccpy,@ccpays, 
                        @cclarticle,@cclpht,@ccltotalht,@cclunitfact,@ccltv,@ccltype,@ccllibre,@ccechspe, 
                        @cclr1,@cclr2,@cclr3,@cclfactman,@ccloffert,@cclphtdev,@ccltotalhtdev, 
                        @ccfranco,@ccfrancobe,@cclmarche,@arcomp,@cclnum,@clccbe,@cccommentaires,@cctarif, 
                        @ccescompte 
 
while (@@sqlstatus=0) 
begin  
 
    if @debug = 1 
        select 'debug','entre boucle',@becode,@vatest2,@vaqte,@passage 
     
    if @vatest2=1 and @vaqte>0 
    begin 
 
        if @debug = 1 
            select 'debug','int @cclcl=@client',@cclcl,@client,@ccnom,@nom,@ccadr1,@adr1,@cccp,@cp,@ccldev,@devise,@commande,@cclcode,@clccbe 
     
        if ((@cclcl<>@client) or (@ccnom<>@nom) or (@ccadr1<>@adr1) or (@cccp<>@cp) 
                              or (@ccldev<>@devise) or (@commande<>@cclcode and @clccbe=1)) 
        begin 
             
            if @debug = 1 
                select 'debug','@cclcl<>@client',@becode,@passage,@vatest2 
             
            /* ********************************************************************************************************* */ 
            /*                         Traitement en fin du BE                                                               */ 
            /* ********************************************************************************************************* */ 
            if @passage = 1    and @becode <> ''                 
            begin 
                if @debug = 1 
                    select 'debug',"fin BE",@becode,"a suivre" 
                 
                /*        Maj de BEMARCHE en fonction du nombre de lignes contenant un BELMARCHE        */ 
                select @countligne = 0 
                select @countligne = count(*) from FBEL where BELCODE=@becode and isnull(BELMARCHE,"")<>"" 
                 
                if @debug = 1 
                    select 'debug','fin BE',@becode,'BEMARCHE',@countligne 
                 
                if @countligne > 1 
                    update FBE set BEMARCHE=1 where BECODE=@becode and (@ent is null or BEENT=@ent) 
                             
                /*        Totaux_BE_maj        */ 
                select @saut_bloc = 0 
                 
                select @countligne = 0 
                select @countligne = count(*) from FBEL where BELCODE=@becode 
                       
                if @countligne = 0 
                begin 
                    delete from FBE where BECODE=@becode 
                    select @an     = datepart(year,@bedate) 
                    select @mois = datepart(month,@bedate) 
                    select @num = convert(int,substring(@becode,7,4)) 
                     
                    if @debug = 1 
                        select 'debug','delete BE',@becode,@an, @mois, @num 
                     
                    select @be_prepares = @be_prepares - 1 
                     
                    if @ent is null                     
                        execute eq_LibNum @vgent, 'FBE', @an, @mois, @num 
                    else 
                        execute eq_LibNum @ent, 'FBE', @an, @mois, @num 
             
                    if @result = 1 
                        select @be_prepares,"BON(S) D'EXPEDITIONS GENERE(S)" 
                         
                    select @saut_bloc = 1                 
                end 
             
                if @saut_bloc = 0 
                begin 
             
                    /*        Recupere BECC        */ 
                    select @becc = '' 
                    select @countligne = 0 
                    select @countligne = count(distinct BELLIENCODE) from FBEL where BELCODE=@becode and (@ent is null or BELENT=@ent) 
                 
                    if @countligne = 1 
                        select @becc = isnull(BELLIENCODE,'') from FBEL where BELCODE=@becode and (@ent is null or BELENT=@ent) 
                        group by BELCODE 
                 
                 
                    /***************************************************************************************************************/ 
                    /************************** Les frais de port ne sont plus traites en allocation automatique *******************/ 
                    /***************************************************************************************************************/ 
                     
                     
                    /*        Il suffit qu  1 seule commande ne soit pas franco pour appliquer les frais de Port    */ 
                    if @nbfranco > 0 and @vprefbeport = 1 and @vprefbeport = 0 and @vprefbeport = 2 
                    begin 
                        select @clchoixport=0 
                        select @clport=0 
                 
                        /*    Recherche des conditions de port de la fiche client    */         
                        select @clchoixport=isnull(CLCHOIXPORT,0),@clport=isnull(CLPORT,0) from FCL where CLCODE=@belcl and (@ent is null or CLENT=@ent) 
                 
                        if @clchoixport <> 0 
                        begin 
                         
                            delete from #Liste_port_variable 
                         
                            if @clchoixport = 2 
                            begin 
                                insert into #Liste_port_variable (CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE) 
                                    select INFPIN_FO,INFPAR,INFPPOURCENTAGE from FINFP where INFPIN_CL=@becl and (@ent is null or INFPENT=@ent) 
                                 
                                select @countligne = 0 
                                select @countligne = count(*) from #Liste_port_variable 
                                if @countligne = 0  
                                    insert into #Liste_port_variable (CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE) values ('',@Pcodeport,@clport) 
                            end     
                         
                            if @clchoixport = 1                                                        /*    F comme forfait    */ 
                                insert into #Liste_port_variable (CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE) values ('$F$',@Pcodeport,case when @clport=0 then @Pforfait1 else @clport end) 
                             
                            open LignePort 
                            fetch LignePort into     @codemarque, @codearticle, @pourcentage_ou_fixe 
                                 
                            while (@@sqlstatus=0) 
                            begin  
                                 
                                select @belarticle = @codearticle 
                                select @beltypeve = '' 
                                select @beltypeve = ARTYPEVE from FAR where ARCODE = @belarticle 
                              
                                select @belprixht = 0 
                                select @belunitfact = 0 
                                select @beltype = 0 
                                select @beldemo = 0 
                                select @belliencode = '' 
                                select @belliennum = 0 
                                select @belechspe = 0 
                                select @belremise1 = 0 
                                select @belremise2 = 0 
                                select @belremise3 = 0 
                                select @belremise4 = 0 
                                select @belremise5 = 0 
                                select @belfactman = @bel_factman 
                                select @beloffert = 0 
                                select @belmotif = "" 
                                select @beldotation = 0 
                                select @belprixhtdev = 0 
                                select @belqte = 1 
                                select @belstade = 3 
                                 
                                select @belnum = @bel_num + 1 
                                select @bel_num = @bel_num + 1 
                                select @belordre = @bel_ordre + 32 
                                select @bel_ordre = @bel_ordre + 32 
                                 
                                select @bellettre = 'AAAB' 
                                select @belreste = @belqte 
                                 
                                execute eq_GetSeq_proc 'FBEL',1,@i = @belseq output 
                     
                                if @codemarque = '$F$' 
                                    select @belprixht = @pourcentage_ou_fixe 
                                else 
                                    select @belprixht = isnull(sum(BELTOTALHT)*@pourcentage_ou_fixe/100,0) from FBEL,FAR  
                                    where ARCODE=BELARTICLE and BELCODE=@becode and (@ent is null or BELENT=@ent) and (@codemarque='' or ARFO=@codemarque) and isnull(ARTYPE,0)<=1 
                                     
                                select @beltotalht = @belprixht 
                     
                                If @beltotalht>0 
                                begin 
                                    if @beldev <> @Pdevref 
                                    begin 
                                        execute Conversion_div_proc @belprixht,@Pcours,3,@mt = @vp3n1 output 
                                        select @belprixhtdev = @vp3n1 * @becoursdev 
                                        select @beltotalhtdev = @belprixhtdev 
                                    end 
                                    else 
                                    begin 
                                        select @belprixhtdev = @belprixht 
                                        select @beltotalhtdev = @beltotalht 
                                    end 
                                 
                                    select @belent = @vgent 
                                     
                                    insert into FBEL (BELSEQ,BELCODE,BELARTICLE,BELQTE,BELDATE,BELPRIXHT,BELORDRE,BELUNITFACT,BELTYPEVE,BELTYPE,BELLIBRE,BELNUM,BELDEMO, 
                                        BELLETTRE,BELRESTE,BELLIENCODE,BELLIENNUM,BELCL,BELTOTALHT,BELECHSPE,BELREMISE1,BELREMISE2,BELREMISE3,BELREMISE4,BELREMISE5, 
                                        BELTYPEMV,BELUSERMDF,BELDATEMDF,BELUSERCRE,BELDATECRE,BELFACTMAN,BELOFFERT,BELMOTIF,BELDOTATION,BELDEV,BELCOURSDEV, 
                                        BELPRIXHTDEV,BELTOTALHTDEV,BELSTADE,BELENT,BELATTACHE,BELEMP,BELMARCHE,BELCOLIS,BELPAHT) 
                                    values     (@belseq,@belcode,@belarticle,@belqte,@beldate,@belprixht,@belordre,@belunitfact,@beltypeve,@beltype,@bellibre,@belnum,@beldemo, 
                                        @bellettre,@belreste,@belliencode,@belliennum,@belcl,@beltotalht,@belechspe,@belremise1,@belremise2,@belremise3,@belremise4,@belremise5, 
                                        @beltypemv,@belusermdf,@beldatemdf,@belusercre,@beldatecre,@belfactman,@beloffert,@belmotif,@beldotation,@beldev,@belcoursdev, 
                                        @belprixhtdev,@beltotalhtdev,@belstade,@belent,null,@belemp,@belmarche,null,null) 
                                end 
                                                         
                                fetch LignePort into     @codemarque,@codearticle,@pourcentage_ou_fixe 
                            end 
                            close LignePort 
                                                                         
                        end        /* @clchoixport <> 0    */ 
                 
                        /*    Le franco apres premier BE=1 si il n y a pas de traitement ou si un forfait est applique    */ 
                        if @clchoixport<2 and @Pfrancobe=1 
                                update FCC set CCFRANCOBE=1 where CCCODE=@numcde and (@ent is null or CCENT=@ent) 
                 
                    end        /*    @nbfranco > 0 and @vprefbeport = 1    */ 
                     
                    /***************************************************************************************************************/ 
                    /*********************  Fin de la partie port qui n est plus traitee en allocation automatique *****************/ 
                    /***************************************************************************************************************/ 
 
                    select @numcde=@cclcode 
                     
                    if @Pfrancobe=1 
                            update FCC set CCFRANCOBE=1 where CCCODE=@numcde and (@ent is null or CCENT=@ent) 
                     
                         
                     
                 
                    select @beechspe = min(BELECHSPE), @betotalht = sum(BELTOTALHT), @betotalhtdev = sum(BELTOTALHTDEV) from FBEL 
                    where BELCODE=@becode and (@ent is null or BELENT=@ent) 
                     
                    select @beregle = 0 
                    select @beregle = count(*) from FAR,FBEL where BELCODE=@becode and BELARTICLE=ARCODE and ARREGLE > 0 and (@ent is null or BELENT=@ent) 
                 
                    if @vgsite=6 
                         select @bestade = @vastade 
                         
                    if @vgsite <> 6 
                        select @bestade = 3 
                 
                    update FBE set     BEECHSPE=@beechspe, BETOTALHT=@betotalht, BETOTALHTDEV=@betotalhtdev, BEREGLE=@beregle, 
                                    BEOBSERVATIONS=@beobservations, BECC=@becc, BESTADE=@bestade, BEESCOMPTE = @ccescompte 
                    where BECODE=@becode and (@ent is null or BEENT=@ent)         
                end 
                 
                select @saut_bloc = 0 
                 
            end        /*        @passage = 1    and @becode <>      */ 
             
            if @debug = 1 
                select 'debug','int valeur client pour NOUVEAU BE' 
             
            select @client = @cclcl 
            select @nom = @ccnom 
            select @adr1 = @ccadr1 
            select @cp = @cccp 
            select @devise = @ccldev 
            select @commande = @cclcode 
         
            /* ********************* */ 
            /* 1.Insertion dans FBE  */ 
            /* ********************* */ 
                     
            select @bedate = getdate() 
            select @yy = convert(char(4),datepart(yy,@bedate)) 
            select @mm = right('00'+convert(varchar,datepart(month,@bedate)),2) 
            select @jj = right('00'+convert(varchar,datepart(day,@bedate)),2) 
             
            select @an     = datepart(year,@bedate) 
            select @mois = datepart(month,@bedate) 
 
            if @ent is null 
                execute eq_GetNum_proc @vgent,'FBE',@an,@mois,1,@i = @numint output 
            else 
                execute eq_GetNum_proc @ent,'FBE',@an,@mois,1,@i = @numint output 
             
            select @numchar=right('0000'+convert(varchar,@numint),4) 
 
            select @bean=right('00'+convert(varchar,datepart(yy,@bedate)),2) 
            select @bemois=right('00'+convert(varchar,datepart(month,@bedate)),2) 
 
            execute eq_GetSeq_proc 'FBE',1,@i = @beseq output 
 
            select @becode='BE'+@bean+@bemois+@numchar 
            select @bedate = convert(smalldatetime,@yy+@mm+@jj) 
             
            select @becc='', @betarif=@cctarif, @becl=@cclcl, @bedev=@ccldev, @becoursdev=@cclcoursdev, 
                         @bestade=(case when @vgsite=6 then @vastade else 3 end), @nbfranco=0, @betotalht=0, @betotalhtdev=0, @beregle=0, 
                         @beechspe=0,@beobservations='',@beent=@vgent 
             
            if @debug = 1 
                select 'debug','insert FBE',@becode,@passage,@bedate,@becl,@bestade   
             
            select @be_prepares = @be_prepares + 1 
             
            insert into FBE (BECODE,BESEQ,BEDATE,BERET,BECL,BEDEV,BECOURSDEV,BEUSERCRE,BEDATECRE,BEUSERMDF,BEDATEMDF,BESTADE,BETARIF, 
                            BENOM,BENOM2,BEPRENOM,BEADR1,BEADR2,BECP,BEVILLE,BEPY,BEPAYS,BEOBSERVATIONS,BECC,BEENT,BETOTALHT, 
                            BETOTALHTDEV,BEREGLE,BEECHSPE,BEMARCHE,BEESCOMPTE) 
            values     (@becode,@beseq,@bedate,0,@becl,@bedev,@becoursdev,@vgspid,getdate(),@vgspid,getdate(),@bestade,@betarif, 
                            @ccnom,@ccnom2,@ccprenom,@ccadr1,@ccadr2,@cccp,@ccville,@ccpy,@ccpays,@beobservations,@becc,@beent, 
                            @betotalht,@betotalhtdev,@beregle,@beechspe,0,@ccescompte) 
 
            /* ********************* */ 
            /* 2.prep dans FBEL             */ 
            /* ********************* */ 
     
            select     @beltypemv='BE', 
                    @belcode=@becode, 
                    @beldate=@bedate, 
                    @belcl=@becl, 
                    @belusercre=@vgspid, 
                    @beldatecre=getdate(), 
                    @belusermdf=@vgspid, 
                    @beldatemdf=getdate(), 
                    @beldev=@bedev, 
                    @belcoursdev=@becoursdev, 
                    @belstade=@bestade 
             
            select     @bel_num = 0, @bel_ordre = 0, @belnum = 0, @belordre = 0 
     
                     
            select @passage = 1 
             
            if @debug = 1 
                select 'debug','init FBEL',@belcode,@beldate,@belstade 
             
        end 
         
        if @debug = 1 
            select 'debug','compare @cclcl=@client',@cclcl,@client,@ccnom,@nom,@ccadr1,@adr1,@cccp,@cp,@ccldev,@devise,@commande,@cclcode,@clccbe 
         
        if ((@cclcl=@client)and(@ccnom=@nom)and(@ccadr1=@adr1)and(@cccp=@cp)and(@ccldev=@devise)and((@commande=@cclcode and @clccbe=1)or(@clccbe=0))) 
        begin 
 
            if @debug = 1 
                select 'debug','@cclcl=@client',@becode,@passage,@vatest2 
             
            if @vatest2=1 
            begin 
                    /*    Initialisation des variables        */ 
                     
                    select @artype = 0 
                    select @artype=ARTYPE from FAR where ARCODE=@cclarticle 
 
                    if @vgsite=6 
                    begin 
                        if (@artype=0 or @artype=1) 
                                select @belstade=@vastade 
                        else 
                                select @belstade=3 
                    end 
                    else 
                        select @belstade=3 
 
                    select @belarticle=@cclarticle, @belprixht=@cclpht, @beltotalht=@ccltotalht, @belunitfact=@cclunitfact 
                    select @beltypeve=@ccltv, @beltype=@ccltype, @bellibre=@ccllibre, @beldemo=0, @belliencode=@cclcode 
                    select @belliennum=@cclnum, @belechspe=@ccechspe, @belremise1=@cclr1, @belremise2=@cclr2, @belremise3=@cclr3 
                    select @belremise4=0, @belremise5=0, @belfactman=@cclfactman, @bel_factman=@belfactman, @beloffert=@ccloffert 
                    select @belmotif="", @beldotation=0, @belprixhtdev=@cclphtdev, @beltotalhtdev=@ccltotalhtdev 
                     
                    /*    ajout de ligne de port ssi (@ccfranco=0 and @ccfrancobe=0)    */ 
                    select @nbfranco = @nbfranco + (case when (@ccfranco=0 and @ccfrancobe=0) then 1 else 0 end) 
                     
                    select @numcde=@cclcode, @belmarche=@cclmarche 
 
                    if @debug = 1 
                        select 'debug','init ligne article',@belcode,@passage,@belstade,@belarticle,@artype,@vaqte                     
                     
                    /*        Ajout ligne de BE        */ 
 
                    if @artype=0 and @vaqte>0 
                    begin                 
                        if @debug = 1 
                            select 'debug','Ajout des lignes BE    ' 
 
                        open LigneStock 
                        fetch LigneStock into     @stempar, @stemplettre, @stempqte, @stempdepot, @stempemp 
                                     
                        while (@@sqlstatus=0) and @vaqte > 0 
                        begin  
                                     
                            if @vaqte < @stempqte 
                                    select @belqte = @vaqte 
                            else  
                                    select @belqte = @stempqte 
                                     
                            select @belnum = @belnum + 1  
                            select @bel_num = @belnum 
                            select @belordre = @belordre + 32 
                            select @bel_ordre = @belordre 
                                         
                            select @bellettre = @stemplettre 
                            select @belreste = @belqte 
                            select @belemp = @stempemp 
                                     
                            execute eq_GetSeq_proc 'FBEL',1,@i = @belseq output 
                                         
                            execute eq_CalculTotal_proc  @belprixhtdev,@belunitfact,@belqte,@belremise1,@belremise2,@belremise3,@totalht = @beltotalhtdev output 
                                     
                            if @bedev <> @Pdevref 
                                    select @beltotalht = @beltotalhtdev 
                            else 
                                    execute eq_CalculTotal_proc  @belprixht,@belunitfact,@belqte,@belremise1,@belremise2,@belremise3,@totalht = @beltotalht output 
                             
                            select @belent = @vgent                         
                                     
                            insert into FBEL (BELSEQ,BELCODE,BELARTICLE,BELQTE,BELDATE,BELPRIXHT,BELORDRE,BELUNITFACT,BELTYPEVE,BELTYPE,BELLIBRE,BELNUM,BELDEMO, 
                                    BELLETTRE,BELRESTE,BELLIENCODE,BELLIENNUM,BELCL,BELTOTALHT,BELECHSPE,BELREMISE1,BELREMISE2,BELREMISE3,BELREMISE4,BELREMISE5, 
                                    BELTYPEMV,BELUSERMDF,BELDATEMDF,BELUSERCRE,BELDATECRE,BELFACTMAN,BELOFFERT,BELMOTIF,BELDOTATION,BELDEV,BELCOURSDEV, 
                                    BELPRIXHTDEV,BELTOTALHTDEV,BELSTADE,BELENT,BELATTACHE,BELEMP,BELMARCHE,BELCOLIS,BELPAHT) 
                                values     (@belseq,@belcode,@belarticle,@belqte,@beldate,@belprixht,@belordre,@belunitfact,@beltypeve,@beltype,@bellibre,@belnum,@beldemo, 
                                    @bellettre,@belreste,@belliencode,@belliennum,@belcl,@beltotalht,@belechspe,@belremise1,@belremise2,@belremise3,@belremise4,@belremise5, 
                                    @beltypemv,@belusermdf,@beldatemdf,@belusercre,@beldatecre,@belfactman,@beloffert,@belmotif,@beldotation,@beldev,@belcoursdev, 
                                    @belprixhtdev,@beltotalhtdev,@belstade,@belent,null,@belemp,@belmarche,null,null) 
 
                            if @debug = 1 
                                    select 'debug','commentaire',@cccommentaires ,(case when charindex(@cclcode,@cccommentaires)>0 then 1 else 0 end), @cclcode 
                                     
                            if @cccommentaires <> '' and (case when charindex(@cclcode,@beobservations)>0 then 1 else 0 end)=0 
                                    select @beobservations = @beobservations + ' +(' + @cclcode + ') ' + @cccommentaires 
                                                                      
                            select @vaqte = @vaqte - @belqte 
                                         
                            fetch LigneStock into     @stempar, @stemplettre, @stempqte, @stempdepot, @stempemp 
                        end 
                        close LigneStock 
                    end 
                    else if @artype<>0 and @vaqte>0 and @vgsite<>6 
                    begin 
                                    if @debug = 1 
                                        select 'debug','Ajout des lignes articles non stockes',@artype,@vaqte,@vgsite 
 
                                    if @artype = 0 
                                    begin                                     
                                        set rowcount 1 
                                        select @stemplettre=STEMPLETTRE, @stempemp=STEMPEMP 
                                        from FSTEMP,FDP,FARE 
                                        where STEMPAR = @belarticle 
                                        and AREAR=STEMPAR 
                                        and AREDEPOT=STEMPDEPOT 
                                        and AREEMP=STEMPEMP 
                                        and isnull(AREPICK,0) = 1 
                                        and DPLOC=1 and DPCODE=@Depot 
                                        and STEMPQTE > 0 
                                        and STEMPDEPOT=DPCODE and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
                                        set rowcount 0 
                                         
                                        select @bellettre = @stemplettre, @belemp = @stempemp 
                                    end 
                                    else if @artype <> 0 
                                        select @bellettre = 'AAAA', @belemp = '0000' 
                                                                                         
                                    select @belnum = @belnum + 1  
                                    select @bel_num = @belnum 
                                    select @belordre = @belordre + 32 
                                    select @bel_ordre = @belordre 
                                         
                                    select @belqte = @vaqte 
                                    select @belreste = @belqte 
                                     
                                    execute eq_GetSeq_proc 'FBEL',1,@i = @belseq output 
                                         
                                    execute eq_CalculTotal_proc  @belprixhtdev,@belunitfact,@belqte,@belremise1,@belremise2,@belremise3,@totalht = @beltotalhtdev output 
                                     
                                    if @bedev <> @Pdevref 
                                        select @beltotalht = @beltotalhtdev 
                                    else 
                                        execute eq_CalculTotal_proc  @belprixht,@belunitfact,@belqte,@belremise1,@belremise2,@belremise3,@totalht = @beltotalht output 
                                     
                                    select @belent = @vgent 
                                     
                                    insert into FBEL (BELSEQ,BELCODE,BELARTICLE,BELQTE,BELDATE,BELPRIXHT,BELORDRE,BELUNITFACT,BELTYPEVE,BELTYPE,BELLIBRE,BELNUM,BELDEMO, 
                                            BELLETTRE,BELRESTE,BELLIENCODE,BELLIENNUM,BELCL,BELTOTALHT,BELECHSPE,BELREMISE1,BELREMISE2,BELREMISE3,BELREMISE4,BELREMISE5, 
                                            BELTYPEMV,BELUSERMDF,BELDATEMDF,BELUSERCRE,BELDATECRE,BELFACTMAN,BELOFFERT,BELMOTIF,BELDOTATION,BELDEV,BELCOURSDEV, 
                                            BELPRIXHTDEV,BELTOTALHTDEV,BELSTADE,BELENT,BELATTACHE,BELEMP,BELMARCHE,BELCOLIS,BELPAHT) 
                                        values     (@belseq,@belcode,@belarticle,@belqte,@beldate,@belprixht,@belordre,@belunitfact,@beltypeve,@beltype,@bellibre,@belnum,@beldemo, 
                                            @bellettre,@belreste,@belliencode,@belliennum,@belcl,@beltotalht,@belechspe,@belremise1,@belremise2,@belremise3,@belremise4,@belremise5, 
                                            @beltypemv,@belusermdf,@beldatemdf,@belusercre,@beldatecre,@belfactman,@beloffert,@belmotif,@beldotation,@beldev,@belcoursdev, 
                                            @belprixhtdev,@beltotalhtdev,@belstade,@belent,null,@belemp,@belmarche,null,null) 
                                     
                                    if @debug = 1 
                                        select 'debug','commentaire',@cccommentaires ,(case when charindex(@cclcode,@cccommentaires)>0 then 1 else 0 end), @cclcode 
                                         
                                    if @cccommentaires <> '' and (case when charindex(@cclcode,@beobservations)>0 then 1 else 0 end)=0 
                                        select @beobservations = @beobservations + ' +(' + @cclcode + ') ' + @cccommentaires 
                                     
                                    select @vaqte = @vaqte - @belqte 
                    end 
            end 
        end 
    end 
     
    if @debug = 1 
        select 'debug','fetch boucle',@becode,@passage 
 
    fetch LigneCde into     @seq, @cclcl, @ccnom, @ccadr1, @cccp, @ccldev, @cclcode, @vatest2, @vaqte, 
                            @ccldev, @cclcoursdev,@ccnom2,@ccprenom,@ccadr1,@ccadr2,@cccp,@ccville,@ccpy,@ccpays, 
                            @cclarticle,@cclpht,@ccltotalht,@cclunitfact,@ccltv,@ccltype,@ccllibre,@ccechspe, 
                            @cclr1,@cclr2,@cclr3,@cclfactman,@ccloffert,@cclphtdev,@ccltotalhtdev, 
                            @ccfranco,@ccfrancobe,@cclmarche,@arcomp,@cclnum,@clccbe,@cccommentaires,@cctarif, 
                            @ccescompte 
end 
 
/* ********************************************************************************************************* */ 
/*                                                                             Traitement en fin du BE                                                                                           */ 
/* ********************************************************************************************************* */ 
if @passage = 1    and @becode <> ''                 
begin 
 
if @debug = 1 
    select 'debug',"fin BE et fin procedure",@becode 
 
    /*        Maj de BEMARCHE en fonction du nombre de lignes contenant un BELMARCHE        */ 
    select @countligne = 0 
    select @countligne = count(*) from FBEL where BELCODE=@becode and isnull(BELMARCHE,"")<>"" 
     
    if @countligne > 1 
        update FBE set BEMARCHE=1 where BECODE=@becode and (@ent is null or BEENT=@ent) 
                 
    /*        Totaux_BE_maj        */ 
    select @saut_bloc = 0 
     
    select @countligne = 0 
    select @countligne = count(*) from FBEL where BELCODE=@becode 
 
  if @debug = 1 
      select 'debug','fin BE',@becode,'delete FBE si = 0',@countligne 
   
    if @countligne = 0 
    begin 
        delete from FBE where BECODE=@becode 
        select @an     = datepart(year,@bedate) 
        select @mois = datepart(month,@bedate) 
        select @num = convert(int,substring(@becode,7,4)) 
         
        if @debug = 1 
            select 'debug','delete BE',@becode,@an, @mois, @num 
         
        select @be_prepares = @be_prepares - 1 
         
        if @ent is null                     
            execute eq_LibNum @vgent, 'FBE', @an, @mois, @num 
        else 
            execute eq_LibNum @ent, 'FBE', @an, @mois, @num 
 
        if @result = 1 
            select @be_prepares,"BON(S) D'EXPEDITIONS GENERE(S)" 
             
        select @saut_bloc = 1 
    end 
 
    if @saut_bloc = 0 
    begin 
         
        /*        Recupere BECC        */ 
        select @becc = '' 
        select @countligne = 0 
        select @countligne = count(distinct BELLIENCODE) from FBEL where BELCODE=@becode and (@ent is null or BELENT=@ent) 
     
        if @countligne = 1 
            select @becc = isnull(BELLIENCODE,'') from FBEL where BELCODE=@becode and (@ent is null or BELENT=@ent) 
            group by BELCODE 
 
        if @debug = 1 
            select 'debug',"Recupere BECC : @nbfranco > 0 and @vprefbeport = 1",@becode,@becc,@nbfranco,@vprefbeport 
             
                         
        /***************************************************************************************************************/ 
        /************************** Les frais de port ne sont plus traites en allocation automatique *******************/ 
        /***************************************************************************************************************/ 
 
     
        /*        Il suffit que 1 seule commande ne soit pas franco pour appliquer les frais de Port    */ 
        if @nbfranco > 0 and @vprefbeport = 1 and @vprefbeport = 0 and @vprefbeport = 2 
        begin 
            select @clchoixport=0 
            select @clport=0 
     
            /*    Recherche des conditions de port de la fiche client    */         
            select @clchoixport=isnull(CLCHOIXPORT,0),@clport=isnull(CLPORT,0) from FCL where CLCODE=@belcl and (@ent is null or CLENT=@ent) 
     
            if @debug = 1 
                select 'debug',"@clchoixport <> 0",@clchoixport 
 
            if @clchoixport <> 0 
            begin 
             
                delete from #Liste_port_variable 
             
                if @clchoixport = 2 
                begin 
                    insert into #Liste_port_variable (CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE) 
                        select INFPIN_FO,INFPAR,INFPPOURCENTAGE from FINFP where INFPIN_CL=@becl and (@ent is null or INFPENT=@ent) 
                     
                    select @countligne = 0 
                    select @countligne = count(*) from #Liste_port_variable 
                    if @countligne = 0  
                        insert into #Liste_port_variable (CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE) values ('',@Pcodeport,@clport) 
                end     
             
                if @clchoixport = 1                                                        /*    F comme forfait    */ 
                    insert into #Liste_port_variable (CODEMARQUE,CODEARTICLE,POURCENTAGE_OU_FIXE) values ('$F$',@Pcodeport,case when @clport=0 then @Pforfait1 else @clport end) 
                 
                open LignePort 
                fetch LignePort into     @codemarque, @codearticle, @pourcentage_ou_fixe 
                     
                while (@@sqlstatus=0) 
                begin  
                     
                    select @belarticle = @codearticle 
                    select @beltypeve = '' 
                    select @beltypeve = ARTYPEVE from FAR where ARCODE = @belarticle 
                  
                    select @belprixht = 0 
                    select @belunitfact = 0 
                    select @beltype = 0 
                    select @beldemo = 0 
                    select @belliencode = '' 
                    select @belliennum = 0 
                    select @belechspe = 0 
                    select @belremise1 = 0 
                    select @belremise2 = 0 
                    select @belremise3 = 0 
                    select @belremise4 = 0 
                    select @belremise5 = 0 
                    select @belfactman = @bel_factman 
                    select @beloffert = 0 
                    select @belmotif = "" 
                    select @beldotation = 0 
                    select @belprixhtdev = 0 
                    select @belqte = 1 
                    select @belstade = 3 
                     
                    select @belnum = @bel_num + 1 
                    select @bel_num = @bel_num + 1 
                    select @belordre = @bel_ordre + 32 
                    select @bel_ordre = @bel_ordre + 32 
                     
                    select @bellettre = 'AAAB' 
                    select @belreste = @belqte 
                     
                    execute eq_GetSeq_proc 'FBEL',1,@i = @belseq output 
         
                    if @codemarque = '$F$' 
                        select @belprixht = @pourcentage_ou_fixe 
                    else 
                        select @belprixht = isnull(sum(BELTOTALHT)*@pourcentage_ou_fixe/100,0) from FBEL,FAR  
                        where ARCODE=BELARTICLE and BELCODE=@becode and (@ent is null or BELENT=@ent) and (@codemarque='' or ARFO=@codemarque) and isnull(ARTYPE,0)<=1 
                         
                    select @beltotalht = @belprixht 
         
                    If @beltotalht>0 
                    begin 
                        if @beldev <> @Pdevref 
                        begin 
                            execute Conversion_div_proc @belprixht,@Pcours,3,@mt = @vp3n1 output 
                            select @belprixhtdev = @vp3n1 * @becoursdev 
                            select @beltotalhtdev = @belprixhtdev 
                        end 
                        else 
                        begin 
                            select @belprixhtdev = @belprixht 
                            select @beltotalhtdev = @beltotalht 
                        end 
         
                        select @belent = @vgent 
                         
                        insert into FBEL (BELSEQ,BELCODE,BELARTICLE,BELQTE,BELDATE,BELPRIXHT,BELORDRE,BELUNITFACT,BELTYPEVE,BELTYPE,BELLIBRE,BELNUM,BELDEMO, 
                            BELLETTRE,BELRESTE,BELLIENCODE,BELLIENNUM,BELCL,BELTOTALHT,BELECHSPE,BELREMISE1,BELREMISE2,BELREMISE3,BELREMISE4,BELREMISE5, 
                            BELTYPEMV,BELUSERMDF,BELDATEMDF,BELUSERCRE,BELDATECRE,BELFACTMAN,BELOFFERT,BELMOTIF,BELDOTATION,BELDEV,BELCOURSDEV, 
                            BELPRIXHTDEV,BELTOTALHTDEV,BELSTADE,BELENT,BELATTACHE,BELEMP,BELMARCHE,BELCOLIS,BELPAHT) 
                        values     (@belseq,@belcode,@belarticle,@belqte,@beldate,@belprixht,@belordre,@belunitfact,@beltypeve,@beltype,@bellibre,@belnum,@beldemo, 
                            @bellettre,@belreste,@belliencode,@belliennum,@belcl,@beltotalht,@belechspe,@belremise1,@belremise2,@belremise3,@belremise4,@belremise5, 
                            @beltypemv,@belusermdf,@beldatemdf,@belusercre,@beldatecre,@belfactman,@beloffert,@belmotif,@beldotation,@beldev,@belcoursdev, 
                            @belprixhtdev,@beltotalhtdev,@belstade,@belent,null,@belemp,@belmarche,null,null) 
                    end  
                             
                    fetch LignePort into     @codemarque,@codearticle,@pourcentage_ou_fixe 
                end 
                close LignePort 
                         
            end        /* @clchoixport <> 0    */ 
     
            /*    Le franco apres premier BE=1 si il n y a pas de traitement ou si un forfait est applique    */ 
            if @clchoixport<2 and @Pfrancobe=1 
                    update FCC set CCFRANCOBE=1 where CCCODE=@numcde and (@ent is null or CCENT=@ent) 
     
        end        /*    @nbfranco > 0 and @vprefbeport = 1    */ 
         
                     
        /***************************************************************************************************************/ 
        /*********************  Fin de la partie port qui n est plus traitee en allocation automatique *****************/ 
        /***************************************************************************************************************/ 
         
         
        if @Pfrancobe=1 
                update FCC set CCFRANCOBE=1 where CCCODE=@numcde and (@ent is null or CCENT=@ent) 
     
         
     
        select @beechspe = min(BELECHSPE), @betotalht = sum(BELTOTALHT), @betotalhtdev = sum(BELTOTALHTDEV) from FBEL 
        where BELCODE=@becode and (@ent is null or BELENT=@ent) 
         
        select @beregle = 0 
        select @beregle = count(*) from FAR,FBEL where BELCODE=@becode and BELARTICLE=ARCODE and ARREGLE > 0 and (@ent is null or BELENT=@ent) 
     
        if @vgsite=6 
            select @bestade = @vastade 
             
        if @vgsite <> 6 
            select @bestade = 3 
     
        update FBE set     BEECHSPE=@beechspe, BETOTALHT=@betotalht, BETOTALHTDEV=@betotalhtdev, BEREGLE=@beregle, 
                        BEOBSERVATIONS=@beobservations, BECC=@becc, BESTADE=@bestade, BEESCOMPTE = @ccescompte 
        where BECODE=@becode and (@ent is null or BEENT=@ent) 
    end 
    select @saut_bloc = 0 
end 
 
 
/*    nombre de BE traites        */ 
if @result = 1 
    select @be_prepares ,"BON(S) D'EXPEDITIONS GENERE(S)" 
     
end 

go

