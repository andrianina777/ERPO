
create procedure NewFSTBL	(	@an_in		int,
								@mois_in	int,
								@frs_in		char(12) = null	
							)
as
begin

	declare	@fournis	char(12),
			@article	char(15),
			@an			int,
			@mois		int,
			@qte		int,
			@totht		numeric(14,2),
			@prht		numeric(14,2)
	
	delete from FSTBL
	  where STBLAN=@an_in and STBLMOIS=@mois_in
	  and (@frs_in is null or STBLFO=@frs_in) 
	
	declare pointeur cursor
	  for select BLLFO,BLLAR,
				 AN=datepart(yy,BLLDATE),MOIS=datepart(mm,BLLDATE),
				 BLLQTE,BLLTOTHT,TOTAL=round((BLLPRHT/CVLOT)*BLLQTE,2)
	  from FBLL,FAR,FCV
	  where ARCODE=BLLAR
	  and CVUNIF=ARUNITACHAT
	  and ARTYPE in (0,1)
	  and datepart(yy,BLLDATE)=@an_in and datepart(mm,BLLDATE)=@mois_in
	  and (@frs_in is null or BLLFO=@frs_in) 
	  and BLLQTE != 0
	  for read only
	
	open pointeur
	
	  fetch pointeur
	  into @fournis,@article,@an,@mois,@qte,@totht,@prht
	  
	  while (@@sqlstatus = 0)
		begin
		
			if exists (select * from FSTBL where STBLFO=@fournis and STBLART=@article and STBLAN=@an and STBLMOIS=@mois)
				update FSTBL
				set STBLQTE = STBLQTE + @qte,
					STBLPA = STBLPA + @totht,
					STBLPR = STBLPR + @prht
				where STBLFO=@fournis and STBLART=@article and STBLAN=@an and STBLMOIS=@mois
	
			else
				  insert into FSTBL(STBLFO,STBLART,STBLAN,STBLMOIS,STBLQTE,STBLPA,STBLPR)
				  values (@fournis,@article,@an,@mois,@qte,@totht,@prht)		
				
			fetch pointeur
				into @fournis,@article,@an,@mois,@qte,@totht,@prht
	  
		end
	
	  close pointeur
	  deallocate cursor pointeur
	  
	  
	  /*-         retour fournisseur        ------------------*/
	  
	  declare PointRetour cursor
	  for select RFLFO,RFLARTICLE,
				 AN=datepart(yy,RFLDATE),MOIS=datepart(mm,RFLDATE),
				 RFLQTE,RFLTOTALHT,TOTAL=round((RFLPAHT/CVLOT)*RFLQTE,2)
	  from FRFL,FAR,FCV
	  where ARCODE=RFLARTICLE
	  and CVUNIF=ARUNITACHAT
	  and ARTYPE in (0,1)
	  and datepart(yy,RFLDATE)=@an_in and datepart(mm,RFLDATE)=@mois_in
	  and (@frs_in is null or RFLFO=@frs_in) 
	  and RFLQTE != 0
	  for read only
	
		open PointRetour
	
	  fetch PointRetour
	  into @fournis,@article,@an,@mois,@qte,@totht,@prht
	  
	  while (@@sqlstatus = 0)
		begin
		
			if exists (select * from FSTBL where STBLFO=@fournis and STBLART=@article and STBLAN=@an and STBLMOIS=@mois)
				update FSTBL
				set STBLQTE = STBLQTE - @qte,
					STBLPA = STBLPA - @totht,
					STBLPR = STBLPR - @prht
				where STBLFO=@fournis and STBLART=@article and STBLAN=@an and STBLMOIS=@mois
	
			else
				  insert into FSTBL(STBLFO,STBLART,STBLAN,STBLMOIS,STBLQTE,STBLPA,STBLPR)
				  values (@fournis,@article,@an,@mois,@qte*-1,@totht*-1,@prht*-1)		
				
			fetch PointRetour
				into @fournis,@article,@an,@mois,@qte,@totht,@prht
	  
		end
	
	  close PointRetour
	  deallocate cursor PointRetour
		  
	  
end
go

