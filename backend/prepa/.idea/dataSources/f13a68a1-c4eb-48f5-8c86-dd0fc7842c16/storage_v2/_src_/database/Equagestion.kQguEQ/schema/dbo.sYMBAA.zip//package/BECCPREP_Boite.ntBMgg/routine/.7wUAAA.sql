/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.BECCPREP_Boite
grant execute on BECCPREP_Boite to public
*/

CREATE PROCEDURE dbo.BECCPREP_Boite(@cc varchar(10),@depot varchar(10))

AS
begin

        declare @nbligne int,@CCLARTICLE varchar(50),@QTE_A_PREPARER int,@CCLSEQ int,@CCLQTE int,@CCLQTE_APREPARER int,@rayon_fictif char(8)
        declare	
                @CCLCODE		char(10),
                @CCLNUM			int,
                @CCLDATE		date,
                @CCLRESTE		int,
                @ARLIB			varchar(80),
                @ARUNITFACT		tinyint,
                @PUHT			numeric(14,2),
                @MODELIV		char(2),
                @CCLLIBRE		varchar(255),
                @CCLTV			char(4),
                @ARREGLE		tinyint,
                @CCLECHSPE		tinyint,
                @CCLFACTMAN		tinyint,
                @CCLOFFERT		tinyint,
                @ARTYPE			tinyint,
                @CCLDEV			char(3),
                @CCLCOURSDEV	        numeric(16,10),
                @CCLPHTDEV		numeric(14,2),
                @CCLTOTALHTDEV	        numeric(14,2),
                @CCLR1			real,
                @CCLR2			real,
                @CCLR3			real,
                @CCLTOTALHT		numeric(14,2),
                @CCLQTERES		int,
                @CCLDATERESFIN	        smalldatetime,
                @CCLDEPOTRES	        char(4),
                @ARCOMP			tinyint,
                @CCLQTEPREP		int,
                @CCLATTACHE		char(10),
                @ARREFFOUR		char(20),
                @CCLMARCHE		char(12),
                @CCLCOLIS		numeric(14,2),
                @ARQTECOLIS		int,
                @CCLPAHT		numeric(14,2),
                @CCL_LIBSEQ             numeric(18,0),
                @CCL_COMMENT_MAG        varchar(255),
                @CCLCOLISAGE	        varchar(25) ,
                @CCLNBCOLIS		int,
                @CCLPACK		int
        
        create table #stockFinal(
                SEQ numeric identity,
                STEMPAR varchar(50) null,
                STEMPLETTRE varchar(10) null,
                QteLoc int null,
                STEMPDATE  date null,
                STEMPEMP varchar(10) null,
                STEMPLOT varchar(50) null,
                STEMPDEPOT varchar(10) null
        )
        create index stockFinal_idx0001 on #stockFinal(STEMPAR)
        create index stockFinal_idx0002 on #stockFinal(STEMPLETTRE)
        create index stockFinal_idx0003 on #stockFinal(STEMPDEPOT)
        create index stockFinal_idx0004 on #stockFinal(SEQ)

        create table #cclFinal(
                CCLSEQ numeric(14,0),
                CCLARTICLE varchar(50) null,
                CCLQTE int null,
                CCLQTE_APREPARER int null
        )
        
        create index cclFinal_idx0001 on #cclFinal(CCLSEQ)
        create index cclFinal_idx0002 on #cclFinal(CCLARTICLE)
        
        create table #Prep
        (
                CCLSEQ			numeric(14,0)   not null,
                CCLCODE			char(10)	not null,
                CCLNUM			int		null,
                CCLDATE			date	        null,
                CCLARTICLE		char(15)	not null,
                CCLRESTE		int		null,
                ARLIB			varchar(80)	null,
                ARUNITFACT		tinyint		null,
                CCLPHT			numeric(14,2)	null,
                MODELIV			char(2)		null,
                CCLLIBRE		varchar(255)	null,
                CCLTV			char(4)		null,
                ARREGLE			tinyint		null,
                CCLECHSPE		tinyint		null,
                CCLFACTMAN		tinyint		null,
                CCLOFFERT		tinyint		null,
                ARTYPE			tinyint		null,
                CCLDEV			char(3)		null,
                CCLCOURSDEV		numeric(16,10)	null,
                CCLPHTDEV		numeric(14,2)	null,
                CCLTOTALHTDEV	        numeric(14,2)	null,
                CCLR1			real		null,
                CCLR2			real		null,
                CCLR3			real		null,
                CCLTOTALHT		numeric(14,2)	null,
                CCLQTERES		int		null,
                CCLDATERESFIN	        smalldatetime	null,
                CCLDEPOTRES		char(4)		null,
                ARCOMP			tinyint		null,
                CCLQTEPREP		int		null,
                CCLATTACHE		char(10)	null,
                ARREFFOUR 		char(20)	null,
                CCLMARCHE		char(12)	null,
                CCLCOLIS		numeric(14,2)	null,
                ARQTECOLIS		int		null,
                CCLPAHT			numeric(14,2)	null,
                CCL_LIBSEQ              numeric(18,0)   null,
                CCL_COMMENT_MAG         varchar(255)	null,
                CCLCOLISAGE 	        varchar(25)     null,
                CCLNBCOLIS		int             null,
                CCLPACK			int             null,
                CCL_APREPARER           int             null
        )    

        create table #Liste
        (
                Article 		char(15)	not null,
                Lettre			char(4)		not null,
                Designation		char(80)	null,
                LienCode		char(10)	not null,
                LienNum			int		not null,
                Qte			int		null,
                UnitFact		tinyint		not null,
                PrixHT			numeric(14,2)	null,
                ModeLiv			char(2)		null,
                LigneLibre		varchar(255)	null,
                TypeVente		char(4)		not null,
                Reglement		tinyint		null,
                Echeancesp		tinyint		null,
                Factman			tinyint		null,
                Offert			tinyint		null,
                Artype			tinyint		null,
                Devise			char(3)		not null,
                Coursdev		numeric(16,10)	null,
                PrixHTdev		numeric(14,2)	null,
                TotHTdev		numeric(14,2)	null,
                Rem1			real		null,
                Rem2			real		null,
                Rem3	 		real		null,
                TotPrixHT		numeric(14,2)	null,
                Emplacement		char(8)		not null,
                Attachement		char(10)	null,
                Lot			char(12)	not null,
                Arreffour		char(20)	null,
                cclmarche		char(12)	null,
                ccldate			date  	        null,
                cclcolis		numeric(14,2)	null,
                arqtecolis		int		null,
                cclpaht			numeric(14,2)	null,
                seqLib                  numeric (18,0)  null,
                comment_mag		varchar(255)	null,
                cclcolisage		varchar(25)	null,
                cclnbcolis		int		null,
                cclpack			int		null,
                rayon			char(8) null
        )

        
        /*LIGNE COMMANDE*/
        select CCLSEQ, CCLCODE, CCLARTICLE, CCLQTE, CCLDATE, CCLR1, CCLR2, CCLR3, CCLR4, CCLR5, CCLPHT, CCLORDRE, CCLUNITFACT, CCLTV, CCLTYPE, CCLLIBRE, CCLNUM, CCLQTEEXP, CCLRESTE, CCLCL, CCLTOTALHT, CCLECHSPE, CCLTYPEMV, CCLDATEMDF, CCLUSERMDF, CCLFACTMAN, CCLOFFERT, CCLDATECRE, CCLUSERCRE, CCLDEV, CCLCOURSDEV, CCLPHTDEV, CCLTOTALHTDEV, CCLATTACHE, CCLENT, CCLQTERES, CCLDATERESFIN, CCLDEPOTRES, CCLREP, CCLREPDIV, CCLWEBCODE, CCLWEBNUM, CCLQTEPREP, CCLCF, CCLMARCHE, CCLFACT, CCLLOT, CCLFRAIS, CCLCOLIS, CCLPAHT, CCLDATEINIT, CCLTOTALHTORG, CCLNUMARM1, CCL_LIBSEQ, CCLATTETRANSFERT, CCL_COMMENT_MAG, CCLCOLISAGE, CCLNBCOLIS, CCLPACK 
        into #FCCL
        from FCCL
        where CCLCODE=@cc
        and (isnull(CCLRESTE,0)-isnull(CCLQTEPREP,0))>0
        
        create index FCCL_idx0001 on #FCCL(CCLARTICLE)

        select CCLCODE,CCLARTICLE,sum(CCLQTE) as QTE_CDE,sum(CCLRESTE-(isnull(CCLQTEPREP,0))) as QTE_A_PREPARER,isnull(ARFRANCOFO,0) as COLISAGE,(case when (isnull(ARFRANCOFO,0)<>0) then (sum(CCLRESTE-(isnull(CCLQTEPREP,0))))/isnull(ARFRANCOFO,0)  else 0 end * isnull(ARFRANCOFO,0)) as QTE_PREPARER_COLIS,ARTYPE
        into #FCCL_GROUPE
        from #FCCL,VIEW_FAR
        where ARCODE=CCLARTICLE
        group by CCLCODE,CCLARTICLE,isnull(ARFRANCOFO,0),ARTYPE
        
        delete from #FCCL_GROUPE where QTE_A_PREPARER<=0
        
        
        create index FCCL_GROUPE_idx0001 on #FCCL_GROUPE(CCLARTICLE)
        create index FCCL_GROUPE_idx0002 on #FCCL_GROUPE(QTE_PREPARER_COLIS)
        create index FCCL_GROUPE_idx0003 on #FCCL_GROUPE(QTE_A_PREPARER)
        
        /*VIEW_STOCK_LOT_EMPLACEMENT*/        
        select STEMPID, STEMPAR, STEMPDEPOT, STEMPEMP, STLOT, NLOTDATEPER, xDPVTE, xDPCENTRAL, STFO, STDATEENTR, STLETTRE, STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS, ARLIB, ARQTEPALETTE, ARFO, ARREFFOUR, ARPRM, ARUNITACHAT, ARNUMEROTE, ARFRANCOFO, STEMPQTE, VALEUR, ARESSEMP, ST_UG, ARPVHT, xARTP_STATSPEC 
        into #VIEW_STOCK_LOT_EMPLACEMENT
        from VIEW_STOCK_LOT_EMPLACEMENT,#FCCL_GROUPE
        where STEMPDEPOT=@depot
        and STEMPAR=CCLARTICLE
        
        create index STOCK_idx0001 on #VIEW_STOCK_LOT_EMPLACEMENT(STEMPAR)
        create index STOCK_idx0002 on #VIEW_STOCK_LOT_EMPLACEMENT(STEMPDEPOT)
        create index STOCK_idx0003 on #VIEW_STOCK_LOT_EMPLACEMENT(STLETTRE)

        select @nbligne=0
        select @nbligne=count(*) from #FCCL_GROUPE
        if (@nbligne>0)
        begin
                /*reservation commmande*/
                select  RCCARTICLE,sum(RCCQTE) as RCCQTE 
                into #FRCC
                from VIEW_FRCC_BLOQUE,#FCCL_GROUPE
                where RCCARTICLE=CCLARTICLE
                and isnull(RCCDEPOTRES,'')=@depot
                group by RCCARTICLE
                
                create index FRCC_idx0001 on #FRCC(RCCARTICLE)

                /*ligne de stock*/
                select STAR, STLETTRE, STQTE,STDEPOT,isnull(ST_QTE_RSRV,0) as ST_QTE_RSRV,STLOT,STQTE- isnull(ST_QTE_RSRV,0) as STOCK_DISPO
                into #STOCK
                from VIEW_FSTOCK,#FCCL_GROUPE                
                where STDEPOT=@depot
                and STAR =CCLARTICLE
                

                create index stock_idx0001 on #STOCK(STAR)
                create index stock_idx0002 on #STOCK(STLETTRE)
                create index stock_idx0003 on #STOCK(STDEPOT)
                

                /*stock general depot*/
                select STAR,sum(STOCK_DISPO)as STOCK_DISPO,STDEPOT,convert(int,null) as STOCK_AVEC_EMP, convert(int,null) as STOCK_PORTE
                into #STOCKTOTAL
                from #STOCK
                group by STAR,STDEPOT
                
                /*ARTICLE DEJA DANS UNE PORTE*/
                /* SELECT DISTINCT PORTE FROM xCorrespRAYON_DIGUE*/
                select STEMPAR,
                sum( case when (STEMPEMP in (select xEMPL from xEMP_DIGUEL where xDEPOTL=@depot)) then STEMPQTE else 0 end ) as STOCK_AVEC_EMP,
                sum(case when (STEMPEMP in (SELECT DISTINCT PORTE FROM xCorrespRAYON_DIGUE)) then STEMPQTE else 0 end) as STOCK_PORTE
                into #STOCK_PORTE
                from VIEW_FSTEMP,#FCCL_GROUPE
                where STEMPDEPOT=@depot
                and STEMPAR=CCLARTICLE  
                group by STEMPAR              
                 
                create index stockTotal_idx0001 on #STOCKTOTAL(STAR)
                
                update #STOCKTOTAL set STOCK_DISPO=STOCK_DISPO-RCCQTE
                from #STOCKTOTAL,#FRCC
                where RCCARTICLE=STAR
                
                update #STOCKTOTAL set STOCK_DISPO=STOCK_DISPO-#STOCK_PORTE.STOCK_PORTE,STOCK_AVEC_EMP=#STOCK_PORTE.STOCK_AVEC_EMP,STOCK_PORTE=#STOCK_PORTE.STOCK_PORTE
                from #STOCKTOTAL,#STOCK_PORTE
                where STAR=STEMPAR
                
                
 
                select CCLCODE, CCLARTICLE, QTE_CDE,   QTE_A_PREPARER, COLISAGE, isnull(STOCK_DISPO,0) as STOCK_DISPO,ARTYPE,
                (case when CCLARTICLE='FRAISDIV' and @depot in ('GROS','DET') then @depot else STDEPOT end) as STDEPOT,STOCK_PORTE as STOCK_PORTE
                into #resultat
                from #FCCL_GROUPE,#STOCKTOTAL
                where CCLARTICLE*=STAR and   STDEPOT=@depot
                
                delete from #resultat where   QTE_A_PREPARER<=0 

 
                select CCLCODE, CCLARTICLE, QTE_CDE,  QTE_A_PREPARER, STOCK_DISPO,ARTYPE ,
                case when (STOCK_PORTE>0 and QTE_A_PREPARER-STOCK_DISPO>0 and STOCK_PORTE>=QTE_A_PREPARER-STOCK_DISPO) then 'Porte ('||convert(varchar,QTE_A_PREPARER-STOCK_DISPO)||')'
                     when (isnull(STOCK_PORTE,0)=0 and QTE_A_PREPARER-STOCK_DISPO>0) then
                'Transfert ('||convert(varchar,QTE_A_PREPARER-STOCK_DISPO)||')' 
                else '' end  as TRANSFERT,STOCK_PORTE
                into #attenteTransfert
                from #resultat
                where QTE_A_PREPARER>STOCK_DISPO
                and ARTYPE=0   
                
                 
                /*ARTICLE STOCKE*/
                select STEMPAR,STLETTRE ,sum(STEMPQTE) as STEMPQTE,convert (date,NLOTDATEPER) as NLOTDATEPER ,STEMPEMP,STLOT ,STEMPDEPOT,ARESSEMP
                into #StockTmp1
                from #VIEW_STOCK_LOT_EMPLACEMENT
                where STEMPDEPOT=@depot
                group by STEMPAR,NLOTDATEPER,STLETTRE,STEMPEMP,STLOT,STEMPDEPOT,ARESSEMP
                order by STEMPAR,NLOTDATEPER,STLETTRE,STEMPEMP,STLOT,STEMPDEPOT,ARESSEMP
                
                create index StockTmp1_idx0001 on #StockTmp1(STEMPAR)
                create index StockTmp1_idx0002 on #StockTmp1(STEMPDEPOT)
                create index StockTmp1_idx0003 on #StockTmp1(STLETTRE)
                
                /*SUPPRIMER LES LIRGNES DE STOCK PORTE*/
                delete from #StockTmp1 where  STEMPEMP in (SELECT DISTINCT PORTE FROM xCorrespRAYON_DIGUE where DEPOT='DET')
                
                /*SUPPRIMER LES LIGNE STOCK SANS EMPL*/
                --select STEMPAR, ARLIB, STEMPDEPOT, STEMPEMP, ARESSEMP, STEMPQTE from VIEW_SANS_EMPL
               delete from #StockTmp1 where  STEMPEMP in (select distinct ARESSEMP from VIEW_SANS_EMPL)

                /*PREPARATION ENCOURS*/
                select RBPARTICLE,RBPDEPOT,RBPLETTRE,RBPEMP,sum(RBPQTE) as RBPQTE
                into #FRBP
                from FRBP,#resultat
                where RBPARTICLE=CCLARTICLE and STDEPOT=RBPDEPOT
                and RBPDEPOT=@depot
                group by RBPARTICLE,RBPDEPOT,RBPLETTRE,RBPEMP
                
                create index FRBP_idx0001 on #FRBP(RBPARTICLE)
                create index FRBP_idx0002 on #FRBP(RBPDEPOT)
                create index FRBP_idx0003 on #FRBP(RBPLETTRE)
                create index FRBP_idx0004 on #FRBP(RBPEMP)

                /*supprimer les resrvation FRBP*/
                 update #StockTmp1 set STEMPQTE=STEMPQTE-RBPQTE
                 from #StockTmp1,#FRBP
                 where STEMPAR=RBPARTICLE
                 and STEMPDEPOT=RBPDEPOT
                 and STLETTRE=RBPLETTRE
                 and STEMPEMP=RBPEMP
                 
                 
                 /*supprimer les ligne de stock avec qte<=0 suite à des diverse reservation*/
                delete from #StockTmp1 where STEMPQTE<=0                
                 
               /*Nettoyer le stock par emplacement avec les reservation en ligne de stock FSTOCK*/
                declare 	@qteST 			int,
                                @articleST 		char(15),
                                @lettreST 		char(4),
                                @qtealivrer		int,
                                @emplacement	char(8),
                                @lot			char(12),
                                @dep			char(4),
                                @seq			numeric(14,0),
                                @resteapreparer	int,
                                @stockRSRV_FSTOCK int,@datePer datetime,
                                @stocktotal int
                        
                
                declare stockTmp cursor for select STEMPAR,STLETTRE,STEMPQTE,NLOTDATEPER,STEMPEMP,STLOT,STEMPDEPOT from #StockTmp1 --order by SEQ 
                open stockTmp
                fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@dep
                while (@@sqlstatus=0)
                begin
                        select @stockRSRV_FSTOCK=0
                        select @stockRSRV_FSTOCK=isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #STOCK  where STAR=@articleST and STDEPOT=@depot and STLETTRE= @lettreST
                        select @qteST=@qteST-@stockRSRV_FSTOCK
                        
                        insert into #stockFinal(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT) values (@articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot)
                        
                        fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@dep
                end
                close stockTmp
                deallocate cursor stockTmp
                        
                delete from #stockFinal where QteLoc<=0

                /*parcour ce resultat pour constituer les ligne CCL a preparer selon FCCL*/
                declare liste cursor for select CCLARTICLE,QTE_A_PREPARER from #resultat where STOCK_DISPO>=QTE_A_PREPARER and ARTYPE=0
                open liste
                fetch liste into @CCLARTICLE,@QTE_A_PREPARER
                while (@@sqlstatus=0)
                begin
                        /*parcour #FCCL pour cet article et cette QTE*/
                        declare ligneCommande cursor for select CCLSEQ,CCLQTE-CCLQTEPREP from #FCCL where CCLARTICLE=@CCLARTICLE order by CCLQTE desc 
                        open ligneCommande
                        fetch ligneCommande into @CCLSEQ,@CCLQTE
                        while (@@sqlstatus=0)
                        begin
                                if(@QTE_A_PREPARER>=@CCLQTE)
                                begin
                                        select @CCLQTE_APREPARER=@CCLQTE
                                end
                                else
                                begin
                                        select @CCLQTE_APREPARER=@QTE_A_PREPARER
                                end

                                insert into #cclFinal values (@CCLSEQ,@CCLARTICLE,@CCLQTE,@CCLQTE_APREPARER)
                                select @QTE_A_PREPARER=@QTE_A_PREPARER-@CCLQTE
                                
                                if (@QTE_A_PREPARER<=0)
                                begin
                                        break
                                end
                                
                                fetch ligneCommande into @CCLSEQ,@CCLQTE
                        end
                        close ligneCommande 
                        deallocate cursor ligneCommande
                        
                        fetch liste into @CCLARTICLE,@QTE_A_PREPARER
                end
                close liste 
                deallocate cursor liste

              /*inserer les article non stocké dans la liste cclfinal pour pdepot non colis*/

                /*ARTICLE NON STOCKE*/
                insert into #stockFinal(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
                select STEMPAR,STEMPLETTRE,STEMPQTE,null,STEMPEMP,'',STEMPDEPOT
                from FSTEMP
                where STEMPAR in (select CCLARTICLE from #resultat where ARTYPE<>0)
                and STEMPDEPOT= @depot
                
                insert into #cclFinal 
                select CCLSEQ,CCLARTICLE,CCLQTE,CCLQTE 
                from #FCCL
                where CCLARTICLE in (select CCLARTICLE from #resultat where ARTYPE<>0)                        
                      
                insert into #Prep
                select #cclFinal.CCLSEQ,CCLCODE,CCLNUM,CCLDATE,#cclFinal.CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
                        substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
                        ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
                        isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
                        isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,''),isnull(CCLCOLISAGE,''),isnull(CCLNBCOLIS,0),isnull(CCLPACK,0),
                        CCLQTE_APREPARER
                from #cclFinal,#FCCL,VIEW_FAR,FCC
                where #cclFinal.CCLSEQ=#FCCL.CCLSEQ
                and ARCODE=#cclFinal.CCLARTICLE
                and CCLCODE=CCCODE                      

                declare commandes cursor for
                        select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCL_APREPARER,ARLIB,
                        ARUNITFACT,CCLPHT,MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,CCLOFFERT,
                        ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
                        CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,ARCOMP,CCLQTEPREP,CCLATTACHE,ARREFFOUR,CCLMARCHE,CCLCOLIS,ARQTECOLIS,CCLPAHT,CCL_LIBSEQ,CCL_COMMENT_MAG,CCLCOLISAGE,CCLNBCOLIS,CCLPACK
                        from #Prep
                        order by CCLDATE,CCLSEQ
                        for read only
                
                open commandes
                fetch commandes
                into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
                        @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
                        @CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV ,
                        @CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
                        @CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK

                while (@@sqlstatus = 0)
                begin
                        
                                        select @resteapreparer = @CCLRESTE--@CCLQTEPREP
                                        select @stocktotal= isnull(sum(QteLoc),0) from #stockFinal where STEMPAR=@CCLARTICLE 
                                
                                        /*stocker dans une table tmp le stock*/
                                        select STEMPAR, STEMPLETTRE, QteLoc, STEMPDATE, STEMPEMP, STEMPLOT, STEMPDEPOT, SEQ  
                                        into #stockTmp
                                        from #stockFinal 
                                        
                                        create index stockTmp_idx0001 on #stockTmp(STEMPAR)
                                        create index stockTmp_idx0002 on #stockTmp(SEQ)
                
                                        /*parcoourir la ligne de stock*/
                                        declare ligneStock cursor for select STEMPAR,STEMPLETTRE,QteLoc,STEMPEMP,STEMPLOT,STEMPDEPOT,SEQ from #stockTmp where STEMPAR=@CCLARTICLE  order by SEQ
                                        open ligneStock
                                        fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                                        while (@@sqlstatus=0)
                                        begin
                                                if(@ARTYPE<>0)
                                                begin
                                                        select @qtealivrer=@resteapreparer
                                                        select @resteapreparer=0
                                                end
                                                else
                                                begin
                                                        if(@qteST>=@resteapreparer)/*QTE ligne de stock peut honorer la quantité a preparer*/
                                                        begin
                                                                select @qtealivrer=@resteapreparer
                                                                update #stockFinal set QteLoc=QteLoc-@qtealivrer where SEQ = @seq
                                                                select @resteapreparer=0
                                                        end
                                                        else 
                                                        begin
                                                                select @qtealivrer=@qteST/*quantité a lvrer = qte en stock*/
                                                                update #stockFinal set QteLoc=0 where SEQ = @seq
                                                                select @resteapreparer= @resteapreparer-@qtealivrer
                        
                                                        end
                                                  end      
                                                  
                                                  		--select @rayon_fictif=rtrim(RAYON) from xCorrespRAYON_DIGUE inner join xEMP_DIGUEL on (xALLEL=ALLEE  and xDEPOTL=DEPOT) where xARTICLE=@articleST and xDEPOTL=@depot and xEMPL=@emplacement

                                                                select @rayon_fictif=rtrim(RAYON) from xCorrespRAYON_DIGUE,xEMP_DIGUEL 
                                                                where xDEPOTL=DEPOT and ALLEE=xALLEL and xEMPL=@emplacement and xDEPOTL=@depot
                                                     		
                                                        
                                                        insert into #Liste (Article,Lettre,Designation,LienCode,LienNum,Qte,
                                                                                                  UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,
                                                                                                  Reglement,Echeancesp,Factman,Offert,Artype,
                                                                                                  Devise,Coursdev,PrixHTdev,TotHTdev,Rem1,Rem2,Rem3,
                                                                                                  TotPrixHT,Emplacement,Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,seqLib,comment_mag,cclcolisage,cclnbcolis,cclpack,rayon)
                                                        select @articleST,@lettreST,@ARLIB,@CCLCODE,@CCLNUM,@qtealivrer,
                                                                                                  @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,
                                                                                                  @CCLTV,@ARREGLE,@CCLECHSPE,@CCLFACTMAN,@CCLOFFERT,@ARTYPE,
                                                                                                  @CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,@CCLR1,@CCLR2,@CCLR3,
                                                                                                  @CCLTOTALHT,@emplacement,@CCLATTACHE,@lot,@ARREFFOUR,@CCLMARCHE,@CCLDATE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK,@rayon_fictif
                                                
                                                if @resteapreparer<=0 break
                                                
                                                fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                                        end
                                        close ligneStock
                                        deallocate cursor ligneStock
                                    
                        
                        /*FIN NEW*/     --delete from #Stock where SEQ=@seq
                                        drop table #stockTmp
                
                        fetch commandes
                        into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
                        @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
                        @CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
                        @CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
                        @CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK
                end
                
                close commandes
                deallocate cursor commandes

                delete from #Liste
                where Artype=4
                and not exists (select * from #Liste as b where #Liste.LienCode=b.LienCode and b.Artype <> 4)
                and not exists (select * from FCCL,FAR where CCLCODE=#Liste.LienCode and ARCODE=CCLARTICLE and CCLRESTE > 0 and (ARNUMEROTE=1 or ARCOMP=2))



                /*TOTAL ARTICLE AA PREPARER*/
                select #resultat.CCLCODE, #resultat.CCLARTICLE,ARLIB, #resultat.QTE_CDE,  #resultat.QTE_A_PREPARER, #resultat.COLISAGE, #resultat.STOCK_DISPO ,isnull(TRANSFERT,'') as TRANSFERT,case when (isnull(TRANSFERT,'')='') then 1 else 0 end
                from #resultat,#attenteTransfert,VIEW_FAR
                where #resultat.CCLARTICLE*=#attenteTransfert.CCLARTICLE
                and ARCODE=#resultat.CCLARTICLE 
		--and STDEPOT=@depot
                

                /*LISTE PREPARATION*/
                select Article,Lettre,rtrim(Designation) as Designation,LienCode,LienNum,Qte,
                           UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,Reglement,
                           Echeancesp,abs(Qte),Factman,isnull(Offert,0),isnull(Artype,0),
                           isnull(Devise,''),isnull(Coursdev,0),isnull(PrixHTdev,0),
                           isnull(TotHTdev,0),Rem1,Rem2,Rem3,TotPrixHT,Emplacement,
                           Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,'',0,0,0,0,0,0,'','','',0,'','',0,'','','',0,0,0,seqLib,comment_mag,cclcolisage,cclnbcolis,cclpack,rayon
                from #Liste
                where Qte > 0
                order by LienCode,LienNum


                /*pour les articles qui n ont pas d emplacement*/
                select   CCLARTICLE, VIEW_SANS_EMPL.ARLIB, STEMPDEPOT,STEMPEMP,ARESSEMP
                from #cclFinal,VIEW_SANS_EMPL,VIEW_FAR
                where STEMPAR=CCLARTICLE 
                and STEMPDEPOT=@depot 
                and CCLARTICLE=ARCODE
                and ARTYPE=0
                and CCLARTICLE not in (select distinct Article from #Liste)
                
                /*select  distinct CCLARTICLE, VIEW_SANS_EMPL.ARLIB, STEMPDEPOT,STEMPEMP,ARESSEMP,RAYON
                from #cclFinal,VIEW_SANS_EMPL,VIEW_FAR,xCorrespRAYON_DIGUE
                where STEMPAR=CCLARTICLE 
                and PORTE=STEMPEMP
                and DEPOT = STEMPDEPOT
                and STEMPDEPOT=@depot 
                and CCLARTICLE=ARCODE
                and ARTYPE=0
                */
               select distinct rayon,1 from #Liste
               
                drop table #FRCC
                drop table #STOCK
                drop table #STOCKTOTAL
                drop table #attenteTransfert
                drop table #FRBP
                drop table #StockTmp1
                drop table #cclFinal
                drop table #STOCK_PORTE                
        end


        drop table #FCCL
        drop table #FCCL_GROUPE
        drop table #VIEW_STOCK_LOT_EMPLACEMENT

end
go

