


create procedure Echeances_dues (	@ent	char(5) = null,
									@client char(12) = null)
with recompile
as
begin

if (@client is null)
begin
  select Mode_Reglement=MRLIB, Num_fact=FACODE, Date_fact=FADATE, Echeance=FATRDATE1, Num_Comptable_livre=a.CLNUMCOMPTABLE,
  		 Nom_Client=a.CLNOM1,Reglement=sum(FAREGL1),Client_facture=FACLFACT,Nom_Client_fact=b.CLNOM1, Num_Comptable_fact=b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR1
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE1, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  union
  select MRLIB, FACODE, FADATE, FATRDATE2, a.CLNUMCOMPTABLE, a.CLNOM1, sum(FAREGL2), FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR2
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and FATR2<>""
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE2, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  union
  select MRLIB, FACODE, FADATE, FATRDATE3, a.CLNUMCOMPTABLE, a.CLNOM1, sum(FAREGL3), FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR3
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and FATR3<>""
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE3, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  union
  select MRLIB, FACODE, FADATE, FATRDATE4, a.CLNUMCOMPTABLE, a.CLNOM1, sum(FAREGL4), FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR4
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and FATR4<>""
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE4, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  order by MRLIB, FATRDATE1, FACODE
end
else if (@client is not null)
begin
  select Mode_Reglement=MRLIB, Num_fact=FACODE, Date_fact=FADATE, Echeance=FATRDATE1, Num_Comptable_livre=a.CLNUMCOMPTABLE,
  		 Nom_Client=a.CLNOM1,Reglement=sum(FAREGL1),Client_facture=FACLFACT,Nom_Client_fact=b.CLNOM1, Num_Comptable_fact=b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where FACL=@client
  and a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR1
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE1, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  union
  select MRLIB, FACODE, FADATE, FATRDATE2, a.CLNUMCOMPTABLE, a.CLNOM1, sum(FAREGL2), FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where FACL=@client
  and a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR2
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and FATR2<>""
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE2, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  union
  select MRLIB, FACODE, FADATE, FATRDATE3, a.CLNUMCOMPTABLE, a.CLNOM1, sum(FAREGL3), FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where FACL=@client
  and a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR3
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and FATR3<>""
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE3, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  union
  select MRLIB, FACODE, FADATE, FATRDATE4, a.CLNUMCOMPTABLE, a.CLNOM1, sum(FAREGL4), FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  from FFA,FCL a,FCL b,FMR,FTR
  where FACL=@client
  and a.CLCODE=FACL
  and b.CLCODE=FACLFACT
  and TRCODE=FATR4
  and MRCODE=TRMODE
  and isnull(FACOMPTA,0) = 0
  and FATR4<>""
  and (@ent is null or(FAENT=@ent and a.CLENT=@ent))
  group by MRLIB, FACODE, FADATE, FATRDATE4, a.CLNUMCOMPTABLE, a.CLNOM1, FACLFACT, b.CLNOM1, b.CLNUMCOMPTABLE
  order by MRLIB, FATRDATE1, FACODE
end

end



go

