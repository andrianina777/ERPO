

create procedure FactSpe   (@ent			char(5) = null,
							@FromClient 	char(12) = null,
							@ToClient 		char(12) = null,
						  	@FromDate 		smalldatetime = null,
							@ToDate 		smalldatetime = null,
							@modefact		tinyint		  = 0,		/* 0 = tous les BE, 1 = par BE, 2 = par cdes, 3 = par cdes completes */
							@periode		tinyint		  = 0,
							@codebe			char(10)	  = null,
							@codebefin		char(10)	  = null,
							@PrefEscompte	tinyint	= 0	/* 1 = traitement escompte depuis BE */
						   )
with recompile
as
begin

if @ToClient is null
select @ToClient=@FromClient

if @ToDate is null
select @ToDate=@FromDate

if @codebefin is null
select @codebefin=@codebe

declare @saisondeb		char(5),
		@saisonfin		char(5),
		@datesaisondeb	datetime,
		@datesaisonfin	datetime
		
select @saisondeb=PSAISONDEB,@saisonfin=PSAISONFIN from KParam
where (@ent is null or PENT=@ent)

set dateformat dmy
select @datesaisondeb=convert(datetime,@saisondeb+"/"+convert(varchar(4),datepart(yy,getdate())))
select @datesaisonfin=convert(datetime,@saisonfin+"/"+convert(varchar(4),datepart(yy,getdate())))
set dateformat mdy


if @modefact in (0,1,2)
begin
  select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
   BELREMISE1,BELREMISE2,BELREMISE3,
   BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1=isnull(BEADR1,""),BEADR2=isnull(BEADR2,""),BECP=isnull(BECP,""),
   BELLIENNUM,ARTYPE,BELOFFERT=isnull(BELOFFERT,0),BELMARCHE=isnull(BELMARCHE,""),
   BENOM2=isnull(BENOM2,""),BEPRENOM=isnull(BEPRENOM,""),
   BEESCOMPTE=( case when @PrefEscompte=1 then isnull(BEESCOMPTE,0) else isnull(CLESCOMPTE,0) end ),
   BELCOLIS=isnull(BELCOLIS,0)
  into #BE
  from FBEL,FRBE,FCL,FBE,FAR
   where BELSEQ=RBESEQ
   and RBECL=CLCODE
   and CLMODEFACT = @modefact
   and RBEARTICLE!=''
   and ARCODE=RBEARTICLE
   and RBEFACTMAN=0
   and RBEDEMO=0
   and RBESTADE in (2,3)
   and BECODE=BELCODE
   and (@codebe is null or BELCODE between @codebe and @codebefin)
   and RBEECH=1 and RBEDATE >= @datesaisondeb and RBEDATE <= @datesaisonfin
   and (@FromClient is null or RBECL between @FromClient and @ToClient)
   and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
   and isnull(BELTYPEVE,'')!=''
   and BELQTE>=0
   and (@ent is null or (BELENT=@ent and RBEENT=@ent and BEENT=@ent))
   and CLFACTPERIODE = @periode
end
else if @modefact = 3
begin
    select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
     BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1=isnull(BEADR1,""),BEADR2=isnull(BEADR2,""),BECP=isnull(BECP,""),
	 BELLIENNUM,ARTYPE,BELOFFERT=isnull(BELOFFERT,0),BELMARCHE=isnull(BELMARCHE,""),
	 BENOM2=isnull(BENOM2,""),BEPRENOM=isnull(BEPRENOM,""),
     BEESCOMPTE=( case when @PrefEscompte=1 then isnull(BEESCOMPTE,0) else isnull(CLESCOMPTE,0) end ),
     BELCOLIS=isnull(BELCOLIS,0)
	into #Bel
	from FBEL,FRBE,FAR,FBE,FCL
	 where BELSEQ=RBESEQ
	 and RBECL=CLCODE
     and CLMODEFACT = @modefact
	 and RBEARTICLE!=''
	 and ARCODE=RBEARTICLE
	 and RBEFACTMAN=0
	 and RBEDEMO=0
	 and RBESTADE in (2,3)
   	 and (@FromClient is null or RBECL between @FromClient and @ToClient)
     and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
	 and RBEECH=1 and RBEDATE >= @datesaisondeb and RBEDATE <= @datesaisonfin
	 and isnull(BELTYPEVE,'')!=''
	 and BELQTE>=0
	 and BELLIENCODE like "CC%"
	 and BECODE=BELCODE
     and (@codebe is null or BELCODE between @codebe and @codebefin)
	 and (@ent is null or (BELENT=@ent and RBEENT=@ent))
     and CLFACTPERIODE = @periode

	select distinct incomplet=BELLIENCODE
	into #Inc
	from #Bel,FCCL,FRCC
	where RCCSEQ=CCLSEQ
	and BELLIENCODE=CCLCODE
	and (@ent is null or (CCLENT=@ent and RCCENT=@ent))
	
	
	delete #Bel
	from #Inc
	where incomplet=BELLIENCODE
	
	drop table #Inc
end


if @modefact = 0
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,"",BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS
	from #BE
	order by BELCL,BELDEV,BEADR1,BEADR2,BECP,BEESCOMPTE,BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 1
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,"",BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS
	from #BE
	order by BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 2
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,"",BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS
	from #BE
	where (ARTYPE not in (3,7) or BELLIENCODE like "CC%")
	order by BEADR1,BEADR2,BECP,BELDEV,BEESCOMPTE,BELLIENCODE,BELLIENNUM,BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 3
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,"",BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS
	from #Bel
	where (ARTYPE not in (3,7) or BELLIENCODE like "CC%")
	order by BEADR1,BEADR2,BECP,BELLIENCODE,BELLIENNUM,BELDEV,BEESCOMPTE
	
	drop table #Bel
end



end
go

