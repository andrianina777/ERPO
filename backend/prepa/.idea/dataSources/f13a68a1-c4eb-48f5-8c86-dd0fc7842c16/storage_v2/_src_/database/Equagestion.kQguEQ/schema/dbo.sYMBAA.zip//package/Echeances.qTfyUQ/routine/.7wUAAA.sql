


create procedure Echeances (@ent	char(5)		= null,
							@Mois	tinyint		= null,
							@An		smallint	= null)
with recompile
as
begin


if ((@Mois<1) or (@Mois>12))
select @Mois=null

if (@Mois is null)
select @An=null

if ((@Mois is not null) and (@An is null))
select @An=datepart(yy,getdate())


select Client=FACLFACT,Facture=FACODE,
Echeance=FATRDATE1,Montant=FAREGL1
into #FA
from FFA
where (@Mois is null or datepart(mm,FADATE)=@Mois)
and (@An is null or datepart(yy,FADATE)=@An)
and (@ent is null or FAENT=@ent)

union

select FACLFACT,FACODE,
FATRDATE2,FAREGL2
from FFA
where (FATRDATE2 is not null or FAREGL2!=0.00)
and (@Mois is null or datepart(mm,FADATE)=@Mois)
and (@An is null or datepart(yy,FADATE)=@An)
and (@ent is null or FAENT=@ent)

union

select FACLFACT,FACODE,
FATRDATE3,FAREGL3
from FFA
where (FATRDATE3 is not null or FAREGL3!=0.00)
and (@Mois is null or datepart(mm,FADATE)=@Mois)
and (@An is null or datepart(yy,FADATE)=@An)
and (@ent is null or FAENT=@ent)

union

select FACLFACT,FACODE,
FATRDATE3,FAREGL4
from FFA
where (FATRDATE4 is not null or FAREGL4!=0.00)
and (@Mois is null or datepart(mm,FADATE)=@Mois)
and (@An is null or datepart(yy,FADATE)=@An)
and (@ent is null or FAENT=@ent)


order by FACLFACT,FACODE,FATRDATE1

select 'Num Comptable','Code Client','Nom','NÃÂ° Facture','Date Echeance','Montant TTC','Regle par cheque'

select CLNUMCOMPTABLE,Client,CLNOM1,Facture,Echeance,Montant
from #FA,FCL
where CLCODE=Client
and (@ent is null or CLENT=@ent)

drop table #FA

end



go

