


create procedure Maj_MirroringAr(@ar	char(15)	=null)
as
begin

	if @ar is null select @ar=""

	/* Reorganisation des sequentiels geres par sybase */
	/* *********************************************** */

	if @ar=""
	begin

		/* Mise Ã¢?Â¡ jour des sequentiels de la tables FTF sur la base maitre */
		create table #ftf (TFCODE	char(8) not null,TFENT char(5) null,seq numeric(7) identity)
	      insert into #ftf (TFCODE,TFENT) select TFCODE, TFENT from FTF
		set identity_update FTF on
		update FTF set TFSEQ=seq from #ftf where FTF.TFCODE=#ftf.TFCODE and FTF.TFENT=#ftf.TFENT
		select "Mise a jour sequentiels FTF :",@@rowcount
		drop table #ftf
		set identity_update FTF off

		/* Mise Ã¢?Â¡ jour des sequentiels de la tables FTFL sur la base maitre  */
		create table #ftfl (TFLCODE	char(8) not null,TFLENT char(5) null,TFLDATE datetime not null,seq numeric(7) identity)
		insert into #ftfl (TFLCODE, TFLDATE, TFLENT ) select  TFLCODE, TFLDATE, TFLENT from FTFL
		set identity_update FTFL on
		update FTFL set TFLSEQ=seq from #ftfl where FTFL.TFLCODE=#ftfl.TFLCODE and FTFL.TFLCODE=#ftfl.TFLCODE and FTFL.TFLDATE=#ftfl.TFLDATE and   FTFL.TFLENT=#ftfl.TFLENT
		select "Mise a jour sequentiels FTFL :",@@rowcount
		drop table #ftfl
		set identity_update FTFL off

		/* Mise Ã¢?Â¡ jour des sequentiels de la tables FART sur la base maitre  */
		create table #fart (ARTAR	char(15) not null,ARTTARIF char(8) not null,ARTENT char(5) null, ARTDATE datetime not null, ARTDEV char(3) not null, ARTQTE int not null ,seq numeric(7) identity)
		set identity_update FART on
		insert into #fart (ARTAR, ARTTARIF, ARTENT, ARTDATE, ARTDEV, ARTQTE ) select ARTAR, ARTTARIF, ARTENT, ARTDATE, ARTDEV, ARTQTE  from FART
		update FART set ARTSEQ=seq from #fart 	where FART.ARTAR=#fart.ARTAR and FART.ARTTARIF=#fart.ARTTARIF and isnull(FART.ARTENT,'')=isnull(#fart.ARTENT,'')
 									and   FART.ARTDATE=#fart.ARTDATE and FART.ARTDEV=#fart.ARTDEV and FART.ARTQTE =#fart.ARTQTE 
		select "Mise a jour sequentiels FART :",@@rowcount
	    drop table #fart
	    set identity_update FART off

	end

	/* Mise a jour de la table article et fichiers lignes sur les bases Esclaves */
	/* ************************************************************************* */

	declare @BaseEsclave varchar(32)
	declare @string varchar(1000)

	declare Base cursor  for
	select ENBASE from FEN where isnull(ENTYPE,0)=2 and isnull(ENMIRRORAR,0)=1

	open Base
	fetch Base into @BaseEsclave
	
	while (@@sqlstatus=0)
	begin

		if @BaseEsclave!=null
		begin
	
			select "MISE A JOUR DE LA BASE ",@BaseEsclave

			select @string='delete from '+@BaseEsclave+'..FAR where  "'+@ar+'" ="" or ARCODE="'+@ar+'"'
			execute (@string)
			select @string='truncate table '+@BaseEsclave+'..FARDEL'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FAR select * from FAR where "'+@ar+'" ="" or ARCODE="'+@ar+'"'
			execute (@string)
			select "Mise a jour articles :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FART where  "'+@ar+'" ="" or ARTAR="'+@ar+'"'
			execute (@string)
			select @string='set identity_insert  '+@BaseEsclave+'..FART'+' on'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FART (ARTSEQ,ARTAR,ARTTARIF,ARTDATE,ARTDEV,ARTQTE,ARTPVHT,ARTUSERCRE,ARTDATECRE,ARTUSERMDF,ARTDATEMDF,ARTENT) select ARTSEQ,ARTAR,ARTTARIF,ARTDATE,ARTDEV,ARTQTE,ARTPVHT,ARTUSERCRE,ARTDATECRE,ARTUSERMDF,ARTDATEMDF,ARTENT  from FART where "'+@ar+'" ="" or ARTAR="'+@ar+'"'
			execute (@string)
			select "Mise a jour tarifs :",@@rowcount
			select @string='set identity_insert  '+@BaseEsclave+'..FART'+' off'
			execute (@string)

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FARE where  "'+@ar+'" ="" or AREAR="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FARE select * from FARE where "'+@ar+'" ="" or AREAR="'+@ar+'"'
			execute (@string)
			select "Mise a jour emplacement des articles :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FARF where  "'+@ar+'" ="" or ARFCODE="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FARF select * from FARF where "'+@ar+'" ="" or ARFCODE="'+@ar+'"'
			execute (@string)
			select "Mise a jour fournisseurs des articles :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FARD where  "'+@ar+'" ="" or ARDCODE="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FARD (ARDLANGUE,ARDCODE,ARDLIB) select ARDLANGUE,ARDCODE,ARDLIB  from FARD where "'+@ar+'" ="" or ARDCODE="'+@ar+'"'
			execute (@string)
			select "Mise a jour libelles articles :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FARC where  "'+@ar+'" ="" or ARCCODE="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FARC select * from FARC where "'+@ar+'" ="" or ARCCODE="'+@ar+'"'
			execute (@string)
			select "Mise a jour articles composants :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FARS where  "'+@ar+'" ="" or ARSAR1="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FARS select * from FARS where "'+@ar+'" ="" or ARSAR1="'+@ar+'"'
			execute (@string)
			select "Mise a jour articles de substitution :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FCLAX where  "'+@ar+'" ="" or CLAXCLE="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FCLAX (CLAXCLE,CLAXAX,CLAXSECTION,CLAXENT) select CLAXCLE,CLAXAX,CLAXSECTION,CLAXENT from FCLAX where "'+@ar+'" ="" or CLAXCLE="'+@ar+'"'
			execute (@string)
			select "Mise a jour des sections complementaires :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FCLAXH where  "'+@ar+'" ="" or CLAXHCLE="'+@ar+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FCLAXH (CLAXHCLE,CLAXHAX,CLAXHSECTION,CLAXHENT,CLAXHDATE) select CLAXHCLE,CLAXHAX,CLAXHSECTION,CLAXHENT,CLAXHDATE from FCLAXH where "'+@ar+'" ="" or CLAXHCLE="'+@ar+'"'
			execute (@string)
			select "Mise a jour historique sections complementaires :",@@rowcount
		
		end
		fetch Base into @BaseEsclave
	end

	close Base


	/* Mise a jour des fichier de parametres sur les bases esclaves */
	/* ************************************************************ */

	if (@ar ="")	/* La mise a jour de masse entraine une mise Ã¢?Â¡ jour des tables de parametres */
	begin

		select @BaseEsclave=null

		open Base
		fetch Base into @BaseEsclave
	
		while (@@sqlstatus=0)
		begin

			if @BaseEsclave!=null
			begin

				select @string='truncate table '+@BaseEsclave+'..FTF'
				execute (@string)
				select @string='set identity_insert  '+@BaseEsclave+'..FTF'+' on'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FTF (TFSEQ,TFCODE,TFLIB ,TFUSERCRE,TFDATECRE , TFUSERMDF, TFDATEMDF ,TFENT) select TFSEQ,TFCODE,TFLIB ,TFUSERCRE,TFDATECRE , TFUSERMDF, TFDATEMDF ,TFENT from FTF'
				execute (@string)
				select "Mise a jour tarifs :",@@rowcount
				select @string='set identity_insert  '+@BaseEsclave+'..FTF'+' off'
				execute (@string)

				select @string='truncate table '+@BaseEsclave+'..FTFL'
				execute (@string)
				select @string='set identity_insert  '+@BaseEsclave+'..FTFL'+' on'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FTFL (TFLSEQ,TFLCODE,TFLDATE,TFLDESACT,TFLUSERCRE,TFLDATECRE,TFLUSERMDF,TFLDATEMDF,TFLDES,TFLENT   ) select TFLSEQ,TFLCODE,TFLDATE,TFLDESACT,TFLUSERCRE,TFLDATECRE,TFLUSERMDF,TFLDATEMDF,TFLDES,TFLENT    from FTFL'
				execute (@string)
				select "Mise a jour date tarifs :",@@rowcount
				select @string='set identity_insert  '+@BaseEsclave+'..FTFL'+' off'
				execute (@string)

				select @string='truncate table '+@BaseEsclave+'..FFP'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FFP select * from FFP'
				execute (@string)
				select "Mise a jour familles :",@@rowcount

				select @string='truncate table  '+@BaseEsclave+'..FDT'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FDT select * from FDT'
				execute (@string)
				select "Mise a jour departements :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FGF'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FGF select * from FGF'
				execute (@string)
				select "Mise a jour categories :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FFO'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FFO select * from FFO'
				execute (@string)
				select "Mise a jour frs:",@@rowcount

				select @string='truncate table  '+@BaseEsclave+'..FCR'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FCR select * from FCR'
				execute (@string)
				select "Mise a jour cr :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FMA'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FMA select * from FMA'
				execute (@string)
				select "Mise a jour ma :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FTA'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FTA select * from FTA'
				execute (@string)
				select "Mise a jour ta :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FCH'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FCH select * from FCH'
				execute (@string)
				select "Mise a jour ch :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FAX'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FAX select * from FAX'
				execute (@string)
				select "Mise a jour ax :",@@rowcount

				select @string='truncate table '+@BaseEsclave+'..FAXL'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FAXL select * from FAXL' 
				execute (@string)
				select "Mise a jour axl :",@@rowcount


			end

			fetch Base into @BaseEsclave
		end

		close Base


	deallocate cursor Base

	select @string='delete '+@BaseEsclave+'..KSeq where name in ("FAR","FARE","FARF","FARD","FARS","FARC","FFP","FDT","FGF","FFO","FCR","FMA","FTA","FCH","FAX","FAXL")'
	execute (@string) 
	select @string='insert into '+@BaseEsclave+'..KSeq (name,value) select name,value from KSeq where name in ("FAR","FARE","FARF","FARD","FARS","FARC","FFP","FDT","FGF","FFO","FCR","FMA","FTA","FCH","FAX","FAXL")'
	execute (@string) 

	end


end



go

