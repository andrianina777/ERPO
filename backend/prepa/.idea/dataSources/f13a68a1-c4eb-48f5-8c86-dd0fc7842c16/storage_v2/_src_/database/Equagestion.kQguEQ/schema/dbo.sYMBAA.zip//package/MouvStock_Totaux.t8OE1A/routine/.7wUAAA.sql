


/* Procedure generant les lignes de mouvements de stock */


create procedure MouvStock_Totaux ( @annee			smallint,
									@mois			tinyint,
									@depart			char(8)		= null,
									@marque			char(12)	= null,
									@famille		char(8)		= null,
									@article		char(15)	= null,
									@depot			tinyint 	= 0
									)
with recompile
as
begin

set arithabort numeric_truncation off


declare @anneeInit		smallint
declare @count			int

select @anneeInit=@annee-1
	
/******* table des articles ******/
	
create table #FAR
(
ARCODE		char(15)		not null,
ARFO		char(12)			null,
ARFAM		char(8)				null,
ARLIB		varchar(80)			null,
ARNUMEROTE	tinyint				null
)

/******* table de l''inventaire initial ******/

create table #Init
(
articleInit		char(15)		null,
QuantiteInit	int				null,
CoutInit		numeric(14,2)	null,
CoutInitNum		numeric(14,2)	null,
DepotInit		tinyint			null
)


/******* table des entrees pendant la periode ******/

create table #Entree
(
articleIn	char(15)	null,
QuantiteIn	int			null,
CoutIn		numeric(14,2)		null,
CoutInNum	numeric(14,2)		null,
DepotIn		tinyint		null
)

/******* table des valeurs reajustees pendant la periode ******/

create table #Reajust
(
articleReajust	char(15)	null,
QuantiteReajust	int			null,
CoutReajust		numeric(14,2)		null,
CoutReajustNum	numeric(14,2)		null,
DepotReajust	tinyint		null
)

/******* table des sorties pendant la periode ******/

create table #Sortie
(
articleOut	char(15)	null,
QuantiteOut	int			null,
CoutOut		numeric(14,2)		null,
CoutOutNum	numeric(14,2)		null,
DepotOut	tinyint		null
)

/******************* Traitement ********************/

select @count=count(*) from FMOIS
where MOISANNEE=@anneeInit
and MOISMOIS=12


if (@count=0)	/* si le mois precedent n''a pas ete stocke, renvoie -1 sur @count */
	begin
	select @count=-1
	select @count,0
	end
else
	begin


	 if ((@marque is null) and (@famille is null) and (@article is null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@marque is null) and (@famille is null) and (@article is not null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARCODE=@article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@marque is null) and (@famille is not null) and (@article is null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARFAM=@famille
			 and (@depart is null or ARDEPART=@depart)
		 end	
	 else if ((@marque is null) and (@famille is not null) and (@article is not null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARFAM=@famille
			 and ARCODE=@article
			 and (@depart is null or ARDEPART=@depart)
		 end		
	 else if ((@marque is not null) and (@famille is null) and (@article is null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARFO=@marque
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@marque is not null) and (@famille is null) and (@article is not null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARFO=@marque
			 and ARCODE=@article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@marque is not null) and (@famille is not null) and (@article is null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARFO=@marque
			 and ARFAM=@famille
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@marque is not null) and (@famille is not null) and (@article is not null))
		 begin
			 insert into #FAR (ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE)
			 select ARCODE,ARFO,ARFAM,ARLIB,ARNUMEROTE
			 from FAR
			 where ARFO=@marque
			 and ARFAM=@famille
			 and ARCODE=@article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 
	 
	 create unique clustered index article on #FAR(ARCODE)
	 
	 
	 /****** Information initiale stockee le mois precedent dans FMOIS ******/
	 
	 
	 if (@depot=0)			/* Tout le stock */
		 begin
			 insert into #Init (articleInit,QuantiteInit,CoutInit,CoutInitNum,DepotInit)
			 select MOISARTICLE,MOISQTE,(case when ARNUMEROTE=0 then MOISTOTPR else 0 end),
			 							(case when ARNUMEROTE=1 then MOISTOTPR else 0 end),
										MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@anneeInit
			 and MOISMOIS=12
			 and MOISQTE != 0
		 end
	 else if (@depot=1)		/* Le stock local */
		 begin
			 insert into #Init (articleInit,QuantiteInit,CoutInit,CoutInitNum,DepotInit)
			 select MOISARTICLE,MOISQTE,(case when ARNUMEROTE=0 then MOISTOTPR else 0 end),
			 							(case when ARNUMEROTE=1 then MOISTOTPR else 0 end),
										MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@anneeInit
			 and MOISMOIS=12
			 and MOISDEPOT=1
			 and MOISQTE != 0
		 end
	 else if (@depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Init (articleInit,QuantiteInit,CoutInit,CoutInitNum,DepotInit)
			 select MOISARTICLE,MOISQTE,(case when ARNUMEROTE=0 then MOISTOTPR else 0 end),
			 							(case when ARNUMEROTE=1 then MOISTOTPR else 0 end),
										MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@anneeInit
			 and MOISMOIS=12
			 and MOISDEPOT in (0,2)
			 and MOISQTE != 0
		 end
	 
	 create clustered index ardep on #Init(articleInit,DepotInit)
	 
	 
	 
	 /******* Calcul des valeurs entree pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@depot=0)			/* Tout le stock */
		 begin
			 insert into #Entree (articleIn,QuantiteIn,CoutIn,CoutInNum,DepotIn)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSTYPE='E'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@depot=1)		/* Le stock local */
		 begin
			 insert into #Entree (articleIn,QuantiteIn,CoutIn,CoutInNum,DepotIn)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSDEPOT=1
			 and MSTYPE='E'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Entree (articleIn,QuantiteIn,CoutIn,CoutInNum,DepotIn)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSDEPOT in (0,2)
			 and MSTYPE='E'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 
	 create clustered index ardep on #Entree(articleIn,DepotIn)
	 
	 /******* Calcul des valeurs reajustees pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@depot=0)			/* Tout le stock */
		 begin
			 insert into #Reajust (articleReajust,QuantiteReajust,CoutReajust,CoutReajustNum,DepotReajust)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSTYPE in ('F','R','A','C','M')
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@depot=1)		/* Le stock local */
		 begin
			 insert into #Reajust (articleReajust,QuantiteReajust,CoutReajust,CoutReajustNum,DepotReajust)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSDEPOT=1
			 and MSTYPE in ('F','R','A','C','M')
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Reajust (articleReajust,QuantiteReajust,CoutReajust,CoutReajustNum,DepotReajust)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSDEPOT in (0,2)
			 and MSTYPE in ('F','R','A','C','M')
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 
	 
	 create clustered index ardep on #Reajust(articleReajust,DepotReajust)
	 
	 /******* Calcul des valeurs sorties pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@depot=0)			/* Tout le stock */
		 begin
			 insert into #Sortie (articleOut,QuantiteOut,CoutOut,CoutOutNum,DepotOut)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSTYPE='S'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@depot=1)		/* Le stock local */
		 begin
			 insert into #Sortie (articleOut,QuantiteOut,CoutOut,CoutOutNum,DepotOut)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSDEPOT=1
			 and MSTYPE='S'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT
		 end
	 else if (@depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Sortie (articleOut,QuantiteOut,CoutOut,CoutOutNum,DepotOut)
			 select MSARTICLE,sum(MSQTE),sum(case when ARNUMEROTE=0 then MSTOTPR else 0 end),
			 							 sum(case when ARNUMEROTE=1 then MSTOTPR else 0 end),
										 MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@annee
			 and MSMOIS between 1 and @mois
			 and MSDEPOT in (0,2)
			 and MSTYPE='S'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT
		 end
	 
	 create clustered index ardep on #Sortie(articleOut,DepotOut)
	 
	 
	 /* Creation du fichier final avec insertion des articles de #Init et de #Reajust */
	 
	 select article=articleInit,
	 QteInit=isnull(QuantiteInit,0),
	 ValeurInit=isnull(CoutInit,0),
	 ValeurInitNum=isnull(CoutInitNum,0),
	 QteRJ=0,
	 ValeurRJ=convert(numeric(14,2),0),
	 ValeurRJNum=convert(numeric(14,2),0),
	 QteIn=0,
	 ValeurIn=convert(numeric(14,2),0),
	 ValeurInNum=convert(numeric(14,2),0),
	 QteOut=0,
	 ValeurOut=convert(numeric(14,2),0),
	 ValeurOutNum=convert(numeric(14,2),0),
	 QteFinale=0,
	 ValeurFinale=convert(numeric(14,2),0),
	 ValeurFinaleNum=convert(numeric(14,2),0),
	 Depot=DepotInit
	 into #Final
	 from #Init
	 
	 drop table #Init
	 
	 create clustered index ardep on #Final(article,Depot)
	 
	 /* Insertion dans #Final des articles entres sans correpondance dans #Final */
	 
	 insert into #Final
	 select articleIn,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,DepotIn
	 from #Entree
	 where not exists (select * from #Final 
					   where article=#Entree.articleIn
					   and Depot=#Entree.DepotIn)
	 
	 /* Mise a jour de #Final avec les valeurs de #Entree */
	 
	 update #Final
	 set QteIn=isnull(QuantiteIn,0),ValeurIn=isnull(CoutIn,0),ValeurInNum=isnull(CoutInNum,0)
	 from #Entree
	 where article=articleIn
	 and Depot=DepotIn
	 
	 drop table #Entree
	 
	 /* Insertion dans #Final des articles reajustes sans correspondance dans #Final */
	 
	 insert into #Final
	 select articleReajust,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,DepotReajust
	 from #Reajust
	 where not exists (select * from #Final 
					   where article=#Reajust.articleReajust
					   and Depot=#Reajust.DepotReajust)
	 
	 /* Mise a jour de #Final avec les valeurs de #Reajust */
	 
	 update #Final
	 set QteRJ=isnull(QuantiteReajust,0),ValeurRJ=isnull(CoutReajust,0),ValeurRJNum=isnull(CoutReajustNum,0)
	 from #Reajust
	 where article=articleReajust
	 and Depot=DepotReajust
	 
	 drop table #Reajust
	 
	 
	 /* Insertion dans #Final des articles sortis sans correspondance dans #Final */
	 
	 insert into #Final
	 select articleOut,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,DepotOut
	 from #Sortie
	 where not exists (select * from #Final 
					   where article=#Sortie.articleOut
					   and Depot=#Sortie.DepotOut)
	 
	 /* Mise a jour de #Final avec les valeurs de #Sortie */
	 
	 update #Final
	 set QteOut=isnull(QuantiteOut,0),ValeurOut=isnull(CoutOut,0),ValeurOutNum=isnull(CoutOutNum,0)
	 from #Sortie
	 where article=articleOut
	 and Depot=DepotOut
	 
	 drop table #Sortie
	 
	 
	 /* Mise a jour des valeurs finales de #Final */
	 
	 select article=article,
	 	 QteInit=isnull(sum(QteInit),0),ValeurInit=isnull(sum(ValeurInit),0),ValeurInitNum=isnull(sum(ValeurInitNum),0),
		 QteRJ=isnull(sum(QteRJ),0),ValeurRJ=isnull(sum(ValeurRJ),0),ValeurRJNum=isnull(sum(ValeurRJNum),0),
		 QteIn=isnull(sum(QteIn),0),ValeurIn=isnull(sum(ValeurIn),0),ValeurInNum=isnull(sum(ValeurInNum),0),
		 QteOut=isnull(sum(QteOut),0),ValeurOut=isnull(sum(ValeurOut),0),ValeurOutNum=isnull(sum(ValeurOutNum),0),
		 QteFinale=sum(isnull(QteInit,0)+isnull(QteRJ,0)+isnull(QteIn,0)-isnull(QteOut,0)),
		 ValeurFinale=convert(numeric(14,2),0),ValeurFinaleNum=convert(numeric(14,2),0)
	 into #Final2
	 from #Final
	 group by article
	 
	 drop table #Final
	 
	 delete from #Final2
	 where QteFinale = 0
	 
	 update #Final2
	 set ValeurInit=0
	 where QteInit=0
	 	 
	 update #Final2
	 set ValeurFinale=isnull(ValeurInit,0)+isnull(ValeurRJ,0)+isnull(ValeurIn,0)-isnull(ValeurOut,0),
	 	 ValeurFinaleNum=isnull(ValeurInitNum,0)+isnull(ValeurRJNum,0)+isnull(ValeurInNum,0)-isnull(ValeurOutNum,0)	 
	 
	 select isnull(sum(ValeurFinale),0),isnull(sum(ValeurFinaleNum),0)
	 from #Final2
	 
	   
	drop table #FAR
	drop table #Final2
 
	end		/* else de if (@count=0) */
end



go

