


create procedure Maj_MirroringCl(@cl	char(15)	=null)
as
begin

	if @cl is null select @cl=""

	/* Mise a jour de la table clients et fichiers lignes sur les bases Esclaves */
	/* ************************************************************************* */

	declare @BaseEsclave varchar(32)
	declare @string varchar(1000)
	declare @sect char(8)

	declare Base cursor  for
	select ENBASE,ENPY from FEN where isnull(ENTYPE,0)=2 and isnull(ENMIRRORCL,0)=1 /* Attention, il s''agit du code secteur au lieu du code pays ... */

	open Base
	fetch Base into @BaseEsclave,@sect
	
	while (@@sqlstatus=0)
	begin

		if @BaseEsclave!=null
		begin
	
			select "MISE A JOUR DE LA BASE ",@BaseEsclave

			select @string='delete from '+@BaseEsclave+'..FCL where  ("'+@cl+'" ="" or CLCODE="'+@cl+'") and CLSECT="'+@sect+'"'
			execute (@string)
			select @string='insert into ' + @BaseEsclave + '..FCL select * from FCL where ("'+@cl+'" ="" or CLCODE="'+@cl+'") and CLSECT="'+@sect+'"'
			execute (@string)
			select "Mise a jour clients :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FADR where  ("'+@cl+'" ="" or ADRCL="'+@cl+'") and  exists (select * from FCL where CLCODE='+@BaseEsclave+'..FADR.ADRCL and CLSECT="'+@sect+'")'
			execute (@string)
			select @string='insert into '+@BaseEsclave+'..FADR select * from FADR where ("'+@cl+'" ="" or ADRCL="'+@cl+'") and  exists (select * from FCL where CLCODE=FADR.ADRCL and CLSECT="'+@sect+'")'

			execute (@string)
			select "Mise a jour des adresses des clients :",@@rowcount

			dump tran @BaseEsclave with truncate_only

			select @string='delete from '+@BaseEsclave+'..FRC where ("'+@cl+'" ="" or RCCL="'+@cl+'") and exists (select * from FCL where CLCODE='+@BaseEsclave+'..FRC.RCCL and CLSECT="'+@sect+'")' 
			execute (@string)
			select @string='insert into '+@BaseEsclave+'..FRC select * from FRC where ("'+@cl+'" ="" or RCCL="'+@cl+'") and  exists (select * from FCL where CLCODE=FRC.RCCL and CLSECT="'+@sect+'")'
			execute (@string)
			select "Mise a jour remises des clients :",@@rowcount	

		end
		fetch Base into @BaseEsclave,@sect
	end

	close Base


	/* Mise a jour des fichier de parametres sur les bases esclaves */
	/* ************************************************************ */

	if (@cl ="")	/* La mise a jour de masse entraine une mise Ã¢?Â¡ jour des tables de parametres */
	begin

		select @sect=null,@BaseEsclave=null
		
		open Base
		fetch Base into @BaseEsclave,@sect
	
		while (@@sqlstatus=0)
		begin


			if @BaseEsclave!=null
			begin

				select @string='delete from '+@BaseEsclave+'..FPY'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FPY select * from FPY'
				execute (@string)
				select "Mise a jour pays  :",@@rowcount

				select @string='set identity_insert  '+@BaseEsclave+'..FLA'+' on'
				execute (@string)
				select @string='delete from '+@BaseEsclave+'..FLA'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FLA (LASEQ,LACODE,LALIB) select LASEQ,LACODE,LALIB from FLA'
				execute (@string)
				select "Mise a jour langue :",@@rowcount
				select @string='set identity_insert  '+@BaseEsclave+'..FLA'+' off'
				execute (@string)

				select @string='delete from '+@BaseEsclave+'..FSA'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FSA select * from FSA'
				execute (@string)
				select "Mise a jour activitÃ?s :",@@rowcount

				select @string='set identity_insert  '+@BaseEsclave+'..FCLA'+' on'
				execute (@string)
				select @string='delete from '+@BaseEsclave+'..FCLA'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FCLA (CLASEQ,CLACODE,CLADES,CLATYPE,CLARACINE,CLAENT,CLAINTERCO) select (CLASEQ,CLACODE,CLADES,CLATYPE,CLARACINE,CLAENT,CLAINTERCO) from FCLA'
				execute (@string)
				select "Mise a jour classes:",@@rowcount
				select @string='set identity_insert  '+@BaseEsclave+'..FCLA'+' off'
				execute (@string)

				select @string='delete from '+@BaseEsclave+'..FTR'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FTR select * from FTR'
				execute (@string)
				select "Mise a jour reglements :",@@rowcount

				select @string='delete from '+@BaseEsclave+'..FREP'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FREP select * from FREP where REPAYS="'+@sect+'"'
				execute (@string)
				select "Mise a jour representant :",@@rowcount

				select @string='delete from '+@BaseEsclave+'..FSECT'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FSECT select * from FSECT'
				execute (@string)
				select "Mise a jour secteurs :",@@rowcount

				select @string='delete from '+@BaseEsclave+'..FRG'
				execute (@string)
				select @string='insert into '+@BaseEsclave+'..FRG select * from FRG'
				execute (@string)
				select "Mise a jour region :",@@rowcount


			end

			fetch Base into @BaseEsclave,@sect
		end

		close Base


	deallocate cursor Base

	select @string='delete '+@BaseEsclave+'..KSeq where name in ("FPY","FLA","FSA","FCLA","FTR","FSECT","FREP","FRG", "FCL","FADR","FRC")'
	execute (@string) 
	select @string='insert into '+@BaseEsclave+'..KSeq (name,value) select name,value from KSeq where name in ("FPY","FLA","FSA","FCLA","FTR","FSECT","FREP","FRG")'
	execute (@string) 
	select @string='insert into '+@BaseEsclave+'..KSeq (name,value) select "FCL",max(CLSEQ)+1 from '+@BaseEsclave+'..FCL'
	execute (@string) 
	select @string='insert into '+@BaseEsclave+'..KSeq (name,value) select "FADR",max(ADRSEQ)+1 from '+@BaseEsclave+'..FADR'
	execute (@string)
	select @string='insert into '+@BaseEsclave+'..KSeq (name,value) select "FRC",max(RCSEQ)+1 from '+@BaseEsclave+'..FRC'
	execute (@string)

	end
 

end



go

