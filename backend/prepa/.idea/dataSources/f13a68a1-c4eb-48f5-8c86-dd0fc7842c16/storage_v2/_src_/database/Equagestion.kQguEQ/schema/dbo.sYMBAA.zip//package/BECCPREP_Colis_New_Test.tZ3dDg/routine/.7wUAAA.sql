CREATE PROCEDURE dbo.BECCPREP_Colis_New_Test (@cc varchar(10),@depot varchar(10))
AS
begin

        declare @nbligne int,@prepa_colis int,@CCLARTICLE varchar(50),@APREPARER int,@CCLSEQ numeric(14,0),@CCLQTE int,@CCLQTE_APREPARER int,
                @STAR varchar(50),  @ST_QTE_RSRV int, @STLETTRE varchar(10),
                @STEMPAR varchar(50),  
                @STEMPQTE int, 
                @NLOTDATEPER smalldatetime, 
                @STEMPEMP varchar(10), 
                @STLOT varchar(50), 
                @STEMPDEPOT varchar(10)


declare	
                @CCLCODE		char(10),
                @CCLNUM			int,
                @CCLDATE		datetime,
                @CCLRESTE		int,
                @ARLIB			varchar(80),
                @ARUNITFACT		tinyint,
                @PUHT			numeric(14,2),
                @MODELIV		char(2),
                @CCLLIBRE		varchar(255),
                @CCLTV			char(4),
                @ARREGLE		tinyint,
                @CCLECHSPE		tinyint,
                @CCLFACTMAN		tinyint,
                @CCLOFFERT		tinyint,
                @ARTYPE			tinyint,
                @CCLDEV			char(3),
                @CCLCOURSDEV	        numeric(16,10),
                @CCLPHTDEV		numeric(14,2),
                @CCLTOTALHTDEV	        numeric(14,2),
                @CCLR1			real,
                @CCLR2			real,
                @CCLR3			real,
                @CCLTOTALHT		numeric(14,2),
                @CCLQTERES		int,
                @CCLDATERESFIN	        smalldatetime,
                @CCLDEPOTRES	        char(4),
                @ARCOMP			tinyint,
                @CCLQTEPREP		int,
                @CCLATTACHE		char(10),
                @ARREFFOUR		char(20),
                @CCLMARCHE		char(12),
                @CCLCOLIS		numeric(14,2),
                @ARQTECOLIS		int,
                @CCLPAHT		numeric(14,2),
                @CCL_LIBSEQ             numeric(18,0),
                @CCL_COMMENT_MAG        varchar(255),
                @CCLCOLISAGE	        varchar(25) ,
                @CCLNBCOLIS		int,
                @CCLPACK		int
        
        create table #stockFinal(
                SEQ numeric identity,
                STEMPAR varchar(50) null,
                STEMPLETTRE varchar(10) null,
                QteLoc int null,
                STEMPDATE  date null,
                STEMPEMP varchar(10) null,
                STEMPLOT varchar(50) null,
                STEMPDEPOT varchar(10) null
        )
        create index stockFinal_idx0001 on #stockFinal(STEMPAR)
        create index stockFinal_idx0002 on #stockFinal(STEMPLETTRE)
        create index stockFinal_idx0003 on #stockFinal(STEMPDEPOT)
        create index stockFinal_idx0004 on #stockFinal(SEQ)

        create table #Prep
        (
                CCLSEQ			numeric(14,0)   not null,
                CCLCODE			char(10)	not null,
                CCLNUM			int		null,
                CCLDATE			date	        null,
                CCLARTICLE		char(15)	not null,
                CCLRESTE		int		null,
                ARLIB			varchar(80)	null,
                ARUNITFACT		tinyint		null,
                CCLPHT			numeric(14,2)	null,
                MODELIV			char(2)		null,
                CCLLIBRE		varchar(255)	null,
                CCLTV			char(4)		null,
                ARREGLE			tinyint		null,
                CCLECHSPE		tinyint		null,
                CCLFACTMAN		tinyint		null,
                CCLOFFERT		tinyint		null,
                ARTYPE			tinyint		null,
                CCLDEV			char(3)		null,
                CCLCOURSDEV		numeric(16,10)	null,
                CCLPHTDEV		numeric(14,2)	null,
                CCLTOTALHTDEV	        numeric(14,2)	null,
                CCLR1			real		null,
                CCLR2			real		null,
                CCLR3			real		null,
                CCLTOTALHT		numeric(14,2)	null,
                CCLQTERES		int		null,
                CCLDATERESFIN	        smalldatetime	null,
                CCLDEPOTRES		char(4)		null,
                ARCOMP			tinyint		null,
                CCLQTEPREP		int		null,
                CCLATTACHE		char(10)	null,
                ARREFFOUR 		char(20)	null,
                CCLMARCHE		char(12)	null,
                CCLCOLIS		numeric(14,2)	null,
                ARQTECOLIS		int		null,
                CCLPAHT			numeric(14,2)	null,
                CCL_LIBSEQ              numeric(18,0)   null,
                CCL_COMMENT_MAG         varchar(255)	null,
                CCLCOLISAGE 	        varchar(25)     null,
                CCLNBCOLIS		int             null,
                CCLPACK			int             null,
                CCL_APREPARER           int             null
        )    

        create index Prep_idx0001 on #Prep(CCLSEQ)
        create index Prep_idx0002 on #Prep(CCLDATE)

        create table #Liste
        (
                Article 		char(15)	not null,
                Lettre			char(4)		not null,
                Designation		char(80)	null,
                LienCode		char(10)	not null,
                LienNum			int		not null,
                Qte			int		null,
                UnitFact		tinyint		not null,
                PrixHT			numeric(14,2)	null,
                ModeLiv			char(2)		null,
                LigneLibre		varchar(255)	null,
                TypeVente		char(4)		not null,
                Reglement		tinyint		null,
                Echeancesp		tinyint		null,
                Factman			tinyint		null,
                Offert			tinyint		null,
                Artype			tinyint		null,
                Devise			char(3)		not null,
                Coursdev		numeric(16,10)	null,
                PrixHTdev		numeric(14,2)	null,
                TotHTdev		numeric(14,2)	null,
                Rem1			real		null,
                Rem2			real		null,
                Rem3	 		real		null,
                TotPrixHT		numeric(14,2)	null,
                Emplacement		char(8)		not null,
                Attachement		char(10)	null,
                Lot			char(12)	not null,
                Arreffour		char(20)	null,
                cclmarche		char(12)	null,
                ccldate			date	        null,
                cclcolis		numeric(14,2)	null,
                arqtecolis		int		null,
                cclpaht			numeric(14,2)	null,
                seqLib                  numeric (18,0)  null,
                comment_mag		varchar(255)	null,
                cclcolisage		varchar(25)	null,
                cclnbcolis		int		null,
                cclpack			int		null
        )


        create table #cclFinal(
                CCLSEQ numeric(14,0),
                CCLARTICLE varchar(50) null,
                CCLQTE int null,
                CCLQTE_APREPARER int null
        )
        
        create index cclFinal_idx0001 on #cclFinal(CCLSEQ)
        create index cclFinal_idx0002 on #cclFinal(CCLARTICLE)
        
        
        select CCLSEQ, CCLCODE, CCLARTICLE, CCLQTE, CCLDATE, CCLR1, CCLR2, CCLR3, CCLR4, CCLR5, CCLPHT, CCLORDRE, CCLUNITFACT, CCLTV, CCLTYPE, CCLLIBRE, CCLNUM, CCLQTEEXP, CCLRESTE, CCLCL, CCLTOTALHT, CCLECHSPE, CCLTYPEMV, CCLDATEMDF, CCLUSERMDF, CCLFACTMAN, CCLOFFERT, CCLDATECRE, CCLUSERCRE, CCLDEV, CCLCOURSDEV, CCLPHTDEV, CCLTOTALHTDEV, CCLATTACHE, CCLENT, CCLQTERES, CCLDATERESFIN, CCLDEPOTRES, CCLREP, CCLREPDIV, CCLWEBCODE, CCLWEBNUM, CCLQTEPREP, CCLCF, CCLMARCHE, CCLFACT, CCLLOT, CCLFRAIS, CCLCOLIS, CCLPAHT, CCLDATEINIT, CCLTOTALHTORG, CCLNUMARM1, CCL_LIBSEQ, CCLATTETRANSFERT, CCL_COMMENT_MAG, CCLCOLISAGE, CCLNBCOLIS, CCLPACK 
        into #FCCL
        from FCCL
        where CCLCODE=@cc
        and (isnull(CCLRESTE,0)-isnull(CCLQTEPREP,0))>0


/* Adaptive Server has expanded all '*' elements in the following statement */ select #FCCL.CCLSEQ, #FCCL.CCLCODE, #FCCL.CCLARTICLE, #FCCL.CCLQTE, #FCCL.CCLDATE, #FCCL.CCLR1, #FCCL.CCLR2, #FCCL.CCLR3, #FCCL.CCLR4, #FCCL.CCLR5, #FCCL.CCLPHT, #FCCL.CCLORDRE, #FCCL.CCLUNITFACT, #FCCL.CCLTV, #FCCL.CCLTYPE, #FCCL.CCLLIBRE, #FCCL.CCLNUM, #FCCL.CCLQTEEXP, #FCCL.CCLRESTE, #FCCL.CCLCL, #FCCL.CCLTOTALHT, #FCCL.CCLECHSPE, #FCCL.CCLTYPEMV, #FCCL.CCLDATEMDF, #FCCL.CCLUSERMDF, #FCCL.CCLFACTMAN, #FCCL.CCLOFFERT, #FCCL.CCLDATECRE, #FCCL.CCLUSERCRE, #FCCL.CCLDEV, #FCCL.CCLCOURSDEV, #FCCL.CCLPHTDEV, #FCCL.CCLTOTALHTDEV, #FCCL.CCLATTACHE, #FCCL.CCLENT, #FCCL.CCLQTERES, #FCCL.CCLDATERESFIN, #FCCL.CCLDEPOTRES, #FCCL.CCLREP, #FCCL.CCLREPDIV, #FCCL.CCLWEBCODE, #FCCL.CCLWEBNUM, #FCCL.CCLQTEPREP, #FCCL.CCLCF, #FCCL.CCLMARCHE, #FCCL.CCLFACT, #FCCL.CCLLOT, #FCCL.CCLFRAIS, #FCCL.CCLCOLIS, #FCCL.CCLPAHT, #FCCL.CCLDATEINIT, #FCCL.CCLTOTALHTORG, #FCCL.CCLNUMARM1, #FCCL.CCL_LIBSEQ, #FCCL.CCLATTETRANSFERT, #FCCL.CCL_COMMENT_MAG, #FCCL.CCLCOLISAGE, #FCCL.CCLNBCOLIS, #FCCL.CCLPACK from #FCCL

        create index FCCL_idx0001 on #FCCL(CCLARTICLE)

        select CCLCODE,CCLARTICLE,sum(CCLQTE) as QTE_CDE,sum(CCLRESTE-(isnull(CCLQTEPREP,0))) as QTE_A_PREPARER,isnull(ARFRANCOFO,0) as COLISAGE,(case when (isnull(ARFRANCOFO,0)<>0) then (sum(CCLRESTE-(isnull(CCLQTEPREP,0))))/isnull(ARFRANCOFO,0)  else 0 end * isnull(ARFRANCOFO,0)) as QTE_PREPARER_COLIS,ARTYPE
        into #FCCL_GROUPE
        from #FCCL,VIEW_FAR
        where ARCODE=CCLARTICLE
        group by CCLCODE,CCLARTICLE,isnull(ARFRANCOFO,0),ARTYPE

        create index FCCL_GROUPE_idx0001 on #FCCL_GROUPE(CCLARTICLE)
        create index FCCL_GROUPE_idx0002 on #FCCL_GROUPE(QTE_PREPARER_COLIS)
        create index FCCL_GROUPE_idx0003 on #FCCL_GROUPE(QTE_A_PREPARER)

                
        select STEMPID, STEMPAR, STEMPDEPOT, STEMPEMP, STLOT, NLOTDATEPER, xDPVTE, xDPCENTRAL, STFO, STDATEENTR, STLETTRE, STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS, ARLIB, ARQTEPALETTE, ARFO, ARREFFOUR, ARPRM, ARUNITACHAT, ARNUMEROTE, ARFRANCOFO, STEMPQTE, VALEUR, ARESSEMP, ST_UG, ARPVHT, xARTP_STATSPEC 
        into #VIEW_STOCK_LOT_EMPLACEMENT
        from VIEW_STOCK_LOT_EMPLACEMENT,#FCCL_GROUPE
        where STEMPDEPOT=@depot
        and STEMPAR=CCLARTICLE
        
        create index STOCK_idx0001 on #VIEW_STOCK_LOT_EMPLACEMENT(STEMPAR)
        create index STOCK_idx0002 on #VIEW_STOCK_LOT_EMPLACEMENT(STEMPDEPOT)
        create index STOCK_idx0003 on #VIEW_STOCK_LOT_EMPLACEMENT(STLETTRE)        
        
        select @nbligne=0
        select @nbligne=count(*) from #FCCL_GROUPE  
        
 select #FCCL_GROUPE.CCLCODE, #FCCL_GROUPE.CCLARTICLE, #FCCL_GROUPE.QTE_CDE, #FCCL_GROUPE.QTE_A_PREPARER, #FCCL_GROUPE.COLISAGE, #FCCL_GROUPE.QTE_PREPARER_COLIS, #FCCL_GROUPE.ARTYPE from #FCCL_GROUPE
        if (@nbligne>0)
        begin
                delete from #FCCL_GROUPE where (QTE_PREPARER_COLIS=0 or COLISAGE<1)
                update #FCCL_GROUPE set QTE_A_PREPARER=QTE_PREPARER_COLIS 
                
                
                select  RCCARTICLE,sum(RCCQTE) as RCCQTE 
                into #FRCC
                from VIEW_FRCC_BLOQUE,#FCCL_GROUPE
                where RCCARTICLE=CCLARTICLE
                and isnull(RCCDEPOTRES,'')=@depot
                group by RCCARTICLE
                
                create index FRCC_idx0001 on #FRCC(RCCARTICLE)

                
                select STAR, STLETTRE, STQTE,STDEPOT,isnull(ST_QTE_RSRV,0) as ST_QTE_RSRV,STLOT,STQTE- isnull(ST_QTE_RSRV,0) as STOCK_DISPO
                into #STOCK
                from VIEW_FSTOCK,#FCCL_GROUPE                
                where STDEPOT=@depot
                and STAR =CCLARTICLE

                create index stock_idx0001 on #STOCK(STAR)
                create index stock_idx0002 on #STOCK(STLETTRE)
                create index stock_idx0003 on #STOCK(STDEPOT)  

                
                                 
                select distinct #STOCK.STAR,#STOCK.STLETTRE,#STOCK.STDEPOT,#STOCK.STLOT,ARESSEMP
                into #stockAvecSSemp
                from #STOCK,#VIEW_STOCK_LOT_EMPLACEMENT
                where #STOCK.STAR=#VIEW_STOCK_LOT_EMPLACEMENT.STEMPAR
                and #STOCK.STLETTRE=#VIEW_STOCK_LOT_EMPLACEMENT.STLETTRE
                and #STOCK.STDEPOT=#VIEW_STOCK_LOT_EMPLACEMENT.STEMPDEPOT

                create index stockAvecSSemp_idx0001 on #stockAvecSSemp(STAR)
                create index stockAvecSSemp_idx0002 on #stockAvecSSemp(STLETTRE)
                create index stockAvecSSemp_idx0003 on #stockAvecSSemp(STDEPOT)  
                
                delete from #STOCK
                from #STOCK,#stockAvecSSemp
                where #STOCK.STAR=#stockAvecSSemp.STAR
                and #STOCK.STLETTRE=#stockAvecSSemp.STLETTRE
                and #STOCK.STDEPOT=#stockAvecSSemp.STDEPOT
                and ARESSEMP in ('GAFR','GF--')
                
                

                drop table #stockAvecSSemp   
                             
                
                select STAR,sum(STOCK_DISPO)as STOCK_DISPO
                into #stockTotal
                from #STOCK
                group by STAR
                
                update #stockTotal set STOCK_DISPO=STOCK_DISPO-RCCQTE
                from #stockTotal,#FRCC
                where RCCARTICLE=STAR
                
                select CCLCODE, CCLARTICLE, QTE_CDE,   QTE_A_PREPARER, COLISAGE, isnull(STOCK_DISPO,0) as STOCK_DISPO,ARTYPE
                into #resultat
                from #FCCL_GROUPE,#stockTotal
                where CCLARTICLE*=STAR
                

                delete from #resultat where   (QTE_A_PREPARER<=0 or STOCK_DISPO<QTE_A_PREPARER or QTE_A_PREPARER<COLISAGE)       


                select CCLCODE, CCLARTICLE, QTE_CDE,  QTE_A_PREPARER, COLISAGE, STOCK_DISPO,ARTYPE ,'Transfert('||convert(varchar,QTE_A_PREPARER-STOCK_DISPO)||')' as TRANSFERT
                into #attenteTransfert
                from #resultat
                where QTE_A_PREPARER>STOCK_DISPO
                and ARTYPE=0
                


                
                select STEMPAR,STLETTRE ,sum(STEMPQTE) as STEMPQTE,NLOTDATEPER ,STEMPEMP,STLOT ,STEMPDEPOT,ARESSEMP
                into #StockTmp1
                from #VIEW_STOCK_LOT_EMPLACEMENT,#resultat
                where STEMPAR =CCLARTICLE
                and STEMPDEPOT=@depot
                group by STEMPAR,NLOTDATEPER,STLETTRE,STEMPEMP,STLOT,STEMPDEPOT,ARESSEMP
                order by STEMPAR,NLOTDATEPER,STLETTRE,STEMPEMP,STLOT,STEMPDEPOT,ARESSEMP
                
                delete from #StockTmp1 where ARESSEMP in ('GAFR','GF--')
                

                
                select RBPARTICLE,RBPDEPOT,RBPLETTRE,sum(RBPQTE) as RBPQTE
                into #FRBP
                from FRBP,#resultat
                where RBPARTICLE =CCLARTICLE
                and RBPDEPOT=@depot
                group by RBPARTICLE,RBPDEPOT,RBPLETTRE
                
                
                 update #StockTmp1 set STEMPQTE=STEMPQTE-RBPQTE
                 from #StockTmp1,#FRBP
                 where STEMPAR=RBPARTICLE
                 and STEMPDEPOT=RBPDEPOT
                 and STLETTRE=RBPLETTRE
                 
                 
                delete from #StockTmp1 where STEMPQTE<=0                

                
               
                declare 	@qteST 			int,
                                @articleST 		char(15),
                                @lettreST 		char(4),
                                @qtealivrer		int,
                                @emplacement	        char(8),
                                @lot			char(12),
                                @dep			char(4),
                                @seq			numeric(14,0),
                                @resteapreparer	        int,
                                @stockRSRV_FSTOCK       int,
                                @datePer                date,
                                @stocktotal             int
                        
                
                declare stockTmp cursor for select STEMPAR,STLETTRE,STEMPQTE,NLOTDATEPER,STEMPEMP,STLOT,STEMPDEPOT from #StockTmp1 
                open stockTmp
                fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@dep
                while (@@sqlstatus=0)
                begin
                        select @stockRSRV_FSTOCK=0
                        select @stockRSRV_FSTOCK=isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #STOCK  where STAR=@articleST and STDEPOT=@depot and STLETTRE= @lettreST
                        select @qteST=@qteST-@stockRSRV_FSTOCK
                        
                        insert into #stockFinal(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT) values (@articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot)
                        
                        fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@dep
                end
                close stockTmp
                deallocate cursor stockTmp
                        
                delete from #stockFinal where QteLoc<=0


               
                
               
               
                declare liste cursor for select CCLARTICLE,QTE_A_PREPARER from #resultat where STOCK_DISPO>=QTE_A_PREPARER and ARTYPE=0
                open liste
                fetch liste into @CCLARTICLE,@APREPARER
                while (@@sqlstatus=0)
                begin
                        
                        declare ligneCommande cursor for select CCLSEQ,CCLQTE-CCLQTEPREP from #FCCL where CCLARTICLE=@CCLARTICLE order by CCLQTE desc 
                        open ligneCommande
                        fetch ligneCommande into @CCLSEQ,@CCLQTE
                        while (@@sqlstatus=0)
                        begin
                                if(@APREPARER>=@CCLQTE)
                                begin
                                        select @CCLQTE_APREPARER=@CCLQTE
                                end
                                else
                                begin
                                        select @CCLQTE_APREPARER=@APREPARER
                                end

                                insert into #cclFinal values (@CCLSEQ,@CCLARTICLE,@CCLQTE,@CCLQTE_APREPARER)
                                select @APREPARER=@APREPARER-@CCLQTE
                                
                                if (@APREPARER<=0)
                                begin
                                        break
                                end
                                
                                fetch ligneCommande into @CCLSEQ,@CCLQTE
                        end
                        close ligneCommande 
                        deallocate cursor ligneCommande
                        
                        fetch liste into @CCLARTICLE,@APREPARER
                end
                close liste 
                deallocate cursor liste
                


                insert into #Prep
                select #cclFinal.CCLSEQ,CCLCODE,CCLNUM,CCLDATE,#cclFinal.CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
                        substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
                        ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
                        isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
                        isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,''),isnull(CCLCOLISAGE,''),isnull(CCLNBCOLIS,0),isnull(CCLPACK,0),
                        CCLQTE_APREPARER
                from #cclFinal,#FCCL,VIEW_FAR,FCC
                where #cclFinal.CCLSEQ=#FCCL.CCLSEQ
                and ARCODE=#cclFinal.CCLARTICLE
                and CCLCODE=CCCODE
                
                declare commandes cursor for
                        select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCL_APREPARER,ARLIB,
                        ARUNITFACT,CCLPHT,MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,CCLOFFERT,
                        ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
                        CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,ARCOMP,CCLQTEPREP,CCLATTACHE,ARREFFOUR,CCLMARCHE,CCLCOLIS,ARQTECOLIS,CCLPAHT,CCL_LIBSEQ,CCL_COMMENT_MAG,CCLCOLISAGE,CCLNBCOLIS,CCLPACK
                        from #Prep
                        order by CCLDATE,CCLSEQ
                        for read only
                
                open commandes
                fetch commandes
                into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
                        @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
                        @CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV ,
                        @CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
                        @CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK

                while (@@sqlstatus = 0)
                begin
                        
                                        select @resteapreparer = @CCLRESTE
                                        select @stocktotal= isnull(sum(QteLoc),0) from #stockFinal where STEMPAR=@CCLARTICLE 
                                
                                        
                                        select STEMPAR, STEMPLETTRE, QteLoc, STEMPDATE, STEMPEMP, STEMPLOT, STEMPDEPOT, SEQ  
                                        into #stockTmp
                                        from #stockFinal 
                
                                        
                                        declare ligneStock cursor for select STEMPAR,STEMPLETTRE,QteLoc,STEMPEMP,STEMPLOT,STEMPDEPOT,SEQ from #stockTmp where STEMPAR=@CCLARTICLE  order by SEQ
                                        open ligneStock
                                        fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                                        while (@@sqlstatus=0)
                                        begin
                                                if(@ARTYPE<>0)
                                                begin
                                                        select @qtealivrer=@resteapreparer
                                                        select @resteapreparer=0
                                                end
                                                else
                                                begin
                                                        if(@qteST>=@resteapreparer)
                                                        begin
                                                                select @qtealivrer=@resteapreparer
                                                                update #stockFinal set QteLoc=QteLoc-@qtealivrer where SEQ = @seq
                                                                select @resteapreparer=0
                                                        end
                                                        else 
                                                        begin
                                                                select @qtealivrer=@qteST
                                                                update #stockFinal set QteLoc=0 where SEQ = @seq
                                                                select @resteapreparer= @resteapreparer-@qtealivrer
                        
                                                        end
                                                  end      
                                                        
                                                        insert into #Liste (Article,Lettre,Designation,LienCode,LienNum,Qte,
                                                                                                  UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,
                                                                                                  Reglement,Echeancesp,Factman,Offert,Artype,
                                                                                                  Devise,Coursdev,PrixHTdev,TotHTdev,Rem1,Rem2,Rem3,
                                                                                                  TotPrixHT,Emplacement,Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,seqLib,comment_mag,cclcolisage,cclnbcolis,cclpack)
                                                        select @articleST,@lettreST,@ARLIB,@CCLCODE,@CCLNUM,@qtealivrer,
                                                                                                  @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,
                                                                                                  @CCLTV,@ARREGLE,@CCLECHSPE,@CCLFACTMAN,@CCLOFFERT,@ARTYPE,
                                                                                                  @CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,@CCLR1,@CCLR2,@CCLR3,
                                                                                                  @CCLTOTALHT,@emplacement,@CCLATTACHE,@lot,@ARREFFOUR,@CCLMARCHE,@CCLDATE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK
                                                
                                                if @resteapreparer<=0 break
                                                
                                                fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                                        end
                                        close ligneStock
                                        deallocate cursor ligneStock
                                    
                        
                             
                                        drop table #stockTmp
                
                        fetch commandes
                        into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
                        @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
                        @CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
                        @CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
                        @CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK
                end
                
                close commandes
                deallocate cursor commandes


                delete from #Liste
                where Artype=4
                and not exists (select * from #Liste as b where #Liste.LienCode=b.LienCode and b.Artype <> 4)
                and not exists (select * from FCCL,FAR where CCLCODE=#Liste.LienCode and ARCODE=CCLARTICLE and CCLRESTE > 0 and (ARNUMEROTE=1 or ARCOMP=2))

                
                select #resultat.CCLCODE, #resultat.CCLARTICLE,ARLIB, #resultat.QTE_CDE,  #resultat.QTE_A_PREPARER, #resultat.COLISAGE, #resultat.STOCK_DISPO ,isnull(TRANSFERT,'') as TRANSFERT,case when (isnull(TRANSFERT,'')='') then 1 else 0 end,
                case when isnull(bgArticle,'')<>'' then 1 else 0 end 
                from #resultat,#attenteTransfert,VIEW_FAR,bPrepGros
                where #resultat.CCLARTICLE*=#attenteTransfert.CCLARTICLE
                and ARCODE=#resultat.CCLARTICLE and #resultat.CCLARTICLE*=bgArticle
                
                
                select Article,Lettre,rtrim(Designation) as Designation,LienCode,LienNum,Qte,
                           UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,Reglement,
                           Echeancesp,abs(Qte),Factman,isnull(Offert,0),isnull(Artype,0),
                           isnull(Devise,''),isnull(Coursdev,0),isnull(PrixHTdev,0),
                           isnull(TotHTdev,0),Rem1,Rem2,Rem3,TotPrixHT,Emplacement,
                           Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,'',0,0,0,0,0,0,'','','',0,'','',0,'','','',0,0,0,seqLib,comment_mag,cclcolisage,cclnbcolis,cclpack
                from #Liste
                where Qte > 0
                order by LienCode,LienNum

                
                select   CCLARTICLE, VIEW_SANS_EMPL.ARLIB, STEMPDEPOT,STEMPEMP,ARESSEMP
                from #cclFinal,VIEW_SANS_EMPL,VIEW_FAR
                where STEMPAR=CCLARTICLE 
                and STEMPDEPOT=@depot 
                and CCLARTICLE=ARCODE
                and ARTYPE=0

                
        end        
        
     /*   drop table #FCCL
        drop table #FCCL_GROUPE
        drop table #VIEW_STOCK_LOT_EMPLACEMENT
        drop table #FRCC
        drop table #STOCK
        drop table #stockTotal
        drop table #attenteTransfert
        drop table #FRBP
        drop table #StockTmp1
        drop table #cclFinal
        
        */
end
go

