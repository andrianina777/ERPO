


/* Procedure specifique Rivolier */

create procedure RFA_Fiocchi (@ent		char(5)	= null,
							  @an		smallint)
with recompile
as
begin

set arithabort numeric_truncation off

create table #Finale
(
Client		char(12)	not null,
Famille		char(8)		not null,
Quantite	int				null,
Valeur		int				null,
DroitRFA	int				null,
PotRFA		int				null
)


/* Calcul du CA total */

insert into	#Finale (Client,Famille,Quantite,Valeur,DroitRFA,PotRFA)
select 	STCL,ARFAM,isnull(sum(STQTEFA),0),isnull(sum(STCAFA),0),0,isnull(sum(STCAFA),0)*0.05
from FST,FAR
where STAN=@an
and ARCODE=START
and ARTYPE in (0,1)
and ARFAM in ('MUNCFI','MUNTFI')
and (@ent is null or STENT=@ent)
group by STCL,ARFAM


/* Maj du droit a la RFA */

update #Finale
set DroitRFA=(case when Famille='MUNCFI' and Quantite >= 5000 then Valeur*0.05
				   when Famille='MUNTFI' and Quantite >= 30000 then Valeur*0.05
				   else 0 end)


select Client,Famille,Quantite,Valeur,DroitRFA,PotRFA
from #Finale
where Valeur > 0
order by Client,Famille
compute sum(DroitRFA),sum(PotRFA) by Client
compute sum(DroitRFA),sum(PotRFA)

end



go

