


/* Procedure generant les lignes de mouvements eclates
	des reajustements									 */

create procedure MouvReajust (@Fournisseur	char(12)	= null,
							@Famille		char(8)		= null,
							@Article		char(15)	= null,
							@DuMois			tinyint,
							@AuMois			tinyint,
							@Annee			smallint,
							@Depot			tinyint,
							@depart			char(8)		= null)
with recompile
as
begin

set arithabort numeric_truncation off


/* 	@Depot = 0 => tout le stock 
	@Depot = 1 => le stock local
	@Depot = 2 => le stock sous douanes
*/

declare @MoisPrecedent	tinyint
declare @AnneeInit		smallint
declare @count			int


if (@DuMois=1)
	begin
	select @MoisPrecedent=12
	select @AnneeInit=@Annee-1
	end
else
	begin
	select @MoisPrecedent=@DuMois-1
	select @AnneeInit=@Annee
	end
	
/******* table des articles ******/
	
create table #FAR
(
ARCODE	char(15)		not null,
ARFO	char(12)			null,
ARFAM	char(8)				null,
ARLIB	varchar(80)			null
)

/******* table de l''inventaire initial ******/

create table #Init
(
ArticleInit		char(15)		not null,
QuantiteInit	int					null,
CoutInit		numeric(14,2)		null,
DepotInit		tinyint			not null
)


/******* table des mouvements reajustes pendant la periode ******/

create table #RM
(
ArticleRM	char(15)		not null,
QuantiteRM	int					null,
CoutRM		numeric(14,2)		null,
DepotRM		tinyint			not null
)

/******* table des fluctuations pendant la periode ******/

create table #SI
(
ArticleSI	char(15)		not null,
QuantiteSI	int					null,
CoutSI		numeric(14,2)		null,
DepotSI		tinyint			not null
)

/******* table des valeurs reajustees pendant la periode ******/

create table #RJ
(
ArticleRJ	char(15)		not null,
QuantiteRJ	int					null,
CoutRJ		numeric(14,2)		null,
DepotRJ		tinyint			not null
)

/******* table des lignes de casse pendant la periode ******/

create table #LC
(
ArticleLC	char(15)		not null,
QuantiteLC	int					null,
CoutLC		numeric(14,2)		null,
DepotLC		tinyint			not null
)

/******* table des assemblages pendant la periode ******/

create table #AS
(
ArticleAS	char(15)		not null,
QuantiteAS	int					null,
CoutAS		numeric(14,2)		null,
DepotAS		tinyint			not null
)

/******* table finale ******/

create table #Final
(
Article		char(15)		not null,
QteInit		int				null,
ValeurInit	numeric(14,2)	null,
QteRM		int				null,
ValeurRM	numeric(14,2)	null,
QteSI		int				null,
ValeurSI	numeric(14,2)	null,
QteRJ		int				null,
ValeurRJ	numeric(14,2)	null,
QteLC		int				null,
ValeurLC	numeric(14,2)	null,
QteAS		int				null,
ValeurAS	numeric(14,2)	null,
Depot		tinyint		not null
)

/******************* Traitement ********************/

select @count=count(*) from FMOIS
where MOISMOIS=@MoisPrecedent
and MOISANNEE=@AnneeInit


if (@count=0)	/* si le mois precedent n''a pas ete stocke, renvoie -1 sur @count */
	begin
	select @count=-1
	select '','','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,'','','',@count
	end
else
	begin


	 if ((@Fournisseur is null) and (@Famille is null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is null) and (@Famille is null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is null) and (@Famille is not null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFAM=@Famille
			 and (@depart is null or ARDEPART=@depart)
		 end	
	 else if ((@Fournisseur is null) and (@Famille is not null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFAM=@Famille
			 and ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end		
	 else if ((@Fournisseur is not null) and (@Famille is null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is not null) and (@Famille is null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is not null) and (@Famille is not null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and ARFAM=@Famille
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is not null) and (@Famille is not null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and ARFAM=@Famille
			 and ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 
	 
	 create unique clustered index article on #FAR(ARCODE)
	 
	 
	 /****** Information initiale stockee le mois precedent dans FMOIS ******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #Init (ArticleInit,QuantiteInit,CoutInit,DepotInit)
			 select MOISARTICLE,MOISQTE,MOISTOTPR,MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@AnneeInit
			 and MOISMOIS=@MoisPrecedent
			 and MOISQTE != 0
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #Init (ArticleInit,QuantiteInit,CoutInit,DepotInit)
			 select MOISARTICLE,MOISQTE,MOISTOTPR,MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@AnneeInit
			 and MOISMOIS=@MoisPrecedent
			 and MOISDEPOT=1
			 and MOISQTE != 0
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Init (ArticleInit,QuantiteInit,CoutInit,DepotInit)
			 select MOISARTICLE,MOISQTE,MOISTOTPR,MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@AnneeInit
			 and MOISMOIS=@MoisPrecedent
			 and MOISDEPOT in (0,2)
			 and MOISQTE != 0
		 end
	 
	 create clustered index ardep on #Init (ArticleInit,DepotInit)
	 
	 
	 /******* Calcul des mouvements reajustes pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #RM (ArticleRM,QuantiteRM,CoutRM,DepotRM)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSQTE!=0
			 and MSTYPE='M'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #RM (ArticleRM,QuantiteRM,CoutRM,DepotRM)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSQTE!=0
			 and MSTYPE='M'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #RM (ArticleRM,QuantiteRM,CoutRM,DepotRM)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSQTE!=0
			 and MSTYPE='M'
			 group by MSARTICLE,MSDEPOT	
		 end
	 
	 create clustered index ardep on #RM (ArticleRM,DepotRM)
	 
	 /******* Calcul des fluctuations pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #SI (ArticleSI,QuantiteSI,CoutSI,DepotSI)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSQTE!=0
			 and MSTYPE='F'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #SI (ArticleSI,QuantiteSI,CoutSI,DepotSI)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSQTE!=0
			 and MSTYPE='F'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #SI (ArticleSI,QuantiteSI,CoutSI,DepotSI)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSQTE!=0
			 and MSTYPE='F'
			 group by MSARTICLE,MSDEPOT	
		 end
	 
	 
	 create clustered index ardep on #SI (ArticleSI,DepotSI)
	 
	 /******* Calcul des valeurs reajustees pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #RJ (ArticleRJ,QuantiteRJ,CoutRJ,DepotRJ)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSQTE!=0
			 and MSTYPE='R'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #RJ (ArticleRJ,QuantiteRJ,CoutRJ,DepotRJ)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSQTE!=0
			 and MSTYPE='R'
			 group by MSARTICLE,MSDEPOT
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #RJ (ArticleRJ,QuantiteRJ,CoutRJ,DepotRJ)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSQTE!=0
			 and MSTYPE='R'
			 group by MSARTICLE,MSDEPOT
		 end
	 
	 create clustered index ardep on #RJ (ArticleRJ,DepotRJ)
	 
	 
	 /******* Calcul des lignes de casse pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #LC (ArticleLC,QuantiteLC,CoutLC,DepotLC)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSQTE!=0
			 and MSTYPE='C'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #LC (ArticleLC,QuantiteLC,CoutLC,DepotLC)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSQTE!=0
			 and MSTYPE='C'
			 group by MSARTICLE,MSDEPOT
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #LC (ArticleLC,QuantiteLC,CoutLC,DepotLC)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSQTE!=0
			 and MSTYPE='C'
			 group by MSARTICLE,MSDEPOT
		 end
	 
	 create clustered index ardep on #LC (ArticleLC,DepotLC)
	 
	 
	 /******* Calcul des assemblages pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #AS (ArticleAS,QuantiteAS,CoutAS,DepotAS)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSQTE!=0
			 and MSTYPE='A'
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #AS (ArticleAS,QuantiteAS,CoutAS,DepotAS)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSQTE!=0
			 and MSTYPE='A'
			 group by MSARTICLE,MSDEPOT
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #AS (ArticleAS,QuantiteAS,CoutAS,DepotAS)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSQTE!=0
			 and MSTYPE='A'
			 group by MSARTICLE,MSDEPOT
		 end
	 
	 create clustered index ardep on #AS (ArticleAS,DepotAS)
	 
	 
	 /* Creation du fichier final avec insertion des articles de #Init et de #Reajust */
	 
	 
	 insert into #Final (Article,QteInit,ValeurInit,QteRM,ValeurRM,QteSI,
			 ValeurSI,QteRJ,ValeurRJ,QteLC,ValeurLC,QteAS,ValeurAS,Depot)
	 select ArticleInit,QuantiteInit,CoutInit,0,0,0,0,0,0,0,0,0,0,DepotInit
	 from #Init
	 
	 drop table #Init
	 
	 create clustered index ardep on #Final(Article,Depot)
	 
	 /* Insertion dans #Final des articles de mouvements reajustes sans correpondance dans #Final */
	 
	 insert into #Final (Article,QteInit,ValeurInit,QteRM,ValeurRM,QteSI,
			 ValeurSI,QteRJ,ValeurRJ,QteLC,ValeurLC,QteAS,ValeurAS,Depot)
	 select ArticleRM,0,0,0,0,0,0,0,0,0,0,0,0,DepotRM
	 from #RM
	 where not exists (select * from #Final 
					   where Article=#RM.ArticleRM
					   and Depot=#RM.DepotRM)
	 
	 /* Mise a jour de #Final avec les valeurs de #RM */
	 
	 update #Final
	 set QteRM=QuantiteRM,ValeurRM=CoutRM
	 from #RM
	 where Article=ArticleRM
	 and Depot=DepotRM
	 
	 drop table #RM
	 
	 /* Insertion dans #Final des articles fluctues sans correpondance dans #Final */
	 
	 insert into #Final (Article,QteInit,ValeurInit,QteRM,ValeurRM,QteSI,
			 ValeurSI,QteRJ,ValeurRJ,QteLC,ValeurLC,QteAS,ValeurAS,Depot)
	 select ArticleSI,0,0,0,0,0,0,0,0,0,0,0,0,DepotSI
	 from #SI
	 where not exists (select * from #Final 
					   where Article=#SI.ArticleSI
					   and Depot=#SI.DepotSI)
	 
	 /* Mise a jour de #Final avec les valeurs de #SI */
	 
	 update #Final
	 set QteSI=QuantiteSI,ValeurSI=CoutSI
	 from #SI
	 where Article=ArticleSI
	 and Depot=DepotSI
	 
	 drop table #SI
	 
	 /* Insertion dans #Final des articles reajustes sans correpondance dans #Final */
	 
	 insert into #Final (Article,QteInit,ValeurInit,QteRM,ValeurRM,QteSI,
			 ValeurSI,QteRJ,ValeurRJ,QteLC,ValeurLC,QteAS,ValeurAS,Depot)
	 select ArticleRJ,0,0,0,0,0,0,0,0,0,0,0,0,DepotRJ
	 from #RJ
	 where not exists (select * from #Final 
					   where Article=#RJ.ArticleRJ
					   and Depot=#RJ.DepotRJ)
	 
	 /* Mise a jour de #Final avec les valeurs de #RJ */
	 
	 update #Final
	 set QteRJ=QuantiteRJ,ValeurRJ=CoutRJ
	 from #RJ
	 where Article=ArticleRJ
	 and Depot=DepotRJ
	 
	 drop table #RJ
	 
	 /* Insertion dans #Final des articles casses sans correpondance dans #Final */
	 
	 insert into #Final (Article,QteInit,ValeurInit,QteRM,ValeurRM,QteSI,
			 ValeurSI,QteRJ,ValeurRJ,QteLC,ValeurLC,QteAS,ValeurAS,Depot)
	 select ArticleLC,0,0,0,0,0,0,0,0,0,0,0,0,DepotLC
	 from #LC
	 where not exists (select * from #Final 
					   where Article=#LC.ArticleLC
					   and Depot=#LC.DepotLC)
	 
	 /* Mise a jour de #Final avec les valeurs de #LC */
	 
	 update #Final
	 set QteLC=QuantiteLC,ValeurLC=CoutLC
	 from #LC
	 where Article=ArticleLC
	 and Depot=DepotLC
	 
	 drop table #LC
	 
	 /* Insertion dans #Final des articles assembles sans correpondance dans #Final */
	 
	 insert into #Final (Article,QteInit,ValeurInit,QteRM,ValeurRM,QteSI,
			 ValeurSI,QteRJ,ValeurRJ,QteLC,ValeurLC,QteAS,ValeurAS,Depot)
	 select ArticleAS,0,0,0,0,0,0,0,0,0,0,0,0,DepotAS
	 from #AS
	 where not exists (select * from #Final 
					   where Article=#AS.ArticleAS
					   and Depot=#AS.DepotAS)
	 
	 /* Mise a jour de #Final avec les valeurs de #AS */
	 
	 update #Final
	 set QteAS=QuantiteAS,ValeurAS=CoutAS
	 from #AS
	 where Article=ArticleAS
	 and Depot=DepotAS
	 
	 drop table #AS
	 
	 /* Mise a jour des valeurs finales de #Final */
	 
	 select Article=Article,QteInit=isnull(sum(QteInit),0),ValeurInit=isnull(sum(ValeurInit),0),
		 QteRM=isnull(sum(QteRM),0),ValeurRM=isnull(sum(ValeurRM),0),
		 QteSI=isnull(sum(QteSI),0),ValeurSI=isnull(sum(ValeurSI),0),
		 QteRJ=isnull(sum(QteRJ),0),ValeurRJ=isnull(sum(ValeurRJ),0),
		 QteLC=isnull(sum(QteLC),0),ValeurLC=isnull(sum(ValeurLC),0),
		 QteAS=isnull(sum(QteAS),0),ValeurAS=isnull(sum(ValeurAS),0),
		 QteTotale=sum(isnull(QteRM,0)+isnull(QteSI,0)+isnull(QteRJ,0)+isnull(QteLC,0)+isnull(QteAS,0)),
		 ValeurTotale=sum(isnull(ValeurRM,0)+isnull(ValeurSI,0)+isnull(ValeurRJ,0)+isnull(ValeurLC,0)+isnull(ValeurAS,0))
	 into #Final2
	 from #Final
	 group by Article
	 
	 drop table #Final
	 
	 update #Final2
	 set ValeurTotale=0
	 where QteTotale=0
	 
	 
	 
	 select @count=count(*) from #Final2
	 
	 if @count>0
	   begin
		 select Article,ARFAM,ARFO,
		 QteInit,ValeurInit,round(ValeurInit/(QteInit+(1-abs(sign(QteInit)))),2),
		 QteRM,ValeurRM,
		 QteSI,ValeurSI,
		 QteRJ,ValeurRJ,
		 QteLC,ValeurLC,
		 QteAS,ValeurAS,
		 QteTotale,ValeurTotale,round(ValeurTotale/(QteTotale+(1-abs(sign(QteTotale)))),2),
		 ARLIB,FPLIB,FONOM,@count
		 from #Final2,#FAR,FFP,FFO
		 where Article=ARCODE
		 and ARFAM=FPCODE
		 and ARFO=FOCODE
		 order by ARFO,ARFAM,Article
	   end
	  else
	   begin
		 select '','','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'','','',@count
	   end
	 
	   
	  drop table #FAR
	  drop table #Final2
 
	end		/* else de if (@count=0) */
end



go

