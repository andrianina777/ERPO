


/* Procedure utilisee par les triggers qui mettent a jour le stock.
	Genere le code stock lettre AAAA	*/

create procedure ARNextLettre (@Code 		char(15),
							   @lettreout 	char(4) output)
with recompile
as
begin

	declare @longueur 	tinyint
	declare @compt		tinyint
	declare @car		char(1)
	declare @lettre		char(4)
	
	begin tran NEXTLETTRE

	select @lettreout=ARNEXTLETTRE from FAR holdlock where ARCODE=@Code

	if isnull(@lettreout,'')=''
	begin
		select @lettreout='AAAA'
	end

	select @lettre=@lettreout
	select @longueur=datalength(@lettre)
	select @compt=0
	select @car=''
	if substring(@lettre,4,1)=' ' 	select @longueur=3
	else							select @longueur=4


	if @longueur=3
	begin
		if @lettreout in ('ZZZ','ZZ2','ZZ3','ZZ4','ZZ5','ZZ6','ZZ7','ZZ8','ZZ9')
		begin
			select @lettre='AAAA'
		end
		else
		begin
			while @longueur!=0
			begin
				select @car=substring(@lettre,@longueur,1)
				select @compt=charindex(@car,'ABCDEFGHIJKLMNOPQRSTUVWXYZ23456789')
				select @car=substring('BCDEFGHIJKLMNOPQRSTUVWXYZAAAAAAAAA',@compt,1)
				select @lettre=substring(@lettre,1,@longueur-1)+@car+substring(@lettre,@longueur+1,3)
				if @car='A'
					select @longueur=@longueur-1
				else
					select @longueur=0
			end
		end
	end
	else if @longueur=4
	begin
	while @longueur!=0
		begin
			select @car=substring(@lettre,@longueur,1)
			select @compt=charindex(@car,'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
			select @car=substring('BCDEFGHIJKLMNOPQRSTUVWXYZA',@compt,1)
			select @lettre=substring(@lettre,1,@longueur-1)+@car+substring(@lettre,@longueur+1,4)
			if @car='A'
				select @longueur=@longueur-1
			else
				select @longueur=0
		end
	end

	
	update FAR set ARNEXTLETTRE=@lettre where ARCODE=@Code
	
	
	commit tran NEXTLETTRE

end



go

