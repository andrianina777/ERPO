


create proc CheckResa
as
begin

	/* rercherche et suppression des dates de reservation arriveees a echeances */
	/* *********************************************************************** */

	select "1.Suppression quotidienne des reservations arrivees a la date limite :"

	select CCLCODE,CCLNUM,CCLCL,CCLDATE,CCLARTICLE,CCLQTE,CCLQTEEXP,CCLQTERES from FCCL
	where CCLDATERESFIN<=getdate() and CCLQTERES>0

	update FCCL set CCLQTERES=null,CCLDATERESFIN=null,CCLDEPOTRES=null 
	where CCLDATERESFIN<=getdate() and CCLQTERES>0

	/* recherche et presentation des incoherences de reservations (dans le cas d''un mouvement de stock annexe) */
	/* ******************************************************************************************************* */

	select RCCARTICLE,RCCDEPOTRES,QTERES=sum(isnull(RCCQTERES,0)) into #resa from FRCC
	group by RCCARTICLE,RCCDEPOTRES 

	select STAR,STDEPOT,QTESTOCK=sum(isnull(STQTE,0)) into #stock from FSTOCK
	group by STAR,STDEPOT


	select "2.Anomalie : Stock reserve > Stock total :"

	select STAR,STDEPOT,QTERES,QTESTOCK,QTESTOCK-QTERES from #resa,#stock 
	where STAR=RCCARTICLE and STDEPOT=RCCDEPOTRES and QTERES>QTESTOCK

	select "3.Anomalie : Stock reserve restant sur une ligne de commande expediee :"

	select CCLCODE,CCLNUM,CCLARTICLE,QTE_CC=CCLQTE,QTE_EXP=CCLQTEEXP,QTE_RES=CCLQTERES
	from FCCL
	where isnull(CCLQTERES,0)>0 and isnull(CCLRESTE,0)=0
end



go

