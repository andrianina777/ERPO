
create procedure ChoixCdesDA (@type       tinyint, 			/* 0 : pointage DC DA 1 : pointage CF DC */ 
							  @ent        char(5) 	= null, 
							  @article    char(15), 
							  @fournis    char(12)	= null 
							 ) 
with recompile 
 
as 
begin 
 
create table #Da 
( 
article char(15)    not null, 
qte     int     	not null, 
recu    int     	not null, 
reste   int     	not null, 
code    char(10)    not null, 
num     int         not null
) 
 
insert into #Da (article,qte,recu,reste,code,num) 
select CBFARTICLE,0,0,sum(-CBFQTE),CBFCODE,CBFNUM 
from FCBF 
where CBFARTICLE=@article 
and (@ent is null or CBFENT=@ent) 
group by CBFARTICLE,CBFCODE,CBFNUM 
having sum (-CBFQTE) != 0 
union 
select DALARTICLE,DALQTE,DALRECU,DALRESTE,DALCODE,DALNUM 
from FRDA,FDAL,FDA 
where RDASEQ=DALSEQ 
and RDAARTICLE=@article 
/*and (@fournis is null or RDAFO=@fournis) */
and (@fournis is null or exists (select * from FARF where ARFCODE=@article and ARFFO=@fournis)) /* Patch LL 2008/02 pour permettre le pointage d'une ligne sur un autre frs en veillant au respect FARF */
and DACODE=DALCODE 
and isnull(DAVALIDE,0)=0 
and isnull(DASTATUS,0)=@type 
and (@ent is null or (RDAENT=@ent and DALENT=@ent and DAENT=@ent)) 

 
select article,sum(qte),sum(recu),sum(reste),code,num,DALDATEP,DALLIBRE,DALREFFO 
from #Da,FDAL 
where code=DALCODE 
and num=DALNUM+0 
and (@ent is null or DALENT=@ent) 
group by article,code,num,DALDATEP,DALLIBRE,DALREFFO 
having sum(reste) > 0 
order by DALDATEP 
 
drop table #Da 
 
end
go

