



create procedure CAAnnee   (@ent		char(5)			= null,
							@an			smallint,					/* annee */
							@client1	char(12) 		= null,		/* du client */
							@client2	char(12) 		= null,		/* au client */
							@sectact	char(6) 		= null,		/* code secteur d''activite */
							@repres		char(8) 		= null,		/* code representant general */
							@sectgeo 	char(8) 		= null,		/* code secteur geographique */
							@groupe		char(12) 		= null,		/* groupe du client */
							@fourchette	tinyint 		= null,		/* 0 = pas de fourchette, 1 = fourchette de CA */
							@tranchedeb	numeric(14,2) 	= null,		/* fourchette basse */
							@tranchefin	numeric(14,2) 	= null,		/* fourchette haute */
							@dep1		char(2) 		= null,		/* du departement */
							@dep2		char(2) 		= null,		/* au departement */
							@contrat	char(10) 		= null,		/* code du contrat */
							@agrement	tinyint			= null,		/* 1 = seulement clients avec autorisations */
							@depart		char(8)			= null,		/* departement produit */
							@marque		char(12)		= null,		/* marque produit */
							@famille	char(8)			= null,		/* famille produit */
							@article	char(15)		= null,		/* code produit */
							@pays		char(8)			= null,		/* code du pays */
							@status		tinyint			= 0,		/* 0 = tous les clients, 1 = sans les anciens clients */
							@chefp		char(8)			= null,		/* code chef de produit */
							@repdiv		char(8)			= null,		/* code representant division */
							@sansrfa	tinyint			= 1			/* 1 = sans la RFA */
							)

with recompile
as
begin
	
	set arithabort numeric_truncation off


	if (@tranchedeb	is null)
	begin
		select @tranchedeb=0
		select @tranchefin=0
	end
	
	if (@fourchette	is null)
	select @fourchette=0
	
	if (@agrement is null)
	select @agrement=0
	
	declare @date1	datetime,
			@date2	datetime
			
	select @date1=convert(datetime,"01/01/"+convert(varchar,@an))
	select @date2=convert(datetime,"12/31/"+convert(varchar,@an))
	
	create table #Cdes
	(
	client_cde		char(12)		not null,
	ca_cdes			numeric(14,2)	not null
	)
	
	create table #Be
	(
	client_be		char(12)		not null,
	ca_be			numeric(14,2)	not null
	)
	
	create table #Image
	(
	client_image	char(12)		not null,
	seq_image		numeric(18,0)	not null
	)
	
	create table #Far
	(
	depart	char(8)		not null,
	marque	char(12)	not null,
	famille	char(8)		not null,
	article	char(15)	not null
	)
	
	
	if (@depart != null or @marque != null or @famille != null or @article != null or @chefp != null)
	begin
	  insert into #Far (depart,marque,famille,article)
	  select ARDEPART,ARFO,ARFAM,ARCODE
	  from FAR
	  where (@depart is null or ARDEPART=@depart)
	  and (@marque is null or ARFO=@marque)
	  and (@famille is null or ARFAM=@famille)
	  and (@article is null or ARCODE=@article)
	  and (@chefp is null or ARCHEFP=@chefp)
	  and (@sansrfa = 0 or ARTYPE != 6)
	  
	  create unique clustered index art on #Far (article)
	end


	create table #Clients
	(
	Client			char(12)	not null,
	SectAct			char(6) 		null,
	Rep				char(8)			null,
	SectGeo			char(8)			null,
	Groupe			char(12) 		null,
	Dep				char(12)		null
	)
	
if isnull(@repdiv,"")=""

     begin	
          insert into #Clients(Client,SectAct,Rep,SectGeo,Groupe,Dep)
          select CLCODE,CLSA,CLREP,CLSECT,isnull(CLCODEGROUPE,''),CLCP
          from FCL
          where (@client1 is null or CLCODE between @client1 and @client2)
          and (@dep1 is null or substring(CLCP,1,2) between @dep1 and @dep2)
          and (@sectact is null or CLSA = @sectact)
          and (@repres is null or CLREP = @repres)
          and (@sectgeo is null or CLSECT = @sectgeo)
          and (@groupe is null or CLCODEGROUPE = @groupe)
          and (@pays is null or CLPY = @pays)
          and (@status=0 or CLSTATUS != 2)
          and (@ent is null or CLENT=@ent)
     end
else

     begin
     	  insert into #Clients(Client,SectAct,Rep,SectGeo,Groupe,Dep)
          select CLCODE,CLSA,CLREP,CLSECT,isnull(CLCODEGROUPE,''),CLCP
          from FCL
          where (@client1 is null or CLCODE between @client1 and @client2)
          and (@dep1 is null or substring(CLCP,1,2) between @dep1 and @dep2)
          and (@sectact is null or CLSA = @sectact)
          and (@repres is null or CLREP = @repres)
          and (@sectgeo is null or CLSECT = @sectgeo)
          and (@groupe is null or CLCODEGROUPE = @groupe)
          and (@pays is null or CLPY = @pays)
          and (@status=0 or CLSTATUS != 2)
          and (@ent is null or CLENT=@ent)
          and exists (select * from FCLR where CLRCL=FCL.CLCODE and CLRREPDIV=@repdiv)
          
     end


if (@contrat is not null)
	delete from #Clients
	where not exists (select * from FCT2 where CTCL=#Clients.Client 
										and CTAN=@an 
										and CTCODE=@contrat 
										and (@ent is null or CTENT=@ent))

if (@agrement=1)
	delete #Clients
	from FCL
	where CLCODE=Client
	and (CLNOAGR = "" or CLNOAGR is null)
	and (@ent is null or CLENT=@ent)

	create unique clustered index client on #Clients (Client)
	

	create table #CACL
	(
	Code	char(12)		not null,
	CA		numeric(14,2)		null
	)
		
	create unique clustered index client on #CACL (Code)

	
	/***** selection des CA *****/
	
	
	
	if (@depart = null and @marque = null and @famille = null and @article = null and @chefp = null)
	  insert into #CACL (Code,CA)
	  select STCL,sum(STCAFA)
	  from FST,#Clients,FAR
	  where STCL=Client
	  and STAN=@an
	  and START=ARCODE
	  and (@sansrfa = 0 or ARTYPE != 6)
	  and (@ent is null or STENT=@ent)
	  group by STCL
	else
	  insert into #CACL (Code,CA)
	  select STCL,sum(STCAFA)
	  from FST,#Clients,#Far
	  where STCL=Client
	  and STAN=@an
	  and START=article
	  and (@ent is null or STENT=@ent)
	  group by STCL
	
	
	/***** selection du portefeuille des commandes *******/
	
	if (@depart = null and @marque = null and @famille = null and @article = null and @chefp = null)
	  insert into #Cdes (client_cde,ca_cdes)
	  select RCCCL,sum(CCLTOTALHT/CCLQTE*RCCQTE)
	  from FRCC,#Clients,FAR,FCCL
	  where RCCCL=Client
	  and RCCSEQ=CCLSEQ
	  and RCCARTICLE=ARCODE
	  and (@sansrfa = 0 or ARTYPE != 6)
	  and (@repdiv = null or CCLREPDIV=@repdiv)
	  and (@ent is null or (CCLENT=@ent and RCCENT=@ent))
	  group by RCCCL
	else
	  insert into #Cdes (client_cde,ca_cdes)
	  select RCCCL,sum(CCLTOTALHT/CCLQTE*RCCQTE)
	  from FRCC,#Clients,#Far,FCCL
	  where RCCCL=Client
	  and RCCSEQ=CCLSEQ
	  and RCCARTICLE=article
	  and (@repdiv = null or CCLREPDIV=@repdiv)
	  and (@ent is null or (CCLENT=@ent and RCCENT=@ent))
	  group by RCCCL

	
	create unique index client on #Cdes (client_cde)
	
	
	insert into #CACL (Code,CA)
	select client_cde,0
	from #Cdes
	where not exists (select * from #CACL where Code=#Cdes.client_cde)
	
	

	/***** selection du portefeuille des Bons Expeditions *******/
	
	if @repdiv is null
	begin
	  if (@depart = null and @marque = null and @famille = null and @article = null and @chefp = null)
		insert into #Be (client_be,ca_be)
		select RBECL,sum(BELTOTALHT/BELQTE*RBEQTE)
		from FRBE,#Clients,FAR,FBEL
		where RBECL=Client
		and RBESEQ=BELSEQ
		and RBEARTICLE=ARCODE
		and (@sansrfa = 0 or ARTYPE != 6)
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		group by RBECL
	  else
		insert into #Be (client_be,ca_be)
		select RBECL,sum(BELTOTALHT/BELQTE*RBEQTE)
		from FRBE,#Clients,#Far,FBEL
		where RBECL=Client
		and RBESEQ=BELSEQ
		and RBEARTICLE=article
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		group by RBECL
	end
	else
	begin
	  if (@depart = null and @marque = null and @famille = null and @article = null and @chefp = null)
		insert into #Be (client_be,ca_be)
		select RBECL,sum(BELTOTALHT/BELQTE*RBEQTE)
		from FRBE,#Clients,FAR,FBEL,FCLR
		where RBECL=Client
		and RBESEQ=BELSEQ
		and RBEARTICLE=ARCODE
		and Client = CLRCL
		and (@sansrfa = 0 or ARTYPE != 6)
		and CLRREPDIV=@repdiv
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		group by RBECL
	  else
		insert into #Be (client_be,ca_be)
		select RBECL,sum(BELTOTALHT/BELQTE*RBEQTE)
		from FRBE,#Clients,#Far,FBEL,FCLR
		where RBECL=Client
		and RBESEQ=BELSEQ
		and RBEARTICLE=article
		and Client = CLRCL
		and CLRREPDIV=@repdiv
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		group by RBECL
	end
	
	create unique index cltbe on #Be (client_be)
	
	insert into #CACL (Code,CA)
	select client_be,0
	from #Be
	where not exists (select * from #CACL where Code=#Be.client_be)

	insert into #Image (client_image,seq_image)
	select XIMCODE_FICHE,isnull(XIMSEQ,0)
	from FXIM,#Clients
	where XIMTABLE = "FCL"
	and XIMCOLONNE = "CLCODE"
	and XIMCODE_FICHE = Client
	group by XIMCODE_FICHE
	having XIMINDICE = max(XIMINDICE)
	and XIMTABLE = "FCL"
	and XIMCOLONNE = "CLCODE"
	and XIMCODE_FICHE = Client

	
	drop table #Clients
	drop table #Far
			
	
	if (@fourchette=0)
	begin
		select CLNUMCOMPTABLE,CLCODE,CLNOM1,CLVILLE,isnull(CA,0),CLCOMREP,CLRAISONSOC,
			CLADR1,CLADR2,CLCP,CLSTATUS,CLREP,substring(CLCP,1,2),isnull(ca_cdes,0),isnull(ca_be,0),
			CLNOM2,CLNOM3,PYNOM,CLLOGIN,CLPASSWORD,CLAPE,CLTEL1,CLTELECOP1,CLEMAIL,isnull(seq_image,0)
		from #CACL,FCL,#Cdes,#Be,FPY,#Image
		where CLCODE = Code
		and CLCODE *= client_cde
		and CLCODE *= client_be
		and CLCODE *= client_image
		and CLPY *= PYCODE
		and (@ent is null or CLENT=@ent)
		order by CLCODE
	end
	else
	begin
		select CLNUMCOMPTABLE,CLCODE,CLNOM1,CLVILLE,isnull(CA,0),CLCOMREP,CLRAISONSOC,
			CLADR1,CLADR2,CLCP,CLSTATUS,CLREP,substring(CLCP,1,2),isnull(ca_cdes,0),isnull(ca_be,0),
			CLNOM2,CLNOM3,PYNOM,CLLOGIN,CLPASSWORD,CLAPE,CLTEL1,CLTELECOP1,CLEMAIL,isnull(seq_image,0)
		from #CACL,FCL,#Cdes,#Be,FPY,#Image
		where CLCODE = Code
		and CLCODE *= client_cde
		and CLCODE *= client_be
		and CLCODE *= client_image
		and CLPY *= PYCODE
		and isnull(CA,0) between @tranchedeb and @tranchefin
		and (@ent is null or CLENT=@ent)
		order by CLCODE
	end

	drop table #CACL
	drop table #Be
	drop table #Image
	
end

go

