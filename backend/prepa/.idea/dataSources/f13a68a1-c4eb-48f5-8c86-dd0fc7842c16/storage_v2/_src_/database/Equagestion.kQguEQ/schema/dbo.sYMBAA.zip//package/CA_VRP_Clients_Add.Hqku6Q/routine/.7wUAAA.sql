


create procedure CA_VRP_Clients_Add
with recompile
as
begin

set arithabort numeric_truncation off


declare @an			smallint
declare @mois		tinyint
declare @date		datetime

select @an=datepart(yy,getdate())
select @mois=datepart(mm,getdate())


create table #CA
(
STCL	char(12)		not null,
CAN2	numeric(14,2)	not null,
CAN1	numeric(14,2)	not null,
CAN		numeric(14,2)	not null,
CACC	numeric(14,2)	not null,
CAENT	char(5)				null
)


insert into #CA (STCL,CAN2,CAN1,CAN,CACC,CAENT)
select STCL,isnull(sum(case when STAN=@an-2 then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an-1 then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an then STCAFA else 0 end),0),
			0.00,STENT
from FST,FCL
where CLCODE=STCL and STENT=CLENT
and STAN between @an-2 and @an
and STMOIS between 1 and @mois
group by STCL,STENT


insert into #CA (STCL,CAN2,CAN1,CAN,CACC,CAENT)
select RCCCL,0.00,0.00,0.00,round(isnull(sum((CCLTOTALHT/CCLQTE)*RCCQTE),0),2),RCCENT
from FRCC,FCL,FCCL,FCC
where RCCSEQ=CCLSEQ and RCCENT=CLENT
and CLCODE=RCCCL
and CCCODE=CCLCODE
/* and isnull(CCVALIDE,0)=0 */
group by RCCCL,RCCENT

create index client on #CA (STCL)

select @date = getdate()

insert into FCAREP (CAREP,CACP2,CACL,CANOM,CAVILLE,CA_N_2,CA_N_1,CA_N,CACC,CADATE,CAREPENT,CAMOIS,CAAN)
select isnull(CLREP,""),substring(isnull(CLCP,''),1,2),CLCODE,isnull(CLNOM1,""),isnull(CLVILLE,""),
		sum(CAN2),sum(CAN1),sum(CAN),sum(CACC),@date,CAENT,datepart(mm,dateadd(dd,-1,@date)),
		datepart(yy,dateadd(dd,-1,@date))
from FCL,#CA
where CLCODE=STCL and CAENT=CLENT
and (CAN2!=0 or CAN1!=0 or CAN!=0 or CACC!=0)
group by CLREP,substring(isnull(CLCP,''),1,2),CLCODE,CLNOM1,CLVILLE,CAENT
order by CLREP,substring(isnull(CLCP,''),1,2),CLCODE,CAENT

drop table #CA

/* Traitement pour les representants division */

create table #CAREPDIV
(
STCL		char(12)		not null,
STREPDIV	char(8)			not null,
CAN2		numeric(14,2)	not null,
CAN1		numeric(14,2)	not null,
CAN			numeric(14,2)	not null,
CACC		numeric(14,2)	not null,
CAENT		char(5)				null
)

insert into #CAREPDIV (STCL,STREPDIV,CAN2,CAN1,CAN,CACC,CAENT)
select STCL,STREPDIV,isnull(sum(case when STAN=@an-2 then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an-1 then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an then STCAFA else 0 end),0),
			0.00,STENT
from FST,FCL
where CLCODE=STCL and STENT=CLENT
and STAN between @an-2 and @an
and STMOIS between 1 and @mois
group by STCL,STREPDIV,STENT


insert into #CAREPDIV (STCL,STREPDIV,CAN2,CAN1,CAN,CACC,CAENT)
select RCCCL,CCLREPDIV,0.00,0.00,0.00,round(isnull(sum((CCLTOTALHT/CCLQTE)*RCCQTE),0),2),RCCENT
from FRCC,FCL,FCCL,FCC
where RCCSEQ=CCLSEQ and RCCENT=CLENT
and CLCODE=RCCCL
and CCCODE=CCLCODE
/* and isnull(CCVALIDE,0)=0 */
group by RCCCL,CCLREPDIV,RCCENT

create index client on #CA (STCL)

select @date = getdate()

insert into FCAREP (CAREP,CACP2,CACL,CANOM,CAVILLE,CA_N_2,CA_N_1,CA_N,CACC,CADATE,CAREPENT,CAMOIS,CAAN)
select isnull(STREPDIV,""),substring(isnull(CLCP,''),1,2),CLCODE,isnull(CLNOM1,""),isnull(CLVILLE,""),
		sum(CAN2),sum(CAN1),sum(CAN),sum(CACC),@date,CAENT,datepart(mm,dateadd(dd,-1,@date)),
		datepart(yy,dateadd(dd,-1,@date))
from FCL,#CAREPDIV
where CLCODE=STCL and CAENT=CLENT
and (CAN2!=0 or CAN1!=0 or CAN!=0 or CACC!=0)
group by STREPDIV,substring(isnull(CLCP,''),1,2),CLCODE,CLNOM1,CLVILLE,CAENT
order by STREPDIV,substring(isnull(CLCP,''),1,2),CLCODE,CAENT

drop table #CAREPDIV

end



go

