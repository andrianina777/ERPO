


/* Procedure utilisee par le requeteur ""Statistiques Articles"" */

create procedure StatArticles (@datedeb		smalldatetime,
							   @datefin		smalldatetime,
							   @depart		char(8)		= null,
							   @marque		char(12)	= null,
							   @famille		char(8)		= null,
							   @categorie	char(8)		= null,
							   @article		char(15) 	= null,
							   @ordre		tinyint		= 0
							  )
with recompile
as
begin

set arithabort numeric_truncation off

create table #Articles
(
article		char(15)	not null
)

	/* lecture des articles */
	
	insert into #Articles (article)
	select ARCODE
	from FAR
	where isnull(AROLD,0)=0
	and (@depart is null or ARDEPART = @depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM = @famille)
	and (@categorie is null or ARGRFAM = @categorie)
	and (@article is null or ARCODE = @article)

	create index article on #Articles(article)


create table #liste
(
codeart 	char(15) 	not null,
cdeclient 	int 			null,
factclient	int				null,
cdefour 	int 			null,
stock 		int 			null
)


	/* lecture des cdes clients en cours */
	
	insert into #liste (codeart,cdeclient,factclient,cdefour,stock)
	select RCCARTICLE,sum(RCCQTE),0,0,0
	from #Articles,FRCC,FCCL,FCC
	where RCCARTICLE = article
	and CCLSEQ=RCCSEQ
	and CCCODE=CCLCODE
	and CCDATECOM between @datedeb and @datefin
	group by RCCARTICLE
	
	
	/* lecture des factures */
	
	insert into #liste (codeart,cdeclient,factclient,cdefour,stock)
	select FALARTICLE,0,sum(FALQTE),0,0
	from #Articles,FFAL (index date)
	where FALARTICLE = article
	and FALDATE between @datedeb and @datefin
	group by FALARTICLE
	

	/* lecture des cdes fournisseurs en cours */
	
	insert into #liste (codeart,cdeclient,factclient,cdefour,stock)
	select RCFARTICLE,0,0,sum(RCFQTE),0
	from #Articles,FRCF,FCFL,FCF
	where RCFARTICLE = article
	and CFLSEQ=RCFSEQ
	and CFCODE=CFLCODE
	and CFDATE between @datedeb and @datefin
	group by RCFARTICLE

	
	/* lecture du stock en cours */	
	
	
	insert into #liste (codeart,cdeclient,factclient,cdefour,stock)
	select STAR,0,0,0,sum(STQTE)
	from #Articles,FSTOCK
	where STAR = article
	and STQTE > 0
	group by STAR



	select codeart,cdeclient=isnull(sum(cdeclient),0),factclient=isnull(sum(factclient),0),
			cdesETfact=isnull(sum(cdeclient),0)+isnull(sum(factclient),0),
			cdefour=isnull(sum(cdefour),0),stock_net=isnull(sum(stock),0)-isnull(sum(cdeclient),0),
			stock_brut=isnull(sum(stock),0)
	into #finale
	from #liste
	group by codeart

	if @ordre = 0
	begin
	select codeart,ARLIB,cdeclient,factclient,cdesETfact,cdefour,stock_net,stock_brut
	from #finale,FAR
	where ARCODE=codeart
	order by codeart
	end
	else if @ordre = 1
	begin
	select codeart,ARLIB,cdeclient,factclient,cdesETfact,cdefour,stock_net,stock_brut
	from #finale,FAR
	where ARCODE=codeart
	order by cdesETfact desc	
	end

			
	drop table #liste
	drop table #Articles
	
end	



go

