
/* Reconstruction des statistiques de commandes clients */

create procedure New_FSTCC_AR	(@article	char(15),
								 @an		smallint
								)
with recompile
as
begin
	
set arithabort numeric_truncation off
	
declare @smalldate1	datetime,
		@smalldate2	datetime
		
declare	@base	varchar(30)
select  @base = db_name()


select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))


dump tran @base with truncate_only


create table #FSTCC
(
STCCREP		char(8)			not null,
STCCGROUPE	char(12)		not null,
STCCCL		char(12)		not null,
STCCART		char(15)		not null,
STCCAN		smallint		not null,
STCCMOIS	tinyint			not null,
STCCQTE		int				not null,
STCCCA		numeric(14,2)	not null,
STCCENT		char(5)				null,
STCCREPDIV	char(8)			not null
)

insert into #FSTCC (STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCQTE,STCCCA,STCCENT,STCCREPDIV)
select isnull(CCREPRES,''),isnull(CCGROUPE,''),CCLCL,CCLARTICLE,
		datepart(yy,CCLDATE),datepart(mm,CCLDATE),
		sum(isnull(CCLQTE,0)),sum(isnull(CCLTOTALHT,0)),CCLENT,isnull(CCLREPDIV,'')
from FCCL (index date),FCC
where CCCODE=CCLCODE
and CCLENT=CCENT
and CCLDATE between @smalldate1 and @smalldate2
and CCLARTICLE=@article
and isnull(CCLARTICLE,'') != ''
group by CCREPRES,CCGROUPE,CCLCL,CCLARTICLE,datepart(yy,CCLDATE),datepart(mm,CCLDATE),CCLENT,CCLREPDIV


delete from FSTCC
where STCCAN=@an
and STCCART=@article

  
dump tran @base with truncate_only

insert into FSTCC (STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCQTE,STCCCA,STCCENT,STCCREPDIV)
select STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,sum(STCCQTE),sum(STCCCA),STCCENT,STCCREPDIV
from #FSTCC
group by STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCENT,STCCREPDIV
order by STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCENT,STCCREPDIV

drop table #FSTCC


dump tran @base with truncate_only

end
go

