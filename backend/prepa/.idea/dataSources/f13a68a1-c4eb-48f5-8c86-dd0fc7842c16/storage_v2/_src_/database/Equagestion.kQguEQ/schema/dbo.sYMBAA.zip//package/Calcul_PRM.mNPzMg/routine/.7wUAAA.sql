


create procedure Calcul_PRM (	@ent		char(5) = null,
								@article	char(15),
							 	@ante		int		= -3
							)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1	smalldatetime

if sign(@ante) = 1
select @ante = -@ante

select @date1 = dateadd(yy,@ante,getdate())

create table #moyen
(
article		char(15)		not null,
prix_rev	numeric(14,2)	not null,
qte			int				not null
)

create table #final
(
article		char(15)		not null,
prix_rev	numeric(14,2)	not null,
qte			int				not null
)

insert into #moyen (article,prix_rev,qte)	
select SILARTICLE,round(sum((SILPAHT+SILFRAIS)/CVLOT*SILQTE),2),sum(SILQTE)
from FSIL,FDP,FAR,FCV
where DPCODE=SILDEPOT
and CVUNIF=ARUNITACHAT
and SILARTICLE=ARCODE
and SILDATE between @date1 and getdate()
and ARCODE=@article
and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by SILARTICLE


insert into #moyen (article,prix_rev,qte)	
select BLLAR,sum(BLLTOTHT),sum(BLLQTE)
from FBLL,FBL
where BLCODE=BLLCODE
and BLM=""
and BLLDATE between @date1 and getdate()
and BLLAR=@article
and (@ent is null or (BLLENT=@ent and BLENT=@ent))
group by BLLAR

insert into #moyen (article,prix_rev,qte)	
select RFLARTICLE,sum(RFLTOTALHT),-sum(RFLQTE)
from FRFL
where RFLDATE between @date1 and getdate()
and RFLARTICLE=@article
and (@ent is null or RFLENT=@ent)
group by RFLARTICLE


insert into #moyen (article,prix_rev,qte)	
select DOLAR,sum(DOLTOTHT),sum(DOLQTE)
from FDOL
where DOLDATE between @date1 and getdate()
and DOLQTE>0
and DOLAR=@article
and (@ent is null or DOLENT=@ent)
group by DOLAR


insert into #moyen (article,prix_rev,qte)	
select ASLARTICLE,sum(ASLPAHT+ASLFRAIS),sum(ASLQTE)
from FASL,FDP
where DPCODE=ASLDEPOT
and ASLDATE between @date1 and getdate()
and ASLQTE>0
and ASLARTICLE=@article
and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ASLARTICLE


insert into #final (article,prix_rev,qte)
select article,sum(prix_rev),sum(qte)
from #moyen
group by article

drop table #moyen


update FAR
set ARPRM = round(prix_rev/qte,4)
from #final
where ARCODE = article
and qte > 0
and ARPRM != round(prix_rev/qte,2)


drop table #final

end



go

