


/* Procedure utilisee pour supprimer les Commandes Clients trop anciennes */


create procedure Cdes_Clients  (@ent		char(5) = null,
								@date 		datetime,
								@depart		char(8) = null,
								@marque		char(8) = null,
								@grfam		char(8) = null,
								@famille	char(8) = null,
								@article 	char(15) = null,
								@client		char(12) = null,
								@produits	smallint = 0,
								@prodnsto	smallint = 1,
								@services	smallint = 2,
								@ports		smallint = 3,
								@comments	smallint = 4,
								@remises	smallint = 5,
								@rfa		smallint = 6,
								@assur		smallint = 7
								)
with recompile						
as
begin


create table #Prep
(
CCLSEQ			int				not null,
CCLCL			char(12)		not null,
CCLCODE			char(10)		not null,
CCLNUM			int					null,
CCLDATE			datetime			null,
CCLARTICLE		char(15)		not null,
CCLLIBRE		varchar(255)		null,
CCLRESTE		int					null,
CLPAYEUR		tinyint			not null,
SEQ				numeric(14,0)	identity
)


create table #Stock
(
ArticleCde	char(15)	not null,
QteStock	int				null
)


insert into #Prep (CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,
					CCLRESTE,CLPAYEUR)
select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,
					CCLRESTE,CLPAYEUR
from FRCC,FCCL,FCL,FAR
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CLENT=@ent))
and CCLSEQ=RCCSEQ
and ARCODE=RCCARTICLE
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@grfam is null or ARGRFAM=@grfam)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)
and (@client is null or RCCCL=@client)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
and RCCDATE < @date
and CLCODE=CCLCL
order by CCLDATECRE

create 		  index article on #Prep(CCLARTICLE)
create unique index seq 	on #Prep(CCLSEQ)

create table #Art
(
CCLARTICLE		char(15)		not null
)

insert into #Art (CCLARTICLE)
select CCLARTICLE
from #Prep
group by CCLARTICLE

create unique index art on #Art (CCLARTICLE)

insert into #Stock (ArticleCde,QteStock)
select CCLARTICLE,isnull(sum(STQTE),0)
from #Art,FSTOCK,FDP
where STAR=*CCLARTICLE
and STQTE > 0
and DPCODE=*STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by CCLARTICLE

create unique index article on #Stock (ArticleCde)

drop table #Art


select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,ARLIB,
					CCLRESTE,QteStock,CLPAYEUR,1
from #Prep,FAR,#Stock
where #Prep.CCLARTICLE*=ARCODE
and #Prep.CCLARTICLE*=#Stock.ArticleCde


drop table #Prep
drop table #Stock

end



go

