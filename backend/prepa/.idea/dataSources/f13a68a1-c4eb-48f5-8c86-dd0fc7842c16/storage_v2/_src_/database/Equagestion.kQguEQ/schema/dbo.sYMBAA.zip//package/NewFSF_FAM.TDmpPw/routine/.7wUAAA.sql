


/* Procedure permettant la creation des lignes groupees par familles
	du tableau de bord fournisseurs pour N, N-1, N-2 pour une famille */

create procedure NewFSF_FAM (@fam	char(8))
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
ARCODE		char(15)		null
)

create table #SF
(
fournisseur		char(12),
famille			char(8),
annee			int,
mois			int,
qtebl			int,
cabl			numeric(14,2),
qtecf			int,
cacf			numeric(14,2)
)


declare @date	datetime
select @date = convert (datetime,("01/01/"+convert(char(4),datepart(yy,getdate())-2)))

insert into #Far (ARCODE)
select ARCODE
from FAR
where ARFAM=@fam


create unique clustered index article on #Far (ARCODE)


   delete FSF
   where SFAN >= datepart(yy,getdate())-2
   and SFFAM = @fam
   
   insert into #SF (fournisseur,famille,annee,mois,qtebl,cabl,qtecf,cacf)
	select BLLFO,@fam,datepart(yy,BLLDATE),datepart(mm,BLLDATE),SFQTEBL=sum(BLLQTE),SFCABL=sum(BLLTOTHT),0,0
	from FBLL,#Far
	where ARCODE=BLLAR
	and BLLDATE >= @date
	and substring(BLLLIENCODE,1,2)!="CS"
	group by BLLFO,datepart(yy,BLLDATE),datepart(mm,BLLDATE)
   union
	select RFLFO,@fam,datepart(yy,RFLDATE),datepart(mm,RFLDATE),SFQTEBL=-sum(RFLQTE),SFCABL=-sum(RFLTOTALHT),0,0
	from FRFL,#Far
	where ARCODE=RFLARTICLE
	and RFLDATE >= @date
	group by RFLFO,datepart(yy,RFLDATE),datepart(mm,RFLDATE)
	
   insert into FSF(SFFO,SFFAM,SFAN,SFMOIS,SFQTEBL,SFCABL,SFQTECF,SFCACF,SFDATEMDF)
   select fournisseur,famille,annee,mois,sum(qtebl),sum(cabl),sum(qtecf),sum(cacf),getdate()
   from #SF
   group by fournisseur,famille,annee,mois
   
   drop table #SF
      
   
   select CFLFO,fam=@fam,annee=datepart(yy,CFLDATEP),
   			mois=datepart(mm,CFLDATEP),CFLRESTE,
			CALigne=round((CFLTOTALHT/CFLQTE),2)*CFLRESTE
   into #FromCFL
	from FRCF,FCFL,#Far
	where RCFSEQ=CFLSEQ
	and RCFARTICLE=ARCODE
	and CFLQTE != 0
   
   select FO=CFLFO,FAM=fam,AN=annee,MOIS=mois,QTE=sum(CFLRESTE),CA=sum(CALigne)
   into #SCF
	from #FromCFL
	group by CFLFO,fam,annee,mois
	
	create unique clustered index code on #SCF (FO,FAM,AN,MOIS)

   
    insert into FSF(SFFO,SFFAM,SFAN,SFMOIS,SFQTEBL,SFCABL,SFQTECF,SFCACF,SFDATEMDF)
	select FO,FAM,AN,MOIS,0,0,0,0,getdate()
	from #SCF
	where not exists (select * from FSF where SFFO=#SCF.FO and SFFAM=#SCF.FAM and SFAN=#SCF.AN and SFMOIS=#SCF.MOIS)

   update FSF
	set SFQTECF=QTE,SFCACF=CA
	from #SCF
	where SFFO=FO
	and SFFAM=FAM
	and SFAN=AN
	and SFMOIS=MOIS
	
   
   drop table #FromCFL
   drop table #SCF
   drop table #Far

end



go

