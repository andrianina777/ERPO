


create procedure BTrRiv(@ent		char(5)	= null,
						@datedebut	smalldatetime,
						@datefin	smalldatetime,
						@LeTransp 	tinyint,
						@transp1	char(8) = null,
						@transp2	char(8) = null)
with recompile
as
begin

	select EXTRANSP,EXCL,EXNOM,EXADR1,EXADR2,EXCP,EXVILLE,EXPAYS,
	EXAPAYER,EXOBS,EXTOTCOLIS,EXTOTPOIDS,EXRECOM,EXTOTALTR
	from FEX
	where EXDATE between @datedebut and @datefin
	and (@LeTransp=0 or EXTRANSP between @transp1 and @transp2)
	and (@ent is null or EXENT=@ent)
	order by EXTRANSP,EXCL
	
end



go

