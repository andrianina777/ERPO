


/* Calcule la RFA pour chaque client puis pour la societe - TBGL - procedure nocturne */

create procedure RFA_TBGL (	@ent	char(5) = null,
							@an		smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @pent			char(5)
select 	@pent=PENT from KParam


declare @CAtotal		numeric(14,2),			/* CA total pour calcul droit */
		@CAsansRFA		numeric(14,2),			/* CA des articles sans RFA */
		@CARFAct		numeric(14,2),			/* CA des articles avec RFA contrats */
		@CARFAHct		numeric(14,2),			/* CA des articles avec RFA hors contrats */
		@droitRFA		numeric(8,4),			/* % du droit a RFA */
		@RFAct			numeric(14,2),			/* total de la RFA contrat */
		@RFAremCL		numeric(14,2),			/* total de la RFA sans contrat (RFA fiche remises) */
		@RFAremCL_pot	numeric(14,2),			/* total de la RFA potentielle sans contrat (RFA fiche remises) */
		@rfa_ca			numeric(14,2),			/* total de la RFA CA */
		@rfa_pot		numeric(14,2),			/* total de la RFA CA potentielle */
		@droit_pot		numeric(8,4),			/* % du droit potentiel */
		@groupement		char(12)				/* code du groupement d''achat du client */
		
declare @contrat		char(10),
        @depart         char(8),
        @marque         char(12),
        @famille        char(8),
        @categorie      char(8),
        @article        char(15),
        @tarif          char(8),
		@qte_ct			int,
		@atteint_qte	int,
		@montant_ct     numeric(14,0),
		@atteint_val	numeric(14,2),
		@rfa_due		numeric(14,2)

declare @seq			int

create table #Finale
(
annee		smallint		not null,
client		char(12)		not null,
contrat		char(10)		not null,
depart      char(8)         not null,
marque      char(12)        not null,
famille     char(8)         not null,
categorie   char(8)         not null,
article     char(15)        not null,
tarif       char(8)         not null,
qte_ct		int					null,
atteint_qte	int					null,
montant_ct  numeric(14,0)       null,
atteint_val	numeric(14,2)		null,
rfa_due		numeric(14,2)		null,
rfa_pot		numeric(14,2)		null,
seq			numeric(14,0)	identity
)


declare clients cursor
for select STCL
from FST,FCL
where STCL=CLCODE
and isnull(CLSANSRFA,0)=0
and STAN=@an
and (@ent is null or (STENT=@ent and CLENT=@ent))
group by STCL
for read only

declare @client	char(12)

open clients

fetch clients into @client


while (@@sqlstatus = 0)
begin
	
	execute RFA_Detail null,@client,@an,2,0

	insert into #Finale (annee,client,contrat,depart,marque,famille,categorie,article,tarif,qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot)
	select ANNEE,CLIENT,CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,QTE_CT,ATTEINT_QTE,VAL_CT,ATTEINT_VAL,RFA_DUE,RFA_POT
	from FRFATemp
	where SPID=@@spid
		
	fetch clients into @client
		
end

close clients
deallocate cursor clients

/* Mise a jour de la table des RFA clients */

delete from FRCL
where RCLAN=@an
and (@ent is null or RCLENT=@ent)

select @seq=isnull(max(RCLSEQ),0) from FRCL

declare rfa cursor 
for select client,contrat,depart,marque,famille,categorie,article,tarif,qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot
from #Finale
order by client,contrat,depart,marque,famille,categorie,article,tarif
for read only

open rfa

fetch rfa into  @client,@contrat,@depart,@marque,@famille,@categorie,@article,@tarif,
                @qte_ct,@atteint_qte,@montant_ct,@atteint_val,@rfa_due,@rfa_pot

while (@@sqlstatus = 0)
begin
	
	select @seq=@seq+1

	
	insert into FRCL (RCLAN,RCLCL,RCLCODE,RCLDEPART,RCLFO,RCLFAM,RCLCATEG,RCLARTICLE,RCLTARIF,
	                    RCLQTECT,RCLATTEINT,RCLMONTANT,RCLCAATTEINT,RCLDROIT,RCLPOT,RCLSEQ,RCLENT)
	values (@an,@client,@contrat,@depart,@marque,@famille,@categorie,@article,@tarif,
	                    @qte_ct,@atteint_qte,@montant_ct,@atteint_val,
						@rfa_due,@rfa_pot,@seq,isnull(@ent,@pent))
	
	fetch rfa into  @client,@contrat,@depart,@marque,@famille,@categorie,@article,@tarif,
                    @qte_ct,@atteint_qte,@montant_ct,@atteint_val,@rfa_due,@rfa_pot

	
end

close rfa
deallocate cursor rfa


/* Mise a jour de la table des RFA pour l''ensemble des clients */

delete from FRGL
where RGLAN=@an
and (@ent is null or RGLENT=@ent)


insert into FRGL ( RGLAN,RGLCODE,RGLDEPART,RGLFO,RGLFAM,RGLCATEG,RGLARTICLE,RGLTARIF,
                    RGLQTECT,RGLATTEINT,RGLMONTANT,RGLCAATTEINT,RGLDROIT,RGLPOT,RGLDATE,RGLENT)
select 	@an,contrat,depart,marque,famille,categorie,article,tarif,
        sum(qte_ct),sum(atteint_qte),sum(montant_ct),sum(atteint_val),
		sum(rfa_due),sum(rfa_pot),getdate(),isnull(@ent,@pent)
from #Finale
group by contrat,depart,marque,famille,categorie,article,tarif
order by contrat,depart,marque,famille,categorie,article,tarif


drop table #Finale

end



go

