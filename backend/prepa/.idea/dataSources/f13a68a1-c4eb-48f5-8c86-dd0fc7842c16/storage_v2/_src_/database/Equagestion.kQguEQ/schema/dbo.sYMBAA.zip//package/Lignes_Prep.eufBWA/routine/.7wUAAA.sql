


/* Procedure utilisee par le module ""Suivi de production"" */


create procedure Lignes_Prep (@ent			char(5)	= null,
							  @date			datetime,
							  @valeur		numeric(14,2),
							  @stocklocal	tinyint=0)
with recompile						
as

begin

set arithabort numeric_truncation off


create table #Finale
(
lignes		int				null,
valeur		numeric(14,2)	null,
seq			numeric(14,0)	identity
)

create table #Prep
(
CCLCL			char(12)		not null,
CCLCODE			char(10)		not null,
CCLDATE			datetime			null,
CCLARTICLE		char(15)		not null,
CCLRESTE		int					null,
CLPAYEUR		tinyint			not null,
CCLTOTALHT		numeric(14,2)		null,
CCLQTE			int					null,
CLPREP			tinyint			not null,
CCPREP			tinyint			not null,
CCOK			int					null,
SEQ				numeric(14,0)	identity
)

create table #Stock
(
ArticleCde	char(15)	not null,
QteLoc		int				null,
QteAutre	int				null,
Qtedisp		int				null
)

create table #StockDep
(
Article		char(15)	not null,
Qte			int				null,
Depot		char(4)			null
)

create table #Articles
(
CCLARTICLE	char(15)	not null,
ALivrer		int				null
)

create table #Art
(
CCLARTICLE	char(15)	not null
)

declare @FromDate	smalldatetime
		
select @FromDate=dateadd(yy,-2,getdate())


insert into #Prep (CCLCL,CCLCODE,CCLDATE,CCLARTICLE,CCLRESTE,CLPAYEUR,
					CCLTOTALHT,CCLQTE,CLPREP,CCPREP)
select CCLCL,CCLCODE,CCLDATE,CCLARTICLE,
CCLRESTE,CLPAYEUR,CCLTOTALHT,CCLQTE,isnull(CLPREP,0),isnull(CCPREP,0)
from FRCC,FCCL,FCC,FCL,FAR
where CCLSEQ=RCCSEQ
and RCCDATE between @FromDate and @date
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and CLCODE=CCLCL
and ARCODE=RCCARTICLE
and ARTYPE in (0,1)
and CCLQTE > 0
and CCLRESTE > 0
and CLPAYEUR in (0,1)
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
order by CCLDATECRE

create index article on #Prep(CCLARTICLE)


insert into #Art
select CCLARTICLE
from #Prep
group by CCLARTICLE

insert into #Articles
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Art
where RCCARTICLE=CCLARTICLE
and RCCDATE between @FromDate and @date
and (@ent is null or RCCENT=@ent)
group by RCCARTICLE

create unique clustered index art on #Articles (CCLARTICLE)

drop table #Art

if (@stocklocal=0)
begin
  insert into #StockDep (Article,Qte,Depot)
  select CCLARTICLE,isnull(sum(STQTE),0),isnull(STDEPOT,'')
  from #Articles,FSTOCK,FDP
  where STAR=*CCLARTICLE
  and DPCODE*=STDEPOT
  and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
  group by CCLARTICLE,STDEPOT
end
else if (@stocklocal=1)
begin
  insert into #StockDep (Article,Qte,Depot)
  select CCLARTICLE,isnull(sum(STQTE),0),isnull(STDEPOT,'')
  from #Articles,FSTOCK,FDP
  where STAR=*CCLARTICLE
  and DPLOC=1
  and DPCODE*=STDEPOT
  and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
  group by CCLARTICLE,STDEPOT
end

create unique clustered index ardep on #StockDep (Article,Depot)

insert into #Stock (ArticleCde,QteLoc,QteAutre)
select Article,sum(case when (Depot != '')
							then (case when DPLOC=1 then Qte else 0 end)
						when (Depot = '')
							then 0
				   end),
			   sum(case when (Depot != '')
							then (case when DPLOC != 1 then Qte else 0 end)
						when (Depot = '')
							then 0
				   end)
from #StockDep,FDP
where Depot*=DPCODE
group by Article

create unique clustered index article on #Stock (ArticleCde)

update #Stock
set Qtedisp=QteLoc+QteAutre


select Cde=CCLCODE,Article=CCLARTICLE,Qte=CCLRESTE
into #Complet
from #Prep,FAR
where (CLPREP=1 or CCPREP=1)
and ARCODE=CCLARTICLE
and ARCOMP != 2

delete #Prep
from #Stock,#Complet
where Cde=CCLCODE
and ArticleCde=Article
and Qte > Qtedisp

drop table #Complet


/* suppression des lignes sans stock */

declare commandes cursor 
for select SEQ,CCLARTICLE,CCLRESTE
from #Prep,FAR
where CCLARTICLE=ARCODE
and ARCOMP != 2
order by SEQ
for read only

declare	@seq		int,
		@article	char(15),
		@reste		int,
		@stock		int

open commandes

fetch commandes
into @seq,@article,@reste

while (@@sqlstatus = 0)
	begin
	
	select @stock=Qtedisp
	from #Stock
	where ArticleCde=@article
	
	if (@stock-@reste) >= 0
	begin
	  update #Prep
	  set CCOK=@reste
	  where SEQ=@seq
	  
	  update #Stock
	  set Qtedisp=@stock-@reste
	  where ArticleCde=@article
	end
	else
	begin
	  update #Prep
	  set CCOK=0
	  where SEQ=@seq
	end
	
	fetch commandes
	into @seq,@article,@reste
	
end

close commandes
deallocate cursor commandes

delete from #Prep
where CCOK=0



select client=CCLCL,total = sum(case 	when (CCLRESTE > QteLoc+QteAutre) 
										  then round((CCLTOTALHT/CCLQTE),2)*(QteLoc+QteAutre)
									  when (CCLRESTE <= QteLoc+QteAutre) 
										  then round((CCLTOTALHT/CCLQTE),2)*CCLRESTE
								end)
into #Totaux
from #Prep,#Stock
where ArticleCde=CCLARTICLE
group by CCLCL




insert into #Finale (lignes,valeur)
select count(*),isnull(sum (case when (CCLRESTE > QteLoc+QteAutre) 
				  then round(CCLTOTALHT/CCLQTE,2)*(QteLoc+QteAutre)
				when (CCLRESTE <= QteLoc+QteAutre) 
				  then round(CCLTOTALHT/CCLQTE,2)*CCLRESTE
		  			end),0)
from #Prep,#Stock,#Articles,FAR,#Totaux
where #Prep.CCLARTICLE=ARCODE
and #Stock.ArticleCde=ARCODE
and #Articles.CCLARTICLE=ARCODE
and #Prep.CCLCL=#Totaux.client
and (ARCOMP = 2 or isnull(QteLoc,0)+isnull(QteAutre,0) > 0)
and total >=  @valeur


insert into #Finale (lignes,valeur)
select count(*),isnull(sum (case when (CCLRESTE > QteLoc+QteAutre) 
				  then round(CCLTOTALHT/CCLQTE,2)*(QteLoc+QteAutre)
				when (CCLRESTE <= QteLoc+QteAutre) 
				  then round(CCLTOTALHT/CCLQTE,2)*CCLRESTE
		  			end),0)
from #Prep,#Stock,#Articles,FAR,#Totaux
where #Prep.CCLARTICLE=ARCODE
and #Stock.ArticleCde=ARCODE
and #Articles.CCLARTICLE=ARCODE
and #Prep.CCLCL=#Totaux.client
and (ARCOMP = 2 or isnull(QteLoc,0)+isnull(QteAutre,0) > 0)
and total <  @valeur


select lignes,valeur
from #Finale
order by seq


drop table #Prep
drop table #Articles
drop table #Stock
drop table #StockDep
drop table #Totaux
drop table #Finale

end



go

