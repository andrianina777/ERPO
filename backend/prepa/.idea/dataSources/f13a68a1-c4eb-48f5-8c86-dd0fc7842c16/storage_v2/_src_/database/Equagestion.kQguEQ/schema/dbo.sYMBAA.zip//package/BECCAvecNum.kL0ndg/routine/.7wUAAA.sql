


/* Procedure utilisee par le module ""Expeditions"". */
/*	Renvoie les commandes a expedier dont les articles sont numerotes */
/*	et qui font partie d''une commande specifique 	*/
/* Modification le 22-12-05 par SP : ajout CCLMARCHE */

create procedure BECCAvecNum(	@ent		char(5) = null,
								@UntilDate 	datetime = null,
							 	@Client		char(12),
							 	@Commande 	char (10) = null,
							 	@Depot		char(4),
							 	@nom		varchar(35) = null,
							 	@adr1		varchar(50) = null,
							 	@adr2		varchar(50) = null,
							 	@cp			varchar(12) = null,
							 	@ville		varchar(30) = null,
							 	@py			char(8) = null,
								@devise		char(3) = null
							 	)
with recompile					
as
begin

set arithabort numeric_truncation off

create table #Stock
(
Article		char(15)	not null,
Emplacement	char(4)			null
)


create table #Prep
(
CCLCODE			char(10)		not null,
CCLNUM			int				not null,
CCLARTICLE		char(15)		not null,
CCLRESTE		int				not null,
ARLIB			varchar(80)			null,
ARUNITFACT		tinyint			not null,
CCLPHT			numeric(14,2)		null,
MODELIV			char(2)				null,
CCLLIBRE		varchar(255)		null,
CCLTV			char(4)			not null,
ARREGLE			tinyint				null,
CCLECHSPE		tinyint				null,
ARCOMP			tinyint				null,
ARFO			char(12)		not null,
CCFACTMAN		tinyint				null,
ARTYPE			tinyint				null,
CCLPHTDEV		numeric(14,2)		null,
CCLOFFERT		tinyint				null,
CCLTOTALHT		numeric(14,2)		null,
CCLTOTALHTDEV	numeric(14,2)		null,
CCLQTE			int				not null,
CCLDEV			char(3)			not null,
CCLCOURSDEV		numeric(12,6)	not null,
CCLR1			real				null,
CCLR2			real				null,
CCLR3			real				null,
CCLATTACHE		char(10)			null,
ARNUMEROTE		tinyint				null,
ARREFFOUR		char(20)			null,
CCLMARCHE       char(12)            null,
SEQ				numeric(14,0)	identity
)

if (@UntilDate is null)
   begin
	   insert into #Prep
	   select CCLCODE,CCLNUM,CCLARTICLE,CCLRESTE-(isnull(CCLQTEPREP,0)),ARLIB,ARUNITFACT,CCLPHT,
	   MODELIV=substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,
	   ARCOMP,ARFO,CCFACTMAN,ARTYPE,CCLPHTDEV,isnull(CCLOFFERT,0),CCLTOTALHT,
	   CCLTOTALHTDEV,CCLQTE,CCLDEV,CCLCOURSDEV,CCLR1,CCLR2,CCLR3,isnull(CCLATTACHE,""),
	   ARNUMEROTE,ARREFFOUR,CCLMARCHE
	   from FCCL,FAR,FCC,FRCC
	   where CCLSEQ=RCCSEQ
	   and RCCCL=@Client
	   and RCCARTICLE=ARCODE
	   and (ARNUMEROTE=1 or ARCOMP=2)
	   and CCCODE=CCLCODE
	   and (@Commande is null or CCLCODE=@Commande)
	   and isnull(CCVALIDE,0)=0
	   and isnull(CCBEBLOQUE,0)=0
	   and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	   and (@ent is null or (CCLENT=RCCENT and CCENT=RCCENT and RCCENT=@ent))
	   and (isnull(@nom,"") = "" or CCNOM = @nom)
	   and (isnull(@adr1,"") = "" or CCADR1 = @adr1)
	   and (isnull(@adr2,"") = "" or CCADR2 = @adr2)
	   and (isnull(@cp,"") = "" or CCCP = @cp)
	   and (isnull(@ville,"") = "" or CCVILLE = @ville)
	   and (isnull(@py,"") = "" or CCPY = @py)
	   and (isnull(@devise,"") = "" or CCDEV = @devise)
   end
else
   begin
	   insert into #Prep
	   select CCLCODE,CCLNUM,CCLARTICLE,CCLRESTE-(isnull(CCLQTEPREP,0)),ARLIB,ARUNITFACT,CCLPHT,
	   MODELIV=substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,
	   ARCOMP,ARFO,CCFACTMAN,ARTYPE,CCLPHTDEV,isnull(CCLOFFERT,0),CCLTOTALHT,
	   CCLTOTALHTDEV,CCLQTE,CCLDEV,CCLCOURSDEV,CCLR1,CCLR2,CCLR3,isnull(CCLATTACHE,""),
	   ARNUMEROTE,ARREFFOUR,CCLMARCHE
	   from FCCL,FAR,FCC,FRCC
	   where CCLSEQ=RCCSEQ
	   and RCCCL=@Client
	   and RCCDATE<=@UntilDate		
	   and RCCARTICLE=ARCODE
	   and (ARNUMEROTE=1 or ARCOMP=2)
	   and CCCODE=CCLCODE
	   and (@Commande is null or CCLCODE=@Commande)
	   and isnull(CCVALIDE,0)=0
	   and isnull(CCBEBLOQUE,0)=0
	   and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	   and (@ent is null or (CCLENT=RCCENT and CCENT=RCCENT and RCCENT=@ent))
	   and (isnull(@nom,"") = "" or CCNOM = @nom)
	   and (isnull(@adr1,"") = "" or CCADR1 = @adr1)
	   and (isnull(@adr2,"") = "" or CCADR2 = @adr2)
	   and (isnull(@cp,"") = "" or CCCP = @cp)
	   and (isnull(@ville,"") = "" or CCVILLE = @ville)
	   and (isnull(@py,"") = "" or CCPY = @py)
	   and (isnull(@devise,"") = "" or CCDEV = @devise)
   end
   
create index article on #Prep(CCLARTICLE)


declare @CCLARTICLE	char(15),
		@ARCOMP		tinyint

declare stock cursor
for select CCLARTICLE,ARCOMP
from #Prep
group by CCLARTICLE,ARCOMP
for read only

open stock

fetch stock into @CCLARTICLE,@ARCOMP

while (@@sqlstatus = 0)
  begin

/*
	if @ARCOMP=2
	begin
	  insert into #Stock (Article,Emplacement)
	  select AREAR,AREEMP
	  from FAR,FDP,FARE
	  where ARCODE=@CCLARTICLE
	  and AREAR=ARCODE and AREDEPOT = @Depot and AREPICK=1
	  and DPCODE=AREDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	  group by AREAR,AREEMP
	end
    else 
*/


    if @ARCOMP != 2
	begin
	
	  insert into #Stock (Article)
	  select STEMPAR
	  from FSTEMP,FAR,FDP
	  where STEMPAR=@CCLARTICLE
	  and ARCODE=STEMPAR
	  and (ARTYPE <> 0 or STEMPQTE > 0)
	  and STEMPDEPOT = @Depot
	  and DPCODE=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	  group by STEMPAR
  
  	end
  
  	fetch stock into @CCLARTICLE,@ARCOMP
  end
  
close stock
deallocate cursor stock

create unique clustered index star on #Stock(Article)

delete from #Prep
where not exists (select * from #Stock where Article=#Prep.CCLARTICLE)
and ARCOMP != 2

/*
select CCLCODE,CCLNUM,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,ARCOMP,ARFO,CCFACTMAN,ARTYPE,
CCLPHTDEV,CCLOFFERT,CCLTOTALHT,CCLTOTALHTDEV,CCLQTE,CCLDEV,CCLCOURSDEV,
CCLR1,CCLR2,CCLR3,Emplacement,CCLATTACHE,ARNUMEROTE,@Depot,ARREFFOUR,CCLMARCHE
from #Prep,#Stock
where Article=#Prep.CCLARTICLE
order by CCLCODE,CCLNUM
*/

select CCLCODE,CCLNUM,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,ARCOMP,ARFO,CCFACTMAN,ARTYPE,
CCLPHTDEV,CCLOFFERT,CCLTOTALHT,CCLTOTALHTDEV,CCLQTE,CCLDEV,CCLCOURSDEV,
CCLR1,CCLR2,CCLR3,"",CCLATTACHE,ARNUMEROTE,@Depot,ARREFFOUR,CCLMARCHE
from #Prep
order by CCLCODE,CCLNUM


drop table #Prep
drop table #Stock

end



go

