



create procedure Ref_NonStock ( @ent		char(5)  = null,
								@an			smallint,
								@depart		char(8)  = null,
								@produits	smallint = 1,
								@services	smallint = 2,
								@ports		smallint = 3,
								@comments	smallint = 4,
								@remises	smallint = 5,
								@rfa		smallint = 6,
								@assur		smallint = 7
								)
with recompile
as
begin

set arithabort numeric_truncation off


declare @labase		varchar(30),
		@lignes		int
		
select  @labase = db_name()
select 	@lignes = 0

create table #CA
(
artype		tinyint		not null,
annee		int			not null,
jan			numeric(14,2)	null,
fev			numeric(14,2)	null,
mar			numeric(14,2)	null,
avr			numeric(14,2)	null,
mai			numeric(14,2)	null,
jun			numeric(14,2)	null,
jul			numeric(14,2)	null,
aou			numeric(14,2)	null,
sep			numeric(14,2)	null,
oct			numeric(14,2)	null,
nov			numeric(14,2)	null,
dec			numeric(14,2)	null
)

/* creation de toutes les lignes de mois pour les articles choisis */

declare @lemois	int
select  @lemois = 1

while @lemois <= 12
begin

 insert into #CA (artype,annee,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
 select ARTYPE,@an-2,0,0,0,0,0,0,0,0,0,0,0,0
 from FAR
 where ARTYPE in (@produits,@services,@ports,@comments,@remises,@rfa,@assur)
 group by ARTYPE
 
 insert into #CA (artype,annee,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
 select ARTYPE,@an-1,0,0,0,0,0,0,0,0,0,0,0,0
 from FAR
 where ARTYPE in (@produits,@services,@ports,@comments,@remises,@rfa,@assur)
 group by ARTYPE
 
 insert into #CA (artype,annee,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
 select ARTYPE,@an,0,0,0,0,0,0,0,0,0,0,0,0
 from FAR
 where ARTYPE in (@produits,@services,@ports,@comments,@remises,@rfa,@assur)
 group by ARTYPE
 
 select @lemois = @lemois +1

end

	
insert into #CA (artype,annee,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
select ARTYPE,STAN,
		isnull(sum(case when STMOIS=1 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=2 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=3 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=4 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=5 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=6 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=7 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=8 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=9 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=10 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=11 then STCAFA else 0 end),0),
		isnull(sum(case when STMOIS=12 then STCAFA else 0 end),0)
from FST,FAR
where START=ARCODE
and STAN between @an-2 and @an
and ARTYPE in (@produits,@services,@ports,@comments,@remises,@rfa,@assur)
and (@depart is null or ARDEPART=@depart)
and (@ent is null or STENT=@ent)
group by ARTYPE,STAN
order by ARTYPE,STAN desc


select artype,annee,
		sum(jan),sum(fev),sum(mar),
		sum(avr),sum(mai),sum(jun),
		sum(jul),sum(aou),sum(sep),
		sum(oct),sum(nov),sum(dec)
from #CA
group by artype,annee
order by artype,annee desc

drop table #CA


end



go

