


create procedure Dotations (@ent		char(5) = null,
							@an			smallint,
							@depart		char(8) = null,
							@marque		char(12) = null,
							@famille	char(8)	= null,
							@article	char(15) = null,
							@depot		char(4) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1	smalldatetime,
		@date2	smalldatetime
		
select @date1=convert(smalldatetime,"01/01/"+convert(varchar,@an))
select @date2=convert(smalldatetime,"12/31/"+convert(varchar,@an))


create table #Mouv
(
article		char(15)	not null,
depot		char(4)		not null,
annee		smallint	not null,
mois		tinyint		not null,
qtein		int				null,
valin		numeric(14,2)	null,
qteout		int				null,
valout		numeric(14,2)	null
)

create table #Far
(
ARCODE	char(15)	null,
ARLIB	varchar(80)	null,
CVLOT	int			null
)

insert into #Far
select ARCODE,ARLIB,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)
and (@depart is null or ARDEPART = @depart)
and (@marque is null or ARFO = @marque)
and (@famille is null or ARFAM = @famille)
and (@article is null or ARCODE = @article)

create unique clustered index code on #Far (ARCODE)


create table #Far2
(
ARCODE	char(15)	not null,
ARLIB	varchar(80)		null,
CVLOT	int				null
)

insert into #Far2
select ARCODE,ARLIB,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)
and (@depart is null or ARDEPART = @depart)
and (@marque is null or ARFO = @marque)
and (@famille is null or ARFAM = @famille)
and (@article is null or ARCODE = @article)

create unique clustered index code on #Far2 (ARCODE)



insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select DOTARTICLE,DOTDEPOT,@an-1,12,sum(DOTQTEIN),sum(DOTPRIN),sum(DOTQTEOUT),sum(DOTPROUT)
from FDOT,#Far2
where DOTAN < @an
and DOTMOIS = 12
and DOTARTICLE=ARCODE
and (@ent is null or DOTENT=@ent)
group by DOTARTICLE,DOTDEPOT


insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select SILARTICLE,SILDEPOT,@an,datepart(mm,SILDATE),
	   sum(SILQTE),round(sum(((SILPAHT+SILFRAIS)/CVLOT)*SILQTE),2),0,0.00
from FSIL,#Far,FDP
where SILARTICLE=ARCODE
and SILDATE between @date1 and @date2
and SILDEPOT=DPCODE and (@ent is null or DPENT=@ent)
and DPDOTATION=1
and (@depot is null or SILDEPOT = @depot)
group by SILARTICLE,SILDEPOT,datepart(mm,SILDATE)
having sum(SILQTE) != 0


insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select RJLARTICLE,RJLDEPOT,@an,datepart(mm,RJLDATE),
		sum(RJLQTE),sum(((RJLPAHT+RJLFRAIS)/CVLOT)*RJLQTE),0,0.00
from FRJL,#Far,FDP
where RJLARTICLE=ARCODE
and RJLDATE between @date1 and @date2
and RJLDEPOT=DPCODE and (@ent is null or DPENT=@ent)
and DPDOTATION=1
and (@depot is null or RJLDEPOT = @depot)
group by RJLARTICLE,RJLDEPOT,datepart(mm,RJLDATE)
having sum(RJLQTE) != 0


insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select LCLARTICLE,LCLDEPOT,@an,datepart(mm,LCLDATE),
		sum(LCLQTE),sum(((LCLPAHT+LCLFRAIS)/CVLOT)*LCLQTE),0,0.00
from FLCL,#Far2,FDP
where LCLARTICLE=ARCODE
and LCLDATE between @date1 and @date2
and LCLDEPOT=DPCODE and (@ent is null or DPENT=@ent)
and DPDOTATION=1
and (@depot is null or LCLDEPOT = @depot)
group by LCLARTICLE,LCLDEPOT,datepart(mm,LCLDATE)
having sum(LCLQTE) != 0


insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select ASLARTICLE,ASLDEPOT,@an,datepart(mm,ASLDATE),
		sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE),0,0.00
from FASL,#Far2,FDP
where ASLARTICLE=ARCODE
and ASLDATE between @date1 and @date2
and ASLDEPOT=DPCODE and (@ent is null or DPENT=@ent)
and DPDOTATION=1
and (@depot is null or ASLDEPOT = @depot)
group by ASLARTICLE,ASLDEPOT,datepart(mm,ASLDATE)
having sum(ASLQTE) != 0



insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select BLLAR,BLLDEP,@an,datepart(mm,BLLDATE),
		sum(BLLQTE),sum(((BLLPRHT)/CVLOT)*BLLQTE),0,0.00
from FBLL,FCV,FDP
where BLLUA=CVUNIF
and BLLDATE between @date1 and @date2
and BLLDEP=DPCODE
and DPDOTATION=1
and (@depot is null or BLLDEP = @depot)
and (@ent is null or (BLLENT=@ent and DPENT=@ent))
group by BLLAR,BLLDEP,datepart(mm,BLLDATE)
having sum(BLLQTE) != 0


insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select DOLAR,DOLDEP,@an,datepart(mm,DOLDATE),
		sum(DOLQTE),sum(((DOLPRHT)/CVLOT)*DOLQTE),0,0.00
from FDOL,FCV,FDP
where DOLUA=CVUNIF
and DOLDATE between @date1 and @date2
and DOLDEP=DPCODE
and DPDOTATION=1
and (@depot is null or DOLDEP = @depot)
and (@ent is null or (DOLENT=@ent and DPENT=@ent))
group by DOLAR,DOLDEP,datepart(mm,DOLDATE)



insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select RFLARTICLE,RFLDEPOT,@an,datepart(mm,RFLDATE),
-(sum(RFLQTE)),-(sum(((RFLPAHT)/CVLOT)*RFLQTE)),0,0.00
from FRFL,FCV,FDP
where RFLUNITACHAT=CVUNIF
and RFLDATE between @date1 and @date2
and RFLDEPOT=DPCODE
and DPDOTATION=1
and (@depot is null or RFLDEPOT = @depot)
and (@ent is null or (RFLENT=@ent and DPENT=@ent))
group by RFLARTICLE,RFLDEPOT,datepart(mm,RFLDATE)
having sum(RFLQTE) != 0



insert into #Mouv (article,depot,annee,mois,qtein,valin,qteout,valout)
select BELARTICLE,STDEPOT,@an,datepart(mm,BELDATE),0,0.00,
		sum(BELQTE),sum(((STPAHT+STFRAIS)/CVLOT)*BELQTE)
from FBEL,FSTOCK,#Far,FDP
where BELARTICLE=ARCODE
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and BELDATE between @date1 and @date2
and STDEPOT=DPCODE
and (@ent is null or (BELENT=@ent and DPENT=@ent))
and DPDOTATION=1
and (@depot is null or STDEPOT = @depot)
group by BELARTICLE,STDEPOT,datepart(mm,BELDATE)
having sum(BELQTE) != 0


/**** select final ****/

select article=article,depot=depot,annee=annee,mois=mois,
		qtein=sum(qtein),valin=sum(valin),
		qteout=sum(qteout),valout=sum(valout)
into #Finale
from #Mouv
group by article,depot,annee,mois
order by article,depot,annee,mois


select article,ARLIB,depot,isnull(sum(case when mois=12 and annee=@an-1 then qtein else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an-1 then valin else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an-1 then qteout else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an-1 then valout else 0 end),0),
					isnull(sum(case when mois=1 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=1 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=1 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=1 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=2 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=2 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=2 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=2 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=3 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=3 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=3 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=3 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=4 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=4 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=4 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=4 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=5 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=5 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=5 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=5 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=6 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=6 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=6 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=6 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=7 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=7 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=7 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=7 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=8 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=8 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=8 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=8 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=9 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=9 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=9 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=9 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=10 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=10 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=10 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=10 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=11 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=11 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=11 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=11 and annee=@an then valout else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an then qtein else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an then valin else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an then qteout else 0 end),0),
					isnull(sum(case when mois=12 and annee=@an then valout else 0 end),0)
from #Finale,#Far2
where ARCODE=article
group by article,ARLIB,depot
order by article,ARLIB,depot


drop table #Mouv
drop table #Far
drop table #Far2
drop table #Finale

end



go

