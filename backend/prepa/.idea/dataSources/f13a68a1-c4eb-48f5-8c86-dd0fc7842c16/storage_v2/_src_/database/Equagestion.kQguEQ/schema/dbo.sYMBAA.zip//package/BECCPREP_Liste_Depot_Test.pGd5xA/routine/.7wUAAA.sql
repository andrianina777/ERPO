CREATE PROCEDURE dbo.BECCPREP_Liste_Depot_Test (@pCC varchar(10))

AS
begin
        declare @id_User varchar(255),
                @DPCODE varchar(50),
                @depot varchar(50),
                @nbArticle int

        create table #DEPOT(
                COMMANDE varchar(50) null,
                DEPOT varchar(50) null,
                ARTICLE int
        )
        
        select @id_User=newID()
        
        exec x_LigneStockDispo1 @pCC,@id_User

           
        declare depot cursor for select DPCODE from FDP where DPCENTRAL=1 and xDPVTE=1 order by DPCOLIS desc 
        open depot
        fetch depot into @DPCODE
        while (@@sqlstatus=0)
        begin
                select @depot='',@nbArticle=0
                
                exec x_PrepDepotTest1 @pCC,@DPCODE,@depot output,@nbArticle output,@id_User
                if (@depot<>'')
                begin
                        
                        exec x_CreateListePrepa2 @pCC,@depot,@id_User
                                       
                        insert into #DEPOT (COMMANDE,DEPOT,ARTICLE) values (@pCC,@depot,@nbArticle) 
                end
                fetch depot into @DPCODE
        end
        close depot
        deallocate cursor depot

                                
        select COMMANDE, DEPOT,ARTICLE from #DEPOT
 
        /*prendre les article qui sont dans la porte*/
        select distinct Article,Emplacement,rayon,depot 
        into #articlePorte
        from DBSUIVI..L6_PREPA,xCorrespRAYON_DIGUE
        where commande=@pCC 
        and ID=@id_User
        and depot=DEPOT
        and Emplacement=PORTE
        
        update DBSUIVI..PREPARATION_COMMANDE set TRANSFERT='Porte'
        from DBSUIVI..PREPARATION_COMMANDE,#articlePorte
        where DEPOT=depot
        and CCLARTICLE=Article
        and ID=@id_User
        and CCLCODE=@pCC 
        
        

        /*pour un article avec des ignes de stock differenet et qui est aussi dans la porte, il faut forcer le blocage de prepa comme toutes les lignes sont dans la porte*/
        update DBSUIVI..L6_PREPA set rayon =#articlePorte.Emplacement
        from DBSUIVI..L6_PREPA,#articlePorte
        where DBSUIVI..L6_PREPA.Article=#articlePorte.Article
        and DBSUIVI..L6_PREPA.depot=#articlePorte.depot
        and ID=@id_User
        and commande=@pCC

        /*Prendre les articlesans emplacement 'DIGUE','0000'*/
        select distinct Article,Emplacement,rayon,depot 
        into #articleSansEmpl
        from DBSUIVI..L6_PREPA,VIEW_FAR
        where commande=@pCC 
        and ID=@id_User
        and Emplacement in ('DIGUE','0000')
        and ARCODE=Article
        and ARTYPE=0
        
        update DBSUIVI..PREPARATION_COMMANDE set TRANSFERT='Sans Empl'
        from DBSUIVI..PREPARATION_COMMANDE,#articleSansEmpl
        where DEPOT=depot
        and CCLARTICLE=Article
        and ID=@id_User
        and CCLCODE=@pCC         




        /*pour un article avec des ignes de stock differenet et qui est aussi dans la porte, il faut forcer le blocage de prepa comme toutes les lignes sont sans emplacement*/
        update DBSUIVI..L6_PREPA set rayon =#articleSansEmpl.Emplacement
        from DBSUIVI..L6_PREPA,#articleSansEmpl
        where DBSUIVI..L6_PREPA.Article=#articleSansEmpl.Article
        and DBSUIVI..L6_PREPA.depot=#articleSansEmpl.depot
        and ID=@id_User
        and commande=@pCC     


        select CCLCODE, CCLARTICLE,ARLIB, COLISAGE, QTE_A_PREPARER, /*PREP_BOITE, PREP_COLIS,*/ DISPO, TRANSFERT,case when (isnull(TRANSFERT,'')='') then 1 else 0 end, DEPOT
        from DBSUIVI..PREPARATION_COMMANDE,VIEW_FAR
        where ID=@id_User
        and ARCODE=CCLARTICLE
        and CCLCODE=@pCC           
      
        /*L6*/
        select Article, Lettre, Designation, LienCode, LienNum, Qte, UnitFact, PrixHT, ModeLiv, LigneLibre, TypeVente, Reglement, Echeancesp, abs_Qte, Factman, Offert, Artype, Devise, Coursdev, PrixHTdev, TotHTdev, Rem1, Rem2, Rem3, TotPrixHT, Emplacement, Attachement, Lot, Arreffour, cclmarche, ccldate, cclcolis, arqtecolis, 
        cclpaht,'',0,0,0,0,0,0,depot,'','',0,'','',0,'','','',0,0,0, seqLib, comment_mag, cclcolisage, cclnbcolis, cclpack, case when isnull(rayon,'')<>'' then rayon else Emplacement end
        from DBSUIVI..L6_PREPA
        where commande=@pCC
        and ID=@id_User
        
        /*RAYON*/
        select distinct case when isnull(rayon,'')<>'' then rayon else Emplacement end ,depot,1,count(distinct Article) 
        from DBSUIVI..L6_PREPA 
        where commande=@pCC 
        and ID=@id_User 
        group by rayon,depot 
        order by case when isnull(rayon,'')<>'' then rayon else Emplacement end
        
        --BPLARTICLE,BPLLETTRE,ARLIB,BPLLIENCODE,BPLLIENNUM,BPLQTE,BPLUNITFACT,BPLPRIXHT,VACAR,BPLLIBRE,BPLTYPEVE,ARREGLE,BPLECHSPE,BPLRESTE,BPLFACTMAN,BPLOFFERT,ARTYPE,BPLDEV,BPLCOURSDEV,BPLPRIXHTDEV,BPLTOTALHTDEV,BPLREMISE1,BPLREMISE2,BPLREMISE3,BPLTOTALHT,BPLEMP,BPLATTACHE,STLOT,ARREFFOUR,BPLMARCHE,CCLDATE,BPLCOLIS,ARQTECOLIS,
        --BPLPAHT,NLOTDATEPER,BPLNUM,BPLORDRE,BPLSEQ,BPLTYPE,BPLDOTATION,BPLSTADE,BPLDEPOT,BPLENT,BPLBELIENCODE,BPLBELIENNUM,BPLCODE,BPLCL,ARPOIDS,STDEPOT,STNUMARM1,STNUMARM2,ARNUMEROTE,ARCOMP,VVS0,BPL_SEQLIB,BPL_COMMENT_MAG,BPLCOLISAGE,BPLNBCOLIS,BPLPACK,STEMPEMP

        
        delete from DBSUIVI..PREPARATION_COMMANDE where ID=@id_User
        
        delete from DBSUIVI..STOCK_LOT_EMPLACEMENT_TMP  where ID=@id_User
        
        delete from  DBSUIVI..L6_PREPA where commande=@pCC and ID=@id_User 
        
        drop table #DEPOT
        drop table #articlePorte
        drop table #articleSansEmpl 
        


end
go

