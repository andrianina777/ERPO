


create procedure Change_CLCODE	(	@ent		char(5) = null,
									@old		char(12),
								 	@new		char(12)
								 )
as
begin

declare @seq 		int,
		@compteur	int,
		@base		varchar(30)

declare @crep		char(8),
		@groupe		char(12),
		@client		char(12),
		@art		char(15),
		@an			smallint,
		@mois		smallint
		
select @base=db_name()

/*	curseurs	*/
/* ************ */

declare fbe cursor
for select BESEQ from FBE where BECL=@old and (@ent is null or BEENT=@ent)
for update of BECL

declare fbel cursor
for select BELSEQ from FBEL where BELCL=@old and (@ent is null or BELENT=@ent)
for update of BELCL

declare fcc cursor
for select CCSEQ from FCC where CCCLIENT=@old and (@ent is null or CCENT=@ent)
for update of CCCLIENT

declare fccl cursor
for select CCLSEQ from FCCL where CCLCL=@old and (@ent is null or CCLENT=@ent)
for update of CCLCL

declare fdel cursor
for select DELSEQ from FDEL where DELCL=@old and (@ent is null or DELENT=@ent)
for update of DELCL

declare fex cursor
for select EXSEQ from FEX where EXCL=@old and (@ent is null or EXENT=@ent)
for update of EXCL

declare fexl cursor
for select EXLSEQ from FEXL where EXLCL=@old and (@ent is null or EXLENT=@ent)
for update of EXLCL

declare ffa1 cursor
for select FASEQ from FFA where FACL=@old and (@ent is null or FAENT=@ent)
for update of FACL

declare ffa2 cursor
for select FASEQ from FFA where FACLFACT=@old and (@ent is null or FAENT=@ent)
for update of FACLFACT

declare ffal cursor
for select FALSEQ from FFAL where FALCL=@old and (@ent is null or FALENT=@ent)
for update of FALCL

declare ffal1 cursor
for select FALSEQ from FFAL where FALLIBRE=@old and (@ent is null or FALENT=@ent)
for update of FALLIBRE

declare fstcc cursor
for select STCCREP, STCCGROUPE, STCCCL, STCCART, STCCAN, STCCMOIS 
from FSTCC where STCCCL=@old and (@ent is null or STCCENT=@ent)
for update of STCCCL

declare delfst cursor
for select STREP, STGROUPE, STCL, START, STAN, STMOIS 
from FST where STCL=@old and (@ent is null or STENT=@ent)
for read only

declare delfstcc cursor
for select STCCREP, STCCGROUPE, STCCCL, STCCART, STCCAN, STCCMOIS 
from FSTCC where STCCCL=@old and (@ent is null or STCCENT=@ent)
for read only

/*	update pour les tables ayant peu de lignes a modidier		 */
/* ************************************************************* */

update FACL set ACLCL=@new where ACLCL=@old	and (@ent is null or ACLENT=@ent)	

update FADR set ADRCODELI=@new where ADRCODELI=@old	
and ADRTYPEFIC='CL' and (@ent is null or ADRCODELIENT=@ent)
update FADR set ADRCL=@new where ADRCL=@old	
and ADRTYPEFIC='CL' and (@ent is null or ADRCODELIENT=@ent)

update FCA set CACLIENT=@new where CACLIENT=@old and (@ent is null or CACLENT=@ent)		

update FCL set CLCODE=@new where CLCODE=@old and (@ent is null or CLENT=@ent)		
update FCL2 set CL2CODE=@new where CL2CODE=@old	and (@ent is null or CL2ENT=@ent)	

update FCT2 set CTCL=@new where CTCL=@old and (@ent is null or CTENT=@ent)		

update FOD set ODCLORG=@new where ODCLORG=@old and (@ent is null or ODENT=@ent)		

update FME set MECL=@new where MECL=@old and (@ent is null or MEENT=@ent)

update FRC set RCCL=@new where RCCL=@old and (@ent is null or RCENT=@ent)

update FRCL set RCLCL=@new where RCLCL=@old	and (@ent is null or RCLENT=@ent)	

update KParam set PCLPUB=@new where PCLPUB=@old	and (@ent is null or PENT=@ent)	


/*	open curseur fbe	*/
/* ******************** */

open fbe
fetch fbe into @seq

while (@@sqlstatus=0)
begin  

	update FBE set BECL=@new 
	where current of fbe
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fbe into @seq
end


/*	open curseur fbel	*/
/* ******************** */

open fbel
fetch fbel into @seq

while (@@sqlstatus=0)
begin  

	update FBEL set BELCL=@new	
	where current of fbel
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fbel into @seq
end


/*	open curseur fcc	*/
/* ******************** */

open fcc
fetch fcc into @seq

while (@@sqlstatus=0)
begin  

	update FCC set CCCLIENT=@new	
	where current of fcc
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fcc into @seq
end


/*	open curseur fccl	*/
/* ******************** */

open fccl
fetch fccl into @seq

while (@@sqlstatus=0)
begin  

	update FCCL set CCLCL=@new	
	where current of fccl
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fccl into @seq
end


/*	open curseur fdel	*/
/* ******************** */

open fdel
fetch fdel into @seq

while (@@sqlstatus=0)
begin  

	update FDEL set DELCL=@new	
	where current of fdel
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fdel into @seq
end


/*	open curseur fex	*/
/* ******************** */

open fex
fetch fex into @seq

while (@@sqlstatus=0)
begin  

	update FEX set EXCL=@new	
	where current of fex
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fex into @seq
end

/*	open curseur fexl	*/
/* ******************** */

open fexl
fetch fexl into @seq

while (@@sqlstatus=0)
begin  

	update FEXL set EXLCL=@new	
	where current of fexl
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fexl into @seq
end
	
	
/*	open curseur ffa1	*/
/* ******************** */

open ffa1
fetch ffa1 into @seq

while (@@sqlstatus=0)
begin  

	update FFA set FACL=@new 
	where current of ffa1
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch ffa1 into @seq
end


/*	open curseur ffa2	*/
/* ******************** */

open ffa2
fetch ffa2 into @seq

while (@@sqlstatus=0)
begin  

	update FFA set FACLFACT=@new 
	where current of ffa2
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch ffa2 into @seq
end

/*	open curseur ffal	*/
/* ******************** */

open ffal
fetch ffal into @seq

while (@@sqlstatus=0)
begin  

	update FFAL set FALCL=@new 
	where current of ffal
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch ffal into @seq
end

/*	open curseur ffal1	*/
/* ******************** */

/* open ffal1	*/
/* fetch ffal1 into @seq	*/

/* while (@@sqlstatus=0)	*/
/* begin  	*/

/* 	update FFAL set FALLIBRE=@new 	*/
/* 	where current of ffal1	*/
	
/* 	select @compteur = @compteur + 1	*/
/* 	if @compteur >= 1000	*/
/* 		begin	*/
/* 			dump tran @base with truncate_only	*/
/* 			select @compteur = 0	*/
/* 		end	*/
	
/* 	fetch ffal1 into @seq	*/
/* end	*/

/*	open curseur fstcc	*/
/* ******************** */

open fstcc
fetch fstcc into @crep, @groupe, @client, @art, @an, @mois

while (@@sqlstatus=0)
begin  

	update FSTCC set STCCCL=@new 
	where current of fstcc
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch fstcc into @crep, @groupe, @client, @art, @an, @mois
end

/*	open curseur fst pour detruire les enregistrements de l''ancien code		*/
/* ************************************************************************ */

open delfst
fetch delfst into @crep, @groupe, @client, @art, @an, @mois

while (@@sqlstatus=0)
begin  

	delete FST  
	where STREP=@crep and STGROUPE=@groupe and STCL=@client and START=@art and STAN=@an and STMOIS=@mois
	and (@ent is null or STENT=@ent)
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch delfst into @crep, @groupe, @client, @art, @an, @mois
end

/*	open curseur fstcc pour detruire les enregistrements de l''ancien code	*/
/* ************************************************************************ */

open delfstcc
fetch delfstcc into @crep, @groupe, @client, @art, @an, @mois

while (@@sqlstatus=0)
begin  

	delete FSTCC
	where STCCREP=@crep and STCCGROUPE=@groupe and STCCCL=@client and STCCART=@art and STCCAN=@an and STCCMOIS=@mois
	and (@ent is null or STCCENT=@ent)
	
	select @compteur = @compteur + 1
	if @compteur >= 1000
		begin
			dump tran @base with truncate_only
			select @compteur = 0
		end
	
	fetch delfstcc into @crep, @groupe, @client, @art, @an, @mois
end

end



go

