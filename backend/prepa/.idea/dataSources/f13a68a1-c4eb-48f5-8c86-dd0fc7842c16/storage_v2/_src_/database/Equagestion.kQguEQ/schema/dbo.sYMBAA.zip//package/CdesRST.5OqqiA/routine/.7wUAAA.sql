


/* Procedure donnant les restes a recevoir des Fournisseurs
	avec les sommes a regler correspondantes				*/

create procedure CdesRST	(@ent			char(5)	 = null,
							 @Fournisseur	char(12) = null,
							 @Article		char(15) = null)
with recompile
as
begin

set arithabort numeric_truncation off


create table #ComFourn
(
Fournisseur			char(12)	not null,
Date_Commande		datetime	not null,
Mois_Prevu			tinyint			null,
Annee_Prevue		int				null,
Article				char(15)	not null,
Reste_a_Recevoir	int				null,
TOTALHT				numeric(14,2)	null
)

insert into #ComFourn (Fournisseur,Date_Commande,Mois_Prevu,Annee_Prevue,Article,Reste_a_Recevoir,TOTALHT)
select CFLFO,CFDATE,datepart(mm,isnull(CFLDATEP,CFDATE)),datepart(yy,isnull(CFLDATEP,CFDATE)),
CFLARTICLE,sum(CFLRESTE),round(sum((CFLTOTALHT/CFLQTE)*CFLRESTE*(1+CFFRAIS/100)),2)
from FCFL,FCF
where CFLCODE=CFCODE
and CFLQTE>0
and CFLRESTE>0
and (@Fournisseur is null or CFLFO=@Fournisseur)
and (@Article is null or CFLARTICLE=@Article)
and (@ent is null or (CFLENT=@ent and CFENT=CFLENT))
group by CFLFO,CFDATE,datepart(mm,isnull(CFLDATEP,CFDATE)),datepart(yy,isnull(CFLDATEP,CFDATE)),CFLARTICLE


create table #Final
(
FournF		char(12)			not null,
ArtF		char(15)			not null,
Qte_Tot		int						null,
Tot_HT		numeric(14,2)			null,
mois1		numeric(14,2)			null,
mois2		numeric(14,2)			null,
mois3		numeric(14,2)			null,
mois4		numeric(14,2)			null,
mois5		numeric(14,2)			null,
mois6		numeric(14,2)			null,
mois7		numeric(14,2)			null,
mois8		numeric(14,2)			null,
mois9		numeric(14,2)			null,
mois10		numeric(14,2)			null,
mois11		numeric(14,2)			null,
mois12		numeric(14,2)			null
)

insert into #Final (FournF,ArtF,Qte_Tot,Tot_HT)
select Fournisseur,Article,sum(Reste_a_Recevoir),sum(TOTALHT)
from #ComFourn
group by Fournisseur,Article


/* mois 1 */

insert into  #Final (FournF,ArtF,mois1)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where ((Mois_Prevu<=datepart(mm,getdate())) and (Annee_Prevue=datepart(yy,getdate())))
  or
(Annee_Prevue<datepart(yy,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois2)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,1,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,1,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois3)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,2,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,2,getdate()))
group by Fournisseur,Article



insert into  #Final (FournF,ArtF,mois4)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,3,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,3,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois5)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,4,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,4,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois6)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,5,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,5,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois7)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,6,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,6,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois8)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,7,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,7,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois9)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,8,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,8,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois10)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,9,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,9,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois11)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,10,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,10,getdate()))
group by Fournisseur,Article


insert into  #Final (FournF,ArtF,mois12)
select Fournisseur,Article,sum(TOTALHT)
from #ComFourn
where Mois_Prevu=datepart(mm,dateadd(mm,11,getdate()))
and Annee_Prevue=datepart(yy,dateadd(mm,11,getdate()))
group by Fournisseur,Article


select 'Fournisseur','Article','Designation','Reste_a_Recevoir','Total_HT',
convert(char(14),datename(mm,getdate())+' '+datename(yy,getdate())),
convert(char(14),datename(mm,dateadd(mm,1,getdate()))+' '+datename(yy,dateadd(mm,1,getdate()))),
convert(char(14),datename(mm,dateadd(mm,2,getdate()))+' '+datename(yy,dateadd(mm,2,getdate()))),
convert(char(14),datename(mm,dateadd(mm,3,getdate()))+' '+datename(yy,dateadd(mm,3,getdate()))),
convert(char(14),datename(mm,dateadd(mm,4,getdate()))+' '+datename(yy,dateadd(mm,4,getdate()))),
convert(char(14),datename(mm,dateadd(mm,5,getdate()))+' '+datename(yy,dateadd(mm,5,getdate()))),
convert(char(14),datename(mm,dateadd(mm,6,getdate()))+' '+datename(yy,dateadd(mm,6,getdate()))),
convert(char(14),datename(mm,dateadd(mm,7,getdate()))+' '+datename(yy,dateadd(mm,7,getdate()))),
convert(char(14),datename(mm,dateadd(mm,8,getdate()))+' '+datename(yy,dateadd(mm,8,getdate()))),
convert(char(14),datename(mm,dateadd(mm,9,getdate()))+' '+datename(yy,dateadd(mm,9,getdate()))),
convert(char(14),datename(mm,dateadd(mm,10,getdate()))+' '+datename(yy,dateadd(mm,10,getdate()))),
convert(char(14),datename(mm,dateadd(mm,11,getdate()))+' '+datename(yy,dateadd(mm,11,getdate()))),
convert(char(14),datename(mm,dateadd(mm,12,getdate()))+' '+datename(yy,dateadd(mm,12,getdate())))



select FournF,ArtF,ARLIB,sum(Qte_Tot),sum(Tot_HT),
sum(mois1),sum(mois2),sum(mois3),
sum(mois4),sum(mois5),sum(mois6),
sum(mois7),sum(mois8),sum(mois9),
sum(mois10),sum(mois11),sum(mois12)
from #Final,FAR
where ARCODE=ArtF
group by FournF,ArtF,ARLIB
order by FournF,ArtF
compute sum(sum(Qte_Tot)),sum(sum(Tot_HT)),sum(sum(mois1)),sum(sum(mois2)),sum(sum(mois3)),
sum(sum(mois4)),sum(sum(mois5)),sum(sum(mois6)),sum(sum(mois7)),sum(sum(mois8)),sum(sum(mois9)),
sum(sum(mois10)),sum(sum(mois11)),sum(sum(mois12)) by FournF
compute sum(sum(Qte_Tot)),sum(sum(Tot_HT)),sum(sum(mois1)),sum(sum(mois2)),sum(sum(mois3)),
sum(sum(mois4)),sum(sum(mois5)),sum(sum(mois6)),sum(sum(mois7)),sum(sum(mois8)),sum(sum(mois9)),
sum(sum(mois10)),sum(sum(mois11)),sum(sum(mois12))


drop table #ComFourn
drop table #Final

end



go

