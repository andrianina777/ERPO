


create procedure NewFMS_Mois (@an		smallint,
							  @mois		tinyint)
with recompile
as
begin

declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@date1			datetime,
		@date2			datetime

if @mois=1
	begin
		select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'01/31/'+convert(varchar(4),@an))
	end
else if @mois=2
	begin
		select @smalldate1=convert(smalldatetime,'02/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		select @smalldate2=dateadd(dd,-1,@smalldate2)
	end
else if @mois=3
	begin
		select @smalldate1=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'03/31/'+convert(varchar(4),@an))
	end
else if @mois=4
	begin
		select @smalldate1=convert(smalldatetime,'04/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'04/30/'+convert(varchar(4),@an))
	end
else if @mois=5
	begin
		select @smalldate1=convert(smalldatetime,'05/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'05/31/'+convert(varchar(4),@an))
	end
else if @mois=6
	begin
		select @smalldate1=convert(smalldatetime,'06/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'06/30/'+convert(varchar(4),@an))
	end
else if @mois=7
	begin
		select @smalldate1=convert(smalldatetime,'07/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'07/31/'+convert(varchar(4),@an))
	end
else if @mois=8
	begin
		select @smalldate1=convert(smalldatetime,'08/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'08/31/'+convert(varchar(4),@an))
	end
else if @mois=9
	begin
		select @smalldate1=convert(smalldatetime,'09/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'09/30/'+convert(varchar(4),@an))
	end
else if @mois=10
	begin
		select @smalldate1=convert(smalldatetime,'10/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'10/31/'+convert(varchar(4),@an))
	end
else if @mois=11
	begin
		select @smalldate1=convert(smalldatetime,'11/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'11/30/'+convert(varchar(4),@an))
	end
else if @mois=12
	begin
		select @smalldate1=convert(smalldatetime,'12/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))
	end


select @date1 = convert(datetime,@smalldate1)
select @date2 = convert(datetime,@smalldate2)


create table #Far
(
ARCODE	char(15)	null,
CVLOT	int			null
)

insert into #Far
select ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF

create unique clustered index code on #Far (ARCODE)


create table #Far2
(
ARCODE	char(15)	not null,
CVLOT	int				null
)

insert into #Far2
select ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF

create unique clustered index code on #Far2 (ARCODE)


select Article=SILARTICLE,Annee=datepart(yy,SILDATE),Mois=datepart(mm,SILDATE),
Total=sum(SILQTE),PrixRevientTot=sum(round(((SILPAHT+SILFRAIS)/CVLOT),2)*SILQTE),Type='F',
Depot=SILNUMDEP
into #Entree
from FSIL,#Far
where SILARTICLE=ARCODE
and SILDATE between @smalldate1 and @smalldate2
group by SILARTICLE,datepart(yy,SILDATE),datepart(mm,SILDATE),SILNUMDEP
having sum(SILQTE)!=0


insert into #Entree
select RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),
sum(RJLQTE),sum(round(((RJLPAHT+RJLFRAIS)/CVLOT),2)*RJLQTE),'R',RJLNUMDEP
from FRJL,#Far
where RJLARTICLE=ARCODE
and RJLDATE between @smalldate1 and @smalldate2
group by RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),RJLNUMDEP
having sum(RJLQTE)!=0


insert into #Entree
select LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),
sum(LCLQTE),sum(round(((LCLPAHT+LCLFRAIS)/CVLOT),2)*LCLQTE),'C',LCLNUMDEP
from FLCL,#Far2
where LCLARTICLE=ARCODE
and LCLDATE between @date1 and @date2
group by LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),LCLNUMDEP
having sum(LCLQTE)!=0


insert into #Entree
select ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),
sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE),'A',ASLNUMDEP
from FASL,#Far2
where ASLARTICLE=ARCODE
and ASLDATE between @date1 and @date2
group by ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),ASLNUMDEP
having sum(ASLQTE)!=0


insert into #Entree
select RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),
sum(RMQTE),sum(round(((RMPAHT+RMFRAIS)/CVLOT),2)*RMQTE),'M',RMNUMDEP
from FRM,#Far
where RMARTICLE=ARCODE
and RMDATE between @smalldate1 and @smalldate2
group by RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),RMNUMDEP
having sum(RMQTE)!=0


insert into #Entree
select BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),
sum(BLLQTE),sum(round(((BLLPRHT)/CVLOT),2)*BLLQTE),'E',BLLNUMDEP
from FBLL,FCV
where BLLUA=CVUNIF
and BLLDATE between @smalldate1 and @smalldate2
group by BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),BLLNUMDEP
having sum(BLLQTE)!=0


insert into #Entree
select DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),
sum(DOLQTE),sum(round(((DOLPRHT)/CVLOT),2)*DOLQTE),'E',DOLNUMDEP
from FDOL,FCV
where DOLUA=CVUNIF
and DOLDATE between @smalldate1 and @smalldate2
group by DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),DOLNUMDEP



insert into #Entree
select RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),
-(sum(RFLQTE)),-(sum(round(((RFLPAHT)/CVLOT),2)*RFLQTE)),'E',RFLNUMDEP
from FRFL,FCV
where RFLUNITACHAT=CVUNIF
and RFLDATE between @smalldate1 and @smalldate2
group by RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),RFLNUMDEP
having sum(RFLQTE)!=0



insert into #Entree
select FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE),
sum(FALQTE),sum(round(((STPAHT+STFRAIS)/CVLOT),2)*FALQTE),'S',1
from FFAL,FSTOCK,#Far
where FALARTICLE=ARCODE
and FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALDATE between @smalldate1 and @smalldate2
group by FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE)



delete from FMS
where MSANNEE = @an
and MSMOIS = @mois


insert into FMS(MSARTICLE,MSANNEE,MSMOIS,MSQTE,MSTOTPR,MSTYPE,MSDEPOT)
select Article,Annee,Mois,QteTot=sum(Total),PrixTot=sum(PrixRevientTot),Type,Depot
from #Entree
group by Article,Annee,Mois,Type,Depot
order by Article,Annee,Mois,Type,Depot

drop table #Entree
drop table #Far
drop table #Far2

end



go

