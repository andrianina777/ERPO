





create procedure Maj_PRM_Mensuel_PUMP	 
 
with recompile 
as 
begin 
 
	declare @an         int, 
	        @article	char(15), 
	        @date       datetime, 
	        @mois	    int, 
	        @nbresult   int, 
	        @prix       numeric(14,4), 
	        @seq		int, 
	        @userid		int 
	        
	/* On veut que le prix soit affiche pour le mois precedent */  
	select @date=dateadd(mm,-1,getdate()) 
	 
	select @an=datepart(yy,@date) 
	select @mois=datepart(mm,@date) 
 
	select @userid=(select user_id()) 
 
    declare articles cursor  
    for select ARCODE  
    from FAR 
    where isnull(AROLD,0)=0 
 
    open articles 
 
    fetch articles 
    into @article 
 
    while (@@sqlstatus = 0) 
	begin 
	 
	    select @nbresult=count(*) from FPRM where PRMAR=@article and PRMAN=@an and PRMMOIS=@mois 
	    /* si un prix de revient manuel a ete entre on ne passe pas par la proc auto */ 
	    if @nbresult=0 
	    begin 
	        	         
	        /* Recuperation du dernier PUMP */ 
	        select @prix=isnull(PUMP,0) from FPUM  
	        where PUMAR=@article and PUMDATE=(select max(PUMDATE) from FPUM where PUMAR=@article) 
 
	        exec eq_GetSeq_proc "FPRM", 1, @seq output 
	     	     
	        insert into FPRM (PRMSEQ,PRMAR,PRMAN,PRMMOIS,PRM,PRMUSERCRE,PRMDATECRE,PRMUSERMDF,PRMDATEMDF) 
	        select @seq,@article,@an,@mois,@prix,@userid,getdate(),@userid,getdate() 
         
	    end 
	                
	    fetch articles 
	    into @article 
	 
    end 
 
    close articles 
    deallocate cursor articles 
 
end 




go

