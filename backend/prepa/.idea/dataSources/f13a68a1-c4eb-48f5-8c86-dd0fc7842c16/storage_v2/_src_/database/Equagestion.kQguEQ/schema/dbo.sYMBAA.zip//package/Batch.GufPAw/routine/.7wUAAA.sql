



create proc Batch
with recompile
as
begin


  declare @an 		int,
  		  @multient	tinyint
		  
  select @multient = KIMULTIENTITE from KInfos
  select @an =datepart(year,getdate())
  
if @multient = 0
  begin
	exec RFA_Depart null,@an 
	exec RFA_Chef null,@an 
	exec RFA_Rep null,@an 
	exec RFA_TBGL null,@an 
  end
else
  begin
  
  declare @labase		varchar(30),
		  @suserid		int,
		  @susername	varchar(30)
  select  @labase = db_name(),
  		  @suserid = suser_id(),
		  @susername = suser_name()

  declare boucle cursor 
  for select PENT
  from KParam
  for read only
  
  declare @ent char(5)
  
  open boucle
  
  fetch boucle
  into @ent
  
  while (@@sqlstatus = 0)
	begin
	  
	  exec RFA_Depart @ent,@an 
	  dump tran @labase with truncate_only
	  
	  exec RFA_Chef @ent,@an 
	  dump tran @labase with truncate_only
	  
	  exec RFA_Rep @ent,@an 
	  dump tran @labase with truncate_only
	  
	  exec RFA_TBGL @ent,@an 
	  dump tran @labase with truncate_only
	  	  
	  fetch boucle
	  into @ent
	  
	end
  
	close boucle
	deallocate cursor boucle
  
  end
  
end



go

