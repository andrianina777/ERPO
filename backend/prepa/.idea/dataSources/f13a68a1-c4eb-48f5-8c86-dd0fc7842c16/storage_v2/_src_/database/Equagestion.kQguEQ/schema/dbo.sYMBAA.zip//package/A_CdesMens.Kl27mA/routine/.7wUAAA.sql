


/* Procedure permettant de recuperer les commandes constates sur une annee
	pour un article dans le fichier FSTCC  */
	

create procedure A_CdesMens (	@Article	char(15),
						  	 	@Annee		smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int

declare @Janval		int
declare @Fevval		int
declare @Marval		int
declare @Avrval		int
declare @Maival		int
declare @Junval		int
declare @Juival		int
declare @Aouval		int
declare @Sepval		int
declare @Octval		int
declare @Novval		int
declare @Decval		int


select 	@Janvier=sum(case when STCCMOIS=1 then STCCQTE else 0 end),
		@Janval=sum(case when STCCMOIS=1 then STCCCA else 0 end),
		@Fevrier=sum(case when STCCMOIS=2 then STCCQTE else 0 end),
		@Fevval=sum(case when STCCMOIS=2 then STCCCA else 0 end),
		@Mars=sum(case when STCCMOIS=3 then STCCQTE else 0 end),
		@Marval=sum(case when STCCMOIS=3 then STCCCA else 0 end),
		@Avril=sum(case when STCCMOIS=4 then STCCQTE else 0 end),
		@Avrval=sum(case when STCCMOIS=4 then STCCCA else 0 end),
		@Mai=sum(case when STCCMOIS=5 then STCCQTE else 0 end),
		@Maival=sum(case when STCCMOIS=5 then STCCCA else 0 end),
		@Juin=sum(case when STCCMOIS=6 then STCCQTE else 0 end),
		@Junval=sum(case when STCCMOIS=6 then STCCCA else 0 end),
		@Juillet=sum(case when STCCMOIS=7 then STCCQTE else 0 end),
		@Juival=sum(case when STCCMOIS=7 then STCCCA else 0 end),
		@Aout=sum(case when STCCMOIS=8 then STCCQTE else 0 end),
		@Aouval=sum(case when STCCMOIS=8 then STCCCA else 0 end),
		@Septembre=sum(case when STCCMOIS=9 then STCCQTE else 0 end),
		@Sepval=sum(case when STCCMOIS=9 then STCCCA else 0 end),
		@Octobre=sum(case when STCCMOIS=10 then STCCQTE else 0 end),
		@Octval=sum(case when STCCMOIS=10 then STCCCA else 0 end),
		@Novembre=sum(case when STCCMOIS=11 then STCCQTE else 0 end),
		@Novval=sum(case when STCCMOIS=11 then STCCCA else 0 end),
		@Decembre=sum(case when STCCMOIS=12 then STCCQTE else 0 end),
		@Decval=sum(case when STCCMOIS=12 then STCCCA else 0 end)
from FSTCC
where STCCART=@Article
and STCCAN=@Annee

select 	isnull(@Janvier,0),isnull(@Fevrier,0),isnull(@Mars,0),
		isnull(@Avril,0),isnull(@Mai,0),isnull(@Juin,0),
		isnull(@Juillet,0),isnull(@Aout,0),isnull(@Septembre,0),
		isnull(@Octobre,0),isnull(@Novembre,0),isnull(@Decembre,0),
		isnull(@Janval,0),isnull(@Fevval,0),isnull(@Marval,0),
		isnull(@Avrval,0),isnull(@Maival,0),isnull(@Junval,0),
		isnull(@Juival,0),isnull(@Aouval,0),isnull(@Sepval,0),
		isnull(@Octval,0),isnull(@Novval,0),isnull(@Decval,0)
end



go

