


/* Procedure renvoyant les chiffres d''affaires, qtes livrees par les fournisseurs
	et commandes pour les annees N-2, N-1, annee en cours en Devise et en monnaie de reference */

create procedure CAFODev (	@fourn	char(12) = null,
							@an 	smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @d1 datetime,@d2 datetime
select @d1=convert(datetime,convert(char(4),@an-2)+"0101")
select @d2=dateadd(year,3,@d1)

create table #CA
(	
FAM			char(8)			not null,
DEV			char(3)				null,
AN			smallint			null,
QTEBL		int					null,
PADEVBL		numeric(14,2)		null,
PAFFBL		numeric(14,2)		null,
QTECF		int					null,
PADEVCF		numeric(14,2)		null,
PAFFCF		numeric(14,2)		null
)

if @fourn is null
  begin
  
	/* Pour tous les fournisseurs */
	/* Les lignes livree jusqu''ici dans la periode */
	
	insert into #CA
	select ARFAM,BLLDEV,AN=datepart(year,BLLDATE),QTEBL=sum(BLLQTE),PATOTDEV=sum(BLLTOTDEV),
	PATOTHT=sum(BLLTOTHT),0,0,0
	from FBLL,FAR
	where BLLDATE>=@d1 and BLLDATE<@d2
	and BLLAR=ARCODE
	group by ARFAM,BLLDEV,datepart(year,BLLDATE)
	
	/* les lignes retournees */
	
	insert into #CA
	select ARFAM,FODEVISE,AN=datepart(year,RFLDATE),QTERF=-sum(RFLQTE),
			PATOTDEV=-sum(RFLTOTALDEV),PATOTHT=-sum(RFLTOTALHT),0,0,0
	from FRFL,FAR,FFO
	where RFLDATE>=@d1 and RFLDATE<@d2
		and RFLARTICLE=ARCODE
		and RFLFO=FOCODE
	group by ARFAM,FODEVISE,datepart(year,RFLDATE)
	
	/* Les cdes non soldee, toute periode confondues */
	
	insert into #CA
	select ARFAM,CFLDEVISE,AN=datepart(year,CFLDATEP),0,0,0,RESTE=sum(CFLRESTE),
			PADEV=round(sum((CFLTOTALDEV/CFLQTE)*CFLRESTE),2),
			PAHT=round(sum((CFLTOTALHT/CFLQTE)*CFLRESTE),2)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
		and CFLQTE != 0
		and CFLARTICLE=ARCODE
	group by ARFAM,CFLDEVISE,datepart(year,CFLDATEP)
	
  end
else
  begin
	/* Pour le fournisseur @fourn */
	/* Les lignes livree jusqu''ici dans la periode */
	
	insert into #CA
	select ARFAM,BLLDEV,AN=datepart(year,BLLDATE),QTEBL=sum(BLLQTE),PATOTDEV=sum(BLLTOTDEV),
			PATOTHT=sum(BLLTOTHT),0,0,0
	from FBLL,FAR
	where BLLFO=@fourn
		and BLLDATE>=@d1 and BLLDATE<@d2
		and BLLAR=ARCODE
	group by ARFAM,BLLDEV,datepart(year,BLLDATE)
	
	/* les lignes retournees */
	insert into #CA
	select ARFAM,FODEVISE,AN=datepart(year,RFLDATE),QTERF=-sum(RFLQTE),PATOTDEV=-sum(RFLTOTALDEV),PATOTHT=-sum(RFLTOTALHT),0,0,0
	from FRFL,FAR,FFO
	where RFLDATE>=@d1 and RFLDATE<@d2
		and RFLARTICLE=ARCODE
		and RFLFO=@fourn
		and RFLFO=FOCODE
	group by ARFAM,FODEVISE,datepart(year,RFLDATE)
	
	/* Les cdes non soldee, toute periode confondues */
	
	insert into #CA
	select ARFAM,CFLDEVISE,AN=datepart(year,CFLDATEP),0,0,0,RESTE=sum(CFLRESTE),
			PADEV=round(sum((CFLTOTALDEV/CFLQTE)*CFLRESTE),2),
			PAHT=round(sum((CFLTOTALHT/CFLQTE)*CFLRESTE),2)
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
		and CFLFO="BUSHNE"
		and CFLQTE != 0
		and CFLARTICLE=ARCODE
	group by ARFAM,CFLDEVISE,datepart(year,CFLDATEP)
	
  end
  
select FAM,FPLIB,DEV,
		QTEBLN2=sum(QTEBL*(1-sign(abs(AN-@an+2)))),
		PADEVBLN2=sum(PADEVBL*(1-sign(abs(AN-@an+2)))),
		PAFFBLN2=sum(PAFFBL*(1-sign(abs(AN-@an+2)))),
		QTEBLN1=sum(QTEBL*(1-sign(abs(AN-@an+1)))),
		PADEVBLBLN1=sum(PADEVBL*(1-sign(abs(AN-@an+1)))),
		PAFFBLBLN1=sum(PAFFBL*(1-sign(abs(AN-@an+1)))),
		QTEBLN0=sum(QTEBL*(1-sign(abs(AN-@an)))),
		PADEVBLBLN0=sum(PADEVBL*(1-sign(abs(AN-@an)))),
		PAFFBLBLN0=sum(PAFFBL*(1-sign(abs(AN-@an)))),
		QTECFN0=sum(QTECF),
		PADEVCFN0=sum(PADEVCF),
		PAFFCFN0=sum(PAFFCF)
from #CA,FFP
where FPCODE=FAM
group by FAM,FPLIB,DEV
order by FAM,DEV

drop table #CA

end



go

