


create procedure StatRepFam (	@ent		char(5) = null,
								@rep		char(8),
							 	@anobj		smallint,
							 	@marque		char(8),
							 	@famille	char(6) = null,
								@division	char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off


create table #MAR
(
marque		char(8)		not null,
famille		char(6)		not null,
ventes_N2	int				null,
ventes_N1	int				null,
ventes_N1P	int				null,
ventes_N	int				null,
cdes		int				null,
prix_moyen	numeric(14,2)	null,
objectif	int				null,
realise_pc	numeric(14,2)	null,
ca_encours	numeric(14,2)	null
)

create table #Final
(
marque		char(8)		not null,
famille		char(6)		not null,
ventes_N2	int				null,
ventes_N1	int				null,
ventes_N1P	int				null,
ventes_N	int				null,
cdes		int				null,
prix_moyen	numeric(14,2)	null,
objectif	int				null,
realise_pc	numeric(14,2)	null,
ca_encours	numeric(14,2)	null
)

declare @an		smallint,
		@mois	tinyint
		
select  @an  =convert(smallint,datepart(yy,getdate())),
		@mois=convert(tinyint,datepart(mm,getdate()))
		
declare @type	tinyint
select  @type=RETYPE from FREP where RECODE=@rep

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos


					/*******************/

insert into #MAR (marque,famille,ventes_N2,ventes_N1,ventes_N1P,ventes_N,
					cdes,prix_moyen,objectif,realise_pc,ca_encours)
select ARFO,ARFAM,0,0,0,0,0,0,0,0,0
from FAR
where ARFO=@marque
and (@famille is null or ARFAM=@famille)
and (@division is null or ARDEPART = @division)
group by ARFO,ARFAM


					/****** Chiffres sur les annees N-2, N-1 & N ******/

insert into #MAR (marque,famille,ventes_N2,ventes_N1,ventes_N,ca_encours)
select ARFO,ARFAM,
		sum(STQTEFA*(1-sign(abs(STAN-@an+2)))),
		sum(STQTEFA*(1-sign(abs(STAN-@an+1)))),
		sum(STQTEFA*(1-sign(abs(STAN-@an)))),
		sum(STCAFA*(1-sign(abs(STAN-@an))))
from FST,FAR
where (@multient=0 or @ent is null or STENT=@ent)
and (@type = 2 or STREP=@rep)
and (@type != 2 or STREPDIV=@rep)
and ARCODE=START
and ARFO=@marque
and (@famille is null or ARFAM=@famille)
and (@division is null or ARDEPART = @division)
group by ARFO,ARFAM

	
					/****** Insertion des chiffres sur l''annee N-1 partielle ******/

insert into #MAR (marque,famille,ventes_N1P)
select ARFO,ARFAM,sum(STQTEFA*(1-sign(abs(STAN-@an+1))))
from FST,FAR
where (@multient=0 or @ent is null or STENT=@ent)
and (@type = 2 or STREP=@rep)
and (@type != 2 or STREPDIV=@rep)
and ARCODE=START
and STAN=@an-1
and STMOIS between 1 and @mois
and ARFO=@marque		
and (@famille is null or ARFAM=@famille)
and (@division is null or ARDEPART = @division)
group by ARFO,ARFAM

					/****** Insertion des commandes a livrer ******/


insert into #MAR (marque,famille,cdes)
select ARFO,ARFAM,sum(RCCQTE)
from FRCC,FAR,FCCL,FCC
where (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and (@type = 2 or CCLREP=@rep)
and (@type != 2 or CCLREPDIV=@rep)
and ARCODE=RCCARTICLE
and ARFO=@marque		
and (@famille is null or ARFAM=@famille)
and (@division is null or ARDEPART = @division)
group by ARFO,ARFAM

					

					/****** Insertion des objectifs ******/
					
 insert into #MAR (marque,famille,objectif)
 select ORMARQUE,ORFAM,sum(isnull(ORQTE,0))
 from FOREP
 where (@multient=0 or @ent is null or ORENT=@ent)
 and ORREP=@rep
 and ORMARQUE=@marque
 and (@famille is null or ORFAM=@famille)
 and (@division is null or ORDEPART = @division)
 and ORAN=@anobj
 group by ORMARQUE,ORFAM
		
					
					/****** Regroupement dans la table finale ******/
					
insert into #Final (marque,famille,ventes_N2,ventes_N1,ventes_N1P,ventes_N,cdes,objectif,ca_encours)
select marque,famille,sum(ventes_N2),sum(ventes_N1),sum(ventes_N1P),sum(ventes_N),
				sum(cdes),sum(objectif),sum(ca_encours)
from #MAR
group by marque,famille

drop table #MAR

					/******* Maj des valeurs en division *******/

update #Final
set prix_moyen = round(isnull(ca_encours,0)/isnull(convert(numeric(14,2),ventes_N),0),2)
where isnull(ventes_N,0) != 0

update #Final
set prix_moyen = 0.00
where isnull(ventes_N,0) = 0

update #Final
set realise_pc = isnull(convert(numeric(14,2),ventes_N),0)/isnull(convert(numeric(14,2),objectif),0)*100
where isnull(objectif,0) != 0

update #Final
set realise_pc = 0.00
where isnull(objectif,0) = 0

					/******** select final *********/
		
select Marque=marque,Famille=famille,Annee_2=isnull(ventes_N2,0),Annee_1=isnull(ventes_N1,0),
			Annee_1_partiel=isnull(ventes_N1P,0),Annee_en_cours=isnull(ventes_N,0),
			Cdes=isnull(cdes,0),Prix_moyen=abs(prix_moyen),Objectifs=isnull(objectif,0),
			Realise_pc=realise_pc,Chiffre_affaires=isnull(ca_encours,0)
from #Final
order by marque,famille


drop table #Final

end



go

