

create procedure Maj_RERSATISFAITE  (@fiche	char(10))
with recompile
as
begin

	/* version du 010608 */

  declare	@nbLignesTotal		int,
			@nbLignesSoldees	int,
			@satisfaite			int
	
		  
  select @satisfaite = 0 /* en attente */
  
  select @nbLignesTotal=count(*) from FRERL1 where RERL1RER=@fiche
  
  if @nbLignesTotal > 0
  begin
  
		select @nbLignesSoldees=sum(isnull(RERL1SOLDEE,0))
		from FRERL1
		where RERL1RER=@fiche
		
		if @nbLignesSoldees = @nbLignesTotal select @satisfaite = 2			/* soldee */
										else select @satisfaite = 1 		/* en cours */
		
	end
	
	update FRER set RERSATISFAITE = @satisfaite	where RERCODE=@fiche 

end
go

