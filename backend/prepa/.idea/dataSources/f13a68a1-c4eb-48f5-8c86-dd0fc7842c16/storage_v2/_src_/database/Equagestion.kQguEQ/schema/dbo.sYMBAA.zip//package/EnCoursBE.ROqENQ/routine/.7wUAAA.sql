


create procedure EnCoursBE			       (@ent		char(5) = null,
							@client 	char(12) = null,
							@groupe		tinyint = null,		
							@depart		char(8) = null,
							@marque		char(12) = null,
							@grfam		char(8) = null,
							@famille	char(8) = null,
							@article	char(15) = null,
							@produits	smallint = null,
							@prodnsto	smallint = null,
							@services	smallint = null,
							@ports		smallint = null,
							@comments	smallint = null,
							@remises	smallint = null,
							@rfa		smallint = null,
							@assur		smallint = null,
							@classe		smallint = null
							)
with recompile
as
begin
declare @type	tinyint
if (@produits is not null) or (@prodnsto is not null) or (@services is not null) or (@ports is not null) or (@comments is not null)
	or (@remises is not null) or (@rfa is not null) or (@assur is not null)
	select @type = 1
else
	select @type = 0

set forceplan on

if @groupe is null select @groupe=0

if @groupe=0
begin
	if @type = 0
		begin
		select Montant=sum(case when RBEDEMO=0 then BELTOTALHT else 0 end),Demo=sum(case when RBEDEMO=1 then BELTOTALHT else 0 end)
		from FRBE,FBEL,FAR
		where BELSEQ=RBESEQ 
		and ARCODE=RBEARTICLE
		and (@client is null  or RBECL=@client)
		and (@depart is null or ARDEPART=@depart)
		and (@marque is null or ARFO=@marque)
		and (@grfam is null or ARGRFAM=@grfam)
		and (@famille is null or ARFAM=@famille)
		and (@article is null or ARCODE=@article)
		and (@classe is null or exists (select * from FCL,FTBGC where FRBE.RBECL=CLCODE and TBGCCLASSE=CLCLASSE))
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		end
	else if @type = 1
		begin
		select Montant=sum(case when RBEDEMO=0 then BELTOTALHT else 0 end),
		Demo=sum(case when RBEDEMO=1 then BELTOTALHT else 0 end)
		from FRBE,FBEL,FAR
		where BELSEQ=RBESEQ 
		and ARCODE=RBEARTICLE 
		and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
		and (@client is null  or RBECL=@client)
		and (@depart is null or ARDEPART=@depart)
		and (@marque is null or ARFO=@marque)
		and (@grfam is null or ARGRFAM=@grfam)
		and (@famille is null or ARFAM=@famille)
		and (@article is null or ARCODE=@article)
		and (@classe is null or exists (select * from FCL,FTBGC where FRBE.RBECL=CLCODE and TBGCCLASSE=CLCLASSE))
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		end
end
else
begin
	if @type = 0
		begin
		select Montant=sum(case when RBEDEMO=0 then BELTOTALHT else 0 end),Demo=sum(case when RBEDEMO=1 then BELTOTALHT else 0 end)
		from FRBE,FBEL,FAR,FCL
		where BELSEQ=RBESEQ 
		and ARCODE=RBEARTICLE
		and BELCL=CLCODE
		and (@client is null  or CLCODEGROUPE=@client)
		and (@depart is null or ARDEPART=@depart)
		and (@marque is null or ARFO=@marque)
		and (@grfam is null or ARGRFAM=@grfam)
		and (@famille is null or ARFAM=@famille)
		and (@article is null or ARCODE=@article)
		and (@classe is null or exists (select * from FCL,FTBGC where FRBE.RBECL=CLCODE and TBGCCLASSE=CLCLASSE))
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		end
	else if @type = 1
		begin
		select Montant=sum(case when RBEDEMO=0 then BELTOTALHT else 0 end),
		Demo=sum(case when RBEDEMO=1 then BELTOTALHT else 0 end)
		from FRBE,FBEL,FAR,FCL
		where BELSEQ=RBESEQ 
		and ARCODE=RBEARTICLE 
		and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
		and BELCL=CLCODE 
		and (@client is null  or CLCODEGROUPE=@client)
		and (@depart is null or ARDEPART=@depart)
		and (@marque is null or ARFO=@marque)
		and (@grfam is null or ARGRFAM=@grfam)
		and (@famille is null or ARFAM=@famille)
		and (@article is null or ARCODE=@article)
		and (@classe is null or exists (select * from FCL,FTBGC where FRBE.RBECL=CLCODE and TBGCCLASSE=CLCLASSE))
		and (@ent is null or (BELENT=@ent and RBEENT=@ent))
		end
end

set forceplan off
end



go

