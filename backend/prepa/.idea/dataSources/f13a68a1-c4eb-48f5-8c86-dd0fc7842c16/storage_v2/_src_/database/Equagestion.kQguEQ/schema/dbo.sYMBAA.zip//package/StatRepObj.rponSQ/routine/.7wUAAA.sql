


create procedure StatRepObj (	@ent		char(5) 	= null,
								@rep		char(8),
								@typerep	tinyint,
								@detail		tinyint,
							 	@an			smallint,
								@sansobj0	tinyint		= 0,
								@depart		char(8) 	= null,
							 	@marque		char(12) 	= null,
							 	@famille	char(8) 	= null
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @mois	tinyint
select  @mois=convert(tinyint,datepart(mm,getdate()))

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos

declare @code	char(8)
declare	@type	tinyint

create table #REP
(
trep 	char(8)not null,
ttype	tinyint
)

create table #MAR
(
repres		char(8)		not null,
depart		char(8)		not null,
marque		char(12)	not null,
famille		char(8)		not null,
ventes_N1	int				null,
ventes_N1P	int				null,
ventes_N	int				null,
cdes		int				null,
objectif	int				null
)

create table #Final
(
repres		char(8)		not null,
depart		char(8)		not null,
marque		char(12)	not null,
famille		char(8)		not null,
ventes_N1	int				null,
ventes_N1P	int				null,
ventes_N	int				null,
cdes		int				null,
objectif	int				null
)

/* table des reprÃ?sentants */
if isnull(@rep,'')=''
 begin
	if @typerep=0
		insert into #REP (trep,ttype)
		select RECODE,RETYPE from FREP 
		where RETYPE<>2
	else
		insert into #REP (trep,ttype)
		select RECODE,RETYPE from FREP 
		where RETYPE=2
 end
else
	insert into #REP (trep,ttype)
		select RECODE,RETYPE from FREP 
		where RECODE=@rep

declare representant cursor 
  for select trep,ttype from #REP
  for read only
		
open representant
	
	fetch representant
	into @code,@type
	
	while (@@sqlstatus = 0)
		begin		
		
          /* table de base de travail */
          insert into #MAR (repres,depart,marque,famille,ventes_N1,ventes_N1P,ventes_N,cdes,objectif)
          select @code,ARDEPART,ARFO,ARFAM,0,0,0,0,0
          from FAR
          where (@depart is null or ARDEPART=@depart)
          and (@marque is null or ARFO=@marque)
          and (@famille is null or ARFAM=@famille)
          group by ARDEPART,ARFO,ARFAM
          
          
          					/****** Chiffres sur les annees  N-1 & N ******/
          
          insert into #MAR (repres,depart,marque,famille,ventes_N1,ventes_N)
          select @code,ARDEPART,ARFO,ARFAM,
          		sum(case when STAN = @an-1 then STQTEFA else 0 end),
          		sum(case when STAN = @an then STQTEFA else 0 end)
          from FST,FAR
          where ARCODE=START
          and (@type = 2 or STREP=@code)
          and (@type != 2 or STREPDIV=@code)
          and (@depart is null or ARDEPART=@depart)
          and (@marque is null or ARFO=@marque)
          and (@famille is null or ARFAM=@famille)
          and (@multient=0 or @ent is null or STENT=@ent)
          group by ARDEPART,ARFO,ARFAM
          	
          					/****** Insertion des chiffres sur l''annee N-1 partielle ******/
          
          insert into #MAR (repres,depart,marque,famille,ventes_N1P)
          select @code,ARDEPART,ARFO,ARFAM,sum(STQTEFA)
          from FST,FAR
          where ARCODE=START
          and (@type = 2 or STREP=@code)
          and (@type != 2 or STREPDIV=@code)
          and STAN=@an-1
          and STMOIS between 1 and @mois
          and (@depart is null or ARDEPART=@depart)
          and (@marque is null or ARFO=@marque)
          and (@famille is null or ARFAM=@famille)
          and (@multient=0 or @ent is null or STENT=@ent)
          group by ARDEPART,ARFO,ARFAM
          	
          
          					/****** Insertion des commandes a livrer ******/
          					
          insert into #MAR (repres,depart,marque,famille,cdes)
          select @code,ARDEPART,ARFO,ARFAM,sum(RCCQTE)
          from FRCC,FAR,FCC,FCCL
          where CCLSEQ=RCCSEQ
          and CCCODE=CCLCODE
          and isnull(CCVALIDE,0)=0
          and (@type = 2 or CCLREP=@code)
          and (@type != 2 or CCLREPDIV=@code)
          and ARCODE=RCCARTICLE
          and (@depart is null or ARDEPART=@depart)
          and (@marque is null or ARFO=@marque)
          and (@famille is null or ARFAM=@famille)
          and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=@ent and CCLENT=@ent))
          group by ARDEPART,ARFO,ARFAM
          	
          	
          					/****** Insertion des objectifs ******/
          					
          insert into #MAR (repres,depart,marque,famille,objectif)
          select @code,ORDEPART,ORMARQUE,ORFAM,isnull(ORQTE,0)
          from FOREP
          where ORREP=@code
          and (@depart is null or ORDEPART=@depart)
          and (@marque is null or ORMARQUE=@marque)
          and (@famille is null or ORFAM=@famille)
          and ORAN=@an
          and (@multient=0 or @ent is null or ORENT=@ent)
					

		fetch representant
		into @code,@type
					
	end

close representant
deallocate cursor representant
										
		
					/****** Regroupement dans la table finale ******/
if (@sansobj0 = 0)
 begin
  if @detail=1	
  	insert into #Final (repres,depart,marque,famille,ventes_N1,ventes_N1P,ventes_N,cdes,objectif)
  	select repres,depart,marque,famille,sum(ventes_N1),sum(ventes_N1P),sum(ventes_N),
				  sum(cdes),sum(objectif)
  	from #MAR
  	group by repres,depart,marque,famille
  else if @detail=0	
  	insert into #Final (repres,depart,marque,famille,ventes_N1,ventes_N1P,ventes_N,cdes,objectif)
  	select '',depart,marque,famille,sum(ventes_N1),sum(ventes_N1P),sum(ventes_N),
				  sum(cdes),sum(objectif)
  	from #MAR
  	group by depart,marque,famille  	
 end
 
else if (@sansobj0 = 1)

 begin
  if @detail=1
  	insert into #Final (repres,depart,marque,famille,ventes_N1,ventes_N1P,ventes_N,cdes,objectif)
  	select repres,depart,marque,famille,sum(ventes_N1),sum(ventes_N1P),sum(ventes_N),
				  sum(cdes),sum(objectif)
  	from #MAR
  	group by repres,depart,marque,famille
  	having sum(objectif) > 0
  else if @detail=0		
  	insert into #Final (repres,depart,marque,famille,ventes_N1,ventes_N1P,ventes_N,cdes,objectif)
  	select '',depart,marque,famille,sum(ventes_N1),sum(ventes_N1P),sum(ventes_N),
				  sum(cdes),sum(objectif)
  	from #MAR
  	group by depart,marque,famille
  	having sum(objectif) > 0
 end


drop table #MAR


					/******** select final *********/
		
select repres,depart,marque,famille,FPLIB,annee_1=isnull(ventes_N1,0),
			annee_1_partiel = isnull(ventes_N1P,0),annee_en_cours=isnull(ventes_N,0),
			cdes = isnull(cdes,0),objectifs=isnull(objectif,0),
			pc1 = convert(numeric(20,2),(case when objectif = 0 then 100 else convert(numeric(20,2),isnull(ventes_N,0)*100)/isnull(objectif,0) end)),
			pc2 = convert(numeric(20,2),(case when objectif = 0 then 100 else convert(numeric(20,2),(isnull(ventes_N,0)+isnull(cdes,0))*100)/isnull(objectif,0) end))
from #Final,FFP
where FPCODE = famille
order by repres,depart,marque,famille

drop table #Final

end



go

