

create procedure ACommander(@ent			char(5)			= null,
							@DateCL 		datetime,
							@DateFO			datetime,
							@ComSeulement 	tinyint			= 1,
							@SansMauvPaye 	tinyint			= 1,
							@SansStockMini	tinyint			= 0,
							@SansArtCompos	tinyint			= 0, 
							@Fournisseur 	char(12) 		= null,
							@Famille 		varchar(1000) 	= null,
							@Article 		char(15) 		= null,
							@categorie		varchar(1000)	= null,
							@depart			varchar(1000) 	= null,
							@marque			varchar(1000) 	= null,
							@chefproduit	varchar(1000)	= null,
							@grille			varchar(1000)	= null,
							@matiere		varchar(1000)	= null,
							@couleur		varchar(1000)	= null,
							@typeDemande	tinyint			= null,
							@kit			tinyint			= 0,
							@classe			varchar(1000)	= null,
							@calculACde		tinyint			= 0,
							@DateTrav		smalldatetime,
							@jperiodesup	int				= 0,
							@foreign1		varchar(1000)	= null,
							@calibre		varchar(1000)	= null,
							@foPrincipal	tinyint			= 0,
							@avecCCnonConf	tinyint			= 0,
							@delaisArt		tinyint			= 0,		/* analyse sur  0=@DateCL et @DateFO, 1=delais article */
							@previsions		tinyint			= 0,		/* calculs selon 0=cdes, 1=previsions, 2=max des 2 */
							@depot			varchar(1000)	= null
						   )
with recompile
as
begin
	
	set arithabort numeric_truncation off
	
	declare @nbreweek			int, 
			@count				int, 
			@delai				int, 
			@Moyenne			numeric(14,2), 
			@Besoins			numeric(14,2), 
			@ARTICLE 			char(15),
			@TOTALCC 			int, 
			@TOTALDA 			int, 
			@ANENCOURS 			int, 
			@ANPRECEDENTE		int, 
			@AFACTURER 			int, 
			@COMPART			char(15), 
			@COMPQTE			int, 
			@STOCKMINI			int, 
			@TOTALCF			int,		/* Total en commande composants fournisseurs */
			@TOTALST			int,		/* Total en stock composants */
			@DISPO				int, 
			@ACOMMANDER			int, 
			@TotCC	 			int,		/* Total en commande composants clients */
			@TotCCc	 			int,		/* Total en commande composants clients depuis produits finis */
			@TotDA 				int,		/* Total en demande achat composants clients */
			@TotDAc 			int,		/* Total en demande achat composants clients depuis produits finis */
			@TotCF				int,		/* Total en commande composants fournisseurs */
			@TotCFc				int,		/* Total en commande composants fournisseurs depuis produits finis */
			@TotBEaFact			int,		/* Total en BE composants a facturer */
			@TotBEaFactc		int,		/* Total en BE composants a facturer depuis produits finis */
			@TotST				int,		/* Total en stock composants */
			@TotSTc				int,		/* Total en stock composants depuis produits finis */
			@Totan				int,		/* Total composants vendus annee en cours */
			@Totanc				int,		/* Total composants vendus annee en cours depuis produits finis */
			@Totan_1			int,		/* Total composants vendus annee -1 */
			@Totan_1c			int,		/* Total composants vendus annee -1 depuis produits finis */
			@FALQTE				int,		/* ventes durant la periode */
			@FALQTEc			int,		/* ventes durant la periode depuis produits finis */
			@nbjsec				int,		/* Nombre de jours de stock de securite */ 
			@nbjvente			int,		/* Nombre de jours d analyse de consommation */
			@fournis			char(12),	/* Code du fournisseur principal */
			@ARFRANCOFO			int,
			@DelaiLiv			int,		/* delai de livraison d un article */
			@DateLivraison		datetime,
			@DateFinAnalyseCL	datetime,	/* date de fin periode analyse client d un article */
			@DateFinAnalyseFO	datetime,	/* date de fin periode analyse client d un article */
			@PADev				numeric(14,2),	/* prix d achat en devise d un article */
			@Dev				char(3),	/* devise du prix d achat d un article */
			@AnneeCours			char(4),	/* annee pour calcul des previsions exceptionnelles */
			@AnneeSuiv			char(4),	/* annee pour calcul des previsions exceptionnelles */
			@Date1MoisSuiv		datetime,	/* date du 1er jour du mois qui suit la date de travail */ 
			@NbJoursMois		tinyint,	/* nombre de jours du mois de la date de travail */
			@requete			varchar(2000)
	 
	
	select  @nbreweek = datepart(cwk,getdate()) 
	
	create table #Tab 
	( 
	Article				char(15)	not	null, 
	Marque				char(12)	not null, 
	StockMini			int				null, 
	TotalCC				int				null, 
	TotalST				int				null, 
	TotalCF				int				null, 
	TotalDA				int				null, 
	Dispo				int				null, 
	ACommander			int				null, 
	AFacturer			int				null, 
	Compose				tinyint			null,
	PADev				numeric(14,2)	null,	/* prix d achat en devise */
	Dev					char(3)			null,	/* devise du prix d achat */
	DelaiLiv			int				null,	/* delai de livraison de l article */
	DateFinAnalyseCL	datetime		null,	/* date de fin d analyse client de l article */
	DateFinAnalyseFO	datetime		null	/* date de fin d analyse fournisseur de l article */
	)
	
	
	create table #CdesCL
	(
	CdeAR		char(15)	not null,
	Qte			int				null,
	QteSFOL		int				null,
	QteSFOE		int				null,
	ExpedMois1	int				null,	/* qtes expediees pour le mois de la date de travail */
	ResteMois1	int				null,	/* qtes restant a expedier pour le mois de la date de travail */
	PrevMois1	int				null	/* qtes prevues pour le mois de la date de travail */
	)
	
	create table #FCL
	(
	CLCODE		char(12)	not null
	)
	
	create table #Depots
	(
	depot		char(4)		not null
	)
		
	create table #FinalKit  
	(  
	Article				char(15)	not	null, 
	StockMini			int				null, 
	TotalCC				int				null, 
	TotalST				int				null, 
	TotalCF				int				null, 
	TotalDA				int				null, 
	Dispo				int				null, 
	ACommander			int				null, 
	AFacturer			int				null, 
	Annee_en_Cours		int				null, 
	Annee_Precedente 	int				null,
	TotalFAPeriode		int				null,
	Compose				tinyint			null,
	ARFRANCOFO			int				null,
	DateFinAnalyseCL	datetime		null,	/* date de fin d analyse client de l article */
	DateFinAnalyseFO	datetime		null,	/* date de fin d analyse fournisseur de l article */
	DateLivraison		datetime		null,
	PADev				numeric(14,2)	null,
	Dev					char(3)			null
	)
	
	
	create table #Final
	(
	ARDEPART			char(8)			not null,
	ARFO				char(12)		not null,
	ARFAM				char(8)			not null,
	ARGRFAM				char(8)			not null,
	Article				char(15)		not null,
	ARREFFOUR			char(20)		not null,
	ARLIB				varchar(80)			null,
	ARPRM				numeric(14,4)		null,
	ARCHEFP				char(8)				null,
	TotalCC				numeric(14,2)		null,
	TotalCF				numeric(14,2)		null,
	TotalDA				numeric(14,2)		null,
	TotalST				numeric(14,2)		null,
	StockMini			int					null,
	Dispo				int					null,
	ACommander			int					null,
	Annee_en_Cours		int					null,
	Annee_Precedente	int					null,
	AFacturer			int					null,
	Compose				tinyint				null,
	ARREGROUPE			char(15)			null,
	ARNBJSEC			int					null,
	ARNBJVENTE			int					null,
	ARQTECOLIS			int					null,
	ARFDELAI			int					null,
	Besoin				int					null,
	Moyenne				int					null,
	Fournisseur			char(12)			null,
	ARFOREIGN1			char(12)			null,
	ARCALIBRE			char(14)			null,
	FALQTE				int					null,
	ARFRANCOFO			int					null,
	DateFinAnalyseCL	datetime			null,	/* date de fin d analyse client de l article */
	DateFinAnalyseFO	datetime			null,	/* date de fin d analyse fournisseur de l article */
	DateLivraison		datetime			null,
	PADev				numeric(14,2)		null,
	Dev					char(3)				null
	)
	
	create table #Final2
	(
	ARDEPART			char(8)			not null,
	ARFO				char(12)		not null,
	ARFAM				char(8)			not null,
	ARGRFAM				char(8)			not null,
	Article				char(15)		not null,
	ARREFFOUR			char(20)		not null,
	ARLIB				varchar(80)			null,
	ARPRM				numeric(14,4)		null,
	ARCHEFP				char(8)				null,
	TotalCC				numeric(14,2)		null,
	TotalCF				numeric(14,2)		null,
	TotalDA				numeric(14,2)		null,
	TotalST				numeric(14,2)		null,
	StockMini			int					null,
	Dispo				int					null,
	ACommander			int					null,
	Annee_en_Cours		int					null,
	Annee_Precedente	int					null,
	AFacturer			int					null,
	Compose				tinyint				null,
	ARREGROUPE			char(15)			null,
	ARNBJSEC			int					null,
	ARNBJVENTE			int					null,
	ARQTECOLIS			int					null,
	ARFDELAI			int					null,
	Besoin				int					null,
	Moyenne				int					null,
	Fournisseur			char(12)			null,
	ARFOREIGN1			char(12)			null,
	ARCALIBRE			char(14)			null,
	FALQTE				int					null,
	ARFRANCOFO			int					null,
	DateFinAnalyseCL	datetime			null,	/* date de fin d analyse client de l article */
	DateFinAnalyseFO	datetime			null,	/* date de fin d analyse fournisseur de l article */
	DateLivraison		datetime			null,
	PADev				numeric(14,2)		null,
	Dev					char(3)				null
	)
	
	/* Selection des articles concernes */ 
	
	select @requete = "
		insert into #Tab (Article,Marque,StockMini,TotalCC,TotalST,TotalCF,TotalDA,Dispo,
			ACommander,AFacturer,Compose,PADev,Dev,DelaiLiv,DateFinAnalyseCL,DateFinAnalyseFO) 
		select ARCODE,ARFO,ARSTOCKMINI,0,0,0,0,0,0,0,ARCOMP,0,'',ARDELAI,null,null "
		
		
	if 	@Fournisseur is null
	begin
		select @requete = @requete + "
		from FAR
		where AROLD=0 and ARTYPE=0 "
	end
	else
	begin
		select @requete = @requete + "
		from FAR,FARF
		where AROLD=0 and ARTYPE=0 and ARFCODE=ARCODE and ARFFO = '" + @Fournisseur + "' "
		
		if @foPrincipal = 1
			select @requete = @requete + "
			and ARFDEFAUT = 1 "
	end
	
	if @SansArtCompos = 1
		select @requete = @requete + "
		and isnull(ARCOMP,0) < 2 "

	if @Article is not null
		select @requete = @requete + "
		and ARCODE = '" + @Article + "' "
		
	if @Famille is not null
		select @requete = @requete + "
		and ARFAM in (" + @Famille + ") "
		
	if @categorie is not null
		select @requete = @requete + "
		and ARGRFAM in (" + @categorie + ") "
	
	if @depart is not null
		select @requete = @requete + "
		and ARDEPART in (" + @depart + ") "
		
	if @marque is not null
		select @requete = @requete + "
		and ARFO in (" + @marque + ") "
		
	if @chefproduit is not null
		select @requete = @requete + "
		and ARCHEFP in (" + @chefproduit + ") "
	
	if @grille is not null
		select @requete = @requete + "
		and ARGRILLE in (" + @grille + ") "
			
	if @matiere is not null
		select @requete = @requete + "
		and ARMATIERE in (" + @matiere + ") "
	
	if @couleur is not null
		select @requete = @requete + "
		and ARCOULEUR in (" + @couleur + ") "
	
	if @foreign1 is not null
		select @requete = @requete + "
		and ARFOREIGN1 in (" + @foreign1 + ") "
	
	if @calibre is not null
		select @requete = @requete + "
		and ARCALIBRE in (" + @calibre + ") "
		
	execute (@requete)
	
	create unique index art	on #Tab (Article)
	
	
	
	/* Selection des clients concernes */
	
	
	select @requete = "
		insert into #FCL (CLCODE) 
		select CLCODE from FCL
		where CLSTATUS <> 1 "
			
	if @SansMauvPaye = 1
		select @requete = @requete + "
		and CLPAYEUR not in (2,3) "
		
	if @ent is not null
		select @requete = @requete + "
		and CLENT = '" + @ent + "' "
		
	if @classe is not null
		select @requete = @requete + "
		and CLCLASSE in (" + @classe + ") "
		
	execute (@requete)
	
	create unique index code on #FCL (CLCODE)
	
	
	/* Selection des depots concernes */
	
	
	select @requete = "
		insert into #Depots (depot) 
		select DPCODE from FDP
		where DPCODE in (" + @depot + ") "
		
	execute (@requete)
	
	create unique index code on #Depots (depot)
	
	/********************/
	
		
	/* Mise a jour Prix Achat, Devise, Delai de Livraison */
	
	if 	@Fournisseur is null
	begin
		update #Tab set PADev = 
		(select (case when isnull(ARFPADEV,0)=0 then ARPADEV else ARFPADEV end)
		from FAR,FARF
		where ARFCODE=ARCODE and ARCODE=#Tab.Article and ARFDEFAUT=1)
		
		update #Tab set Dev = 
		(select (case when isnull(ARFPADEV,0)=0 then ARDEVPASTAND else ARFDEV end)
		from FAR,FARF
		where ARFCODE=ARCODE and ARCODE=#Tab.Article and ARFDEFAUT=1)
		
		update #Tab set PADev = ARPADEV, Dev = ARDEVPASTAND
		from FAR
		where ARCODE=#Tab.Article and isnull(PADev,0) = 0
	end
	else
	begin
		update #Tab set PADev = 
		(select (case when isnull(ARFPADEV,0)=0 then ARPADEV else ARFPADEV end)
		from FAR,FARF
		where ARFCODE=ARCODE and ARCODE=#Tab.Article 
			and ARFFO=@Fournisseur and (@foPrincipal = 0 or ARFDEFAUT=1))
			
		update #Tab set Dev = 
		(select (case when isnull(ARFPADEV,0)=0 then ARDEVPASTAND else ARFDEV end)
		from FAR,FARF
		where ARFCODE=ARCODE and ARCODE=#Tab.Article 
			and ARFFO=@Fournisseur and (@foPrincipal = 0 or ARFDEFAUT=1))
			
		update #Tab set DelaiLiv = 
		(select (case when isnull(ARFDELAI,0)=0 then ARDELAI else ARFDELAI end)
		from FAR,FARF
		where ARFCODE=ARCODE and ARCODE=#Tab.Article 
			and ARFFO=@Fournisseur and (@foPrincipal = 0 or ARFDEFAUT=1))
			
		update #Tab set PADev = ARPADEV, Dev = ARDEVPASTAND
		from FAR
		where ARCODE=#Tab.Article and isnull(PADev,0) = 0

		update #Tab set DelaiLiv = ARDELAI
		from FAR
		where ARCODE=#Tab.Article and isnull(DelaiLiv,0) = 0
	end
		
		
	/* Mise a jour dates fin analyse */
	
	if @delaisArt = 0
	begin
		update #Tab set DateFinAnalyseCL = 
		(select dateadd(dd,isnull(ARNBJSEC,0)+@jperiodesup,@DateCL) from FAR where ARCODE=#Tab.Article)
		
		update #Tab set DateFinAnalyseFO = 
		(select dateadd(dd,isnull(ARNBJSEC,0)+@jperiodesup,@DateFO) from FAR where ARCODE=#Tab.Article)
	end
	else
	begin
		update #Tab set DateFinAnalyseCL =
		(select	(case when (ARNEW=1 and ARDATEDISPO is not null) then 
				(case when dateadd(dd,#Tab.DelaiLiv+isnull(ARNBJSEC,0)+@jperiodesup,@DateTrav) < ARDATEDISPO 
					then dateadd(dd,isnull(ARNBJSEC,0)+@jperiodesup,ARDATEDISPO)
					else dateadd(dd,#Tab.DelaiLiv+isnull(ARNBJSEC,0)+@jperiodesup,@DateTrav) 
				end)
			else 
				dateadd(dd,#Tab.DelaiLiv+isnull(ARNBJSEC,0)+@jperiodesup,@DateTrav)
			end)
		from FAR
		where ARCODE=#Tab.Article)
		
		update #Tab set DateFinAnalyseFO = DateFinAnalyseCL
	end
				
	  
	/*************************************************/
	/* Selection des commandes clients ou previsions */ 
	/*************************************************/
	
	insert into #CdesCL (CdeAR,Qte,QteSFOL,QteSFOE)
	select Article,0,0,0
	from #Tab
	
	create unique index art	on #CdesCL (CdeAR)
	
	/* Mise a jour des commandes clients */
	
	if (@previsions = 0 or @previsions = 2)
	begin
		update #CdesCL
		set Qte=isnull((select sum(RCCQTE)
		from #Tab,FRCC,#FCL,FCC,FCCL
		where RCCARTICLE=Article and RCCARTICLE=#CdesCL.CdeAR
			and RCCDATE<= DateFinAnalyseCL
			and CLCODE=RCCCL 
			and CCLSEQ=RCCSEQ 
			and CCCODE=CCLCODE 
			and (@avecCCnonConf = 1 or isnull(CCVALIDE,0)=0)
			and (@ent is null or (RCCENT=@ent and CCENT=@ent and CCLENT=@ent))),0)
	end
	
	
		
	/* Mise a jour des previsions normales */
	
	if (@previsions = 1 or @previsions = 2)
	begin
		update #CdesCL
		set QteSFOL=isnull((select
			sum(case 
					when (@DateTrav<"JAN 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="JAN 31 "+convert(varchar,SFOLANNEE))
					then SFOLN1
					when (@DateTrav>="FEB 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"JAN 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="JAN 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"FEB 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="JAN 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"FEB 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN1*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="JAN 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"FEB 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="JAN 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN1*(datediff(dd,@DateTrav,"JAN 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"JAN 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="JAN 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"FEB 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN1*(datediff(dd,"JAN 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"FEB 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="FEB 28 "+convert(varchar,SFOLANNEE))
					then SFOLN2
					when (@DateTrav>="MAR 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"FEB 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="FEB 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"MAR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="FEB 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"MAR 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN2*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="FEB 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"MAR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="FEB 28 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN2*(datediff(dd,@DateTrav,"FEB 28 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"FEB 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="FEB 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"MAR 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN2*(datediff(dd,"FEB 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"MAR 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="MAR 31 "+convert(varchar,SFOLANNEE))
					then SFOLN3
					when (@DateTrav>="APR 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"MAR 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="MAR 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"APR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="MAR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"APR 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN3*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="MAR 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"APR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="MAR 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN3*(datediff(dd,@DateTrav,"MAR 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"MAR 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="MAR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"APR 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN3*(datediff(dd,"MAR 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"APR 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="APR 30 "+convert(varchar,SFOLANNEE))
					then SFOLN4
					when (@DateTrav>="MAY 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"APR 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="APR 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"MAY 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="APR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"MAY 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN4*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="APR 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"MAY 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="APR 30 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN4*(datediff(dd,@DateTrav,"APR 30 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"APR 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="APR 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"MAY 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN4*(datediff(dd,"APR 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"MAY 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="MAY 31 "+convert(varchar,SFOLANNEE))
					then SFOLN5
					when (@DateTrav>="JUN 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"MAY 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="MAY 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"JUN 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="MAY 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"JUN 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN5*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="MAY 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"JUN 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="MAY 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN5*(datediff(dd,@DateTrav,"MAY 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"MAY 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="MAY 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"JUN 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN5*(datediff(dd,"MAY 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"JUN 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="JUN 30 "+convert(varchar,SFOLANNEE))
					then SFOLN6
					when (@DateTrav>="JUL 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"JUN 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="JUN 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"JUL 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="JUN 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"JUL 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN6*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="JUN 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"JUL 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="JUN 30 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN6*(datediff(dd,@DateTrav,"JUN 30 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"JUN 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="JUN 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"JUL 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN6*(datediff(dd,"JUN 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"JUL 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="JUL 31 "+convert(varchar,SFOLANNEE))
					then SFOLN7
					when (@DateTrav>="AUG 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"JUL 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="JUL 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"AUG 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="JUL 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"AUG 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN7*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="JUL 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"AUG 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="JUL 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN7*(datediff(dd,@DateTrav,"JUL 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"JUL 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="JUL 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"AUG 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN7*(datediff(dd,"JUL 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"AUG 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="AUG 31 "+convert(varchar,SFOLANNEE))
					then SFOLN8
					when (@DateTrav>="SEP 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"AUG 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="AUG 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"SEP 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="AUG 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"SEP 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN8*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="AUG 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"SEP 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="AUG 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN8*(datediff(dd,@DateTrav,"AUG 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"AUG 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="AUG 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"SEP 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN8*(datediff(dd,"AUG 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"SEP 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="SEP 30 "+convert(varchar,SFOLANNEE))
					then SFOLN9
					when (@DateTrav>="OCT 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"SEP 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="SEP 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"OCT 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="SEP 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"OCT 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN9*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="SEP 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"OCT 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="SEP 30 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN9*(datediff(dd,@DateTrav,"SEP 30 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"SEP 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="SEP 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"OCT 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN9*(datediff(dd,"SEP 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"OCT 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="OCT 31 "+convert(varchar,SFOLANNEE))
					then SFOLN10
					when (@DateTrav>="NOV 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"OCT 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="OCT 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"NOV 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="OCT 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"NOV 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN10*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="OCT 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"NOV 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="OCT 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN10*(datediff(dd,@DateTrav,"OCT 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"OCT 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="OCT 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"NOV 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN10*(datediff(dd,"OCT 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"NOV 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="NOV 30 "+convert(varchar,SFOLANNEE))
					then SFOLN11
					when (@DateTrav>="DEC 01 "+convert(varchar,SFOLANNEE)
						or DateFinAnalyseCL<"NOV 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="NOV 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"DEC 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="NOV 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"DEC 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN11*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="NOV 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<"DEC 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL>="NOV 30 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN11*(datediff(dd,@DateTrav,"NOV 30 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"NOV 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="NOV 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<"DEC 01 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN11*(datediff(dd,"NOV 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
			+ sum(case 
					when (@DateTrav<"DEC 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="DEC 31 "+convert(varchar,SFOLANNEE))
					then SFOLN12
					when (@DateTrav>=dateadd(dd,1,"DEC 31 "+convert(varchar,SFOLANNEE))
						or DateFinAnalyseCL<"DEC 01 "+convert(varchar,SFOLANNEE))
					then 0
					when (@DateTrav>="DEC 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<dateadd(dd,1,"DEC 31 "+convert(varchar,SFOLANNEE))
						and DateFinAnalyseCL>="DEC 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<dateadd(dd,1,"DEC 31 "+convert(varchar,SFOLANNEE)))
					then ceiling(SFOLN12*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
					when (@DateTrav>="DEC 01 "+convert(varchar,SFOLANNEE)
						and @DateTrav<dateadd(dd,1,"DEC 31 "+convert(varchar,SFOLANNEE))
						and DateFinAnalyseCL>="DEC 31 "+convert(varchar,SFOLANNEE))
					then ceiling(SFOLN12*(datediff(dd,@DateTrav,"DEC 31 "+convert(varchar,SFOLANNEE))+1)/31)
					when (@DateTrav<"DEC 02 "+convert(varchar,SFOLANNEE) 
						and DateFinAnalyseCL>="DEC 01 "+convert(varchar,SFOLANNEE)
						and DateFinAnalyseCL<dateadd(dd,1,"DEC 31 "+convert(varchar,SFOLANNEE)))
					then ceiling(SFOLN12*(datediff(dd,"DEC 01 "+convert(varchar,SFOLANNEE),
						DateFinAnalyseCL)+1)/31)
				end)
		from #Tab,FSFOL,FSFO 
		where SFOLANNEE=SFOANNEE and SFOLVERSION=SFOVERSION
			and SFOACTIVE=1
			and SFOLCODE=Article and SFOLCODE=#CdesCL.CdeAR),0)
	
	/* Mise a jour des previsions exceptionnelles */
	
		select @AnneeCours = convert(varchar,datepart(yy,getdate())),
			@AnneeSuiv = convert(varchar,datepart(yy,getdate())+1)
		update #CdesCL
		set QteSFOE=isnull((select
			(case 
				when (@DateTrav<"JAN 02 "+@AnneeCours
					and DateFinAnalyseCL>="JAN 31 "+@AnneeCours)
				then SFOEN1
				when (@DateTrav>="FEB 01 "+@AnneeCours
					or DateFinAnalyseCL<"JAN 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="JAN 01 "+@AnneeCours
					and @DateTrav<"FEB 01 "+@AnneeCours
					and DateFinAnalyseCL>="JAN 01 "+@AnneeCours
					and DateFinAnalyseCL<"FEB 01 "+@AnneeCours)
				then ceiling(SFOEN1*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="JAN 01 "+@AnneeCours
					and @DateTrav<"FEB 01 "+@AnneeCours
					and DateFinAnalyseCL>="JAN 31 "+@AnneeCours)
				then ceiling(SFOEN1*(datediff(dd,@DateTrav,"JAN 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"JAN 02 "+@AnneeCours 
					and DateFinAnalyseCL>="JAN 01 "+@AnneeCours
					and DateFinAnalyseCL<"FEB 01 "+@AnneeCours)
				then ceiling(SFOEN1*(datediff(dd,"JAN 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"FEB 02 "+@AnneeCours 
					and DateFinAnalyseCL>="FEB 28 "+@AnneeCours)
				then SFOEN2
				when (@DateTrav>="MAR 01 "+@AnneeCours
					or DateFinAnalyseCL<"FEB 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="FEB 01 "+@AnneeCours
					and @DateTrav<"MAR 01 "+@AnneeCours
					and DateFinAnalyseCL>="FEB 01 "+@AnneeCours
					and DateFinAnalyseCL<"MAR 01 "+@AnneeCours)
				then ceiling(SFOEN2*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="FEB 01 "+@AnneeCours
					and @DateTrav<"MAR 01 "+@AnneeCours
					and DateFinAnalyseCL>="FEB 28 "+@AnneeCours)
				then ceiling(SFOEN2*(datediff(dd,@DateTrav,"FEB 28 "+@AnneeCours)+1)/31)
				when (@DateTrav<"FEB 02 "+@AnneeCours 
					and DateFinAnalyseCL>="FEB 01 "+@AnneeCours
					and DateFinAnalyseCL<"MAR 01 "+@AnneeCours)
				then ceiling(SFOEN2*(datediff(dd,"FEB 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"MAR 02 "+@AnneeCours 
					and DateFinAnalyseCL>="MAR 31 "+@AnneeCours)
				then SFOEN3
				when (@DateTrav>="APR 01 "+@AnneeCours
					or DateFinAnalyseCL<"MAR 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="MAR 01 "+@AnneeCours
					and @DateTrav<"APR 01 "+@AnneeCours
					and DateFinAnalyseCL>="MAR 01 "+@AnneeCours
					and DateFinAnalyseCL<"APR 01 "+@AnneeCours)
				then ceiling(SFOEN3*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="MAR 01 "+@AnneeCours
					and @DateTrav<"APR 01 "+@AnneeCours
					and DateFinAnalyseCL>="MAR 31 "+@AnneeCours)
				then ceiling(SFOEN3*(datediff(dd,@DateTrav,"MAR 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"MAR 02 "+@AnneeCours 
					and DateFinAnalyseCL>="MAR 01 "+@AnneeCours
					and DateFinAnalyseCL<"APR 01 "+@AnneeCours)
				then ceiling(SFOEN3*(datediff(dd,"MAR 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"APR 02 "+@AnneeCours 
					and DateFinAnalyseCL>="APR 30 "+@AnneeCours)
				then SFOEN4
				when (@DateTrav>="MAY 01 "+@AnneeCours
					or DateFinAnalyseCL<"APR 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="APR 01 "+@AnneeCours
					and @DateTrav<"MAY 01 "+@AnneeCours
					and DateFinAnalyseCL>="APR 01 "+@AnneeCours
					and DateFinAnalyseCL<"MAY 01 "+@AnneeCours)
				then ceiling(SFOEN4*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="APR 01 "+@AnneeCours
					and @DateTrav<"MAY 01 "+@AnneeCours
					and DateFinAnalyseCL>="APR 30 "+@AnneeCours)
				then ceiling(SFOEN4*(datediff(dd,@DateTrav,"APR 30 "+@AnneeCours)+1)/31)
				when (@DateTrav<"APR 02 "+@AnneeCours 
					and DateFinAnalyseCL>="APR 01 "+@AnneeCours
					and DateFinAnalyseCL<"MAY 01 "+@AnneeCours)
				then ceiling(SFOEN4*(datediff(dd,"APR 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"MAY 02 "+@AnneeCours 
					and DateFinAnalyseCL>="MAY 31 "+@AnneeCours)
				then SFOEN5
				when (@DateTrav>="JUN 01 "+@AnneeCours
					or DateFinAnalyseCL<"MAY 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="MAY 01 "+@AnneeCours
					and @DateTrav<"JUN 01 "+@AnneeCours
					and DateFinAnalyseCL>="MAY 01 "+@AnneeCours
					and DateFinAnalyseCL<"JUN 01 "+@AnneeCours)
				then ceiling(SFOEN5*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="MAY 01 "+@AnneeCours
					and @DateTrav<"JUN 01 "+@AnneeCours
					and DateFinAnalyseCL>="MAY 31 "+@AnneeCours)
				then ceiling(SFOEN5*(datediff(dd,@DateTrav,"MAY 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"MAY 02 "+@AnneeCours 
					and DateFinAnalyseCL>="MAY 01 "+@AnneeCours
					and DateFinAnalyseCL<"JUN 01 "+@AnneeCours)
				then ceiling(SFOEN5*(datediff(dd,"MAY 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"JUN 02 "+@AnneeCours 
					and DateFinAnalyseCL>="JUN 30 "+@AnneeCours)
				then SFOEN6
				when (@DateTrav>="JUL 01 "+@AnneeCours
					or DateFinAnalyseCL<"JUN 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="JUN 01 "+@AnneeCours
					and @DateTrav<"JUL 01 "+@AnneeCours
					and DateFinAnalyseCL>="JUN 01 "+@AnneeCours
					and DateFinAnalyseCL<"JUL 01 "+@AnneeCours)
				then ceiling(SFOEN6*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="JUN 01 "+@AnneeCours
					and @DateTrav<"JUL 01 "+@AnneeCours
					and DateFinAnalyseCL>="JUN 30 "+@AnneeCours)
				then ceiling(SFOEN6*(datediff(dd,@DateTrav,"JUN 30 "+@AnneeCours)+1)/31)
				when (@DateTrav<"JUN 02 "+@AnneeCours 
					and DateFinAnalyseCL>="JUN 01 "+@AnneeCours
					and DateFinAnalyseCL<"JUL 01 "+@AnneeCours)
				then ceiling(SFOEN6*(datediff(dd,"JUN 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"JUL 02 "+@AnneeCours 
					and DateFinAnalyseCL>="JUL 31 "+@AnneeCours)
				then SFOEN7
				when (@DateTrav>="AUG 01 "+@AnneeCours
					or DateFinAnalyseCL<"JUL 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="JUL 01 "+@AnneeCours
					and @DateTrav<"AUG 01 "+@AnneeCours
					and DateFinAnalyseCL>="JUL 01 "+@AnneeCours
					and DateFinAnalyseCL<"AUG 01 "+@AnneeCours)
				then ceiling(SFOEN7*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="JUL 01 "+@AnneeCours
					and @DateTrav<"AUG 01 "+@AnneeCours
					and DateFinAnalyseCL>="JUL 31 "+@AnneeCours)
				then ceiling(SFOEN7*(datediff(dd,@DateTrav,"JUL 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"JUL 02 "+@AnneeCours 
					and DateFinAnalyseCL>="JUL 01 "+@AnneeCours
					and DateFinAnalyseCL<"AUG 01 "+@AnneeCours)
				then ceiling(SFOEN7*(datediff(dd,"JUL 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"AUG 02 "+@AnneeCours 
					and DateFinAnalyseCL>="AUG 31 "+@AnneeCours)
				then SFOEN8
				when (@DateTrav>="SEP 01 "+@AnneeCours
					or DateFinAnalyseCL<"AUG 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="AUG 01 "+@AnneeCours
					and @DateTrav<"SEP 01 "+@AnneeCours
					and DateFinAnalyseCL>="AUG 01 "+@AnneeCours
					and DateFinAnalyseCL<"SEP 01 "+@AnneeCours)
				then ceiling(SFOEN8*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="AUG 01 "+@AnneeCours
					and @DateTrav<"SEP 01 "+@AnneeCours
					and DateFinAnalyseCL>="AUG 31 "+@AnneeCours)
				then ceiling(SFOEN8*(datediff(dd,@DateTrav,"AUG 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"AUG 02 "+@AnneeCours 
					and DateFinAnalyseCL>="AUG 01 "+@AnneeCours
					and DateFinAnalyseCL<"SEP 01 "+@AnneeCours)
				then ceiling(SFOEN8*(datediff(dd,"AUG 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"SEP 02 "+@AnneeCours 
					and DateFinAnalyseCL>="SEP 30 "+@AnneeCours)
				then SFOEN9
				when (@DateTrav>="OCT 01 "+@AnneeCours
					or DateFinAnalyseCL<"SEP 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="SEP 01 "+@AnneeCours
					and @DateTrav<"OCT 01 "+@AnneeCours
					and DateFinAnalyseCL>="SEP 01 "+@AnneeCours
					and DateFinAnalyseCL<"OCT 01 "+@AnneeCours)
				then ceiling(SFOEN9*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="SEP 01 "+@AnneeCours
					and @DateTrav<"OCT 01 "+@AnneeCours
					and DateFinAnalyseCL>="SEP 30 "+@AnneeCours)
				then ceiling(SFOEN9*(datediff(dd,@DateTrav,"SEP 30 "+@AnneeCours)+1)/31)
				when (@DateTrav<"SEP 02 "+@AnneeCours 
					and DateFinAnalyseCL>="SEP 01 "+@AnneeCours
					and DateFinAnalyseCL<"OCT 01 "+@AnneeCours)
				then ceiling(SFOEN9*(datediff(dd,"SEP 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"OCT 02 "+@AnneeCours 
					and DateFinAnalyseCL>="OCT 31 "+@AnneeCours)
				then SFOEN10
				when (@DateTrav>="NOV 01 "+@AnneeCours
					or DateFinAnalyseCL<"OCT 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="OCT 01 "+@AnneeCours
					and @DateTrav<"NOV 01 "+@AnneeCours
					and DateFinAnalyseCL>="OCT 01 "+@AnneeCours
					and DateFinAnalyseCL<"NOV 01 "+@AnneeCours)
				then ceiling(SFOEN10*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="OCT 01 "+@AnneeCours
					and @DateTrav<"NOV 01 "+@AnneeCours
					and DateFinAnalyseCL>="OCT 31 "+@AnneeCours)
				then ceiling(SFOEN10*(datediff(dd,@DateTrav,"OCT 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"OCT 02 "+@AnneeCours 
					and DateFinAnalyseCL>="OCT 01 "+@AnneeCours
					and DateFinAnalyseCL<"NOV 01 "+@AnneeCours)
				then ceiling(SFOEN10*(datediff(dd,"OCT 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"NOV 02 "+@AnneeCours 
					and DateFinAnalyseCL>="NOV 30 "+@AnneeCours)
				then SFOEN11
				when (@DateTrav>="DEC 01 "+@AnneeCours
					or DateFinAnalyseCL<"NOV 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="NOV 01 "+@AnneeCours
					and @DateTrav<"DEC 01 "+@AnneeCours
					and DateFinAnalyseCL>="NOV 01 "+@AnneeCours
					and DateFinAnalyseCL<"DEC 01 "+@AnneeCours)
				then ceiling(SFOEN11*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="NOV 01 "+@AnneeCours
					and @DateTrav<"DEC 01 "+@AnneeCours
					and DateFinAnalyseCL>="NOV 30 "+@AnneeCours)
				then ceiling(SFOEN11*(datediff(dd,@DateTrav,"NOV 30 "+@AnneeCours)+1)/31)
				when (@DateTrav<"NOV 02 "+@AnneeCours 
					and DateFinAnalyseCL>="NOV 01 "+@AnneeCours
					and DateFinAnalyseCL<"DEC 01 "+@AnneeCours)
				then ceiling(SFOEN11*(datediff(dd,"NOV 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"DEC 02 "+@AnneeCours 
					and DateFinAnalyseCL>="DEC 31 "+@AnneeCours)
				then SFOEN12
				when (@DateTrav>=dateadd(dd,1,"DEC 31 "+@AnneeCours)
					or DateFinAnalyseCL<"DEC 01 "+@AnneeCours)
				then 0
				when (@DateTrav>="DEC 01 "+@AnneeCours
					and @DateTrav<dateadd(dd,1,"DEC 31 "+@AnneeCours)
					and DateFinAnalyseCL>="DEC 01 "+@AnneeCours
					and DateFinAnalyseCL<dateadd(dd,1,"DEC 31 "+@AnneeCours))
				then ceiling(SFOEN12*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="DEC 01 "+@AnneeCours
					and @DateTrav<dateadd(dd,1,"DEC 31 "+@AnneeCours)
					and DateFinAnalyseCL>="DEC 31 "+@AnneeCours)
				then ceiling(SFOEN12*(datediff(dd,@DateTrav,"DEC 31 "+@AnneeCours)+1)/31)
				when (@DateTrav<"DEC 02 "+@AnneeCours 
					and DateFinAnalyseCL>="DEC 01 "+@AnneeCours
					and DateFinAnalyseCL<dateadd(dd,1,"DEC 31 "+@AnneeCours))
				then ceiling(SFOEN12*(datediff(dd,"DEC 01 "+@AnneeCours,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"JAN 02 "+@AnneeSuiv
					and DateFinAnalyseCL>="JAN 31 "+@AnneeSuiv)
				then SFOENPLUS11
				when (@DateTrav>="FEB 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"JAN 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="JAN 01 "+@AnneeSuiv
					and @DateTrav<"FEB 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="JAN 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"FEB 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS11*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="JAN 01 "+@AnneeSuiv
					and @DateTrav<"FEB 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="JAN 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS11*(datediff(dd,@DateTrav,"JAN 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"JAN 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="JAN 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"FEB 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS11*(datediff(dd,"JAN 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"FEB 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="FEB 28 "+@AnneeSuiv)
				then SFOENPLUS12
				when (@DateTrav>="MAR 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"FEB 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="FEB 01 "+@AnneeSuiv
					and @DateTrav<"MAR 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="FEB 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"MAR 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS12*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="FEB 01 "+@AnneeSuiv
					and @DateTrav<"MAR 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="FEB 28 "+@AnneeSuiv)
				then ceiling(SFOENPLUS12*(datediff(dd,@DateTrav,"FEB 28 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"FEB 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="FEB 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"MAR 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS12*(datediff(dd,"FEB 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"MAR 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="MAR 31 "+@AnneeSuiv)
				then SFOENPLUS13
				when (@DateTrav>="APR 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"MAR 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="MAR 01 "+@AnneeSuiv
					and @DateTrav<"APR 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="MAR 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"APR 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS13*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="MAR 01 "+@AnneeSuiv
					and @DateTrav<"APR 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="MAR 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS13*(datediff(dd,@DateTrav,"MAR 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"MAR 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="MAR 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"APR 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS13*(datediff(dd,"MAR 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"APR 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="APR 30 "+@AnneeSuiv)
				then SFOENPLUS14
				when (@DateTrav>="MAY 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"APR 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="APR 01 "+@AnneeSuiv
					and @DateTrav<"MAY 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="APR 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"MAY 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS14*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="APR 01 "+@AnneeSuiv
					and @DateTrav<"MAY 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="APR 30 "+@AnneeSuiv)
				then ceiling(SFOENPLUS14*(datediff(dd,@DateTrav,"APR 30 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"APR 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="APR 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"MAY 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS14*(datediff(dd,"APR 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"MAY 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="MAY 31 "+@AnneeSuiv)
				then SFOENPLUS15
				when (@DateTrav>="JUN 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"MAY 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="MAY 01 "+@AnneeSuiv
					and @DateTrav<"JUN 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="MAY 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"JUN 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS15*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="MAY 01 "+@AnneeSuiv
					and @DateTrav<"JUN 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="MAY 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS15*(datediff(dd,@DateTrav,"MAY 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"MAY 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="MAY 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"JUN 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS15*(datediff(dd,"MAY 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"JUN 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="JUN 30 "+@AnneeSuiv)
				then SFOENPLUS16
				when (@DateTrav>="JUL 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"JUN 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="JUN 01 "+@AnneeSuiv
					and @DateTrav<"JUL 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="JUN 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"JUL 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS16*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="JUN 01 "+@AnneeSuiv
					and @DateTrav<"JUL 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="JUN 30 "+@AnneeSuiv)
				then ceiling(SFOENPLUS16*(datediff(dd,@DateTrav,"JUN 30 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"JUN 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="JUN 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"JUL 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS16*(datediff(dd,"JUN 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"JUL 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="JUL 31 "+@AnneeSuiv)
				then SFOENPLUS17
				when (@DateTrav>="AUG 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"JUL 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="JUL 01 "+@AnneeSuiv
					and @DateTrav<"AUG 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="JUL 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"AUG 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS17*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="JUL 01 "+@AnneeSuiv
					and @DateTrav<"AUG 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="JUL 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS17*(datediff(dd,@DateTrav,"JUL 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"JUL 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="JUL 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"AUG 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS17*(datediff(dd,"JUL 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"AUG 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="AUG 31 "+@AnneeSuiv)
				then SFOENPLUS18
				when (@DateTrav>="SEP 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"AUG 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="AUG 01 "+@AnneeSuiv
					and @DateTrav<"SEP 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="AUG 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"SEP 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS18*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="AUG 01 "+@AnneeSuiv
					and @DateTrav<"SEP 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="AUG 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS18*(datediff(dd,@DateTrav,"AUG 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"AUG 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="AUG 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"SEP 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS18*(datediff(dd,"AUG 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"SEP 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="SEP 30 "+@AnneeSuiv)
				then SFOENPLUS19
				when (@DateTrav>="OCT 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"SEP 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="SEP 01 "+@AnneeSuiv
					and @DateTrav<"OCT 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="SEP 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"OCT 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS19*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="SEP 01 "+@AnneeSuiv
					and @DateTrav<"OCT 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="SEP 30 "+@AnneeSuiv)
				then ceiling(SFOENPLUS19*(datediff(dd,@DateTrav,"SEP 30 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"SEP 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="SEP 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"OCT 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS19*(datediff(dd,"SEP 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"OCT 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="OCT 31 "+@AnneeSuiv)
				then SFOENPLUS110
				when (@DateTrav>="NOV 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"OCT 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="OCT 01 "+@AnneeSuiv
					and @DateTrav<"NOV 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="OCT 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"NOV 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS110*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="OCT 01 "+@AnneeSuiv
					and @DateTrav<"NOV 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="OCT 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS110*(datediff(dd,@DateTrav,"OCT 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"OCT 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="OCT 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"NOV 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS110*(datediff(dd,"OCT 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"NOV 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="NOV 30 "+@AnneeSuiv)
				then SFOENPLUS111
				when (@DateTrav>="DEC 01 "+@AnneeSuiv
					or DateFinAnalyseCL<"NOV 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="NOV 01 "+@AnneeSuiv
					and @DateTrav<"DEC 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="NOV 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"DEC 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS111*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="NOV 01 "+@AnneeSuiv
					and @DateTrav<"DEC 01 "+@AnneeSuiv
					and DateFinAnalyseCL>="NOV 30 "+@AnneeSuiv)
				then ceiling(SFOENPLUS111*(datediff(dd,@DateTrav,"NOV 30 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"NOV 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="NOV 01 "+@AnneeSuiv
					and DateFinAnalyseCL<"DEC 01 "+@AnneeSuiv)
				then ceiling(SFOENPLUS111*(datediff(dd,"NOV 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
			+ (case 
				when (@DateTrav<"DEC 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="DEC 31 "+@AnneeSuiv)
				then SFOENPLUS112
				when (@DateTrav>=dateadd(dd,1,"DEC 31 "+@AnneeSuiv)
					or DateFinAnalyseCL<"DEC 01 "+@AnneeSuiv)
				then 0
				when (@DateTrav>="DEC 01 "+@AnneeSuiv
					and @DateTrav<dateadd(dd,1,"DEC 31 "+@AnneeSuiv)
					and DateFinAnalyseCL>="DEC 01 "+@AnneeSuiv
					and DateFinAnalyseCL<dateadd(dd,1,"DEC 31 "+@AnneeSuiv))
				then ceiling(SFOENPLUS112*(datediff(dd,@DateTrav,DateFinAnalyseCL)+1)/31)
				when (@DateTrav>="DEC 01 "+@AnneeSuiv
					and @DateTrav<dateadd(dd,1,"DEC 31 "+@AnneeSuiv)
					and DateFinAnalyseCL>="DEC 31 "+@AnneeSuiv)
				then ceiling(SFOENPLUS112*(datediff(dd,@DateTrav,"DEC 31 "+@AnneeSuiv)+1)/31)
				when (@DateTrav<"DEC 02 "+@AnneeSuiv 
					and DateFinAnalyseCL>="DEC 01 "+@AnneeSuiv
					and DateFinAnalyseCL<dateadd(dd,1,"DEC 31 "+@AnneeSuiv))
				then ceiling(SFOENPLUS112*(datediff(dd,"DEC 01 "+@AnneeSuiv,
					DateFinAnalyseCL)+1)/31)
			end)
		from #Tab,FSFOE
		where SFOECODE=Article and SFOECODE=#CdesCL.CdeAR),0)

	
	
	
		/* Mise a jour commandes livrees au cours du mois de la date de travail */
		
		update #CdesCL set ExpedMois1 =
		isnull((select sum(BELQTE) from FBEL
		where BELARTICLE=#CdesCL.CdeAR
			and datepart(mm,BELDATE) = datepart(mm,@DateTrav)
			and datepart(yy,BELDATE) = datepart(yy,@DateTrav)),0)
			
		/* Mise a jour commandes restant a livrer au cours du mois de la date de travail */
		
		select @Date1MoisSuiv = datename(mm,dateadd(mm,1,@DateTrav))+" 01 "+convert(varchar(4),datepart(yy,dateadd(mm,1,@DateTrav)))
		update #CdesCL set ResteMois1 =
		isnull((select isnull(sum(RCCQTE),0)
		from #Tab,FRCC,#FCL,FCC,FCCL 
		where RCCARTICLE=Article and RCCARTICLE=#CdesCL.CdeAR
			and RCCDATE< @Date1MoisSuiv
			and CLCODE=RCCCL 
			and CCLSEQ=RCCSEQ 
			and CCCODE=CCLCODE
			and (@avecCCnonConf = 1 or isnull(CCVALIDE,0)=0) 
			and (@ent is null or (RCCENT=@ent and CCENT=@ent and CCLENT=@ent))),0)

	

		/* Mise a jour previsions du mois de la date de travail */
		
		update #CdesCL set PrevMois1 = 
		isnull((select	(case datepart(mm,@DateTrav) 
				when 1 then SFOLN1 when 2 then SFOLN2 when 3 then SFOLN3 when 4 then SFOLN4 when 5 then SFOLN5 when 6 then SFOLN6
				when 7 then SFOLN7 when 8 then SFOLN8 when 9 then SFOLN9 when 10 then SFOLN10 when 11 then SFOLN11 when 12 then SFOLN12
			end)
		from FSFOL,FSFO 
		where SFOANNEE=SFOLANNEE and SFOVERSION=SFOLVERSION and SFOACTIVE=1 
			and SFOLCODE=#CdesCL.CdeAR and SFOLANNEE=datepart(yy,@DateTrav)),0)
	
		if datepart(yy,@DateTrav) = datepart(yy,getdate())
			update #CdesCL set PrevMois1 = PrevMois1 +
			isnull((select	(case datepart(mm,@DateTrav) 
					when 1 then SFOEN1 when 2 then SFOEN2 when 3 then SFOEN3 when 4 then SFOEN4 when 5 then SFOEN5 when 6 then SFOEN6
					when 7 then SFOEN7 when 8 then SFOEN8 when 9 then SFOEN9 when 10 then SFOEN10 when 11 then SFOEN11 when 12 then SFOEN12
				end)
			from FSFOE
			where SFOECODE=#CdesCL.CdeAR),0)
	
		if datepart(yy,@DateTrav) = datepart(yy,getdate()) + 1
			update #CdesCL set PrevMois1 = PrevMois1 +
			isnull((select	(case datepart(mm,@DateTrav) 
					when 1 then SFOENPLUS11 when 2 then SFOENPLUS12 when 3 then SFOENPLUS13 when 4 then SFOENPLUS14 
					when 5 then SFOENPLUS15 when 6 then SFOENPLUS16 when 7 then SFOENPLUS17 when 8 then SFOENPLUS18 
					when 9 then SFOENPLUS19 when 10 then SFOENPLUS110 when 11 then SFOENPLUS111 when 12 then SFOENPLUS112
				end)
			from FSFOE
			where SFOECODE=#CdesCL.CdeAR),0)
			
		select @NbJoursMois = 	
			(case datepart(mm,@DateTrav)
				when 1 then 31 when 2 then 28 when 3 then 31 when 4 then 30 when 5 then 31 when 6 then 30
				when 7 then 31 when 8 then 31 when 9 then 30 when 10 then 31 when 11 then 30 when 12 then 31
			end)
	

	
		if @previsions = 1
			update #CdesCL set Qte =
				isnull(QteSFOL + QteSFOE - ceiling(PrevMois1*(datediff(dd,@DateTrav,@Date1MoisSuiv))/@NbJoursMois),0)
				+
				(case when isnull(PrevMois1-ExpedMois1,0) > 0 then isnull(PrevMois1-ExpedMois1,0) else 0 end)
				
		else if @previsions = 2
			update #CdesCL set Qte =
				(case when (isnull(QteSFOL + QteSFOE - ceiling(PrevMois1*(datediff(dd,@DateTrav,@Date1MoisSuiv))/@NbJoursMois),0)
							+
						   (case when isnull(PrevMois1-ExpedMois1,0) > 0 then isnull(PrevMois1-ExpedMois1,0) else 0 end))
						> Qte
					  then (isnull(QteSFOL + QteSFOE - ceiling(PrevMois1*(datediff(dd,@DateTrav,@Date1MoisSuiv))/@NbJoursMois),0)
							+
						   (case when isnull(PrevMois1-ExpedMois1,0) > 0 then isnull(PrevMois1-ExpedMois1,0) else 0 end))
					  else Qte
				end)
	
	end /****** @previsions = 1 ou 2 *******/
	
	
	 
	update #Tab 
	set TotalCC=isnull(Qte,0)
	from #CdesCL 
	where Article=CdeAR
	
	  
	drop table #CdesCL 
	  
	/* Selection des expeditions clients restant a facturer */ 
	  
	select RBEARTICLE,Qte=isnull(sum(RBEQTE),0)
	into #BEL 
	from #Tab,FRBE,#FCL,FBEL 
	where RBEARTICLE=Article 
	and CLCODE=RBECL 
	and BELSEQ=RBESEQ  
	and (@ent is null or (RBEENT=@ent and BELENT=@ent)) 
	group by RBEARTICLE
	
	create unique index art	on #BEL (RBEARTICLE)
	 
	update #Tab 
	set AFacturer=Qte 
	from #BEL 
	where Article=RBEARTICLE 
	 
	drop table #BEL 
	 
	/* Selection du stock */ 
	  
	select STAR,Qte=isnull(sum(STQTE),0)
	into #Stock 
	from #Tab,FSTOCK,FDP,#Depots 
	where DPCODE=STDEPOT
	and DPCODE=depot 
	and STAR=Article 
	and STQTE != 0 
	and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	group by STAR
	
	create unique index art	on #Stock (STAR)
	 
	update #Tab 
	set TotalST=Qte 
	from #Stock 
	where Article=STAR 
	 
	drop table #Stock 
	 
	/* Selection des demandes Fournisseurs */ 
	 
	if (@typeDemande!=null) 
	begin 
	 
		create table #DAL 
		( 
		RDAARTICLE	char(15)	not null, 
		Qte			int				null 
		) 
	 
		insert into #DAL 
		select RDAARTICLE,isnull(sum(RDAQTE),0)
		from #Tab,FRDA,FDA,FDAL 
		where Article=RDAARTICLE and DALSEQ=RDASEQ and DACODE=DALCODE 
			and (RDADATE is null or RDADATE<= DateFinAnalyseFO) 
			and (@ent is null or RDAENT=@ent) 
			and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande) 
		group by RDAARTICLE 
		 
		create unique index art	on #DAL (RDAARTICLE)
		 
		update #Tab 
		set TotalDA=Qte 
		from #DAL 
		where Article=RDAARTICLE 
		 
		drop table #DAL 
		 
	end 
	 
	 
	/* Selection des commandes Fournisseurs (avec les non confirmees) */ 
	 
	select RCFARTICLE,Qte=isnull(sum(RCFQTE),0)
	into #CFL 
	from #Tab,FRCF
	where Article=RCFARTICLE 
		and (RCFDATE is null or RCFDATE<= DateFinAnalyseFO)
		and (@ent is null or RCFENT=@ent) 
	group by RCFARTICLE
	
	create unique index art	on #CFL (RCFARTICLE)
	
	update #Tab 
	set TotalCF=Qte 
	from #CFL 
	where Article=RCFARTICLE 
	 
	drop table #CFL 
	 
	/* Mise a jour des dernieres valeurs */
	
	update #Tab set Dispo=(isnull(TotalCF,0)+isnull(TotalDA,0)+isnull(TotalST,0))-isnull(TotalCC,0) 
	 
	if @SansStockMini = 0 
	begin 
		update #Tab set ACommander=isnull(StockMini,0)-isnull(Dispo,0)  
	end 
	else 
	begin 
		update #Tab set ACommander=-isnull(Dispo,0) 
	end 
	 
	/* Statistiques */ 
	
	declare @an	  smallint 
	select  @an = datepart(yy,getdate())
	
	create table #An 
	( 
	An_Article		char(15)	not null, 
	An_Qte			int				null 
	)
	
	create table #Fal 
	( 
	Fal_Article		char(15)	not null, 
	Fal_Qte			int	 			null 
	)
	
	if @ComSeulement=0 
	begin 
		/* Recuperation du nombre d article vendus l annee en cours */
		
		insert into #An (An_Article,An_Qte)
		select START,isnull(sum(STQTEFA),0)
		from #Tab,FST,#FCL
		where START=Article
		and STCL=CLCODE
		and STAN = @an
		and (@ent is null or STENT=@ent)
		group by START
	 
		/* Recuperation du nombre d articles vendus l annee precedent la date demandee */ 
		
		insert into #Fal (Fal_Article,Fal_Qte)
		select START,isnull(sum(STQTEFA),0)
		from #Tab,FST,#FCL
		where START=Article
		and STCL=CLCODE
		and STAN=@an-1
		and (@ent is null or STENT=@ent)
		group by START
	end 
	else 
	begin 
		/* Recuperation du nombre d article vendus l annee en cours */ 
		
		insert into #An (An_Article,An_Qte)
		select START,isnull(sum(STQTEFA),0) 
		from #Tab,FST,#FCL 
		where START=Article 
		and STCL=CLCODE 
		and STAN = @an 
		and ACommander>0 
		and (@ent is null or STENT=@ent) 
		group by START 
	 
		/* Recuperation du nombre d article vendus l annee precedant la date demandee */ 
		
		insert into #Fal (Fal_Article,Fal_Qte)
		select START,isnull(sum(STQTEFA),0)
		from #Tab,FST,#FCL 
		where START=Article 
		and STCL=CLCODE 
		and STAN=@an-1 
		and ACommander>0 
		and (@ent is null or STENT=@ent) 
		group by START 
	end 
	 
	create unique index art	on #An (An_Article)
	
	create unique index art	on #Fal (Fal_Article)
	
	/* Qte facturee durant la periode choisie */
	
	
	select FALARTICLE,FALQTE=isnull(sum(FALQTE),0)
	into #FalPeriode
	from #Tab,FAR,FFAL
	where FALARTICLE=Article
	and ARCODE=FALARTICLE
	and isnull(FALLETTRE,'')!=''
	and FALDATE between dateadd(dd,isnull(ARNBJVENTE,0)*(-1),@DateTrav) and @DateTrav
	and (@ent is null or FALENT=@ent) 
	group by FALARTICLE
	
	create unique index art	on #FalPeriode (FALARTICLE)
	
	
	/* regroupement final */
	
	insert into #Final (ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,
		TotalCC,TotalCF,TotalDA,TotalST,StockMini,Dispo,ACommander,
		Annee_en_Cours,Annee_Precedente,AFacturer,Compose,ARREGROUPE,
		ARNBJSEC,ARNBJVENTE,ARQTECOLIS,ARFDELAI,Besoin,Moyenne,Fournisseur,
		ARFOREIGN1,ARCALIBRE,FALQTE,ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev)
	select isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(ARGRFAM,""),isnull(Article,""),isnull(ARREFFOUR,""),
		isnull(ARLIB,""),isnull(ARPRM,0),isnull(ARCHEFP,""), 
		sum(isnull(TotalCC,0)),sum(isnull(TotalCF,0)),sum(isnull(TotalDA,0)),sum(isnull(TotalST,0)),
		sum(isnull(StockMini,0)),sum(isnull(Dispo,0)),sum(isnull(ACommander,0)), 
		sum(isnull(An_Qte,0)),sum(isnull(Fal_Qte,0)),sum(isnull(AFacturer,0)),
		Compose,isnull(ARREGROUPE,""),isnull(ARNBJSEC,0),isnull(ARNBJVENTE,0),isnull(ARQTECOLIS,0),
		0,0,0,"",isnull(ARFOREIGN1,""),isnull(ARCALIBRE,""),sum(isnull(FALQTE,0)),
		ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,dateadd(dd,DelaiLiv,@DateTrav),PADev,Dev
	from #Tab,#An,#Fal,#FalPeriode,FAR
	where An_Article=*Article
		and Fal_Article=*Article
		and FALARTICLE=*Article
		and ARCODE=Article
	group by ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,
		Compose,ARREGROUPE,ARNBJSEC,ARNBJVENTE,ARQTECOLIS,ARFOREIGN1,ARCALIBRE,
		ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,dateadd(dd,DelaiLiv,@DateTrav),PADev,Dev
	order by Article
	 
	create index articles on #Final (Article)
	
    update #Final set Fournisseur=ARFFO from FARF where Article=ARFCODE and ARFDEFAUT=1 /* A revoir car a quoi sert @fournis */
	 
	/* ----------------------------------------------------------------*/  
	/* Traitement si pas de remplacement des kits par leurs composants */  
	/* ----------------------------------------------------------------*/  

	if @kit=0 
	begin 
	  
	 
		/* --calcul du besoin theorique et de la moyenne des ventes mensuelles   */ 
		 
		declare cursbesoin cursor   
		for select Article,isnull(ARNBJSEC,0),isnull(ARNBJVENTE,0),FALQTE
		from #Final  
		for read only 
		  
		open cursbesoin  
		  
		fetch cursbesoin  
		into @ARTICLE,@nbjsec,@nbjvente,@FALQTE
		  
		while (@@sqlstatus = 0)
		begin 	 
		   
		/*select @ARTICLE,@nbjsec,@nbjvente */ 
			if @nbjvente=0 
				select @nbjvente=1 
				 
			select @Moyenne=(@FALQTE)/round(convert(numeric(14,2),@nbjvente)/30,2)
	 
			if 	@Fournisseur is null
			begin
				select @delai=isnull(ARDELAI,0) from FAR where ARCODE=@ARTICLE
			end
			else
			begin
				select @delai=0
				select @delai=isnull(ARFDELAI,0) from FARF 
					where ARFFO=@fournis and ARFCODE=@ARTICLE 
						and (@foPrincipal = 0 or ARFDEFAUT=1)
						
				if isnull(@delai,0)=0
					select @delai=isnull(ARDELAI,0) from FAR where ARCODE=@ARTICLE
			end
	
			/************ select @Besoins=convert(numeric(14,2),@Moyenne*round(convert(numeric(14,2),@delai+@nbjsec)/30,2)) ************/
			select @DateFinAnalyseFO = DateFinAnalyseFO from #Tab where Article = @ARTICLE
			select @Besoins=convert(numeric(14,2),@Moyenne*round(convert(numeric(14,2),datediff(dd,@DateTrav,@DateFinAnalyseFO))/30,2))
	 
			update #Final set Moyenne=round(@Moyenne,0),ARFDELAI=@delai,Besoin=round(@Besoins,0),Fournisseur=@fournis
			where Article=@ARTICLE
		 
			fetch cursbesoin  
			into @ARTICLE,@nbjsec,@nbjvente,@FALQTE 
			  
		end
		  
		close cursbesoin  
		deallocate cursor cursbesoin  
		 
		 
		/* ----------------------------------------------------------------------------------------- */ 
		/* ----  renvoi le final                                                                     */ 
		/* ----------------------------------------------------------------------------------------- */ 
		if @ComSeulement=0  
		begin  
			select ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,TotalCC,TotalCF,TotalDA,TotalST,  
			StockMini,Dispo,ACommander=(case when ACommander < 0 then 0 else isnull(ACommander,0) end),  
			Annee_en_Cours,Annee_Precedente,convert(numeric(14,4),Annee_en_Cours)/@nbreweek,AFacturer,ARREGROUPE , 
			round(convert(dec(5,2),ARNBJSEC)/30,2),round(convert(dec(5,2),ARNBJVENTE)/30,2),round(convert(dec(5,2),ARFDELAI)/30,2), 
			ARQTECOLIS,Besoin,Moyenne,(case when ACommander < 0 then 0 else isnull(ACommander,0) end),Fournisseur,ARFOREIGN1,ARCALIBRE,
			ARFRANCOFO,DateFinAnalyseCL,DateLivraison,PADev,Dev
			from #Final  
			order by Article  
		end 
		else  
		begin  
			select ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,TotalCC,TotalCF,TotalDA, 
			TotalST,StockMini,Dispo,ACommander,  
			Annee_en_Cours,Annee_Precedente,convert(numeric(14,4),Annee_en_Cours)/@nbreweek,AFacturer,ARREGROUPE, 
			round(convert(dec(5,2),ARNBJSEC)/30,2),round(convert(dec(5,2),ARNBJVENTE)/30,2),round(convert(dec(5,2),ARFDELAI)/30,2), 
			ARQTECOLIS,Besoin,Moyenne,ACommander,Fournisseur,ARFOREIGN1,ARCALIBRE,ARFRANCOFO,DateFinAnalyseCL,DateLivraison,PADev,Dev
			from #Final  
			where isnull(ACommander,0)>0  
			order by Article
		end  
	end  

	/* ---------------------------------------------------------*/  
	/* Traitement si remplacement des kits par leurs composants */  
	/* ---------------------------------------------------------*/  

	else  
	begin  
		/* -----------------------------------------------------*/
		
		  
		declare curskit cursor   
		for select ARCCOMP
		from #Final,FAR,FARC
		where Compose=2
		and ARCCODE=Article
		and ARCODE=Article
		and ARTYPE=0
		and (@ComSeulement=0 or isnull(ACommander,0)>0)
		group by ARCCOMP

		
		open curskit  
		  
		fetch curskit  
		into @COMPART

		while (@@sqlstatus = 0)  
		begin
							
			select 	@TotCC = 0,
					@TotCCc = 0,
					@TotDA = 0,
					@TotDAc = 0,
					@TotCF = 0,
					@TotCFc = 0,
					@TotBEaFact = 0,
					@TotBEaFactc = 0,
					@TotST = 0,
					@TotSTc = 0,
					@Totan = 0,
					@Totanc = 0,
					@Totan_1 = 0,
					@Totan_1c = 0
	
	
		/* insertion du composant dans Final (si il n y est pas deja) - le composant ne fait alors pas partie de la selection */
			
			select @count=0  
			select @count=count(*) from #Final  
				where Article=@COMPART
		
		if @count > 0
		begin
		
			select @ARFRANCOFO=ARFRANCOFO,@DateFinAnalyseCL=DateFinAnalyseCL,@DateFinAnalyseFO=DateFinAnalyseFO,
					@DateLivraison=DateLivraison,@PADev=PADev,@Dev=Dev
				from #Final  
				where Article=@COMPART
		end		
		else if @count=0
		begin
								  
			/* Prix Achat, Devise, Delai de Livraison, Date de Livraison */
					
					if 	@Fournisseur is null
					begin
						select @DelaiLiv = ARDELAI from FAR where ARCODE=@COMPART
						
						select @PADev = (case when isnull(ARFPADEV,0)=0 then ARPADEV else ARFPADEV end),
							@Dev = (case when isnull(ARFPADEV,0)=0 then ARDEVPASTAND else ARFDEV end)
						from FAR,FARF
						where ARFCODE=ARCODE and ARCODE=@COMPART and ARFDEFAUT=1
						
						if isnull(@PADev,0) = 0
							select @PADev = ARPADEV, @Dev = ARDEVPASTAND
							from FAR
							where ARCODE=@COMPART
					end
					else
					begin
						select @PADev = (case when isnull(ARFPADEV,0)=0 then ARPADEV else ARFPADEV end),
							@Dev = (case when isnull(ARFPADEV,0)=0 then ARDEVPASTAND else ARFDEV end),
							@DelaiLiv = (case when isnull(ARFDELAI,0)=0 then ARDELAI else ARFDELAI end)
						from FAR,FARF
						where ARFCODE=ARCODE and ARCODE=@COMPART 
							and ARFFO=@Fournisseur
							and (@foPrincipal = 0 or ARFDEFAUT=1)
							
						if isnull(@DelaiLiv,0) = 0
							select @DelaiLiv = ARDELAI from FAR where ARCODE=@COMPART
							
						if isnull(@PADev,0) = 0
							select @PADev = ARPADEV, @Dev = ARDEVPASTAND
							from FAR
							where ARCODE=@COMPART
					end
					
					select @DateLivraison = dateadd(dd,@DelaiLiv,@DateTrav)
				
			/*- dates fin analyse ---*/
					
					if @delaisArt = 0
						select 
							@DateFinAnalyseCL = dateadd(dd,isnull(ARNBJSEC,0)+@jperiodesup,@DateCL),
							@DateFinAnalyseFO = dateadd(dd,isnull(ARNBJSEC,0)+@jperiodesup,@DateFO),
							@ARFRANCOFO = ARFRANCOFO
						from FAR
						where ARCODE=@COMPART
					else
					begin
						select @DateFinAnalyseCL = 
							(case when (ARNEW=1 and ARDATEDISPO is not null) then 
								(case when dateadd(dd,@DelaiLiv+isnull(ARNBJSEC,0)+@jperiodesup,@DateTrav) < ARDATEDISPO 
									then dateadd(dd,isnull(ARNBJSEC,0)+@jperiodesup,ARDATEDISPO)
									else dateadd(dd,@DelaiLiv+isnull(ARNBJSEC,0)+@jperiodesup,@DateTrav) 
								end)
							else 
								dateadd(dd,@DelaiLiv+isnull(ARNBJSEC,0)+@jperiodesup,@DateTrav)
							end),
							@ARFRANCOFO = ARFRANCOFO
						from FAR
						where ARCODE=@COMPART
						
						select @DateFinAnalyseFO = @DateFinAnalyseCL
					end


			/*- calcul du stock TotalST pour le composant ---*/
					
					select @TotST = isnull(sum(STQTE),0)  
					from FSTOCK,FDP,#Depots 
					where DPCODE=STDEPOT
						and DPCODE=depot
						and STAR=@COMPART  
						and STQTE != 0  
						and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
					
					
			/*- calcul des BE a facturer clients TotalBE ---*/
					
					select @TotBEaFact = isnull(sum(RBEQTE),0)  
					from FRBE,#FCL 
					where RBEARTICLE=@COMPART  
						and RBECL=CLCODE 
						and (RBEDATE <= @DateFinAnalyseCL or RBEDATE is null)   
						and (@ent is null or RBEENT=@ent)
						
					
			/*- calcul des commandes clients TotalCC ---*/
					
					select @TotCC = isnull(sum(RCCQTE),0)  
					from FRCC,#FCL  
					where RCCARTICLE=@COMPART  
						and RCCCL=CLCODE 
						and (RCCDATE <= @DateFinAnalyseCL or RCCDATE is null)   
						and (@ent is null or RCCENT=@ent)
						
					
			/*- calcul des commandes fournisseurs TotalCF ---*/
					
					select @TotCF = isnull(sum(RCFQTE),0)  
					from FRCF  
					where RCFARTICLE=@COMPART  
						and (RCFDATE<= @DateFinAnalyseFO or RCFDATE is null)   
						and (@ent is null or RCFENT=@ent)  
					

			/*- calcul des demandes d achat fournisseurs TotalDA ---*/
					
					select @TotDA = 0  
					if (@typeDemande!=null)
					begin
						select @TotDA=isnull(sum(RDAQTE),0)
						from FRDA,FDA,FDAL  
						where RDAARTICLE=@COMPART  
							and DALSEQ=RDASEQ  
							and DACODE=DALCODE  
							and (RDADATE<= @DateFinAnalyseFO or RDADATE is null)   
							and (@ent is null or RDAENT=@ent)  
							and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande)
					end		
					
						
			/* Recuperation du nombre d article vendus l annee en cours */
					
					select @Totan = isnull(sum(STQTEFA),0)  
					from FST,#FCL  
					where START=@COMPART 
						and STCL=CLCODE 
						and STAN = @an  
						and (@ent is null or STENT=@ent)
						
					
					
			/* Recuperation du nombre d articles vendus l annee precedent la date demandee */
					
					select @Totan_1 = isnull(sum(STQTEFA),0)  
					from FST,#FCL  
					where START=@COMPART  
						and STCL=CLCODE 
						and STAN = @an-1  
						and (@ent is null or STENT=@ent)
						
			
			/* Qte facturee durant la periode choisie */
					 
					select @FALQTE = isnull(sum(FALQTE),0)
					from FAR,FFAL,#FCL
					where FALARTICLE=@COMPART
						and FALCL=CLCODE
						and ARCODE=FALARTICLE
						and isnull(FALLETTRE,'')!=''
						and FALDATE between dateadd(dd,isnull(ARNBJVENTE,0)*(-1),@DateTrav) and @DateTrav
						and (@ent is null or FALENT=@ent) 
					


			/* insertion dans #Final des lignes concernant le composant */
					 
					insert into #Final (ARDEPART,ARFO,ARFAM,ARGRFAM,
						Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,  
						TotalCC,TotalCF,TotalDA,TotalST,StockMini,  
						Dispo,ACommander,
						Annee_en_Cours,Annee_Precedente,AFacturer,Compose,ARREGROUPE, 
						ARNBJSEC,ARNBJVENTE,ARQTECOLIS,ARFDELAI,Besoin,Moyenne,ARFOREIGN1,
						ARCALIBRE,FALQTE,ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev)  
					select isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(ARGRFAM,""),
						@COMPART,isnull(ARREFFOUR,""),isnull(ARLIB,""),isnull(ARPRM,0),isnull(ARCHEFP,""),  
						isnull(@TotCC,0),isnull(@TotCF,0),isnull(@TotDA,0),isnull(@TotST,0),isnull(ARSTOCKMINI,0),
						isnull(@TotCF,0)+isnull(@TotDA,0)+isnull(@TotST,0),-(isnull(@TotCF,0)+isnull(@TotDA,0)+isnull(@TotST,0)),  
						isnull(@Totan,0),isnull(@Totan_1,0),isnull(@TotBEaFact,0),1,isnull(ARREGROUPE,""),  
						isnull(ARNBJSEC,0),isnull(ARNBJVENTE,0),isnull(ARQTECOLIS,0),0,0,0,isnull(ARFOREIGN1,""),
						isnull(ARCALIBRE,""),isnull(@FALQTE,0),ARFRANCOFO,@DateFinAnalyseCL,@DateFinAnalyseFO,@DateLivraison,@PADev,@Dev
					from FAR 
					where ARCODE=@COMPART 
		end 

		/* Totalisation du composant a partir des produits finis concernes sans distinction de selection */

					select @TotSTc = isnull(sum(STQTE*ARCQTE),0)
					from FSTOCK,FDP,FARC,#Depots 
					where DPCODE=STDEPOT
						and DPCODE=depot
						and STAR=ARCCODE
						and ARCCOMP=@COMPART
						and STQTE != 0
						and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
				

					select @TotBEaFactc = isnull(sum(RBEQTE*ARCQTE),0)  
					from FRBE,#FCL,FARC
					where RBEARTICLE=ARCCODE
						and ARCCOMP=@COMPART
						and RBECL=CLCODE 
						and (RBEDATE <= @DateFinAnalyseCL or RBEDATE is null)   
						and (@ent is null or RBEENT=@ent)
					

					select @TotCCc = isnull(sum(RCCQTE*ARCQTE),0)  
					from FRCC,#FCL,FARC 
					where RCCARTICLE=ARCCODE
						and ARCCOMP=@COMPART
						and RCCCL=CLCODE 
						and (RCCDATE <= @DateFinAnalyseCL or RCCDATE is null)   
						and (@ent is null or RCCENT=@ent)
					

					select @TotCFc = isnull(sum(RCFQTE*ARCQTE),0)
					from FRCF,FARC
					where RCFARTICLE=ARCCODE
						and (RCFDATE<= @DateFinAnalyseFO or RCFDATE is null)    
						and ARCCOMP=@COMPART
						and (@ent is null or RCFENT=@ent)
						

					select @TotDAc = 0  
					if (@typeDemande!=null)
					begin
						select @TotDAc = isnull(sum(RDAQTE*ARCQTE),0)
						from FRDA,FDA,FDAL,FARC
						where RDAARTICLE=ARCCODE
							and ARCCOMP=@COMPART 
							and DALSEQ=RDASEQ  
							and DACODE=DALCODE  
							and (RDADATE<= @DateFinAnalyseFO or RDADATE is null)   
							and (@ent is null or RDAENT=@ent)  
							and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande)
					end

					select @Totanc = isnull(sum(STQTEFA*ARCQTE),0)  
					from FST,#FCL,FARC 
					where START=ARCCODE
						and ARCCOMP=@COMPART 
						and STCL=CLCODE 
						and STAN = @an  
						and (@ent is null or STENT=@ent)
						

					select @Totan_1c = isnull(sum(STQTEFA*ARCQTE),0)  
					from FST,#FCL,FARC 
					where START=ARCCODE
						and ARCCOMP=@COMPART 
						and STCL=CLCODE 
						and STAN = @an-1 
						and (@ent is null or STENT=@ent)
						

					select @FALQTEc = isnull(sum(FALQTE*ARCQTE),0)
					from FAR,FFAL,FARC,#FCL
					where FALARTICLE=ARCCODE
						and FALCL=CLCODE
						and ARCCOMP=@COMPART
						and ARCODE=FALARTICLE
						and isnull(FALLETTRE,'')!=''
						and FALDATE between dateadd(dd,isnull(ARNBJVENTE,0)*(-1),@DateTrav) and @DateTrav
						and (@ent is null or FALENT=@ent) 

				if (@typeDemande = null)  
					select @TOTALDA = 0			  
				
				/*- Mise a jour des dernieres valeurs --*/  
				  
				select @DISPO=(isnull(@TotCFc,0)+isnull(@TotDAc,0)+isnull(@TotSTc,0))  
								-(isnull(@TotCCc,0))  
				  
				if @SansStockMini = 0  
				begin  
					select @STOCKMINI=isnull(ARSTOCKMINI,0) from FAR where ARCODE=@COMPART  
					select @ACOMMANDER=isnull(@STOCKMINI,0) - (isnull(@DISPO,0))  
				end  
				else
					select @ACOMMANDER = -(isnull(@DISPO,0))
					  
					  
					/*- ajout des composants dans finalkit ---*/  
					  
				insert into #FinalKit (Article,StockMini,TotalCC,TotalST,TotalCF,
					TotalDA,Dispo,ACommander,AFacturer,Annee_en_Cours,
					Annee_Precedente,TotalFAPeriode,Compose,
					ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev)  
				values (@COMPART,@STOCKMINI,isnull(@TotCCc,0),isnull(@TotSTc,0),isnull(@TotCFc,0),  
					isnull(@TotDAc,0),@DISPO,@ACOMMANDER,isnull(@TotBEaFactc,0),isnull(@Totanc,0),  
					isnull(@Totan_1c,0),isnull(@FALQTEc,0),1,
					@ARFRANCOFO,@DateFinAnalyseCL,@DateFinAnalyseFO,@DateLivraison,@PADev,@Dev)  
				  
		  
		  
			fetch curskit  
			into @COMPART
			  
		end  
		  
		close curskit  
		deallocate cursor curskit

		  
		delete #Final where Compose=2  
		  
		insert into #Final(ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,
			ARLIB,ARPRM,ARCHEFP,TotalCC,TotalCF,TotalDA,TotalST,StockMini,Dispo,
			ACommander,Annee_en_Cours,Annee_Precedente,AFacturer,Compose,ARREGROUPE,ARNBJSEC,
			ARNBJVENTE,ARQTECOLIS,ARFDELAI,Besoin,Moyenne,ARFOREIGN1,ARCALIBRE,FALQTE,ARFRANCOFO,
			DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev)  
		select  isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(ARGRFAM,""),isnull(Article,""),isnull(ARREFFOUR,""),
			isnull(ARLIB,""),isnull(ARPRM,0),isnull(ARCHEFP,""),sum(TotalCC),sum(TotalCF),sum(TotalDA),sum(TotalST),StockMini,Dispo,
			sum(ACommander),sum(Annee_en_Cours),sum(Annee_Precedente),sum(AFacturer),1,isnull(ARREGROUPE,""),isnull(ARNBJSEC,0),
			isnull(ARNBJVENTE,0),isnull(ARQTECOLIS,0),0,0,0,isnull(ARFOREIGN1,""),isnull(ARCALIBRE,""),sum(TotalFAPeriode),#FinalKit.ARFRANCOFO,
			DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev
		from #FinalKit,FAR  
		where ARCODE=Article 
		group by  ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,StockMini,Dispo,
			ARREGROUPE,ARNBJSEC,ARNBJVENTE,ARQTECOLIS,ARFOREIGN1,ARCALIBRE,#FinalKit.ARFRANCOFO,
			DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev
		 
		 
		
		insert into #Final2(ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,
			ARLIB,ARPRM,ARCHEFP,TotalCC,TotalCF,TotalDA,TotalST,
			StockMini,Dispo,ACommander,Annee_en_Cours,Annee_Precedente,
			AFacturer,Compose,ARREGROUPE,ARNBJSEC,ARNBJVENTE,ARQTECOLIS,ARFDELAI,Besoin,Moyenne,ARFOREIGN1,ARCALIBRE,FALQTE,
			ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev)  
		select isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(ARGRFAM,""),isnull(Article,""),isnull(ARREFFOUR,""),
			ARLIB,ARPRM,ARCHEFP, sum(isnull(TotalCC,0)),sum(isnull(TotalCF,0)),sum(isnull(TotalDA,0)),sum(isnull(TotalST,0)),
			sum(isnull(StockMini,0)),sum(isnull(Dispo,0)),sum(isnull(ACommander,0)),sum(isnull(Annee_en_Cours,0)),sum(isnull(Annee_Precedente,0)),
			sum(isnull(AFacturer,0)),Compose,ARREGROUPE,ARNBJSEC,ARNBJVENTE,ARQTECOLIS,0,0,0,ARFOREIGN1,ARCALIBRE,sum(isnull(FALQTE,0)),
			ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev
		from #Final
		group by ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,ARREGROUPE,
			ARNBJSEC,ARNBJVENTE,ARQTECOLIS,ARFOREIGN1,ARCALIBRE,ARFRANCOFO,DateFinAnalyseCL,DateFinAnalyseFO,DateLivraison,PADev,Dev
		
		create index articles on #Final2 (Article)
		
		
		/* --calcul du besoin theorique et de la moyenne des ventes mensuelles  */ 
		 
		declare cursbesoin cursor   
		for select Article,isnull(ARNBJSEC,0),isnull(ARNBJVENTE,0),isnull(FALQTE,0) 
		from #Final2
		for read only
		  
		open cursbesoin  
		  
		fetch cursbesoin  
		into @ARTICLE,@nbjsec,@nbjvente,@FALQTE
		  
		while (@@sqlstatus = 0)  
		begin 	 
			if @nbjvente=0 
				select @nbjvente=1 
				 
			select @Moyenne=(@FALQTE)/round(convert(dec(5,2),@nbjvente)/30,2)			
			
			if 	@Fournisseur is null
			begin
				select @delai=isnull(ARDELAI,0) from FAR where ARCODE=@ARTICLE
			end
			else
			begin
				select @delai=0
				select @delai=isnull(ARFDELAI,0) from FARF 
					where ARFFO=@fournis and ARFCODE=@ARTICLE 
						and (@foPrincipal = 0 or ARFDEFAUT=1)
				if isnull(@delai,0)=0
					select @delai=isnull(ARDELAI,0) from FAR where ARCODE=@ARTICLE
			end

			
			/*********** select @Besoins=convert(numeric(14,2),@Moyenne*round(convert(dec(5,2),@delai+@nbjsec)/30,2)) ************/
			select @DateFinAnalyseFO = DateFinAnalyseFO from #Tab where Article = 	@ARTICLE			
			select @Besoins=convert(numeric(14,2),@Moyenne*round(convert(numeric(14,2),datediff (dd,@DateTrav,@DateFinAnalyseFO))/30,2))
	 
			update #Final2 set Moyenne=round(@Moyenne,0),ARFDELAI=@delai,Besoin=round(@Besoins,0),Fournisseur=@fournis
			where Article=@ARTICLE
		 
			fetch cursbesoin  
			into @ARTICLE,@nbjsec,@nbjvente,@FALQTE 
			  
		end  
		  
		close cursbesoin  
		deallocate cursor cursbesoin  
		 
        update #Final2 set Fournisseur=ARFFO from FARF where Article=ARFCODE and ARFDEFAUT=1 /* A revoir car a quoi sert @fournis */ 
		  
		/* ----  renvoi le final        */  
		if @ComSeulement=0  
				select ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,sum(TotalCC),sum(TotalCF),  
				sum(TotalDA),sum(TotalST),sum(StockMini),sum(Dispo),(case when sum(ACommander) < 0 then 0 else sum(ACommander) end),  
				sum(Annee_en_Cours),sum(Annee_Precedente),sum(convert(numeric(14,4),Annee_en_Cours)/@nbreweek),sum(AFacturer), 
				ARREGROUPE, 
				round(convert(dec(5,2),ARNBJSEC)/30,2),round(convert(dec(5,2),ARNBJVENTE)/30,2),round(convert(dec(5,2),ARFDELAI)/30,2), 
				ARQTECOLIS,sum(Besoin),sum(Moyenne), 
				(case when sum(ACommander) < 0 then 0 else sum(ACommander) end),Fournisseur,ARFOREIGN1,ARCALIBRE,
				ARFRANCOFO,DateFinAnalyseCL,DateLivraison,PADev,Dev
			from #Final2  
			group by Article,ARDEPART,ARFO,ARFAM,ARGRFAM,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,ARREGROUPE, 
				ARNBJSEC,ARNBJVENTE,ARFDELAI,ARQTECOLIS,Fournisseur,ARFOREIGN1,ARCALIBRE,ARFRANCOFO,DateFinAnalyseCL,DateLivraison,PADev,Dev
		else  
			select ARDEPART,ARFO,ARFAM,ARGRFAM,Article,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,sum(TotalCC),sum(TotalCF),  
				sum(TotalDA),sum(TotalST),sum(StockMini),sum(Dispo),sum(ACommander),sum(Annee_en_Cours),  
				sum(Annee_Precedente),sum(convert(numeric(14,4),Annee_en_Cours)/@nbreweek),sum(AFacturer),ARREGROUPE, 
				round(convert(dec(5,2),ARNBJSEC)/30,2),round(convert(dec(5,2),ARNBJVENTE)/30,2),round(convert(dec(5,2),ARFDELAI)/30,2), 
				ARQTECOLIS,sum(Besoin),sum(Moyenne), 
				sum(ACommander),Fournisseur,ARFOREIGN1,ARCALIBRE,ARFRANCOFO,DateFinAnalyseCL,DateLivraison,PADev,Dev
			from #Final2  
			group by Article,ARDEPART,ARFO,ARFAM,ARGRFAM,ARREFFOUR,ARLIB,ARPRM,ARCHEFP,Compose,ARREGROUPE, 
				ARNBJSEC,ARNBJVENTE,ARFDELAI,ARQTECOLIS,Fournisseur,ARFOREIGN1,ARCALIBRE,ARFRANCOFO,DateFinAnalyseCL,DateLivraison,PADev,Dev
			having sum(ACommander) > 0  
			  
		  
		/* -----------------------------------------------------*/  
	end   
	  
	/* -----------------------------------------------------*/  
	/* drop des tables 										*/  
	/* -----------------------------------------------------*/  
	  
	drop table 	#Tab  
	drop table 	#An  
	drop table 	#Fal  
	drop table 	#Final
	drop table 	#Final2  
	drop table 	#FinalKit
	drop table 	#FalPeriode
	
	declare @base varchar(30)
	select @base = db_name()
	dump tran @base with truncate_only
end
go

