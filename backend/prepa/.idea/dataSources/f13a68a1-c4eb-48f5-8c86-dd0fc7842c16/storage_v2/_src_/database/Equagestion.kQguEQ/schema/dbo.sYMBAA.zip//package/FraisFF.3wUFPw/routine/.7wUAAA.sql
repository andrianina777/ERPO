


create procedure FraisFF (	@ent	char(5) = null,
							@date1	datetime = null,
						  	@date2	datetime = null)
with recompile
as
begin

set arithabort numeric_truncation off


if @date1 is null
begin
select @date1=convert(datetime,"01/01/"+convert(varchar,datepart(yy,getdate())))
select @date2=convert(datetime,"12/31/"+convert(varchar,datepart(yy,getdate())))
end


create table #Liste
(
frais		numeric(14,2)	null,	/* Frais */
compte		char(8)			null	/* Compte d''achat associe aux frais */
)


/**** Frais sur ligne frais de transport ****/

insert into #Liste (compte,frais)
select TVLCPT,sum(FFFRAISFR)
from FFF, FFO, FTVL
where FFFO=FOCODE and TVLCODE=FFTAFRAIS and TVLCLASSE=FOCLASSE
and FFDATE between @date1 and @date2
and (@ent is null or (FFENT=@ent and TVLENT=@ent))
group by TVLCPT

/**** Frais sur ligne frais de douanes ****/

insert into #Liste (compte,frais)
select TVLCPT,sum(FFDOUAFR)
from FFF, FFO, FTVL
where FFFO=FOCODE and TVLCODE=FFTADOUA and TVLCLASSE=FOCLASSE
and FFDATE between @date1 and @date2
and (@ent is null or (FFENT=@ent and TVLENT=@ent))
group by TVLCPT

/**** Frais sur ligne frais de transitaires ****/

insert into #Liste (compte,frais)
select TVLCPT,sum(FFTRANSFR)
from FFF, FFO, FTVL
where FFFO=FOCODE and TVLCODE=FFTATRANS and TVLCLASSE=FOCLASSE
and FFDATE between @date1 and @date2
and (@ent is null or (FFENT=@ent and TVLENT=@ent))
group by TVLCPT

/**** Frais sur ligne frais de TVA transitaires ****/

insert into #Liste (compte,frais)
select TVLCPT,sum(FFTVAFR)
from FFF, FFO, FTVL
where FFFO=FOCODE and TVLCODE=FFTATVA and TVLCLASSE=FOCLASSE
and FFDATE between @date1 and @date2
and (@ent is null or (FFENT=@ent and TVLENT=@ent))
group by TVLCPT

 

/**** select final ****/

select compte,sum(frais)
from #Liste
group by compte
having sum(frais) != 0
order by compte


drop table #Liste

end



go

