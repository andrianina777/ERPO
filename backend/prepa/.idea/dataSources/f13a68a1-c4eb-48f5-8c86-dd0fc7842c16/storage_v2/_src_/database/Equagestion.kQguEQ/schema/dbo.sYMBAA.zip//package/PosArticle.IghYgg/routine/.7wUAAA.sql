
create procedure PosArticle (@ent				char(5)	= null,
							 @article			char(15),
							 @typeDemande		tinyint	=null,
							 @depot				char(4)	= null,
							 @AvecCdesNonConf	tinyint = 1
							)
with recompile
as
begin

create table #Pos
(
periode	int			null,
qteST	int			null,
qteCcl	int			null,
qteCfn	int			null,
qteRes	int			null,
qteAfn	int			null,
qtePrep	int			null,
date	datetime	null
)

declare @date1 		datetime
declare @date2		datetime
declare @date3		datetime
declare @date4		datetime
declare @date5		datetime
declare @date6		datetime
declare @date7		datetime
declare @date8		datetime
declare @date9		datetime


 

select @date1=convert(datetime,convert(varchar,datepart(mm,getdate()))+"/"+convert(varchar,datepart(dd,getdate()))+"/"+convert(varchar,datepart(yy,getdate()))+" 22:00:00")
select @date2=dateadd(wk,1,@date1)
select @date3=dateadd(wk,2,@date1)
select @date4=dateadd(wk,3,@date1)
select @date5=dateadd(mm,1,@date1)
select @date6=dateadd(mm,2,@date1)
select @date7=dateadd(qq,1,@date1)
select @date8=dateadd(qq,2,@date1)
select @date9=dateadd(yy,1,@date1)

/* select @datefin=convert(datetime,'12/31/'+convert(varchar(4),datepart(yy,@date3))) */


insert into #Pos (periode,date)
values (1,@date1)

insert into #Pos (periode,date)
values (2,@date2)

insert into #Pos (periode,date)
values (3,@date3)

insert into #Pos (periode,date)
values (4,@date4)

insert into #Pos (periode,date)
values (5,@date5)

insert into #Pos (periode,date)
values (6,@date6)

insert into #Pos (periode,date)
values (7,@date7)

insert into #Pos (periode,date)
values (8,@date8)

insert into #Pos (periode,date)
values (9,@date9)

create unique index period on #Pos (periode)

/* ***** */
/* Stock */
/* ***** */

update #Pos 
set qteST=(select sum(STQTE)
		   from FSTOCK,FDP
		   where STAR=@article
		   and (@depot is null or STDEPOT = @depot)
		   and STQTE > 0
		   and DPLOC in (0,1)
		   and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
)

/* ************ */
/* Cdes Clients */
/* ************ */

update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date1)
where periode=1


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date2)
where periode=2	


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date3)
where periode=3


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ			 
  			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date4)
where periode=4


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date5)
where periode=5


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date6)
where periode=6

update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date7)
where periode=7


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date8)
where periode=8


update #Pos
set qteCcl=(select sum(RCCQTE) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and RCCDATE<=@date9)
where periode=9

/* ***************** */
/* Cdes Fournisseurs */
/* ***************** */

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ 
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date1)
where periode=1

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			  where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date1
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=1


update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date2)
where periode=2

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date2
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=2

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date3)
where periode=3

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date3
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=3


update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date4)
where periode=4

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date4
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=4

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date5)
where periode=5

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date5
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=5

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date6)
where periode=6

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date6
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
where periode=6

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date7)
where periode=7

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date7
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=7

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date8)
where periode=8

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date8
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=8

update #Pos
set qteCfn=(select sum(RCFQTE) from FRCF,FCFL,FCF
			where RCFARTICLE=@article
			  and CFLSEQ=RCFSEQ
			  and CFCODE=CFLCODE
			  and CFVALIDE=0
			  and RCFDATE<=@date9)
where periode=9

if @typeDemande is not null
	update #Pos
	set qteAfn=(select sum(RDAQTE) from FRDA,FDAL,FDA
			where RDAARTICLE=@article
			  and DALSEQ=RDASEQ 
			  and DACODE=DALCODE
			  and DAVALIDE=0
			  and DALDATEP<=@date9
			  and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande))
	where periode=9

/* ************ */
/* Qte Reservee */
/* ************ */

update #Pos
set qteRes=(select isnull(sum(RCCQTERES),0) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
/* 			  and RCCDATERESFIN >= convert(datetime,convert(varchar,datepart(mm,#Pos.date))+"/"+convert(varchar,datepart(dd,#Pos.date))+"/"+convert(varchar,datepart(yy,#Pos.date))+" 00:00:00") */
			  and (@depot is null or RCCDEPOTRES = @depot)) 


/* ************ */
/* Qte Preparee */
/* ************ */

update #Pos
set qtePrep=(select isnull(sum(RCCQTEPREP),0) from FRCC,FCCL,FCC
			where RCCARTICLE=@article
			  and CCLSEQ=RCCSEQ
			  and CCCODE=CCLCODE
			  and (@AvecCdesNonConf = 1 or CCVALIDE=0)
			  and (@depot is null or RCCDEPOTRES = @depot))


select  Periode=periode,
		Stock=isnull(qteST,0),
		Commandes_Clients=isnull(qteCcl,0),
		Qte_Reserve=isnull(qteRes,0),
		Commandes_Fourn=isnull(qteCfn,0),
		Qte_Demande=isnull(qteAfn,0),
		Stock_a_terme=isnull(qteST,0)+isnull(qteCfn,0)+isnull(qteAfn,0)-isnull(qteCcl,0),
		Stock_Net=isnull(qteST,0)-isnull(qteCcl,0),
		Qte_Prepare=isnull(qtePrep,0),
		Stock_Dispo=isnull(qteST,0)-isnull(qteRes,0)

from #Pos

end  
go

