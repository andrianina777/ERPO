
create procedure FactAtelier  (@ent				char(5) 		= null,
							   @FromClient 		char(12) 		= null,
							   @ToClient 		char(12) 		= null,
							   @FromDate 		smalldatetime 	= null,
							   @ToDate 			smalldatetime 	= null,
							   @modefact		tinyint			= 0,		/* 0 = tous les WB, 1 = par WB, 2 = par cdes, 3 = par cdes completes */
							   @periode			tinyint			= 0,
							   @codebe			char(10)	    = null,
							   @PrefEscompte	tinyint	= 0	/* 1 = traitement escompte depuis BE  - atelier non concerne pour le moment */
							   )
with recompile
as
begin

	set arithabort numeric_truncation off

	if @ToClient is null
	select @ToClient=@FromClient

	if @ToDate is null
	select @ToDate=@FromDate

  	select 	WBLCL,WBLCODE,WBLNUM,WBLARTICLE,WBLLETTRE,WBLQTE,WBLPRIXHT,
   		REMISE1=0,REMISE2=0,REMISE3=0, 
   		UNIFACT=0,TYPENORMLIBRE=0,WBLARDES,WBLTOTALHT,WBLTYPEVE,WBLFICHE,WBLDEV,TARIF='', 
   		WBLPRIXHTDEV,WBLTOTALHTDEV,WBLCOURSDEV,
   		WBADR1=isnull(WBADR1,""),WBADR2=isnull(WBADR2,""),WBCP=isnull(WBCP,""),
   		LIENLIGNECDE=1,ARTYPE,OFFERT=0,MARCHE="",WBNOM2=isnull(WBNOM2,""),WBPRENOM=isnull(WBPRENOM,""),
   		CLESCOMPTE=isnull(CLESCOMPTE,0)
  	into #WB
  	from FWBL,FRWB,FCL,FWB,FAR
   	where WBLSEQ=RWBSEQ
   	and RWBCL=CLCODE
   	and CLMODEFACT = @modefact
   	and RWBARTICLE != ''
   	and ARCODE=RWBARTICLE
   	and WBCODE=WBLCODE
   	and (@FromClient is null or RWBCL between @FromClient and @ToClient)
   	and (@FromDate is null or RWBDATE between @FromDate and @ToDate)
   	and isnull(WBLTYPEVE,'')!=''
   	and WBLQTE >= 0
   	and (@ent is null or (WBLENT=@ent and RWBENT=@ent and CLENT=@ent and WBENT=@ent))
   	and CLFACTPERIODE = @periode
   
      	/*----- Recherche et suppression des ports et assurances Isoles -----*/
   	select WBLCODE,Nb=count(*) into #port      from #WB 	where ARTYPE in (3,7) 	group by WBLCODE 
   	select WBLCODE,Nb=count(*) into #portVerif from #WB 	group by WBLCODE

   	delete #WB
   	from #portVerif,#port
   	where #WB.WBLCODE=#portVerif.WBLCODE 
   	and #portVerif.WBLCODE=#port.WBLCODE 
  	and #portVerif.Nb=#port.Nb


	if @modefact = 0
	begin
		select 	WBLCL,WBLCODE,WBLNUM,WBLARTICLE,WBLLETTRE,WBLQTE,WBLPRIXHT,
	 		REMISE1,REMISE2,REMISE3, 
	 		UNIFACT,TYPENORMLIBRE,WBLARDES,WBLTOTALHT,WBLTYPEVE,WBLFICHE,"",WBLDEV,TARIF,
	 		WBLPRIXHTDEV,WBLTOTALHTDEV,WBLCOURSDEV,WBADR1,WBADR2,WBCP,OFFERT,MARCHE,WBNOM2,WBPRENOM,CLESCOMPTE
		from #WB
		order by WBLCL,WBLDEV,WBADR1,WBADR2,WBCP,CLESCOMPTE,WBLCODE,WBLNUM
	
		drop table #WB
	end

	else if @modefact = 1
	begin
		select 	WBLCL,WBLCODE,WBLNUM,WBLARTICLE,WBLLETTRE,WBLQTE,WBLPRIXHT,
	 		REMISE1,REMISE2,REMISE3, 
	 		UNIFACT,TYPENORMLIBRE,WBLARDES,WBLTOTALHT,WBLTYPEVE,WBLFICHE,"",WBLDEV,TARIF,
	 		WBLPRIXHTDEV,WBLTOTALHTDEV,WBLCOURSDEV,WBADR1,WBADR2,WBCP,OFFERT,MARCHE,WBNOM2,WBPRENOM
		from #WB
		order by WBLCODE,WBLNUM
	
		drop table #WB
	end
	
	else if @modefact = 2
	begin
		select 	WBLCL,WBLCODE,WBLNUM,WBLARTICLE,WBLLETTRE,WBLQTE,WBLPRIXHT,
	 		REMISE1,REMISE2,REMISE3,
	 		UNIFACT,TYPENORMLIBRE,WBLARDES,WBLTOTALHT,WBLTYPEVE,WBLFICHE,"",WBLDEV,TARIF,
	 		WBLPRIXHTDEV,WBLTOTALHTDEV,WBLCOURSDEV,WBADR1,WBADR2,WBCP,OFFERT,MARCHE,WBNOM2,WBPRENOM
		from #WB
		where (ARTYPE not in (3,7) or WBLFICHE like "WR%" or WBLFICHE like "WM%" or WBLFICHE like "WF%")
		order by WBADR1,WBADR2,WBCP,WBLDEV,CLESCOMPTE,WBLFICHE,WBLCODE,WBLNUM
	
		drop table #WB
	end
	
	else if @modefact = 3
	begin
		select 	WBLCL,WBLCODE,WBLNUM,WBLARTICLE,WBLLETTRE,WBLQTE,WBLPRIXHT,
	 		REMISE1,REMISE2,REMISE3,
	 		UNIFACT,TYPENORMLIBRE,WBLARDES,WBLTOTALHT,WBLTYPEVE,WBLFICHE,"",WBLDEV,TARIF,
	 		WBLPRIXHTDEV,WBLTOTALHTDEV,WBLCOURSDEV,WBADR1,WBADR2,WBCP,OFFERT,MARCHE,WBNOM2,WBPRENOM
		from #WB
		where (ARTYPE not in (3,7) or WBLFICHE like "WR%" or WBLFICHE like "WM%" or WBLFICHE like "WF%")
		order by WBADR1,WBADR2,WBCP,WBLFICHE,WBLDEV,CLESCOMPTE
	
		drop table #WB
	end

end
go

