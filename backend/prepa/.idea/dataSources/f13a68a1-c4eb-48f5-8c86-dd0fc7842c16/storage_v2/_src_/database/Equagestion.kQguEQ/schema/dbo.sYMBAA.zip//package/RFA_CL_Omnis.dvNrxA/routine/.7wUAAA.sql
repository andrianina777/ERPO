


/* Procedure utilisee pour le calcul du droit a la RFA d''un client
	sur une ligne de facture */

create procedure RFA_CL_Omnis  (@ent		char(5) = null,
								@client		char(12),
								@annee		smallint,
								@article	char(15),
								@valeur		numeric(14,2)
								)
with recompile
as
begin

set arithabort numeric_truncation off


declare @carfa	numeric(14,2),
		@rfact	numeric(14,2)


exec RFA_CL @ent,@client,@annee,@article,@valeur,@carfa output,@rfact output



select @carfa,@rfact

end



go

