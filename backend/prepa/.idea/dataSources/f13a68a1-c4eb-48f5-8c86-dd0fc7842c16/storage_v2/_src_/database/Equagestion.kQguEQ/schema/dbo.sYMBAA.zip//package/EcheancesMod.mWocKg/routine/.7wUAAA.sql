


create procedure EcheancesMod(@ent	char(5)	= null,
							  @Mois	tinyint = null,
							  @An	smallint = null)
with recompile
as
begin

set arithabort numeric_truncation off


if ((@Mois<1) or (@Mois>12) or (@Mois is null))
select @Mois=datepart(mm,getdate())

if (@An is null)
select @An=datepart(yy,getdate())

declare @datedep	datetime
declare @datefin	datetime

select @datedep=convert(datetime,(convert(varchar(2),@Mois)+'/01/'+convert(varchar(4),@An)))

if ((@Mois=1) or (@Mois=3) or (@Mois=5) or (@Mois=7) or (@Mois=8) or (@Mois=10) or (@Mois=12))
begin
select @datefin=convert(datetime,(convert(varchar(2),@Mois)+'/31/'+convert(varchar(4),@An)))
end
if ((@Mois=4) or (@Mois=6) or (@Mois=9) or (@Mois=11))
begin
select @datefin=convert(datetime,(convert(varchar(2),@Mois)+'/30/'+convert(varchar(4),@An)))
end
if (@Mois=2)
begin
	if (@An%4=0)
	begin
	select @datefin=convert(datetime,(convert(varchar(2),@Mois)+'/29/'+convert(varchar(4),@An)))
	end
	else
	begin
	select @datefin=convert(datetime,(convert(varchar(2),@Mois)+'/28/'+convert(varchar(4),@An)))
	end
end


select ModeR=FAMODEREG1,Echeance=FATRDATE1,Montant=isnull(FAREGL1,0)
into #Temp
from FFA
where FADATE between @datedep and @datefin
and (@ent is null or FAENT=@ent)


insert into #Temp
select FAMODEREG2,FATRDATE2,isnull(FAREGL2,0)
from FFA
where (FATRDATE2 is not null or FAREGL2!=0.00)
and FADATE between @datedep and @datefin
and (@ent is null or FAENT=@ent)


insert into #Temp
select FAMODEREG3,FATRDATE3,isnull(FAREGL3,0)
from FFA
where (FATRDATE3 is not null or FAREGL3!=0.00)
and FADATE between @datedep and @datefin
and (@ent is null or FAENT=@ent)


insert into #Temp
select FAMODEREG4,FATRDATE4,isnull(FAREGL4,0)
from FFA
where (FATRDATE4 is not null or FAREGL4!=0.00)
and FADATE between @datedep and @datefin
and (@ent is null or FAENT=@ent)


select ModeR,EcheanceM=datepart(mm,Echeance),
EcheanceA=datepart(yy,Echeance),Montant=sum(Montant)
into #FA
from #Temp
group by ModeR,datepart(yy,Echeance),datepart(mm,Echeance)

drop table #Temp


create table #Final
(
Mode	tinyint,
mois1	numeric(14,2)	null,
mois2	numeric(14,2)	null,
mois3	numeric(14,2)	null,
mois4	numeric(14,2)	null,
mois5	numeric(14,2)	null,
mois6	numeric(14,2)	null,
mois7	numeric(14,2)	null,
mois8	numeric(14,2)	null,
mois9	numeric(14,2)	null,
mois10	numeric(14,2)	null,
Total	numeric(14,2)	null
)

insert into #Final(Mode,mois1)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,@datedep)
	and EcheanceA=datepart(yy,@datedep)
group by ModeR

insert into #Final(Mode,mois2)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,1,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,1,@datedep))
group by ModeR

insert into #Final(Mode,mois3)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,2,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,2,@datedep))
group by ModeR
			
insert into #Final(Mode,mois4)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,3,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,3,@datedep))
group by ModeR

insert into #Final(Mode,mois5)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,4,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,4,@datedep))
group by ModeR

insert into #Final(Mode,mois6)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,5,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,5,@datedep))
group by ModeR

insert into #Final(Mode,mois7)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,6,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,6,@datedep))
group by ModeR

insert into #Final(Mode,mois8)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,7,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,7,@datedep))
group by ModeR

insert into #Final(Mode,mois9)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,8,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,8,@datedep))
group by ModeR

insert into #Final(Mode,mois10)
select ModeR,sum(Montant)
from #FA
	where EcheanceM=datepart(mm,dateadd(mm,9,@datedep))
	and EcheanceA=datepart(yy,dateadd(mm,9,@datedep))
group by ModeR


drop table #FA


select Mode,mois1=sum(isnull(mois1,0)),mois2=sum(isnull(mois2,0)),mois3=sum(isnull(mois3,0)),
			mois4=sum(isnull(mois4,0)),mois5=sum(isnull(mois5,0)),mois6=sum(isnull(mois6,0)),
			mois7=sum(isnull(mois7,0)),mois8=sum(isnull(mois8,0)),mois9=sum(isnull(mois9,0)),
			mois10=sum(isnull(mois10,0)),Total=convert(numeric(14,2),0)
into #Final2
from #Final
group by Mode

drop table #Final


update #Final2
set Total= mois1 + mois2 + mois3 + mois4 + mois5 + mois6
		 + mois7 + mois8 + mois9 + mois10



select 'Mode Reglem.','Total TTC',
convert(varchar(2),datepart(mm,@datedep))+'/'+convert(varchar(4),datepart(yy,@datedep)),
convert(varchar(2),datepart(mm,dateadd(mm,1,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,1,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,2,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,2,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,3,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,3,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,4,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,4,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,5,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,5,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,6,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,6,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,7,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,7,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,8,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,8,@datedep))),
convert(varchar(2),datepart(mm,dateadd(mm,9,@datedep)))+'/'+convert(varchar(4),datepart(yy,dateadd(mm,9,@datedep)))


select MRLIB,Total,mois1,mois2,mois3,mois4,mois5,mois6,mois7,mois8,mois9,mois10
from #Final2, FMR
where Mode=MRCODE
order by Mode
compute sum(Total),sum(mois1),sum(mois2),sum(mois3),sum(mois4),sum(mois5),sum(mois6),
sum(mois7),sum(mois8),sum(mois9),sum(mois10)


drop table #Final2

end



go

