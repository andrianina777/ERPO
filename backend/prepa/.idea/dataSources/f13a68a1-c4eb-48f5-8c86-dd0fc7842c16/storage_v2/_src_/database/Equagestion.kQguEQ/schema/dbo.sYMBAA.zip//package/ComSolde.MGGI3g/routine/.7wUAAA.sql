





/* Procedure donnant la liste des lignes de commandes clients non facturees
appartenant a des commandes entierement livrees avec lignes de BE correspondantes */
create procedure ComSolde (@ent	char(5) = null)
with recompile
as
begin
create table #Bel
(
Client		char(12)	not null,
LienCode	char(10)	not null,
LienNum		int			not null,
BECode		char(10)	not null,
BENum		int			not null
)
create table #Cdes
(
Code	char(10)	not null
)
insert into #Bel (Client,LienCode,LienNum,BECode,BENum)
select BELCL,BELLIENCODE,BELLIENNUM,BELCODE,BELNUM
from FBEL, FRBE
where RBESEQ=BELSEQ
and RBEDEMO = 0
and BELLIENCODE like 'CC%'
and (@ent is null or (BELENT=@ent and RBEENT=@ent))
insert into #Cdes (Code)
select distinct LienCode
from #Bel
order by LienCode
select distinct incomplet=Code
into #Inc
from #Cdes,FCCL,FRCC,FCC
where RCCSEQ=CCLSEQ
and Code=CCLCODE
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@ent is null or (CCLENT=@ent and RCCENT=@ent and CCENT=@ent))
delete #Bel
from #Inc
where incomplet=LienCode
select Client,LienCode,LienNum,BECode,BENum
from #Bel
order by LienCode,LienNum
drop table #Inc
drop table #Cdes
drop table #Bel
end



go

