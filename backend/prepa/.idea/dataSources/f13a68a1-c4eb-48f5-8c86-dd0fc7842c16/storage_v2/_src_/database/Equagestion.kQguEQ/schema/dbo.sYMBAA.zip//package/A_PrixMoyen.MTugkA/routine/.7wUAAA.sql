


/* Procedure generant le prix moyen UNITAIRE a partir des lignes de
	Bordereau de livraisons fournisseur les plus recentes */

create procedure A_PrixMoyen
with recompile
as
begin

set arithabort numeric_truncation off


create table #AR
(
code	char(15)	not null,
date	datetime	not null
)

create table #PR
(
code	char(15)	not null,
prix	numeric(14,2)	null,
UA		tinyint		not null
)

create table #Final
(
code	char(15)	not null,
prix	numeric(14,2)	null
)


insert into #AR (code,date)
select BLLAR,max(BLLDATE)
from FBLL
group by BLLAR

create unique clustered index article on #AR (code)

insert into #PR (code,prix,UA)
select BLLAR,avg(BLLPRHT),BLLUA
from FBLL,#AR
where BLLAR=code
and BLLDATE=date
group by BLLAR,BLLUA

drop table #AR

create unique clustered index article on #PR (code)

insert into #Final (code,prix)
select code,prix/CVLOT
from #PR,FCV
where UA=CVUNIF

drop table #PR

create unique clustered index article on #Final (code)


update FAR
set ARPRM=prix
from #Final
where ARCODE=code

drop table #Final

end

go

