



create procedure Ports (@ent	char(5) = null, 
						@an		smallint,
						@type 	tinyint = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @labase		varchar(30),
		@lignes		int
		
select  @labase = db_name()
select 	@lignes = 0

create table #CA
(
flot		char(10)			not null,
jan			numeric(14,2)			null,
fev			numeric(14,2)			null,
mar			numeric(14,2)			null,
avr			numeric(14,2)			null,
mai			numeric(14,2)			null,
jun			numeric(14,2)			null,
jul			numeric(14,2)			null,
aou			numeric(14,2)			null,
sep			numeric(14,2)			null,
oct			numeric(14,2)			null,
nov			numeric(14,2)			null,
dec			numeric(14,2)			null
)


insert into #CA (flot,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
select 'Recettes',0,0,0,0,0,0,0,0,0,0,0,0

insert into #CA (flot,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
select 'Frais',0,0,0,0,0,0,0,0,0,0,0,0
 

if @type is null
begin
  insert into #CA (flot,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
  select 'Recettes',
		  isnull(sum(case when STMOIS=1 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=2 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=3 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=4 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=5 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=6 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=7 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=8 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=9 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=10 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=11 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=12 then STCAFA else 0 end),0)
  from FST,FAR
  where START=ARCODE
  and STAN = @an
  and ARTYPE in (3,7)
  and (@ent is null or STENT=@ent)
end
else
begin
  insert into #CA (flot,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
  select 'Recettes',
		  isnull(sum(case when STMOIS=1 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=2 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=3 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=4 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=5 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=6 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=7 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=8 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=9 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=10 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=11 then STCAFA else 0 end),0),
		  isnull(sum(case when STMOIS=12 then STCAFA else 0 end),0)
  from FST,FAR
  where START=ARCODE
  and STAN = @an
  and ARTYPE=@type
  and (@ent is null or STENT=@ent)
end



insert into #CA (flot,jan,fev,mar,avr,mai,jun,jul,aou,sep,oct,nov,dec)
select 'Frais',
		isnull(sum(case when datepart(mm,EXDATE)=1 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=2 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=3 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=4 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=5 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=6 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=7 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=8 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=9 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=10 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=11 then EXTOTALTR else 0 end),0),
		isnull(sum(case when datepart(mm,EXDATE)=12 then EXTOTALTR else 0 end),0)
from FEX
where datepart(yy,EXDATE) = @an
and (@ent is null or EXENT=@ent)



select flot,
		sum(jan),sum(fev),sum(mar),
		sum(avr),sum(mai),sum(jun),
		sum(jul),sum(aou),sum(sep),
		sum(oct),sum(nov),sum(dec)
from #CA
group by flot
order by flot

drop table #CA


end



go

