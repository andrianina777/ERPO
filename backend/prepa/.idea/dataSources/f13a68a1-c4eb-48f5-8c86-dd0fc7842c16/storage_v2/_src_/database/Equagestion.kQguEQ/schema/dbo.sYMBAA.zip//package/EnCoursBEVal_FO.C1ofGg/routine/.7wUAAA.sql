


create procedure EnCoursBEVal_FO (@ent		char(5) = null,
								@client 	char(12) = null,
								@depart		char(8) = null,
								@fourn		char(12) = null,
								@grfam		char(8) = null,
								@famille	char(8) = null,
								@articleBE	char(15) = null,
								@produits	smallint = null,
								@prodnsto	smallint = null,
								@services	smallint = null,
								@ports		smallint = null,
								@comments	smallint = null,
								@remises	smallint = null,
								@rfa		smallint = null,
								@assur		smallint = null,
								@chef		char(8) = null,
								@modevalo	tinyint = 0,
								@classe		smallint = null
							  )
with recompile
as
begin


declare @type	tinyint

if (@produits is not null) or (@prodnsto is not null) or 
	(@services is not null) or (@ports is not null) or
	(@comments is not null) or (@remises is not null) or
	(@rfa is not null) or (@assur is not null)
select @type = 1
else
select @type = 0


create table #Bel
(
rbedemo		tinyint			not null,
rbearticle	char(15)		not null,
bellettre	char(4)			not null,		
rbeqte		int				not null,
rbeval		numeric(14,2)	not null,
rbevaldemo	numeric(14,2)	not null,
rbedate		smalldatetime	not null,
cvlot		int				not null,
seq			numeric(14,0)	identity
)


insert into #Bel (rbedemo,rbearticle,bellettre,rbeqte,rbeval,rbevaldemo,rbedate,cvlot)
select RBEDEMO,RBEARTICLE,BELLETTRE,RBEQTE*sign(BELQTE),0,0,dateadd(hh,19,BELDATE),CVLOT
from FRBE,FBEL,FAR,FCV,FSTOCK
where (@ent is null or (BELENT=@ent and RBEENT=@ent))
and BELSEQ=RBESEQ 
and ARCODE=RBEARTICLE
and ARUNITACHAT=CVUNIF
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and ARTYPE != 8
and (@type = 0 or ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur))
and (@client is null or RBECL=@client)
and (@depart is null or ARDEPART=@depart)
and (@fourn is null or STFO=@fourn)
and (@grfam is null or ARGRFAM=@grfam)
and (@famille is null or ARFAM=@famille)
and (@articleBE is null or ARCODE=@articleBE)
and (@chef is null or ARCHEFP=@chef)
and (@classe is null or exists (select * from FCL,FTBGC where FRBE.RBECL=CLCODE and TBGCCLASSE=CLCLASSE))



create index seq on #Bel (seq)
  
  
declare @seq			int,
		@article		char(15),
		@qte			int,
		@prixrevient	numeric(14,4),
		@cvlot			int,
		@lettre			char(4),
		@date			datetime,
		@demo			tinyint
			
  declare rbe cursor
  for
  select seq,rbedemo,rbearticle,bellettre,rbeqte,rbedate,cvlot
  from #Bel
  where rbeqte != 0
  order by rbearticle
  for read only

  open rbe
  
  fetch rbe
  into @seq,@demo,@article,@lettre,@qte,@date,@cvlot
  
  while (@@sqlstatus = 0)
	 begin
	 
	 	select @prixrevient = 0
	 
	   if @modevalo=0
	   begin
	   
		select @prixrevient = convert(numeric(14,4),(STPAHT+STFRAIS)/@cvlot) from FSTOCK
		where STAR = @article
		and STLETTRE = @lettre

		if @prixrevient is null
			select @prixrevient = 0
	   end
	   else if @modevalo=1
	   begin
		   
		   select @prixrevient = ARPRM from FAR where ARCODE = @article
		   
		   if @prixrevient is null
			   select @prixrevient = 0
	   end
	   else if @modevalo=2
	   begin
		   
		   select @prixrevient = PUMP
		   from FPUM
		   where PUMAR = @article
		   and PUMDATE <= convert (smalldatetime, @date)
		   having PUMAR = @article
		   and PUMDATE <= convert (smalldatetime, @date)
		   and PUMDATE = max(PUMDATE)
		   
		   if @prixrevient is null
			   select @prixrevient = 0
	   end
	   else if @modevalo=3
	   begin
		   
		   set rowcount 1
		   
		   select @prixrevient = PRM
		   from FPRM
		   where PRMAR = @article
		   and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		   order by PRMAN desc,PRMMOIS desc
		   
		   set rowcount 0
		   
		   if @prixrevient is null
			   select @prixrevient = 0
	   end
	   else if @modevalo=4
	   begin
		   
		   select @prixrevient = convert(numeric(14,4),(BLLPAHT+BLLFRAIS)/@cvlot)
		   from FBLL
		   where BLLAR=@article
		   having BLLAR=@article
		   and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		 
		   if isnull(@prixrevient,0)=0
		   begin
			 select @prixrevient = convert(numeric(14,4),(SILPAHT+SILFRAIS)/@cvlot)
			 from FSIL
			 where SILARTICLE=@article
			 having SILARTICLE=@article
			 and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		   end
		   
		   if @prixrevient is null
			   select @prixrevient = 0
	   end
 
 
	   update #Bel
	   set rbeval = (case when @demo = 0 then convert(numeric(14,2),isnull(@prixrevient * @qte,0)) else 0 end),
		   rbevaldemo = (case when @demo = 1 then convert(numeric(14,2),isnull(@prixrevient * @qte,0)) else 0 end)
	   where seq=@seq
 
	   
	  fetch rbe
	  into @seq,@demo,@article,@lettre,@qte,@date,@cvlot
	 
	 end
  
	close rbe
	deallocate cursor rbe

	select sum(rbeval),sum(rbevaldemo)
	from #Bel
	
	drop table #Bel

end



go

