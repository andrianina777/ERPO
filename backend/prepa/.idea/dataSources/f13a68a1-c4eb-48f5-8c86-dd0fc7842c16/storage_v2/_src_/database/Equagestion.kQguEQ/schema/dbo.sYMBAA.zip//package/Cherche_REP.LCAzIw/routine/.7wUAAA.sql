



create procedure Cherche_REP (@ent	char(5)	= null,
							  @rep	char(8))		/* VRP general */
with recompile
as
begin

select "Commandes FCC : ",count(*) from FCC
where CCREPRES=@rep
and (@ent is null or CCENT=@ent)

select "Stats Commandes FSTCC : ",count(*) from FSTCC
where STCCREP=@rep
and (@ent is null or STCCENT=@ent)

select "Factures FFA : ",count(*) from FFA
where FAREP=@rep
and (@ent is null or FAENT=@ent)

select "Lignes Factures FFAL : ",count(*) from FFAL
where FALREP=@rep
and (@ent is null or FALENT=@ent)

select "Commandes FST : ",count(*) from FST
where STREP=@rep
and (@ent is null or STENT=@ent)

select "Clients FCL : ",count(*) from FCL
where CLREP=@rep
and (@ent is null or CLENT=@ent)


end



go

