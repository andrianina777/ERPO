


create procedure BEPrepReliq (	@ent		char(5) = null,
								@Client 	char(12),
						   	  	@Commande	char(10),
								@Depot		char(4) = null,
								@nom		varchar(35) = null,
								@adr1		varchar(50) = null,
								@adr2		varchar(50) = null,
								@cp			varchar(12) = null,
								@ville		varchar(30) = null,
								@py			char(8) = null
							 )
with recompile
as
begin

create table #Stock
(
ArticleCde	char(15)	not null,
QteLoc		int				null,
QteAutre	int				null,
QteDepot	int				null
)

create table #StockDep
(
Article		char(15)	not null,
Qte			int				null,
Depot		char(4)			null,
Emplace		char(8)			null
)

create table #Articles
(
CCLARTICLE	char(15)	not null,
ALivrer		int				null
)

create table #Art
(
CCLARTICLE	char(15)	not null
)

select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,
CCLRESTE,MODELIV=substring(CCMODELIV,1,2),CLNOM1,CCPREP=isnull(CCPREP,0),
CCLQTEPREP=isnull(CCLQTEPREP,0),CCFRANCO=isnull(CCFRANCO,0),
CCFRANCOBE=isnull(CCFRANCOBE,0)
into #Prep
from FCCL,FAR,FCC,FCL,FRCC
where RCCSEQ=CCLSEQ
and RCCDATE <= dateadd(dd,5,getdate())
and RCCARTICLE=ARCODE
and RCCCL=@Client
and RCCCL=CLCODE
and CCLCODE=CCCODE
and CCLCODE!=@Commande
and isnull(CCVALIDE,0)=0
and isnull(CCBEBLOQUE,0)=0
and isnull(CCPREP,0)=0
and (@ent is null or (CCLENT=@ent and CCENT=@ent and CLENT=@ent and RCCENT=@ent))
and (isnull(@nom,"") = "" or CCNOM = @nom)
and (isnull(@adr1,"") = "" or CCADR1 = @adr1)
and (isnull(@adr2,"") = "" or CCADR2 = @adr2)
and (isnull(@cp,"") = "" or CCCP = @cp)
and (isnull(@ville,"") = "" or CCVILLE = @ville)
and (isnull(@py,"") = "" or CCPY = @py)

	
insert into #Art
select CCLARTICLE
from #Prep
group by CCLARTICLE

insert into #Articles
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Art
where RCCARTICLE=CCLARTICLE
and (@ent is null or RCCENT=@ent)
group by RCCARTICLE

create unique index art on #Articles (CCLARTICLE)

drop table #Art


insert into #StockDep (Article,Qte,Depot,Emplace)
select CCLARTICLE,isnull(sum(STEMPQTE),0),isnull(STEMPDEPOT,''),STEMPEMP
from #Articles,FSTEMP,FDP
where STEMPAR=*CCLARTICLE
and DPCODE*=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by CCLARTICLE,STEMPDEPOT,STEMPEMP


create unique index ardep on #StockDep (Article,Depot,Emplace)


if @Depot is null
begin
  insert into #Stock (ArticleCde,QteLoc,QteAutre,QteDepot)
  select Article,sum(case when DPLOC = 1 then Qte else 0 end),
				 sum(case when DPLOC != 1 then Qte else 0 end),
				 sum(case when DPLOC = 1 then Qte else 0 end)
  from #StockDep,FDP
  where Depot*=DPCODE
  group by Article
end
else
begin
  insert into #Stock (ArticleCde,QteLoc,QteAutre,QteDepot)
  select Article,sum(case when Depot = @Depot then Qte else 0 end),
				 sum(case when Depot != @Depot then Qte else 0 end),
				 sum(case when Depot = @Depot then Qte else 0 end)
  from #StockDep
  group by Article
end


create unique index article on #Stock (ArticleCde)


select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,#Prep.CCLARTICLE,CCLLIBRE,
		CCLRESTE,ARLIB,MODELIV,isnull(QteLoc,0),isnull(QteLoc,0)+isnull(QteAutre,0),
		ALivrer,CLNOM1,ARCOMP,ARREFFOUR,ARNUMEROTE,CCLQTEPREP,CCFRANCO,CCFRANCOBE,isnull(QteDepot,0)
from #Prep,#Stock,#Articles,FAR
where #Prep.CCLARTICLE = ARCODE
and #Stock.ArticleCde =ARCODE
and #Articles.CCLARTICLE = ARCODE
and ((isnull(QteLoc,0)+isnull(QteAutre,0) > 0) or (ARTYPE <> 0))
order by CCLCL,CCLCODE,CCLNUM


drop table #Prep
drop table #Articles
drop table #Stock

end



go

