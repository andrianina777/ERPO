


create proc STGF_ClientsGLP (@ent		char(5) = null,
							 @An 		smallint,
							 @depart	tinyint = null,
							 @grfam		tinyint = null,
							 @marque	tinyint = null,
							 @famille	tinyint = null,
							 @chef		tinyint = null,
							 @srfa		tinyint = null
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @modevalo		tinyint
select @modevalo=PMODEVALO from KParam

if (@depart is null) and (@grfam is null) and (@marque is null) and (@famille is null) and (@chef is null)
select @grfam = 1

declare @curyear smallint,@curmonth tinyint,@curday tinyint,@factor float

select 	@curyear=@An,
		@curmonth=datepart(month,getdate()),
		@curday=datepart(day,getdate())

create table #CA
(
AR		char(15)	not null,
AN		smallint	not null,
QteFA	int				null,
CAFA	numeric(14,2)	null,
QteCC	int				null,
CACC	numeric(14,2)	null,
Stock	numeric(14,2)	null
)

create table #CA2
(
Groupe	char(15)	not null,
AN		smallint	not null,
QteFA	int				null,
CAFA	numeric(14,2)	null,
QteCC	int				null,
CACC	numeric(14,2)	null,
Stock	numeric(14,2)	null
)

create table #Stock
(
STAR 				char(15) 		not null,
QTE	 				int 			not null,
ARPRM 				numeric(14,4)	not null,
CVLOT				int				not null,
STPAHT				numeric(14,2)	not null,
STFRAIS				numeric(14,2)	not null,
PrixRevientLigne 	numeric(14,2)	not null,
Seq					numeric(14,0)	identity
)

select @factor=convert(float,@curday)/
	   datepart(day,dateadd(day,-1,dateadd(month,1,convert(datetime,convert(char,@An*10000+@curmonth*100+1)))))

insert into #CA (AR,AN,QteFA,CAFA,QteCC,CACC,Stock)
 select START,STAN,
		sum(case when STAN!=@An and STMOIS=@curmonth then STQTEFA*@factor
				 when STMOIS>@curmonth then 0
				 else STQTEFA
			end),
		sum(case when STAN!=@An and STMOIS=@curmonth then STCAFA*@factor
				 when STMOIS>@curmonth then 0
				 else STCAFA
			end),
		0,0,0
 from FST,FCL,FAR
 where ARCODE=START
 and (@ent is null or STENT=@ent)
 and (@srfa=0 or ARTYPE != 6)
 and STCL=CLCODE and CLCLASSE in (select TBGCCLASSE from FTBGC)
 and STAN between @An-2 and @An
 group by START,STAN
 
 
insert into #CA (AR,AN,QteFA,CAFA,QteCC,CACC,Stock)
 select RCCARTICLE,RCCAN,0,0,
		sum(RCCQTE),round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0
 from FRCC,FCCL,FCC,FCL
 where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
 and CCCLIENT=CLCODE and CLCLASSE in (select TBGCCLASSE from FTBGC)
 and RCCAN between @An-2 and @An
 and CCLSEQ=RCCSEQ
 and CCCODE=CCLCODE
 and isnull(CCVALIDE,0)=0
 group by RCCARTICLE,RCCAN
 
 /*---------------------------------------------------------------------------------------------------------*/

 insert into #Stock (STAR,QTE,ARPRM,CVLOT,STPAHT,STFRAIS,PrixRevientLigne)
 select STAR,isnull(STQTE,0),isnull(ARPRM,0),CVLOT,isnull(STPAHT,0),isnull(STFRAIS,0),0
 from FSTOCK,FAR,FCV,FDP
 where DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
 and ARCODE=STAR
 and ARUNITACHAT=CVUNIF
 and ARTYPE=0
 and STQTE > 0

 create unique index seq on #Stock (Seq)


  declare @date				smalldatetime,
		  @article			char(15),
		  @qte				int,
		  @totalht			numeric(14,2),
		  @cvlot			int,
		  @PrixRevient		numeric(14,4),
		  @PrixRevientLigne	numeric(14,2),
		  @seq				int,
		  @arprm			numeric(14,4),
		  @paht				numeric(14,2),
		  @frais			numeric(14,2)

  select @date=getdate()	
  
  declare stockcurs cursor 
  for select Seq,STAR,QTE,ARPRM,CVLOT,STPAHT,STFRAIS
  from #Stock
  order by Seq
  for read only

 open stockcurs
	
	fetch stockcurs
	into @seq,@article,@qte,@arprm,@cvlot,@paht,@frais
	
	while (@@sqlstatus = 0)

	begin
		select 	@PrixRevient = 0,
				@PrixRevientLigne = 0
		
		if @modevalo = 0										/*--------------------- FIFO */
		begin
		
		  select @PrixRevient = round((@paht+@frais)/@cvlot,4)
		
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		end
		else if @modevalo = 1									/*--------------------- PRM */
		begin
		  select @PrixRevientLigne = convert(numeric(14,2),@arprm * @qte)
		end
		else if @modevalo = 2									/*--------------------- PUMP */
		begin
		  select @PrixRevient=isnull(PUMP,0)
		  from FPUM
		  where PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @date)
		  having PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @date)
		  and PUMDATE = max(PUMDATE)
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		end
		else if @modevalo = 3								/*--------------------- PRM Mensuel */
		begin
		  set rowcount 1
		  
		  select @PrixRevient=isnull(PRM,0)
		  from FPRM
		  where PRMAR = @article
		  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  and PRMAR = @article
		  order by PRMAN desc,PRMMOIS desc
		  
		  set rowcount 0
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
		end
		else  if @modevalo = 4								/*--------------------- DPA unitaire */
		begin
		  set rowcount 1
		
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/@cvlot,4)
		  from FBLL
		  where BLLAR=@article
		  having BLLAR=@article
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		
		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/@cvlot,4)
			from FSIL
			where SILARTICLE=@article
			having SILARTICLE=@article
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end
		  
		  set rowcount 0
		  		  
		  if @PrixRevient is null
		    select @PrixRevient = 0


		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		end

		update #Stock set PrixRevientLigne = @PrixRevientLigne
		where Seq = @seq
	
		
		fetch stockcurs
		into @seq,@article,@qte,@arprm,@cvlot,@paht,@frais
		
	end

	close stockcurs
	deallocate cursor stockcurs


insert into #CA (AR,AN,QteFA,CAFA,QteCC,CACC,Stock)
select STAR,datepart(yy,getdate()),0,0,0,0,PrixRevientLigne
from #Stock

 /*---------------------------------------------------------------------------------------------------------*/
 
create index article on #CA (AR)


if isnull(@depart,0) > 0
begin
  
  insert into #CA2 (Groupe,AN,QteFA,CAFA,QteCC,CACC,Stock)
  select isnull(ARDEPART,''),isnull(AN,datepart(yy,getdate())),sum(QteFA),sum(CAFA),sum(QteCC),sum(CACC),sum(Stock)
  from #CA,FAR
  where ARCODE*=AR
  group by ARDEPART,isnull(AN,datepart(yy,getdate()))
  
  
  select isnull(DTCODE,''),isnull(DTLIB,''),
		 QteFAN2=isnull(sum(QteFA*(1-sign(abs(AN-@An+2)))),0),CAFAN2=isnull(sum(CAFA*(1-sign(abs(AN-@An+2)))),0),
		 QteFAN1=isnull(sum(QteFA*(1-sign(abs(AN-@An+1)))),0),CAFAN1=isnull(sum(CAFA*(1-sign(abs(AN-@An+1)))),0),
		 QteFAN0=isnull(sum(QteFA*(1-sign(abs(AN-@An)))),0),CAFAN0=isnull(sum(CAFA*(1-sign(abs(AN-@An)))),0),
		 QteCAN0=isnull(sum(QteCC),0),CACCN0=isnull(sum(CACC),0),Stock=isnull(sum(Stock),0),2
  from #CA2,FDT
  where DTCODE=*Groupe
  group by DTCODE,DTLIB
  order by DTLIB

end
else if isnull(@grfam,0) > 0
begin  
  
  insert into #CA2 (Groupe,AN,QteFA,CAFA,QteCC,CACC,Stock)
  select isnull(ARGRFAM,''),isnull(AN,datepart(yy,getdate())),sum(QteFA),sum(CAFA),sum(QteCC),sum(CACC),sum(Stock)
  from #CA,FAR
  where ARCODE*=AR
  group by ARGRFAM,isnull(AN,datepart(yy,getdate()))
  
  
  select isnull(GFCODE,''),isnull(GFNOM,''),
		 QteFAN2=isnull(sum(QteFA*(1-sign(abs(AN-@An+2)))),0),CAFAN2=isnull(sum(CAFA*(1-sign(abs(AN-@An+2)))),0),
		 QteFAN1=isnull(sum(QteFA*(1-sign(abs(AN-@An+1)))),0),CAFAN1=isnull(sum(CAFA*(1-sign(abs(AN-@An+1)))),0),
		 QteFAN0=isnull(sum(QteFA*(1-sign(abs(AN-@An)))),0),CAFAN0=isnull(sum(CAFA*(1-sign(abs(AN-@An)))),0),
		 QteCAN0=isnull(sum(QteCC),0),CACCN0=isnull(sum(CACC),0),Stock=isnull(sum(Stock),0),3
  from #CA2,FGF
  where GFCODE=*Groupe
  group by GFCODE,GFNOM
  order by GFNOM

end
else if isnull(@marque,0) > 0
begin
  
  insert into #CA2 (Groupe,AN,QteFA,CAFA,QteCC,CACC,Stock)
  select isnull(ARFO,''),isnull(AN,datepart(yy,getdate())),sum(QteFA),sum(CAFA),sum(QteCC),sum(CACC),sum(Stock)
  from #CA,FAR
  where ARCODE*=AR
  group by ARFO,isnull(AN,datepart(yy,getdate()))
  
  
  select isnull(FOCODE,''),isnull(FONOM,''),
		 QteFAN2=isnull(sum(QteFA*(1-sign(abs(AN-@An+2)))),0),CAFAN2=isnull(sum(CAFA*(1-sign(abs(AN-@An+2)))),0),
		 QteFAN1=isnull(sum(QteFA*(1-sign(abs(AN-@An+1)))),0),CAFAN1=isnull(sum(CAFA*(1-sign(abs(AN-@An+1)))),0),
		 QteFAN0=isnull(sum(QteFA*(1-sign(abs(AN-@An)))),0),CAFAN0=isnull(sum(CAFA*(1-sign(abs(AN-@An)))),0),
		 QteCAN0=isnull(sum(QteCC),0),CACCN0=isnull(sum(CACC),0),Stock=isnull(sum(Stock),0),4
  from #CA2,FFO
  where FOCODE=*Groupe
  group by FOCODE,FONOM
  order by FONOM

end
else if isnull(@famille,0) > 0
begin

  insert into #CA2 (Groupe,AN,QteFA,CAFA,QteCC,CACC,Stock)
  select isnull(ARFAM,''),isnull(AN,datepart(yy,getdate())),sum(QteFA),sum(CAFA),sum(QteCC),sum(CACC),sum(Stock)  
  from #CA,FAR
  where ARCODE*=AR
  group by ARFAM,isnull(AN,datepart(yy,getdate()))
  
  
  select isnull(FPCODE,''),isnull(FPLIB,''),
		 QteFAN2=isnull(sum(QteFA*(1-sign(abs(AN-@An+2)))),0),CAFAN2=isnull(sum(CAFA*(1-sign(abs(AN-@An+2)))),0),
		 QteFAN1=isnull(sum(QteFA*(1-sign(abs(AN-@An+1)))),0),CAFAN1=isnull(sum(CAFA*(1-sign(abs(AN-@An+1)))),0),
		 QteFAN0=isnull(sum(QteFA*(1-sign(abs(AN-@An)))),0),CAFAN0=isnull(sum(CAFA*(1-sign(abs(AN-@An)))),0),
		 QteCAN0=isnull(sum(QteCC),0),CACCN0=isnull(sum(CACC),0),Stock=isnull(sum(Stock),0),5
  from #CA2,FFP
  where FPCODE=*Groupe
  group by FPCODE,FPLIB
  order by FPLIB

end
else if isnull(@chef,0) > 0
begin
  
  insert into #CA2 (Groupe,AN,QteFA,CAFA,QteCC,CACC,Stock)
  select isnull(ARCHEFP,''),isnull(AN,datepart(yy,getdate())),sum(QteFA),sum(CAFA),sum(QteCC),sum(CACC),sum(Stock)
  from #CA,FAR
  where ARCODE*=AR
  group by ARCHEFP,isnull(AN,datepart(yy,getdate()))
  
  
  select isnull(CHCODE,''),isnull(CHNOM,''),
		 QteFAN2=isnull(sum(QteFA*(1-sign(abs(AN-@An+2)))),0),CAFAN2=isnull(sum(CAFA*(1-sign(abs(AN-@An+2)))),0),
		 QteFAN1=isnull(sum(QteFA*(1-sign(abs(AN-@An+1)))),0),CAFAN1=isnull(sum(CAFA*(1-sign(abs(AN-@An+1)))),0),
		 QteFAN0=isnull(sum(QteFA*(1-sign(abs(AN-@An)))),0),CAFAN0=isnull(sum(CAFA*(1-sign(abs(AN-@An)))),0),
		 QteCAN0=isnull(sum(QteCC),0),CACCN0=isnull(sum(CACC),0),Stock=isnull(sum(Stock),0),1
  from #CA2,FCH
  where CHCODE=*Groupe
  group by CHCODE,CHNOM
  order by CHNOM

end



drop table #CA
drop table #CA2
drop table #Stock
	
end



go

