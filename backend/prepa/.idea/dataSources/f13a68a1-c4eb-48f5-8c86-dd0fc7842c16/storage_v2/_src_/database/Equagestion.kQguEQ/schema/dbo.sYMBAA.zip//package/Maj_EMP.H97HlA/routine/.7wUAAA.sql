



create procedure Maj_EMP
with recompile
as
begin

declare @article	char(15),
		@seq		int

declare articles cursor
for select ARCODE from FAR
where not exists (select * from FARE where AREAR=FAR.ARCODE)
for read only

open articles

fetch articles
into @article

while (@@sqlstatus = 0)
begin

	exec eq_GetSeq_proc "FARE",1,@seq output
	
	insert into FARE (ARESEQ,AREEMP,AREAR,ARELIGNE)
	values (@seq,'NONIMP',@article,1)
	
	fetch articles
	into @article
end

close articles
deallocate cursor articles

end



go

