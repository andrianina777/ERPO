


create procedure Bilan (@ent	char(5)	 = null,
						@marque	char(12),
						@date1	datetime = null,
						@date2	datetime = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @datedeb1 smalldatetime,
		@datefin1 smalldatetime,
		@datedeb2 smalldatetime,
		@datefin2 smalldatetime

select @datedeb1=convert(datetime,"01/01/"+convert(char(4),datepart(yy,getdate())))
select @datefin1=convert(datetime,"12/31/"+convert(char(4),datepart(yy,getdate())))
select @datedeb2=convert(datetime,"01/01/"+convert(char(4),datepart(yy,getdate())-1))
select @datefin2=convert(datetime,"12/31/"+convert(char(4),datepart(yy,getdate())-1))


create table #Finale
(
arfo		char(12)	not null,
arfam		char(8)		not null,
arcode		char(8)		not null,
arreffour	char(20)	not null,
arlib		varchar(80)		null,
arprm		numeric(14,2)	null,
belqte_1	int				null,
belqte		int				null,
stock		int				null,
alivrer		int				null,
qteforecast	int				null
)

insert into #Finale (arfo,arfam,arcode,arreffour,arlib,arprm,belqte_1,belqte,stock,alivrer,qteforecast)
select ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM,0,0,0,0,0
from FAR
where ARFO=@marque
and AROLD=0


insert into #Finale (arfo,arfam,arcode,arreffour,arlib,arprm,belqte_1,belqte,stock,alivrer,qteforecast)
select ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM,sum(BELQTE),0,0,0,0
from FAR,FBEL
where ARCODE=BELARTICLE
and ARFO=@marque
and BELDATE between @datedeb2 and @datefin2
and (@ent is null or BELENT=@ent)
group by ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM

insert into #Finale (arfo,arfam,arcode,arreffour,arlib,arprm,belqte_1,belqte,stock,alivrer,qteforecast)
select ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM,0,sum(BELQTE),0,0,0
from FAR,FBEL
where ARCODE=BELARTICLE
and ARFO=@marque
and BELDATE between @datedeb1 and getdate()
and (@ent is null or BELENT=@ent)
group by ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM


insert into #Finale (arfo,arfam,arcode,arreffour,arlib,arprm,belqte_1,belqte,stock,alivrer,qteforecast)
select ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM,0,0,sum(STQTE),0,0
from FAR,FSTOCK,FDP
where ARCODE=STAR
and ARFO=@marque
and STQTE != 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM


insert into #Finale (arfo,arfam,arcode,arreffour,arlib,arprm,belqte_1,belqte,stock,alivrer,qteforecast)
select ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM,0,0,0,sum(RCCQTE),0
from FAR,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and RCCSEQ=CCLSEQ
and CCCODE=CCLCODE
and CCVALIDE=0
and ARFO=@marque
and (@date1 is null or RCCDATE between @date1 and @date2)
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT))
group by ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM


insert into #Finale (arfo,arfam,arcode,arreffour,arlib,arprm,belqte_1,belqte,stock,alivrer,qteforecast)
select ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM,0,0,0,0,sum(CFLQTE)
from FAR,FCFL,FCF
where ARCODE=CFLARTICLE
and CFCODE=CFLCODE
and CFVALIDE=0
and isnull(CFLFORECAST,0)=1
and CFLDATE between @datedeb1 and @datefin1
and ARFO=@marque
and (@ent is null or (CFLENT=@ent and CFENT=CFLENT))
group by ARFO,ARFAM,ARCODE,ARREFFOUR,ARLIB,ARPRM



select Mark=arfo,Fam=arfam,Code=arcode,SKU=arreffour,Description=arlib,MRC=arprm,Expedie_N_1=sum(belqte_1),
	Expedie_N=sum(belqte),Stock=sum(stock),BackOrders=sum(alivrer),Forecast=sum(qteforecast)
from #Finale
group by arfo,arfam,arcode,arreffour,arlib,arprm
order by arfo,arfam,arcode,arreffour


drop table #Finale

end



go

