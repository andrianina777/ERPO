

/* Cette procedure est utilisee par la fenetre ECdes */

create procedure CdesTBCL ( @ent	char(5) = null,
							@client	char(12),		/* Le client peut etre un independant ou un groupe */
							@toutes	tinyint = 0,
							@valide	tinyint = 0,
							@groupe	tinyint = 0
						)
with recompile
as
begin

if @groupe is null select @groupe=0

set arithabort numeric_truncation off


create table #Stock
(
ArticleCde	char(15)	not null,
QteLoc		int				null,
QteAutre	int				null
)

create table #StockDep
(
Article		char(15)	not null,
Qte			int				null,
Depot		char(4)		not null
)

create table #Articles
(
CCLARTICLE		char(15)	not null
)

create table #Final
(
CCLCODE			char(10)	not null,
CCLARTICLE		char(15)	not null,
CCLLIBRE		varchar(255)	null,
ARLIB			varchar(80)		null,
CCLDATE			smalldatetime	null,
CCLRESTE		int				null,
CCLPHT			numeric(14,2)	null,
CCLR1			real			null,
CCLR2			real			null,
CCLR3			real			null,
THT				numeric(14,2)	null,
CCLUNITFACT		tinyint			null,
CCLSEQ			int				null,
CCLNUM			int				null,
CCECHSPE		tinyint			null,
CCFRANCO		tinyint			null,
CCFRANCOBE		tinyint			null,
ARPUB			tinyint			null,
ARTYPE			tinyint			null,
ARCOMP			tinyint			null,
ARREFFOUR		char(40)		null,
CCREFCOMCL		char(15)		null,
CCCOMMENTAIRES	varchar(255)	null,
CCCLIENT		char(12)	not null,
CCNOM			varchar(40)		null,
CCLQTEPREP		int				null
)

if @groupe=0
begin
	if isnull(@toutes,0)=0
	  begin
		insert into #Final (CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,
							CCLPHT,CCLR1,CCLR2,CCLR3,THT,CCLUNITFACT,CCLSEQ,CCLNUM,
							CCECHSPE,CCFRANCO,CCFRANCOBE,ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
							CCCOMMENTAIRES,CCCLIENT,CCNOM,CCLQTEPREP)
		select CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,CCLPHT,CCLR1,CCLR2,CCLR3,
				THT=round((CCLTOTALHT/CCLQTE)*CCLRESTE,2),CCLUNITFACT,CCLSEQ,CCLNUM,CCECHSPE,
				CCFRANCO,isnull(CCFRANCOBE,0),ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
				CCCOMMENTAIRES,CCCLIENT,CCNOM,isnull(CCLQTEPREP,0)
		from FCCL,FAR,FCC,FRCC
		where CCLSEQ=RCCSEQ
		and RCCARTICLE=ARCODE
		and RCCCL=@client
		and CCCODE=CCLCODE
		and isnull(CCVALIDE,0)=@valide
		and datepart(yy,RCCDATE)>=datepart(yy,getdate())-2
		and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	  end
	else if isnull(@toutes,0)=1
	  begin
		insert into #Final (CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,
							CCLPHT,CCLR1,CCLR2,CCLR3,THT,CCLUNITFACT,CCLSEQ,CCLNUM,
							CCECHSPE,CCFRANCO,CCFRANCOBE,ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
							CCCOMMENTAIRES,CCCLIENT,CCNOM,CCLQTEPREP)
		select CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,CCLPHT,CCLR1,CCLR2,CCLR3,
				THT=round((CCLTOTALHT/CCLQTE)*CCLRESTE,2),CCLUNITFACT,CCLSEQ,CCLNUM,CCECHSPE,
				CCFRANCO,isnull(CCFRANCOBE,0),ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
				CCCOMMENTAIRES,CCCLIENT,CCNOM,isnull(CCLQTEPREP,0)
		from FCCL,FAR,FCC,FRCC
		where CCLSEQ=RCCSEQ
		and RCCARTICLE=ARCODE
		and RCCCL=@client
		and CCCODE=CCLCODE
		and isnull(CCVALIDE,0)=@valide
		and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	  end
end
else
begin
	if isnull(@toutes,0)=0
	  begin
		insert into #Final (CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,
							CCLPHT,CCLR1,CCLR2,CCLR3,THT,CCLUNITFACT,CCLSEQ,CCLNUM,
							CCECHSPE,CCFRANCO,CCFRANCOBE,ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
							CCCOMMENTAIRES,CCCLIENT,CCNOM,CCLQTEPREP)
		select CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,CCLPHT,CCLR1,CCLR2,CCLR3,
				THT=round((CCLTOTALHT/CCLQTE)*CCLRESTE,2),CCLUNITFACT,CCLSEQ,CCLNUM,CCECHSPE,
				CCFRANCO,isnull(CCFRANCOBE,0),ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
				CCCOMMENTAIRES,CCCLIENT,CCNOM,isnull(CCLQTEPREP,0)
		from FCCL,FAR,FCC,FRCC,FCL
		where CCLSEQ=RCCSEQ
		and RCCARTICLE=ARCODE
		and CLCODE=CCCLIENT
		and CLCODEGROUPE=@client
		and CCCODE=CCLCODE
		and isnull(CCVALIDE,0)=@valide
		and datepart(yy,RCCDATE)>=datepart(yy,getdate())-2
		and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	  end
	else if isnull(@toutes,0)=1
	  begin
		insert into #Final (CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,
							CCLPHT,CCLR1,CCLR2,CCLR3,THT,CCLUNITFACT,CCLSEQ,CCLNUM,
							CCECHSPE,CCFRANCO,CCFRANCOBE,ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
							CCCOMMENTAIRES,CCCLIENT,CCNOM,CCLQTEPREP)
		select CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,CCLPHT,CCLR1,CCLR2,CCLR3,
				THT=round((CCLTOTALHT/CCLQTE)*CCLRESTE,2),CCLUNITFACT,CCLSEQ,CCLNUM,CCECHSPE,
				CCFRANCO,isnull(CCFRANCOBE,0),ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,
				CCCOMMENTAIRES,CCCLIENT,CCNOM,isnull(CCLQTEPREP,0)
		from FCCL,FAR,FCC,FRCC,FCL
		where CCLSEQ=RCCSEQ
		and RCCARTICLE=ARCODE
		and CLCODE=CCCLIENT
		and CLCODEGROUPE=@client
		and CCCODE=CCLCODE
		and isnull(CCVALIDE,0)=@valide
		and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	  end
end

insert into #Articles
select CCLARTICLE
from #Final
group by CCLARTICLE

create unique index art on #Articles (CCLARTICLE)

insert into #StockDep (Article,Qte,Depot)
select STAR,sum(STQTE),STDEPOT
from #Articles,FSTOCK,FDP
where DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and STAR=CCLARTICLE
group by STAR,STDEPOT

create unique index ardep on #StockDep (Article,Depot)

insert into #Stock (ArticleCde,QteLoc,QteAutre)
select Article,sum(case when DPLOC=1 then Qte else 0 end),sum(case when DPLOC != 1 then Qte else 0 end)
from #StockDep,FDP
where Depot=DPCODE and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by Article

create unique index article on #Stock (ArticleCde)

select CCLCODE,CCLARTICLE,CCLLIBRE,ARLIB,CCLDATE,CCLRESTE,CCLPHT,
	CCLR1,CCLR2,CCLR3,
	THT,CCLUNITFACT,CCLSEQ,CCLNUM,CCECHSPE,CCFRANCO,CCFRANCOBE,QteLoc,QteAutre,
	ARPUB,ARTYPE,ARCOMP,ARREFFOUR,CCREFCOMCL,CCCOMMENTAIRES,CCCLIENT,CCNOM,CCLQTEPREP
from #Final,#Stock
where ArticleCde=*CCLARTICLE
order by CCLARTICLE,CCLDATE

drop table #Articles
drop table #StockDep
drop table #Stock
drop table #Final

end
go

