


create procedure NewFMS
with recompile
as
begin

declare @an		smallint,
		@date	datetime
		
select @an=datepart(yy,getdate())
select @date=convert(datetime,"01/01/"+convert(varchar(4),@an-1))


create table #Far
(
ARCODE	char(15)	null,
CVLOT	int			null
)

insert into #Far
select ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF

create unique clustered index code on #Far (ARCODE)

create table #Far2
(
ARCODE	char(15)	not null,
CVLOT	int				null
)

insert into #Far2
select ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF

create unique clustered index code on #Far2 (ARCODE)




select Article=SILARTICLE,Annee=datepart(yy,SILDATE),Mois=datepart(mm,SILDATE),
Total=sum(SILQTE),PrixRevientTot=sum(round(((SILPAHT+SILFRAIS)/CVLOT),2)*SILQTE),Type='F',
Depot=SILNUMDEP
into #Entree
from FSIL,#Far
where SILARTICLE=ARCODE
and SILDATE >= @date
group by SILARTICLE,datepart(yy,SILDATE),datepart(mm,SILDATE),SILNUMDEP
having sum(SILQTE)!=0


insert into #Entree
select RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),
sum(RJLQTE),sum(round(((RJLPAHT+RJLFRAIS)/CVLOT),2)*RJLQTE),'R',RJLNUMDEP
from FRJL,#Far
where RJLARTICLE=ARCODE
and RJLDATE >= @date
group by RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),RJLNUMDEP
having sum(RJLQTE)!=0


insert into #Entree
select LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),
sum(LCLQTE),sum(round(((LCLPAHT+LCLFRAIS)/CVLOT),2)*LCLQTE),'C',LCLNUMDEP
from FLCL,#Far2
where LCLARTICLE=ARCODE
and LCLDATE >= @date
group by LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),LCLNUMDEP
having sum(LCLQTE)!=0


insert into #Entree
select ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),
sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE),'A',ASLNUMDEP
from FASL,#Far2
where ASLARTICLE=ARCODE
and ASLDATE >= @date
group by ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),ASLNUMDEP
having sum(ASLQTE)!=0


insert into #Entree
select RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),
sum(RMQTE),sum(round(((RMPAHT+RMFRAIS)/CVLOT),2)*RMQTE),'M',RMNUMDEP
from FRM,#Far
where RMARTICLE=ARCODE
and RMDATE >= @date
group by RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),RMNUMDEP
having sum(RMQTE)!=0


insert into #Entree
select BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),
sum(BLLQTE),sum(round(((BLLPRHT)/CVLOT),2)*BLLQTE),'E',BLLNUMDEP
from FBLL,FCV
where BLLUA=CVUNIF
and BLLDATE >= @date
group by BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),BLLNUMDEP
having sum(BLLQTE)!=0


insert into #Entree
select DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),
sum(DOLQTE),sum(round(((DOLPRHT)/CVLOT),2)*DOLQTE),'E',DOLNUMDEP
from FDOL,FCV
where DOLUA=CVUNIF
and DOLDATE >= @date
group by DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),DOLNUMDEP



insert into #Entree
select RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),
-(sum(RFLQTE)),-(sum(round(((RFLPAHT)/CVLOT),2)*RFLQTE)),'E',RFLNUMDEP
from FRFL,FCV
where RFLUNITACHAT=CVUNIF
and RFLDATE >= @date
group by RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),RFLNUMDEP
having sum(RFLQTE)!=0


/*
insert into #Entree
select BELARTICLE,datepart(yy,BELDATE),datepart(mm,BELDATE),
sum(BELQTE),sum(((STPAHT+STFRAIS)/CVLOT)*BELQTE),''B'',1
from FBEL,FSTOCK,#Far
where BELARTICLE=ARCODE
and BELARTICLE=STAR
and BELLETTRE=STLETTRE
and BELDATE >= @date
group by BELARTICLE,datepart(yy,BELDATE),datepart(mm,BELDATE)
having sum(BELQTE)!=0
*/


insert into #Entree
select FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE),
sum(FALQTE),sum(round(((STPAHT+STFRAIS)/CVLOT),2)*FALQTE),'S',1
from FFAL,FSTOCK,#Far
where FALARTICLE=ARCODE
and FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALDATE >= @date
group by FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE)
having sum(FALQTE)!=0


delete from FMS
where MSANNEE >= (@an-1)

drop index FMS.article


insert into FMS(MSARTICLE,MSANNEE,MSMOIS,MSQTE,MSTOTPR,MSTYPE,MSDEPOT)
select Article,Annee,Mois,QteTot=sum(Total),PrixTot=sum(PrixRevientTot),Type,Depot
from #Entree
group by Article,Annee,Mois,Type,Depot
order by Article,Annee,Mois,Type,Depot

drop table #Entree
drop table #Far
drop table #Far2

create unique	clustered index article on FMS (MSARTICLE,MSANNEE,MSMOIS,MSTYPE,MSDEPOT)

end



go

