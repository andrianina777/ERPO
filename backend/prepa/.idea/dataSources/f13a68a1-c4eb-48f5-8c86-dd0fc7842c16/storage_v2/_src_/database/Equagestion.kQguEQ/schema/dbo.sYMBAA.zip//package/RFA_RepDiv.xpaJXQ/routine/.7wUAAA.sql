


/* Calcule la RFA pour chaque representant division - procedure nocturne */

create procedure RFA_RepDiv (@ent	char(5) = null,
							 @an		smallint)
with recompile
as
begin

set arithabort numeric_truncation off

declare @pent			char(5)
select 	@pent=PENT from KParam

declare @client	char(12)
declare @repdiv	char(8)

create table #Finale
(
client          char(12)        not null,
repres		    char(8)			not null,
contrat		    char(10)		not null,
depart          char(8)         not null,
marque          char(12)        not null,
famille         char(8)         not null,
categorie       char(8)         not null,
article         char(15)        not null,
tarif           char(8)         not null,
qte_ct		    int					null,
montant_ct      numeric(14,0)       null,
qte_atteint	    int					null,
montant_atteint	numeric(14,2)		null,
rfa_due		    numeric(14,2)		null,
rfa_pot		    numeric(14,2)		null,
seq			    numeric(14,0)	identity
)


declare clients cursor
for select STCL,STREPDIV
from FST,FCL
where STCL=CLCODE
and isnull(CLSANSRFA,0)=0
and STAN=@an
and (@ent is null or (STENT=@ent and CLENT=@ent))
group by STCL,STREPDIV
for read only

open clients

fetch clients into @client,@repdiv

while (@@sqlstatus = 0)
begin

	 execute RFA_Detail null,@client,@an,2,0,null,@repdiv

	 insert into #Finale (client,repres,contrat,depart,marque,famille,categorie,article,tarif,qte_ct,montant_ct,qte_atteint,montant_atteint,rfa_due,rfa_pot)
	 select CLIENT,@repdiv,CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,QTE_CT,VAL_CT,ATTEINT_QTE,ATTEINT_VAL,RFA_DUE,RFA_POT
	 from FRFATemp
	 where SPID=@@spid
		
	 fetch clients into @client,@repdiv			
end

close clients
deallocate cursor clients

/* Mise a jour de la table des RFA representants division */

update #Finale
set repres = "DIVISION"
where repres = ""

delete FRRP
from FRRP,FREP
where RRPAN=@an
and RRPREP=RECODE
and RETYPE=2
and (@ent is null or RRPENT=@ent)


insert into FRRP (RRPAN,RRPREP,RRPCODE,RRPDEPART,RRPFO,RRPFAM,RRPCATEG,RRPARTICLE,RRPTARIF,RRPQTECT,RRPATTEINT,RRPMONTANT,RRPCAATTEINT,RRPDROIT,RRPPOT,RRPDATE,RRPENT)
select 	@an,repres,contrat,depart,marque,famille,categorie,article,tarif,sum(qte_ct),sum(qte_atteint),sum(montant_ct),sum(montant_atteint),sum(rfa_due),sum(rfa_pot),getdate(),isnull(@ent,@pent)
from #Finale
group by repres,contrat,depart,marque,famille,categorie,article,tarif

drop table #Finale

end

go

