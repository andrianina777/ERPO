


/* Procedure permettant de recuperer les commandes fournisseurs a recevoir sur une annee
	pour un article dans le fichier FRCF  */
	

create procedure A_CdesF (@Article	char(15),
						  @Annee	smallint)
with recompile
as
begin

declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int


select @Janvier=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=1
select @Fevrier=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=2
select @Mars=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=3
select @Avril=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=4
select @Mai=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=5
select @Juin=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=6
select @Juillet=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=7
select @Aout=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=8
select @Septembre=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=9
select @Octobre=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=10
select @Novembre=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=11
select @Decembre=sum(RCFQTE) from FRCF where RCFARTICLE=@Article and RCFAN=@Annee and RCFMOIS=12


select 	isnull(@Janvier,0),isnull(@Fevrier,0),isnull(@Mars,0),
		isnull(@Avril,0),isnull(@Mai,0),isnull(@Juin,0),
		isnull(@Juillet,0),isnull(@Aout,0),isnull(@Septembre,0),
		isnull(@Octobre,0),isnull(@Novembre,0),isnull(@Decembre,0)
end



go

