



create procedure Rech_Pays (@ent	char(5) = null,
							@pays	char(8))
with recompile
as
begin

  select "FCL",CLSEQ,CLCODE,CLPY,CLPAYS
  from FCL
  where CLPY=@pays
  and (@ent is null or CLENT=@ent)
  
  union
  
  select "FFO",FOSEQ,FOCODE,FOPY,FOPAYS
  from FFO
  where FOPY=@pays
  
  union
  
  select "FADR",ADRSEQ,ADRCODELI,ADRPY,ADRPAYS
  from FADR
  where ADRPY=@pays
  and (@ent is null or ADRCODELIENT=@ent)

end



go

