


/* Valide pour le VRP central uniquement */

create procedure RecapRepCL(@ent		char(5)	= null,
							@rep 		char(8),
							@an 		int,
							@moisdeb 	smallint = null,
							@moisfin 	smallint = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @client char(12),
		@sept	numeric(14,2),
		@oct	numeric(14,2)


create table #Prep
(	
client			char(12)		null,
ca				numeric(14,2)	null,
cafiocchi		numeric(14,2)	null,
marge			numeric(14,2)	null,
margefiocchi	numeric(14,2)	null
)

create table #Recap
(
client			char(12)			null,
ville			varchar(30)			null,
ca				numeric(14,2)		null,
cafiocchi		numeric(14,2)		null,
marge			numeric(14,2)		null,
margefiocchi	numeric(14,2)		null,
septembre		numeric(14,2)		null,
octobre			numeric(14,2)		null
)

create table #Detail
(
mois	tinyint		null,
aregler	numeric(14,2)		null
)

create table #Group
(
mois	tinyint		null,
aregler	numeric(14,2)		null
)


insert into #Prep (client,ca,cafiocchi,marge,margefiocchi)
select STCL,sum(STCAFA),0,sum(isnull(STCAFA,0)-isnull(STPR,0)),0
from FST,FAR
where ARCODE=START
and STREP=@rep
and STAN=@an
and (@moisdeb is null or STMOIS between @moisdeb and @moisfin)
and ARGRFAM not in ("FSP","FIC","F22","FLO")
and (@ent is null or STENT=@ent)
group by STCL

insert into #Prep (client,ca,cafiocchi,marge,margefiocchi)
select STCL,0,sum(STCAFA),0,sum(isnull(STCAFA,0)-isnull(STPR,0))
from FST,FAR
where ARCODE=START
and STREP=@rep
and STAN=@an
and (@moisdeb is null or STMOIS between @moisdeb and @moisfin)
and ARGRFAM in ("FSP","FIC","F22","FLO")
and (@ent is null or STENT=@ent)
group by STCL


create index code on #Prep (client)

insert into #Recap (client,ville,ca,cafiocchi,marge,margefiocchi,septembre,octobre)
select CLCODE,CLVILLE,sum(ca),sum(cafiocchi),sum(marge),sum(margefiocchi),0,0
from #Prep,FCL
where CLCODE=client
and (@ent is null or CLENT=@ent)
group by CLCODE,CLVILLE

drop table #Prep


insert into #Recap (client,ville,ca,cafiocchi,marge,margefiocchi,septembre,octobre)
select "_CLTS_","",isnull(sum(ca),0),isnull(sum(cafiocchi),0),
		isnull(sum(marge),0),isnull(sum(margefiocchi),0),0,0
from #Recap
where (ca+cafiocchi) <= 10000.00

create unique clustered index code on #Recap (client)

delete from #Recap
where (ca+cafiocchi) <= 10000.00
and client != "_CLTS_"


declare risque cursor
for select client from #Recap
where client != "_CLTS_"
for update of septembre,octobre

open risque

fetch risque
into @client

while (@@sqlstatus = 0)
begin

	delete from #Detail
	delete from #Group
	select @sept=0, @oct=0
	
	insert into #Detail (mois,aregler)
	select datepart(mm,FATRDATE1),sum(FAREGL1)
	from FFA
	where FACL=@client
	and datepart(yy,FATRDATE1)=@an
	and datepart(mm,FATRDATE1) between 9 and 10
	and (@ent is null or FAENT=@ent)
	group by datepart(mm,FATRDATE1)
	
	insert into #Detail (mois,aregler)
	select datepart(mm,FATRDATE2),sum(FAREGL2)
	from FFA
	where FACL=@client
	and datepart(yy,FATRDATE2)=@an
	and datepart(mm,FATRDATE2) between 9 and 10
	and (@ent is null or FAENT=@ent)
	group by datepart(mm,FATRDATE2)
	
	insert into #Detail (mois,aregler)
	select datepart(mm,FATRDATE3),sum(FAREGL3)
	from FFA
	where FACL=@client
	and datepart(yy,FATRDATE3)=@an
	and datepart(mm,FATRDATE3) between 9 and 10
	and (@ent is null or FAENT=@ent)
	group by datepart(mm,FATRDATE3)
	
	insert into #Group (mois,aregler)
	select mois,sum(aregler)
	from #Detail
	group by mois
	
	select @sept = aregler
	from #Group
	where mois = 9
	
	select @oct = aregler
	from #Group
	where mois = 10
	
/*	print ""client = %1!, septembre = %2!, octobre = %3!"",@client,@sept,@oct */
	
	update #Recap
	set septembre = isnull(@sept,0), octobre = isnull(@oct,0)
	where current of risque
	
	fetch risque
	into @client

end

close risque
deallocate cursor risque

drop table #Detail
drop table #Group

select client,ville,ca,"",
		marge,round((marge*abs(sign(ca)))/(ca+(1-abs(sign(ca)))),2)*100,
		"",cafiocchi,"",
		margefiocchi,round((margefiocchi*abs(sign(cafiocchi)))/(cafiocchi+(1-abs(sign(cafiocchi)))),2)*100,
		"",septembre,octobre
from #Recap
order by client
compute sum(ca),sum(marge),sum(cafiocchi),sum(margefiocchi),sum(septembre),sum(octobre)

drop table #Recap

end



go

