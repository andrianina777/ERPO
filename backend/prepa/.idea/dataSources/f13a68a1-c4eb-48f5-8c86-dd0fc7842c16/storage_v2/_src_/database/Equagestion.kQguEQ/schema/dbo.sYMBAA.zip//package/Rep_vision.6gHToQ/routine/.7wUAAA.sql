


create procedure Rep_vision  (	@ent			char(5) 	= null,
								@moisdeb		tinyint,
							  	@andeb			smallint,
							  	@moisfin		tinyint,
							  	@anfin			smallint,
							  	@rep			char(8) 	= null,
							  	@marque			char(12)	= null
							  )
with recompile
as
begin

set arithabort numeric_truncation off

declare @type		tinyint,
		@division	char(8)

select  @type = 0

if @rep is not null
	select  @type=RETYPE, @division=REDIV from FREP where RECODE=@rep

declare @multient	tinyint

select @multient=KIMULTIENTITE from KInfos


declare @datedeb		smalldatetime,
		@datefin		smalldatetime,
		@MoisSuivant	tinyint,
		@AnneeInit		smallint


select @datedeb=convert(datetime,convert(char(2),@moisdeb)+"/01/"+convert(char(4),@andeb))

if @moisfin=12
  begin
	select @MoisSuivant=1
	select @AnneeInit=@anfin+1
  end
else
  begin
	select @MoisSuivant=@moisfin+1
	select @AnneeInit=@anfin
  end

select @datefin=convert(datetime,convert(char(2),@MoisSuivant)+"/01/"+convert(char(4),@AnneeInit))
select @datefin=dateadd(dd,-1,@datefin)



create table #Final
(
annee			smallint		not null,
mois			tinyint			not null,
rep				char(8)			not null,
marque			char(12)		not null,
cafa			numeric(14,2)		null,
cabe			numeric(14,2)		null,
cdestot			numeric(14,2)		null,
alivrer			numeric(14,2)		null,
repdiv			char(8)			not null
)


/*---- Facturation ----*/

if (@andeb = @anfin)
begin
	
  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select STAN,STMOIS,STREP,ARFO,isnull(sum(STCAFA),0),0,0,0,isnull(STREPDIV,"")
  from FST,FAR
  where (@multient = 0 or (@ent is null or STENT=@ent))
  and START=ARCODE
  and (@type = 2 or @rep is null or STREP=@rep)
  and (@type != 2 or @rep is null or STREPDIV=@rep)
  and (@marque is null or ARFO=@marque)
  and STAN=@andeb
  and STMOIS between @moisdeb and @moisfin
  group by STAN,STMOIS,STREP,ARFO,STREPDIV
		
end
else if (@anfin - @andeb = 1)
begin

  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select STAN,STMOIS,STREP,ARFO,isnull(sum(STCAFA),0),0,0,0,isnull(STREPDIV,"")
  from FST,FAR
  where (@multient = 0 or (@ent is null or STENT=@ent))
  and START=ARCODE
  and (@type = 2 or @rep is null or STREP=@rep)
  and (@type != 2 or @rep is null or STREPDIV=@rep)
  and (@marque is null or ARFO=@marque)
  and ((STAN=@andeb and STMOIS between @moisdeb and 12)
  		or (STAN=@anfin and STMOIS between 1 and @moisfin))
  group by STAN,STMOIS,STREP,ARFO,STREPDIV

end
else if (@anfin - @andeb > 1)
begin

  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select STAN,STMOIS,STREP,ARFO,isnull(sum(STCAFA),0),0,0,0,isnull(STREPDIV,"")
  from FST,FAR
  where (@multient = 0 or (@ent is null or STENT=@ent))
  and START=ARCODE
  and (@type = 2 or @rep is null or STREP=@rep)
  and (@type != 2 or @rep is null or STREPDIV=@rep)
  and (@marque is null or ARFO=@marque)
  and ((STAN=@andeb and STMOIS between @moisdeb and 12)
  		or (STAN between @andeb+1 and @anfin-1)
  		or (STAN=@anfin and STMOIS between 1 and @moisfin))
  group by STAN,STMOIS,STREP,ARFO,STREPDIV

end


/*---- BE ----*/
if @type != 2
begin
  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select datepart(yy,RBEDATE),datepart(mm,RBEDATE),CLREP,ARFO,0,
		  isnull(sum(BELTOTALHT),0),0,0,isnull(CLRREPDIV,"")
  from FRBE,FBEL,FAR,FCL,FCLR
  where (@multient = 0 or (@ent is null or (RBEENT=@ent and BELENT=RBEENT)))
  and RBEARTICLE=ARCODE
  and CLRCL =* CLCODE
  and CLRDIV =* ARDEPART
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and RBESEQ=BELSEQ
  and RBECL=CLCODE
  and RBEDEMO=0
  and RBEDATE between @datedeb and @datefin
  group by datepart(yy,RBEDATE),datepart(mm,RBEDATE),CLREP,ARFO,CLRREPDIV
end
else if @type = 2
begin
  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select datepart(yy,RBEDATE),datepart(mm,RBEDATE),CLREP,ARFO,0,
		  isnull(sum(BELTOTALHT),0),0,0,isnull(CLRREPDIV,"")
  from FRBE,FBEL,FAR,FCL,FCLR
  where (@multient = 0 or (@ent is null or (RBEENT=@ent and BELENT=RBEENT)))
  and RBEARTICLE=ARCODE
  and CLRCL = CLCODE
  and (@rep is null or (CLRREPDIV=@rep and ARDEPART=@division))
  and (@marque is null or ARFO=@marque)
  and RBESEQ=BELSEQ
  and RBECL=CLCODE
  and RBEDEMO=0
  and RBEDATE between @datedeb and @datefin
  group by datepart(yy,RBEDATE),datepart(mm,RBEDATE),CLREP,ARFO,CLRREPDIV
end


/*---- Commandes ----*/

if @andeb = @anfin
begin

  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select STCCAN,STCCMOIS,STCCREP,ARFO,0,0,isnull(sum(STCCCA),0),0,isnull(STCCREPDIV,"")
  from FSTCC,FAR
  where (@multient = 0 or (@ent is null or STCCENT=@ent))
  and STCCART=ARCODE
  and (@type = 2 or @rep is null or STCCREP=@rep)
  and (@type != 2 or @rep is null or STCCREPDIV=@rep)
  and (@marque is null or ARFO=@marque)
  and STCCAN=@andeb
  and STCCMOIS between @moisdeb and @moisfin  
  group by STCCAN,STCCMOIS,STCCREP,ARFO,STCCREPDIV
		
end
else if (@anfin - @andeb = 1)
begin
  
  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select STCCAN,STCCMOIS,STCCREP,ARFO,0,0,isnull(sum(STCCCA),0),0,isnull(STCCREPDIV,"")
  from FSTCC,FAR
  where (@multient = 0 or (@ent is null or STCCENT=@ent))
  and STCCART=ARCODE
  and (@type = 2 or @rep is null or STCCREP=@rep)
  and (@type != 2 or @rep is null or STCCREPDIV=@rep)
  and (@marque is null or ARFO=@marque)
  and ((STCCAN=@andeb and STCCMOIS between @moisdeb and 12) 
  		or (STCCAN=@anfin and STCCMOIS between 1 and @moisfin))
  group by STCCAN,STCCMOIS,STCCREP,ARFO,STCCREPDIV


end
else if (@anfin - @andeb > 1)
begin

  insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
  select STCCAN,STCCMOIS,STCCREP,ARFO,0,0,isnull(sum(STCCCA),0),0,isnull(STCCREPDIV,"")
  from FSTCC,FAR
  where (@multient = 0 or (@ent is null or STCCENT=@ent))
  and STCCART=ARCODE
  and (@type = 2 or @rep is null or STCCREP=@rep)
  and (@type != 2 or @rep is null or STCCREPDIV=@rep)
  and (@marque is null or ARFO=@marque)
  and ((STCCAN=@andeb and STCCMOIS between @moisdeb and 12)
  		or (STCCAN between @andeb+1 and @anfin-1)
  		or (STCCAN=@anfin and STCCMOIS between 1 and @moisfin))
  group by STCCAN,STCCMOIS,STCCREP,ARFO,STCCREPDIV

end


/*---- A livrer ----*/


insert into #Final (annee,mois,rep,marque,cafa,cabe,cdestot,alivrer,repdiv)
select RCCAN,RCCMOIS,CCLREP,ARFO,0,0,0,isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0),isnull(CCLREPDIV,"")
from FRCC,FCCL,FAR,FCC
where (@multient = 0 or (@ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT)))
and RCCARTICLE=ARCODE
and (@type = 2 or @rep is null or CCLREP=@rep)
and (@type != 2 or @rep is null or CCLREPDIV=@rep)
and (@marque is null or ARFO=@marque)
and RCCSEQ=CCLSEQ
and CCCODE=CCLCODE
and RCCDATE between @datedeb and @datefin
group by RCCAN,RCCMOIS,CCLREP,ARFO,CCLREPDIV


/*------- Regroupement et envoi ----------*/


select annee,mois,rep,a.RENOM,repdiv,b.RENOM,marque,cafa=sum(cafa),cabe=sum(cabe),alivrer=sum(alivrer),cdestot=sum(cdestot)
from #Final, FREP a, FREP b
where a.RECODE =* rep
and b.RECODE =* repdiv
group by annee,mois,rep,a.RENOM,repdiv,b.RENOM,marque
order by rep,repdiv,annee,mois,marque


drop table #Final

end



go

