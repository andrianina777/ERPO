


create procedure EquationStock  (@DateTrav 		datetime,
								 @ent			char(5)			= null,
								 @where			varchar(255) 	= null,
								 @lClassestring	varchar(255) 	= null,
								 @lDepotstring	varchar(255) 	= null,
								 @avecCCnonConf	tinyint			= 0,
								 @typeDemande	tinyint			= null
								)
with recompile
as
begin

set arithabort numeric_truncation off

/* Declaration des variables de travail */
/* ************************************ */

declare @string 	varchar(2000)
declare @anneeTrav 	int
declare @moisTrav	tinyint
declare @mois		int
declare @moisE		int
declare @annee		int
declare @i			int

declare @DateFinMoisAvant		datetime
declare @DateFinMois			datetime
declare @DateFinMois1			datetime
declare @DateFinMois2			datetime
declare @DateFinMois3			datetime
declare @DateFinMois4			datetime
declare @DateFinMois5			datetime
declare @DateFinMois6			datetime
declare @DateFinMois7			datetime
declare @DateFinMois8			datetime
declare @DateFinMois9			datetime
declare @DateFinMois10			datetime
declare @DateFinMois11			datetime
declare @DateFinMois12			datetime
declare @DateFinMois13			datetime
declare @DateFinMois14			datetime
declare @DateFinMois15			datetime
declare @DateFinMois16			datetime
declare @DateFinMois17			datetime
declare @DateFinMois18			datetime
declare @DateFinMois19			datetime
declare @DateFinMois20			datetime
declare @DateFinMois21			datetime
declare @DateFinMois22			datetime
declare @DateFinMois23			datetime

select @anneeTrav=datepart(yy,@DateTrav)
select @moisTrav=datepart(mm,@DateTrav)

select @DateFinMoisAvant=dateadd(day,datepart(dd,@DateTrav)*-1,@DateTrav)
select @DateFinMois=dateadd(mm,1,@DateFinMoisAvant)
select @DateFinMois1=dateadd(mm,1,@DateFinMois)
select @DateFinMois2=dateadd(mm,1,@DateFinMois1)
select @DateFinMois3=dateadd(mm,1,@DateFinMois2)
select @DateFinMois4=dateadd(mm,1,@DateFinMois3)
select @DateFinMois5=dateadd(mm,1,@DateFinMois4)
select @DateFinMois6=dateadd(mm,1,@DateFinMois5)
select @DateFinMois7=dateadd(mm,1,@DateFinMois6)
select @DateFinMois8=dateadd(mm,1,@DateFinMois7)
select @DateFinMois9=dateadd(mm,1,@DateFinMois8)
select @DateFinMois10=dateadd(mm,1,@DateFinMois9)
select @DateFinMois11=dateadd(mm,1,@DateFinMois10)
select @DateFinMois12=dateadd(mm,1,@DateFinMois11)
select @DateFinMois13=dateadd(mm,1,@DateFinMois12)
select @DateFinMois14=dateadd(mm,1,@DateFinMois13)
select @DateFinMois15=dateadd(mm,1,@DateFinMois14)
select @DateFinMois16=dateadd(mm,1,@DateFinMois15)
select @DateFinMois17=dateadd(mm,1,@DateFinMois16)
select @DateFinMois18=dateadd(mm,1,@DateFinMois17)
select @DateFinMois19=dateadd(mm,1,@DateFinMois18)
select @DateFinMois20=dateadd(mm,1,@DateFinMois19)
select @DateFinMois21=dateadd(mm,1,@DateFinMois20)
select @DateFinMois22=dateadd(mm,1,@DateFinMois21)
select @DateFinMois23=dateadd(mm,1,@DateFinMois22)

/* Creation de la table des articles selectionnes */
/* ********************************************** */

create table #Tab 
( 
ARCODE		char(15)	not	null
)

/* Creation des tables temporaires necessaires en amont a cause de l''execution de @string */
/* ************************************************************************************** */

create table #SFOLTemp
(
SFOLARTICLE		char(15) 	not null,
SFOLDATE		datetime	not null,
SFOLQTE			int			not null,
Type				tinyint not null /* 0 pour prvisions, 1 pour ventes exceptionnelles, 2 pour regroupement des deux */
)

create table #BEL
(
BELARTICLE		char(15)	not null,
SalesNmoins1	int 			null,
SalesN			int 			null,
SalesMois 		int 			null
)

create table #STOCK
(
STAR			char(15)	not null,
QteStock		int 			null
)

/* 
create table #Final
(

ARCODE					char(15)		not null,
ARREFFOUR				char(20)		not null,
ARLIB					varchar(80)			null,
ARDEPART				char(8)			not null,
ARFO					char(12)		not null,
ARFAM					char(8)			not null,
ARGRFAM					char(8)			not null,
ARCHEFP					char(8)				null,
ARMATIERE				varchar(14)			null,
ARCOULEUR 				char(8)				null,
ARGRILLE				char(10)			null,
ARCALIBRE 				char(14)			null,
ARPRODUIT				char(15)			null,
ARFOREIGN1 				char(12)			null,
ARFOREIGN2				char(12)			null,
ARPRM					numeric(14,4) 		null,
ARSTOCKMINI				int 				null,
SalesNmoins1			int				not null,
ForecastNext12Months	int				not null,
SalesN					int				not null,
CCLQteAvantM			int				not null,
SFOLQteM				int				not null,
BELQteM					int				not null,
RAF						int				not null,
Inventory				int				not null,
CCLQteM					int				not null,
BELSalesMois			int				not null,

CFLQteAvantM			int				not null,
CFLQteM					int				not null,
DALQteAvantM			int				not null,
DALQteM					int				not null,
StockEOM 				int				not null,
CouvertureM 			int				not null,

SFOLQteMPLUS1			int				not null,
CCLQteMPLUS1			int				not null,
CFLQteMPLUS1			int				not null,
DALQteMPLUS1			int				not null,
StockEOM1 				int				not null,
CouvertureMPLUS1		int				not null,

SFOLQteMPLUS2			int				not null,
CCLQteMPLUS2			int				not null,
CFLQteMPLUS2			int				not null,
DALQteMPLUS2			int				not null,
StockEOM2 				int				not null,
CouvertureMPLUS2		int				not null,

SFOLQteMPLUS3			int				not null,
CCLQteMPLUS3			int				not null,
CFLQteMPLUS3			int				not null,
DALQteMPLUS3			int				not null,
StockEOM3 				int				not null,
CouvertureMPLUS3		int				not null,

SFOLQteMPLUS4			int				not null,
CCLQteMPLUS4			int				not null,
CFLQteMPLUS4			int				not null,
DALQteMPLUS4			int				not null,
StockEOM4 				int				not null,
CouvertureMPLUS4		int				not null,

SFOLQteMPLUS5			int				not null,
CCLQteMPLUS5			int				not null,
CFLQteMPLUS5			int				not null,
DALQteMPLUS5			int				not null,
StockEOM5 				int				not null,
CouvertureMPLUS5		int				not null,

SFOLQteMPLUS6			int				not null,
CCLQteMPLUS6			int				not null,
CFLQteMPLUS6			int				not null,
DALQteMPLUS6			int				not null,
StockEOM6 				int				not null,
CouvertureMPLUS6		int				not null,

SFOLQteMPLUS7			int				not null,
CCLQteMPLUS7			int				not null,
CFLQteMPLUS7			int				not null,
DALQteMPLUS7			int				not null,
StockEOM7				int				not null,
CouvertureMPLUS7		int				not null,

SFOLQteMPLUS8			int				not null,
CCLQteMPLUS8			int				not null,
CFLQteMPLUS8			int				not null,
DALQteMPLUS8			int				not null,
StockEOM8 				int				not null,
CouvertureMPLUS8		int				not null,

SFOLQteMPLUS9			int				not null,
CCLQteMPLUS9			int				not null,
CFLQteMPLUS9			int				not null,
DALQteMPLUS9			int				not null,
StockEOM9				int				not null,
CouvertureMPLUS9		int				not null,

SFOLQteMPLUS10			int				not null,
CCLQteMPLUS10			int				not null,
CFLQteMPLUS10			int				not null,
DALQteMPLUS10			int				not null,
StockEOM10				int				not null,
CouvertureMPLUS10		int				not null,

SFOLQteMPLUS11			int				not null,
CCLQteMPLUS11			int				not null,
CFLQteMPLUS11			int				not null,
DALQteMPLUS11			int				not null,
StockEOM11 				int				not null,
CouvertureMPLUS11		int				not null,

SFOLQteMPLUS12			int				not null,
CCLQteMPLUS12			int				not null,
CFLQteMPLUS12			int				not null,
DALQteMPLUS12			int				not null,
StockEOM12 				int				not null,
CouvertureMPLUS12		int				not null,

SFOLQteMPLUS13			int				not null,
CCLQteMPLUS13			int				not null,
CFLQteMPLUS13			int				not null,
DALQteMPLUS13			int				not null,
StockEOM13 				int				not null,
CouvertureMPLUS13		int				not null,

SFOLQteMPLUS14			int				not null,
CCLQteMPLUS14			int				not null,
CFLQteMPLUS14			int				not null,
DALQteMPLUS14			int				not null,
StockEOM14 				int				not null,
CouvertureMPLUS14		int				not null,

SFOLQteMPLUS15			int				not null,
CCLQteMPLUS15			int				not null,
CFLQteMPLUS15			int				not null,
DALQteMPLUS15			int				not null,
StockEOM15 				int				not null,
CouvertureMPLUS15		int				not null,

SFOLQteMPLUS16			int				not null,
CCLQteMPLUS16			int				not null,
CFLQteMPLUS16			int				not null,
DALQteMPLUS16			int				not null,
StockEOM16 				int				not null,
CouvertureMPLUS16		int				not null,

SFOLQteMPLUS17			int				not null,
CCLQteMPLUS17			int				not null,
CFLQteMPLUS17			int				not null,
DALQteMPLUS17			int				not null,
StockEOM17 				int				not null,
CouvertureMPLUS17		int				not null,

SFOLQteMPLUS18			int				not null,
CCLQteMPLUS18			int				not null,
CFLQteMPLUS18			int				not null,
DALQteMPLUS18			int				not null,
StockEOM18 				int				not null,
CouvertureMPLUS18		int				not null,

SFOLQteMPLUS19			int				not null,
CCLQteMPLUS19			int				not null,
CFLQteMPLUS19			int				not null,
DALQteMPLUS19			int				not null,
StockEOM19 				int				not null,
CouvertureMPLUS19		int				not null,

SFOLQteMPLUS20			int				not null,
CCLQteMPLUS20			int				not null,
CFLQteMPLUS20			int				not null,
DALQteMPLUS20			int				not null,
StockEOM20 				int				not null,
CouvertureMPLUS20		int				not null,

SFOLQteMPLUS21			int				not null,
CCLQteMPLUS21			int				not null,
CFLQteMPLUS21			int				not null,
DALQteMPLUS21			int				not null,
StockEOM21 				int				not null,
CouvertureMPLUS21		int				not null,

SFOLQteMPLUS22			int				not null,
CCLQteMPLUS22			int				not null,
CFLQteMPLUS22			int				not null,
DALQteMPLUS22			int				not null,
StockEOM22 				int				not null,
CouvertureMPLUS22		int				not null,

SFOLQteMPLUS23			int				not null,
CCLQteMPLUS23			int				not null,
CFLQteMPLUS23			int				not null,
DALQteMPLUS23			int				not null,
StockEOM23 				int				not null,
CouvertureMPLUS23		int				not null

)

*/

/* 1.Selection des articles concernes */
/* ********************************** */ 

select @string="
	insert into #Tab (ARCODE) 
	select ARCODE from FAR where "+@where+" order by ARCODE"
execute (@string)

	
create unique index art	on #Tab (ARCODE) 

/* 2.Selection des previsions de ventes des 12 prochains mois */ 
/* ********************************************************** */

select @mois=@moisTrav
select @moisE=@moisTrav
select @annee=@anneeTrav

select @i=1

while @i<=24
begin

	select @string="insert into #SFOLTemp
		select 	SFOLCODE,'"+convert(varchar(4),@annee)+"/"+convert(varchar(2),@mois)+"/15"+"',SFOLN"+convert(varchar(2),@mois)+",0
		from #Tab,FSFOL,FSFO where (ARCODE=SFOLCODE) and (SFOVERSION=SFOLVERSION and SFOANNEE=SFOLANNEE) 
		and SFOACTIVE=1 and SFOLANNEE="+convert(varchar(4),@annee)
	execute (@string)
	
	select @string="insert into #SFOLTemp
		select 	SFOECODE,'"+convert(varchar(4),@annee)+"/"+convert(varchar(2),@mois)+"/15"+"',"+(case when @moisE<=12 then "SFOEN" else "SFOENPLUS1" end)+convert(varchar(2),@mois)+",1
		from #Tab,FSFOE where (ARCODE=SFOECODE)"  
	execute (@string)

	select @moisE=@moisE+1
	select @mois=@mois+1
	if @mois=13
	begin
		select @annee=@annee+1
		select @mois=1
	end
	
	select @i=@i+1
	
end

/* On regroupe les prvisions et les Ventes exceptionnelles avant mise  jour de #SFOL */
insert into #SFOLTemp 
select SFOLARTICLE,SFOLDATE,sum(SFOLQTE),2 from #SFOLTemp group by SFOLARTICLE,SFOLDATE
delete from #SFOLTemp where Type!=2

select SFOLARTICLE,
	QteAvantM=isnull(sum(case when SFOLDATE<=@DateFinMoisAvant and datepart(yy,SFOLDATE)=@anneeTrav then SFOLQTE else 0 end),0),
					QteM     =isnull(sum(case when SFOLDATE>@DateFinMoisAvant and SFOLDATE<=@DateFinMois  then SFOLQTE else 0 end),0),
					QteMPLUS1=isnull(sum(case when SFOLDATE>@DateFinMois      and SFOLDATE<=@DateFinMois1 then SFOLQTE else 0 end),0),
					QteMPLUS2=isnull(sum(case when SFOLDATE>@DateFinMois1     and SFOLDATE<=@DateFinMois2 then SFOLQTE else 0 end),0),
					QteMPLUS3=isnull(sum(case when SFOLDATE>@DateFinMois2     and SFOLDATE<=@DateFinMois3 then SFOLQTE else 0 end),0),
					QteMPLUS4=isnull(sum(case when SFOLDATE>@DateFinMois3     and SFOLDATE<=@DateFinMois4 then SFOLQTE else 0 end),0),
					QteMPLUS5=isnull(sum(case when SFOLDATE>@DateFinMois4     and SFOLDATE<=@DateFinMois5 then SFOLQTE else 0 end),0),
					QteMPLUS6=isnull(sum(case when SFOLDATE>@DateFinMois5     and SFOLDATE<=@DateFinMois6 then SFOLQTE else 0 end),0),
					QteMPLUS7=isnull(sum(case when SFOLDATE>@DateFinMois6     and SFOLDATE<=@DateFinMois7 then SFOLQTE else 0 end),0),
					QteMPLUS8=isnull(sum(case when SFOLDATE>@DateFinMois7     and SFOLDATE<=@DateFinMois8 then SFOLQTE else 0 end),0),
					QteMPLUS9=isnull(sum(case when SFOLDATE>@DateFinMois8     and SFOLDATE<=@DateFinMois9 then SFOLQTE else 0 end),0),
					QteMPLUS10=isnull(sum(case when SFOLDATE>@DateFinMois9    and SFOLDATE<=@DateFinMois10 then SFOLQTE else 0 end),0),
					QteMPLUS11=isnull(sum(case when SFOLDATE>@DateFinMois10   and SFOLDATE<=@DateFinMois11 then SFOLQTE else 0 end),0),						
					QteMPLUS12=isnull(sum(case when SFOLDATE>@DateFinMois11   and SFOLDATE<=@DateFinMois12 then SFOLQTE else 0 end),0),	
					QteMPLUS13=isnull(sum(case when SFOLDATE>@DateFinMois12   and SFOLDATE<=@DateFinMois13 then SFOLQTE else 0 end),0),	
					QteMPLUS14=isnull(sum(case when SFOLDATE>@DateFinMois13   and SFOLDATE<=@DateFinMois14 then SFOLQTE else 0 end),0),		
					QteMPLUS15=isnull(sum(case when SFOLDATE>@DateFinMois14   and SFOLDATE<=@DateFinMois15 then SFOLQTE else 0 end),0),	
					QteMPLUS16=isnull(sum(case when SFOLDATE>@DateFinMois15   and SFOLDATE<=@DateFinMois16 then SFOLQTE else 0 end),0),	
					QteMPLUS17=isnull(sum(case when SFOLDATE>@DateFinMois16   and SFOLDATE<=@DateFinMois17 then SFOLQTE else 0 end),0),											
					QteMPLUS18=isnull(sum(case when SFOLDATE>@DateFinMois17   and SFOLDATE<=@DateFinMois18 then SFOLQTE else 0 end),0),	
					QteMPLUS19=isnull(sum(case when SFOLDATE>@DateFinMois18   and SFOLDATE<=@DateFinMois19 then SFOLQTE else 0 end),0),	
					QteMPLUS20=isnull(sum(case when SFOLDATE>@DateFinMois19   and SFOLDATE<=@DateFinMois20 then SFOLQTE else 0 end),0),	
					QteMPLUS21=isnull(sum(case when SFOLDATE>@DateFinMois20   and SFOLDATE<=@DateFinMois21 then SFOLQTE else 0 end),0),		
					QteMPLUS22=isnull(sum(case when SFOLDATE>@DateFinMois21   and SFOLDATE<=@DateFinMois22 then SFOLQTE else 0 end),0),	
					QteMPLUS23=isnull(sum(case when SFOLDATE>@DateFinMois22   and SFOLDATE<=@DateFinMois23 then SFOLQTE else 0 end),0),
					SFOLQTEAN=convert(int,0)																															
into #SFOL
from #SFOLTemp
group by SFOLARTICLE

/* On met  jour la prevision annuelle */

update #SFOL set #SFOL.SFOLQTEAN=FSFOL.SFOLQTEAN 
from FSFOL,FSFO 
where (#SFOL.SFOLARTICLE=SFOLCODE) and (SFOVERSION=SFOLVERSION and SFOANNEE=SFOLANNEE) 
and SFOACTIVE=1 and SFOLANNEE=@anneeTrav

create unique index art	on #SFOL (SFOLARTICLE)


/* 3. Recherche des Ventes (sorties Basees sur les BE) */
/* *************************************************** */

select @string="
	insert into #BEL 
	select 	BELARTICLE,
			isnull(sum(case when datepart(yy,BELDATE)="+convert(varchar(4),@anneeTrav)+"-1 then BELQTE else 0 end),0),
			isnull(sum(case when datepart(yy,BELDATE)="+convert(varchar(4),@anneeTrav)+" and datepart(mm,BELDATE)<"+convert(varchar(2),@moisTrav)+" then BELQTE else 0 end),0),
			isnull(sum(case when datepart(yy,BELDATE)="+convert(varchar(4),@anneeTrav)+" and datepart(mm,BELDATE)>="+convert(varchar(2),@moisTrav)+" then BELQTE else 0 end),0)
	from FBEL,#Tab where BELARTICLE=ARCODE
	and exists (select * from FCL where CLCODE=FBEL.BELCL and CLCLASSE in "+@lClassestring+") 
	and (('"+@ent+"' is null or '"+@ent+"'='') or BELENT='"+@ent+"') group by BELARTICLE"

execute (@string)

create unique index code on #BEL (BELARTICLE)

/* 4. Selection du Stock */
/* ********************* */

select @string="
insert into #STOCK 
select 	STAR,isnull(sum(STQTE),0) 
from FSTOCK,#Tab where STAR=ARCODE
and STDEPOT in "+@lDepotstring+" group by STAR"
execute (@string)


create unique index code on #STOCK (STAR)

/* 5. Selection des commandes clients */ 
/* ********************************** */
  
select CCLARTICLE,
	QteAvantM=isnull(sum(case when RCCDATE<=@DateFinMoisAvant then RCCQTE else 0 end),0),
					QteM     =isnull(sum(case when RCCDATE>@DateFinMoisAvant and RCCDATE<=@DateFinMois  then RCCQTE else 0 end),0),
					QteMPLUS1=isnull(sum(case when RCCDATE>@DateFinMois      and RCCDATE<=@DateFinMois1 then RCCQTE else 0 end),0),
					QteMPLUS2=isnull(sum(case when RCCDATE>@DateFinMois1     and RCCDATE<=@DateFinMois2 then RCCQTE else 0 end),0),
					QteMPLUS3=isnull(sum(case when RCCDATE>@DateFinMois2     and RCCDATE<=@DateFinMois3 then RCCQTE else 0 end),0),
					QteMPLUS4=isnull(sum(case when RCCDATE>@DateFinMois3     and RCCDATE<=@DateFinMois4 then RCCQTE else 0 end),0),
					QteMPLUS5=isnull(sum(case when RCCDATE>@DateFinMois4     and RCCDATE<=@DateFinMois5 then RCCQTE else 0 end),0),
					QteMPLUS6=isnull(sum(case when RCCDATE>@DateFinMois5     and RCCDATE<=@DateFinMois6 then RCCQTE else 0 end),0),
					QteMPLUS7=isnull(sum(case when RCCDATE>@DateFinMois6     and RCCDATE<=@DateFinMois7 then RCCQTE else 0 end),0),
					QteMPLUS8=isnull(sum(case when RCCDATE>@DateFinMois7     and RCCDATE<=@DateFinMois8 then RCCQTE else 0 end),0),
					QteMPLUS9=isnull(sum(case when RCCDATE>@DateFinMois8     and RCCDATE<=@DateFinMois9 then RCCQTE else 0 end),0),
					QteMPLUS10=isnull(sum(case when RCCDATE>@DateFinMois9    and RCCDATE<=@DateFinMois10 then RCCQTE else 0 end),0),
					QteMPLUS11=isnull(sum(case when RCCDATE>@DateFinMois10   and RCCDATE<=@DateFinMois11 then RCCQTE else 0 end),0),
					QteMPLUS12=isnull(sum(case when RCCDATE>@DateFinMois11   and RCCDATE<=@DateFinMois12 then RCCQTE else 0 end),0),	
					QteMPLUS13=isnull(sum(case when RCCDATE>@DateFinMois12   and RCCDATE<=@DateFinMois13 then RCCQTE else 0 end),0),	
					QteMPLUS14=isnull(sum(case when RCCDATE>@DateFinMois13   and RCCDATE<=@DateFinMois14 then RCCQTE else 0 end),0),		
					QteMPLUS15=isnull(sum(case when RCCDATE>@DateFinMois14   and RCCDATE<=@DateFinMois15 then RCCQTE else 0 end),0),	
					QteMPLUS16=isnull(sum(case when RCCDATE>@DateFinMois15   and RCCDATE<=@DateFinMois16 then RCCQTE else 0 end),0),	
					QteMPLUS17=isnull(sum(case when RCCDATE>@DateFinMois16   and RCCDATE<=@DateFinMois17 then RCCQTE else 0 end),0),											
					QteMPLUS18=isnull(sum(case when RCCDATE>@DateFinMois17   and RCCDATE<=@DateFinMois18 then RCCQTE else 0 end),0),	
					QteMPLUS19=isnull(sum(case when RCCDATE>@DateFinMois18   and RCCDATE<=@DateFinMois19 then RCCQTE else 0 end),0),	
					QteMPLUS20=isnull(sum(case when RCCDATE>@DateFinMois19   and RCCDATE<=@DateFinMois20 then RCCQTE else 0 end),0),	
					QteMPLUS21=isnull(sum(case when RCCDATE>@DateFinMois20   and RCCDATE<=@DateFinMois21 then RCCQTE else 0 end),0),		
					QteMPLUS22=isnull(sum(case when RCCDATE>@DateFinMois21   and RCCDATE<=@DateFinMois22 then RCCQTE else 0 end),0),	
					QteMPLUS23=isnull(sum(case when RCCDATE>@DateFinMois22   and RCCDATE<=@DateFinMois23 then RCCQTE else 0 end),0)																												
into #CCL 
from #Tab,FRCC,FCC,FCCL 
where (RCCARTICLE=ARCODE) 
and (CCLSEQ=RCCSEQ) 
and (CCCODE=CCLCODE) 
and (@avecCCnonConf = 1 or isnull(CCVALIDE,0)=0)
and (@ent is null or (RCCENT=@ent and CCENT=@ent and CCLENT=@ent)) 
group by CCLARTICLE

create unique index code	on #CCL (CCLARTICLE)
 
/* 6.Selection des demandes Fournisseurs */ 
/* ************************************* */

 select DALARTICLE,
 	QteAvantM=isnull(sum(case when RDADATE<=@DateFinMoisAvant 													then RDAQTE else 0 end),0),
					QteM     =isnull(sum(case when RDADATE>@DateFinMoisAvant and RDADATE<=@DateFinMois  then RDAQTE else 0 end),0),
					QteMPLUS1=isnull(sum(case when RDADATE>@DateFinMois      and RDADATE<=@DateFinMois1 then RDAQTE else 0 end),0),
					QteMPLUS2=isnull(sum(case when RDADATE>@DateFinMois1     and RDADATE<=@DateFinMois2 then RDAQTE else 0 end),0),
					QteMPLUS3=isnull(sum(case when RDADATE>@DateFinMois2     and RDADATE<=@DateFinMois3 then RDAQTE else 0 end),0),
					QteMPLUS4=isnull(sum(case when RDADATE>@DateFinMois3     and RDADATE<=@DateFinMois4 then RDAQTE else 0 end),0),
					QteMPLUS5=isnull(sum(case when RDADATE>@DateFinMois4     and RDADATE<=@DateFinMois5 then RDAQTE else 0 end),0),
					QteMPLUS6=isnull(sum(case when RDADATE>@DateFinMois5     and RDADATE<=@DateFinMois6 then RDAQTE else 0 end),0),
					QteMPLUS7=isnull(sum(case when RDADATE>@DateFinMois6     and RDADATE<=@DateFinMois7 then RDAQTE else 0 end),0),
					QteMPLUS8=isnull(sum(case when RDADATE>@DateFinMois7     and RDADATE<=@DateFinMois8 then RDAQTE else 0 end),0),
					QteMPLUS9=isnull(sum(case when RDADATE>@DateFinMois8     and RDADATE<=@DateFinMois9 then RDAQTE else 0 end),0),
					QteMPLUS10=isnull(sum(case when RDADATE>@DateFinMois9    and RDADATE<=@DateFinMois10 then RDAQTE else 0 end),0),
					QteMPLUS11=isnull(sum(case when RDADATE>@DateFinMois10   and RDADATE<=@DateFinMois11 then RDAQTE else 0 end),0),
					QteMPLUS12=isnull(sum(case when RDADATE>@DateFinMois11   and RDADATE<=@DateFinMois12 then RDAQTE else 0 end),0),	
					QteMPLUS13=isnull(sum(case when RDADATE>@DateFinMois12   and RDADATE<=@DateFinMois13 then RDAQTE else 0 end),0),	
					QteMPLUS14=isnull(sum(case when RDADATE>@DateFinMois13   and RDADATE<=@DateFinMois14 then RDAQTE else 0 end),0),		
					QteMPLUS15=isnull(sum(case when RDADATE>@DateFinMois14   and RDADATE<=@DateFinMois15 then RDAQTE else 0 end),0),	
					QteMPLUS16=isnull(sum(case when RDADATE>@DateFinMois15   and RDADATE<=@DateFinMois16 then RDAQTE else 0 end),0),	
					QteMPLUS17=isnull(sum(case when RDADATE>@DateFinMois16   and RDADATE<=@DateFinMois17 then RDAQTE else 0 end),0),											
					QteMPLUS18=isnull(sum(case when RDADATE>@DateFinMois17   and RDADATE<=@DateFinMois18 then RDAQTE else 0 end),0),	
					QteMPLUS19=isnull(sum(case when RDADATE>@DateFinMois18   and RDADATE<=@DateFinMois19 then RDAQTE else 0 end),0),	
					QteMPLUS20=isnull(sum(case when RDADATE>@DateFinMois19   and RDADATE<=@DateFinMois20 then RDAQTE else 0 end),0),	
					QteMPLUS21=isnull(sum(case when RDADATE>@DateFinMois20   and RDADATE<=@DateFinMois21 then RDAQTE else 0 end),0),		
					QteMPLUS22=isnull(sum(case when RDADATE>@DateFinMois21   and RDADATE<=@DateFinMois22 then RDAQTE else 0 end),0),	
					QteMPLUS23=isnull(sum(case when RDADATE>@DateFinMois22   and RDADATE<=@DateFinMois23 then RDAQTE else 0 end),0)																											
into #DAL 
from #Tab,FRDA,FDA,FDAL 
where (RDAARTICLE=ARCODE) 
and (DALSEQ=RDASEQ) 
and (DACODE=DALCODE) 
and RDADATE<=@DateFinMois23 
and (@ent is null or (RDAENT=@ent and DAENT=@ent and DALENT=@ent)) 
and (@typeDemande=2 or isnull(DASTATUS,0)=@typeDemande) 
group by DALARTICLE 

create unique index code	on #DAL (DALARTICLE)
	  
 
/* 7. Selection des commandes Fournisseurs (avec les non confirmees) */ 
/* ***************************************************************** */

 select CFLARTICLE,
 	QteAvantM=isnull(sum(case when RCFDATE<=@DateFinMoisAvant 													then RCFQTE else 0 end),0),
					QteM     =isnull(sum(case when RCFDATE>@DateFinMoisAvant and RCFDATE<=@DateFinMois  then RCFQTE else 0 end),0),
					QteMPLUS1=isnull(sum(case when RCFDATE>@DateFinMois      and RCFDATE<=@DateFinMois1 then RCFQTE else 0 end),0),
					QteMPLUS2=isnull(sum(case when RCFDATE>@DateFinMois1     and RCFDATE<=@DateFinMois2 then RCFQTE else 0 end),0),
					QteMPLUS3=isnull(sum(case when RCFDATE>@DateFinMois2     and RCFDATE<=@DateFinMois3 then RCFQTE else 0 end),0),
					QteMPLUS4=isnull(sum(case when RCFDATE>@DateFinMois3     and RCFDATE<=@DateFinMois4 then RCFQTE else 0 end),0),
					QteMPLUS5=isnull(sum(case when RCFDATE>@DateFinMois4     and RCFDATE<=@DateFinMois5 then RCFQTE else 0 end),0),
					QteMPLUS6=isnull(sum(case when RCFDATE>@DateFinMois5     and RCFDATE<=@DateFinMois6 then RCFQTE else 0 end),0),
					QteMPLUS7=isnull(sum(case when RCFDATE>@DateFinMois6     and RCFDATE<=@DateFinMois7 then RCFQTE else 0 end),0),
					QteMPLUS8=isnull(sum(case when RCFDATE>@DateFinMois7     and RCFDATE<=@DateFinMois8 then RCFQTE else 0 end),0),
					QteMPLUS9=isnull(sum(case when RCFDATE>@DateFinMois8     and RCFDATE<=@DateFinMois9 then RCFQTE else 0 end),0),
					QteMPLUS10=isnull(sum(case when RCFDATE>@DateFinMois9    and RCFDATE<=@DateFinMois10 then RCFQTE else 0 end),0),
					QteMPLUS11=isnull(sum(case when RCFDATE>@DateFinMois10   and RCFDATE<=@DateFinMois11 then RCFQTE else 0 end),0),
					QteMPLUS12=isnull(sum(case when RCFDATE>@DateFinMois11   and RCFDATE<=@DateFinMois12 then RCFQTE else 0 end),0),	
					QteMPLUS13=isnull(sum(case when RCFDATE>@DateFinMois12   and RCFDATE<=@DateFinMois13 then RCFQTE else 0 end),0),	
					QteMPLUS14=isnull(sum(case when RCFDATE>@DateFinMois13   and RCFDATE<=@DateFinMois14 then RCFQTE else 0 end),0),		
					QteMPLUS15=isnull(sum(case when RCFDATE>@DateFinMois14   and RCFDATE<=@DateFinMois15 then RCFQTE else 0 end),0),	
					QteMPLUS16=isnull(sum(case when RCFDATE>@DateFinMois15   and RCFDATE<=@DateFinMois16 then RCFQTE else 0 end),0),	
					QteMPLUS17=isnull(sum(case when RCFDATE>@DateFinMois16   and RCFDATE<=@DateFinMois17 then RCFQTE else 0 end),0),											
					QteMPLUS18=isnull(sum(case when RCFDATE>@DateFinMois17   and RCFDATE<=@DateFinMois18 then RCFQTE else 0 end),0),	
					QteMPLUS19=isnull(sum(case when RCFDATE>@DateFinMois18   and RCFDATE<=@DateFinMois19 then RCFQTE else 0 end),0),	
					QteMPLUS20=isnull(sum(case when RCFDATE>@DateFinMois19   and RCFDATE<=@DateFinMois20 then RCFQTE else 0 end),0),	
					QteMPLUS21=isnull(sum(case when RCFDATE>@DateFinMois20   and RCFDATE<=@DateFinMois21 then RCFQTE else 0 end),0),		
					QteMPLUS22=isnull(sum(case when RCFDATE>@DateFinMois21   and RCFDATE<=@DateFinMois22 then RCFQTE else 0 end),0),	
					QteMPLUS23=isnull(sum(case when RCFDATE>@DateFinMois22   and RCFDATE<=@DateFinMois23 then RCFQTE else 0 end),0)																											
into #CFL 
from #Tab,FRCF,FCFL 
where (RCFARTICLE=ARCODE) 
and (CFLSEQ=RCFSEQ) 
and RCFDATE<=@DateFinMois23 
and (@ent is null or (RCFENT=@ent and CFLENT=@ent)) 
group by CFLARTICLE 

create unique index code	on #CFL (CFLARTICLE)

/* Renvoi du select Final */
/* ********************** */

select

/* rubriques articles */
#Tab.ARCODE,ARREFFOUR,ARLIB,ARDEPART,ARFO,ARFAM,ARGRFAM,ARCHEFP,ARMATIERE,ARCOULEUR,ARGRILLE,ARCALIBRE,ARPRODUIT,ARFOREIGN1,ARFOREIGN2,ARPRM,ARSTOCKMINI,

/* rubriques generiques */
BEL_SalesNmoins1=isnull(#BEL.SalesNmoins1,0),
/* SFOL_Next_12Months=isnull(#SFOL.QteM+#SFOL.QteMPLUS1+#SFOL.QteMPLUS2+#SFOL.QteMPLUS3+#SFOL.QteMPLUS4+#SFOL.QteMPLUS5+#SFOL.QteMPLUS6+#SFOL.QteMPLUS7+#SFOL.QteMPLUS8+#SFOL.QteMPLUS9+#SFOL.QteMPLUS10+#SFOL.QteMPLUS11,0),*/
SFOL_QteAn=isnull(#SFOL.SFOLQTEAN,0),
BEL_SalesN=isnull(#BEL.SalesN,0),
CCL_QteAvantM=isnull(#CCL.QteAvantM,0),	

/* Donnees du mois M : Nota =>  */
SFOL_QteM=isnull(#SFOL.QteM,0),
BEL_SalesMois=isnull(#BEL.SalesMois,0),
RAF=isnull(#SFOL.QteM,0)-isnull(#BEL.SalesMois,0),
STOCK_QteStock=isnull(#STOCK.QteStock,0),
CCL_QteM=isnull(#CCL.QteM,0),
CFL_Past=isnull(#CFL.QteM+#CFL.QteAvantM,0),
DAL_QteAvantM=isnull(#DAL.QteAvantM,0),
DAL_QteM=isnull(#DAL.QteM,0),
/* #STOCK.QteStock+(#CFL.QteAvantM,#CFL.QteM,#DAL.QteAvantM,#DAL.QteM)-(case when @TypeCalcul=0 then #CCL.QteAvantM+#CCL.QteM else (case when @TypeCalcul=1 then #SFOL.QteM-#BEL.QteM else (case when #SFOL.QteM-#BEL.QteM>#CCL.QteAvantM+#CCL.QteM then #SFOL.QteM-#BEL.QteM else #CCL.QteAvantM+#CCL.QteM end) end) end) */
StEOM=0,CoverageEOM=convert(numeric(14,2),0),

/* Donnees du mois M+1 et suivants */
SFOL_QteMPLUS1=isnull(#SFOL.QteMPLUS1,0),CCL_QteMPLUS1=isnull(#CCL.QteMPLUS1,0),CFL_QteMPLUS1=isnull(#CFL.QteMPLUS1,0),DAL_QteMPLUS1=isnull(#DAL.QteMPLUS1,0),StEOM1=0,CoverageEOM1=convert(numeric(14,2),0),
SFOL_QteMPLUS2=isnull(#SFOL.QteMPLUS2,0),CCL_QteMPLUS2=isnull(#CCL.QteMPLUS2,0),CFL_QteMPLUS2=isnull(#CFL.QteMPLUS2,0),DAL_QteMPLUS2=isnull(#DAL.QteMPLUS2,0),StEOM2=0,CoverageEOM2=convert(numeric(14,2),0),
SFOL_QteMPLUS3=isnull(#SFOL.QteMPLUS3,0),CCL_QteMPLUS3=isnull(#CCL.QteMPLUS3,0),CFL_QteMPLUS3=isnull(#CFL.QteMPLUS3,0),DAL_QteMPLUS3=isnull(#DAL.QteMPLUS3,0),StEOM3=0,CoverageEOM3=convert(numeric(14,2),0),
SFOL_QteMPLUS4=isnull(#SFOL.QteMPLUS4,0),CCL_QteMPLUS4=isnull(#CCL.QteMPLUS4,0),CFL_QteMPLUS4=isnull(#CFL.QteMPLUS4,0),DAL_QteMPLUS4=isnull(#DAL.QteMPLUS4,0),StEOM4=0,CoverageEOM4=convert(numeric(14,2),0),
SFOL_QteMPLUS5=isnull(#SFOL.QteMPLUS5,0),CCL_QteMPLUS5=isnull(#CCL.QteMPLUS5,0),CFL_QteMPLUS5=isnull(#CFL.QteMPLUS5,0),DAL_QteMPLUS5=isnull(#DAL.QteMPLUS5,0),StEOM5=0,CoverageEOM5=convert(numeric(14,2),0),
SFOL_QteMPLUS6=isnull(#SFOL.QteMPLUS6,0),CCL_QteMPLUS6=isnull(#CCL.QteMPLUS6,0),CFL_QteMPLUS6=isnull(#CFL.QteMPLUS6,0),DAL_QteMPLUS6=isnull(#DAL.QteMPLUS6,0),StEOM6=0,CoverageEOM6=convert(numeric(14,2),0),
SFOL_QteMPLUS7=isnull(#SFOL.QteMPLUS7,0),CCL_QteMPLUS7=isnull(#CCL.QteMPLUS7,0),CFL_QteMPLUS7=isnull(#CFL.QteMPLUS7,0),DAL_QteMPLUS7=isnull(#DAL.QteMPLUS7,0),StEOM7=0,CoverageEOM7=convert(numeric(14,2),0),
SFOL_QteMPLUS8=isnull(#SFOL.QteMPLUS8,0),CCL_QteMPLUS8=isnull(#CCL.QteMPLUS8,0),CFL_QteMPLUS8=isnull(#CFL.QteMPLUS8,0),DAL_QteMPLUS8=isnull(#DAL.QteMPLUS8,0),StEOM8=0,CoverageEOM8=convert(numeric(14,2),0),
SFOL_QteMPLUS9=isnull(#SFOL.QteMPLUS9,0),CCL_QteMPLUS9=isnull(#CCL.QteMPLUS9,0),CFL_QteMPLUS9=isnull(#CFL.QteMPLUS9,0),DAL_QteMPLUS9=isnull(#DAL.QteMPLUS9,0),StEOM9=0,CoverageEOM9=convert(numeric(14,2),0),
SFOL_QteMPLUS10=isnull(#SFOL.QteMPLUS10,0),CCL_QteMPLUS10=isnull(#CCL.QteMPLUS10,0),CFL_QteMPLUS10=isnull(#CFL.QteMPLUS10,0),DAL_QteMPLUS10=isnull(#DAL.QteMPLUS10,0),StEOM10=0,CoverageEOM10=convert(numeric(14,2),0),
SFOL_QteMPLUS11=isnull(#SFOL.QteMPLUS11,0),CCL_QteMPLUS11=isnull(#CCL.QteMPLUS11,0),CFL_QteMPLUS11=isnull(#CFL.QteMPLUS11,0),DAL_QteMPLUS11=isnull(#DAL.QteMPLUS11,0),StEOM11=0,CoverageEOM11=convert(numeric(14,2),0),
SFOL_QteMPLUS12=isnull(#SFOL.QteMPLUS12,0),CCL_QteMPLUS12=isnull(#CCL.QteMPLUS12,0),CFL_QteMPLUS12=isnull(#CFL.QteMPLUS12,0),DAL_QteMPLUS12=isnull(#DAL.QteMPLUS12,0),StEOM12=0,CoverageEOM12=convert(numeric(14,2),0),
SFOL_QteMPLUS13=isnull(#SFOL.QteMPLUS13,0),CCL_QteMPLUS13=isnull(#CCL.QteMPLUS13,0),CFL_QteMPLUS13=isnull(#CFL.QteMPLUS13,0),DAL_QteMPLUS13=isnull(#DAL.QteMPLUS13,0),StEOM13=0,CoverageEOM13=convert(numeric(14,2),0),
SFOL_QteMPLUS14=isnull(#SFOL.QteMPLUS14,0),CCL_QteMPLUS14=isnull(#CCL.QteMPLUS14,0),CFL_QteMPLUS14=isnull(#CFL.QteMPLUS14,0),DAL_QteMPLUS14=isnull(#DAL.QteMPLUS14,0),StEOM14=0,CoverageEOM14=convert(numeric(14,2),0),
SFOL_QteMPLUS15=isnull(#SFOL.QteMPLUS15,0),CCL_QteMPLUS15=isnull(#CCL.QteMPLUS15,0),CFL_QteMPLUS15=isnull(#CFL.QteMPLUS15,0),DAL_QteMPLUS15=isnull(#DAL.QteMPLUS15,0),StEOM15=0,CoverageEOM15=convert(numeric(14,2),0),
SFOL_QteMPLUS16=isnull(#SFOL.QteMPLUS16,0),CCL_QteMPLUS16=isnull(#CCL.QteMPLUS16,0),CFL_QteMPLUS16=isnull(#CFL.QteMPLUS16,0),DAL_QteMPLUS16=isnull(#DAL.QteMPLUS16,0),StEOM16=0,CoverageEOM16=convert(numeric(14,2),0),
SFOL_QteMPLUS17=isnull(#SFOL.QteMPLUS17,0),CCL_QteMPLUS17=isnull(#CCL.QteMPLUS17,0),CFL_QteMPLUS17=isnull(#CFL.QteMPLUS17,0),DAL_QteMPLUS17=isnull(#DAL.QteMPLUS17,0),StEOM17=0,CoverageEOM17=convert(numeric(14,2),0),
SFOL_QteMPLUS18=isnull(#SFOL.QteMPLUS18,0),CCL_QteMPLUS18=isnull(#CCL.QteMPLUS18,0),CFL_QteMPLUS18=isnull(#CFL.QteMPLUS18,0),DAL_QteMPLUS18=isnull(#DAL.QteMPLUS18,0),StEOM18=0,CoverageEOM18=convert(numeric(14,2),0),
SFOL_QteMPLUS19=isnull(#SFOL.QteMPLUS19,0),CCL_QteMPLUS19=isnull(#CCL.QteMPLUS19,0),CFL_QteMPLUS19=isnull(#CFL.QteMPLUS19,0),DAL_QteMPLUS19=isnull(#DAL.QteMPLUS19,0),StEOM19=0,CoverageEOM19=convert(numeric(14,2),0),
SFOL_QteMPLUS20=isnull(#SFOL.QteMPLUS20,0),CCL_QteMPLUS20=isnull(#CCL.QteMPLUS20,0),CFL_QteMPLUS20=isnull(#CFL.QteMPLUS20,0),DAL_QteMPLUS20=isnull(#DAL.QteMPLUS20,0),StEOM20=0,CoverageEOM20=convert(numeric(14,2),0),
SFOL_QteMPLUS21=isnull(#SFOL.QteMPLUS21,0),CCL_QteMPLUS21=isnull(#CCL.QteMPLUS21,0),CFL_QteMPLUS21=isnull(#CFL.QteMPLUS21,0),DAL_QteMPLUS21=isnull(#DAL.QteMPLUS21,0),StEOM21=0,CoverageEOM21=convert(numeric(14,2),0),
SFOL_QteMPLUS22=isnull(#SFOL.QteMPLUS22,0),CCL_QteMPLUS22=isnull(#CCL.QteMPLUS22,0),CFL_QteMPLUS22=isnull(#CFL.QteMPLUS22,0),DAL_QteMPLUS22=isnull(#DAL.QteMPLUS22,0),StEOM22=0,CoverageEOM22=convert(numeric(14,2),0),
SFOL_QteMPLUS23=isnull(#SFOL.QteMPLUS23,0),CCL_QteMPLUS23=isnull(#CCL.QteMPLUS23,0),CFL_QteMPLUS23=isnull(#CFL.QteMPLUS23,0),DAL_QteMPLUS23=isnull(#DAL.QteMPLUS23,0),StEOM23=0,CoverageEOM23=convert(numeric(14,2),0)

/* NB : on prend la decision de calculer le Stock End Of Month et la couverture dans le code Omnis */

from #Tab,FAR,#BEL,#SFOL,#CCL,#CFL,#STOCK,#DAL
where (#Tab.ARCODE=FAR.ARCODE) and (#Tab.ARCODE*=#BEL.BELARTICLE) and (#Tab.ARCODE*=#SFOL.SFOLARTICLE) and (#Tab.ARCODE*=#CCL.CCLARTICLE) and (#Tab.ARCODE*=#CFL.CFLARTICLE) and (#Tab.ARCODE*=#DAL.DALARTICLE) and (#Tab.ARCODE*=#STOCK.STAR)
order by ARCODE

drop table #SFOLTemp
drop table #SFOL
drop table #CCL
drop table #BEL
drop table #STOCK
drop table #CFL
drop table #DAL
																														
end

go

