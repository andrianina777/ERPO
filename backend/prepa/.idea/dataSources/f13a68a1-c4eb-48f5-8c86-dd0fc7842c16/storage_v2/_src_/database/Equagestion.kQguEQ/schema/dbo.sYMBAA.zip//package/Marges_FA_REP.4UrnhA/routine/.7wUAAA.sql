


/* Procedure renvoyant les lignes de FA avec la marge par REP sedentaire */

create procedure Marges_FA_REP (@ent	char(5) 	  = null,
							 	@rep	numeric(14,2) = null,	/* ??? */
							 	@an		smallint	  = null
						    	)
with recompile
as
begin

set arithabort numeric_truncation off

declare	@mois	tinyint,
		@date1	smalldatetime,
		@date2	smalldatetime
		
if @an is null
	select  @an = datepart(yy,getdate()),
			@mois = datepart(mm,getdate())
else
	select  @mois = datepart(mm,getdate())

		
select @date1=convert(smalldatetime,"01/01/"+convert(varchar,@an))
select @date2=convert(smalldatetime,"12/31/"+convert(varchar,@an))


create table #FA
(
Rep				char(10)		not null,
Date			smalldatetime	not null,
Article			char(15)		not null,
Quantite		int				not null,
Valeur_Vente	numeric(14,2)	not null,
Marge_Val		numeric(14,2)	not null,
ID				numeric(14,0)	identity
)


insert into #FA (Rep,Date,Article,Quantite,Valeur_Vente,Marge_Val)
select CLREP,dateadd(hh,19,FALDATE),FALARTICLE,FALQTE,FALTOTALHT,0
from FFAL,FAR,FCL
where ARCODE=FALARTICLE
and CLCODE=FALCL
and FALDATE between @date1 and @date2
and ARTYPE=0
and FALLETTRE != ""
and (@ent is null or (FALENT=@ent and CLENT=@ent))


declare factures cursor 
for select ID,Date,Article,Quantite,Valeur_Vente
from #FA
for update of Marge_Val

declare @seq			numeric(14,0),
		@date			smalldatetime,
		@article		char(15),
		@qte			int,
		@totalht		numeric(14,2),
		@PrixRevient	numeric(14,4)

open factures

fetch factures
into @seq,@date,@article,@qte,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @PrixRevient=isnull(PUMP,0)
	from FPUM
	where PUMAR = @article
	and PUMDATE <= @date
	having PUMAR = @article
	and PUMDATE <= @date
	and PUMDATE = max(PUMDATE)
	
	if @PrixRevient is null
		select @PrixRevient=0
	
	if @totalht = 0
	begin
		update #FA set Marge_Val=-(@PrixRevient*@qte)
		where current of factures	
	end
	else if @PrixRevient != 0
	begin
		update #FA set Marge_Val=@totalht-(@PrixRevient*@qte)
		where current of factures	
	end
	else
	begin
		update #FA set Marge_Val=@totalht
		where current of factures
	end
	
	
	fetch factures
	into @seq,@date,@article,@qte,@totalht
	
end

close factures
deallocate cursor factures

insert into #FA (Rep,Date,Article,Quantite,Valeur_Vente,Marge_Val)
select CLREP,dateadd(hh,19,FALDATE),FALARTICLE,0,FALTOTALHT,FALTOTALHT
from FFAL,FAR,FCL
where ARCODE=FALARTICLE
and CLCODE=FALCL
and FALDATE between @date1 and @date2
and ARTYPE=0
and FALLETTRE = ""
and (@ent is null or (FALENT=@ent and CLENT=@ent))


select Rep=Rep,
		Qte_Mois=sum(case when datepart(mm,Date)=@mois then Quantite else 0 end),
		Vente_Mois=sum(case when datepart(mm,Date)=@mois then Valeur_Vente else 0 end),
		Marge_Valeur_Mois=sum(case when datepart(mm,Date)=@mois then Marge_Val else 0 end),
		Marge_PC_Mois=convert(numeric(14,2),0),
		Qte_An=sum(Quantite),
		Vente_An=sum(Valeur_Vente),
		Marge_Valeur_An=sum(Marge_Val),
		Marge_PC_An=convert(numeric(14,2),0)
into #Finale
from #FA
group by Rep

drop table #FA


update #Finale
set Marge_PC_Mois=(case when Vente_Mois != 0 then convert(numeric(14,2),Marge_Valeur_Mois/Vente_Mois*100)
				   	    when Vente_Mois = 0 then 0 end),
	Marge_PC_An=(case when Vente_An != 0 then convert(numeric(14,2),Marge_Valeur_An/Vente_An*100)
				      when Vente_An = 0 then 0 end)


select Rep=Rep,Nom=RENOM,Qte_Mois=Qte_Mois,Vente_Mois=Vente_Mois,Marge_Valeur_Mois=Marge_Valeur_Mois,
		Marge_PC_Mois=Marge_PC_Mois,Qte_An=Qte_An,Vente_An=Vente_An,
		Marge_Valeur_An=Marge_Valeur_An,Marge_PC_An=Marge_PC_An
from #Finale,FREP
where RECODE=Rep
order by Rep

drop table #Finale


end



go

