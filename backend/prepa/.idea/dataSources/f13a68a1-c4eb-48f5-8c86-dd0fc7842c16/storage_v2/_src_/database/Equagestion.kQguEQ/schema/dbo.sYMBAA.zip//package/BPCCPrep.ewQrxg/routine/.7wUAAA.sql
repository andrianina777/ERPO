

/* Procedure utilisee par le module """"""""""""""""Expeditions"""""""""""""""".
Renvoie les commandes a expedier dont les articles ne sont pas numerotes
et qui font partie d''''''''''''''''une commande specifique */
create procedure BPCCPrep  (@ent		char(5) = null,
@UntilDate 	datetime = null,
@Client		char(12),
@Commande 	char(10) = null,
@Depot		char(4))
with recompile					
as
begin
set arithabort numeric_truncation off
declare @restotal	int,
@resligne	int
create table #Liste
(
Article 	char(15)	not null,
Lettre		char(4)		not null,
Designation	char(80)		null,
LienCode	char(10)	not null,
LienNum		int			not null,
Qte			int				null,
UnitFact	tinyint		not null,
PrixHT		numeric(14,2)	null,
ModeLiv		char(2)			null,
LigneLibre	varchar(255)	null,
TypeVente	char(4)		not null,
Reglement	tinyint			null,
Echeancesp	tinyint			null,
Factman		tinyint			null,
Offert		tinyint			null,
Artype		tinyint			null,
Devise		char(3)		not null,
Coursdev	numeric(12,6)	null,
PrixHTdev	numeric(14,2)	null,
TotHTdev	numeric(14,2)	null,
Rem1		real			null,
Rem2		real			null,
Rem3		real			null,
TotPrixHT	numeric(14,2)	null,
Emplacement	char(8)		not null,
Attachement	char(10)		null,
Lot			char(10)	not null,
Arreffour	char(20)		null
)
create table #Prep
(
CCLSEQ			int			not null,
CCLCODE			char(10)	not null,
CCLNUM			int				null,
CCLDATE			datetime		null,
CCLARTICLE		char(15)	not null,
CCLRESTE		int				null,
ARLIB			varchar(80)		null,
ARUNITFACT		tinyint			null,
CCLPHT			numeric(14,2)	null,
MODELIV			char(2)			null,
CCLLIBRE		varchar(255)	null,
CCLTV			char(4)			null,
ARREGLE			tinyint			null,
CCLECHSPE		tinyint			null,
CCLFACTMAN		tinyint			null,
CCLOFFERT		tinyint			null,
ARTYPE			tinyint			null,
CCLDEV			char(3)			null,
CCLCOURSDEV		numeric(12,6)	null,
CCLPHTDEV		numeric(14,2)	null,
CCLTOTALHTDEV	numeric(14,2)	null,
CCLR1			real			null,
CCLR2			real			null,
CCLR3			real			null,
CCLTOTALHT		numeric(14,2)	null,
CCLQTERES		int				null,
CCLDATERESFIN	smalldatetime	null,
CCLDEPOTRES		char(4)			null,
ARCOMP			tinyint			null,
CCLQTEPREP		int				null,
CCLATTACHE		char(10)		null,
ARREFFOUR		char(20)		null
)
create table #Articles
(
CCLARTICLE	char(15)		not null
)
create table #Stock
(
STEMPAR			char(15)	not null,
STEMPLETTRE		char(4)		not null,
QteLoc			int				null,
STEMPDATE		datetime		null,
STEMPEMP		char(8)		not null,
STEMPLOT		char(10)	not null
)
create unique clustered index starlet on #Stock(STEMPAR,STEMPLETTRE)
if (@UntilDate is null)
begin
insert into #Prep
select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),isnull(CCLATTACHE,""),
ARREFFOUR
from FCCL,FAR,FCC,FRCC
where CCLSEQ=RCCSEQ
and RCCCL=@Client
and RCCARTICLE=ARCODE
and CCCODE=CCLCODE
and (@Commande is null or CCLCODE=@Commande)
and ARNUMEROTE=0
and isnull(CCVALIDE,0)=0
and isnull(CCBEBLOQUE,0)=0
and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
order by RCCDATE,RCCSEQ
end
else
begin
insert into #Prep
select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),isnull(CCLATTACHE,""),
ARREFFOUR
from FCCL,FAR,FCC,FRCC
where CCLSEQ=RCCSEQ
and RCCCL=@Client
and RCCDATE<=@UntilDate
and RCCARTICLE=ARCODE
and CCCODE=CCLCODE
and (@Commande is null or CCLCODE=@Commande)
and ARNUMEROTE=0
and isnull(CCVALIDE,0)=0
and isnull(CCBEBLOQUE,0)=0
and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
order by RCCDATE,RCCSEQ
end
declare commandes cursor
for select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,
ARUNITFACT,CCLPHT,MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,CCLOFFERT,
ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,ARCOMP,CCLQTEPREP,CCLATTACHE,ARREFFOUR
from #Prep
order by CCLDATE,CCLSEQ
for read only
insert into #Articles (CCLARTICLE)
select distinct CCLARTICLE from #Prep
create unique clustered index article on #Articles(CCLARTICLE)
declare		@CCLSEQ			int,
@CCLCODE		char(10),
@CCLNUM			int,
@CCLDATE		datetime,
@CCLARTICLE		char(15),
@CCLRESTE		int,
@ARLIB			varchar(80),
@ARUNITFACT		tinyint,
@PUHT			numeric(14,2),
@MODELIV		char(2),
@CCLLIBRE		varchar(255),
@CCLTV			char(4),
@ARREGLE		tinyint,
@CCLECHSPE		tinyint,
@CCLFACTMAN		tinyint,
@CCLOFFERT		tinyint,
@ARTYPE			tinyint,
@CCLDEV			char(3),
@CCLCOURSDEV	numeric(12,6),
@CCLPHTDEV		numeric(14,2),
@CCLTOTALHTDEV	numeric(14,2),
@CCLR1			real,
@CCLR2			real,
@CCLR3			real,
@CCLTOTALHT		numeric(14,2),
@CCLQTERES		int,
@CCLDATERESFIN	smalldatetime,
@CCLDEPOTRES	char(4),
@ARCOMP			tinyint,
@CCLQTEPREP		int,
@CCLATTACHE		char(10),
@ARREFFOUR		char(20)
set forceplan on
insert into #Stock (STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT)
select STEMPAR,STEMPLETTRE,STEMPQTE,STEMPDATE,STEMPEMP,isnull(STEMPLOT,"")
from #Articles,FSTEMP,FAR,FDP,FARE
where STEMPAR=CCLARTICLE
and ARCODE=STEMPAR
and STEMPDEPOT=@Depot
and AREAR=STEMPAR and AREDEPOT=STEMPDEPOT and AREEMP=STEMPEMP and AREPICK=1
and (ARTYPE <> 0 or STEMPQTE > 0)
and DPCODE=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
order by STEMPDATE,STEMPAR,STEMPLETTRE
set forceplan off
declare LeStock cursor
for select STEMPAR,STEMPLETTRE,QteLoc,STEMPEMP,STEMPLOT from #Stock,FAR
where ARCODE=STEMPAR
and STEMPAR=@CCLARTICLE
and (ARTYPE <> 0 or QteLoc > 0)
for update of QteLoc
delete from #Prep where not exists (select * from #Stock where STEMPAR=#Prep.CCLARTICLE)
declare 	@qteST 			int
declare 	@articleST 		char(15)
declare 	@lettreST 		char(4)
declare		@qtelivre		int
declare		@emplacement	char(8)
declare		@lot			char(10)
open commandes
fetch commandes
into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR
while (@@sqlstatus = 0)
begin
select @restotal = sum(RCCQTERES)
from FRCC
where RCCARTICLE = @CCLARTICLE
and RCCDEPOTRES = @Depot
if @restotal is null select @restotal = 0
if @CCLDATERESFIN is not null and @CCLDEPOTRES = @Depot
select @resligne = @CCLQTERES
else
select @resligne = 0
if @resligne is null select @resligne = 0
open LeStock
fetch LeStock
into @articleST,@lettreST,@qteST,@emplacement,@lot
while (@@sqlstatus = 0)
begin
select @qtelivre = 0
if ((@CCLRESTE-@CCLQTEPREP < @qteST-@restotal+@resligne) or (@ARTYPE <> 0))
select @qtelivre = @CCLRESTE-@CCLQTEPREP
else if @qteST-@restotal+@resligne-@CCLQTEPREP > 0
select @qtelivre = @qteST-@restotal+@resligne-@CCLQTEPREP
insert into #Liste (Article,Lettre,Designation,LienCode,LienNum,Qte,
UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,
Reglement,Echeancesp,Factman,Offert,Artype,
Devise,Coursdev,PrixHTdev,TotHTdev,Rem1,Rem2,Rem3,
TotPrixHT,Emplacement,Attachement,Lot,Arreffour)
select @articleST,@lettreST,@ARLIB,@CCLCODE,@CCLNUM,
@qtelivre,@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,
@CCLTV,@ARREGLE,@CCLECHSPE,@CCLFACTMAN,@CCLOFFERT,@ARTYPE,
@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,@CCLR1,@CCLR2,@CCLR3,
@CCLTOTALHT,@emplacement,@CCLATTACHE,@lot,@ARREFFOUR
update #Stock set QteLoc=QteLoc-@qtelivre where current of LeStock
select @CCLRESTE=@CCLRESTE-@qtelivre
select @restotal = (case when @qtelivre >= @resligne then @restotal - @resligne
when @qtelivre < @resligne then @restotal - @qtelivre
end)
select @resligne = (case when @qtelivre >= @resligne then 0
else @resligne - @qtelivre
end)
if (@CCLRESTE <= 0) break
fetch LeStock
into @articleST,@lettreST,@qteST,@emplacement,@lot
end
close LeStock 
fetch commandes
into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR
end
close commandes
deallocate cursor commandes
delete from #Liste
where Artype=4
and not exists (select * from #Liste as b where #Liste.LienCode=b.LienCode and b.Artype <> 4)
and not exists (select * from FCCL,FAR where CCLCODE=#Liste.LienCode and ARCODE=CCLARTICLE and CCLRESTE > 0 and (ARNUMEROTE=1 or ARCOMP=2))
select Article,Lettre,Designation,LienCode,LienNum,Qte,
UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,Reglement,
Echeancesp,abs(Qte),Factman,isnull(Offert,0),isnull(Artype,0),
isnull(Devise,''),isnull(Coursdev,0),isnull(PrixHTdev,0),
isnull(TotHTdev,0),Rem1,Rem2,Rem3,TotPrixHT,Emplacement,
Attachement,@lot,Arreffour
from #Liste
where Qte > 0
order by LienCode,LienNum
drop table #Prep
drop table #Articles
drop table #Stock
drop table #Liste
end


go

