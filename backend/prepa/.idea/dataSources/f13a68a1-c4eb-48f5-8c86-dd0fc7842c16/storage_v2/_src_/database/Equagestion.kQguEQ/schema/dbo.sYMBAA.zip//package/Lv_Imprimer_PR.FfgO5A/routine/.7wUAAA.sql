/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.Lv_Imprimer_PR

*/

create procedure dbo.Lv_Imprimer_PR (
@Lv_prCode char(10)
)

as
--insert procedure body here

begin



select xBPRLAR,

 (
 case when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=0) 
   
   then "*****/+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
    when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=1) 
     
     then "*****/+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"
     
      when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=0) 
     
       then "+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
        when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=1)  
     
         then "+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"
     
          when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=1 and xARR_AO=0) and (xARTP_FROID=0)
     
           then "***** "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
            when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=1 and xARR_AO=0)and (xARTP_FROID=1) 
     
             then "***** "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"
     
              when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=0  and (xARTP_FROID=0)
     
               then rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
                when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=0 and (xARTP_FROID=1) 
     
                 then rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"  
   
else  
    
     case when (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=0) 
          
      then  "*****/+++++  "+ ARLIB
          
       when (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=1) 
          
        then  "*****/+++++  "+ ARLIB+"  --(CONSERVATION ? FROID)"
          
         when (xARR_URGENT=1 and xARR_AO=0)and (xARTP_FROID=0) 
          
          then  "***** "+ ARLIB
          
           when (xARR_URGENT=1 and xARR_AO=0)and (xARTP_FROID=1) 
          
            then  "***** "+ ARLIB+"  --(CONSERVATION ? FROID)"
          
             when (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=0) 
          
              then  "+++++ "+ ARLIB
          
               when (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=1) 
          
                then  "+++++ "+ ARLIB+"  --(CONSERVATION ? FROID)"
          
                 when  (xARR_URGENT+xARR_AO)=0  and (xARTP_FROID=0)
          
                  then ARLIB
          
                   when  (xARR_URGENT+xARR_AO)=0 and (xARTP_FROID=1)
          
                    then ARLIB+"  --(CONSERVATION ? FROID)"  
     
else 
    
       case 
          
        when( rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and xARTP_FROID=1) 
          
         then rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)" 
     
       else   
          
           case 
               
            when(rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO) 
               
             then  rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
                     
              else ARLIB 
           end 
       end 
     end 
end),

 AREEMP,ARESSEMP,xBPRLLOT, sum(xBPRLQTE),isnull(NLOTDATEPER,""),

case 
     
  when (AREEMP="GH--"  or ARESSEMP="GH--") 
      
   then "GH--" 
      
    when (AREEMP="GB--"  or ARESSEMP="GB--") 
    then "GB--" 
      
     when (AREEMP="SP--"  or ARESSEMP="GB--") 
     then "SP--" 
      
      when (AREEMP="GF--"  or ARESSEMP="GB--") 
      then "GF--" 
      
       when (AREEMP="GFC-"  or ARESSEMP="GB--") 
       then "GFC-" 
      
        when (AREEMP="GSME"  or ARESSEMP="GB--") 
        then "GSME" 

else ""

end
from xFBPRL,FARE,FAR,FNLOT,FCF,xArrivage,xFARTYPE

where  xBPRLAR*=AREAR
        and ARCODE=xBPRLAR
        and xBPRLLOT=NLOTCODE
       and xBPRLCODE=@Lv_prCode
group by  xBPRLAR,

(
 case
 when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=0) 
     
  then "*****/+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
      when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=1) 
    
    then "*****/+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"
     
     when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=0 and xARR_AO=1)  and (xARTP_FROID=0)
     
      then "+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
       when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=1)  
     
        then "+++++ "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"
     
         when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=1 and xARR_AO=0) and (xARTP_FROID=0)
     
          then "***** "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
           when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT=1 and xARR_AO=0)and (xARTP_FROID=1) 
     
            then "***** "+rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"
     
             when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=0 and (xARTP_FROID=0)
     
              then rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
     
               when rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and (xARR_URGENT+xARR_AO)=0 and (xARTP_FROID=1) 
     
                then rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)"

else  
  
  case 
        
   when (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=0) 
        
    then  "*****/+++++  "+ ARLIB
        
     when (xARR_URGENT+xARR_AO)=2 and (xARTP_FROID=1) 
        
      then  "*****/+++++  "+ ARLIB+"  --(CONSERVATION ? FROID)"
        
       when (xARR_URGENT=1 and xARR_AO=0) and (xARTP_FROID=0)
        
        then  "***** "+ ARLIB
        
         when (xARR_URGENT=1 and xARR_AO=0)and (xARTP_FROID=1) 
        
          then  "***** "+ ARLIB+"  --(CONSERVATION ? FROID)"
        
           when (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=0) 
        
            then  "+++++ "+ ARLIB
        
             when (xARR_URGENT=0 and xARR_AO=1)and (xARTP_FROID=1) 
        
              then  "+++++ "+ ARLIB+"  --(CONSERVATION ? FROID)"
        
               when  (xARR_URGENT+xARR_AO)=0 and (xARTP_FROID=0)
        
                then ARLIB
        
                 when  (xARR_URGENT+xARR_AO)=0 and (xARTP_FROID=1)
        
                  then ARLIB+"  --(CONSERVATION ? FROID)"

  else 
     
  case 
        
   when( rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO and xARTP_FROID=1) 
        
    then rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) +"  --(CONSERVATION ? FROID)" 
     
     else   
           
      case 
               
       when(rtrim(ARLIBXENO)<>"" and ARLIB<>ARLIBXENO) 
               
        then  rtrim(ARLIBXENO)+ " -- " + rtrim(ARLIB) 
                     
         else ARLIB 
           
     end
     
 end 

 end 

end),

AREEMP,ARESSEMP,xBPRLLOT,NLOTDATEP
ORDER order by xBPRLAR asc

end  
end












go

