


create procedure Frais (@ent	char(5) = null,
						@date1	datetime = null,
						@date2	datetime = null)
with recompile
as
begin

set arithabort numeric_truncation off


if @date1 is null
begin
select @date1=convert(datetime,"01/01/"+convert(varchar,datepart(yy,getdate())))
select @date2=convert(datetime,"12/31/"+convert(varchar,datepart(yy,getdate())))
end


create table #Liste
(
famille		char(8)		not null,
type		char(15)	not null,
transport	numeric(14,2)	null,	/* Frais de transport pour la douane */
totaltr		numeric(14,2)	null,	/* Total HT de la ligne pour transport */
global		numeric(14,2)	null,	/* Frais de transport et de droits de douane */
totalgl		numeric(14,2)	null,	/* Total HT de la ligne pour global */
epreuves	numeric(14,2)	null,	/* Frais d''epreuve */
totalep		numeric(14,2)	null	/* Total HT de la ligne pour epreuve */
)


/**** Frais sur Livraisons ****/

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"livraisons",sum(BLLFRAIS),sum(BLLTOTHT),0,0,0,0
from FBLL,FAR
where ARCODE=BLLAR
and BLLNUMDEP=0
and BLLFRAIS>0
and BLLDATE between @date1 and @date2
and (@ent is null or BLLENT=@ent)
group by ARFAM

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"livraisons",0,0,sum(BLLFRAIS),sum(BLLTOTHT),0,0
from FBLL,FAR
where ARCODE=BLLAR
and BLLNUMDEP=1
and BLLFRAIS>0
and BLLDATE between @date1 and @date2
and (@ent is null or BLLENT=@ent)
group by ARFAM

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"livraisons",0,0,0,0,sum(BLLEPR),sum(BLLTOTHT)
from FBLL,FAR
where ARCODE=BLLAR
and BLLEPR>0
and BLLDATE between @date1 and @date2
and (@ent is null or BLLENT=@ent)
group by ARFAM


/**** Frais sur Sorties de Douanes ****/

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"sorties_douanes",sum(DOLFRAIS),sum(abs(DOLTOTHT)),0,0,0,0
from FDOL,FAR
where ARCODE=DOLAR
and DOLNUMDEP=0
and DOLFRAIS>0
and DOLDATE between @date1 and @date2
and (@ent is null or DOLENT=@ent)
group by ARFAM

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"sorties_douanes",0,0,sum(DOLFRAIS),sum(DOLTOTHT),0,0
from FDOL,FAR
where ARCODE=DOLAR
and DOLNUMDEP=1
and DOLFRAIS>0
and DOLDATE between @date1 and @date2
and (@ent is null or DOLENT=@ent)
group by ARFAM

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"sorties_douanes",0,0,0,0,sum(DOLEPR),sum(DOLTOTHT)
from FDOL,FAR
where ARCODE=DOLAR
and DOLEPR>0
and DOLDATE between @date1 and @date2
and (@ent is null or DOLENT=@ent)
group by ARFAM


/**** Frais sur Stock initial ****/

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"fluctuations",round(sum(SILFRAIS*SILQTE/CVLOT),2),round(sum(SILPAHT*SILQTE/CVLOT),2),0,0,0,0
from FSIL,FDP,FAR,FCV
where DPCODE=SILDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and ARCODE=SILARTICLE
and ARUNITACHAT=CVUNIF
and SILNUMDEP=0
and SILFRAIS>0
and SILDATE between @date1 and @date2
group by ARFAM

insert into #Liste (famille,type,transport,totaltr,global,totalgl,epreuves,totalep)
select ARFAM,"fluctuations",0,0,round(sum(SILFRAIS*SILQTE/CVLOT),2),round(sum(SILPAHT*SILQTE/CVLOT),2),0,0
from FSIL,FDP,FAR,FCV
where DPCODE=SILDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and ARCODE=SILARTICLE
and ARUNITACHAT=CVUNIF
and SILNUMDEP=1
and SILFRAIS>0
and SILDATE between @date1 and @date2
group by ARFAM



/**** select final ****/

select famille,type,transport=sum(transport),totaltr=sum(totaltr),transport_et_douanes=sum(global),
		totalgl=sum(totalgl),epreuve=sum(epreuves),totalep=sum(totalep)
from #Liste
group by famille,type
having sum(transport)+sum(global)+sum(epreuves) != 0
order by famille,type


drop table #Liste

end



go

