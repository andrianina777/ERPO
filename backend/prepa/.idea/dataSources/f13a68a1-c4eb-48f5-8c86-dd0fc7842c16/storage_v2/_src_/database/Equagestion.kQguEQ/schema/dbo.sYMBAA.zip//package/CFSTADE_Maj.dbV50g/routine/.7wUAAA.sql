


create procedure CFSTADE_Maj (	@cfent		char(5) = null,
								@cfcode		char(10))	
with recompile
as
begin

  declare @num		int
  
  select @num = 0
  select @num = isnull(min(CFLSTADE),0) from FCFL,FAR where CFLCODE = @cfcode
  													and ARCODE=CFLARTICLE
													and ARTYPE in (0,1)
  													and (@cfent is null or CFLENT = @cfent)
 
  if @num > 0
	update FCF set CFSTADE = @num where CFCODE = @cfcode and (@cfent is null or CFENT = @cfent)
  else
	update FCF set CFSTADE = 0 where CFCODE = @cfcode and (@cfent is null or CFENT = @cfent)

end



go

