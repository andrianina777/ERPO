


create procedure ConsultST (@ent			char(5)  = null,
							@FromArticle	char(15) = null,
							@ToArticle		char(15) = null,
							@Numarm1	  	char(12) = null,
							@Numarm2	 	char(12) = null,
							@CodeST1	  	char(3)  = null,
							@CodeST2	 	char(3)  = null,
							@RefFourn 		varchar(30) = null,
							@Fourn		 	char(12) = null,
							@Famille	  	char(8)  = null,
							@Depot			char(4)	 = null,
							@sansold		tinyint  = 1,
							@Categ			char(8)  = null,
							@Matiere		varchar(14)= null,
							@Couleur		char(8)  = null,
							@Grille			char(10) = null,
							@lot			char(12) = null
							)
with recompile
as
begin

if @ToArticle is null
	select @ToArticle=@FromArticle

if @CodeST2 is null
	select @CodeST2=@CodeST1

declare @count	int

create table #Stock
(
Article		char(15)	not	null,
Depot		char(4)			null,
Stock		int				null
)

create table #ar
(
ARCODE		char(15)	not	null
)

create table #reserve
(
artres		char(15)	not	null,
qteres		int			not null
)



if (isnull(@Numarm1,'') != '' and isnull(@Numarm2,'') = '')
	begin
		insert into #Stock
		select STAR,STDEPOT,sum(STQTE)
		from FSTOCK,FDP
		where DPCODE=STDEPOT and (@ent is null or  (DPENT=@ent and DPCENTRAL=0))
		and STNUMARM1=@Numarm1
		group by STAR,STDEPOT
	end
else if (isnull(@Numarm1,'') ='' and isnull(@Numarm2,'') !='')
	begin
		insert into #Stock
		select STAR,STDEPOT,sum(STQTE)
		from FSTOCK,FDP
		where DPCODE=STDEPOT and (@ent is null or  (DPENT=@ent and DPCENTRAL=0))
		and STNUMARM2=@Numarm2
		group by STAR,STDEPOT
	end
else if (isnull(@Numarm1,'') != '' and isnull(@Numarm2,'') != '')
	begin
		insert into #Stock
		select STAR,STDEPOT,sum(STQTE)
		from FSTOCK,FDP
		where DPCODE=STDEPOT and (@ent is null or  (DPENT=@ent and DPCENTRAL=0))
		and STNUMARM1=@Numarm1
		and STNUMARM2=@Numarm2
		group by STAR,STDEPOT
	end
else
	begin
		insert  into #ar (ARCODE)
		select ARCODE
		from FAR
		where (@FromArticle is null or (ARCODE between @FromArticle and @ToArticle))
		and (@Fourn is null or ARFO=@Fourn)
		and (@Famille is null or ARFAM=@Famille)
		and (@Categ is null or ARGRFAM=@Categ)
		and (@Matiere is null or ARMATIERE=@Matiere)
		and (@Couleur is null or ARCOULEUR=@Couleur)
		and (@Grille is null or ARGRILLE=@Grille)
		and (@RefFourn is null or ARREFFOUR=@RefFourn)
		and (@sansold = 0 or AROLD = 0)
	end


select @count=count(*) from #ar

if (@count > 0)
	begin
		if (@CodeST1 is null)
			begin
				insert into #Stock
				select STAR,STDEPOT,sum(STQTE)
				from FSTOCK,#ar,FDP
				where DPCODE=STDEPOT and (@ent is null or  (DPENT=@ent and DPCENTRAL=0))
				and ARCODE=STAR
				and (@lot is null or STLOT like "%" + @lot + "%")
				group by STAR,STDEPOT
			end
		else
			begin
				insert into #Stock
				select STAR,STDEPOT,sum(STQTE)
				from FSTOCK,#ar,FDP
				where DPCODE=STDEPOT and (@ent is null or  (DPENT=@ent and DPCENTRAL=0))
				and ARCODE=STAR
				and (@lot is null or STLOT like "%" + @lot + "%")
				and STLETTRE between @CodeST1 and @CodeST2
				group by STAR,STDEPOT
			end
	end

select @count=count(*) from #ar

if (@count > 0)
  begin
	insert into #reserve (artres,qteres)
	select RCCARTICLE,isnull(sum(RCCQTERES),0)
	from FRCC,#ar
	where RCCARTICLE=ARCODE
	and (@Depot is null or RCCDEPOTRES = @Depot)
	group by RCCARTICLE
  end




select Article,ARLIB,ARFO,ARFAM,ARREFFOUR,
	   TotLoc=sum(case when DPLOC = 1 then Stock else 0 end),
	   TotAutres=sum(case when DPLOC != 1 then Stock else 0 end),
	   StockTotal=sum(Stock),qteres
from #Stock,FDP,FAR,#reserve
where Depot=DPCODE
and artres=*Article
and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and ARCODE=Article
and Depot like (case 	when isnull(@Depot,'')<>'' 	then @Depot
						when isnull(@Depot,'')=''	then '%'
				end)
group by Article,ARLIB,ARFO,ARFAM,ARREFFOUR,qteres


drop table #Stock
drop table #ar
drop table #reserve

end



go

