


create procedure Contrats  (@ent		char(5) 	= null,
							@contrat	char(10),
							@an			smallint,
							@rep		char(8)		= null,
							@clientdeb	char(12)	= null,
							@clientfin	char(12)	= null,
							@dep		char(2) 	= null,
							@qte		int			= null,
							@T1			float,
							@T2			float,
							@T3			float,
							@T4			float)
with recompile
as
begin

declare @date1		datetime,
		@date2		datetime,
		@type		tinyint,
		@division	char(8),
		@multient	tinyint

select  @type = 0

if @rep is not null
	select  @type=RETYPE, @division=REDIV from FREP where RECODE=@rep

	
select @multient=KIMULTIENTITE from KInfos


create table #Final
(
rep			char(8)			null,
dep			char(2)			null,
client		char(12)	not null,
nom			varchar(35)		null,
ventesold	int				null,
cdes		int				null,
ventes1T	int				null,
ventes2T	int				null,
ventes3T	int				null,
ventes4T	int				null,
contrat		int				null
)

/* Table des clients avec contrat */

if @type != 2
begin
  insert into #Final (rep,dep,client,nom,ventesold,cdes,ventes1T,ventes2T,ventes3T,ventes4T,contrat)
  select isnull(@rep,CLREP),substring(CLCP,1,2),CTCL,CLNOM1,0,0,0,0,0,0,CTQTE
  from FCT2,FCL
  where CLCODE=CTCL
  and CTCODE=@contrat
  and CTAN=@an
  and (@clientdeb is null or CLCODE between @clientdeb and @clientfin)
  and (@rep is null or CLREP=@rep)
  and (@dep is null or substring(CLCP,1,2)=@dep)
  and (@qte is null or CTQTE>=@qte)
  and (@multient = 0 or @ent is null or (CTENT=@ent and CLENT=CTENT))
  order by CTCL
end
else if @type = 2
begin
  insert into #Final (rep,dep,client,nom,ventesold,cdes,ventes1T,ventes2T,ventes3T,ventes4T,contrat)
  select isnull(@rep,CLRREPDIV),substring(CLCP,1,2),CTCL,CLNOM1,0,0,0,0,0,0,CTQTE
  from FCT2,FCL,FCLR
  where CLCODE=CTCL
  and CTCODE=@contrat
  and CTAN=@an
  and CLCODE=CLRCL
  and (@clientdeb is null or CLCODE between @clientdeb and @clientfin)
  and (@rep is null or CLRREPDIV=@rep)
  and (@dep is null or substring(CLCP,1,2)=@dep)
  and (@qte is null or CTQTE>=@qte)
  and (@multient = 0 or @ent is null or (CTENT=@ent and CLENT=CTENT))
  order by CTCL
end


create unique index client on #Final(client)

/* Table des articles */

select ARCODE,ARDEPART
into #AR
from FAR,FCO
where ARFO=COFO
and (COFAM = "" or ARFAM=COFAM)
and COCODE=@contrat
and isnull(COPQTE,0) > 0
and (@multient = 0 or @ent is null or COENT=@ent)
order by ARCODE


/* Ventes de l''annee precedente */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an-1))
select @date2=convert(datetime,'12/31/'+convert(varchar(4),@an-1))


create table #Old
(
FALCL	char(12)	not null,
Tot		int				null
)

insert into #Old
select isnull(FALCL,""),Tot=sum(FALQTE)
from FFAL,#AR,#Final,FFA
where FALCODE=FACODE
and FACL=client
and FADATE between @date1 and @date2
and FALARTICLE=ARCODE
and isnull(FALLETTRE,'') != ''
and (@multient = 0 or @ent is null or (FALENT=@ent and FAENT=FALENT))
and (@type != 2 or FALREPDIV=@rep)
group by FALCL


update #Final
set ventesold=Tot
from #Old
where client=FALCL

drop table #Old


/* Commandes en cours */

select RCCCL,Tot=sum(RCCQTE)
into #Cdes
from #Final,#AR,FRCC,FCC,FCCL
where RCCARTICLE=ARCODE
and RCCCL=client
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient = 0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@type != 2 or CCLREPDIV=@rep)
group by RCCCL


update #Final
set cdes=Tot
from #Cdes
where client=RCCCL

drop table #Cdes


/* Ventes du 1er trimestre de l''annee demandee */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an))
select @date2=convert(datetime,'03/31/'+convert(varchar(4),@an))


create table #Tr1
(
FALCL	char(12)	not null,
Tot		int				null
)

insert into #Tr1
select isnull(FALCL,""),Tot=sum(FALQTE)
from FFAL,#AR,#Final,FFA
where FALCODE=FACODE
and FACL=client
and FADATE between @date1 and @date2
and FALARTICLE=ARCODE
and isnull(FALLETTRE,'') != ''
and (@multient = 0 or @ent is null or (FALENT=@ent and FAENT=FALENT))
and (@type != 2 or FALREPDIV=@rep)
group by FALCL


update #Final
set ventes1T=Tot
from #Tr1
where client=FALCL

drop table #Tr1


/* Ventes du 2eme trimestre de l''annee demandee */

select @date1=convert(datetime,'04/01/'+convert(varchar(4),@an))
select @date2=convert(datetime,'06/30/'+convert(varchar(4),@an))

create table #Tr2
(
FALCL	char(12)	not null,
Tot		int				null
)

insert into #Tr2
select isnull(FALCL,""),Tot=sum(FALQTE)
from FFAL,#AR,#Final,FFA
where FALCODE=FACODE
and FACL=client
and FADATE between @date1 and @date2
and FALARTICLE=ARCODE
and isnull(FALLETTRE,'') != ''
and (@multient = 0 or @ent is null or (FALENT=@ent and FAENT=FALENT))
and (@type != 2 or FALREPDIV=@rep)
group by FALCL


update #Final
set ventes2T=Tot
from #Tr2
where client=FALCL

drop table #Tr2


/* Ventes du 3eme trimestre de l''annee demandee */

select @date1=convert(datetime,'07/01/'+convert(varchar(4),@an))
select @date2=convert(datetime,'09/30/'+convert(varchar(4),@an))

create table #Tr3
(
FALCL	char(12)	not null,
Tot		int				null
)

insert into #Tr3
select isnull(FALCL,""),Tot=sum(FALQTE)
from FFAL,#AR,#Final,FFA
where FALCODE=FACODE
and FACL=client
and FADATE between @date1 and @date2
and FALARTICLE=ARCODE
and isnull(FALLETTRE,'') != ''
and (@multient = 0 or @ent is null or (FALENT=@ent and FAENT=FALENT))
and (@type != 2 or FALREPDIV=@rep)
group by FALCL


update #Final
set ventes3T=Tot
from #Tr3
where client=FALCL

drop table #Tr3


/* Ventes du 4eme trimestre de l''annee demandee */

select @date1=convert(datetime,'10/01/'+convert(varchar(4),@an))
select @date2=convert(datetime,'12/31/'+convert(varchar(4),@an))

create table #Tr4
(
FALCL	char(12)	not null,
Tot		int				null
)

insert into #Tr4
select isnull(FALCL,""),Tot=sum(FALQTE)
from FFAL,#AR,#Final,FFA
where FALCODE=FACODE
and FACL=client
and FADATE between @date1 and @date2
and FALARTICLE=ARCODE
and isnull(FALLETTRE,'') != ''
and (@multient = 0 or @ent is null or (FALENT=@ent and FAENT=FALENT))
and (@type != 2 or FALREPDIV=@rep)
group by FALCL


update #Final
set ventes4T=Tot
from #Tr4
where client=FALCL

drop table #Tr4

drop table #AR

/* select de sortie */
/*

select ""Repres"",""Dep"",""Code CL"",""Nom"",""Ventes ""+convert(varchar(4),@an-1),""Cdes"",
		""Obj. T1"",""Ventes T1"",""Dif T1"",
		""Obj. T2"",""Ventes T2"",""Dif T2"",
		""Obj. T3"",""Ventes T3"",""Dif T3"",
		""Obj. T4"",""Ventes T4"",""Dif T4"",
		""Obj ""+convert(varchar(4),@an),
		""Ventes ""+convert(varchar(4),@an),
		""Dif ""+convert(varchar(4),@an)
*/	

		
select rep,dep,client,nom,ventesold,cdes,
		convert(int,round(contrat*@T1,0)),isnull(ventes1T,0),isnull(ventes1T,0)-convert(int,round(contrat*@T1,0)),
		convert(int,round(contrat*@T2,0)),isnull(ventes2T,0),isnull(ventes2T,0)-convert(int,round(contrat*@T2,0)),
		convert(int,round(contrat*@T3,0)),isnull(ventes3T,0),isnull(ventes3T,0)-convert(int,round(contrat*@T3,0)),
		convert(int,round(contrat*@T4,0)),isnull(ventes4T,0),isnull(ventes4T,0)-convert(int,round(contrat*@T4,0)),
		contrat,isnull(ventes1T,0)+isnull(ventes2T,0)+isnull(ventes3T,0)+isnull(ventes4T,0),
		isnull(ventes1T,0)+isnull(ventes2T,0)+isnull(ventes3T,0)+isnull(ventes4T,0)-contrat
from #Final
order by rep,dep,client

drop table #Final

end



go

