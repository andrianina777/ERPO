

create procedure FactCC (@ent		char(5) 	= null,
						 @FromClient char(12) 	= null,
						 @ToClient 	char(12) 	= null,
						 @FromDate 	smalldatetime = null,
						 @ToDate 	smalldatetime = null,
						 @Cde1		char(10) 	= null,
						 @Cde2		char(10) 	= null,
						 @periode	tinyint	 	= 0
						)
with recompile
as
begin

if @ToClient is null
select @ToClient=@FromClient

if @ToDate is null
select @ToDate=@FromDate

if @Cde2 is null
select @Cde2=@Cde1

declare @saisondeb		char(5),
		@saisonfin		char(5),
		@datesaisondeb	datetime,
		@datesaisonfin	datetime
		
select @saisondeb=PSAISONDEB,@saisonfin=PSAISONFIN from KParam
where (@ent is null or PENT=@ent)

set dateformat dmy
select @datesaisondeb=convert(datetime,@saisondeb+"/"+convert(varchar(4),datepart(yy,getdate())))
select @datesaisonfin=convert(datetime,@saisonfin+"/"+convert(varchar(4),datepart(yy,getdate())))
set dateformat mdy


	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,"",
	 CCLDEV,CCTARIF,BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,
	 BEADR1=isnull(BEADR1,""),BEADR2=isnull(BEADR2,""),BECP=isnull(BECP,""),BELOFFERT=isnull(BELOFFERT,0),
	 BELMARCHE=isnull(BELMARCHE,""),"","",0,BELCOLIS=isnull(BELCOLIS,0)
from FBEL,FRBE,FAR,FCCL,FCC,FBE,FCL
 where BELSEQ=RBESEQ
 and RBECL=CLCODE
 and RBEARTICLE!=''
 and ARCODE=RBEARTICLE
 and RBEFACTMAN=0
 and RBEDEMO=0
 and RBESTADE in (2,3)
 and CCLCODE=BELLIENCODE
 and CCLNUM=BELLIENNUM
 and CCCODE=CCLCODE
 and ((RBEECH=0) or (RBEECH=1 and RBEDATE < @datesaisondeb) or (RBEECH=1 and RBEDATE > @datesaisonfin))
 and (@FromClient is null or RBECL between @FromClient and @ToClient)
 and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
 and isnull(BELTYPEVE,'')!=''
 and BELQTE>=0
 and BELLIENCODE like "CC%"
 and BECODE=BELCODE
 and (@Cde1 is null or BELLIENCODE between @Cde1 and @Cde2)
 and (@ent is null or (BELENT=@ent and RBEENT=@ent and CCLENT=@ent and CCENT=@ent))
 and CLFACTPERIODE = @periode
order by BEADR1,BEADR2,BECP,BELLIENCODE,BELLIENNUM,CCLDEV

end
go

