



create procedure Conversion_mul	(@mtdev 	numeric(14,2),
							 	 @chtaux	numeric(12,6),
							 	 @tronc		tinyint = 2
								 )
as
begin

set arithabort numeric_truncation off


declare @mt		float

if @tronc > 6
	select @tronc = 6

if @tronc = 0
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*1))/1
else if @tronc = 1
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*10))/10
else if @tronc = 2
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*100))/100
else if @tronc = 3
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*1000))/1000
else if @tronc = 4
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*10000))/10000
else if @tronc = 5
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*100000))/100000
else if @tronc = 6
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev*@chtaux)*1000000))/1000000


select @mt

end



go

