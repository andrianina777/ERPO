


/* Met a jour les statistiques clients d''une annee */



create procedure Maj_RFAStats	(@an	smallint)
as
begin

declare @lignes		int,
		@labase		varchar(20),
		@encours	int,
		@compteur	int,
		@count		int
select  @labase = db_name(),
		@lignes = 0,
		@encours = 0,
		@compteur = 0


select @lignes=count(count(*))
from FST
where STAN=@an
group by STCL

print "->  %1! clients a traiter", @lignes

select @lignes = 0

declare contrats cursor 
for select STCL
from FST
where STAN=@an
group by STCL
for read only

declare @client		char(8)

open contrats

fetch contrats
into @client

while (@@sqlstatus = 0)
	begin
	
	select @lignes=@lignes+1
			
	execute MajRFA_FACL null,@client,@an
	
	execute New_FSTClient_An null,@client,@an
	
	select @compteur = @compteur + @@rowcount

	if (@lignes >= 10)
	begin
		select @encours = @encours + @lignes
		dump tran @labase with truncate_only
		select @lignes = 0
		print "->  %1! lignes scannees", @encours
	end
	
	fetch contrats
	into @client
	
end

close contrats
deallocate cursor contrats

select @encours = @encours + @lignes
dump tran @labase with truncate_only
print "->  %1! lignes scannees", @encours
print "->  %1! lignes traitees", @compteur


end



go

