
create procedure AnalyseProgression (
					@ent				char(5)			= null, 
					@select				varchar(1000)	= "",		/* Contient les colonnes demandees par les utilisateurs (8 colonnes) */
					@type				tinyint			= 0,		/* 0 pour analyse sur ventes, 1 pour analyse  commandes, 2 pour analyse du portefeuille de commandes */
					@avecmarge			tinyint			= 0,		/* Uniquement si @type est = 0 */
					@modevalo			tinyint			= 0,		/* necessaire si @type est = 0 */
					@offert				tinyint			= null, 	/* necessaire si @type est = 0 */  
					@d1 				smalldatetime = null, 
					@d2					smalldatetime = null, 
					@d3					smalldatetime = null, 
					@d4					smalldatetime = null, 
					@AR1 				char(15) 	= null,
					@AR2 				char(15) 	= null,
					@DEP1 				char(8) 	= null,   
					@DEP2 				char(8) 	= null,   
					@FOURNISSEUR1 		char(12) 	= null,  
					@FOURNISSEUR2 		char(12) 	= null,  
					@FAMILLE1 			char(8) 	= null, 
					@FAMILLE2 			char(8) 	= null, 
					@CAT1 				char(8) 	= null,
					@CAT2 				char(8) 	= null,
					@CPN1 				char(8) 	= null,
					@CPN2 				char(8) 	= null,
					@DECLINAISON11 		char(14)	= null,
					@DECLINAISON12 		char(14)	= null,
					@DECLINAISON21 		char(8)		= null, 
					@DECLINAISON22 		char(8)		= null, 
					@DECLINAISON31 		char(10)	= null,
					@DECLINAISON32 		char(10)	= null,
					@DECLINAISON41 		char(14)	= null,  
					@DECLINAISON42 		char(14)	= null,  
					@DECLINAISON51 		char(16)	= null,  
					@DECLINAISON52 		char(16)	= null,
					@TIERS11 			char(12)	= null,  
					@TIERS12 			char(12)	= null,
					@TIERS21 			char(12)	= null,  
					@TIERS22			char(12)	= null,   
					@TYPE_AR1			tinyint 	= null,
					@TYPE_AR2 			tinyint 	= null,
					@ACTIVITE1 			char(6)	 	= null,  
					@ACTIVITE2			char(6)	 	= null,  
					@PAYS1  			char(8) 	= null,					
					@PAYS2 				char(8) 	= null,	
					@SALESMAN 			char(8) 	= null,		
					@SALESMAN2			char(8) 	= null,
					@MARKET1 			char(12)	= null,
					@MARKET2 			char(12)	= null,
					@CUSTOMER1 			char(12) 	= null, 
					@CUSTOMER2 			char(12) 	= null, 
					@GROUPE				char(12)	= null,
					@CLASSE		 		char(12) 	= null, 
					@AXCODE 			char(12)	= null,
					@AXSEC 				char(12)	= null,
					@AXFILE 			char(4)		= null,
					@CRITEREDEGRE		tinyint		= 0,		/* 1 indique critere CL2DEGRE a prendre en compte -----> MODIF 291007 */ 
					@CL2DEGRE			int			= 0,		/* Valeur CL2DEGRE -----> MODIF 291007 */
					@TypeDateCde		tinyint		= 0			/* 0 = date des lignes de cdes, 1 = date de la cde */			
)
with recompile
as
begin
  
set arithabort numeric_truncation off
 
create table  #Detail
( 
SEQ			int			not null,	/* Sequentiel de FFAL */
dat 		datetime	not null,	/* Date de la facture */
Col1		varchar(75)		null, 	/* Valeur du premier axe */
Col2		varchar(75)		null,	/* Valeur du second axe */
Col3		varchar(75)		null,	/* Valeur du 3eme axe */
Col4		varchar(75)		null,	/* Valeur du 4eme axe */
Col5		varchar(75)		null,	/* Valeur du 5eme axe */
Col6		varchar(75)		null,	/* Valeur du 6eme axe */
Col7		varchar(75)		null,	/* Valeur du 7eme axe */
Col8		varchar(75)		null,	/* Valeur du 8eme axe */
mt			numeric(14,2)	null,	/* CA */
qte			int				null, 	/* Qte */
cout		numeric(14,2)	null	/* Prix de revient */
)


/* ************************************************************************************************************************************************************* */
/* 1. Selection du detail des lignes concernees pour le calcul des marges : La requete est codee dans @string car de tres nombreux cas de figures sont possibles */
/* ************************************************************************************************************************************************************* */
   
declare @string 	varchar(2000)

declare @file		varchar(32),
		@fileL		varchar(32)

declare @rubDate 	varchar(32),
		@rubQte 	varchar(32),
		@rubMt 		varchar(32),
		@rubCode 	varchar(32),
		@rubCodeL 	varchar(32),
		@rubRep 	varchar(32),
		@rubCl 		varchar(32),
		@rubEnt 	varchar(32),
		@rubAr		varchar(32)

select @rubDate=(case when @type=0 then 'FALDATE' else (case when @TypeDateCde=0 then 'CCLDATE' else 'CCDATECOM' end) end)
select @rubQte=(case when @type=0 then 'FALQTE'  else (case when @type=1 then 'CCLQTE' else 'CCLRESTE' end) end)
select @rubMt=(case when @type=0 then 'FALTOTALHT'  else (case when @type=1 then 'CCLTOTALHT' else 'CCLRESTE*(CCLTOTALHT/CCLQTE)' end) end)
select @rubCode=(case when @type=0 then 'FACODE'  else 'CCCODE' end)
select @rubCodeL=(case when @type=0 then 'FALCODE'  else 'CCLCODE' end)
select @rubRep=(case when @type=0 then 'FALREP'  else 'CCLREP' end)
select @rubCl=(case when @type=0 then 'FACL'  else 'CCLCL' end)
select @rubEnt=(case when @type=0 then 'FALENT'  else 'CCLENT' end)
select @rubAr=(case when @type=0 then 'FALARTICLE'  else 'CCLARTICLE' end)

select @file=(case when @type=0 then 'FFA' else 'FCC' end)
select @fileL=(case when @type=0 then 'FFAL' else 'FCCL' end)

/* Le select travaille avec le detail des lignes FFAL pour le calcul de marge. */
/* Sinon, on regroupe directement les colonnes demandees par l'utilisateur     */

	if (@avecmarge=1)
		select @string="insert into #Detail (SEQ,dat,Col1,Col2,Col3,Col4,Col5,Col6,Col7,Col8,mt,qte,cout) 
				select FALSEQ,FALDATE,"+@select+"FALTOTALHT,FALQTE,0" /* 8 rubriques maximum */ 
	else
		select @string="insert into #Detail (SEQ,dat,Col1,Col2,Col3,Col4,Col5,Col6,Col7,Col8,mt,qte,cout) 
				select 0,(case when "+@rubDate+" between '"+
				convert(varchar(4),datepart(yy,@d1))+"/"+convert(varchar(2),datepart(mm,@d1))+"/"+convert(varchar(4),datepart(dd,@d1))+
				"' and '"+
				convert(varchar(4),datepart(yy,@d2))+"/"+convert(varchar(2),datepart(mm,@d2))+"/"+convert(varchar(4),datepart(dd,@d2))+
				"' then '"+convert(varchar(4),datepart(yy,@d1))+"/"+convert(varchar(2),datepart(mm,@d1))+"/"+convert(varchar(4),datepart(dd,@d1))+
				"' else '"+
				convert(varchar(4),datepart(yy,@d3))+"/"+convert(varchar(2),datepart(mm,@d3))+"/"+convert(varchar(4),datepart(dd,@d3))+
				"' end),"+
				@select+
				"sum("+@rubMt+"),sum("+@rubQte+"),0"

/* from */
									select @string=@string+" from FCL,FAR,"+@file+","+@fileL+",FREP"
if (isnull(@AXCODE,'')!='') 		select @string=@string+",FCLAX"
if (@AXFILE='FAXL') 				select @string=@string+",FAXL"
if @CRITEREDEGRE=1 					select @string=@string+",FCL2"   																											/* -----> MODIF 291007 */

/* where */

/* Groupe general */

select @string=@string+" where "+@rubCode+"="+@rubCodeL+"  and CLCODE="+@rubCl+" and ARCODE="+@rubAr+" and "+@rubRep+"*=RECODE and 
				("+@rubDate+" between '"+convert(varchar(4),datepart(yy,@d1))+"/"+convert(varchar(2),datepart(mm,@d1))+"/"+convert(varchar(4),datepart(dd,@d1))+"' and '"+convert(varchar(4),datepart(yy,@d2))+"/"+convert(varchar(2),datepart(mm,@d2))+"/"+convert(varchar(4),datepart(dd,@d2))+
				"' or "+@rubDate+" between  '"+convert(varchar(4),datepart(yy,@d3))+"/"+convert(varchar(2),datepart(mm,@d3))+"/"+convert(varchar(4),datepart(dd,@d3))+"' and '"+convert(varchar(4),datepart(yy,@d4))+"/"+convert(varchar(2),datepart(mm,@d4))+"/"+convert(varchar(4),datepart(dd,@d4))+"')" 

if (@ent is not null) 		select @string=@string+" and "+@rubEnt+"='"+@ent+"' and CLENT="+@rubEnt
if (isnull(@offert,0)!=0) 	select @string=@string+" and isnull("+@rubMt+",0)!=0"

/* where : Groupe article */
if isnull(@AR1,'')!=''  			select @string=@string+" and ARCODE between '"+@AR1+"' and '"+@AR2+"'"
if isnull(@DEP1,'')!='' 			select @string=@string+" and ARDEPART between '"+@DEP1+"' and '"+@DEP2+"'"
if isnull(@FOURNISSEUR1,'')!='' 	select @string=@string+" and ARFO between '"+@FOURNISSEUR1+"' and '"+@FOURNISSEUR2+"'"
if isnull(@FAMILLE1,'')!='' 		select @string=@string+" and ARFAM between '"+@FAMILLE1+"' and '"+@FAMILLE2+"'"
if isnull(@CAT1,'')!='' 			select @string=@string+" and ARGRFAM between '"+@CAT1+"' and '"+@CAT2+"'"
if isnull(@CPN1,'')!='' 			select @string=@string+" and ARCHEFP between '"+@CPN1+"' and '"+@CPN2+"'"
if isnull(@DECLINAISON11,'')!='' 	select @string=@string+" and ARMATIERE between '"+@DECLINAISON11+"' and '"+@DECLINAISON12+"'"
if isnull(@DECLINAISON21,'')!='' 	select @string=@string+" and ARCOULEUR between '"+@DECLINAISON21+"' and '"+@DECLINAISON22+"'"
if isnull(@DECLINAISON31,'')!='' 	select @string=@string+" and ARGRILLE between '"+@DECLINAISON31+"' and '"+@DECLINAISON32+"'"
if isnull(@DECLINAISON41,'')!='' 	select @string=@string+" and ARCALIBRE between '"+@DECLINAISON41+"' and '"+@DECLINAISON42+"'"
if isnull(@DECLINAISON51,'')!='' 	select @string=@string+" and AREMP between '"+@DECLINAISON51+"' and '"+@DECLINAISON52+"'"
if isnull(@TIERS11,'')!='' 			select @string=@string+" and ARFOREIGN1 between '"+@TIERS11+"' and '"+@TIERS12+"'"
if isnull(@TIERS21,'')!='' 			select @string=@string+" and ARFOREIGN2 between '"+@TIERS21+"' and '"+@TIERS22+"'"
if (@TYPE_AR1=1)					select @string=@string+" and isnull(ARTYPE,0)=0"
if (@TYPE_AR2=1)					select @string=@string+" and isnull(ARTYPE,0)!=3 and isnull(ARTYPE,0)!=4 and isnull(ARTYPE,0)!=7"
									select @string=@string+" and isnull(ARTYPE,0)!=8"

/* where : Groupe client */
if isnull(@ACTIVITE1,'')!='' 		select @string=@string+" and CLSA between '"+@ACTIVITE1+"' and '"+@ACTIVITE2+"'"
if isnull(@PAYS1,'')!='' 			select @string=@string+" and CLPAYS between '"+@PAYS1+"' and '"+@PAYS2+"'"
if isnull(@SALESMAN,'')!='' 		select @string=@string+" and "+@rubRep+" between '"+@SALESMAN+"' and '"+@SALESMAN2+"'"
if isnull(@MARKET1,'')!='' 			select @string=@string+" and CLREGION between '"+@MARKET1+"' and '"+@MARKET2+"'"
if isnull(@CUSTOMER1,'')!='' 		select @string=@string+" and CLCODE between '"+@CUSTOMER1+"' and '"+@CUSTOMER2+"'"
if isnull(@GROUPE,'')!='' 			select @string=@string+" and CLCODEGROUPE = '"+@GROUPE+"'"
if isnull(@CLASSE,'')!='' 			select @string=@string+" and CLCLASSE = '"+@CLASSE+"'"
if @CRITEREDEGRE=1					
select @string=@string+" and CL2DEGRE = " + convert(varchar,@CL2DEGRE) +"  and CL2CODE=CLCODE and CL2ENT=CLENT" 	/* -----> MODIF 291007 */

/* where : Groupe axe */
if (isnull(@AXCODE,'')!='')
begin 			
	if (isnull(@AXSEC,'')!='') 		select @string=@string+" and CLAXSECTION='"+@AXSEC+"'"
	if (isnull(@AXFILE,'')='FAXL')
		begin
									select @string=@string+" and CLCODE=CLAXCLE and CLAXAX='"+@AXCODE+"' and CLAXAX=AXLAX and CLAXSECTION=AXLCODE"
									if (@ent is not null) select @string=@string+" and CLAXENT='"+@ent+"'"
		end
																		
	else
		begin
									select @string=@string+" and CLCODE=CLAXCLE and CLAXAX='"+@AXCODE+"'"
									if (@ent is not null) select @string=@string+" and CLAXENT='"+@ent+"'"
		end
end

/* Group by */
if (@avecmarge=0)
	select @string=@string+" group by 	(case when "+@rubDate+" between '"+
			convert(varchar(4),datepart(yy,@d1))+"/"+convert(varchar(2),datepart(mm,@d1))+"/"+convert(varchar(4),datepart(dd,@d1))+
			"' and '"+
			convert(varchar(4),datepart(yy,@d2))+"/"+convert(varchar(2),datepart(mm,@d2))+"/"+convert(varchar(4),datepart(dd,@d2))+
			"' then '"+convert(varchar(4),datepart(yy,@d1))+"/"+convert(varchar(2),datepart(mm,@d1))+"/"+convert(varchar(4),datepart(dd,@d1))+
			"' else '"+
			convert(varchar(4),datepart(yy,@d3))+"/"+convert(varchar(2),datepart(mm,@d3))+"/"+convert(varchar(4),datepart(dd,@d3))+
			"' end),"+
			(case when charindex("'',",@select)>0 then substring(@select,1,charindex("'',",@select)-2) else substring(@select,1,datalength(@select)-1) end) 

/* select @string */

execute (@string)


declare @i int,@j int
select @j=count(*) from #Detail
select @i=0

create  index seq on #Detail (SEQ)  /* non declare unique car si les marges ne sont pas demandees, on a un SEQ a 0 */
create  index dat on #Detail (dat)  

  
/* ********************* */
/* 2. Calcul de la marge */
/* ********************* */ 

if (@type=0 and @avecmarge=1)
begin
 
	declare	@date					smalldatetime,   
			  	@articlepr		char(15),   
			  	@qte					int,   
			  	@totalht				numeric(14,2),   
			  	@cvlot					int,   
			  	@PrixRevient		numeric(14,4),   
			  	@PrixRevientLigne	numeric(14,2),   
			  	@seq					int,   
			  	@lettre				char(4),   
			  	@arprm				numeric(14,4),   
			  	@facode				char(10),
			  	@fallettre		char(4),
			  	@falfrais			numeric(14,2),
			  	@falpaht			numeric(14,2)
	 
		   
	declare factures cursor    
	for select SEQ,dateadd(hh,19,FALDATE),FALARTICLE,FALQTE,FALTOTALHT,CVLOT,FALLETTRE,isnull(ARPRM,0),FALCODE ,FALLETTRE, isnull(FALFRAIS,0),isnull(FALPAHT,0)
	from #Detail,FFAL,FAR,FCV   
	where FALSEQ=SEQ   
	and ARCODE=FALARTICLE   
	and ARUNITACHAT=CVUNIF   
	order by SEQ   

	open factures   
	   
	fetch factures   
	into @seq,@date,@articlepr,@qte,@totalht,@cvlot,@lettre,@arprm,@facode ,@fallettre, @falfrais, @falpaht
	   
	while (@@sqlstatus = 0)   
	begin   
		select 	@PrixRevient = 0,   
				@PrixRevientLigne = 0 
		
		if (isnull(@fallettre,"") = "")			/* Les Articles sans code stock n'ont pas de prix de revient */
		begin
				select 	@PrixRevient = 0,   
						@PrixRevientLigne = 0
		end 
		else if @modevalo = 0										/*--------------------- FIFO */   
		begin   
		   
		  select @PrixRevient = round((STPAHT+STFRAIS)/@cvlot,4)   
		  from FSTOCK   
		  where STAR=@articlepr   
		  and STLETTRE=@lettre   
		   
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais
		end   
		else if @modevalo = 1									/*--------------------- PRM */   
		begin   
		  select @PrixRevientLigne = convert(numeric(14,2),@arprm * @qte) + @falfrais   
		end   
		else if @modevalo = 2									/*--------------------- PUMP */   
		begin   
		  select @PrixRevient=isnull(PUMP,0)   
		  from FPUM   
		  where PUMAR = @articlepr   
		  and PUMDATE <= convert (smalldatetime, @date)   
		  having PUMAR = @articlepr   
		  and PUMDATE <= convert (smalldatetime, @date)   
		  and PUMDATE = max(PUMDATE)   
		     
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais   
		end   
		else if @modevalo = 3								/*--------------------- PRM Mensuel */   
		begin   
		  set rowcount 1   
		     
		  select @PrixRevient=isnull(PRM,0)   
		  from FPRM   
		  where PRMAR = @articlepr   
		  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))   
		  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))   
		  and PRMAR = @articlepr   
		  order by PRMAN desc,PRMMOIS desc   
		     
		  set rowcount 0   
		     
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais			   
		end   
		else  if @modevalo = 4								/*--------------------- DPA unitaire */   
		begin   
		  set rowcount 1   
		     
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/@cvlot,4)   
		  from FBLL   
		  where BLLAR=@articlepr   
		  having BLLAR=@articlepr   
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))   
		   
		  if isnull(@PrixRevient,0)=0   
		  begin   
				select @PrixRevient = round((SILPAHT+SILFRAIS)/@cvlot,4)   
				from FSIL   
				where SILARTICLE=@articlepr   
				having SILARTICLE=@articlepr   
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))   
		  end   
	 
		  set rowcount 0   
		     
		  if @PrixRevient is null   
		    select @PrixRevient = 0  
		    
		   select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais 
	   
		end 
		else if @modevalo = 5									/*--------------------- PAUHT */   
		begin   
			select @PrixRevient = @falpaht   
		  select @PrixRevientLigne = convert(numeric(14,2),@falpaht * @qte) 
		end   
		
		select @i=@i+1
		/* select @i,"/",@j,"pr :",@PrixRevient,"pr ligne :"	,@PrixRevientLigne */
		update #Detail set cout=@PrixRevientLigne where SEQ=@seq
	 
		fetch factures   
		into @seq,@date,@articlepr,@qte,@totalht,@cvlot,@lettre,@arprm,@facode ,@fallettre, @falfrais, @falpaht  
		   
	end
	close factures  
	deallocate cursor factures
	
end


/* ****************************************** */
/* 3. Renvoi du resultat regroupe par colonne */
/* ****************************************** */

/* select * from #Detail */

select Col1,Col2,Col3,Col4,Col5,Col6,Col7,Col8,
sum((case when dat between @d1 and @d2 then mt else 0 end)),
sum((case when dat between @d1 and @d2 then 0 else mt end)),
sum((case when dat between @d1 and @d2 then qte else 0 end)),
sum((case when dat between @d1 and @d2 then 0 else qte end)),
sum((case when dat between @d1 and @d2 then cout else 0 end)),
sum((case when dat between @d1 and @d2 then 0 else cout end))
from #Detail
group by Col1,Col2,Col3,Col4,Col5,Col6,Col7,Col8
order by Col1,Col2,Col3,Col4,Col5,Col6,Col7,Col8
 

drop table #Detail  
   
end
go

