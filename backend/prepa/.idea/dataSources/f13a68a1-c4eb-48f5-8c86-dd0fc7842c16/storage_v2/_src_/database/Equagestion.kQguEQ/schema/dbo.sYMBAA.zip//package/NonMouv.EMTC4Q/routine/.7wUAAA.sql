


create procedure NonMouv (@ent			char(5)	= null,
						  @date1		smalldatetime,
						  @date2		smalldatetime,
						  @famille		char(8) = null,
						  @qte			int		= null,
						  @depart		char(8) = null,
						  @marque		char(12) = null
						  )
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
article		char(15)		not null,
quantite	int					null,
paht		numeric(14,2)		null,
datein		datetime			null,
dateout		datetime			null
)


/* Selection des articles en stock */

insert into #Far (article,quantite,paht)
select STAR,sum(STQTE),round(sum((STPAHT+STFRAIS)/CVLOT*STQTE),2)
from FSTOCK,FAR,FCV,FDP
where ARCODE=STAR
and ARUNITACHAT=CVUNIF
and STQTE > 0
and AROLD=0
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and STDATEENTR < @date1
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by STAR

create unique clustered index article on #Far (article)

/* Selection des articles mouvementes en sortie */

select BELARTICLE, BELQTE=sum(BELQTE)
into #Exp
from FBEL,FAR
where BELDATE between @date1 and @date2
and ARCODE=BELARTICLE
and (@famille is null or ARFAM=@famille)
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@ent is null or BELENT=@ent)
group by BELARTICLE
having (@qte is null or sum(BELQTE) >= @qte)

create unique clustered index article on #Exp (BELARTICLE)

/* Suppression des articles mouvementes de la selection */

delete from #Far
where exists (select * from #Exp where #Exp.BELARTICLE=#Far.article)

drop table #Exp

/* Selection des dates d''entree des articles non mouvementes en sortie - FBLL */

select BLLAR,BLLDATE=max(BLLDATE)
into #BLL
from FBLL,#Far
where BLLDATE < @date1
and BLLAR=article
and (@ent is null or BLLENT=@ent)
group by BLLAR

create unique clustered index article on #BLL (BLLAR)

/* Selection des dates d''entree des articles non mouvementes en sortie absents des BLL - FSIL */

insert into #BLL (BLLAR,BLLDATE)
select SILARTICLE,max(SILDATE)
from FSIL,#Far
where SILDATE < @date1
and not exists (select * from #BLL where BLLAR=FSIL.SILARTICLE)
group by SILARTICLE


/* Date de derniere sortie */

select BELARTICLE,BELDATE=max(BELDATE)
into #BEL
from FBEL,#Far
where BELDATE < @date1
and BELARTICLE=article
and (@ent is null or BELENT=@ent)
group by BELARTICLE

create unique clustered index article on #BEL (BELARTICLE)


/*---------- Resultat final --------*/

select ChefProd=ARCHEFP,Departement=ARDEPART,Marque=ARFO,Famille=ARFAM,Article=article,Designation=ARLIB,
	   Quantite=quantite,Total=paht,
	   Date_de_derniere_entree=convert(char,BLLDATE,102),
	   Date_de_derniere_sortie=convert(char,BELDATE,102),
	   PV_principal_HT=ARPVHT
from #Far,#BLL,#BEL,FAR
where article*=BLLAR
and article*=BELARTICLE
and article*=ARCODE


drop table #Far
drop table #BLL
drop table #BEL

end



go

