


create procedure Maj_PRM_Mensuel   (@an	int=null,
									@mois	int=null
								   )			

with recompile
as
begin

	declare @datemaj	datetime
	select @datemaj=dateadd(mm,-1,getdate())

	if @an is null select @an=datepart(yy,@datemaj)
	if @mois is null select @mois=datepart(mm,@datemaj)

	declare @seq		int
	declare @userid		int
	
	select @seq=value from KSeq where name='FPRM'
	select @userid=(select user_id())

	create table #temp
	(
		seq				numeric(7) 		identity,
		PRMAR          	char(15)		not null,
		PRMAN          	smallint		not null,
		PRMMOIS      	tinyint			not null,
		PRM            	numeric(14,2)			,
		PRMUSERCRE     	int				not null,
		PRMDATECRE     	datetime		not null,
		PRMUSERMDF     	int 			not null,	
		PRMDATEMDF     	datetime		not null
	)

		
	insert into #temp (PRMAR,PRMAN,PRMMOIS ,PRM,PRMUSERCRE,PRMDATECRE,PRMUSERMDF,PRMDATEMDF)
	select ARCODE,@an,@mois,isnull(ARPRM,0),@userid,getdate(),@userid,getdate()
	from FAR

	insert into FPRM (PRMSEQ,PRMAR,PRMAN,PRMMOIS ,PRM,PRMUSERCRE,PRMDATECRE,PRMUSERMDF,PRMDATEMDF)     
		select @seq+seq,PRMAR,PRMAN,PRMMOIS,PRM,PRMUSERCRE,PRMDATECRE,PRMUSERMDF,PRMDATEMDF
		from #temp

	select "Mise a jour des PRM mensuels sur ",@@rowcount," articles"

	update KSeq set value=(select max(PRMSEQ)+1 from FPRM) where name='FPRM'


	drop table #temp
		

end



go

