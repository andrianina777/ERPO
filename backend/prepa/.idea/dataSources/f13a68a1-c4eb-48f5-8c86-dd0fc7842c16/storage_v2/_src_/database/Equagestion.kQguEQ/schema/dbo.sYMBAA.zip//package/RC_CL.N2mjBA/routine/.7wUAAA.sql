


/* Renvoie les remises d''un client sur un article */

create procedure RC_CL (@ent		char(5) = null,
						@client		char(12),
						@annee		smallint,
						@article	char(15),
						@rcr1		numeric(8,4) output,
						@rcr2		numeric(8,4) output,
						@rcr3		numeric(8,4) output
						)
with recompile
as
begin

set arithabort numeric_truncation off


declare @depart		char(8),
		@arfo		char(12),
		@arfam		char(8),
		@categ		char(8),
		@tarif		char(8),
		@clgroupe	char(12),
		@result		int,
		@rcpr1		tinyint ,
		@rcpr2		tinyint,
		@rcpr3		tinyint,
		@rcprfa		tinyint,
		@rcrfa		numeric(8,4),
		@r1			numeric(8,4),
		@r2			numeric(8,4),
		@r3			numeric(8,4),
		@remdif		tinyint,
		@prixnet	tinyint
		
		
		
select @depart=ARDEPART, @arfo=ARFO, @arfam=ARFAM, @categ=ARGRFAM, @remdif=ARREMDIF, @prixnet=ARPRIXNET
from FAR
where ARCODE=@article


select @r1=0,@r2=0,@r3=0

if @prixnet=1
begin
	select @rcr1=0,@rcr2=0,@rcr3=0
	return
end

select @r1=isnull(NR1,0),@r2=isnull(NR2,0),@r3=isnull(NR3,0) from FNR,FCL
where CLCODE=@client
and CLNIVREM=NRCODE
and (@ent is null or (NRENT=@ent and CLENT=@ent))

if @remdif=1
begin
	select @rcr1=0,@rcr2=0,@rcr3=0
	return
end

select @tarif=isnull(CLTARIF,"")
from FCL
where CLCODE=@client
and (@ent is null or CLENT=@ent)


				/* -----------------------------  recherche sur remises client */

execute @result = RCRFA @ent,@client,@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,@tarif,@depart,@categ,@article

if @result = 0
begin
	if @rcpr1=0 select @rcr1=@r1
	if @rcpr2=0 select @rcr2=@r2
	if @rcpr3=0 select @rcr3=@r3
	return										/* retour car une correspondance a ete trouvee */
end

				/* -----------------------------  recherche sur remises du groupement du client */

select @clgroupe=CLCODEGROUPE
from FCL
where CLCODE=@client
and CLTYPECLI=2
and (@ent is null or CLENT=@ent)

select @tarif=CLTARIF
from FCL
where CLCODE=@clgroupe
and (@ent is null or CLENT=@ent)


if @@rowcount = 1
begin
	execute @result = RCRFA @ent,@clgroupe,@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,@tarif,@depart,@categ,@article

	if @result = 0
	begin
		if @rcpr1=0 select @rcr1=@r1
		if @rcpr2=0 select @rcr2=@r2
		if @rcpr3=0 select @rcr3=@r3
		return										/* retour car une correspondance a ete trouvee */
	end
end

				/* -----------------------------  recherche sur remises generales clients avec tarif */

select @tarif=CLTARIF
from FCL
where CLCODE=@client
and (@ent is null or CLENT=@ent)

execute @result = RCRFA @ent,'',@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,@tarif,@depart,@categ,@article

if @result = 0
begin
	if @rcpr1=0 select @rcr1=@r1
	if @rcpr2=0 select @rcr2=@r2
	if @rcpr3=0 select @rcr3=@r3
	return										/* retour car une correspondance a ete trouvee */
end

				/* -----------------------------  recherche sur remises generales clients */

execute @result = RCRFA @ent,'',@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,'',@depart,@categ,@article

if @result = 0
begin
	if @rcpr1=0 select @rcr1=@r1
	if @rcpr2=0 select @rcr2=@r2
	if @rcpr3=0 select @rcr3=@r3
	return										/* retour car une correspondance a ete trouvee */
end


select @rcr1=@r1,@rcr2=@r2,@rcr3=@r3
	
end



go

