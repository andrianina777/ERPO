


create procedure CA_Clients (@ent	char(5)	= null,
							 @an	smallint)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Finale
(
client		char(12)		not null,
numcompta	char(12)		not null,
nom			varchar(35)		not null,
adr1		varchar(50)			null,
adr2		varchar(50)			null,
cp			varchar(12)			null,
ville		varchar(30)			null,
pays		varchar(30)			null,
CA_HRFA		numeric(14,2)	not null,
marge		numeric(14,2)	not null,
RFA			numeric(14,2)		null,
nbfact		int					null,
nbavoirs	int					null
)

declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@client			char(12),
		@rfadue			numeric(14,2),
		@nbrefact		int,
		@nbreavoirs		int


select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))



insert into #Finale (client,numcompta,nom,adr1,adr2,cp,ville,pays,CA_HRFA,marge,RFA,nbfact,nbavoirs)
select STCL,CLNUMCOMPTABLE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLPAYS,sum(STCAFA),sum(STCAFA)-sum(STPR),0,0,0
from FST,FCL,FAR
where CLCODE=STCL
and ARCODE=START
and STAN=@an
and ARTYPE != 6
and (@ent is null or (STENT=@ent and CLENT=STENT))
group by STCL,CLNUMCOMPTABLE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLPAYS

create unique index client on #Finale (client)


declare rfa cursor 
for select client
from #Finale
for update of RFA,nbfact,nbavoirs

open rfa

fetch rfa
into @client

while (@@sqlstatus = 0)
  begin
	

	exec RFA_client_out @ent,@client,@an,@rfadue output
	
	select @nbrefact=count(*) from FFA (index date)
	where FACL=@client
	and FADATE between @smalldate1 and @smalldate2
	and FANETAPAYER>=0
	and (@ent is null or FAENT=@ent)
	
	select @nbreavoirs=count(*) from FFA (index date)
	where FACL=@client
	and FADATE between @smalldate1 and @smalldate2
	and FANETAPAYER<0
	and (@ent is null or FAENT=@ent)
	
	
	update #Finale
	set RFA=@rfadue,nbfact=@nbrefact,nbavoirs=@nbreavoirs
	where current of rfa
	
	
	fetch rfa
	into @client
	
  end

close rfa
deallocate cursor rfa


select client,numcompta,nom,adr1,adr2,cp,ville,pays,CA_HRFA,marge,RFA,nbfact,nbavoirs
from #Finale
order by client
compute sum(CA_HRFA),sum(marge),sum(RFA),sum(nbfact),sum(nbavoirs)


drop table #Finale

end



go

