


/* Procedure permettant de verifier la rotation des stocks sur une annee
	depuis les fichiers FSTCC et FSK  */
	
	
create procedure A_Rotation	(@Annee		smallint,
						   	 @chef		char(8) = null,
							 @fournis	char(12)	= null,
							 @famille	char(8)	= null,
							 @article	char(15)	= null
							)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date		datetime
select  @date = convert(datetime,convert(char(2),datepart(mm,getdate()))
						+"/01/"+convert(char(4),datepart(yy,getdate())))
declare @mois		tinyint
declare @lemois		tinyint
declare @moisinit	tinyint
select  @moisinit = datepart(mm,getdate())


declare @Janvier	numeric(16,5)
declare @Fevrier	numeric(16,5)
declare @Mars		numeric(16,5)
declare @Avril		numeric(16,5)
declare @Mai		numeric(16,5)
declare @Juin		numeric(16,5)
declare @Juillet	numeric(16,5)
declare @Aout		numeric(16,5)
declare @Septembre	numeric(16,5)
declare @Octobre	numeric(16,5)
declare @Novembre	numeric(16,5)
declare @Decembre	numeric(16,5)

declare @JanvierS	numeric(16,5)
declare @FevrierS	numeric(16,5)
declare @MarsS		numeric(16,5)
declare @AvrilS		numeric(16,5)
declare @MaiS		numeric(16,5)
declare @JuinS		numeric(16,5)
declare @JuilletS	numeric(16,5)
declare @AoutS		numeric(16,5)
declare @SeptembreS	numeric(16,5)
declare @OctobreS	numeric(16,5)
declare @NovembreS	numeric(16,5)
declare @DecembreS	numeric(16,5)


create table #Cdes
(
Qte		int		null,
Mois	tinyint	null
)

create table #Stock
(
Qte		int		null,
Mois	tinyint	null
)

create table #AR
(
Article		char(15)		not null,
Prix		numeric(14,2)		null
)


if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFAM=@famille
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFO=@fournis
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
	end
else if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCODE=@article
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFO=@fournis
		and ARCODE=@article
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end


create unique clustered index article on #AR (Article)


set forceplan on

insert into #Cdes (Qte,Mois)
select sum(STCCQTE),STCCMOIS
from #AR,FSTCC
where STCCART=Article
and STCCAN=@Annee
group by STCCMOIS

set forceplan off


select @Janvier=Qte		from #Cdes where Mois=1
select @Fevrier=Qte		from #Cdes where Mois=2
select @Mars=Qte		from #Cdes where Mois=3
select @Avril=Qte		from #Cdes where Mois=4
select @Mai=Qte			from #Cdes where Mois=5
select @Juin=Qte		from #Cdes where Mois=6
select @Juillet=Qte		from #Cdes where Mois=7
select @Aout=Qte		from #Cdes where Mois=8
select @Septembre=Qte	from #Cdes where Mois=9
select @Octobre=Qte		from #Cdes where Mois=10
select @Novembre=Qte	from #Cdes where Mois=11
select @Decembre=Qte	from #Cdes where Mois=12


if (@Janvier is null)		select @Janvier=0
if (@Fevrier is null)		select @Fevrier=0
if (@Mars is null)			select @Mars=0
if (@Avril is null)			select @Avril=0
if (@Mai is null)			select @Mai=0
if (@Juin is null)			select @Juin=0
if (@Juillet is null)		select @Juillet=0
if (@Aout is null)			select @Aout=0
if (@Septembre is null)		select @Septembre=0
if (@Octobre is null)		select @Octobre=0
if (@Novembre is null)		select @Novembre=0
if (@Decembre is null)		select @Decembre=0


select @Fevrier=@Janvier+@Fevrier
select @Mars=@Fevrier+@Mars
select @Avril=@Mars+@Avril
select @Mai=@Avril+@Mai
select @Juin=@Mai+@Juin
select @Juillet=@Juin+@Juillet
select @Aout=@Juillet+@Aout
select @Septembre=@Aout+@Septembre
select @Octobre=@Septembre+@Octobre
select @Novembre=@Octobre+@Novembre
select @Decembre=@Novembre+@Decembre

set forceplan on

insert into #Stock (Qte,Mois)
select sum(SKQTE),SKMOIS
from #AR,FSK(index code)
where SKARTICLE=Article
and SKAN=@Annee
group by SKMOIS

set forceplan off

select @mois=1

while (@mois <= 12)
begin
  select @lemois=Mois from #Stock
  where Mois=@mois
  
  if (@@rowcount = 0) insert into #Stock values(0,@mois)
  
  select @mois = @mois + 1
end


/* Maj des stocks projetes si annee >= annee en cours */

if (@Annee >= datepart(yy,getdate()))
begin
  select @lemois=@moisinit + 1
  
  while (@lemois <= 12)
  begin
	 
  update #Stock
  set Qte=Qte-(select sum(Qte) from #Cdes
			  where #Cdes.Mois between @moisinit and @lemois - 1)
  where #Stock.Mois = @lemois   
	 
	select @lemois = @lemois + 1
  end
end


select @JanvierS=avg(Qte)		from #Stock where Mois=1
select @FevrierS=avg(Qte)		from #Stock where Mois between 1 and 2
select @MarsS=avg(Qte)			from #Stock where Mois between 1 and 3
select @AvrilS=avg(Qte)			from #Stock where Mois between 1 and 4
select @MaiS=avg(Qte)			from #Stock where Mois between 1 and 5
select @JuinS=avg(Qte)			from #Stock where Mois between 1 and 6
select @JuilletS=avg(Qte)		from #Stock where Mois between 1 and 7
select @AoutS=avg(Qte)			from #Stock where Mois between 1 and 8
select @SeptembreS=avg(Qte)		from #Stock where Mois between 1 and 9
select @OctobreS=avg(Qte)		from #Stock where Mois between 1 and 10
select @NovembreS=avg(Qte)		from #Stock where Mois between 1 and 11
select @DecembreS=avg(Qte)		from #Stock where Mois between 1 and 12


if ((@JanvierS is null)		or (@JanvierS<=0))	select @Janvier=0,	@JanvierS=1
if ((@FevrierS is null)		or (@FevrierS<=0))	select @Fevrier=0,	@FevrierS=1
if ((@MarsS is null)		or (@MarsS<=0))		select @Mars=0,		@MarsS=1
if ((@AvrilS is null)		or (@AvrilS<=0))	select @Avril=0,	@AvrilS=1
if ((@MaiS is null)			or (@MaiS<=0))		select @Mai=0,		@MaiS=1
if ((@JuinS is null)		or (@JuinS<=0))		select @Juin=0,		@JuinS=1
if ((@JuilletS is null) 	or (@JuilletS<=0))	select @Juillet=0,	@JuilletS=1
if ((@AoutS is null)		or (@AoutS<=0))		select @Aout=0,		@AoutS=1
if ((@SeptembreS is null)	or (@SeptembreS<=0)) select @Septembre=0,@SeptembreS=1
if ((@OctobreS is null)		or (@OctobreS<=0))	select @Octobre=0,	@OctobreS=1
if ((@NovembreS is null)	or (@NovembreS<=0))	select @Novembre=0,	@NovembreS=1
if ((@DecembreS is null)	or (@DecembreS<=0))	select @Decembre=0,	@DecembreS=1



drop table #AR

select 	@Janvier/@JanvierS,
		@Fevrier/@FevrierS,
		@Mars/@MarsS,
		@Avril/@AvrilS,
		@Mai/@MaiS,
		@Juin/@JuinS,
		@Juillet/@JuilletS,
		@Aout/@AoutS,
		@Septembre/@SeptembreS,
		@Octobre/@OctobreS,
		@Novembre/@NovembreS,
		@Decembre/@DecembreS
		
drop table #Cdes
drop table #Stock

end



go

