



/* Procedure renvoyant les chiffres d''affaires, marges, objectifs 
pour les annees N-1, annee et mois en cours pour les opticiens */

create procedure CA_OptImp (@ent	char(5) = null)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Final
	(
	CA_mois_0		numeric(14,2)	null,
	CA_mois_1		numeric(14,2)	null,
	Marge_mois_0	numeric(14,2)	null,
	CA_an_0			numeric(14,2)	null,
	CA_an_1			numeric(14,2)	null,
	Marge_an_0		numeric(14,2)	null,
	Obj_mois_0		numeric(14,2)	null,
	Obj_an_0		numeric(14,2)	null
	)
	
	declare @mois	tinyint,
			@an		smallint
			
	select @mois = datepart(mm,getdate()),
		   @an   = datepart(yy,getdate())
		
	
	insert into #Final (CA_an_1,CA_an_0,Marge_an_0)
	select   sum(isnull(STCAFA,0)*(1-sign(abs(STAN-@an+1)))),
			 sum(isnull(STCAFA,0)*(1-sign(abs(STAN-@an)))),
			 sum(isnull(STCAFA,0)*(1-sign(abs(STAN-@an))))-sum(isnull(STPR,0)*(1-sign(abs(STAN-@an))))
	from FST,FCL
	where CLCODE = STCL
	and CLSA = "OPTIC"
	and (@ent is null or (STENT=@ent and CLENT=@ent))
	
	
	insert into #Final (CA_mois_0,Marge_mois_0)
	select   sum(isnull(STCAFA,0)),sum(isnull(STCAFA,0))-sum(isnull(STPR,0))
	from FST,FCL
	where CLCODE = STCL
	and CLSA = "OPTIC"
	and STMOIS = @mois
	and STAN = @an
	and (@ent is null or (STENT=@ent and CLENT=@ent))
	
	insert into #Final (CA_mois_1)
	select   sum(isnull(STCAFA,0))
	from FST,FCL
	where CLCODE = STCL
	and CLSA = "OPTIC"
	and STMOIS = @mois
	and STAN = @an-1
	and (@ent is null or (STENT=@ent and CLENT=@ent))
	
	insert into #Final (Obj_mois_0)
	select isnull(OBRCA,0)
	from FOBR
	where OBRCODE = 'OPTIQUE'
	and OBRMOIS = @mois
	and OBRAN = @an
	and (@ent is null or OBRENT=@ent)
	
	insert into #Final (Obj_an_0)
	select sum(isnull(OBRCA,0))
	from FOBR
	where OBRCODE = 'OPTIQUE'
	and OBRAN = @an
	and (@ent is null or OBRENT=@ent)

	select  "OPTICIENS",sum(isnull(CA_mois_0,0)),sum(isnull(CA_mois_1,0)),sum(isnull(Marge_mois_0,0)),
			sum(isnull(CA_an_0,0)),sum(isnull(CA_an_1,0)),sum(isnull(Marge_an_0,0)),
			sum(Obj_mois_0),(sum(isnull(CA_mois_0,0))/(sum(Obj_mois_0)+1))*100,sum(Obj_an_0),
			(sum(isnull(CA_an_0,0))/(sum(Obj_an_0)+1))*100
	from #Final
	
	
	drop table #Final

end



go

