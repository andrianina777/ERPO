


/* Procedure renvoyant les lignes de mouvements entre deux dates */


create procedure Mouvements	(@datedeb	smalldatetime,
							 @datefin	smalldatetime
							)
with recompile
as
begin


select Article=FALARTICLE,Des_type="Factures&Avoirs_Clients",Type="FA",Date=FALDATE,
	Quantite=sum(FALQTE),Valeur=round(sum((STPAHT+STFRAIS)/CVLOT*FALQTE),2)
from FFAL,FSTOCK,FAR,FCV
where FALDATE between @datedeb and @datefin
and FALARTICLE=STAR
and FALLETTRE=STLETTRE
and ARCODE=FALARTICLE
and ARUNITACHAT=CVUNIF
and FALQTE!=0
group by FALARTICLE,FALDATE

union

select BELARTICLE,"Expeditions&Retours_Clients","BE",BELDATE,sum(BELQTE),round(sum((STPAHT+STFRAIS)/CVLOT*BELQTE),2)
from FBEL,FSTOCK,FAR,FCV
where BELDATE between @datedeb and @datefin
and BELARTICLE=STAR
and BELLETTRE=STLETTRE
and ARCODE=BELARTICLE
and ARUNITACHAT=CVUNIF
and BELQTE!=0
group by BELARTICLE,BELDATE

union

select BLLAR,"Livraisons_Fournisseurs","BL",BLLDATE,sum(BLLQTE),sum(BLLPRHT*BLLQTE)
from FBLL
where BLLDATE between @datedeb and @datefin
and BLLQTE!=0
group by BLLAR,BLLDATE

union

select RFLARTICLE,"Retours_Fournisseurs","RF",RFLDATE,sum(RFLQTE),round(sum((STPAHT+STFRAIS)/CVLOT*RFLQTE),2)
from FRFL,FSTOCK,FAR,FCV
where RFLDATE between @datedeb and @datefin
and RFLARTICLE=STAR
and RFLLETTRE=STLETTRE
and ARCODE=RFLARTICLE
and ARUNITACHAT=CVUNIF
and RFLQTE!=0
group by RFLARTICLE,RFLDATE

union

select DOLAR,"Sorties_Douanes","DO",DOLDATE,sum(DOLQTE),sum(DOLTOTHT)
from FDOL
where DOLDATE between @datedeb and @datefin
group by DOLAR,DOLDATE

union

select SILARTICLE,"Stock_Init_Fluctuations_Transferts","SI",SILDATE,sum(SILQTE),round(sum((SILPAHT+SILFRAIS)/CVLOT*SILQTE),2)
from FSIL,FSTOCK,FAR,FCV
where SILDATE between @datedeb and @datefin
and SILARTICLE=STAR
and SILLETTRE=STLETTRE
and ARCODE=SILARTICLE
and ARUNITACHAT=CVUNIF
and SILQTE!=0
group by SILARTICLE,SILDATE

union

select RJLARTICLE,"Reajustements","RJ",RJLDATE,sum(RJLQTE),round(sum((STPAHT+STFRAIS)/CVLOT*RJLQTE),2)
from FRJL,FSTOCK,FAR,FCV
where RJLDATE between @datedeb and @datefin
and RJLARTICLE=STAR
and RJLLETTRE=STLETTRE
and ARCODE=RJLARTICLE
and ARUNITACHAT=CVUNIF
and RJLQTE!=0
group by RJLARTICLE,RJLDATE

union

select LCLARTICLE,"Casse","LC",LCLDATE,sum(LCLQTE),round(sum((STPAHT+STFRAIS)/CVLOT*LCLQTE),2)
from FLCL,FSTOCK,FAR,FCV
where LCLDATE between @datedeb and @datefin
and LCLARTICLE=STAR
and LCLLETTRE=STLETTRE
and ARCODE=LCLARTICLE
and ARUNITACHAT=CVUNIF
and LCLQTE!=0
group by LCLARTICLE,LCLDATE

union

select ASLARTICLE,"Assemblage_Desassemblage","AS",ASLDATE,sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE)
from FASL
where ASLDATE between @datedeb and @datefin
group by ASLARTICLE,ASLDATE


union

select FFLAR,"Factures&Avoirs_Fournisseurs","FF",FFLDATE,sum(FFLQTE),round(sum((STPAHT+STFRAIS)/CVLOT*FFLQTE),2)
from FFFL,FSTOCK,FAR,FCV
where FFLDATE between @datedeb and @datefin
and FFLAR=STAR
and FFLLETTRE=STLETTRE
and ARCODE=FFLAR
and ARUNITACHAT=CVUNIF
and FFLQTE!=0
group by FFLAR,FFLDATE


end



go

