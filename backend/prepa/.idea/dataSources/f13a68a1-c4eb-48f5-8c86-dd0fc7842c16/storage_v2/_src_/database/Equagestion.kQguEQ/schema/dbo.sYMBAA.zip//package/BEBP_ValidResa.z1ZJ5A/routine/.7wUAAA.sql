
create procedure BEBP_ValidResa (	@Depot			char(4),
									@result			tinyint = 0		/*  = 1 si renvoie resultat		*/
								)   
with recompile						
as
begin

set arithabort numeric_truncation off

declare @vgspid	int
select @vgspid = @@spid


/*	Table PREP_TEMP par ordre 		:	TEMP_CCDATECRE	TEMP_CCLCODE TEMP_CCLNUM	*/
/* ******************************************************************************** */
declare @larticle		char(15),
		@stockdispo		int,
		@vatest			numeric(14,2),
		@ccldateresfin	smalldatetime,
		@cclqteres		int,
		@vaqteares		int,
		@seq			int

declare @ligneResa	int

declare LigneCde cursor
for select	TEMP_CCLSEQ,TEMP_CCLARTICLE, TEMP_VATEST, TEMP_CCLQTERES, TEMP_VAQTEARES, TEMP_CCLDATERESFIN
from PREP_TEMP
where TEMP_ID = @vgspid
and TEMP_VATEST = 1
order by TEMP_CCDATECRE, TEMP_CCLCODE, TEMP_CCLNUM
for read only

select @ligneResa = 0

open LigneCde
fetch LigneCde into @seq, @larticle, @vatest, @cclqteres, @vaqteares, @ccldateresfin 

while (@@sqlstatus=0)
begin 

		if @vatest = 1
		begin
		
			select @stockdispo = TEMP_VASTDEPDISPO
			from PREP_TEMP
			where TEMP_ID = @vgspid and TEMP_CCLSEQ=@seq		/* recalcul en cours	*/	 

/*	select 'debug',"@vatest = 1", @stockdispo, @seq, @larticle, @vatest, @cclqteres, @vaqteares, @ccldateresfin	*/
			
			if @vaqteares = 0
			begin  
				update FCCL set CCLQTERES=0, CCLDATERESFIN=null, CCLDEPOTRES=null where CCLSEQ=@seq
				select @ligneResa = @ligneResa + 1
				update PREP_TEMP set TEMP_CCLQTERES=0 where TEMP_ID = @vgspid and TEMP_CCLSEQ=@seq
			end
			else if @vaqteares <= @stockdispo
			begin  
				update FCCL set CCLQTERES=@vaqteares, CCLDATERESFIN=@ccldateresfin, CCLDEPOTRES=@Depot where CCLSEQ=@seq
				select @ligneResa = @ligneResa + 1
				update PREP_TEMP set TEMP_CCLQTERES=@vaqteares where TEMP_ID = @vgspid and TEMP_CCLSEQ=@seq
			end
			else if @vaqteares > @stockdispo
			begin  
				update FCCL set CCLQTERES=@stockdispo, CCLDATERESFIN=@ccldateresfin, CCLDEPOTRES=@Depot where CCLSEQ=@seq
				select @ligneResa = @ligneResa + 1
				update PREP_TEMP set TEMP_CCLQTERES=@stockdispo, TEMP_VAQTEARES=@stockdispo where TEMP_ID = @vgspid and TEMP_CCLSEQ=@seq
			end

			select @stockdispo = @stockdispo - @cclqteres
	
/*	select 'debug',"fin", @stockdispo, @seq, @larticle	*/
	
			/*	Repartition de @stockdispo sur toutes les lignes de cdes de cet article	*/
			update PREP_TEMP set TEMP_VASTDEPDISPO = @stockdispo where TEMP_ID = @vgspid and TEMP_CCLARTICLE=@larticle		
	
		end	
	
		fetch LigneCde into @seq, @larticle, @vatest, @cclqteres, @vaqteares, @ccldateresfin
end

if @result = 1
		select @ligneResa


end
go

