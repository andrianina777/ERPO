


/* Procedure utilisee pour le calcul du droit a la RFA d''un client
	sur une ligne de facture */

create procedure RFA_CL(@ent		char(5) = null,
						@client		char(12),
						@annee		smallint,
						@article	char(15),
						@valeur		numeric(14,2),
						@carfa		numeric(14,2) output,
						@rfact		numeric(14,2) output
						)
with recompile
as
begin

set arithabort numeric_truncation off


declare @arfo		char(12),
		@arfam		char(8),
		@arsansrfa	tinyint,
		@clgroupe	char(12),
		@result		int,
		@rcpr1		tinyint ,
		@rcr1		numeric(8,4),
		@rcpr2		tinyint,
		@rcr2		numeric(8,4),
		@rcpr3		tinyint,
		@rcr3		numeric(8,4),
		@rcprfa		tinyint,
		@rcrfa		numeric(8,4),
		@tarif		char(8),
		@depart		char(8),
		@categ		char(8)
		
		
select @depart=ARDEPART, @arfo=ARFO, @arfam=ARFAM, @categ=ARGRFAM, @arsansrfa=ARSANSRFA
from FAR
where ARCODE=@article


select @tarif=CLTARIF from FCL where CLCODE=@client

if @arsansrfa=1 
begin 
	select @carfa=0,@rfact=0 return						/* retour si le produit est sans RFA */
end	

				/* recherche des RFA sur remises client */

execute @result = RCRFA @ent,@client,@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,@tarif,@depart,@categ,@article


if @result = 0
begin
	if @rcprfa=1
	begin
		select 	@carfa=0,
				@rfact=round((@valeur*@rcrfa),2)
	end
	else if @rcprfa=0
	begin
		select 	@carfa=@valeur,
				@rfact=0
	end
	return										/* retour car une correspondance a ete trouvee */
end


select @clgroupe=CLCODEGROUPE from FCL
where CLCODE=@client
and CLTYPECLI=2
and (@ent is null or CLENT=@ent)

if @@rowcount = 1
begin
	execute @result = RCRFA @ent,@clgroupe,@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,@tarif,@depart,@categ,@article

	if @result = 0
	begin
		if @rcprfa=1
		begin
			select 	@carfa=0,
					@rfact=round((@valeur*@rcrfa),2)
		end
		else if @rcprfa=0
		begin
			select 	@carfa=@valeur,
					@rfact=0
		end
		return										/* retour car une correspondance a ete trouvee */
	end
end


execute @result = RCRFA @ent,'',@annee,@arfo,@arfam,@rcpr1 output,@rcr1 output,
						@rcpr2 output,@rcr2 output,@rcpr3 output,@rcr3 output,
						@rcprfa output,@rcrfa output,@tarif,@depart,@categ,@article

if @result = 0
begin
	if @rcprfa=1
	begin
		select 	@carfa=0,
				@rfact=round((@valeur*@rcrfa),2)
	end
	else if @rcprfa=0
	begin
		select 	@carfa=@valeur,
				@rfact=0
	end
	return										/* retour car une correspondance a ete trouvee */
end

select 	@carfa=@valeur,
		@rfact=0


	
end



go

