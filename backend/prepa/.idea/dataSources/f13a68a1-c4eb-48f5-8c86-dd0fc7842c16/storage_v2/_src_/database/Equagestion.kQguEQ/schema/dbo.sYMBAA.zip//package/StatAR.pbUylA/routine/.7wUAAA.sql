


/* Procedure utilisee par le requeteur ""Statistiques Articles"" */

create procedure StatAR (@ent			char(5)		= null,
						 @fournisseur	char(12),
						 @famille		char(8)		= null,
						 @article		char(15) 	= null,
						 @detail		tinyint 	= null,
						 @ancien		tinyint		= null,
						 @depot			char(4)		= null,
						 @depexclus		char(4)		= null,
						 @chefp			char(8)		= null
						)
with recompile
as
begin

set arithabort numeric_truncation off


declare @An		smallint,
		@mois	tinyint
		
select 	@An = datepart(yy,getdate()),
		@mois = datepart(mm,getdate())


	create table #liste
	(
		codeart 	char(15) 	not null,
		arfour 		varchar(40) 	null,
		arfam		char(8)			null,
		archefp		char(8)			null,
		valeur 		numeric(14,2)	null,
		designation varchar(80) 	null,
		annee1 		int 			null,		/* annee N-2 */
		annee2 		int 			null,		/* annee N-1 */
		annee2p		int				null,		/* meme periode annee N-1 */
		annee3 		int 			null,		/* annee N */
		arpvht		numeric(14,2)	null,
		rapport		numeric(14,2)	null,		/* % en plus ou moins sur meme periode annee precedente */
		cdeclient 	int 			null,
		stock 		int 			null,
		stockdouane int 			null,
		cdefour 	int 			null,
		janvier 	int 			null,
		fevrier 	int 			null,
		mars 		int 			null,
		avril 		int 			null,
		mai 		int 			null,
		juin 		int 			null,
		juillet 	int 			null,
		aout 		int 			null,
		septembre 	int 			null,
		octobre 	int 			null,
		novembre 	int 			null,
		decembre 	int 			null
	)


	/* lecture des articles */
	
if ((@article is null) and (@famille is null))
	begin
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,arpvht,annee1,annee2,annee3)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT,
		sum(STQTEFA*(1-sign(abs(STAN-@An+2)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An+1)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An))))
		from FAR,FST
		where START=*ARCODE
		and ARFO=@fournisseur
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT
	end
else if ((@article is null) and (@famille is not null))
	begin
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,arpvht,annee1,annee2,annee3)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT,
		sum(STQTEFA*(1-sign(abs(STAN-@An+2)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An+1)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An))))
		from FAR,FST
		where START=*ARCODE
		and ARFO=@fournisseur
		and ARFAM=@famille
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT
	end
else if ((@article is not null) and (@famille is null))
	begin
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,arpvht,annee1,annee2,annee3)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT,
		sum(STQTEFA*(1-sign(abs(STAN-@An+2)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An+1)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An))))
		from FAR,FST
		where START=*ARCODE
		and ARFO=@fournisseur
		and ARCODE=@article
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT
	end	
else if ((@article is not null) and (@famille is not null))
	begin	
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,arpvht,annee1,annee2,annee3)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT,
		sum(STQTEFA*(1-sign(abs(STAN-@An+2)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An+1)))),
		sum(STQTEFA*(1-sign(abs(STAN-@An))))
		from FAR,FST
		where START=*ARCODE
		and ARFO=@fournisseur
		and ARCODE=@article
		and ARFAM=@famille
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,ARPVHT
	end

	create index article on #liste(codeart)

	select STAR,Depot=DPLOC,Qte=sum(STQTE)
	into #Stock
	from #liste,FSTOCK,FDP
	where STAR=#liste.codeart
	and DPLOC in (0,1)
	and STQTE > 0
	and (@depot is null or STDEPOT=@depot)
	and (@depexclus is null or STDEPOT != @depexclus)
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by STAR,DPLOC
	
	update #liste
	set stock=#Stock.Qte
	from #Stock
	where STAR=#liste.codeart
	and Depot=1
	
	update #liste
	set stockdouane=(select sum(#Stock.Qte)
					 from #Stock
					 where STAR=#liste.codeart
					 and Depot != 1)
	
	drop table #Stock
			

	update #liste
	set cdefour=(select sum(RCFQTE)
			 from FRCF
			 where RCFARTICLE=#liste.codeart
			 and (@ent is null or RCFENT=@ent))
		
		
	update #liste
	set cdeclient=	(select sum(RCCQTE)
				from FRCC,FCCL,FCC
				where CCLSEQ=RCCSEQ
				and CCCODE=CCLCODE
				and CCVALIDE = 0
				and RCCARTICLE=#liste.codeart
				and (@ent is null or RCCENT=@ent))
	
	update #liste
	set annee2p = (select sum(STQTEFA)
					from FST
					where START = #liste.codeart
					and STAN = @An-1
					and STMOIS between 1 and @mois
					and (@ent is null or STENT=@ent))
		
	update #liste
	set rapport = 100.00
	where isnull(annee2p,0) = 0
	and isnull(annee3,0) != 0
	
	update #liste
	set rapport = 0
	where isnull(annee3,0) = 0
	and isnull(annee2p,0) != 0
	
	update #liste
	set rapport = (convert(numeric(14,2),annee3)/convert(numeric(14,2),annee2p)-1)*100
	where isnull(annee3,0) != 0
	and isnull(annee2p,0) != 0
	
	update #liste
	set rapport = 0
	where rapport is null
	
	if @detail=1
	
		begin
		
		create table #Mois
		(
		Article		char(8)	not null,
		QteAn2		int			null,
		Mois		int			null
		)	
		
		insert into #Mois
		select codeart,sum(STQTEFA),STMOIS
		from #liste,FST
		where #liste.codeart=START
		and STAN=@An-1
		and (@ent is null or STENT=@ent)
		group by codeart,STMOIS
		
		create index art on #Mois(Article)
		
		update #liste set
		janvier=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=1) 


		update #liste set
		fevrier=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=2)		


		update #liste set
		mars=		(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=3)
			
		update #liste set
		avril=		(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=4)


		update #liste set
		mai=		(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=5)


		update #liste set
		juin=		(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=6)


		update #liste set
		juillet=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=7)


		update #liste set
		aout=		(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=8)


		update #liste set
		septembre=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=9)


		update #liste set
		octobre=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=10)		

			
		update #liste set
		novembre=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=11)		

			
		update #liste set
		decembre=	(select QteAn2 from #Mois 
					where #Mois.Article=#liste.codeart
					and #Mois.Mois=12)

		drop table #Mois


			select Code_Article=codeart,Ref_Fourn=arfour,Famille=arfam,ChefP=archefp,A_commander='',Valeur_Achat=valeur,
			Designation=designation,PVHT=arpvht,Annee_2=isnull(annee1,0),Annee_1=isnull(annee2,0),
			partiel_1=isnull(annee2p,0),Annee_en_cours=isnull(annee3,0),p100_comp=round(rapport,2),
			Cde_Client=isnull(cdeclient,0),Stock=isnull(stock,0),Stock_Douane=isnull(stockdouane,0),
			Cde_Fourn=isnull(cdefour,0),
			Solde=isnull(cdefour,0)+isnull(stock,0)+isnull(stockdouane,0)-isnull(cdeclient,0),
			Janvier=isnull(janvier,0),Fevrier=isnull(fevrier,0),Mars=isnull(mars,0),
			Avril=isnull(avril,0),Mai=isnull(mai,0),Juin=isnull(juin,0),
			Juillet=isnull(juillet,0),Aout=isnull(aout,0),Septembre=isnull(septembre,0),
			Octobre=isnull(octobre,0),Novembre=isnull(novembre,0),Decembre=isnull(decembre,0)
			from #liste
			order by arfam,codeart
			
			
		end
	
	else
		
		begin
		

		select Code_Article=codeart,Ref_Fourn=arfour,Famille=arfam,ChefP=archefp,A_commander='',Valeur_Achat=valeur,
			Designation=designation,PVHT=arpvht,Annee_2=isnull(annee1,0),Annee_1=isnull(annee2,0),
			partiel_1=isnull(annee2p,0),Annee_en_cours=isnull(annee3,0),p100_comp=round(rapport,2),
			Cde_Client=isnull(cdeclient,0),Stock=isnull(stock,0),Stock_Douane=isnull(stockdouane,0),
			Cde_Fourn=isnull(cdefour,0),
			Solde=isnull(cdefour,0)+isnull(stock,0)+isnull(stockdouane,0)-isnull(cdeclient,0)
		from #liste
		order by arfam,codeart
			
		end
			
	drop table #liste
	
end	

go

