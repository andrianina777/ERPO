


create procedure InvoiceToCreditNote
				(   
                @invoice     char(10),  /* Numero invoice origine */   
                @date        datetime,  /* Date de la nouvelle facture */   
                @motif       char(4),   /* Motif de la facture si facture avoir */   
                @sens        int        /* -1 : inversion de sens AV => FA ou FA => AV  /  1 : dupplication */        
                )               
   
with recompile   
as   
begin   
   
set arithabort numeric_truncation off   
           
declare @mois 		varchar(2),   
        @lenum 		varchar(4),   
        @an			varchar(2),   
        @annee    	int,   
        @lemois    	int,   
        @seq        int,   
        @facode   	char(10), 
        @facodeseq	char(10),  
        @i        	int,   
        @prefixe    char(2),   
        @Pent      	varchar(5),   
        @kntable    varchar(50)   
   
/* Insertion ffa */   
   
  
/*Adaptive Server has expanded all  *  elements in the following statement  */ 
select  FFA.FACODE, FFA.FASEQ, FFA.FADATE, FFA.FACL, FFA.FANOM, FFA.FAADR1, FFA.FAADR2, FFA.FACP, FFA.FAVILLE, FFA.FAPAYS, FFA.FACLFACT, FFA.FANOMFACT,   
FFA.FAADR1FACT, FFA.FAADR2FACT, FFA.FACPFACT, FFA.FAVILLEFACT, FFA.FAPAYSFACT, FFA.FAREP, FFA.FATR1, FFA.FATR2, FFA.FATR3, FFA.FATRDATE1,   
FFA.FATRDATE2, FFA.FATRDATE3, FFA.FAREGL1, FFA.FAREGL2, FFA.FAREGL3, FFA.FAPC1, FFA.FAPC2, FFA.FAPC3, FFA.FATOTALHT, FFA.FATAUXESC, FFA.FAESCOMPTE,   
FFA.FATYPETAXE1, FFA.FATYPETAXE2, FFA.FATYPETAXE3, FFA.FATAUXTAXE1, FFA.FATAUXTAXE2, FFA.FATAUXTAXE3, FFA.FABASETAXE1, FFA.FABASETAXE2, FFA.FABASETAXE3,   
FFA.FANETAPAYER, FFA.FAOBSERVATIONS, FFA.FACOMPTA, FFA.FASANSTVA, FFA.FATAXE1, FFA.FATAXE2, FFA.FATAXE3, FFA.FATOTESC, FFA.FATOTNONESC, FFA.FABE,   
FFA.FAREFCL, FFA.FAREMISE, FFA.FADESREM, FFA.FACC, FFA.FAMODEREG1, FFA.FAMODEREG2, FFA.FAMODEREG3, FFA.FAECHSPE, FFA.FASANSDETAIL, FFA.FATR4, FFA.FAREGL4,   
FFA.FAPC4, FFA.FATRDATE4, FFA.FAMODEREG4,   
FFA.FATARIF, FFA.FADEV, FFA.FACOURSDEV, FFA.FAGROUPE, FFA.FAPY, FFA.FAPYFACT, FFA.FAENT,   
FFA.FAPRINT, FFA.FAUSERPRINT, FFA.FADATEPRINT,   
FFA.FAUSERCRE, FFA.FADATECRE, FFA.FAUSERMDF, FFA.FADATEMDF,  
FATVCG,FARG1,FARG2,FARG3,FAAG,FASI,FASTADE,FADATERGT,FAACOMPTE,FAPAYE1,FAPAYE2,FAPAYE3,FAPAYE4  
into #ffa from FFA  where FACODE=@invoice   
select @seq=0   
exec eq_GetSeq_proc "FFA",1,@seq output   
       
/* Recherche du code fa */   
   
select @prefixe=substring(@invoice,1,2)   
select @Pent=PENT from KParam   
select @kntable=(case when @prefixe='FA' then 'FFA' else 'FFA/'+@prefixe end)    
   
select @annee = datepart(yy,@date), @lemois = datepart(mm,@date)   
exec eq_GetNum_proc @Pent,@kntable,@annee,@lemois,1,@i output   
select @an = substring(convert(varchar(4),datepart(yy,@date)),3,2)   
select @mois = convert(varchar(2),datepart(mm,@date))   
if char_length(@mois) = 1    select @mois = '0' + @mois   
select @lenum = convert(varchar(4),@i)   
if char_length(@lenum) = 1    select @lenum = '000' + @lenum   
else if char_length(@lenum) = 2    select @lenum = '00' + @lenum   
else if char_length(@lenum) = 3 select @lenum = '0' + @lenum   
           
select @facode = @prefixe+ @an + @mois + @lenum

select @kntable="FSEQFA"  
exec eq_GetNum_proc @Pent,@kntable,@annee,0,1,@i output   
select @facodeseq=convert(varchar(4),@annee)+substring("000000",1,6-datalength(convert(varchar(6),@i)))+convert(varchar(6),@i)
  
/* Insertion ffa */   
   
insert into FFA    
(   
    /* Rubriques conservÃ¢??es sans changement */   
    FACL,FANOM,FAADR1,FAADR2,FACP,FAVILLE,FAPAYS,FACLFACT,FANOMFACT,FAADR1FACT,FAADR2FACT,FACPFACT,FAVILLEFACT,FAPAYSFACT,FAREP,   
    FATR1,FATR2,FATR3,FATR4,FAPC1,FAPC2,FAPC3,FAPC4,FATAUXESC,FATYPETAXE1,FATYPETAXE2,FATYPETAXE3,FATAUXTAXE1,FATAUXTAXE2,FATAUXTAXE3,   
    FAOBSERVATIONS,FASANSTVA,FAREMISE,FADESREM,FACC,FAMODEREG1,FAMODEREG2,FAMODEREG3,FAMODEREG4,   
    FAECHSPE,FASANSDETAIL,FATARIF,FADEV,FACOURSDEV,FAGROUPE,FAPY,FAPYFACT,FAENT,       
      
    /* rubriques a inverser */   
    FAREGL1,FAREGL2,FAREGL3,FAREGL4,FATOTALHT,FAESCOMPTE,FABASETAXE1,FABASETAXE2,FABASETAXE3,FANETAPAYER,FATAXE1,FATAXE2,FATAXE3,   
    FATOTESC,FATOTNONESC,       
      
    /* rubriques a changer */                               
    FASEQ,FADATE,FACODE,FACODESEQ,FABE,FAREFCL,FACOMPTA,  
    FAPRINT, FAUSERPRINT, FADATEPRINT,  
    FAUSERCRE,FADATECRE,FAUSERMDF,FADATEMDF,  
    FATVCG,FARG1,FARG2,FARG3,FAAG,FASI,FASTADE,FADATERGT,FAACOMPTE,FAPAYE1,FAPAYE2,FAPAYE3,FAPAYE4,  
      
    /* rubriques a changer eventuellement */   
    FATRDATE1,FATRDATE2,FATRDATE3,FATRDATE4   
    )   
    select     
    FACL,FANOM,FAADR1,FAADR2,FACP,FAVILLE,FAPAYS,FACLFACT,FANOMFACT,FAADR1FACT,FAADR2FACT,FACPFACT,FAVILLEFACT,FAPAYSFACT,FAREP,   
    FATR1,FATR2,FATR3,FATR4,FAPC1,FAPC2,FAPC3,FAPC4,FATAUXESC,FATYPETAXE1,FATYPETAXE2,FATYPETAXE3,FATAUXTAXE1,FATAUXTAXE2,FATAUXTAXE3,   
    FAOBSERVATIONS,FASANSTVA,FAREMISE,FADESREM,FACC,FAMODEREG1,FAMODEREG2,FAMODEREG3,FAMODEREG4,   
    FAECHSPE,FASANSDETAIL,FATARIF,FADEV,FACOURSDEV,FAGROUPE,FAPY,FAPYFACT,FAENT,    
      
    FAREGL1*@sens,FAREGL2*@sens,FAREGL3*@sens,FAREGL4*@sens,FATOTALHT*@sens,FAESCOMPTE*@sens,FABASETAXE1*@sens,FABASETAXE2*@sens,FABASETAXE3*@sens,FANETAPAYER*@sens,FATAXE1*@sens,FATAXE2*@sens,FATAXE3*@sens,   
    FATOTESC*@sens,FATOTNONESC*@sens,   
                                       
    @seq,@date,@facode,@facodeseq,'','From '+@invoice,0,  
    0,null,null,  
    user_id(),getdate(),user_id(),getdate(),  
    '','','','','','',0,null,0,0,0,0,0,  
   
    (case when @date>FATRDATE1 then @date else FATRDATE1 end),(case when @date>FATRDATE2 then @date else FATRDATE2 end),(case when @date>FATRDATE3 then @date else FATRDATE3 end),(case when @date>FATRDATE4 then @date else FATRDATE4 end)   
   
from #ffa       
   
drop table #ffa                       
       
/* Insertion ffal */   
   
select FFAL.FALSEQ, FFAL.FALCODE, FFAL.FALARTICLE, FFAL.FALQTE, FFAL.FALDATE, FFAL.FALREMISE1, FFAL.FALREMISE2, FFAL.FALREMISE3, FFAL.FALREMISE4, FFAL.FALREMISE5,   
FFAL.FALPRIXHT, FFAL.FALORDRE, FFAL.FALUNITFACT, FFAL.FALTYPEVE, FFAL.FALTYPE, FFAL.FALLIBRE, FFAL.FALNUM, FFAL.FALLETTRE, FFAL.FALLIENCODE, FFAL.FALLIENNUM,  
 FFAL.FALCL, FFAL.FALTOTALHT, FFAL.FALTYPEMV, FFAL.FALMOTIF, FFAL.FALCARFA, FFAL.FALRFACT, FFAL.FALREP, FFAL.FALDEV, FFAL.FALCOURSDEV, FFAL.FALPRIXHTDEV,   
FFAL.FALTOTALHTDEV, FFAL.FALGROUPE, FFAL.FALDATECRE, FFAL.FALUSERCRE, FFAL.FALDATEMDF, FFAL.FALUSERMDF, FFAL.FALENT, FFAL.FALREPDIV, FFAL.FALOFFERT,FALMARCHE,FALECOTAXE        
 into #ffal from FFAL  where FALCODE=@invoice   
   
create table #ffal_seq    
(   
falcode    char(10)    not null,   
falnum    int    not null,   
falseq    numeric(7)    identity   
)   
   
insert into #ffal_seq    
select FALCODE,FALNUM from #ffal   
   
select @seq=0   
exec eq_GetSeq_proc "FFAL",1,@seq output   
   
insert into FFAL     
(   
    FALSEQ, FALCODE, FALARTICLE, FALQTE, FALDATE, FALREMISE1, FALREMISE2, FALREMISE3, FALREMISE4, FALREMISE5, FALPRIXHT, FALORDRE, FALUNITFACT,    
    FALTYPEVE, FALTYPE, FALLIBRE, FALNUM, FALLETTRE, FALLIENCODE, FALLIENNUM, FALCL, FALTOTALHT, FALTYPEMV, FALMOTIF, FALCARFA, FALRFACT, FALREP,    
    FALDEV, FALCOURSDEV, FALPRIXHTDEV, FALTOTALHTDEV, FALGROUPE, FALDATECRE, FALUSERCRE, FALDATEMDF, FALUSERMDF, FALENT,  
    FALREPDIV,FALOFFERT,FALMARCHE,FALECOTAXE      
   
)    
select   
    falseq+@seq, @facode, FALARTICLE, FALQTE*@sens, @date, FALREMISE1, FALREMISE2, FALREMISE3, FALREMISE4, FALREMISE5, FALPRIXHT, FALORDRE, FALUNITFACT,    
    FALTYPEVE, 1,FALLIBRE, FALNUM,'',null,null, FALCL, FALTOTALHT*@sens, FALTYPEMV, @motif,FALCARFA,FALRFACT,FALREP,   
    FALDEV,FALCOURSDEV,FALPRIXHTDEV,FALTOTALHTDEV*@sens, FALGROUPE,getdate(), user_id(),getdate(),user_id(), FALENT,   
    FALREPDIV,FALOFFERT,FALMARCHE,FALECOTAXE 
from #ffal,#ffal_seq   
where falcode=FALCODE and falnum=FALNUM   
   
   
drop table  #ffal   
   
select @seq=max(FALSEQ) from FFAL   
update KSeq set value=@seq+1 where name='FFAL'   
   
select @facode   
   
end  
 




go

