



/* Les dates doivent etre comprises entre le 1er jour du mois et le dernier */

create procedure New_FST_	(	@smalldate1		smalldatetime,
						 	 	@smalldate2		smalldatetime
							)
with recompile
as
begin
	
set arithabort numeric_truncation off
	
declare @date1	datetime,
		@date2	datetime,
		@mois1	tinyint,
		@mois2	tinyint,
		@an1	smallint,
		@an2	smallint,
		@jour	tinyint

declare	@base	varchar(30)
select  @base = db_name()

select @jour=datepart(dd,@smalldate1)

if @jour != 1
return (1)

select @mois1=datepart(mm,@smalldate1)
select @mois2=datepart(mm,@smalldate2)

if @mois1 != @mois2
return (1)

select @an1=datepart(yy,@smalldate1)
select @an2=datepart(yy,@smalldate2)

if @an1 != @an2
return (1)



if @mois1=1 or @mois1=3 or @mois1=5 or @mois1=7 or @mois1=8 or @mois1=10 or @mois1=12
	begin
		select @jour=31
	end
else if @mois1=4 or @mois1=6 or @mois1=9 or @mois1=11
	begin
		select @jour=30
	end
else if @mois1=2
	begin
		select @date2=convert(datetime,'03/01/'+convert(varchar(4),@an2))
		select @date2=dateadd(dd,-1,@date2)
		select @jour=datepart(dd,@date2)
	end


if @jour != datepart(dd,@smalldate2)
return (1)

		
select 	@date1=convert(datetime,@smalldate1),
		@date2=convert(datetime,@smalldate2)

dump tran @base with truncate_only


create table #FST
(
STREP		char(8)			not null,
STGROUPE	char(12)		not null,
STCL		char(12)		not null,
START		char(15)		not null,
STAN		smallint		not null,
STMOIS		tinyint			not null,
STQTEFA		int				not null,
STCAFA		numeric(14,2)	not null,
STPR		numeric(14,2)	not null,
STCARFA		numeric(14,2)	not null,
STRFACT		numeric(14,2)	not null,
STENT		char(5)			not null,
STPRM		numeric(14,4)	not null,
STPUM		numeric(14,4)	not null,
STREPDIV	char(8)			not null,
STDATE		smalldatetime	not null,
CVLOT		int				not null,
LETTRE		char(4)			not null,
STSEQ		numeric(14,0)	identity
)

insert into #FST (STREP,STGROUPE,STCL,START,STAN,STMOIS,STQTEFA,STCAFA,STPR,
					STCARFA,STRFACT,STENT,STPRM,STPUM,STREPDIV,STDATE,CVLOT,LETTRE)
select isnull(FALREP,''),isnull(FALGROUPE,''),FALCL,FALARTICLE,
		datepart(yy,FALDATE),datepart(mm,FALDATE),FALQTE,isnull(FALTOTALHT,0),0.00,
		isnull(FALCARFA,0),isnull(FALRFACT,0),FALENT,0,0,isnull(FALREPDIV,""),dateadd(hh,19,FALDATE),CVLOT,FALLETTRE
from FFAL (index date),FAR,FCV
where ARCODE=FALARTICLE
and ARUNITACHAT=CVUNIF
and ARTYPE != 8
and FALDATE between @smalldate1 and @smalldate2
and isnull(FALARTICLE,'') != ''
and isnull(FALLETTRE,'') != ''



insert into #FST (STREP,STGROUPE,STCL,START,STAN,STMOIS,STQTEFA,STCAFA,STPR,
					STCARFA,STRFACT,STENT,STPRM,STPUM,STREPDIV,STDATE,CVLOT,LETTRE)
select isnull(FALREP,''),isnull(FALGROUPE,''),FALCL,FALARTICLE,
		datepart(yy,FALDATE),datepart(mm,FALDATE),0,isnull(FALTOTALHT,0),0.00,
		isnull(FALCARFA,0),isnull(FALRFACT,0),FALENT,0,0,isnull(FALREPDIV,""),dateadd(hh,19,FALDATE),1,""
from FFAL (index date),FAR
where ARCODE=FALARTICLE
and ARTYPE != 8
and FALDATE between @smalldate1 and @smalldate2
and isnull(FALARTICLE,'') != ''
and isnull(FALLETTRE,'') = ''


create index seq on #FST (STSEQ)


declare stats cursor
for
select START,STSEQ,STQTEFA,STDATE,CVLOT,LETTRE
from #FST
where STQTEFA != 0
and LETTRE != ""
order by START
for read only

declare @article	char(15),
		@seq		int,
		@qte		int,
		@prm		numeric(14,4),
		@pump		numeric(14,4),
		@date		smalldatetime,
		@prFIFO		numeric(14,4),
		@cvlot		int,
		@lettre		char(4)
		
open stats

fetch stats
into @article,@seq,@qte,@date,@cvlot,@lettre

while (@@sqlstatus = 0)
  begin
  
	  select @prFIFO = 0
	  
	  if isnull(@lettre,'') != ''					/*---------- mode de valorisation au FIFO -----------*/
	  begin
	  select @prFIFO = convert(numeric(14,4),(STPAHT+STFRAIS)/@cvlot) from FSTOCK
	  where STAR = @article
	  and STLETTRE = @lettre
	  end
	  
	  if @prFIFO is null
	  	select @prFIFO = 0

	  select @prm = 0								/*---------- mode de valorisation au PRM mensuel -----------*/
	  
	  set rowcount 1
	  
	  select @prm = PRM from FPRM
	  where PRMAR = @article
	  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
	  order by PRMAN desc,PRMMOIS desc
	  
	  set rowcount 0
	  
	  if @prm is null
		  select @prm = 0
	  
	  select @pump = 0								/*---------- mode de valorisation au PUMP -----------*/
	  
	  select @pump = PUMP from FPUM
	  where PUMAR = @article
	  and PUMDATE <= convert (smalldatetime, @date)
	  having PUMAR = @article
	  and PUMDATE <= convert (smalldatetime, @date)
	  and PUMDATE = max(PUMDATE)
	  
	  if @pump is null
		  select @pump = 0
  
	  update #FST
	  set STPR = convert(numeric(14,2),@prFIFO * @qte), STPRM = convert(numeric(14,2),@prm * @qte), STPUM = convert(numeric(14,2),@pump * @qte)
	  where STSEQ=@seq


	fetch stats
	into @article,@seq,@qte,@date,@cvlot,@lettre

  end


close stats
deallocate cursor stats


delete from FST
where STAN=@an1
and STMOIS=@mois1

  
dump tran @base with truncate_only

insert into FST (STREP,STGROUPE,STCL,START,STAN,STMOIS,STQTEFA,STCAFA,STPR,STCARFA,STRFACT,STENT,STPRM,STPUM,STREPDIV)
select STREP,STGROUPE,STCL,START,STAN,STMOIS,sum(STQTEFA),sum(STCAFA),sum(STPR),sum(STCARFA),sum(STRFACT),STENT,sum(STPRM),sum(STPUM),STREPDIV
from #FST
group by STREP,STGROUPE,STCL,START,STAN,STMOIS,STREPDIV,STENT
order by STREP,STGROUPE,STCL,START,STAN,STMOIS,STREPDIV,STENT

drop table #FST

return (0)

dump tran @base with truncate_only

end



go

