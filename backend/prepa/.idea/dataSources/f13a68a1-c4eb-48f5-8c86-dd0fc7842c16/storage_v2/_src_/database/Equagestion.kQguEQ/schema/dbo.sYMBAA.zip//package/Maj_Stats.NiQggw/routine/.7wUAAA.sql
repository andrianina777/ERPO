



create procedure Maj_Stats	(@an	smallint)
with recompile
as
begin

declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@labase			varchar(30),
		@lignes			int,
		@compteur		int,
		@encours		int

select  @labase = db_name(),
		@lignes = 0,
		@encours = 0,
		@compteur = 0


select 	@smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an)),
		@smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))


dump tran @labase with truncate_only


select FALARTICLE,FATOTALHT=sum(FALTOTALHT)
into #FAL
from FFAL (index date),FAR
where FALDATE between @smalldate1 and @smalldate2
and ARCODE=FALARTICLE
group by FALARTICLE


select START,STCAHT=sum(STCAFA)
into #FST
from FST
where STAN=@an
group by START

select @lignes=count(*)
from #FAL,#FST
where FALARTICLE=START
and STCAHT != FATOTALHT

print "->  %1! lignes a traiter", @lignes

select  @lignes = 0

declare articles cursor 
for select FALARTICLE
from #FAL,#FST
where FALARTICLE=START
and STCAHT != FATOTALHT
for read only

declare @article	char(15)	

open articles

fetch articles
into @article

while (@@sqlstatus = 0)
	begin
	
	select @lignes=@lignes+1
	
	exec New_FSTAR @article,@an

	select @compteur = @compteur + @@rowcount

	if (@lignes >= 100)
	begin
		select @encours = @encours + @lignes
		dump tran @labase with truncate_only
		select @lignes = 0
		print "->  %1! lignes scannees", @encours
	end
	
	fetch articles
	into @article
	
end

close articles
deallocate cursor articles

print "->  %1! lignes scannees", @encours
print "->  %1! lignes traitees", @compteur

dump tran @labase with truncate_only

end



go

