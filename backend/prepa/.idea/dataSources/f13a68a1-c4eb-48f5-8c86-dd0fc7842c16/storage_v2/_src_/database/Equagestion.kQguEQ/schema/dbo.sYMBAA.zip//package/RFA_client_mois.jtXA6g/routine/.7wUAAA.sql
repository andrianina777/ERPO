


create procedure RFA_client_mois (	@ent	char(5) = null,
									@client	char(12),
						 	 		@an		smallint,
						 	 		@mois	tinyint
						 		 )
with recompile
as
begin

set arithabort numeric_truncation off

declare @CAtotal		numeric(14,2),			/* CA total pour calcul droit */
		@CAsansRFA		numeric(14,2),			/* CA des articles sans RFA */
		@CARFAct		numeric(14,2),			/* CA des articles avec RFA contrats */
		@CARFAHct		numeric(14,2),			/* CA des articles avec RFA hors contrats */
		@droitRFA		numeric(8,4),			/* % du droit a RFA */
		@RFAct			numeric(14,2),			/* total de la RFA contrat */
		@RFAremCL		numeric(14,2),			/* total de la RFA sans contrat (RFA fiche remises) */
		@RFAremCL_pot	numeric(14,2),			/* total de la RFA potentielle sans contrat (RFA fiche remises) */
		@rfa_ca			numeric(14,2),			/* total de la RFA CA */
		@rfa_pot		numeric(14,2),			/* total de la RFA CA potentielle */
		@droit_pot		numeric(8,4),			/* % du droit potentiel */
		@groupement		char(12)				/* code du groupement d''achat du client */


select @groupement = CLCODEGROUPE from FCL
where CLCODE=@client
and CLTYPECLI=2
and (@ent is null or CLENT=@ent)


create table #Finale
(
code		char(10)		not null,
qte_ct		int					null,
atteint		int					null,
rfa_due		numeric(14,2)		null,
rfa_pot		numeric(14,2)		null,
seq			numeric(14,0)	identity
)

create table #RC
(
RCCONTRAT	char(10)	not null,
RCFO		char(12)	not null,
RCFAM		char(8)		not null,
RCCT		tinyint		not null,
RCPRFA		tinyint		not null,
RCPQTE		numeric(8,4)	null
)

insert into #RC (RCCONTRAT,RCFO,RCFAM,RCCT,RCPRFA,RCPQTE)
select isnull(RCCONTRAT,''),RCFO,RCFAM,RCCT,RCPRFA,isnull(COPQTE,0)
from FRC,FCO
where RCCL = @client
and RCAN = @an
and RCCONTRAT *= COCODE
and RCFO *= COFO
and RCFAM *= COFAM
and (@ent is null or RCENT=@ent)


			/* Calcul du CA total */

select @CAtotal=isnull(sum(STCAFA),0)
from FST,FAR
where STAN=@an
and STMOIS=@mois
and STCL=@client
and ARCODE=START
and ARTYPE in (0,1)
and (@ent is null or STENT=@ent)


select @droitRFA=isnull(DRFADROIT,0)
from FDRFA
where DRFAVAL = (select max(DRFAVAL) from FDRFA where DRFAVAL <= @CAtotal and (@ent is null or DRFAENT=@ent))


if @droitRFA != 0
begin
	select @droit_pot=@droitRFA
end
else
begin
	select  @droit_pot=isnull(DRFADROIT,0)
	from FDRFA
	where DRFADROIT = (select min(DRFADROIT) from FDRFA where DRFADROIT > 0 and (@ent is null or DRFAENT=@ent))
end


			/* Calcul du CA ne donnant pas droit a RFA */

select @CAsansRFA=isnull(sum(STCAFA),0)
from FST,FAR
where STAN=@an
and STMOIS=@mois
and STCL=@client
and ARCODE=START
and ARSANSRFA=1 
and ARTYPE in (0,1)
and (@ent is null or STENT=@ent)


			/* Calcul du CA donnant droit a la RFA contrat */

select @CARFAct=isnull(sum(STCAFA),0)
from FST,FAR,#RC
where STAN=@an
and STMOIS=@mois
and STCL=@client
and ARCODE=START
and ARSANSRFA=0
and ARTYPE in (0,1)
and (RCFO="" or RCFO=FAR.ARFO)
and (RCFAM="" or RCFAM=FAR.ARFAM)
and RCPRFA=1
and RCCT=1
and (@ent is null or STENT=@ent)


/* Calcul du CA donnant droit a la RFA remises hors contrats RFA forcee */


create table #remHC
(
HCFO	char(12)	not null,
HCFAM	char(8)		not null
)


if (@groupement is not null)
  begin
	insert into #remHC (HCFO,HCFAM)
	select RCFO,RCFAM
	from FRC
	where RCCL=@client
	and RCCT=0
	and RCPRFA=1
	and RCAN=@an
	and (@ent is null or RCENT=@ent)
	group by RCFO,RCFAM
	union
	select RCFO,RCFAM
	from FRC
	where RCCL=@groupement
	and RCCT=0
	and RCPRFA=1
	and RCAN=@an
	and (@ent is null or RCENT=@ent)
	group by RCFO,RCFAM
	union
	select RCFO,RCFAM
	from FRC
	where RCCL=''
	and RCCT=0
	and RCPRFA=1
	and RCAN=@an
	and (@ent is null or RCENT=@ent)
	group by RCFO,RCFAM
  end
else
  begin
	insert into #remHC (HCFO,HCFAM)
	select RCFO,RCFAM
	from FRC
	where RCCL=@client
	and RCCT=0
	and RCPRFA=1
	and RCAN=@an
	and (@ent is null or RCENT=@ent)
	group by RCFO,RCFAM
	union
	select RCFO,RCFAM
	from FRC
	where RCCL=''
	and RCCT=0
	and RCPRFA=1
	and RCAN=@an
	and (@ent is null or RCENT=@ent)
	group by RCFO,RCFAM
  end


delete #remHC
from #RC
where RCCT=1
and (RCFO="" or RCFO=HCFO)
and (RCFAM="" or RCFAM=HCFAM)


select @CARFAHct=isnull(sum(STCAFA),0)
from FST,FAR,#remHC
where STAN=@an
and STMOIS=@mois
and STCL=@client
and ARCODE=START
and ARSANSRFA=0 
and ARTYPE in (0,1)
and (HCFO="" or ARFO=HCFO)
and (HCFAM="" or ARFAM=HCFAM)
and (@ent is null or STENT=@ent)


			/* Construction de la table des contrats du client */

create table #contrats
(
code		char(10)	not null,
qtect		int			null
)

insert into #contrats (code,qtect)
select CTCODE,CTQTE
from FCT2
where CTAN=@an
and CTCL=@client
and (@ent is null or CTENT=@ent)


			/* Construction de la table des contrats actifs du client */

create table #RFA
(
RFA_code		char(10)		not null,
RFA_qtect		int				null,
RFA_atteint		int				null,
RFA_rfa_due		numeric(14,2)	null,
RFA_rfa_pot		numeric(14,2)	null
)

		
insert into #RFA (RFA_code,RFA_qtect,RFA_atteint,RFA_rfa_due,RFA_rfa_pot)
select RCCONTRAT,0,isnull(sum(case when RCPQTE != 0 then STQTEFA else 0 end),0),isnull(sum(STRFACT),0),isnull(sum(STRFACT),0)
from FST,FAR,#RC
where ARCODE=START
and ARSANSRFA=0 
and ARTYPE in (0,1)
and STAN=@an
and STMOIS=@mois
and STCL=@client
and isnull(STRFACT,0)!=0
and (RCFO="" or ARFO=RCFO)
and (RCFAM="" or ARFAM=RCFAM)
and RCCT=1
and (@ent is null or STENT=@ent)
group by RCCONTRAT

insert into #RFA (RFA_code,RFA_qtect,RFA_atteint,RFA_rfa_due,RFA_rfa_pot)
select code,qtect,0,0.00,0.00
from #contrats
where not exists (select * from #RFA where RFA_code=#contrats.code)

update #RFA
set RFA_qtect=#contrats.qtect
from #contrats
where RFA_code=#contrats.code

update #RFA
set RFA_rfa_due=0
where RFA_atteint < RFA_qtect


/* Calcul de la RFA sur remises hors contrats */


select @RFAremCL_pot=isnull(sum(STRFACT),0)
from FST,FAR,#remHC
where ARCODE=START
and ARSANSRFA=0 
and ARTYPE in (0,1)
and STAN=@an
and STMOIS=@mois
and STCL=@client
and isnull(STRFACT,0)!=0
and (HCFO="" or ARFO=HCFO)
and (HCFAM="" or ARFAM=HCFAM)
and (@ent is null or STENT=@ent)


select @RFAremCL = @RFAremCL_pot


select  @rfa_pot = round(((isnull(@CAtotal,0) - isnull(@CAsansRFA,0) - isnull(@CARFAct,0) - isnull(@CARFAHct,0)) * isnull(@droit_pot,0)),2)
select 	@rfa_ca  = round(((isnull(@CAtotal,0) - isnull(@CAsansRFA,0) - isnull(@CARFAct,0) - isnull(@CARFAHct,0)) * isnull(@droitRFA,0)),2)


if @CAtotal	!= 0	  
insert into #Finale (code,qte_ct,atteint,rfa_due,rfa_pot)
values('CA',0,convert(int,@CAtotal),@rfa_ca,(case when @rfa_pot >= 0 then @rfa_pot else 0 end))

insert into #Finale (code,qte_ct,atteint,rfa_due,rfa_pot)
select RFA_code,RFA_qtect,RFA_atteint,RFA_rfa_due,RFA_rfa_pot
from #RFA


if @RFAremCL != 0
begin
insert into #Finale (code,qte_ct,atteint,rfa_due,rfa_pot)
values('Remises HC',0,0,@RFAremCL,@RFAremCL)
end
else if @RFAremCL = 0 and @RFAremCL_pot != 0
begin
insert into #Finale (code,qte_ct,atteint,rfa_due,rfa_pot)
values('Remises HC',0,0,0,@RFAremCL)
end



select 	isnull(sum(rfa_due),0)
from #Finale

drop table #RFA
drop table #contrats
drop table #remHC
drop table #RC
drop table #Finale

end



go

