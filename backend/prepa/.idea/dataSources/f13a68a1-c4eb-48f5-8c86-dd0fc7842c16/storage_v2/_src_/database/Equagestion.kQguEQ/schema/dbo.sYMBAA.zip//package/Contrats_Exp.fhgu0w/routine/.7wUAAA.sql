



/* Renvoie la liste des contrats et de leur realisation pour export ou impression */

create procedure Contrats_Exp  (@ent		char(5) 	= null,
								@contrat	char(10),
								@an			smallint,
								@rep		char(8)		= null,
								@clientdeb	char(12)	= null,
								@clientfin	char(12)	= null,
								@dep		char(2) 	= null,
								@qte		int			= null,
								@div		char(8)		= null
								)
with recompile
as

begin
set arithabort numeric_truncation off

declare @type		tinyint,
		@multient	tinyint
select  @type = 0

if @rep is not null
select  @type=RETYPE from FREP where RECODE=@rep

select @multient=KIMULTIENTITE from KInfos

create table #Finale
(
rep				char(8)			not null,
depart			char(2)			not null,	/* Departement geographique */
annee			smallint		not null,
client			char(12)		not null,
nom				varchar(35)		not null,
contrat			char(10)		not null,
division    	char(8)         not null,
marque      	char(12)        not null,
famille     	char(8)         not null,
categorie   	char(8)         not null,
article     	char(15)        not null,
tarif       	char(8)         not null,
qte_ct			int					null,
atteint_qte		int					null,
montant_ct  	numeric(14,0)       null,
atteint_val		numeric(14,2)		null,
rfa_due			numeric(14,2)		null,
rfa_pot			numeric(14,2)		null,
rfa_pc			numeric(8,4)		null,
stock_cl		varchar(20)			null,
seq				numeric(14,0)	identity
)

create table #Cdes
(
client			char(12)		not null,
division    	char(8)         not null,
marque      	char(12)        not null,
famille     	char(8)         not null,
categorie   	char(8)         not null,
article     	char(15)        not null,
tarif       	char(8)         not null,
encours_qte		int					null,
encours_montant	numeric(14,2)		null,
seq				numeric(14,0)	identity
)



if @type=2 and @rep is not null
	declare clients cursor
	for select STCL,CLNOM1,CLREP,substring(CLCP,1,2)
	from FST,FCL,FAR,FCLR
	where STCL=CLCODE
	and START=ARCODE
	and CLCODE=CLRCL
	and (@clientdeb is null or STCL between @clientdeb	and @clientfin)
	and (@dep is null or substring(CLCP,1,2)=@dep)
	and (@type=2 or (@rep is null or CLREP=@rep))
	and CLRREPDIV=@rep
	and isnull(CLSANSRFA,0)=0
	and STAN=@an
	and (@ent is null or (STENT=@ent and CLENT=@ent))
	group by STCL,CLNOM1,CLREP,substring(CLCP,1,2)
	for read only
else
	declare clients cursor
	for select STCL,CLNOM1,CLREP,substring(CLCP,1,2)
	from FST,FCL,FAR,FCLR
	where STCL=CLCODE
	and START=ARCODE
	and CLCODE*=CLRCL
	and (@clientdeb is null or STCL between @clientdeb	and @clientfin)
	and (@dep is null or substring(CLCP,1,2)=@dep)
	and (@type=2 or (@rep is null or CLREP=@rep))
	and (@type!=2 or (@rep is null or CLRREPDIV=@rep))
	and isnull(CLSANSRFA,0)=0
	and STAN=@an
	and (@ent is null or (STENT=@ent and CLENT=@ent))
	group by STCL,CLNOM1,CLREP,substring(CLCP,1,2)
	for read only

declare @client		char(12),
		@nom			varchar(35),
		@repres			char(8),
		@departement	char(2)

open clients

fetch clients into @client,@nom,@repres,@departement

while (@@sqlstatus = 0)
begin
	if @rep is null
		execute RFA_Detail_2 null,@client,@an,2,0,null,null,null,null,@contrat
	else if @rep is not null and @type != 2
		execute RFA_Detail_2 null,@client,@an,2,0,@rep,null,null,null,@contrat
	else if @rep is not null and @type = 2
		execute RFA_Detail_2 null,@client,@an,2,0,null,@rep,null,null,@contrat
	
	if @div is not null
		delete from FRFATemp where SPID=@@spid and DEPART != @div
		
	if @qte is not null
		delete from FRFATemp where SPID=@@spid and QTE_CT < @qte
	
	if @rep is null
		insert into #Finale (rep,depart,annee,client,nom,contrat,division,marque,famille,categorie,article,tarif,
		qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot,rfa_pc,stock_cl)
		select @repres,@departement,ANNEE,CLIENT,@nom,CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,
		QTE_CT,ATTEINT_QTE,VAL_CT,ATTEINT_VAL,RFA_DUE,RFA_POT,RFA_PC,''
		from FRFATemp
		where SPID=@@spid
	else if @rep is not null
		insert into #Finale (rep,depart,annee,client,nom,contrat,division,marque,famille,categorie,article,tarif,
		qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot,rfa_pc,stock_cl)
		select @rep,@departement,ANNEE,CLIENT,@nom,CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,
		QTE_CT,ATTEINT_QTE,VAL_CT,ATTEINT_VAL,RFA_DUE,RFA_POT,RFA_PC,''
		from FRFATemp
		where SPID=@@spid
	fetch clients into @client,@nom,@repres,@departement
end

close clients
deallocate cursor clients

update #Finale
set stock_cl=RCSTOCK
from FRC (index code)
where annee=RCAN
and client=RCCL
and contrat=isnull(RCCONTRAT,'')
and division=isnull(RCDEPART,'')
and marque=isnull(RCFO,'')
and famille=isnull(RCFAM,'')
and categorie=isnull(RCCATEG,'')
and article=isnull(RCARTICLE,'')
and tarif=isnull(RCTARIF,'')

/* ----------------- */


insert into #Cdes
select client,division,marque,famille,categorie,article,tarif,encours_qte=sum(isnull(RCCQTE,0)),encours_montant=cast(round(sum(isnull(CCLTOTALHT,0)/CCLQTE*RCCQTE),2) as numeric(14,2))
from FRCC,FAR,FCCL,FCL,#Finale
where client=RCCCL and RCCARTICLE=ARCODE and RCCSEQ=CCLSEQ and CLCODE=client
and (division = '' or division = isnull(ARDEPART,''))
and (marque = '' or marque = isnull(ARFO,''))
and (famille = '' or famille = isnull(ARFAM,''))
and (categorie = '' or categorie = isnull(ARGRFAM,''))
and (article = '' or article = isnull(ARCODE,''))
and (tarif = '' or tarif = isnull(CLTARIF,''))
group by client,division,marque,famille,categorie,article,tarif


select rep,depart,#Finale.client,nom,contrat,#Finale.division,#Finale.marque,#Finale.famille,#Finale.categorie,#Finale.article,#Finale.tarif,
isnull(qte_ct,0),isnull(montant_ct,0),
isnull(atteint_qte,0),
isnull(atteint_val,0),
(case when isnull(qte_ct,0) > 0 then isnull(atteint_qte,0)-isnull(qte_ct,0) else 0 end),
(case when isnull(montant_ct,0) > 0 then isnull(atteint_val,0)-isnull(montant_ct,0) else 0 end),
stock_cl,isnull(rfa_pot,0),isnull(rfa_pc,0),
isnull(encours_qte,0),isnull(encours_montant,0)
from #Finale,#Cdes
where #Finale.client *= #Cdes.client
and #Finale.division *= #Cdes.division
and #Finale.marque *= #Cdes.marque
and #Finale.famille *= #Cdes.famille
and #Finale.categorie *= #Cdes.categorie
and #Finale.article *= #Cdes.article
and #Finale.tarif *= #Cdes.tarif
order by rep,depart,#Finale.client,contrat,#Finale.division,#Finale.marque,#Finale.famille,#Finale.categorie,#Finale.article,#Finale.tarif

drop table #Finale
drop table #Cdes

end

go

