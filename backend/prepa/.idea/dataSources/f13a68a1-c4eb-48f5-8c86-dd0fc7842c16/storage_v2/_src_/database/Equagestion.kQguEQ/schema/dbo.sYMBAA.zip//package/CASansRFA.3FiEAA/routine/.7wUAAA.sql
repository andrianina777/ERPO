


create procedure CASansRFA (@ent	char(5)	= null,
							@date1	datetime,
							@date2	datetime)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Fa
(
CLNUMCOMPTABLE		char(12)		null,
CLNOM1				varchar(35)		null,
CLVILLE				varchar(30)		null,
Client				char(12)		null,
Article				char(15)		null,
Designation			varchar(80)		null,
CAAr				numeric(14,2)	null,
CATot				numeric(14,2)	null
)

create table #Far
(
Article				char(15)		null,
Designation			varchar(80)		null,
Type				tinyint			null
)


insert into #Far
select ARCODE,ARLIB,ARTYPE
from FAR
where ARSANSRFA=1

create unique index art on #Far(Article)


insert into #Fa (CLNUMCOMPTABLE,CLNOM1,CLVILLE,Client,Article,Designation,CAAr,CATot)
select CLNUMCOMPTABLE,CLNOM1,CLVILLE,FALCL,FALARTICLE,Designation,sum(FALTOTALHT),0
from #Far,FFAL,FCL
where FALARTICLE=Article
and Type != 3 and Type != 7
and FALDATE between @date1 and @date2
and CLCODE=FALCL
and (@ent is null or (FALENT=@ent and CLENT=FALENT))
group by CLNUMCOMPTABLE,CLNOM1,CLVILLE,FALCL,FALARTICLE,Designation
order by CLNUMCOMPTABLE


select distinct Client
into #Client
from #Fa

create unique index cl on #Client(Client)


select FALCL,CA=sum(FALTOTALHT)
into #CA
from FFAL,#Client,#Far
where Client=FALCL
and FALDATE between @date1 and @date2
and FALARTICLE = Article
and Type != 3 and Type != 7
and (@ent is null or FALENT=@ent)
group by FALCL

drop table #Client

insert into #Fa (CLNUMCOMPTABLE,CLNOM1,CLVILLE,Article,Designation,CAAr,CATot)
select distinct CLNUMCOMPTABLE,CLNOM1,'ÃÂ«TotauxÃÂ»','--------','------------------------',sum(CAAr),CA
from #Fa,#CA
where Client=FALCL
group by CLNUMCOMPTABLE,CLNOM1,CA


select 'NÃÂ°_Comptable','Nom','Ville','Code_Article','Designation','Total_par_Article','CA_Total_Client'


select CLNUMCOMPTABLE,CLNOM1,CLVILLE,Article,Designation,CAAr,CATot
from #Fa
order by CLNUMCOMPTABLE,CLVILLE


select "","","Total general","","",(select sum(CAAr) from #Fa where CLVILLE!='ÃÂ«TotauxÃÂ»'),(select sum(CATot) from #Fa)

drop table #CA
drop table #Fa

end



go

