



create procedure Achats (@ent			char(5)		= null,   
						 @an			smallint,   
						 @moisdeb		tinyint,   
						 @moisfin		tinyint,   
						 @chefprod		char(8) 	= null,   
						 @depart		char(8) 	= null,   
						 @marque		char(12) 	= null,   
						 @famille		char(8) 	= null,   
						 @categorie		char(8) 	= null,   
						 @article		char(15) 	= null,   
						 @frs			char(12) 	= null,   
						 @produits		tinyint 	= 0,   
						 @prodnsto		tinyint 	= 1,   
						 @services		tinyint 	= 2,   
						 @ports			tinyint 	= 3,   
						 @comments		tinyint 	= 4,   
						 @remises		tinyint 	= 5,   
						 @rfa			tinyint 	= 6,   
						 @assur			tinyint 	= 7,   
						 @livraison		char(10) 	= null,   
						 @article_groupe	char(16) = null,  
						 @datedeb		smalldatetime = null,  
						 @datefin		smalldatetime = null,  
						 @fosa			char(6)	 	= null,  
						 @matiere		char(14)	= null,  
						 @couleur		char(8)		= null,  
						 @grille		char(10)	= null,  
						 @calibre		char(14)	= null,  
						 @foreign1		char(12)	= null,  
						 @foreign2		char(12)	= null, 
						 @offert		tinyint		= null, 
						 @foclasse		char(10) 	= null, 
						 @axe			char(12)	= null, 
						 @section		char(12)	= null,
						 @devise		char(3)		= null
						 )   
with recompile   
as   
begin   
  
set arithabort numeric_truncation off   
   
   
declare	@date1			smalldatetime,   
		@date2			smalldatetime   
  
  
if (@datedeb is null)  
begin  
	select @date1=convert(datetime,convert(char(2),@moisdeb)+"/01/"+convert(char(4),@an))   
	select @date2=convert(datetime,convert(char(2),@moisfin)+"/01/"+convert(char(4),@an))   
	select @date2=dateadd(mm,1,@date2)   
	select @date2=dateadd(dd,-1,@date2)  
end  
else  
begin  
	select @date1=@datedeb  
	select @date2=@datefin		  
end  
   

delete from FTAC where TACSPID=@@spid   
   
insert into FTAC (TACCHEFP,TACDEPART,TACMARQUE,TACFAM,TACARTICLE,TACLIB,
				TACFO,TACQTE,TACTOTHT,TACPREUR,TACTOTDEV,TACDEV,
				TACSPID,TACCODE, 
				TACGRFAM,TACSA,TACPAYS,TACCLASSE,TACCOMPTE)   
select 	isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(BLLAR,""),isnull(ARLIB,""),
		isnull(BLLFO,""),BLLQTE,isnull(BLLTOTHT,0),(BLLQTE * round(isnull(BLLPRHT,0)/CVLOT,4)),isnull(BLLTOTDEV,0),BLLDEV,
		@@spid,BLLCODE, 
		isnull(ARGRFAM,''),isnull(FOSA,''),isnull(FOPAYS,''),isnull(FOCLASSE,''),
		isnull((case when FOSANSTVA=0 then TVLCPT else TVLCPTSANSTVA end),'') 
  from FBLL,FAR,FBL,FFO,FTVL,FCV 
  where ARCODE=BLLAR  
  and BLCODE=BLLCODE and ARUNITACHAT=CVUNIF
  and FOCODE=BLFO and TVLTYPE = 1
  and BLLDATE between @date1 and @date2   
  and BLLTYPEVE=TVLCODE and FOCLASSE=TVLCLASSE  
  and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)   
  and (@chefprod is null or ARCHEFP = @chefprod)   
  and (@depart is null or ARDEPART = @depart)   
  and (@marque is null or ARFO = @marque)   
  and (@famille is null or ARFAM = @famille)   
  and (@categorie is null or ARGRFAM = @categorie)   
  and (@article is null or ARCODE = @article)   
  and (@frs is null or BLLFO = @frs)   
  and (@livraison is null or BLLCODE = @livraison)   
  and (@article_groupe is null or ARREGROUPE = @article_groupe) 
  and (@fosa is null or FOSA = @fosa) 
  and (@foclasse is null or FOCLASSE = @foclasse)      
  and (@matiere is null or ARMATIERE = @matiere)  
  and (@couleur is null or ARCOULEUR = @couleur)  
  and (@grille is null or ARGRILLE = @grille)  
  and (@calibre is null or ARCALIBRE = @calibre)  
  and (@foreign1 is null or ARFOREIGN1 = @foreign1)  
  and (@foreign2 is null or ARFOREIGN2 = @foreign2)  
  and (@offert is null or isnull(BLLTOTHT,0)!=0) 
  and (@section is null or exists (select * from FCLAX where FFO.FOCODE=CLAXCLE and (@ent is null or CLAXENT=@ent) and CLAXAX=@axe and CLAXSECTION=@section)) 
  and (@devise is null or BLLDEV=@devise)   
end

go

