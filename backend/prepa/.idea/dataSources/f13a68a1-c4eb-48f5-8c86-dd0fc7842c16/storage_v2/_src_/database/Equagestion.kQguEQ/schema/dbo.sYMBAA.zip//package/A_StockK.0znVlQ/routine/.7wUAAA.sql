


/* Procedure permettant de recuperer les stocks constates sur une annee
	pour un article dans le fichier FSK  */
	
	
create procedure A_StockK (@Article	char(15),
						   @Annee	smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int

declare @Janval		int
declare @Fevval		int
declare @Marval		int
declare @Avrval		int
declare @Maival		int
declare @Junval		int
declare @Juival		int
declare @Aouval		int
declare @Sepval		int
declare @Octval		int
declare @Novval		int
declare @Decval		int

declare @Prix		numeric(14,2)

select @Prix=ARPRM from FAR where ARCODE=@Article


select @Janvier=SKQTE,	@Janval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=1
select @Fevrier=SKQTE,	@Fevval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=2
select @Mars=SKQTE,		@Marval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=3
select @Avril=SKQTE,	@Avrval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=4
select @Mai=SKQTE,		@Maival=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=5
select @Juin=SKQTE,		@Junval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=6
select @Juillet=SKQTE,	@Juival=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=7
select @Aout=SKQTE,		@Aouval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=8
select @Septembre=SKQTE,@Sepval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=9
select @Octobre=SKQTE,	@Octval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=10
select @Novembre=SKQTE,	@Novval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=11
select @Decembre=SKQTE,	@Decval=SKQTE * @Prix from FSK where SKARTICLE=@Article and SKAN=@Annee and SKMOIS=12


select 	isnull(@Janvier,0),isnull(@Fevrier,0),isnull(@Mars,0),
		isnull(@Avril,0),isnull(@Mai,0),isnull(@Juin,0),
		isnull(@Juillet,0),isnull(@Aout,0),isnull(@Septembre,0),
		isnull(@Octobre,0),isnull(@Novembre,0),isnull(@Decembre,0),
		isnull(@Janval,0),isnull(@Fevval,0),isnull(@Marval,0),
		isnull(@Avrval,0),isnull(@Maival,0),isnull(@Junval,0),
		isnull(@Juival,0),isnull(@Aouval,0),isnull(@Sepval,0),
		isnull(@Octval,0),isnull(@Novval,0),isnull(@Decval,0)
end



go

