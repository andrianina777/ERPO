
/* Les dates doivent etre comprises entre le 1er jour du mois et le dernier */

create procedure New_FSTCC_	(@smalldate1		smalldatetime,
						 	 @smalldate2		smalldatetime
							)
with recompile
as
begin
	
set arithabort numeric_truncation off
	
declare @date1	datetime,
		@date2	datetime,
		@mois1	tinyint,
		@mois2	tinyint,
		@an1	smallint,
		@an2	smallint,
		@jour	tinyint

declare	@base	varchar(30)
select  @base = db_name()

select @jour=datepart(dd,@smalldate1)

if @jour != 1
return (1)

select @mois1=datepart(mm,@smalldate1)
select @mois2=datepart(mm,@smalldate2)

if @mois1 != @mois2
return (1)

select @an1=datepart(yy,@smalldate1)
select @an2=datepart(yy,@smalldate2)

if @an1 != @an2
return (1)



if @mois1=1 or @mois1=3 or @mois1=5 or @mois1=7 or @mois1=8 or @mois1=10 or @mois1=12
	begin
		select @jour=31
	end
else if @mois1=4 or @mois1=6 or @mois1=9 or @mois1=11
	begin
		select @jour=30
	end
else if @mois1=2
	begin
		select @date2=convert(datetime,'03/01/'+convert(varchar(4),@an2))
		select @date2=dateadd(dd,-1,@date2)
		select @jour=datepart(dd,@date2)
	end


if @jour != datepart(dd,@smalldate2)
return (1)

		
select 	@date1=convert(datetime,@smalldate1),
		@date2=convert(datetime,@smalldate2)

dump tran @base with truncate_only


create table #FSTCC
(
STCCREP		char(8)			not null,
STCCGROUPE	char(12)		not null,
STCCCL		char(12)		not null,
STCCART		char(15)		not null,
STCCAN		smallint		not null,
STCCMOIS	tinyint			not null,
STCCQTE		int				not null,
STCCCA		numeric(14,2)	not null,
STCCENT		char(5)				null,
STCCREPDIV	char(8)			not null
)

insert into #FSTCC (STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCQTE,STCCCA,STCCENT,STCCREPDIV)
select isnull(CCREPRES,''),isnull(CCGROUPE,''),CCLCL,CCLARTICLE,
		datepart(yy,CCLDATE),datepart(mm,CCLDATE),
		sum(CCLQTE),sum(CCLTOTALHT),CCLENT,isnull(CCLREPDIV,'')
from FCCL (index date),FCC
where CCCODE=CCLCODE and CCLENT=CCENT
and CCLDATE between @smalldate1 and @smalldate2
and isnull(CCLARTICLE,'') != ''
group by CCREPRES,CCGROUPE,CCLCL,CCLARTICLE,datepart(yy,CCLDATE),datepart(mm,CCLDATE),CCLENT,CCLREPDIV


delete from FSTCC
where STCCAN=@an1
and STCCMOIS=@mois1

  
dump tran @base with truncate_only

insert into FSTCC (STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCQTE,STCCCA,STCCENT,STCCREPDIV)
select STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,sum(STCCQTE),sum(STCCCA),STCCENT,STCCREPDIV
from #FSTCC
group by STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCENT,STCCREPDIV
order by STCCREP,STCCGROUPE,STCCCL,STCCART,STCCAN,STCCMOIS,STCCENT,STCCREPDIV

drop table #FSTCC

return (0)

dump tran @base with truncate_only

end
go

