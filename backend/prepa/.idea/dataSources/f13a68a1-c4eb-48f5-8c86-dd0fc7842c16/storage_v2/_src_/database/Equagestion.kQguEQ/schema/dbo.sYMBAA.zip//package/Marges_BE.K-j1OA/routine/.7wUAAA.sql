


/* Procedure renvoyant les lignes de BE dont la marge est < xx% */

create procedure Marges_BE (@ent		char(5) = null,
							@marge		numeric(14,2) = 20.00,
							@date1		smalldatetime = null,
							@date2		smalldatetime = null
						   )
with recompile
as
begin

set arithabort numeric_truncation off

create table #BE
(
Rep_BE			char(8)			not null,
Nom_Rep			varchar(25)			null,
Code_BE			char(10)		not null,
Ligne_BE		int				not null,
Article			char(15)		not null,
Designation		varchar(80)			null,
Code_Client		char(12)		not null,
Nom_Client		varchar(35)			null,
Quantite		int				not null,
Total_HT		numeric(14,2)	not null,
Marge_Val		numeric(14,2)	not null,
Marge_PC		numeric(14,2)	not null,
ID				numeric(14,0)	identity
)

if @date1 is null
begin
  insert into #BE (Rep_BE,Nom_Rep,Code_BE,Ligne_BE,Article,Designation,Code_Client,Nom_Client,
				  Quantite,Total_HT,Marge_Val,Marge_PC)
  select Rep_BE=CLREP,Nom_Rep=RENOM,Code_BE=BELCODE,Ligne_BE=BELNUM,Article=BELARTICLE,Designation=ARLIB,
		  Code_Client=BELCL,Nom_Client=BENOM,Quantite=BELQTE,Total_HT=BELTOTALHT,0,0
  from FBEL,FBE,FAR,FCL,FREP
  where ARCODE=BELARTICLE
  and BECODE=BELCODE
  and CLCODE=BECL
  and RECODE=CLREP
  and BELDATE=convert(varchar(50),getdate(),112)
  and ARTYPE=0
end
else
begin
  insert into #BE (Rep_BE,Nom_Rep,Code_BE,Ligne_BE,Article,Designation,Code_Client,Nom_Client,
				  Quantite,Total_HT,Marge_Val,Marge_PC)
  select Rep_BE=CLREP,Nom_Rep=RENOM,Code_BE=BELCODE,Ligne_BE=BELNUM,Article=BELARTICLE,Designation=ARLIB,
		  Code_Client=BELCL,Nom_Client=BENOM,Quantite=BELQTE,Total_HT=BELTOTALHT,0,0
  from FBEL,FBE,FAR,FCL,FREP
  where ARCODE=BELARTICLE
  and BECODE=BELCODE
  and CLCODE=BECL
  and RECODE=CLREP
  and BELDATE between @date1 and @date2
  and ARTYPE=0
end


declare expeditions cursor 
for select ID,Article,Quantite,Total_HT
from #BE
for update of Marge_Val,Marge_PC

declare @seq			numeric(14,0),
		@article		char(15),
		@qte			int,
		@totalht		numeric(14,2),
		@PrixRevient	numeric(14,4)

open expeditions

fetch expeditions
into @seq,@article,@qte,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @PrixRevient=isnull(PUMP,0)
	from FPUM
	where PUMAR = @article
	and PUMDATE <= convert (smalldatetime, getdate())
	having PUMAR = @article
	and PUMDATE <= convert (smalldatetime, getdate())
	and PUMDATE = max(PUMDATE)
	
	if @PrixRevient is null
		select @PrixRevient=0
	
	
	if @totalht = 0
	begin
		update #BE set Marge_Val=-(@PrixRevient*@qte),Marge_PC=-100
		where current of expeditions	
	end
	else if @PrixRevient != 0
	begin
		update #BE set Marge_Val=@totalht-(@PrixRevient*@qte),Marge_PC=(@totalht-(@PrixRevient*@qte))/@totalht*100
		where current of expeditions	
	end
	else
	begin
		update #BE set Marge_Val=@totalht,Marge_PC=100.00
		where current of expeditions
	end
	
	
	fetch expeditions
	into @seq,@article,@qte,@totalht
	
end

close expeditions
deallocate cursor expeditions


select Rep_BE,Nom_Rep,Code_BE,Ligne_BE,Article,Designation,
		Code_Client,Nom_Client,Quantite,Total_HT,Marge_Val,Marge_PC
from #BE
where Marge_PC < @marge
order by Rep_BE,Nom_Rep,Code_BE,Ligne_BE

drop table #BE


end



go

