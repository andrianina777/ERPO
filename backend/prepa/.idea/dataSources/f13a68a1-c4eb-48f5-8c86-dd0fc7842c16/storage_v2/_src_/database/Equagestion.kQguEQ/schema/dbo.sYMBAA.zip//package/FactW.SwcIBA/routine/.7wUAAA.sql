





create procedure FactW ( 
				@ent		char(5) 	= null, 
				@FromClient 	char(12) 	= null, 
				@ToClient 	char(12) 	= null, 
				@FromDate 	smalldatetime 	= null, 
				@ToDate 	smalldatetime 	= null, 
				@Cde1		char(10) 	= null, 
				@Cde2		char(10) 	= null, 
				@periode	tinyint	 	= 0 
			) 
with recompile 
as 
begin 
 
	set arithabort numeric_truncation off 
 
	if @ToClient is null 	select @ToClient=@FromClient 
 
	if @ToDate is null	select @ToDate=@FromDate 
 
	if @Cde2 is null	select @Cde2=@Cde1 
 
	select WBLCL,WBLCODE,WBLNUM,WBLARTICLE,WBLLETTRE,WBLQTE,WBLPRIXHT, 
   		REMISE1=0,REMISE2=0,REMISE3=0,  
   		UNIFACT=0,TYPENORMLIBRE=0,WBLARDES,WBLTOTALHT,WBLTYPEVE,WBLFICHE,"", 
   		WBLDEV,TARIF='',WBLPRIXHTDEV,WBLTOTALHTDEV,WBLCOURSDEV, 
   		WBADR1=isnull(WBADR1,""),WBADR2=isnull(WBADR2,""),WBCP=isnull(WBCP,""),OFFERT=0,MARCHE="" 
  	from FWBL,FRWB,FCL,FWB 
   	where WBLSEQ=RWBSEQ 
   	and RWBCL=CLCODE 
   	and RWBARTICLE != '' 
   	and WBCODE=WBLCODE 
   	and (@FromClient is null or RWBCL between @FromClient and @ToClient) 
   	and (@FromDate is null or RWBDATE between @FromDate and @ToDate) 
   	and (@Cde1 is null or WBLFICHE between @Cde1 and @Cde2) 
   	and isnull(WBLTYPEVE,'')!='' 
   	and WBLQTE >= 0 
   	and WBLFICHE like "W%" 
   	and (@ent is null or (WBLENT=@ent and RWBENT=@ent and CLENT=@ent and WBENT=@ent)) 
   	and CLFACTPERIODE = @periode 
	order by WBADR1,WBADR2,WBCP,WBLFICHE,WBLDEV 
	 
end 




go

