



create procedure DeletePORT (@ent			char(5) = null,
							 @FromClient 	char(8) = null,
							 @ToClient 		char(8) = null,
							 @FromDate 		smalldatetime = null,
							 @ToDate 		smalldatetime = null
							)
with recompile
as
begin

if @ToClient is null 
	select @ToClient=@FromClient
if @ToDate is null
	select @ToDate=@FromDate


/* Recherche du nombres de lignes de BE restant a facturer par BE */
/* ************************************************************** */

select CODE=BELCODE,LIGNES=count(*) into #LIGNES
from FBEL,FRBE,FCL,FBE
where BELSEQ=RBESEQ and RBECL=CLCODE
and CLMODEFACT=0
and RBEARTICLE != ''
and RBEFACTMAN=0
and RBEDEMO=0
and RBESTADE in (2,3)
and BECODE=BELCODE
and isnull(BELOFFERT,0)=0
and isnull(BELDOTATION,0)=0
and (@FromClient is null or RBECL between @FromClient and @ToClient)
and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
and ((RBEECH=0) or (RBEECH=1  and datepart(mm,RBEDATE)=1) or (RBEECH=1 and datepart(mm,RBEDATE)>7))
and isnull(BELTYPEVE,'')!=''
and BELQTE>=0
and (@ent is null or (RBEENT=@ent and CLENT=RBEENT and BEENT=RBEENT and BELENT=RBEENT))
group by BELCODE

create unique index code on #LIGNES (CODE)

/* Recherche du detail des lignes de BE a facturer */
/* *********************************************** */

select BELSEQ,ARTYPE,LIGNES
into #BE
from FBEL,FRBE,FCL,FBE,FAR,#LIGNES
where BELSEQ=RBESEQ
and RBECL=CLCODE
and CLMODEFACT=0
and RBEARTICLE != ''
and ARCODE=RBEARTICLE
and RBEFACTMAN=0
and RBEDEMO=0
and RBESTADE in (2,3)
and BECODE=BELCODE
and isnull(BELOFFERT,0)=0
and isnull(BELDOTATION,0)=0
and (@FromClient is null or RBECL between @FromClient and @ToClient)
and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
and ((RBEECH=0) or (RBEECH=1 and datepart(mm,RBEDATE)=1) or (RBEECH=1 and datepart(mm,RBEDATE)>7))
and isnull(BELTYPEVE,'')!=''
and BELQTE>=0
and CODE=BELCODE
and (@ent is null or (RBEENT=@ent and CLENT=RBEENT and BEENT=RBEENT and BELENT=RBEENT))

/* 3. Destruction de la ligne de port isolee */
/* ***************************************** */

delete FBEL 
from #BE 
where #BE.BELSEQ=FBEL.BELSEQ
and (ARTYPE=3 or ARTYPE=7)
and LIGNES=1

/* 4. Destruction du BE devenu vide  par destruction de la ligne de port OU unconfirmed de geodis */
/* ********************************************************************************************** */

delete from FBE where not exists (select * from FBEL where BELCODE=FBE.BECODE)

drop table #LIGNES
drop table #BE

end



go

