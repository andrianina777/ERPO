


/* Procedure permettant de recuperer les commandes en reliquat sur une annee
	pour un article dans le fichier FRCC  */
	
	
create procedure A_CdesR (@Article	char(15),
						  @Annee	smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int

declare @Janval		int
declare @Fevval		int
declare @Marval		int
declare @Avrval		int
declare @Maival		int
declare @Junval		int
declare @Juival		int
declare @Aouval		int
declare @Sepval		int
declare @Octval		int
declare @Novval		int
declare @Decval		int

declare @Prix		numeric(14,2)

select @Prix=ARPRM from FAR where ARCODE=@Article


select @Janvier=sum(RCCQTE),	@Janval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=1
select @Fevrier=sum(RCCQTE),	@Fevval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=2
select @Mars=sum(RCCQTE),		@Marval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=3
select @Avril=sum(RCCQTE),		@Avrval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=4
select @Mai=sum(RCCQTE),		@Maival=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=5
select @Juin=sum(RCCQTE),		@Junval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=6
select @Juillet=sum(RCCQTE),	@Juival=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=7
select @Aout=sum(RCCQTE),		@Aouval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=8
select @Septembre=sum(RCCQTE),	@Sepval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=9
select @Octobre=sum(RCCQTE),	@Octval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=10
select @Novembre=sum(RCCQTE),	@Novval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=11
select @Decembre=sum(RCCQTE),	@Decval=sum(RCCQTE) * @Prix from FRCC where RCCARTICLE=@Article and RCCAN=@Annee and RCCMOIS=12


select 	isnull(@Janvier,0),isnull(@Fevrier,0),isnull(@Mars,0),
		isnull(@Avril,0),isnull(@Mai,0),isnull(@Juin,0),
		isnull(@Juillet,0),isnull(@Aout,0),isnull(@Septembre,0),
		isnull(@Octobre,0),isnull(@Novembre,0),isnull(@Decembre,0),
		isnull(@Janval,0),isnull(@Fevval,0),isnull(@Marval,0),
		isnull(@Avrval,0),isnull(@Maival,0),isnull(@Junval,0),
		isnull(@Juival,0),isnull(@Aouval,0),isnull(@Sepval,0),
		isnull(@Octval,0),isnull(@Novval,0),isnull(@Decval,0)
end



go

