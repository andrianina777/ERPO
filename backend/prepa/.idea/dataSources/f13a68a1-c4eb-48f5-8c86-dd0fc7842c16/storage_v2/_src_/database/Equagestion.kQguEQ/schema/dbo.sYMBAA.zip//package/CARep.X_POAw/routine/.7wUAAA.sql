


create procedure CARep (@ent	char(5)	 = null,
						@rep 	char(8),
						@an 	int,
						@mois1 	smallint = null,
						@mois2 	smallint = null,
						@inact	tinyint	 = null
						)
with recompile
as
begin

set arithabort numeric_truncation off


create table #CA
(	
STCL	char(12)			not null,
CAN2	numeric(14,2)		not null,
PR_2	numeric(14,2)		not null,
CAN1	numeric(14,2)		not null,
PR_1	numeric(14,2)		not null,
CAN		numeric(14,2)		not null,
PR		numeric(14,2)		not null,
CACC	numeric(14,2)		not null,
CAENT	char(5)					null
)

declare @type		tinyint

select  @type=RETYPE
from FREP
where RECODE=@rep



insert into #CA (STCL,CAN2,PR_2,CAN1,PR_1,CAN,PR,CACC,CAENT)
select STCL,sum(case when STAN = @an-2 then STCAFA else 0 end),
			sum(case when STAN = @an-2 then STPR else 0 end),
			sum(case when STAN = @an-1 then STCAFA else 0 end),
			sum(case when STAN = @an-1 then STPR else 0 end),
			sum(case when STAN = @an then STCAFA else 0 end),
			sum(case when STAN = @an then STPR else 0 end),
			0.00,STENT
from FST,FCL
where CLCODE=STCL
and (isnull(@inact,0) = 0 or CLSTATUS = 2)
and (@ent is null or (STENT=@ent and CLENT=@ent))
and (@type = 2 or STREP=@rep)
and (@type != 2 or STREPDIV=@rep)
and (@mois1 is null or STMOIS between @mois1 and @mois2)
group by STCL,STENT



insert into #CA (STCL,CAN2,PR_2,CAN1,PR_1,CAN,PR,CACC,CAENT)
select CCLCL,0.00,0.00,0.00,0.00,0.00,0.00,round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),CCLENT
from FRCC,FCCL,FCC,FCL
where CLCODE=CCLCL
and (isnull(@inact,0) = 0 or CLSTATUS = 2)
and CCLSEQ = RCCSEQ
and CCCODE = CCLCODE
and isnull(CCVALIDE,0) = 0
and (@type = 2 or CCLREP=@rep)
and (@type != 2 or CCLREPDIV=@rep)
and RCCAN >= @an-1
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
group by CCLCL,CCLENT


create index client on #CA (STCL)


select CP = substring(isnull(CLCP,''),1,2), CODE = CLCODE, NOM = CLNOM1,VILLE = CLVILLE,
	CA_AN_2 = sum(CAN2), PR_AN_2 = sum(PR_2), Marge_AN_2 = isnull(sum(CAN2),0)-isnull(sum(PR_2),0),
	Marge_PC_AN_2 = (case when isnull(sum(CAN2),0) != 0 then round((isnull(sum(CAN2),0)-isnull(sum(PR_2),0))/isnull(sum(CAN2),0),2)*100 else 0 end),
	CA_AN_1 = sum(CAN1), PR_AN_1 = sum(PR_1), Marge_AN_1 = isnull(sum(CAN1),0)-isnull(sum(PR_1),0),
	Marge_PC_AN_1 = (case when isnull(sum(CAN1),0) != 0 then round((isnull(sum(CAN1),0)-isnull(sum(PR_1),0))/isnull(sum(CAN1),0),2)*100 else 0 end),
	CA_AN = sum(CAN), PR_AN = sum(PR), Marge_AN = isnull(sum(CAN),0)-isnull(sum(PR),0),
	Marge_PC_AN = (case when isnull(sum(CAN),0) != 0 then round((isnull(sum(CAN),0)-isnull(sum(PR),0))/isnull(sum(CAN),0),2)*100 else 0 end),
	En_Commande = sum(CACC)
from FCL,#CA
where CLCODE=STCL and CLENT=CAENT
group by substring(isnull(CLCP,''),1,2),CLCODE,CLNOM1,CLVILLE
having (sum(CAN2) != 0 or sum(PR_2) != 0 or
		sum(CAN1) != 0 or sum(PR_1) != 0 or
		sum(CAN)  != 0 or sum(PR) != 0 or
		sum(CACC) != 0)
order by substring(isnull(CLCP,''),1,2),CLCODE

drop table #CA

end



go

