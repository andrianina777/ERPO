/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.Factures
grant execute on Factures to public

*/


create procedure Factures  (@ent			char(5) 		= null,
							@FromClient 	char(12) 		= null,
							@ToClient 		char(12) 		= null,
						    @FromDate 		smalldatetime 	= null,
							@ToDate 		smalldatetime 	= null,
							@modefact		tinyint			= 0,	/* 0 = tous les BE, 1 = par BE, 2 = par cdes, 3 = par cdes completes */
							@periode		tinyint			= 0,
							@codebe			char(10)		= null,
							@codebefin		char(10)		= null,
							@PrefEscompte	tinyint			= 0		/* 1 = traitement escompte depuis BE */
						   )
with recompile
as
begin

if @ToClient is null
select @ToClient=@FromClient

if @ToDate is null
select @ToDate=@FromDate

if @codebefin is null
select @codebefin=@codebe

declare @saisondeb		char(5),
		@saisonfin		char(5),
		@datesaisondeb	datetime,
		@datesaisonfin	datetime,
		@passagetrcl	int
		
select 	@saisondeb=isnull(PSAISONDEB,''),@saisonfin=isnull(PSAISONFIN,''),
		@passagetrcl=isnull(PPASSAGETRCL,0) from KParam
where (@ent is null or PENT=@ent)


if (@saisondeb <> '' and @saisonfin <> '')
begin
set dateformat dmy
select @datesaisondeb=convert(datetime,@saisondeb+'/'+convert(varchar(4),datepart(yy,getdate())))
select @datesaisonfin=convert(datetime,@saisonfin+'/'+convert(varchar(4),datepart(yy,getdate())))
set dateformat mdy
end
else
begin
select @datesaisondeb=getdate(),@datesaisonfin=getdate()
end

create table #BE
(
BELCODE			char(10)		not null,	/* Code lien de la ligne d'expedition */
BELARTICLE		char(15)			null,	/* Code de l'article expedie */
BELQTE			int				 	null,	/* Quantite expediee */
BELPRIXHT		numeric(14,2)		null,	/* Prix hors taxe de l'article expedie en monnaie de reference */
BELUNITFACT		tinyint			 	null,	/* Unite de facturation de l'article 0 = unite, 1 = cent, 2 = mille */
BELTYPEVE		char(4)			 	null,	/* Type de vente de l'article expedie */
BELTYPE			tinyint			 	null,	/* Type de la ligne d'expedition 0 = normale, 1 = ligne libre */
BELLIBRE		varchar(255)	 	null,	/* Texte de la ligne libre */
BELNUM			int				 	null,	/* Numero de la ligne */
BELLETTRE		char(4)			 	null,	/* Code stock de l'article */
BELLIENCODE		char(10)			null,	/* Code de la commande correspondant ÌÊ la ligne d'expedition */
BELLIENNUM		int				 	null,	/* Ligne de la commande correspondant ÌÊ la ligne d'expedition */
BELCL			char(12)			null,	/* Code du client livre */
BELTOTALHT		numeric(14,2)		null,	/* Total hors taxes de la ligne d'expedition en monnaie de reference */
BELREMISE1		real				null,	/* % de remise 1 */
BELREMISE2		real				null,	/* % de remise 2 */
BELREMISE3		real				null,	/* % de remise 3 */
BELOFFERT		tinyint				null,	/* 1 = indication d'un article offert */
BELDEV			char(3)				null,	/* Code de la devise du tarif de la ligne */
BELCOURSDEV		numeric(12,10)		null,	/* Cours de la devise du tarif de la ligne */
BELPRIXHTDEV	numeric(14,2)		null,	/* Prix en devises de l'article */
BELTOTALHTDEV	numeric(14,2)		null,	/* Total en devises de la ligne */
BELMARCHE       char(12)            null,   /* Code du marche */
BETARIF			char(8)             null,
BEADR1			varchar(50) 	 	null,
BEADR2			varchar(50) 	 	null,
BECP			varchar(12) 	 	null,
ARTYPE			tinyint				null,
BENOM2			varchar(50) 	 	null,
BEPRENOM		varchar(35) 	 	null,
BEESCOMPTE		real				null,
BELCOLIS		numeric(14,2)		null,
BEL_SEQLIB numeric(18,0) null,
BEL_COMMENT_MAG	varchar(255)	null,
BELCOLISAGE		varchar(25)		null,
BELNBCOLIS		int			null,
BELPACK			int			null,
BELPROMO		int			null
)

create table #Bel
(
BELCODE			char(10)		not null,	/* Code lien de la ligne d'expedition */
BELARTICLE		char(15)			null,	/* Code de l'article expedie */
BELQTE			int				 	null,	/* Quantite expediee */
BELPRIXHT		numeric(14,2)		null,	/* Prix hors taxe de l'article expedie en monnaie de reference */
BELUNITFACT		tinyint			 	null,	/* Unite de facturation de l'article 0 = unite, 1 = cent, 2 = mille */
BELTYPEVE		char(4)			 	null,	/* Type de vente de l'article expedie */
BELTYPE			tinyint			 	null,	/* Type de la ligne d'expedition 0 = normale, 1 = ligne libre */
BELLIBRE		varchar(255)	 	null,	/* Texte de la ligne libre */
BELNUM			int				 	null,	/* Numero de la ligne */
BELLETTRE		char(4)			 	null,	/* Code stock de l'article */
BELLIENCODE		char(10)			null,	/* Code de la commande correspondant ÌÊ la ligne d'expedition */
BELLIENNUM		int				 	null,	/* Ligne de la commande correspondant ÌÊ la ligne d'expedition */
BELCL			char(12)			null,	/* Code du client livre */
BELTOTALHT		numeric(14,2)		null,	/* Total hors taxes de la ligne d'expedition en monnaie de reference */
BELREMISE1		real				null,	/* % de remise 1 */
BELREMISE2		real				null,	/* % de remise 2 */
BELREMISE3		real				null,	/* % de remise 3 */
BELOFFERT		tinyint				null,	/* 1 = indication d'un article offert */
BELDEV			char(3)				null,	/* Code de la devise du tarif de la ligne */
BELCOURSDEV		numeric(12,10)		null,	/* Cours de la devise du tarif de la ligne */
BELPRIXHTDEV	numeric(14,2)		null,	/* Prix en devises de l'article */
BELTOTALHTDEV	numeric(14,2)		null,	/* Total en devises de la ligne */
BELMARCHE       char(12)            null,   /* Code du marche */
BETARIF			char(8)             null,
BEADR1			varchar(50) 	 	null,
BEADR2			varchar(50) 	 	null,
BECP			varchar(12) 	 	null,
ARTYPE			tinyint				null,
BENOM2			varchar(50) 	 	null,
BEPRENOM		varchar(35) 	 	null,
BEESCOMPTE		real				null,
BELCOLIS		numeric(14,2)		null,
BEL_SEQLIB numeric(18,0) null,
BEL_COMMENT_MAG	varchar(255)	null,
BELCOLISAGE		varchar(25)		null,
BELNBCOLIS		int			null,
BELPACK			int			null,
BELPROMO		int			null
)



if @modefact in (0,1,2)
begin
   
  insert into #BE (BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	   BELREMISE1,BELREMISE2,BELREMISE3,
	   BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
	   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,
	   BELLIENNUM,ARTYPE,BELOFFERT,BELMARCHE,BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO)
  select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
   BELREMISE1,BELREMISE2,BELREMISE3,
   BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1=isnull(BEADR1,''),BEADR2=isnull(BEADR2,''),BECP=isnull(BECP,''),
   BELLIENNUM,ARTYPE,BELOFFERT=isnull(BELOFFERT,0),BELMARCHE=isnull(BELMARCHE,''),
   BENOM2=isnull(BENOM2,''),BEPRENOM=isnull(BEPRENOM,''),
   case when @PrefEscompte=1 then isnull(BEESCOMPTE,0) else isnull(CLESCOMPTE,0) end,
   BELCOLIS=isnull(BELCOLIS,0),BEL_SEQLIB,isnull(BEL_COMMENT_MAG,''),isnull(BELCOLISAGE,''),isnull(BELNBCOLIS,0),isnull(BELPACK,0),isnull(BELPROMO,0)
  from FBEL,FRBE,FCL,FBE,FAR
   where BELSEQ=RBESEQ
   and RBECL=CLCODE
   and CLMODEFACT = @modefact
   and RBEARTICLE != ''
   and ARCODE=RBEARTICLE
   and RBEFACTMAN=0
   and RBEDEMO=0
   and RBESTADE in (2,3)
   and BECODE=BELCODE
   and (@codebe is null or BELCODE between @codebe and @codebefin)
   and (@FromClient is null or RBECL between @FromClient and @ToClient)
   and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
   and ((RBEECH=0)  or (RBEECH=1 and RBEDATE < @datesaisondeb) or (RBEECH=1 and RBEDATE > @datesaisonfin))
   and isnull(BELTYPEVE,'')!=''
   and BELQTE >= 0
   and (@ent is null or (BELENT=@ent and RBEENT=@ent and CLENT=@ent and BEENT=@ent))
   and CLFACTPERIODE = @periode
   
/* Ajout des lignes a echeances fixes dont la date de 1ere echeance est trop proche de la date du jour */
   
   insert into #BE (BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	   BELREMISE1,BELREMISE2,BELREMISE3,
	   BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
	   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,
	   BELLIENNUM,ARTYPE,BELOFFERT,BELMARCHE,BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO)
   select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
   BELREMISE1,BELREMISE2,BELREMISE3,
   BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1=isnull(BEADR1,''),BEADR2=isnull(BEADR2,''),BECP=isnull(BECP,''),
   BELLIENNUM,ARTYPE,BELOFFERT=isnull(BELOFFERT,0),BELMARCHE=isnull(BELMARCHE,''),
   BENOM2=isnull(BENOM2,''),BEPRENOM=isnull(BEPRENOM,''),
   case when @PrefEscompte=1 then isnull(BEESCOMPTE,0) else isnull(CLESCOMPTE,0) end,
   BELCOLIS=isnull(BELCOLIS,0),BEL_SEQLIB,isnull(BEL_COMMENT_MAG,''),isnull(BELCOLISAGE,''),isnull(BELNBCOLIS,0),isnull(BELPACK,0),isnull(BELPROMO,0)
  from FBEL,FRBE,FCL,FBE,FAR,FCC,FTR
   where BELSEQ=RBESEQ
   and RBECL=CLCODE
   and CLMODEFACT = @modefact
   and RBEARTICLE != ''
   and ARCODE=RBEARTICLE
   and RBEFACTMAN=0
   and RBEDEMO=0
   and RBESTADE in (2,3)
   and BECODE=BELCODE
   and (@codebe is null or BELCODE between @codebe and @codebefin)
   and (@FromClient is null or RBECL between @FromClient and @ToClient)
   and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
   and CCCODE = BELLIENCODE
   and CCTR1 = TRCODE
   and TRTYPEECH = 3
   and (RBEECH=2 and CCDATEECH1 < dateadd(dd,@passagetrcl,getdate()))
   and isnull(BELTYPEVE,'')!=''
   and BELQTE >= 0
   and (@ent is null or (BELENT=@ent and RBEENT=@ent and CLENT=@ent and BEENT=@ent))
   and CLFACTPERIODE = @periode
   
   
      /*----- Recherche et suppression des ports et assurances Isoles -----*/
   select BELCODE,Nb=count(*) into #port      from #BE 	where ARTYPE in (3,7) 	group by BELCODE 
   select BELCODE,Nb=count(*) into #portVerif from #BE 							group by BELCODE

   delete #BE
   from #portVerif,#port
   where #BE.BELCODE=#portVerif.BELCODE 
   and #portVerif.BELCODE=#port.BELCODE 
   and #portVerif.Nb=#port.Nb

end
else if @modefact = 3
begin

	insert into #Bel (BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	   BELREMISE1,BELREMISE2,BELREMISE3,
	   BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
	   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,
	   BELLIENNUM,ARTYPE,BELOFFERT,BELMARCHE,BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO)
    select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
     BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1=isnull(BEADR1,''),BEADR2=isnull(BEADR2,''),BECP=isnull(BECP,''),
	 BELLIENNUM,ARTYPE,BELOFFERT=isnull(BELOFFERT,0),BELMARCHE=isnull(BELMARCHE,''),
   	 BENOM2=isnull(BENOM2,''),BEPRENOM=isnull(BEPRENOM,''),
   	 case when @PrefEscompte=1 then isnull(BEESCOMPTE,0) else isnull(CLESCOMPTE,0) end,
   	 BELCOLIS=isnull(BELCOLIS,0),BEL_SEQLIB,isnull(BEL_COMMENT_MAG,''),isnull(BELCOLISAGE,''),isnull(BELNBCOLIS,0),isnull(BELPACK,0),isnull(BELPROMO,0)
	from FBEL,FRBE,FAR,FBE,FCL
	 where BELSEQ=RBESEQ
	 and RBECL=CLCODE
     and CLMODEFACT = @modefact
	 and RBEARTICLE!=''
	 and ARCODE=RBEARTICLE
	 and RBEFACTMAN=0
	 and RBEDEMO=0
	 and RBESTADE in (2,3)
   	 and (@FromClient is null or RBECL between @FromClient and @ToClient)
     and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
	 and ((RBEECH=0) or (RBEECH=1 and RBEDATE < @datesaisondeb) or (RBEECH=1 and RBEDATE > @datesaisonfin))
	 and isnull(BELTYPEVE,'')!=''
	 and BELQTE>=0
	 and BELLIENCODE like 'CC%'
	 and BECODE=BELCODE
     and (@codebe is null or BELCODE between @codebe and @codebefin)
	 and (@ent is null or (BELENT=@ent and RBEENT=@ent))
     and CLFACTPERIODE = @periode

/* Ajout des lignes a echeances fixes dont la date de 1ere echeance est trop proche de la date du jour */

	insert into #Bel (BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	   BELREMISE1,BELREMISE2,BELREMISE3,
	   BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
	   BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,
	   BELLIENNUM,ARTYPE,BELOFFERT,BELMARCHE,BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO)
    select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,BELDEV,BETARIF,
     BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1=isnull(BEADR1,''),BEADR2=isnull(BEADR2,''),BECP=isnull(BECP,''),
	 BELLIENNUM,ARTYPE,BELOFFERT=isnull(BELOFFERT,0),BELMARCHE=isnull(BELMARCHE,''),
   	 BENOM2=isnull(BENOM2,''),BEPRENOM=isnull(BEPRENOM,''),
   	 case when @PrefEscompte=1 then isnull(BEESCOMPTE,0) else isnull(CLESCOMPTE,0) end,
   	 BELCOLIS=isnull(BELCOLIS,0),BEL_SEQLIB,isnull(BEL_COMMENT_MAG,''),isnull(BELCOLISAGE,''),isnull(BELNBCOLIS,0),isnull(BELPACK,0),isnull(BELPROMO,0)
	from FBEL,FRBE,FAR,FBE,FCL,FCC,FTR
	 where BELSEQ=RBESEQ
	 and RBECL=CLCODE
     and CLMODEFACT = @modefact
	 and RBEARTICLE!=''
	 and ARCODE=RBEARTICLE
	 and RBEFACTMAN=0
	 and RBEDEMO=0
	 and RBESTADE in (2,3)
   	 and (@FromClient is null or RBECL between @FromClient and @ToClient)
     and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
	 and CCCODE = BELLIENCODE
     and CCTR1 = TRCODE
     and TRTYPEECH = 3
     and (RBEECH=2 and CCDATEECH1 < dateadd(dd,@passagetrcl,getdate()))
	 and isnull(BELTYPEVE,'')!=''
	 and BELQTE>=0
	 and BELLIENCODE like 'CC%'
	 and BECODE=BELCODE
     and (@codebe is null or BELCODE between @codebe and @codebefin)
	 and (@ent is null or (BELENT=@ent and RBEENT=@ent))
     and CLFACTPERIODE = @periode

 
  
	select distinct incomplet=BELLIENCODE
	into #Inc
	from #Bel,FCCL,FRCC
	where RCCSEQ=CCLSEQ
	and BELLIENCODE=CCLCODE
	and (@ent is null or (CCLENT=@ent and RCCENT=@ent))
	
	
	delete #Bel
	from #Inc
	where incomplet=BELLIENCODE
	
	drop table #Inc
end



if @modefact = 0
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,'',BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO
	from #BE
	order by BELCL,BELDEV,BEADR1,BEADR2,BECP,BEESCOMPTE,BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 1
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,'',BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO
	from #BE
	order by BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 2
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,'',BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO
	from #BE
	where (ARTYPE not in (3,7) or BELLIENCODE like 'CC%')
	order by BEADR1,BEADR2,BECP,BELDEV,BEESCOMPTE,BELLIENCODE,BELLIENNUM,BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 3
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,BELLIENCODE,'',BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,
	 BENOM2,BEPRENOM,BEESCOMPTE,BELCOLIS,BEL_SEQLIB,BEL_COMMENT_MAG,BELCOLISAGE,BELNBCOLIS,BELPACK,BELPROMO
	from #Bel
	where (ARTYPE not in (3,7) or BELLIENCODE like 'CC%')
	order by BEADR1,BEADR2,BECP,BELLIENCODE,BELLIENNUM,BELDEV,BEESCOMPTE
	
	drop table #Bel
end

end
go

