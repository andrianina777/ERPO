


/* Procedure donnant le palmares des meilleures ventes 
	les mois de depart et de fin sont entres sous
	la forme ""199701"" */


create procedure Palmares	(@ent		char(5)	= null,
							 @dumois	char(6),
							 @aumois	char(6),
							 @lignes	int = 10000,
							 @marque	char(12) = null,
							 @qte		tinyint = null)
with recompile
as
begin

set arithabort numeric_truncation off

declare @andeb		int,
		@anfin		int,
		@moisdeb	int,
		@moisfin	int
		
select  @andeb=convert(int,substring(@dumois,1,4)),
		@moisdeb=convert(int,substring(@dumois,5,2)),
		@anfin=convert(int,substring(@aumois,1,4)),
		@moisfin=convert(int,substring(@aumois,5,2))


create table #Final
(
ARFO	char(12)	not null,
ARFAM	char(8)		not null,
ARCODE	char(15)	not null,
ARLIB	varchar(80)		null,
QTE		int				null,
CA		numeric(14,2)	null,
PR		numeric(14,2)	null,
MARGE	numeric(14,2)	null,
MARGE_PC numeric(14,2)	null
)

create table #Temp
(
ARFO	char(12)	not null,
ARFAM	char(8)		not null,
ARCODE	char(15)	not null,
ARLIB	varchar(80)		null,
QTE		int				null,
CA		numeric(14,2)	null,
PR		numeric(14,2)	null,
MARGE	numeric(14,2)	null,
MARGE_PC numeric(14,2)	null
)


if @marque is not null
  begin

  	insert into #Final (ARFO,ARFAM,ARCODE,ARLIB,QTE,CA,PR,MARGE,MARGE_PC)
	select ARFO,ARFAM,ARCODE,ARLIB,sum(STQTEFA),sum(STCAFA),sum(STPR),
			sum(STCAFA)-sum(STPR),round((sum(STCAFA)-sum(STPR))/(sum(STCAFA)+1)*100,2)
	from FST,FAR
	where ARCODE=START
	and ARFO=@marque
	and STAN = @andeb
	and STMOIS between @moisdeb and @moisfin
	and (@ent is null or STENT=@ent)
	group by ARFO,ARFAM,ARCODE,ARLIB
	
	set rowcount @lignes

	if ((@qte is null) or (@qte=0))
		begin
		 select Marque=ARFO,Famille=ARFAM,Article=ARCODE,
		 		Designation=ARLIB,Quantite=QTE,CA=CA,
				Prix_de_revient=PR,Marge=MARGE,Pourcentage_marge=MARGE_PC
		 from #Final
		 order by ARFO,CA desc,ARFAM,ARCODE
		 compute sum(CA),sum(PR),sum(MARGE)
		end
	else
		begin
		 select Marque=ARFO,Famille=ARFAM,Article=ARCODE,
		 		Designation=ARLIB,Quantite=QTE,CA=CA,
				Prix_de_revient=PR,Marge=MARGE,Pourcentage_marge=MARGE_PC
		 from #Final
		 order by ARFO,QTE desc,ARFAM,ARCODE
		 compute sum(CA),sum(PR),sum(MARGE)
		end

	set rowcount 0
  end
else if @marque is null
  begin
	
	declare fournisseurs cursor
	for select ARFO
	from FST,FAR
	where START=ARCODE
	and STAN = @andeb
	and STMOIS between @moisdeb and @moisfin
	and (@ent is null or STENT=@ent)
	group by ARFO
	for read only
	
	declare @fournis	char(12)
	
	open fournisseurs
	
	fetch fournisseurs
	into @fournis
	
	while (@@sqlstatus = 0)
	  begin
		
		insert into #Temp (ARFO,ARFAM,ARCODE,ARLIB,QTE,CA,PR,MARGE,MARGE_PC)
		select ARFO,ARFAM,ARCODE,ARLIB,sum(STQTEFA),sum(STCAFA),sum(STPR),
				sum(STCAFA)-sum(STPR),round((sum(STCAFA)-sum(STPR))/(sum(STCAFA)+1)*100,2)
		from FST,FAR
		where ARCODE=START
		and ARFO=@fournis
		and STAN = @andeb
		and STMOIS between @moisdeb and @moisfin
		and (@ent is null or STENT=@ent)
		group by ARFO,ARFAM,ARCODE,ARLIB
		
		set rowcount @lignes

		if ((@qte is null) or (@qte=0))
			begin
			 insert into #Final (ARFO,ARFAM,ARCODE,ARLIB,QTE,CA,PR,MARGE,MARGE_PC)
			 select ARFO,ARFAM,ARCODE,ARLIB,QTE,CA,PR,MARGE,MARGE_PC
			 from #Temp
			 order by ARFO,CA desc,ARFAM,ARCODE
			end
		else
			begin
			 insert into #Final (ARFO,ARFAM,ARCODE,ARLIB,QTE,CA,PR,MARGE,MARGE_PC)
			 select ARFO,ARFAM,ARCODE,ARLIB,QTE,CA,PR,MARGE,MARGE_PC
			 from #Temp
			 order by ARFO,QTE desc,ARFAM,ARCODE
			end
	
		set rowcount 0
		
		delete from #Temp
		
		fetch fournisseurs
		into @fournis
		
	  end
	  
	  close fournisseurs
	  
	  deallocate cursor fournisseurs
	  
	if ((@qte is null) or (@qte=0))
		begin
		 select Marque=ARFO,Famille=ARFAM,Article=ARCODE,
		 		Designation=ARLIB,Quantite=QTE,CA=CA,
				Prix_de_revient=PR,Marge=MARGE,Pourcentage_marge=MARGE_PC
		 from #Final
		 order by ARFO,CA desc,ARFAM,ARCODE
		 compute sum(CA),sum(PR),sum(MARGE) by ARFO
		end
	else
		begin
		 select Marque=ARFO,Famille=ARFAM,Article=ARCODE,
		 		Designation=ARLIB,Quantite=QTE,CA=CA,
				Prix_de_revient=PR,Marge=MARGE,Pourcentage_marge=MARGE_PC
		 from #Final
		 order by ARFO,QTE desc,ARFAM,ARCODE
		 compute sum(CA),sum(PR),sum(MARGE) by ARFO
		end
	
  end
  
  drop table #Final
  drop table #Temp

end



go

