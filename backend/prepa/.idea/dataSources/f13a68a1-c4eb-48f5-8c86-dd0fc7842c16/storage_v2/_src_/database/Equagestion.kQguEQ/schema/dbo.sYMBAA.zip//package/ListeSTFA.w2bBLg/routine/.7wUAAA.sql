


create procedure ListeSTFA (@ent			char(5)	 = null,
							@fourn			char(12) = null,
							@FromArticle	char(15) = null,
							@ToArticle		char(15) = null,
							@FromDate		smalldatetime = null,
							@ToDate			smalldatetime = null)
with recompile
as
begin

	select Article=ARCODE,Designation=ARLIB,Emplacement=AREMP,
			Depot=STDEPOT,Stock=sum(STQTE),Vendus=0
	into #Stock
	from FAR,FSTOCK,FDP
	where ARCODE*=STAR
	and (@fourn is null or ARFO=@fourn)
	and (@FromArticle is null or ARCODE between @FromArticle and @ToArticle)
	and DPCODE=*STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by ARCODE,ARLIB,AREMP,STDEPOT
	
	select FALARTICLE,Quantite=sum(FALQTE)
	into #Factures
	from FFAL,FAR
	where FALARTICLE=ARCODE
	and isnull(FALLETTRE,'') != ''
	and (@fourn is null or ARFO=@fourn)
	and (@FromArticle is null or FALARTICLE between @FromArticle and @ToArticle)
	and (@FromDate is null or FALDATE between @FromDate and @ToDate)
	and (@ent is null or FALENT=@ent)
	group by FALARTICLE
	
	update #Stock
	set Vendus=Quantite
	from #Factures
	where Article=FALARTICLE
	
	/* Adaptive Server has expanded all ''*'' elements in the following statement */ select #Stock.Article, #Stock.Designation, #Stock.Emplacement, #Stock.Depot, #Stock.Stock, #Stock.Vendus from #Stock
	order by Article
	
end



go

