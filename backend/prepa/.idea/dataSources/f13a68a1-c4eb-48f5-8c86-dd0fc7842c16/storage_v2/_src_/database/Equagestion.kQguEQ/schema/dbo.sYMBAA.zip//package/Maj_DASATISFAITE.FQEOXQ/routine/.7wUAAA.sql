


create procedure Maj_DASATISFAITE  (@demande	char(10),
									@ent		char(5) = null
								   )
with recompile
as
begin

  declare @seq			int,
		  @qte			int,
		  @reste		int,
		  @lignes		int,
		  @satisfaite	int,
		  @nonlivre		int,
		  @artype		tinyint
		  
  
 select @satisfaite = 0,
  	@nonlivre = 0
  
  select @lignes=count(*) from FDAL where DALCODE=@demande and isnull(DALENT,'')=isnull(@ent,'')
  
  if @lignes > 0
  begin
  
	declare demande cursor 
	for select DALSEQ,DALQTE,DALRESTE
	from FDAL,FAR
	where DALARTICLE=ARCODE
	and DALCODE=@demande
	and isnull(DALENT,'')=isnull(@ent,'')
	and ARTYPE in (0,1)
	for read only
		
	open demande
	
	fetch demande
	into @seq,@qte,@reste
	
	while (@@sqlstatus = 0)
		begin
			
		if @satisfaite = 0
		  begin
		  	if @reste <= 0 select @satisfaite = 2
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
			else select @nonlivre = 1
		  end
		else
		if @satisfaite = 2
		  begin
		  	if @qte = @reste select @satisfaite = 1
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
		  end
		
		fetch demande
		into @seq,@qte,@reste
		
	end
	
	close demande
	deallocate cursor demande
	
	if (@satisfaite = 2) and (@nonlivre = 1)
	select @satisfaite = 1	
	
	update FDA set DASATISFAITE = @satisfaite
	where DACODE=@demande and isnull(DAENT,'')=isnull(@ent,'')
  
  end
  else if @lignes = 0
  begin
  
	update FDA set DASATISFAITE = 2
	where DACODE=@demande and isnull(DAENT,'')=isnull(@ent,'')
  
  end

end 



go

