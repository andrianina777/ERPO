


/* Procedure renvoyant les lignes de BE dont la marge est < xx% */

create procedure Marges_CC (@ent		char(5) = null,
							@marge		numeric(14,2) = 20.00
						   )
with recompile
as
begin

declare	@an		smallint,
		@mois	tinyint,
		@jour	tinyint,
		@date1	smalldatetime,
		@date2	smalldatetime
		

select  @an = datepart(yy,getdate()),
		@mois = datepart(mm,getdate()),
		@jour = datepart(dd,getdate())
select  @date1=convert(smalldatetime,convert(varchar,@mois)+"/"+convert(varchar,@jour)+"/"+convert(varchar,@an))
select  @date2=dateadd(dd,1,@date1)

set arithabort numeric_truncation off

create table #CC
(
Rep_CC			char(8)			not null,
Nom_Rep			varchar(25)			null,
Code_CC			char(10)		not null,
Ligne_CC		int				not null,
Article			char(15)		not null,
Designation		varchar(80)			null,
Code_Client		char(12)		not null,
Nom_Client		varchar(35)			null,
Quantite		int				not null,
Total_HT		numeric(14,2)	not null,
Marge_Val		numeric(14,2)	not null,
Marge_PC		numeric(14,2)	not null,
ID				numeric(14,0)	identity
)


insert into #CC (Rep_CC,Nom_Rep,Code_CC,Ligne_CC,Article,Designation,Code_Client,Nom_Client,
				  Quantite,Total_HT,Marge_Val,Marge_PC)
select Rep_CC=CLREP,Nom_Rep=RENOM,Code_CC=CCLCODE,Ligne_CC=CCLNUM,Article=CCLARTICLE,Designation=ARLIB,
		  Code_Client=CCLCL,Nom_Client=CCNOM,Quantite=RCCQTE,Total_HT=isnull((CCLTOTALHT/CCLQTE)*RCCQTE,0),0,0  
from FCCL,FAR,FCL,FRCC,FREP,FCC
where ARCODE=CCLARTICLE
and CCCODE=CCLCODE
and CCLSEQ=RCCSEQ
and CLCODE=CCLCL
and RECODE=CLREP
and ARTYPE=0
and CCDATECOM between @date1 and @date2
and (@ent is null or (CCLENT=@ent and CLENT=@ent))


declare commandes cursor 
for select ID,Article,Quantite,Total_HT
from #CC
for update of Marge_Val,Marge_PC

declare @seq			numeric(14,0),
		@article		char(15),
		@qte			int,
		@totalht		numeric(14,2),
		@PrixRevient	numeric(14,4)

open commandes

fetch commandes
into @seq,@article,@qte,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @PrixRevient=isnull(PUMP,0)
	from FPUM
	where PUMAR = @article
	and PUMDATE <= convert (smalldatetime, getdate())
	having PUMAR = @article
	and PUMDATE <= convert (smalldatetime, getdate())
	and PUMDATE = max(PUMDATE)
	
	if @PrixRevient is null
		select @PrixRevient=0
	
	
	if @totalht = 0
	begin
		update #CC set Marge_Val=-(@PrixRevient*@qte),Marge_PC=-100
		where current of commandes	
	end
	else if @PrixRevient != 0
	begin
		update #CC set Marge_Val=@totalht-(@PrixRevient*@qte),Marge_PC=(@totalht-(@PrixRevient*@qte))/@totalht*100
		where current of commandes	
	end
	else
	begin
		update #CC set Marge_Val=@totalht,Marge_PC=100.00
		where current of commandes
	end
	
	
	fetch commandes
	into @seq,@article,@qte,@totalht
	
end

close commandes
deallocate cursor commandes


select CCLUSERCRE,name,Rep_CC,Nom_Rep,Code_CC,Ligne_CC,Article,Designation,
		Code_Client,Nom_Client,Quantite,Total_HT,Marge_Val,Marge_PC
from #CC,FCCL,sysusers
where Marge_PC < @marge
and CCLCODE = Code_CC
and CCLNUM = Ligne_CC
and uid = CCLUSERCRE
order by CCLUSERCRE,Rep_CC,Nom_Rep,Code_CC,Ligne_CC

drop table #CC


end



go

