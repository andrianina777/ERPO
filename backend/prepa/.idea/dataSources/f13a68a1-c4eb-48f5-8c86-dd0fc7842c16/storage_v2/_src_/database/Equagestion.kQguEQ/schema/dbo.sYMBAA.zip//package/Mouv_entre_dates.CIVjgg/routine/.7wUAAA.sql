


create procedure Mouv_entre_dates (	@datedeb		datetime = null,
									@datefin		datetime = null
								  )
with recompile
as
begin

set arithabort numeric_truncation off


create table #Final
(
CHEFPROD			char(8)			not null,
FICHIER				char(30)			null,
VALEUR				numeric(14,2)	not null
)


insert into #Final (CHEFPROD,FICHIER,VALEUR)
select isnull(ARCHEFP,''),'Lignes de reajustement',round(((RJLPAHT+RJLFRAIS)/CVLOT),2)*RJLQTE
from FAR,FRJL,FCV
where ARCODE=RJLARTICLE
and ARUNITACHAT=CVUNIF
and RJLDATE between @datedeb and @datefin

insert into #Final (CHEFPROD,FICHIER,VALEUR)
select isnull(ARCHEFP,''),'Stock init/Fluct/TID',round(((SILPAHT+SILFRAIS)/CVLOT),2)*SILQTE
from FAR,FSIL,FCV
where ARCODE=SILARTICLE
and ARUNITACHAT=CVUNIF
and SILDATE between @datedeb and @datefin

insert into #Final (CHEFPROD,FICHIER,VALEUR)
select isnull(ARCHEFP,''),'Lignes de casse',round(((LCLPAHT+LCLFRAIS)/CVLOT),2)*LCLQTE
from FAR,FLCL,FCV
where ARCODE=LCLARTICLE
and ARUNITACHAT=CVUNIF
and LCLDATE between @datedeb and @datefin

insert into #Final (CHEFPROD,FICHIER,VALEUR)
select isnull(ARCHEFP,''),'Lignes assemblage',(ASLPAHT+ASLFRAIS)*ASLQTE
from FAR,FASL
where ARCODE=ASLARTICLE
and ASLDATE between @datedeb and @datefin


select chef_de_produit=CHEFPROD,designation=FICHIER,valeur_FIFO=sum(VALEUR)
from #Final
group by CHEFPROD,FICHIER


drop table #Final


end
 



go

