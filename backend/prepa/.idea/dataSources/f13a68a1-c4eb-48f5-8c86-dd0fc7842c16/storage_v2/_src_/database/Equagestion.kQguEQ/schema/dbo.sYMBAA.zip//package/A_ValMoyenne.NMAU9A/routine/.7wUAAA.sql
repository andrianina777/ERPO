


/* Procedure donnant la liste des articles dont la valeur moyenne
		sur l''horizon demande est >= @valeur */


create procedure A_ValMoyenne (	@mois		tinyint,
							   	@an			smallint,
							   	@horizon	tinyint,
							   	@valeur		int,
							   	@chef		char(8) = null,
							   	@fournis	char(12) = null,
							   	@famille	char(8) = null,
							   	@article	char(15) = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date		datetime
select  @date = convert(datetime,convert(char(2),@mois)+"/01/"+convert(char(4),@an))
select  @date = dateadd(mm,@horizon+1,@date)

declare @dif	int
select @dif = ((@an-1992)*12)+@mois

declare @compteur	int
select @compteur=2

declare @Mois	tinyint
select @Mois=@mois

declare @An	smallint
select @An=@an

create table #Stock
(
Article		char(15)	not null,
Valeur		int				null
)

create table #Ventes
(
Article		char(15)	not null,
Valeur		int				null
)

create table #AR
(
Article		char(15)		not null,
Designation	varchar(80)			null,
Prix		numeric(14,2)		null
)


if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFAM=@famille
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
	end
else if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCODE=@article
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARCODE=@article
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end


create unique clustered index article on #AR (Article)

  insert into #Ventes (Article,Valeur)
  select RCCARTICLE,sum(RCCQTE*Prix)
  from #AR,FRCC
  where RCCARTICLE=#AR.Article
  and RCCDATE < @date
  group by RCCARTICLE

  set forceplan on

  /* Selection des stocks constates */

  insert into #Stock (Article,Valeur)
  select SKARTICLE,sum(SKQTE*Prix)
  from #AR,FSK(2)
  where SKARTICLE=Article
  and SKDIF between @dif and @dif+@horizon
  group by SKARTICLE
  
  set forceplan off
  
  update #Stock
  set Valeur=#Stock.Valeur-#Ventes.Valeur
  from #Ventes
  where #Stock.Article=#Ventes.Article
  

 select #Stock.Article,0,0,Valeur/@horizon,0,0,0,Designation
 from #Stock,#AR
 where #Stock.Article=#AR.Article
 group by #Stock.Article,Designation
 having Valeur/@horizon >= @valeur
 order by #Stock.Article

drop table #Stock
drop table #AR
drop table #Ventes

end



go

