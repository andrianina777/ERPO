


/* Procedure recapitulative des achats et ventes 
	@type = ""DMFA""  -> sortie par departements - marques - familles - articles
	@type = ""DMF""   -> sortie par departements - marques - familles
	@type = ""DM""	-> sortie par departements - marques
	@type = ""DF""    -> sortie par departements - familles
	@type = ""D""     -> sortie par departements
	@type = ""DFA""   -> sortie par departements - familles - articles */


create procedure Recapitulatif (@ent		char(5)		= null,
								@an			smallint,
								@moisdeb	tinyint	 	= 1,
								@moisfin	tinyint	 	= 12,
								@type		varchar(4)  = "DMFA",
								@depart		char(8)	 	= null,
								@marque		char(12)	= null,
								@famille	char(8)	 	= null,
								@article	char(15)	= null)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
ARDEPART		char(8)		not null,
ARFO			char(12)	not null,
ARFAM			char(8)		not null,
ARCODE			char(15)	not null,
CVLOT			int			not null,
ARLIB			varchar(80)		null
)

create table #Detail
(
depart			char(8)			not null,
marque			char(12)		not null,
famille			char(8)			not null,
article			char(15)		not null,
valachat_1		numeric(14,2)		null,
valachat		numeric(14,2)		null,
qteachat_1		int					null,
qteachat		int					null,
valventes_1		numeric(14,2)		null,
valventes		numeric(14,2)		null,
qteventes_1		int					null,
qteventes		int					null,
prixrevient_1	numeric(14,2)		null,
prixrevient		numeric(14,2)		null,
valstock		numeric(14,2)		null,
qtestock		int					null
)

create table #Final
(
depart			char(8)			not null,
marque			char(12)			not null,
famille			char(8)			not null,
article			char(15)			not null,
valachat_1		numeric(14,2)		null,
valachat		numeric(14,2)		null,
qteachat_1		int					null,
qteachat		int					null,
valventes_1		numeric(14,2)		null,
valventes		numeric(14,2)		null,
qteventes_1		int					null,
qteventes		int					null,
prixrevient_1	numeric(14,2)		null,
prixrevient		numeric(14,2)		null,
valstock		numeric(14,2)		null,
qtestock		int					null
)

/*** Selection des articles choisis */

insert into #Far (ARDEPART,ARFO,ARFAM,ARCODE,CVLOT,ARLIB)
select ARDEPART,ARFO,ARFAM,ARCODE,CVLOT,ARLIB
from FAR,FCV
where ARUNITACHAT=CVUNIF
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)

create unique clustered index article on #Far(ARCODE)

/*** Achats */

insert into #Detail (depart,marque,famille,article,valachat_1,qteachat_1)
select 	ARDEPART,ARFO,ARFAM,ARCODE,sum(BLLPRHT*BLLQTE),sum(BLLQTE)
from FBLL,#Far
where ARCODE=BLLAR
and datepart(yy,BLLDATE) = @an-1
and datepart(mm,BLLDATE) between @moisdeb and @moisfin
and (@ent is null or BLLENT=@ent)
group by ARDEPART,ARFO,ARFAM,ARCODE
union
select 	ARDEPART,ARFO,ARFAM,ARCODE,sum(RFLPAHT*RFLQTE),sum(RFLQTE)
from FRFL,#Far
where ARCODE=RFLARTICLE
and datepart(yy,RFLDATE) = @an-1
and datepart(yy,RFLDATE) between @moisdeb and @moisfin
and (@ent is null or RFLENT=@ent)
group by ARDEPART,ARFO,ARFAM,ARCODE


insert into #Detail (depart,marque,famille,article,valachat,qteachat)
select 	ARDEPART,ARFO,ARFAM,ARCODE,sum(BLLPRHT*BLLQTE),sum(BLLQTE)
from FBLL,#Far
where ARCODE=BLLAR
and datepart(yy,BLLDATE) = @an
and datepart(mm,BLLDATE) between @moisdeb and @moisfin
and (@ent is null or BLLENT=@ent)
group by ARDEPART,ARFO,ARFAM,ARCODE
union
select 	ARDEPART,ARFO,ARFAM,ARCODE,sum(RFLPAHT*RFLQTE),sum(RFLQTE)
from FRFL,#Far
where ARCODE=RFLARTICLE
and datepart(yy,RFLDATE) = @an
and datepart(yy,RFLDATE) between @moisdeb and @moisfin
and (@ent is null or RFLENT=@ent)
group by ARDEPART,ARFO,ARFAM,ARCODE


  
/*** Ventes et marges */
  
insert into #Detail (depart,marque,famille,article,valventes_1,qteventes_1,prixrevient_1)
select ARDEPART,ARFO,ARFAM,ARCODE,sum(STCAFA),sum(STQTEFA),sum(STPR)
from FST,#Far
where ARCODE=START
and STAN = @an-1
and STMOIS between @moisdeb and @moisfin
and (@ent is null or STENT=@ent)
group by ARDEPART,ARFO,ARFAM,ARCODE

insert into #Detail (depart,marque,famille,article,valventes,qteventes,prixrevient)
select ARDEPART,ARFO,ARFAM,ARCODE,sum(STCAFA),sum(STQTEFA),sum(STPR)
from FST,#Far
where ARCODE=START
and STAN = @an
and STMOIS between @moisdeb and @moisfin
and (@ent is null or STENT=@ent)
group by ARDEPART,ARFO,ARFAM,ARCODE
  

/*** Stock */

insert into #Detail (depart,marque,famille,article,valstock,qtestock)
select ARDEPART,ARFO,ARFAM,ARCODE,sum(round(((STPAHT+STFRAIS)/CVLOT),2)*STQTE),sum(STQTE)
from FSTOCK,#Far,FDP
where ARCODE=STAR
and STQTE != 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,ARFO,ARFAM,ARCODE


/*** insert final */

if (@type = "DMFA")
begin
	insert into #Final (depart,marque,famille,article,
						valachat_1,valachat,
						qteachat_1,qteachat,
						valventes_1,valventes,
						qteventes_1,qteventes,
						prixrevient_1,prixrevient,
						valstock,qtestock)
	select depart,marque,famille,article,
		sum(isnull(valachat_1,0)),
		sum(isnull(valachat,0)),
		sum(isnull(qteachat_1,0)),
		sum(isnull(qteachat,0)),
		sum(isnull(valventes_1,0)),
		sum(isnull(valventes,0)),
		sum(isnull(qteventes_1,0)),
		sum(isnull(qteventes,0)),
		sum(isnull(prixrevient_1,0)),
		sum(isnull(prixrevient,0)),
		sum(isnull(valstock,0)),
		sum(isnull(qtestock,0))
	from #Detail
	group by depart,marque,famille,article
end
else if (@type = "DMF")
begin
	insert into #Final (depart,marque,famille,article,
						valachat_1,valachat,
						qteachat_1,qteachat,
						valventes_1,valventes,
						qteventes_1,qteventes,
						prixrevient_1,prixrevient,
						valstock,qtestock)
		select depart,marque,famille,'',
		sum(isnull(valachat_1,0)),
		sum(isnull(valachat,0)),
		sum(isnull(qteachat_1,0)),
		sum(isnull(qteachat,0)),
		sum(isnull(valventes_1,0)),
		sum(isnull(valventes,0)),
		sum(isnull(qteventes_1,0)),
		sum(isnull(qteventes,0)),
		sum(isnull(prixrevient_1,0)),
		sum(isnull(prixrevient,0)),
		sum(isnull(valstock,0)),
		sum(isnull(qtestock,0))
	from #Detail
	group by depart,marque,famille
end
else if (@type = "DM")
begin
	insert into #Final (depart,marque,famille,article,
						valachat_1,valachat,
						qteachat_1,qteachat,
						valventes_1,valventes,
						qteventes_1,qteventes,
						prixrevient_1,prixrevient,
						valstock,qtestock)
		select depart,marque,'','',
		sum(isnull(valachat_1,0)),
		sum(isnull(valachat,0)),
		sum(isnull(qteachat_1,0)),
		sum(isnull(qteachat,0)),
		sum(isnull(valventes_1,0)),
		sum(isnull(valventes,0)),
		sum(isnull(qteventes_1,0)),
		sum(isnull(qteventes,0)),
		sum(isnull(prixrevient_1,0)),
		sum(isnull(prixrevient,0)),
		sum(isnull(valstock,0)),
		sum(isnull(qtestock,0))
	from #Detail
	group by depart,marque
end
else if (@type = "DF")
begin
	insert into #Final (depart,marque,famille,article,
						valachat_1,valachat,
						qteachat_1,qteachat,
						valventes_1,valventes,
						qteventes_1,qteventes,
						prixrevient_1,prixrevient,
						valstock,qtestock)
		select depart,'',famille,'',
		sum(isnull(valachat_1,0)),
		sum(isnull(valachat,0)),
		sum(isnull(qteachat_1,0)),
		sum(isnull(qteachat,0)),
		sum(isnull(valventes_1,0)),
		sum(isnull(valventes,0)),
		sum(isnull(qteventes_1,0)),
		sum(isnull(qteventes,0)),
		sum(isnull(prixrevient_1,0)),
		sum(isnull(prixrevient,0)),
		sum(isnull(valstock,0)),
		sum(isnull(qtestock,0))
	from #Detail
	group by depart,famille
end
else if (@type = "D")
begin
	insert into #Final (depart,marque,famille,article,
						valachat_1,valachat,
						qteachat_1,qteachat,
						valventes_1,valventes,
						qteventes_1,qteventes,
						prixrevient_1,prixrevient,
						valstock,qtestock)
		select depart,'','','',
		sum(isnull(valachat_1,0)),
		sum(isnull(valachat,0)),
		sum(isnull(qteachat_1,0)),
		sum(isnull(qteachat,0)),
		sum(isnull(valventes_1,0)),
		sum(isnull(valventes,0)),
		sum(isnull(qteventes_1,0)),
		sum(isnull(qteventes,0)),
		sum(isnull(prixrevient_1,0)),
		sum(isnull(prixrevient,0)),
		sum(isnull(valstock,0)),
		sum(isnull(qtestock,0))
	from #Detail
	group by depart
end
else if (@type = "DFA")
begin
	insert into #Final (depart,marque,famille,article,
						valachat_1,valachat,
						qteachat_1,qteachat,
						valventes_1,valventes,
						qteventes_1,qteventes,
						prixrevient_1,prixrevient,
						valstock,qtestock)
		select depart,'',famille,article,
		sum(isnull(valachat_1,0)),
		sum(isnull(valachat,0)),
		sum(isnull(qteachat_1,0)),
		sum(isnull(qteachat,0)),
		sum(isnull(valventes_1,0)),
		sum(isnull(valventes,0)),
		sum(isnull(qteventes_1,0)),
		sum(isnull(qteventes,0)),
		sum(isnull(prixrevient_1,0)),
		sum(isnull(prixrevient,0)),
		sum(isnull(valstock,0)),
		sum(isnull(qtestock,0))
	from #Detail
	group by depart,famille,article
end

drop table #Detail

/*** select final */

if (@type = "DMFA")
begin
  select depart,marque,famille,article,ARLIB,
		  valachat_1,valachat,qteachat_1,qteachat,valventes_1,valventes,
		  qteventes_1,qteventes,valventes_1-prixrevient_1,valventes-prixrevient,
			  marge_1=round(((valventes_1-prixrevient_1)*abs(sign(valventes_1)))/(valventes_1+(1-abs(sign(valventes_1)))),2)*100,
			  marge=round(((valventes-prixrevient)*abs(sign(valventes)))/(valventes+(1-abs(sign(valventes)))),2)*100,
			  valstock,qtestock
	  from #Final,#Far
	  where ARCODE=article
	  order by depart,marque,famille,article
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart,marque,famille
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart,marque
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock)
end
else if (@type = "DMF")
begin
  select depart,marque,famille,article,'',
		  valachat_1,valachat,qteachat_1,qteachat,valventes_1,valventes,
		  qteventes_1,qteventes,valventes_1-prixrevient_1,valventes-prixrevient,
			  marge_1=round(((valventes_1-prixrevient_1)*abs(sign(valventes_1)))/(valventes_1+(1-abs(sign(valventes_1)))),2)*100,
			  marge=round(((valventes-prixrevient)*abs(sign(valventes)))/(valventes+(1-abs(sign(valventes)))),2)*100,
			  valstock,qtestock
	  from #Final
	  order by depart,marque,famille
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart,marque
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock)
end
else if (@type = "DM")
begin
  select depart,marque,famille,article,"",
		  valachat_1,valachat,qteachat_1,qteachat,valventes_1,valventes,
		  qteventes_1,qteventes,valventes_1-prixrevient_1,valventes-prixrevient,
			  marge_1=round(((valventes_1-prixrevient_1)*abs(sign(valventes_1)))/(valventes_1+(1-abs(sign(valventes_1)))),2)*100,
			  marge=round(((valventes-prixrevient)*abs(sign(valventes)))/(valventes+(1-abs(sign(valventes)))),2)*100,
			  valstock,qtestock
	  from #Final
	  order by depart,marque
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock)
end
else if (@type = "DF")
begin
  select depart,marque,famille,article,"",
		  valachat_1,valachat,qteachat_1,qteachat,valventes_1,valventes,
		  qteventes_1,qteventes,valventes_1-prixrevient_1,valventes-prixrevient,
			  marge_1=round(((valventes_1-prixrevient_1)*abs(sign(valventes_1)))/(valventes_1+(1-abs(sign(valventes_1)))),2)*100,
			  marge=round(((valventes-prixrevient)*abs(sign(valventes)))/(valventes+(1-abs(sign(valventes)))),2)*100,
			  valstock,qtestock
	  from #Final
	  order by depart,famille
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock)
end
else if (@type = "D")
begin
  select depart,marque,famille,article,"",
		  valachat_1,valachat,qteachat_1,qteachat,valventes_1,valventes,
		  qteventes_1,qteventes,valventes_1-prixrevient_1,valventes-prixrevient,
			  marge_1=round(((valventes_1-prixrevient_1)*abs(sign(valventes_1)))/(valventes_1+(1-abs(sign(valventes_1)))),2)*100,
			  marge=round(((valventes-prixrevient)*abs(sign(valventes)))/(valventes+(1-abs(sign(valventes)))),2)*100,
			  valstock,qtestock
	  from #Final
	  order by depart
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock)
end
else if (@type = "DFA")
begin
  select depart,marque,famille,article,ARLIB,
		  valachat_1,valachat,qteachat_1,qteachat,valventes_1,valventes,
		  qteventes_1,qteventes,valventes_1-prixrevient_1,valventes-prixrevient,
			  marge_1=round(((valventes_1-prixrevient_1)*abs(sign(valventes_1)))/(valventes_1+(1-abs(sign(valventes_1)))),2)*100,
			  marge=round(((valventes-prixrevient)*abs(sign(valventes)))/(valventes+(1-abs(sign(valventes)))),2)*100,
			  valstock,qtestock
	  from #Final,#Far
	  where ARCODE=article
	  order by depart,famille,article
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart,famille
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock) by depart
	  compute sum(valachat_1),sum(valachat),sum(qteachat_1),sum(qteachat),sum(valventes_1),sum(valventes),
		  sum(qteventes_1),sum(qteventes),sum(valventes_1-prixrevient_1),sum(valventes-prixrevient),
		  sum(valstock),sum(qtestock)
end

drop table #Far
drop table #Final

end



go

