


/* Procedure renvoyant les lignes de BE avec la marge par REP sedentaire */

create procedure Marges_REP (@ent		char(5) 	  = null,
							 @an		smallint	  = null
						    )
with recompile
as
begin

set arithabort numeric_truncation off

declare	@mois	tinyint,
		@date1	smalldatetime,
		@date2	smalldatetime
		
if @an is null
	select  @an = datepart(yy,getdate()),
			@mois = datepart(mm,getdate())
else
	select  @mois = datepart(mm,getdate())

		
select @date1=convert(smalldatetime,"01/01/"+convert(varchar,@an))
select @date2=convert(smalldatetime,"12/31/"+convert(varchar,@an))


create table #BE
(
Rep				char(10)		not null,
Date			smalldatetime	not null,
Article			char(15)		not null,
Quantite		int				not null,
Valeur_Vente	numeric(14,2)	not null,
Marge_Val		numeric(14,2)	not null,
ID				numeric(14,0)	identity
)


insert into #BE (Rep,Date,Article,Quantite,Valeur_Vente,Marge_Val)
select CLREP,dateadd(hh,19,BELDATE),BELARTICLE,BELQTE,BELTOTALHT,0
from FBEL,FBE,FAR,FCL
where ARCODE=BELARTICLE
and BECODE=BELCODE
and CLCODE=BELCL
and BELDATE between @date1 and @date2
and ARTYPE=0
and BEDEMO=0
and (@ent is null or (BELENT=@ent and BEENT=@ent and CLENT=@ent))


declare expeditions cursor 
for select ID,Date,Article,Quantite,Valeur_Vente
from #BE
for update of Marge_Val

declare @seq			numeric(14,0),
		@date			smalldatetime,
		@article		char(15),
		@qte			int,
		@totalht		numeric(14,2),
		@PrixRevient	numeric(14,4)

open expeditions

fetch expeditions
into @seq,@date,@article,@qte,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @PrixRevient=isnull(PUMP,0)
	from FPUM
	where PUMAR = @article
	and PUMDATE <= @date
	having PUMAR = @article
	and PUMDATE <= @date
	and PUMDATE = max(PUMDATE)
	
	if @PrixRevient is null
		select @PrixRevient=0
	
	if @totalht = 0
	begin
		update #BE set Marge_Val=-(@PrixRevient*@qte)
		where current of expeditions
	end
	else if @PrixRevient != 0
	begin
		update #BE set Marge_Val=@totalht-(@PrixRevient*@qte)
		where current of expeditions	
	end
	else
	begin
		update #BE set Marge_Val=@totalht
		where current of expeditions
	end
	
	
	fetch expeditions
	into @seq,@date,@article,@qte,@totalht
	
end

close expeditions
deallocate cursor expeditions


select Rep=Rep,
		Qte_Mois=sum(case when datepart(mm,Date)=@mois then Quantite else 0 end),
		Vente_Mois=sum(case when datepart(mm,Date)=@mois then Valeur_Vente else 0 end),
		Marge_Valeur_Mois=sum(case when datepart(mm,Date)=@mois then Marge_Val else 0 end),
		Marge_PC_Mois=convert(numeric(14,2),0),
		Qte_An=sum(Quantite),
		Vente_An=sum(Valeur_Vente),
		Marge_Valeur_An=sum(Marge_Val),
		Marge_PC_An=convert(numeric(14,2),0)
into #Finale
from #BE
group by Rep

drop table #BE


update #Finale
set Marge_PC_Mois=(case when Vente_Mois != 0 then convert(numeric(14,2),Marge_Valeur_Mois/Vente_Mois*100)
				   	    when Vente_Mois = 0 then 0 end),
	Marge_PC_An=(case when Vente_An != 0 then convert(numeric(14,2),Marge_Valeur_An/Vente_An*100)
				      when Vente_An = 0 then 0 end)


select Rep=Rep,Nom=RENOM,Qte_Mois=Qte_Mois,Vente_Mois=Vente_Mois,Marge_Valeur_Mois=Marge_Valeur_Mois,
		Marge_PC_Mois=Marge_PC_Mois,Qte_An=Qte_An,Vente_An=Vente_An,
		Marge_Valeur_An=Marge_Valeur_An,Marge_PC_An=Marge_PC_An
from #Finale,FREP
where RECODE=Rep
order by Rep

drop table #Finale


end



go

