


create procedure NewFMSAR_Mois (@Article	char(15),
								@an			smallint,
								@mois		tinyint)
with recompile
as
begin

declare @lot	smallint

declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@date1			datetime,
		@date2			datetime

if @mois=1
	begin
		select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'01/31/'+convert(varchar(4),@an))
	end
else if @mois=2
	begin
		select @smalldate1=convert(smalldatetime,'02/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		select @smalldate2=dateadd(dd,-1,@smalldate2)
	end
else if @mois=3
	begin
		select @smalldate1=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'03/31/'+convert(varchar(4),@an))
	end
else if @mois=4
	begin
		select @smalldate1=convert(smalldatetime,'04/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'04/30/'+convert(varchar(4),@an))
	end
else if @mois=5
	begin
		select @smalldate1=convert(smalldatetime,'05/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'05/31/'+convert(varchar(4),@an))
	end
else if @mois=6
	begin
		select @smalldate1=convert(smalldatetime,'06/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'06/30/'+convert(varchar(4),@an))
	end
else if @mois=7
	begin
		select @smalldate1=convert(smalldatetime,'07/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'07/31/'+convert(varchar(4),@an))
	end
else if @mois=8
	begin
		select @smalldate1=convert(smalldatetime,'08/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'08/31/'+convert(varchar(4),@an))
	end
else if @mois=9
	begin
		select @smalldate1=convert(smalldatetime,'09/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'09/30/'+convert(varchar(4),@an))
	end
else if @mois=10
	begin
		select @smalldate1=convert(smalldatetime,'10/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'10/31/'+convert(varchar(4),@an))
	end
else if @mois=11
	begin
		select @smalldate1=convert(smalldatetime,'11/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'11/30/'+convert(varchar(4),@an))
	end
else if @mois=12
	begin
		select @smalldate1=convert(smalldatetime,'12/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))
	end

select @date1 = convert(datetime,@smalldate1)
select @date2 = convert(datetime,@smalldate2)
		

select @lot=CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARCODE=@Article



select Article=SILARTICLE,Annee=datepart(yy,SILDATE),Mois=datepart(mm,SILDATE),
Total=sum(SILQTE),PrixRevientTot=sum(round(((SILPAHT+SILFRAIS)/@lot),2)*SILQTE),Type='F',
Depot=SILNUMDEP
into #Entree
from FSIL
where SILARTICLE=@Article
and SILDATE between @smalldate1 and @smalldate2
group by SILARTICLE,datepart(yy,SILDATE),datepart(mm,SILDATE),SILNUMDEP
having sum(SILQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),
sum(RJLQTE),sum(round(((RJLPAHT+RJLFRAIS)/@lot),2)*RJLQTE),'R',RJLNUMDEP
from FRJL
where RJLARTICLE=@Article
and RJLDATE between @smalldate1 and @smalldate2
group by RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),RJLNUMDEP
having sum(RJLQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),
sum(LCLQTE),sum(round(((LCLPAHT+LCLFRAIS)/@lot),2)*LCLQTE),'C',LCLNUMDEP
from FLCL
where LCLARTICLE=@Article
and LCLDATE between @date1 and @date2
group by LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),LCLNUMDEP
having sum(LCLQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),
sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE),'A',ASLNUMDEP
from FASL
where ASLARTICLE=@Article
and ASLDATE between @date1 and @date2
group by ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),ASLNUMDEP
having sum(ASLQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),
sum(RMQTE),sum(round(((RMPAHT+RMFRAIS)/@lot),2)*RMQTE),'M',RMNUMDEP
from FRM
where RMARTICLE=@Article
and RMDATE between @smalldate1 and @smalldate2
group by RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),RMNUMDEP
having sum(RMQTE)!=0


insert into #Entree
select BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),
sum(BLLQTE),sum(round(((BLLPRHT)/@lot),2)*BLLQTE),'E',BLLNUMDEP
from FBLL
where BLLAR=@Article
and BLLDATE between @smalldate1 and @smalldate2
group by BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),BLLNUMDEP
having sum(BLLQTE)!=0


insert into #Entree
select DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),
sum(DOLQTE),sum(round(((DOLPRHT)/@lot),2)*DOLQTE),'E',DOLNUMDEP
from FDOL
where DOLAR=@Article
and DOLDATE between @smalldate1 and @smalldate2
group by DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),DOLNUMDEP



insert into #Entree
select RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),
-(sum(RFLQTE)),-(sum(round(((RFLPAHT)/@lot),2)*RFLQTE)),'E',RFLNUMDEP
from FRFL
where RFLARTICLE=@Article
and RFLDATE between @smalldate1 and @smalldate2
group by RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),RFLNUMDEP
having sum(RFLQTE)!=0


insert into #Entree
select FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE),
sum(FALQTE),sum(round(((STPAHT+STFRAIS)/@lot),2)*FALQTE),'S',1
from FFAL,FSTOCK
where FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALARTICLE=@Article
and FALDATE between @smalldate1 and @smalldate2
group by FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE)
having sum(FALQTE)!=0

delete FMS
where MSARTICLE=@Article
and MSANNEE = @an
and MSMOIS = @mois


insert into FMS(MSARTICLE,MSANNEE,MSMOIS,MSQTE,MSTOTPR,MSTYPE,MSDEPOT)
select Article,Annee,Mois,QteTot=sum(Total),PrixTot=sum(PrixRevientTot),Type,Depot
from #Entree
group by Article,Annee,Mois,Type,Depot
order by Article,Annee,Mois,Type,Depot

drop table #Entree

end



go

