





create procedure Historise_Utilisateurs
as
begin
insert into FHUT (HUTUID,HUTNAME,HUTDATE,HUTSUID,HUTLOGIN)
select sysusers.uid,sysusers.name,getdate(),sysusers.suid,master..syslogins.name
from sysusers,master..syslogins
where sysusers.uid > 0
and sysusers.suid =master..syslogins.suid
order by sysusers.uid
end




go

