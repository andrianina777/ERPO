


/* Procedure permettant de recuperer les articles sur une periode donnee
	dont la rotation est > ou < aux valeurs indiquees
	depuis les fichiers FSTCC et FSK  */
	
	
create procedure A_RotaFiltre  (@mois		tinyint,
							  	@an			smallint,
							  	@horizon	tinyint,
								@sens		tinyint,
							  	@rotation	smallint,
						   		@chef		char(8) 	= null,
								@fournis	char(12)	= null,
								@famille	char(8)		= null,
								@article	char(15)	= null
								)
with recompile
as
begin

set arithabort numeric_truncation off


declare @lemois	int


declare @dif	int
select @dif = ((@an-1992)*12)+@mois


create table #Cdes
(
ArticleCP	char(15)	not null,
Qte			int				null,
Dif			int			not null
)

create table #Stock
(
ArticleST	char(15)	not null,
Qte			int				null,
Dif			int			not null
)

create table #Final
(
ArticleF	char(15)	not null,
Rotation	float			null
)

create table #AR
(
Article		char(15)	not null,
Designation	varchar(80)		null,
Prix		numeric(14,2)	null
)


if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFAM=@famille
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
	end
else if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCODE=@article
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARCODE=@article
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end


create unique clustered index article on #AR (Article)

/* Selection des Commandes pour projection des stocks */

 set forceplan on

 insert into #Cdes (ArticleCP,Qte,Dif)
 select STCCART,isnull(sum(STCCQTE),0),(STCCAN-1992)*12+STCCMOIS
 from #AR,FSTCC
 where STCCART=Article
 and (STCCAN-1992)*12+STCCMOIS between @dif and (@dif+@horizon-1)
 group by Article,(STCCAN-1992)*12+STCCMOIS

 
 insert into #Stock (ArticleST,Qte,Dif)
 select SKARTICLE,sum(SKQTE),SKDIF
 from #AR,FSK(2)
 where SKARTICLE=Article
 and SKDIF between @dif and (@dif+@horizon-1)
 group by SKARTICLE,SKDIF

 set forceplan off

/* Insertion reciproque des articles manquants dans stocks et cdes */

insert into #Stock (ArticleST,Qte,Dif)
select ArticleCP,0,Dif
from #Cdes
where not exists (select * from #Stock
					where #Cdes.ArticleCP = #Stock.ArticleST
					and #Cdes.Dif = #Stock.Dif)

insert into #Cdes (ArticleCP,Qte,Dif)
select ArticleST,0,Dif
from #Stock
where not exists (select * from #Cdes
					where #Cdes.ArticleCP = #Stock.ArticleST
					and #Cdes.Dif = #Stock.Dif)

/* Maj des stocks projetes si annee >= annee en cours */

if (@an >= datepart(yy,getdate()))
begin
  select @lemois=1
  
  while (@lemois <= @horizon)
  begin
	 
  update #Stock
  set Qte=Qte-(select sum(Qte) from #Cdes
			  where #Cdes.ArticleCP = #Stock.ArticleST
			  and #Cdes.Dif between @dif + 1 and @dif + @lemois
			  and #Stock.Dif = @dif + @lemois + 1)
			  
	select @lemois = @lemois + 1
  end
end


/* Creation de la table finale */

insert into #Final (ArticleF,Rotation)
select ArticleST,convert(float,(sum(#Cdes.Qte)*@horizon))/convert(float,sum(#Stock.Qte))
from #Stock,#Cdes
where ArticleST=ArticleCP
group by ArticleST
having sum(#Stock.Qte) > 0
union
select ArticleST,0
from #Stock,#Cdes
where ArticleST=ArticleCP
group by ArticleST
having sum(#Stock.Qte) <= 0

drop table #Cdes
drop table #Stock

update #Final
set Rotation=0
where Rotation is null

if (@sens = 0)
	begin
		select ArticleF,0,0,0,0,0,Rotation,Designation
		from #Final,#AR
		where ArticleF=Article
		and Rotation <= @rotation
	end
else
	begin
		select ArticleF,0,0,0,0,0,Rotation,Designation
		from #Final,#AR
		where ArticleF=Article
		and Rotation >= @rotation
	end
	

drop table #AR
drop table #Final

end



go

