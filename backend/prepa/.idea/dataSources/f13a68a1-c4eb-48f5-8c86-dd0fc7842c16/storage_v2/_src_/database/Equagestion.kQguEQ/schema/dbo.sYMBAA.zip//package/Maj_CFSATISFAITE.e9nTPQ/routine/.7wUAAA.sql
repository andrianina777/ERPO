



create procedure Maj_CFSATISFAITE  (@commande	char(10),
									@ent		char(5) = null)
with recompile
as
begin

  declare @seq			int,
		  @qte			int,
		  @reste		int,
		  @lignes		int,
		  @satisfaite	int,
		  @nonlivre		int,
		  @artype		tinyint
		  
  select @satisfaite = 0,
  		 @nonlivre = 0
  
  select @lignes=count(*) from FCFL
  where CFLCODE=@commande
  	and isnull(CFLENT,'')=isnull(@ent,'')
  
  
  if @lignes > 0
  begin
  
	declare commande cursor 
	for select CFLSEQ,CFLQTE,CFLRESTE
	from FCFL,FAR
	where CFLARTICLE=ARCODE
	and CFLCODE=@commande
	and isnull(CFLENT,'')=isnull(@ent,'')
	and ARTYPE in (0,1)
	for read only
	
	
	open commande
	
	fetch commande
	into @seq,@qte,@reste
	
	while (@@sqlstatus = 0)
		begin
		
		
		if @satisfaite = 0
		  begin
		  	if @reste <= 0 select @satisfaite = 2
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
			else select @nonlivre = 1
		  end
		else
		if @satisfaite = 2
		  begin
		  	if @qte = @reste select @satisfaite = 1
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
		  end
	
		
		fetch commande
		into @seq,@qte,@reste
		
	end
	
	close commande
	deallocate cursor commande
	
	if (@satisfaite = 2) and (@nonlivre = 1)
	select @satisfaite = 1	
	
	update FCF set CFSATISFAITE = @satisfaite
	where CFCODE=@commande
  		and isnull(CFENT,'')=isnull(@ent,'')
  
  end
  else if @lignes = 0
  begin
  
	update FCF set CFSATISFAITE = 2
	where CFCODE=@commande
  		and isnull(CFENT,'')=isnull(@ent,'')
  
  end

end



go

