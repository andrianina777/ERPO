
/* Procedure utilisee par le module "Preparation des expeditions" */


create procedure BEPrep(@ent			char(5) = null,
						@FromDate 		smalldatetime,
						@ToDate 		smalldatetime,
						@MauvaisPayeur 	tinyint = 0,
						@EtatStock 		tinyint = 1,
						@StockLocal		tinyint = 0,
						@ARSansNum 		tinyint = 0,
						@CdesTelFax 	tinyint = 0,
						@Produits		tinyint = 1,
						@SansOfferts	tinyint = 1,
						@Livrables		tinyint = 1,
						@valeurdep		numeric(14,2) = 0.00,
						@valeurfin		numeric(14,2) = 0.00,
						@FromClient 	char(12) = null,
						@ToClient 		char(12) = null,
						@GroupeClient	char(12)	= null,
						@FromArticle 	char(15) = null,
						@ToArticle 		char(15) = null,
						@Rep			char(8) = null,			/* Representant central */
						@Depot			char(4),
						@Marque			char(8)	= null,
						@Depart			char(8)	= null,
						@Fam			char(8) = null,
						@GroupArticles	tinyint = null,
						@pays			char(8) = null,
						@commande		char(10) = null,
						@prio1			tinyint = null,
						@prio2			tinyint = null,
						@Matiere		varchar(14) = null,
						@Couleur		char(8) = null,
						@Grille			char(10) = null,
						@expMode		tinyint = null,
						@expMode2		tinyint = null,
						@avecCCbloque	tinyint = 0,			/* 0 = sans les cdes bloquees, 1 = avec, 2 = uniquement les cdes bloquees */
						@avecprep		tinyint	= 0,			/* 1 = avec les commandes entierement preparees mais non expediees */	
						@stringStade 	varchar(10) = null,		/* Chaine Comprenant les stades des commandes (maxi 10 stades, de 0 a 9) */
						@articleInclus	char(15) = null			/* article qui doit faire partie du portefeuille client */
						)
with recompile						
as
begin

set arithabort numeric_truncation off


declare @OK			tinyint,
		@CT			tinyint,
		@MP			tinyint,
		@CI			tinyint

if @MauvaisPayeur = 0
  begin
	  select 	@OK = 0, @CT = 1, @MP = 0, @CI = 0
  end
else if @MauvaisPayeur = 1
  begin
	  select 	@OK = 0, @CT = 1, @MP = 2, @CI = 2
  end
else if @MauvaisPayeur = 2
  begin
	  select 	@OK = 2, @CT = 2, @MP = 2, @CI = 2
  end



if @ToClient is null
	select @ToClient=@FromClient
if @ToArticle is null
	select @ToArticle=@FromArticle

declare @tel	tinyint
declare	@fax	tinyint
declare	@bord	tinyint
declare	@telex	tinyint
declare	@cour	tinyint
declare	@mag	tinyint
declare @rep	tinyint
declare @net	tinyint
declare @export	tinyint

if @CdesTelFax=0
begin
select 	@tel=0
select	@fax=1
select	@bord=2
select	@telex=3
select	@cour=4
select	@mag=5
select	@rep=6
select	@net=7
select	@export=8
end
if @CdesTelFax=1
begin
select 	@tel=0
select	@fax=1
select	@bord=0
select	@telex=0
select	@cour=0
select	@mag=0
select	@rep=0
select	@net=0
select	@export=0
end
if @CdesTelFax=2
begin
select 	@tel=2
select	@fax=2
select	@bord=2
select 	@telex=3
select	@cour=4
select	@mag=5
select	@rep=6
select	@net=7
select	@export=8
end

create table #Prep
(
CCLSEQ			int				not null,
CCLCL			char(12)		not null,
CLNOM1			varchar(35)		not null,
CCLCODE			char(10)		not null,
CCLNUM			int					null,
CCLDATE			datetime			null,
CCLARTICLE		char(15)		not null,
CCLLIBRE		varchar(255)		null,
CCLRESTE		int					null,
MODELIV			char(2)				null,
CCECHSPE		tinyint				null,
CCFRANCO		tinyint				null,
CCFRANCOBE		tinyint				null,
CLPAYEUR		tinyint			not null,
CCLTOTALHT		numeric(14,2)		null,
CCLQTE			int					null,
CLNUMCOMPTABLE	char(12)		not null,
CLPREP			tinyint			not null,
CCPREP			tinyint			not null,
CCCODEADR		char(8)				null,
CCTARIF			char(8)				null,
CCLDEV			char(3)				null,
CCLCOURSDEV		numeric(16,10)		null,
CCLPHTDEV		numeric(14,2)		null,
CCLTOTALHTDEV	numeric(14,2)		null,
CCLR1			real				null,
CCLR2			real				null,
CCLR3			real				null,
CCLFACTMAN		tinyint				null,
CCLOFFERT		tinyint				null,
CCLUNITFACT		tinyint				null,
CCLPHT			numeric(14,2)		null,
CCLTV			char(4)				null,
CCLTYPE			tinyint				null,
CCNOM			varchar(35)			null,
CCNOM2			varchar(50)			null,
CCPRENOM		varchar(35)			null,
CCADR1			varchar(50)			null,
CCADR2			varchar(50)			null,
CCCP			varchar(12)			null,
CCVILLE			varchar(30)			null,
CCPY			char(8)				null,
CCPAYS			varchar(30)			null,
CCDATECOM		datetime			null,
CCLDATECRE		datetime			null,
CCCOMMENTAIRES	varchar(255)		null,
CCREFCOMCL		varchar(15)			null,
CLCCBE			tinyint				null,
CLPRIORITE		tinyint				null,
CCOK			int					null,
MARGIN			numeric(12,2)		null,
CCSATISFAITE	tinyint				null,
CCLQTERES		int					null,
CCLDATERESFIN	smalldatetime		null,
CCLDEPOTRES		char(4)				null,
CVLOT			int					null,
CCBEBLOQUE		tinyint				null,
AR_TYPE			tinyint				null,
CCLATTACHE		char(10)			null,
CCLQTEPREP		int					null,
CCLMARCHE		char(12)			null,
CCLREP			char(8)				null,
CCLLOT			char(12)			null,
NLOTDATEPER		datetime			null,
SEQ				numeric(14,0)	identity
)


create table #Stock
(
ArticleCde	char(15)	not null,
StockDepot	int				null,
StockAutre	int				null,
StockTotal	int				null,
StockPick	int				null
)

create table #StockLivrable
(
ArticleCde	char(15)	not null,
StockDepot	int				null,
StockAutre	int				null,
StockTotal	int				null
)


create table #StockDep
(
Article		char(15)	not null,
Qte			int				null,
Depot		char(4)			null,
Emplace		char(8)			null
)

create table #Reservations
(
ArticleRes	char(15)	not null,
DepotRes	int				null,
TotalRes	int				null
)


create table #Articles
(
CCLARTICLE		char(15)	not null,
TotalALivrer	int				null
)

create table #CdesCL
(
RCCARTICLE		char(15)	not null,
RCCQTE			int				null,	/* Total reste a livrer toutes commandes confondues */
TotalPrep		int				null	/* Total prepare toutes commandes confondues */
)

create table #Art
(
CCLARTICLE		char(15)	not null
)

create table #CdesFO
(
CFLARTICLE		char(15)	not null,
ARecevoir		int				null
)

create table #Tot_temp
(
client_temp		char(12)		not null,
total_temp		numeric(14,2)		null
)

create table #Totaux
(
client		char(12)		not null,
total		numeric(14,2)		null
)

create table #TotCC
(
cclcode		char(10)		not null,
completion	numeric(12,2)		null
)



insert into #Prep (CCLSEQ,CCLCL,CLNOM1,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,
					CCLRESTE,MODELIV,CCECHSPE,CCFRANCO,CCFRANCOBE,CLPAYEUR,CCLTOTALHT,CCLQTE,
					CLNUMCOMPTABLE,CLPREP,CCPREP,CCCODEADR,CCTARIF,CCLDEV,
					CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLFACTMAN,
					CCLOFFERT,CCLUNITFACT,CCLPHT,CCLTV,CCLTYPE,CCNOM,CCNOM2,CCPRENOM,CCADR1,CCADR2,CCCP,
					CCVILLE,CCPY,CCPAYS,CCDATECOM,CCLDATECRE,CCCOMMENTAIRES,CCREFCOMCL,CLCCBE,
					CLPRIORITE,MARGIN,CCSATISFAITE,CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,CVLOT,
					CCBEBLOQUE,AR_TYPE,CCLATTACHE,CCLQTEPREP,CCLMARCHE,CCLREP,
					CCLLOT,NLOTDATEPER)
select CCLSEQ,CCLCL,isnull(CLNOM1,""),CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,
CCLRESTE,MODELIV=substring(CCMODELIV,1,2),CCECHSPE,isnull(CCFRANCO,0),isnull(CCFRANCOBE,0),CLPAYEUR,
CCLTOTALHT,CCLQTE,CLNUMCOMPTABLE,CLPREP,isnull(CCPREP,0),isnull(CCCODEADR,""),CCTARIF,CCLDEV,
CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLFACTMAN,CCLOFFERT,
CCLUNITFACT,CCLPHT,CCLTV,CCLTYPE,isnull(CCNOM,""),isnull(CCNOM2,""),isnull(CCPRENOM,""),isnull(CCADR1,""),isnull(CCADR2,""),isnull(CCCP,""),
isnull(CCVILLE,""),CCPY,CCPAYS,CCDATECOM,CCLDATECRE,CCCOMMENTAIRES,CCREFCOMCL,CLCCBE,CLPRIORITE,
(case when isnull(CCLTOTALHT,0)=0 then 0 else round((isnull(CCLTOTALHT,0) - (CCLQTE*isnull(ARPRM,0))) /isnull(CCLTOTALHT,0),2) end)*100,
CCSATISFAITE,isnull(CCLQTERES,0),CCLDATERESFIN,CCLDEPOTRES,CVLOT,CCBEBLOQUE,ARTYPE,isnull(CCLATTACHE,""),
isnull(CCLQTEPREP,0),isnull(CCLMARCHE,""),CCLREP,
CCLLOT,NLOTDATEPER
from FRCC,FCCL,FCC,FCL,FAR,FCV,FNLOT
where CCLSEQ=RCCSEQ
and ARCODE=RCCARTICLE
and CVUNIF=CCLUNITFACT
and (@Matiere is null or ARMATIERE=@Matiere)
and (@Couleur is null or ARCOULEUR=@Couleur)
and (@Grille is null or ARGRILLE=@Grille)
and (@Marque is null or ARFO=@Marque)
and (@Depart is null or ARDEPART=@Depart)
and (@Fam is null or ARFAM=@Fam)
and (@FromClient is null or RCCCL between @FromClient and @ToClient)
and (@GroupeClient is null or CLCODEGROUPE=@GroupeClient)
and (@FromArticle is null or RCCARTICLE between @FromArticle and @ToArticle)
and (@Rep is null or CCREPRES=@Rep)
and (@pays is null or CLPY=@pays)
and (@commande is null or CCCODE=@commande)
and RCCDATE between @FromDate and @ToDate
and CCMODECOM in(@tel,@fax,@bord,@telex,@cour,@mag,@rep,@net,@export)
and CCCODE=CCLCODE
and CLCODE=CCLCL
and CCLQTE > 0
and CCLRESTE > 0
and (@avecprep = 1 or CCLRESTE-(isnull(CCLQTEPREP,0)) > 0)
and isnull(CCVALIDE,0)=0
and isnull(CCBEBLOQUE,0) between (case when @avecCCbloque = 0 then 0
		  						 		when @avecCCbloque = 2 then 1
		  						 		when @avecCCbloque = 1 then 0
		  						 		else 0 end)
						 and (case when @avecCCbloque = 0 then 0
		  						 		when @avecCCbloque = 2 then 1
		  						 		when @avecCCbloque = 1 then 1
		  						 		else 0 end)
and CLPAYEUR in (@OK,@CT,@MP,@CI)
and (@SansOfferts=0 or CCLOFFERT=0)
and (@prio1 is null or CLPRIORITE between @prio1 and @prio2)
and (@stringStade is null or charindex(convert(varchar(1),isnull(CCSTADE_DET,0)),@stringStade)>0)
and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent and CLENT=@ent))
and NLOTAR=*CCLARTICLE and NLOTCODE=*CCLLOT
order by CCLDATECRE


create			index article 	on #Prep (CCLARTICLE)
create unique 	index seq 		on #Prep (CCLSEQ)
create			index code		on #Prep (CCLCODE)
create			index client	on #Prep (CCLCL)

if @articleInclus is not null
begin

  create table #ClientsArticlesInclus
  (
  client		char(12)
  )

  insert into #ClientsArticlesInclus (client)
  select CCLCL
  from #Prep
  where CCLARTICLE=@articleInclus
  group by CCLCL
  
  create unique index client on #ClientsArticlesInclus (client)

  delete #Prep
  where not exists (select * from #ClientsArticlesInclus where client=#Prep.CCLCL)
  
  drop table #ClientsArticlesInclus
end


if @ARSansNum=1
begin
  delete #Prep
  from FAR
  where ARCODE=CCLARTICLE
  and ARNUMEROTE=1
end

if @Produits=1
begin
	delete #Prep
	from FAR
	where ARCODE=CCLARTICLE
	and ARTYPE not in (0,1)
end
else if @Produits=2
begin
	delete #Prep
	from FAR
	where ARCODE=CCLARTICLE
	and ARTYPE <> 0
end


insert into #Art
select CCLARTICLE
from #Prep
group by CCLARTICLE

insert into #Articles (CCLARTICLE,TotalALivrer)
select RCCARTICLE,0
from FRCC,#Art
where RCCARTICLE=CCLARTICLE
and RCCDATE between @FromDate and @ToDate
and (@ent is null or RCCENT=@ent)
group by RCCARTICLE

create unique index art on #Articles (CCLARTICLE)

insert into #CdesCL (RCCARTICLE,RCCQTE,TotalPrep)
select RCCARTICLE,sum(RCCQTE),isnull(sum(CCLQTEPREP),0)
from FRCC,#Art,FCL,FCCL
where RCCARTICLE=#Art.CCLARTICLE
and RCCSEQ=CCLSEQ
and RCCDATE between @FromDate and @ToDate
and RCCCL=CLCODE
and CLPAYEUR in (@OK,@CT,@MP,@CI)
and (@ent is null or (RCCENT=@ent and CLENT=@ent))
group by RCCARTICLE

create unique index art on #CdesCL (RCCARTICLE)


if (@StockLocal=0)
begin
 	insert into #StockDep (Article,Qte,Depot,Emplace)
	select CCLARTICLE,isnull(sum(STEMPQTE),0),isnull(STEMPDEPOT,''),isnull(STEMPEMP,'')
	from #Articles,FSTEMP,FDP
	where STEMPAR=*CCLARTICLE
	and DPCODE*=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by CCLARTICLE,STEMPDEPOT,STEMPEMP
end
else if (@StockLocal=1)
begin
	insert into #StockDep (Article,Qte,Depot,Emplace)
	select CCLARTICLE,isnull(sum(STEMPQTE),0),isnull(STEMPDEPOT,''),isnull(STEMPEMP,'')
	from #Articles,FSTEMP,FDP
	where STEMPAR=*CCLARTICLE
	and DPLOC=1
	and DPCODE*=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by CCLARTICLE,STEMPDEPOT,STEMPEMP
end

delete from #StockDep
where Depot=''

create unique index ardep on #StockDep (Article,Depot,Emplace)


insert into #Reservations (ArticleRes,DepotRes,TotalRes)
select RCCARTICLE,
		sum(case when isnull(RCCDEPOTRES,'') = @Depot then isnull(RCCQTERES,0) else 0 end),
		sum(isnull(RCCQTERES,0))
from FRCC,#Art,FCL
where RCCARTICLE=CCLARTICLE
and RCCCL=CLCODE
and CLPAYEUR in (@OK,@CT,@MP,@CI)
and (@ent is null or (RCCENT=@ent and CLENT=@ent))
group by RCCARTICLE


insert into #Reservations (ArticleRes,DepotRes,TotalRes)
select CCLARTICLE,0,0
from #Articles
where not exists (select * from #Reservations where ArticleRes=#Articles.CCLARTICLE)

create index ar on #Reservations (ArticleRes)

drop table #Art


insert into #Stock (ArticleCde,StockDepot,StockAutre,StockPick)
select Article,sum(case when Depot = @Depot then Qte else 0 end),
			   sum(case when ((Depot != @Depot) or (Depot = @Depot and FARE.AREEMP = Emplace and FARE.AREPICK = 0)) then Qte else 0 end),
			   sum(case when Depot = @Depot and FARE.AREEMP = Emplace and FARE.AREPICK = 1 then Qte else 0 end)			   
from #StockDep,FDP,FARE
where Depot*=DPCODE
and AREAR=*Article
and AREDEPOT=*Depot
and AREEMP=*Emplace
group by Article


create unique index article on #Stock (ArticleCde)

update #Stock
set StockTotal=isnull(StockPick,0)+isnull(StockAutre,0)


if (@EtatStock=1)
begin
  select Cde=CCLCODE,Article=CCLARTICLE,Qte=CCLRESTE
  into #Complet
  from #Prep,FAR
  where (CLPREP=1 or CCPREP=1)
  and ARCODE=CCLARTICLE
  and ARCOMP != 2
  and ARTYPE = 0
  
  delete #Prep
  from #Stock,#Complet
  where Cde=CCLCODE
  and ArticleCde=Article
  and Qte > StockDepot
  
  drop table #Complet
end


if @Livrables=1
begin

  insert into #StockLivrable (ArticleCde,StockDepot,StockAutre,StockTotal)
  select ArticleCde,StockDepot,StockAutre,StockTotal
  from #Stock

  declare commandes cursor 
  for select SEQ,CCLARTICLE,CCLRESTE,ARTYPE
  from #Prep,FAR
  where CCLARTICLE=ARCODE
  and ARCOMP != 2
  order by SEQ
  for read only
  
  declare 	@seq		int,
  			@article	char(15),
  			@reste		int,
			@type		tinyint,
  			@stock		int
  
  open commandes
  
  fetch commandes
  into @seq,@article,@reste,@type
  
  while (@@sqlstatus = 0)
  begin   
	select @stock=StockDepot from #StockLivrable
	where ArticleCde=@article
	  
	if (@type != 0)
	begin
		update #Prep set CCOK=@reste where SEQ=@seq
	end
	else if (@type = 0) and ((@stock-@reste) >= 0)
	begin
		update #Prep set CCOK=@reste where SEQ=@seq
		update #StockLivrable set StockDepot=@stock-@reste where ArticleCde=@article
	end
	else
	begin
		update #Prep set CCOK=0 where SEQ=@seq
	end
			
	fetch commandes
  	into @seq,@article,@reste,@type
	  
  end
  
  close commandes
  deallocate cursor commandes
  
  delete from #Prep
  where CCOK=0

end


if (@EtatStock=0) or (@EtatStock=2)
begin
  insert into #Totaux (client,total)
  select CCLCL,round(sum(CCLTOTALHT/CCLQTE*CCLRESTE),2)
  from #Prep
  group by CCLCL
end
else if (@EtatStock=1) or (@EtatStock=3)
begin
  insert into #Tot_temp (client_temp,total_temp)
  select CCLCL,round(sum(case when (CCLRESTE > isnull(StockDepot,0))
										then (CCLTOTALHT/CCLQTE)*(isnull(StockDepot,0))
									when (CCLRESTE <= isnull(StockDepot,0))
										then CCLTOTALHT/CCLQTE*CCLRESTE end),2)
  from #Prep,#Stock,FAR
  where ArticleCde=CCLARTICLE
  and ARCODE=ArticleCde
  and ARTYPE = 0
  and ARCOMP != 2
  group by CCLCL
  
  insert into #Tot_temp (client_temp,total_temp)
  select CCLCL,round(sum(CCLTOTALHT/CCLQTE*CCLRESTE),2)
  from #Prep,FAR
  where ARCODE=CCLARTICLE
  and ARTYPE = 0
  and ARCOMP = 2
  group by CCLCL

  insert into #Tot_temp (client_temp,total_temp)
  select CCLCL,round(sum(CCLTOTALHT/CCLQTE*CCLRESTE),2)
  from #Prep,FAR
  where ARCODE=CCLARTICLE
  and ARTYPE != 0
  group by CCLCL
  
  insert into #Totaux (client,total)
  select client_temp,sum(total_temp)
  from #Tot_temp
  group by client_temp
  
  drop table #Tot_temp
end

create index client on #Totaux (client)

/** second filtre si valeurs limites en commande **/

if (@valeurdep != 0 or @valeurfin != 0)
begin
  
  delete from #Prep
  from #Totaux
  where CCLCL=client
  and (total < @valeurdep or total > @valeurfin)

end

delete from #Articles

if @avecprep=0
begin
  insert into #Articles (CCLARTICLE,TotalALivrer)
  select CCLARTICLE,sum(CCLRESTE)-sum(isnull(CCLQTEPREP,0))
  from #Prep
  group by CCLARTICLE
end
else if @avecprep=1
begin
  insert into #Articles (CCLARTICLE,TotalALivrer)
  select CCLARTICLE,sum(CCLRESTE)
  from #Prep
  group by CCLARTICLE
end

insert into #CdesFO (CFLARTICLE,ARecevoir)
select RCFARTICLE, isnull(sum(RCFQTE),0)
from FRCF,#Articles
where RCFARTICLE=CCLARTICLE
and RCFDATE <= convert(datetime,@ToDate)
and (@ent is null or RCFENT=@ent)
group by RCFARTICLE

insert into #CdesFO (CFLARTICLE,ARecevoir)
select CCLARTICLE,0
from #Articles
where not exists (select * from #CdesFO where CFLARTICLE=#Articles.CCLARTICLE)

create index article on #CdesFO (CFLARTICLE)

insert into #TotCC (cclcode,completion)
	select CCLCODE,0 from #Prep group by CCLCODE
	
create index cc on #TotCC (cclcode)

declare completion cursor 
  for select cclcode from #TotCC order by cclcode
  for read only
  
declare @cclcode 	char(10),
		@qteAdd	 	int,
		@ValAdd	 	numeric(14,2),
		@completion numeric(12,2),
		@pdureeres	int

select @pdureeres=isnull(PDUREERES,0) from KParam
		
open completion

fetch completion into @cclcode

while (@@sqlstatus = 0)
begin 

	/* @ValAdd=round(isnull(sum(CCLPHT*(1-CCLR1)*(1-CCLR2)*(1-CCLR3)/CVLOT*CCLRESTE),0),2) */

	select @qteAdd=isnull(sum(CCLRESTE),0),
		   @ValAdd=round(isnull(sum(CCLTOTALHT/CCLQTE*CCLRESTE),0),2)
	from #Prep,#Articles,#Stock,#Reservations	
	where #Prep.CCLCODE=@cclcode
	and (isnull(StockDepot,0)-isnull(DepotRes,0))>=TotalALivrer 
	and (@expMode is null or (CCLDATE<=dateadd(dd,@pdureeres,getdate() )))
	and (@expMode2 is null or isnull(CCBEBLOQUE,0) = 0)
	and #Articles.CCLARTICLE=#Prep.CCLARTICLE
	and #Stock.ArticleCde=#Prep.CCLARTICLE
	and #Reservations.ArticleRes=#Prep.CCLARTICLE

	/* select @cclcode,@qteAdd,@ValAdd */
	exec GetCompletionOutput @cclcode,@qteAdd,@ValAdd,@completion output

	update #TotCC set completion=@completion where cclcode=@cclcode

	fetch completion into @cclcode 

end 
 
close completion 
deallocate cursor completion 

										/*-------------- Filtre les commentaires isoles ----*/
if @Produits = 0
begin

  create table #Comments
  (
  cclcode		char(10)	not null,
  artype		tinyint		not null
  )
  
  declare @code		char(10),
  		  @artype	tinyint
  
  insert into #Comments (cclcode,artype)
  select CCLCODE,AR_TYPE
  from #Prep
  group by CCLCODE,AR_TYPE


  declare commentaires cursor
  for select cclcode,artype
  from #Comments
  where artype=4
  for read only

 
  open commentaires
  
  fetch commentaires into @code,@artype
  
  while (@@sqlstatus = 0)
  begin
	
	delete from #Prep
	where CCLCODE=@code
	and not exists (select * from #Comments where cclcode=@code and artype != 4)
	
	fetch commentaires into @code,@artype
	
  end
  
  close commentaires
  deallocate cursor commentaires
  
  drop table #Comments
end
										/*-------------- Fin du Filtre des commentaires isoles ----*/



if (@EtatStock=0)
begin
  insert into #Stock (ArticleCde,StockDepot,StockAutre,StockTotal,StockPick)
  select CCLARTICLE,0,0,0,0
  from #Articles
  where not exists (select * from #Stock where ArticleCde=#Articles.CCLARTICLE)
  
  if isnull(@GroupArticles,0)=0
  begin
  	set forceplan on
  
	select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,#Prep.CCLARTICLE,CCLLIBRE,
	CCLRESTE-isnull(CCLQTEPREP,0),ARLIB,MODELIV,isnull(StockPick,0),
	StockAutre=isnull(StockAutre,0),TotalALivrer,
	CLNOM1,isnull(AREEMP,''),CCECHSPE,CCFRANCO,CCFRANCOBE,ARCOMP,ARREFFOUR,CLPAYEUR,
	totalht = round((CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))),2),
	total,CLNUMCOMPTABLE,isnull(ARecevoir,0),CCCODEADR,CCTARIF,CCLDEV,
	CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLFACTMAN,CCLOFFERT,
	CCLUNITFACT,CCLPHT,CCLTV,CCLTYPE,CCNOM,CCNOM2,CCPRENOM,CCADR1,CCADR2,CCCP,CCVILLE,CCPY,CCPAYS,
	CCDATECOM,CCLDATECRE,CCCOMMENTAIRES,RCCQTE,CCREFCOMCL,CLCCBE,CLPRIORITE,ARTYPE,MARGIN,completion,
	CCSATISFAITE,CCLQTERES,CCLDATERESFIN,DepotRes,TotalRes,
	(case when isnull(StockDepot,0)-isnull(DepotRes,0) > 0 then isnull(StockDepot,0)-isnull(DepotRes,0) else 0 end),
	CCBEBLOQUE,ARNUMEROTE,CCLATTACHE,CCLQTEPREP,isnull(StockDepot,0),TotalPrep,CCLRESTE,CCLMARCHE,CCLREP,
	CCLLOT,NLOTDATEPER,isnull(ARPRODUIT,'')
	from #Prep,FAR,#Articles,#Stock,FARE,#Totaux,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
	and #Stock.ArticleCde=ARCODE
	and #Articles.CCLARTICLE=ARCODE
	and #Prep.CCLCL=#Totaux.client
	and #CdesFO.CFLARTICLE=ARCODE
	and #CdesCL.RCCARTICLE=ARCODE
	and #TotCC.cclcode=#Prep.CCLCODE
	and #Reservations.ArticleRes=ARCODE
	and AREAR=*ARCODE
	and ARELIGNE=1
	order by CCLCL,CCLCODE,CCLNUM
	
  	set forceplan off
  end
  else if isnull(@GroupArticles,0)=1
  begin
  	select 0,'','',0,'',#Prep.CCLARTICLE,'',sum(CCLRESTE-isnull(CCLQTEPREP,0)),ARLIB,'',isnull(StockPick,0),
		StockAutre=isnull(StockAutre,0),sum(CCLRESTE-isnull(CCLQTEPREP,0)),
		'','',0,0,0,ARCOMP,ARREFFOUR,0,
		totalht = round(sum((CCLTOTALHT/CCLQTE)*(CCLRESTE-isnull(CCLQTEPREP,0))),2),0,'',isnull(ARecevoir,0),'','','',
		0,0,0,0,0,0,0,0,0,0,CCLTV,0,'','','','','','','','','',
		'','','',RCCQTE,'','',0,ARTYPE,0,0,0,sum(CCLQTERES),'',DepotRes,TotalRes,0,0,ARNUMEROTE,'',sum(isnull(CCLQTEPREP,0)),
		isnull(StockDepot,0),TotalPrep,sum(CCLRESTE)
	from #Prep,FAR,#Articles,#Stock,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
		and #Articles.CCLARTICLE=ARCODE
		and #Stock.ArticleCde=ARCODE
		and #CdesFO.CFLARTICLE=ARCODE
		and #CdesCL.RCCARTICLE=ARCODE
		and #TotCC.cclcode=#Prep.CCLCODE
		and #Reservations.ArticleRes=ARCODE	
	group by #Prep.CCLARTICLE,ARLIB,isnull(StockPick,0),
		isnull(StockAutre,0),ARCOMP,ARREFFOUR,isnull(ARecevoir,0),CCLTV,RCCQTE,ARTYPE,
		DepotRes,TotalRes,ARNUMEROTE,isnull(StockDepot,0),TotalPrep
	order by #Prep.CCLARTICLE
  end
end
else if (@EtatStock=1)
begin
  if isnull(@GroupArticles,0)=0
  begin
  	set forceplan on

	select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,#Prep.CCLARTICLE,CCLLIBRE,
	CCLRESTE-isnull(CCLQTEPREP,0),ARLIB,MODELIV,isnull(StockPick,0),
	StockAutre=isnull(StockAutre,0),TotalALivrer,
	CLNOM1,isnull(AREEMP,''),CCECHSPE,CCFRANCO,CCFRANCOBE,ARCOMP,ARREFFOUR,CLPAYEUR,
	totalht = round((case when ((ARTYPE = 0 and ARCOMP != 2) and ((CCLRESTE-isnull(CCLQTEPREP,0)) > isnull(StockDepot,0)))
					  		then CCLTOTALHT/CCLQTE*(isnull(StockDepot,0))
						  when (((CCLRESTE-isnull(CCLQTEPREP,0)) <= isnull(StockDepot,0) and ARTYPE = 0 and ARCOMP != 2)
							or (ARTYPE = 0 and ARCOMP = 2)
							or ARTYPE != 0)
					  		then CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))
						  end),2),
	total,CLNUMCOMPTABLE,isnull(ARecevoir,0),CCCODEADR,CCTARIF,CCLDEV,
	CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLFACTMAN,CCLOFFERT,
	CCLUNITFACT,CCLPHT,CCLTV,CCLTYPE,CCNOM,CCNOM2,CCPRENOM,CCADR1,CCADR2,CCCP,CCVILLE,CCPY,CCPAYS,
	CCDATECOM,CCLDATECRE,CCCOMMENTAIRES,RCCQTE,CCREFCOMCL,CLCCBE,CLPRIORITE,ARTYPE,MARGIN,completion,
	CCSATISFAITE,CCLQTERES,CCLDATERESFIN,DepotRes,TotalRes,
	(case when isnull(StockDepot,0)-isnull(DepotRes,0) > 0 then isnull(StockDepot,0)-isnull(DepotRes,0) else 0 end),
	CCBEBLOQUE,ARNUMEROTE,CCLATTACHE,CCLQTEPREP,isnull(StockDepot,0),TotalPrep,CCLRESTE,CCLMARCHE,CCLREP,
	CCLLOT,NLOTDATEPER,isnull(ARPRODUIT,'')
	from #Prep,FAR,#Articles,#Stock,FARE,#Totaux,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
	and #Stock.ArticleCde=ARCODE
	and #Articles.CCLARTICLE=ARCODE
	and #Prep.CCLCL=#Totaux.client
	and #CdesFO.CFLARTICLE=ARCODE
	and #CdesCL.RCCARTICLE=ARCODE
	and #TotCC.cclcode=#Prep.CCLCODE
	and #Reservations.ArticleRes=ARCODE
	and AREAR=*ARCODE
	and ARELIGNE=1
	and (ARCOMP = 2 or isnull(StockDepot,0) > 0 or ARTYPE <> 0)
	order by CCLCL,CCLCODE,CCLNUM
	
  	set forceplan off
  	end
  else if isnull(@GroupArticles,0)=1
  begin
  	select 0,'','',0,'',#Prep.CCLARTICLE,'',sum(CCLRESTE-isnull(CCLQTEPREP,0)),ARLIB,'',isnull(StockPick,0),
		StockAutre=isnull(StockAutre,0),sum(CCLRESTE-isnull(CCLQTEPREP,0)),
		'','',0,0,0,ARCOMP,ARREFFOUR,0,
		totalht = round(sum(case when ((ARTYPE = 0 and ARCOMP != 2) and ((CCLRESTE-isnull(CCLQTEPREP,0)) > isnull(StockDepot,0)))
					  		then CCLTOTALHT/CCLQTE*(isnull(StockDepot,0))
						  when (((CCLRESTE-isnull(CCLQTEPREP,0)) <= isnull(StockDepot,0) and ARTYPE = 0 and ARCOMP != 2)
							or (ARTYPE = 0 and ARCOMP = 2)
							or ARTYPE != 0)
					  		then CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))
						  end),2),
		0,'',isnull(ARecevoir,0),'','','',
		0,0,0,0,0,0,0,0,0,0,CCLTV,0,'','','','','','','','','',
		'','','',RCCQTE,'',0,0,ARTYPE,0,0,0,sum(CCLQTERES),'',DepotRes,TotalRes,0,0,ARNUMEROTE,'',sum(isnull(CCLQTEPREP,0)),
		isnull(StockDepot,0),TotalPrep,sum(CCLRESTE)
	from #Prep,FAR,#Articles,#Stock,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
		and #Articles.CCLARTICLE=ARCODE
		and #Stock.ArticleCde=ARCODE
		and #CdesFO.CFLARTICLE=ARCODE
		and #CdesCL.RCCARTICLE=ARCODE
		and #TotCC.cclcode=#Prep.CCLCODE
		and #Reservations.ArticleRes=ARCODE
		and (ARCOMP = 2 or (isnull(StockDepot,0)) > 0 or ARTYPE <>0)
	group by #Prep.CCLARTICLE,ARLIB,isnull(StockPick,0),
		isnull(StockAutre,0),ARCOMP,ARREFFOUR,isnull(ARecevoir,0),CCLTV,RCCQTE,ARTYPE,
		DepotRes,TotalRes,ARNUMEROTE,isnull(StockDepot,0),TotalPrep
	order by #Prep.CCLARTICLE
  end
end
else if (@EtatStock=2)
begin
  if isnull(@GroupArticles,0)=0
  begin
  	set forceplan on

	select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,#Prep.CCLARTICLE,CCLLIBRE,
	CCLRESTE-isnull(CCLQTEPREP,0),ARLIB,MODELIV,isnull(StockPick,0),
	StockAutre=isnull(StockAutre,0),TotalALivrer,
	CLNOM1,isnull(AREEMP,''),CCECHSPE,CCFRANCO,CCFRANCOBE,ARCOMP,ARREFFOUR,CLPAYEUR,
	totalht = round((CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))),2),
	total,CLNUMCOMPTABLE,isnull(ARecevoir,0),CCCODEADR,CCTARIF,CCLDEV,
	CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLFACTMAN,CCLOFFERT,
	CCLUNITFACT,CCLPHT,CCLTV,CCLTYPE,CCNOM,CCNOM2,CCPRENOM,CCADR1,CCADR2,CCCP,CCVILLE,CCPY,CCPAYS,
	CCDATECOM,CCLDATECRE,CCCOMMENTAIRES,RCCQTE,CCREFCOMCL,CLCCBE,CLPRIORITE,ARTYPE,MARGIN,completion,
	CCSATISFAITE,CCLQTERES,CCLDATERESFIN,DepotRes,TotalRes,
	(case when isnull(StockDepot,0)-isnull(DepotRes,0) > 0 then isnull(StockDepot,0)-isnull(DepotRes,0) else 0 end),
	CCBEBLOQUE,ARNUMEROTE,CCLATTACHE,CCLQTEPREP,isnull(StockDepot,0),TotalPrep,CCLRESTE,CCLMARCHE,CCLREP,
	CCLLOT,NLOTDATEPER,isnull(ARPRODUIT,'')
	from #Prep,FAR,#Articles,#Stock,FARE,#Totaux,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
	and #Stock.ArticleCde=ARCODE
	and #Articles.CCLARTICLE=ARCODE
	and #Prep.CCLCL=#Totaux.client
	and #CdesFO.CFLARTICLE=ARCODE
	and #CdesCL.RCCARTICLE=ARCODE
	and #TotCC.cclcode=#Prep.CCLCODE
	and #Reservations.ArticleRes=ARCODE
	and AREAR=*ARCODE
	and ARELIGNE=1
	and ((isnull(StockDepot,0) = 0) and (ARTYPE = 0))
	order by CCLCL,CCLCODE,CCLNUM
	
  	set forceplan off
  	end
  else if isnull(@GroupArticles,0)=1
  begin
  	select 0,'','',0,'',#Prep.CCLARTICLE,'',sum(CCLRESTE-isnull(CCLQTEPREP,0)),ARLIB,'',isnull(StockPick,0),
		StockAutre=isnull(StockAutre,0),sum(CCLRESTE-isnull(CCLQTEPREP,0)),
		'','',0,0,0,ARCOMP,ARREFFOUR,0,
		totalht = round(sum(CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))),2),
		0,'',isnull(ARecevoir,0),'','','',
		0,0,0,0,0,0,0,0,0,0,CCLTV,0,'','','','','','','','','',
		'','','',RCCQTE,'',0,0,ARTYPE,0,0,0,sum(CCLQTERES),'',DepotRes,TotalRes,0,0,ARNUMEROTE,'',sum(isnull(CCLQTEPREP,0)),
		isnull(StockDepot,0),TotalPrep,sum(CCLRESTE)
	from #Prep,FAR,#Articles,#Stock,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
		and #Articles.CCLARTICLE=ARCODE
		and #Stock.ArticleCde=ARCODE
		and #CdesFO.CFLARTICLE=ARCODE
		and #CdesCL.RCCARTICLE=ARCODE
		and #TotCC.cclcode=#Prep.CCLCODE
		and #Reservations.ArticleRes=ARCODE
		and ((isnull(StockDepot,0) = 0) and (ARTYPE = 0))
	group by #Prep.CCLARTICLE,ARLIB,isnull(StockPick,0),
		isnull(StockAutre,0),ARCOMP,ARREFFOUR,isnull(ARecevoir,0),CCLTV,RCCQTE,ARTYPE,
		DepotRes,TotalRes,ARNUMEROTE,isnull(StockDepot,0),TotalPrep
	order by #Prep.CCLARTICLE
  end
end
else if (@EtatStock=3)
begin
  if isnull(@GroupArticles,0)=0
  begin
  	set forceplan on

	select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,#Prep.CCLARTICLE,CCLLIBRE,
	CCLRESTE-isnull(CCLQTEPREP,0),ARLIB,MODELIV,isnull(StockPick,0),
	StockAutre=isnull(StockAutre,0),TotalALivrer,
	CLNOM1,isnull(AREEMP,''),CCECHSPE,CCFRANCO,CCFRANCOBE,ARCOMP,ARREFFOUR,CLPAYEUR,
	totalht = round((case when ((ARTYPE = 0 and ARCOMP != 2) and ((CCLRESTE-isnull(CCLQTEPREP,0)) > isnull(StockDepot,0)))
					  		then CCLTOTALHT/CCLQTE*(isnull(StockDepot,0))
						  when (((CCLRESTE-isnull(CCLQTEPREP,0)) <= isnull(StockDepot,0) and ARTYPE = 0 and ARCOMP != 2)
							or (ARTYPE = 0 and ARCOMP = 2)
							or ARTYPE != 0)
					  		then CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))
						  end),2),
	total,CLNUMCOMPTABLE,isnull(ARecevoir,0),CCCODEADR,CCTARIF,CCLDEV,
	CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLFACTMAN,CCLOFFERT,
	CCLUNITFACT,CCLPHT,CCLTV,CCLTYPE,CCNOM,CCNOM2,CCPRENOM,CCADR1,CCADR2,CCCP,CCVILLE,CCPY,CCPAYS,
	CCDATECOM,CCLDATECRE,CCCOMMENTAIRES,RCCQTE,CCREFCOMCL,CLCCBE,CLPRIORITE,ARTYPE,MARGIN,completion,
	CCSATISFAITE,CCLQTERES,CCLDATERESFIN,DepotRes,TotalRes,
	(case when isnull(StockDepot,0)-isnull(DepotRes,0) > 0 then isnull(StockDepot,0)-isnull(DepotRes,0) else 0 end),
	CCBEBLOQUE,ARNUMEROTE,CCLATTACHE,CCLQTEPREP,isnull(StockDepot,0),TotalPrep,CCLRESTE,CCLMARCHE,CCLREP,
	CCLLOT,NLOTDATEPER,isnull(ARPRODUIT,'')
	from #Prep,FAR,#Articles,#Stock,FARE,#Totaux,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
	and #Stock.ArticleCde=ARCODE
	and #Articles.CCLARTICLE=ARCODE
	and #Prep.CCLCL=#Totaux.client
	and #CdesFO.CFLARTICLE=ARCODE
	and #CdesCL.RCCARTICLE=ARCODE
	and #TotCC.cclcode=#Prep.CCLCODE
	and #Reservations.ArticleRes=ARCODE
	and AREAR=*ARCODE
	and ARELIGNE=1
	and isnull(StockDepot,0) != 0
	and isnull(StockDepot,0) < TotalALivrer
	and ARTYPE = 0
	order by CCLCL,CCLCODE,CCLNUM
	
  	set forceplan off
  	end
  else if isnull(@GroupArticles,0)=1
  begin
  	select 0,'','',0,'',#Prep.CCLARTICLE,'',sum(CCLRESTE-isnull(CCLQTEPREP,0)),ARLIB,'',isnull(StockPick,0),
		StockAutre=isnull(StockAutre,0),sum(CCLRESTE-isnull(CCLQTEPREP,0)),
		'','',0,0,0,ARCOMP,ARREFFOUR,0,
	totalht = round(sum(case when ((ARTYPE = 0 and ARCOMP != 2) and ((CCLRESTE-isnull(CCLQTEPREP,0)) > isnull(StockDepot,0)))
					  		then CCLTOTALHT/CCLQTE*(isnull(StockDepot,0))
						  when (((CCLRESTE-isnull(CCLQTEPREP,0)) <= isnull(StockDepot,0) and ARTYPE = 0 and ARCOMP != 2)
							or (ARTYPE = 0 and ARCOMP = 2)
							or ARTYPE != 0)
					  		then CCLTOTALHT/CCLQTE*(CCLRESTE-isnull(CCLQTEPREP,0))
						  end),2),
		0,'',isnull(ARecevoir,0),'','','',
		0,0,0,0,0,0,0,0,0,0,CCLTV,0,'','','','','','','','','',
		'','','',RCCQTE,'',0,0,ARTYPE,0,0,0,sum(CCLQTERES),'',DepotRes,TotalRes,0,0,ARNUMEROTE,'',sum(isnull(CCLQTEPREP,0)),
		isnull(StockDepot,0),TotalPrep,sum(CCLRESTE)
	from #Prep,FAR,#Articles,#Stock,#CdesFO,#CdesCL,#TotCC,#Reservations
	where #Prep.CCLARTICLE=ARCODE
		and #Articles.CCLARTICLE=ARCODE
		and #Stock.ArticleCde=ARCODE
		and #CdesFO.CFLARTICLE=ARCODE
		and #CdesCL.RCCARTICLE=ARCODE
		and #TotCC.cclcode=#Prep.CCLCODE
		and #Reservations.ArticleRes=ARCODE
		and isnull(StockDepot,0) != 0
		and isnull(StockDepot,0) < TotalALivrer
		and ARTYPE = 0
	group by #Prep.CCLARTICLE,ARLIB,isnull(StockPick,0),
		isnull(StockAutre,0),ARCOMP,ARREFFOUR,isnull(ARecevoir,0),CCLTV,RCCQTE,ARTYPE,
		DepotRes,TotalRes,ARNUMEROTE,isnull(StockDepot,0),TotalPrep
	order by #Prep.CCLARTICLE
  end
end



drop table #Prep
drop table #Articles
drop table #Stock
drop table #StockLivrable
drop table #StockDep
drop table #Totaux
drop table #CdesFO
drop table #CdesCL
drop table #Reservations

end
go

