


/* Procedure permettant de visualiser les lignes d''articles avec :
	- les expeditions depuis le debut de l''annee en cours
	- les stocks en cours
	- les reliquats de commandes clients jusqu''au mois precedent
	- les reliquats de commandes fournisseurs jusqu''au mois precedent
	- les commandes clients en cours
	- les commandes fournisseurs en cours
	- les commandes clients pour le mois suivant 
	- les commandes fournisseurs pour le mois suivant
	et ce, jusqu''au 6eme mois  */

create procedure CompareCdes   (@ent		char(5) 	= null,
								@fournis	char(12)	= null,
								@famille	char(8)		= null,
								@article	char(15)	= null)
with recompile
as
begin

declare	@date1	datetime,
		@date2	datetime


create table #Final
(
Articles	char(15)	not null,
Ventes		int				null,
Stock		int				null,
CdesCLRel	int				null,
CdesFORel	int				null,
CdesCL1		int				null,
CdesFO1		int				null,
CdesCL2		int				null,
CdesFO2		int				null,
CdesCL3		int				null,
CdesFO3		int				null,
CdesCL4		int				null,
CdesFO4		int				null,
CdesCL5		int				null,
CdesFO5		int				null,
CdesCL6		int				null,
CdesFO6		int				null
)


create table #Far
(
Article		char(15)	not null,
Desi		varchar(80)		null
)


if ((@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
	end
else if ((@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARCODE=@article
	end	
else if ((@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARFAM=@famille
	end	
else if ((@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARFAM=@famille
		and ARCODE=@article
	end	
else if ((@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARFO=@fournis
	end
else if ((@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARFO=@fournis
		and ARCODE=@article
	end
else if ((@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
	end
else if ((@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #Far (Article,Desi)
		select ARCODE,ARLIB
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end


create unique clustered index code on #Far (Article)

/* Cumul des Ventes depuis le debut de l''annee */
/***********************************************/

select @date1=convert(datetime,convert(char(4),datepart(yy,getdate()))+"0101")

insert into #Final (Articles,Ventes)
select BELARTICLE,sum(BELQTE)
from FBEL,#Far
where (@ent is null or BELENT=@ent)
and BELARTICLE=Article
and BELDATE >= @date1
group by BELARTICLE


/* Stock du jour */
/*****************/

insert into #Final (Articles,Stock)
select STAR,sum(STQTE)
from FSTOCK,#Far,FDP
where DPCODE=STDEPOT and (@ent is null or  (DPENT=@ent and DPCENTRAL=0))
and STAR=Article
and STQTE > 0
group by STAR


/* Reliquats de commandes clients jusqu''au mois precedent la requete */
/*********************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,getdate()))+"/01/"+convert(char(4),datepart(yy,getdate())))


insert into #Final (Articles,CdesCLRel)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCCL,FCC
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE < @date1
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Reliquats de commandes fournisseurs jusqu''au mois precedent la requete */
/**************************************************************************/


insert into #Final (Articles,CdesFORel)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE < @date1
group by RCFARTICLE


/* Commandes clients restant a livrer pour le mois en cours 1 */
/**************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,getdate()))+"/01/"+convert(char(4),datepart(yy,getdate())))
select @date2=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,1,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,1,getdate()))))


insert into #Final (Articles,CdesCL1)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCC,FCCL
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE >= @date1
and RCCDATE < @date2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Commandes fournisseurs restant a livrer pour le mois en cours 1 */
/*******************************************************************/


insert into #Final (Articles,CdesFO1)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE >= @date1
and RCFDATE < @date2
group by RCFARTICLE


/* Commandes clients restant a livrer pour le mois suivant 2 */
/*************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,1,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,1,getdate()))))
select @date2=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,2,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,2,getdate()))))


insert into #Final (Articles,CdesCL2)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCC,FCCL
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE >= @date1
and RCCDATE < @date2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Commandes fournisseurs restant a livrer pour le mois suivant 2 */
/******************************************************************/


insert into #Final (Articles,CdesFO2)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE >= @date1
and RCFDATE < @date2
group by RCFARTICLE


/* Commandes clients restant a livrer pour le mois suivant 3 */
/*************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,2,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,2,getdate()))))
select @date2=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,3,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,3,getdate()))))


insert into #Final (Articles,CdesCL3)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCC,FCCL
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE >= @date1
and RCCDATE < @date2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Commandes fournisseurs restant a livrer pour le mois suivant 3 */
/******************************************************************/


insert into #Final (Articles,CdesFO3)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE >= @date1
and RCFDATE < @date2
group by RCFARTICLE


/* Commandes clients restant a livrer pour le mois suivant 4 */
/*************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,3,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,3,getdate()))))
select @date2=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,4,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,4,getdate()))))


insert into #Final (Articles,CdesCL4)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCC,FCCL
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE >= @date1
and RCCDATE < @date2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Commandes fournisseurs restant a livrer pour le mois suivant 4 */
/******************************************************************/


insert into #Final (Articles,CdesFO4)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE >= @date1
and RCFDATE < @date2
group by RCFARTICLE


/* Commandes clients restant a livrer pour le mois suivant 5 */
/*************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,4,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,4,getdate()))))
select @date2=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,5,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,5,getdate()))))


insert into #Final (Articles,CdesCL5)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCC,FCCL
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE >= @date1
and RCCDATE < @date2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Commandes fournisseurs restant a livrer pour le mois suivant 5 */
/******************************************************************/


insert into #Final (Articles,CdesFO5)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE >= @date1
and RCFDATE < @date2
group by RCFARTICLE


/* Commandes clients restant a livrer pour le mois suivant 6 */
/*************************************************************/

select @date1=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,5,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,5,getdate()))))
select @date2=convert(datetime,convert(char(2),datepart(mm,dateadd(mm,6,getdate())))+"/01/"+convert(char(4),datepart(yy,dateadd(mm,6,getdate()))))


insert into #Final (Articles,CdesCL6)
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Far,FCC,FCCL
where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and RCCARTICLE=Article
and RCCDATE >= @date1
and RCCDATE < @date2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
group by RCCARTICLE


/* Commandes fournisseurs restant a livrer pour le mois suivant 6 */
/******************************************************************/


insert into #Final (Articles,CdesFO6)
select RCFARTICLE,sum(RCFQTE)
from FRCF,#Far
where (@ent is null or RCFENT=@ent)
and RCFARTICLE=Article
and RCFDATE >= @date1
and RCFDATE < @date2
group by RCFARTICLE


/* select final */
/****************/


select Articles,Desi,
		sum(Ventes),sum(Stock),
		sum(CdesCLRel),sum(CdesFORel),
		sum(CdesCL1),sum(CdesFO1),
		sum(CdesCL2),sum(CdesFO2),
		sum(CdesCL3),sum(CdesFO3),
		sum(CdesCL4),sum(CdesFO4),
		sum(CdesCL5),sum(CdesFO5),
		sum(CdesCL6),sum(CdesFO6)
from #Final,#Far
where Articles=Article
group by Articles,Desi
order by Articles

drop table #Far
drop table #Final

end



go

