



create procedure Milliers (@nombre	varchar(30) output)
with recompile
as
begin

set arithabort numeric_truncation off


declare @long	int,
		@separe	numeric(14,2)


select @separe = convert(numeric(14,2),(char_length (@nombre)-6))/3


if @separe > 0
begin
  select @long = char_length (@nombre)
  select @nombre = substring(@nombre,1,@long-6) +' '+ substring(@nombre,@long-5,@long)
end

if @separe > 1
begin
  select @long = char_length (@nombre)
  select @nombre = substring(@nombre,1,@long-10) +' '+ substring(@nombre,@long-9,@long)
end

if @separe > 2
begin
  select @long = char_length (@nombre)
  select @nombre = substring(@nombre,1,@long-14) +' '+ substring(@nombre,@long-13,@long)
end

if @separe > 3
begin
select @long = char_length (@nombre)
select @nombre = substring(@nombre,1,@long-18) +' '+ substring(@nombre,@long-17,@long)
end

if @separe > 4
begin
select @long = char_length (@nombre)
select @nombre = substring(@nombre,1,@long-22) +' '+ substring(@nombre,@long-21,@long)
end

select @nombre = ltrim(@nombre)

end



go

