


/* Procedure utilisee par la procedure Prep_ERNST */


create procedure BEPrepFO (@UntilDate 	smalldatetime,
						   @fournis		char(12),
						   @famille		char(8) = null,
						   @ent			char(5)	= null
						  )
with recompile						
as

begin


create table #Prep
(
CCLCL			char(12)		not null,
CCLCODE			char(10)		not null,
CCLNUM			int					null,
CCLDATE			datetime			null,
CCLARTICLE		char(15)		not null,
CCLLIBRE		varchar(255)		null,
CCLRESTE		int					null,
CCLQTE			int					null,
CCOK			int					null,
SEQ				numeric(14,0)	identity
)


create table #Stock
(
ArticleCde	char(15)	not null,
QteLoc		int				null,
QteAutre	int				null,
Qtedisp		int				null
)

create table #StockDep
(
Article		char(15)	not null,
Qte			int				null,
Depot		char(4)			null
)

create table #Articles
(
CCLARTICLE	char(15)	not null
)


insert into #Prep (CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,CCLRESTE,CCLQTE)
select CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,CCLRESTE,CCLQTE
from FRCC,FCCL,FCC,FCL,FAR
where CCLSEQ=RCCSEQ
and RCCDATE <= @UntilDate
and RCCARTICLE=ARCODE
and ARFO=@fournis
and (@famille is null or ARFAM=@famille)
and CCCODE=CCLCODE
and CLCODE=CCLCL
and CCLQTE > 0
and CCLRESTE > 0
and isnull(CCVALIDE,0)=0
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
order by CCLDATECRE


create index article on #Prep(CCLARTICLE)

insert into #Articles
select CCLARTICLE
from #Prep
group by CCLARTICLE

create unique clustered index art on #Articles (CCLARTICLE)


insert into #StockDep (Article,Qte,Depot)
select CCLARTICLE,isnull(sum(STQTE),0),isnull(STDEPOT,'')
from #Articles,FSTOCK,FDP
where STAR=*CCLARTICLE
and DPCODE*=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by CCLARTICLE,STDEPOT

create unique clustered index ardep on #StockDep (Article,Depot)

insert into #Stock (ArticleCde,QteLoc,QteAutre)
select Article,sum(case when (Depot != '')
							then (case when DPLOC = 1 then Qte else 0 end)
						when (Depot = '')
							then 0
				   end),
			   sum(case when (Depot != '')
							then (case when DPLOC != 1 then Qte else 0 end)
						when (Depot = '')
							then 0
				   end)
from #StockDep,FDP
where Depot*=DPCODE
group by Article

update #Stock
set Qtedisp=isnull(QteLoc,0)+isnull(QteAutre,0)

create unique clustered index article on #Stock (ArticleCde)


  declare commandes cursor 
  for select SEQ,CCLARTICLE,CCLRESTE
  from #Prep,FAR
  where CCLARTICLE=ARCODE
  order by SEQ
  for read only
  
  declare 	@seq		int,
  			@article	char(15),
  			@reste		int,
  			@stock		int
  
  open commandes
  
  fetch commandes
  into @seq,@article,@reste
  
  while (@@sqlstatus = 0)
	  begin
	  
	  select @stock=Qtedisp
	  from #Stock
	  where @article=ArticleCde
	  
	  if (@stock-@reste) >= 0
	  begin
		update #Prep
		set CCOK=@reste
		where SEQ=@seq
		
		update #Stock
		set Qtedisp=@stock-@reste
		where @article=ArticleCde
	  end
	  else
	  begin
	  	update #Prep
		set CCOK=0
		where SEQ=@seq
	  end
  	  
	  fetch commandes
  	  into @seq,@article,@reste
	  
  end
  
  close commandes
  deallocate cursor commandes
  
  delete from #Prep
  where CCOK <> 0



insert into #Stock
select CCLARTICLE,0,0,0
from #Articles
where not exists (select * from #Stock where ArticleCde=#Articles.CCLARTICLE)

select CCLCL,Commande=CCLCODE+' / '+convert(varchar(4),CCLNUM),CCLDATE,#Prep.CCLARTICLE,
		(case when ARLIB='' then CCLLIBRE else substring(ARLIB,1,40) end),
		CCLRESTE,Stock_Dispo=isnull(Qtedisp,0)
from #Prep,#Stock,FAR
where #Prep.CCLARTICLE=ARCODE
and #Stock.ArticleCde=*ARCODE
order by CCLCL,#Prep.CCLARTICLE

drop table #Prep
drop table #Articles
drop table #Stock
drop table #StockDep

end



go

