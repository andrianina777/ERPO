


create procedure NewFDOT (	@ent	char(5) = null,
							@an		smallint)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Mouv
(
article		char(15)	not null,
depot		char(4)		not null,
qtein		int				null,
valin		numeric(14,2)	null,
qteout		int				null,
valout		numeric(14,2)	null
)

create table #Far
(
ARCODE	char(15)	null,
CVLOT	int			null
)

insert into #Far
select ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)

create unique clustered index code on #Far (ARCODE)

create table #Far2
(
ARCODE	char(15)	null,
CVLOT	int			null
)

insert into #Far2
select ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)

create unique clustered index code on #Far2 (ARCODE)



insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select SILARTICLE,SILDEPOT,
	   sum(SILQTE),sum(round(((SILPAHT+SILFRAIS)/CVLOT),2)*SILQTE),0,0.00
from FSIL,#Far,FDP
where SILARTICLE=ARCODE
and datepart(yy,SILDATE) = @an
and SILDEPOT=DPCODE
and DPDOTATION=1
group by SILARTICLE,SILDEPOT
having sum(SILQTE) != 0


insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select RJLARTICLE,RJLDEPOT,
		sum(RJLQTE),sum(round(((RJLPAHT+RJLFRAIS)/CVLOT),2)*RJLQTE),0,0.00
from FRJL,#Far,FDP
where RJLARTICLE=ARCODE
and datepart(yy,RJLDATE) = @an
and RJLDEPOT=DPCODE
and DPDOTATION=1
group by RJLARTICLE,RJLDEPOT
having sum(RJLQTE) != 0


insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select LCLARTICLE,LCLDEPOT,
		sum(LCLQTE),sum(round(((LCLPAHT+LCLFRAIS)/CVLOT),2)*LCLQTE),0,0.00
from FLCL,#Far2,FDP
where LCLARTICLE=ARCODE
and datepart(yy,LCLDATE) = @an
and LCLDEPOT=DPCODE
and DPDOTATION=1
group by LCLARTICLE,LCLDEPOT
having sum(LCLQTE) != 0


insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select ASLARTICLE,ASLDEPOT,
		sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE),0,0.00
from FASL,#Far2,FDP
where ASLARTICLE=ARCODE
and datepart(yy,ASLDATE) = @an
and ASLDEPOT=DPCODE
and DPDOTATION=1
group by ASLARTICLE,ASLDEPOT
having sum(ASLQTE) != 0



insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select BLLAR,BLLDEP,
		sum(BLLQTE),sum(round(((BLLPRHT)/CVLOT),2)*BLLQTE),0,0.00
from FBLL,FCV,FDP
where BLLUA=CVUNIF
and datepart(yy,BLLDATE) = @an
and BLLDEP=DPCODE
and DPDOTATION=1
and (@ent is null or BLLENT=@ent)
group by BLLAR,BLLDEP
having sum(BLLQTE) != 0


insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select DOLAR,DOLDEP,
		sum(DOLQTE),sum(round(((DOLPRHT)/CVLOT),2)*DOLQTE),0,0.00
from FDOL,FCV,FDP
where DOLUA=CVUNIF
and datepart(yy,DOLDATE) = @an
and DOLDEP=DPCODE
and DPDOTATION=1
and (@ent is null or DOLENT=@ent)
group by DOLAR,DOLDEP



insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select RFLARTICLE,RFLDEPOT,
-(sum(RFLQTE)),-(sum(round(((RFLPAHT)/CVLOT),2)*RFLQTE)),0,0.00
from FRFL,FCV,FDP
where RFLUNITACHAT=CVUNIF
and datepart(yy,RFLDATE) = @an
and RFLDEPOT=DPCODE
and DPDOTATION=1
and (@ent is null or RFLENT=@ent)
group by RFLARTICLE,RFLDEPOT
having sum(RFLQTE) != 0



insert into #Mouv (article,depot,qtein,valin,qteout,valout)
select BELARTICLE,STDEPOT,0,0.00,
		sum(BELQTE),sum(round(((STPAHT+STFRAIS)/CVLOT),2)*BELQTE)
from FBEL,FSTOCK,#Far,FDP
where BELARTICLE=ARCODE
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and datepart(yy,BELDATE) = @an
and STDEPOT=DPCODE 
and (@ent is null or BELENT=@ent)
and DPDOTATION=1
group by BELARTICLE,STDEPOT
having sum(BELQTE) != 0


delete from FDOT
where DOTAN = @an and (@ent is null or DOTENT=@ent)


insert into FDOT (DOTARTICLE,DOTAN,DOTMOIS,DOTQTEIN,DOTPRIN,DOTQTEOUT,
					DOTPROUT,DOTDEPOT,DOTDATECRE,DOTUSERCRE,DOTENT)
select article,@an,12,sum(qtein),sum(valin),sum(qteout),sum(valout),depot,getdate(),user_id(),@ent
from #Mouv
group by article,depot
order by article,depot

drop table #Mouv
drop table #Far


end



go

