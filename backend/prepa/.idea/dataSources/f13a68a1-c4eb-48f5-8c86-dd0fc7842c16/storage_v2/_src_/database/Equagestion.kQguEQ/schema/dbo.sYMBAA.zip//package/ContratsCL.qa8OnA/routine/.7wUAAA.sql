


/* Renvoie la liste des contrats et de leur realisation pour un client pour une annee */

create procedure ContratsCL  (@ent		char(5) 	= null,
							  @client	char(12),
							  @an		smallint
							  )
								
with recompile
as
begin

set arithabort numeric_truncation off

declare @multient	tinyint,
		@testRFA	tinyint					/* variable renvoyee par RFACT indiquant si une ligne de RFA a ete trouvee */

	
select @multient=KIMULTIENTITE from KInfos



create table #Finale
(
contrat			char(10)		not null,
division    	char(8)         not null,
marque      	char(12)        not null,
famille     	char(8)         not null,
categorie   	char(8)         not null,
article     	char(15)        not null,
tarif       	char(8)         not null,
qte_ct			int					null,
atteint_qte		int					null,
montant_ct  	numeric(14,0)       null,
atteint_val		numeric(14,2)		null,
rfa_due			numeric(14,2)		null,
rfa_pot			numeric(14,2)		null,
qte_atteint_1	int					null,
val_atteint_1	numeric(14,2)		null,
nbre_cdes		int					null,
seq				numeric(14,0)	identity
)

/*----- curseur ventesannee indiquee -----*/

declare clients cursor
for select STCL
from FST,FCL,FAR
where STCL=CLCODE
and START=ARCODE
and STCL = @client
and isnull(CLSANSRFA,0)=0
and STAN=@an
and (@ent is null or (STENT=@ent and CLENT=@ent))
group by STCL
for read only

/*----- curseur ventes annee - 1 -----*/

declare clients_1 cursor
for select STCL
from FST,FCL,FAR
where STCL=CLCODE
and START=ARCODE
and STCL = @client
and isnull(CLSANSRFA,0)=0
and STAN=@an - 1
and (@ent is null or (STENT=@ent and CLENT=@ent))
group by STCL
for read only

											/*----- ventes annee indiquee -----*/
open clients

fetch clients into @client


while (@@sqlstatus = 0)
begin
	

	execute RFA_Detail null,@client,@an,2,0
	
	insert into #Finale (contrat,division,marque,famille,categorie,article,tarif,
							qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot,
							qte_atteint_1,val_atteint_1,nbre_cdes)
	select CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,
							QTE_CT,ATTEINT_QTE,VAL_CT,ATTEINT_VAL,RFA_DUE,RFA_POT,0,0,0
	from FRFATemp
	where SPID=@@spid
	and CONTRAT not in (" CA","RFAHorsCTR")
		
	fetch clients into @client
	
end

close clients
deallocate cursor clients

											/*----- ventes annee - 1 -----*/

open clients_1

fetch clients_1 into @client


while (@@sqlstatus = 0)
begin
	

	execute RFA_Detail_1 null,@client,@an,2,0
	
	insert into #Finale (contrat,division,marque,famille,categorie,article,tarif,
							qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot,
							qte_atteint_1,val_atteint_1,nbre_cdes)
	select CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,
							QTE_CT,0,VAL_CT,0,0,0,ATTEINT_QTE,ATTEINT_VAL,0
	from FRFATemp
	where SPID=@@spid
	and CONTRAT not in (" CA","RFAHorsCTR")
		
	fetch clients_1 into @client
	
end

close clients_1
deallocate cursor clients_1


/*-------- recherche des commandes -----------*/


declare commandes cursor 
for select isnull(RCCARTICLE,''),sum(isnull(RCCQTE,0))
from FRCC,FAR
where ARCODE=RCCARTICLE
and ARSANSRFA=0 
and ARTYPE in (0,1)
and RCCCL=@client
group by RCCARTICLE
for read only


declare @article_curs	char(15),
		@qte_curs		int,
		@contrat_out	char(10),
		@depart_out		char(8),
		@fo_out			char(12),
		@fam_out		char(8),
		@categ_out		char(8),
		@article_out	char(15),
		@tarif_out		char(8),
		@qtect_out		int,
		@valct_out		numeric(14,0),
		@rcrfa_out		numeric(8,4)

open commandes

fetch commandes
into @article_curs,@qte_curs

while (@@sqlstatus = 0)
  begin
	
	select @testRFA = 0
	
	exec @testRFA = RFACT null,@client,@an,@article_curs,null,@contrat_out output,
			@depart_out output,@fo_out output,@fam_out output,@categ_out output,
			@article_out output,@tarif_out output,@qtect_out output,@valct_out output,
			@rcrfa_out output
 
	if @testRFA = 0
	begin
	  
	  if @contrat_out != ""
		insert into #Finale (contrat,division,marque,famille,categorie,article,tarif,
							  qte_ct,atteint_qte,montant_ct,atteint_val,rfa_due,rfa_pot,
							  qte_atteint_1,val_atteint_1,nbre_cdes)
		values(@contrat_out,@depart_out,@fo_out,@fam_out,@categ_out,@article_out,@tarif_out,
				  @qtect_out,0,@valct_out,0,0,0,0,0,@qte_curs)
	  end
 
	fetch commandes
	into @article_curs,@qte_curs
	
  end

close commandes
deallocate cursor commandes


select contrat,division,marque,famille,categorie,article,tarif,
		qte_ct,atteint_qte=sum(atteint_qte),montant_ct,atteint_val=sum(atteint_val),
		rfa_due=sum(rfa_due),rfa_pot=sum(rfa_pot),qte_atteint_1=sum(qte_atteint_1),
		val_atteint_1=sum(val_atteint_1), nbre_cdes=sum(nbre_cdes)
into #Finale2
from #Finale
group by contrat,division,marque,famille,categorie,article,tarif,qte_ct,montant_ct



/* select de sortie */

select  contrat,division,marque,famille,categorie,article,tarif,
        isnull(qte_atteint_1,0),isnull(val_atteint_1,0),        
		isnull(nbre_cdes,0),
		isnull(qte_ct,0),isnull(atteint_qte,0),
		(case when qte_ct=0 then 0 else isnull(atteint_qte,0) - isnull(qte_ct,0) end),
		isnull(montant_ct,0),isnull(atteint_val,0),
		(case when montant_ct=0 then 0 else isnull(atteint_val,0) - isnull(montant_ct,0) end)
from #Finale2

drop table #Finale
drop table #Finale2

end



go

