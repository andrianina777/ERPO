/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.BECCPrep_Spec
grant execute on BECCPrep_Spec to public

*/


/*  Procedure utilisee par le module 'Expeditions et Bons de Preparation'.	 */
/*	Renvoie les commandes a expedier dont les articles ne sont pas numerotes */
/*	Renvoie le nombre de colis de la commande								 */

CREATE PROCEDURE dbo.BECCPrep_Spec (@ent		char(5) = null,
							@UntilDate 	datetime = null,
							@Client		char(12),
							@Commande 	char(10) = null,
							@Depot		char(4),
							@nom		varchar(35) = null,
							@adr1		varchar(50) = null,
							@adr2		varchar(50) = null,
							@cp			varchar(12) = null,
							@ville		varchar(30) = null,
							@py			char(8) = null,
							@devise		char(3) = null
						   )
with recompile					
as
begin

set arithabort numeric_truncation off

declare @restotal	int,
		@resligne	int,
		@stocktotal	int,
		@CC2AO int,
		@CC2SPEC int

        create table #ccl(
                CCLSEQ int,
                CCLCODE char(15) null,
                CCLARTICLE char(15) null,
                ARLIB char(80) null,
                ARLIBXENO char(50) null,
                ARFO char(30) null,
                CCLNUMARM1 char(50) null,
                CCLLOT char(12) null,
                CCLQTE int not null,
                AREEMP char(10) null,
                STRESQTE int null,
                NLOTDATEPER smalldatetime null,
                xORDRE int null,
                xCONTENT char(50) null,
                xSTKAUTRE int null,
                xCONTENT2 char(50) null,
                ARESSEMP char(10) null
        )
	create table #ccl2(
                CCLCODE char(15) null,
                CCLARTICLE char(15) null,
                ARLIB char(80) null,
                ARLIBXENO char(50) null,
                ARFO char(30) null,
                CCLQTE int not null,
                AREEMP char(10) null,
                STRESQTE int null,
                xORDRE int null,
                xCONTENT char(50) null,
                xSTKAUTRE int null,
                xCONTENT2 char(50) null,
                ARESSEMP char(10) null
	)	

		
        create table #Liste
        (
                Article 		char(15)	not null,
                Lettre			char(4)		not null,
                Designation		char(80)		null,
                LienCode		char(10)	not null,
                LienNum			int			not null,
                Qte				int				null,
                UnitFact		tinyint		not null,
                PrixHT			numeric(14,3)	null,
                ModeLiv			char(2)			null,
                LigneLibre		varchar(255)	null,
                TypeVente		char(4)		not null,
                Reglement		tinyint			null,
                Echeancesp		tinyint			null,
                Factman			tinyint			null,
                Offert			tinyint			null,
                Artype			tinyint			null,
                Devise			char(3)		not null,
                Coursdev		numeric(16,10)	null,
                PrixHTdev		numeric(14,3)	null,
                TotHTdev		numeric(14,3)	null,
                Rem1			real			null,
                Rem2			real			null,
                Rem3	 		real			null,
                TotPrixHT		numeric(14,3)	null,
                Emplacement		char(8)		not null,
                Attachement		char(10)		null,
                Lot				char(12)	not null,
                Arreffour		char(20)		null,
                cclmarche		char(12)		null,
                ccldate			datetime		null,
                cclcolis		numeric(14,3)	null,
                arqtecolis		int				null,
                cclpaht			numeric(14,3)	null,
                seqLib numeric (18,0) null,
                comment_mag		varchar(255)	null,
                cclcolisage		varchar(25)     null,
                cclnbcolis		int				null,
                cclpack			int				null,
                id numeric identity
        )

        create table #Prep
        (
                CCLSEQ			int			not null,
                CCLCODE			char(10)	not null,
                CCLNUM			int				null,
                CCLDATE			datetime		null,
                CCLARTICLE		char(15)	not null,
                CCLRESTE		int				null,
                ARLIB			varchar(80)		null,
                ARUNITFACT		tinyint			null,
                CCLPHT			numeric(14,3)	null,
                MODELIV			char(2)			null,
                CCLLIBRE		varchar(255)	null,
                CCLTV			char(4)			null,
                ARREGLE			tinyint			null,
                CCLECHSPE		tinyint			null,
                CCLFACTMAN		tinyint			null,
                CCLOFFERT		tinyint			null,
                ARTYPE			tinyint			null,
                CCLDEV			char(3)			null,
                CCLCOURSDEV		numeric(16,10)	null,
                CCLPHTDEV		numeric(14,3)	null,
                CCLTOTALHTDEV	numeric(14,3)	null,
                CCLR1			real		 	null,
                CCLR2			real			null,
                CCLR3			real			null,
                CCLTOTALHT		numeric(14,3)	null,
                CCLQTERES		int				null,
                CCLDATERESFIN	smalldatetime	null,
                CCLDEPOTRES		char(4)			null,
                ARCOMP			tinyint			null,
                CCLQTEPREP		int				null,
                CCLATTACHE		char(10)		null,
                ARREFFOUR 		char(20)		null,
                CCLMARCHE		char(12)		null,
                CCLCOLIS		numeric(14,3)	null,
                ARQTECOLIS		int				null,
                CCLPAHT			numeric(14,3)	null,
                CCL_LIBSEQ numeric(18,0) null,
                CCL_COMMENT_MAG varchar(255)	null,
                CCLCOLISAGE		varchar(25)		null,
                CCLNBCOLIS		int				null,
                CCLPACK			int				null
        )

        create table #Articles
        (
                CCLARTICLE	char(15)		not null,
                ARTYPE int null
        )

        create table #Stock
        (
                STEMPAR			char(15)		not null,
                STEMPLETTRE		char(4)			not null,
                QteLoc			int					null,
                STEMPDATE		datetime			null,
                STEMPEMP		char(8)			not null,
                STEMPLOT		char(12)		not null,
                STEMPDEPOT		char(4)			not null,
                SEQ				numeric(14,0)	identity
        )
        create table #Stocktmp
        (
                STEMPAR			char(15)	not null,
                STEMPLETTRE		char(4)		not null,
                QteLoc			int		null,
                STEMPDATE		datetime	null,
                STEMPEMP		char(8)		not null,
                STEMPLOT		char(12)	not null,
                STEMPDEPOT		char(4)		not null,
                SEQ			numeric(14,0)	identity
        )

 CREATE TABLE
    #FRCC
    (
        CCCODE varchar(10) null,
        RCCSEQ INT,
        RCCARTICLE CHAR(15),
        RCCDATE DATETIME,
        RCCMOIS TINYINT,
        RCCAN SMALLINT,
        RCCQTE INT,
        RCCCL CHAR(12),
        RCCECH TINYINT,
        RCCFACTMAN TINYINT NULL,
        RCCENT CHAR(5) NULL,
        RCCQTERES INT NULL,
        RCCDATERESFIN SMALLDATETIME NULL,
        RCCDEPOTRES CHAR(4) NULL,
        RCCQTEPREP INT NULL,
        RCCLOT CHAR(12) NULL,
        RCCARM1 CHAR(30) NULL
    )


create unique clustered index starlet on #Stock(STEMPAR,STEMPLETTRE,STEMPEMP)

/*FCCL*/
select FCCL.CCLSEQ, FCCL.CCLCODE, FCCL.CCLARTICLE, FCCL.CCLQTE, FCCL.CCLDATE, FCCL.CCLR1, FCCL.CCLR2, FCCL.CCLR3, FCCL.CCLR4, FCCL.CCLR5, FCCL.CCLPHT, FCCL.CCLORDRE, FCCL.CCLUNITFACT, FCCL.CCLTV, FCCL.CCLTYPE, FCCL.CCLLIBRE, FCCL.CCLNUM, FCCL.CCLQTEEXP, FCCL.CCLRESTE, FCCL.CCLCL, FCCL.CCLTOTALHT, FCCL.CCLECHSPE, FCCL.CCLTYPEMV, FCCL.CCLDATEMDF, FCCL.CCLUSERMDF, FCCL.CCLFACTMAN, FCCL.CCLOFFERT, FCCL.CCLDATECRE, 
FCCL.CCLUSERCRE, FCCL.CCLDEV, FCCL.CCLCOURSDEV, FCCL.CCLPHTDEV, FCCL.CCLTOTALHTDEV, FCCL.CCLATTACHE, FCCL.CCLENT, FCCL.CCLQTERES, FCCL.CCLDATERESFIN, FCCL.CCLDEPOTRES, FCCL.CCLREP, FCCL.CCLREPDIV, FCCL.CCLWEBCODE, FCCL.CCLWEBNUM, FCCL.CCLQTEPREP, FCCL.CCLCF, FCCL.CCLMARCHE, FCCL.CCLFACT, FCCL.CCLLOT, FCCL.CCLFRAIS, FCCL.CCLCOLIS, FCCL.CCLPAHT, FCCL.CCLDATEINIT, FCCL.CCLTOTALHTORG, FCCL.CCLNUMARM1, FCCL.CCL_LIBSEQ, FCCL.CCLATTETRANSFERT, FCCL.CCL_COMMENT_MAG,
CCLCOLISAGE,CCLNBCOLIS,CCLPACK
into #FCCL
from FCCL 
where CCLCODE=@Commande


/*LISTE ARTICLE*/
select distinct CCLARTICLE
into #LISTE_ARTICLE
from #FCCL

/*FCC*/
select VIEW_FCC_FCC2.CCCODE, VIEW_FCC_FCC2.CCSEQ, VIEW_FCC_FCC2.CCREFCOMCL, VIEW_FCC_FCC2.CCDATECOM, VIEW_FCC_FCC2.CCCLIENT, VIEW_FCC_FCC2.CCREPRES, VIEW_FCC_FCC2.CCUSERID, VIEW_FCC_FCC2.CCFRANCO, VIEW_FCC_FCC2.CCECHSPE, VIEW_FCC_FCC2.CCSATISFAITE, VIEW_FCC_FCC2.CCMODELIV, VIEW_FCC_FCC2.CCCOMMENTAIRES, VIEW_FCC_FCC2.CCMODECOM, VIEW_FCC_FCC2.CCPCLIVRE, VIEW_FCC_FCC2.CCDATEMDF, VIEW_FCC_FCC2.CCFACTMAN, VIEW_FCC_FCC2.CCSANSASSUR, VIEW_FCC_FCC2.CCPREP, VIEW_FCC_FCC2.CCDATECRE, VIEW_FCC_FCC2.CCUSERCRE, VIEW_FCC_FCC2.CCCODEADR, VIEW_FCC_FCC2.CCTARIF, VIEW_FCC_FCC2.CCDEV, VIEW_FCC_FCC2.CCCOURSDEV, VIEW_FCC_FCC2.CCGROUPE, VIEW_FCC_FCC2.CCVALIDE, VIEW_FCC_FCC2.CCNOM, VIEW_FCC_FCC2.CCADR1, VIEW_FCC_FCC2.CCADR2, VIEW_FCC_FCC2.CCCP, VIEW_FCC_FCC2.CCVILLE, VIEW_FCC_FCC2.CCPAYS, VIEW_FCC_FCC2.CCATTACHE, VIEW_FCC_FCC2.CCPY, VIEW_FCC_FCC2.CCENT, VIEW_FCC_FCC2.CCTR1, VIEW_FCC_FCC2.CCTR2, VIEW_FCC_FCC2.CCTR3, VIEW_FCC_FCC2.CCTR4, VIEW_FCC_FCC2.CCPCECH1, VIEW_FCC_FCC2.CCPCECH2, VIEW_FCC_FCC2.CCPCECH3, VIEW_FCC_FCC2.CCPCECH4, VIEW_FCC_FCC2.CCFRANCOBE, VIEW_FCC_FCC2.CCBEBLOQUE, 
VIEW_FCC_FCC2.CCCOMMENTMAG, VIEW_FCC_FCC2.CCDATEECH1, VIEW_FCC_FCC2.CCDATEECH2, VIEW_FCC_FCC2.CCDATEECH3, VIEW_FCC_FCC2.CCDATEECH4, VIEW_FCC_FCC2.CCWEBCODE, VIEW_FCC_FCC2.CCDATEFINLIV, VIEW_FCC_FCC2.CCALERTE, VIEW_FCC_FCC2.CCRESUME, VIEW_FCC_FCC2.CCTVCG, VIEW_FCC_FCC2.CCRG1, VIEW_FCC_FCC2.CCRG2, VIEW_FCC_FCC2.CCRG3, VIEW_FCC_FCC2.CCSI, VIEW_FCC_FCC2.CCMARCHE, VIEW_FCC_FCC2.CCREFCL, VIEW_FCC_FCC2.CCACOMPTE1, VIEW_FCC_FCC2.CCACOMPTE2, VIEW_FCC_FCC2.CCACOMPTE3, VIEW_FCC_FCC2.CCACOMPTE4, VIEW_FCC_FCC2.CCAGE, VIEW_FCC_FCC2.CCORIGINE, VIEW_FCC_FCC2.CCDEVIS_PROSPECT, VIEW_FCC_FCC2.CCSTADE_DET, 
VIEW_FCC_FCC2.CCDATE_0, VIEW_FCC_FCC2.CCDATE_1, VIEW_FCC_FCC2.CCDATE_2, VIEW_FCC_FCC2.CCDATE_3, VIEW_FCC_FCC2.CCDATE_4, VIEW_FCC_FCC2.CCDATE_5, VIEW_FCC_FCC2.CCDATE_6, VIEW_FCC_FCC2.CCDATE_PROACT, VIEW_FCC_FCC2.CCBILAN, VIEW_FCC_FCC2.CCPROACT, VIEW_FCC_FCC2.CCREMISE, VIEW_FCC_FCC2.CCTOTFINAL, VIEW_FCC_FCC2.CCRESTEACOMPTE, VIEW_FCC_FCC2.CCDEVCODE, VIEW_FCC_FCC2.CCNOM2, VIEW_FCC_FCC2.CCPRENOM, VIEW_FCC_FCC2.CCESCOMPTE, VIEW_FCC_FCC2.CCPRIORITE, VIEW_FCC_FCC2.CCTRANSPORTEUR, VIEW_FCC_FCC2.CCMODETRANSP, VIEW_FCC_FCC2.CCPREPSPECIF, VIEW_FCC_FCC2.CCDATELIV, VIEW_FCC_FCC2.CCADRCODEFACT, VIEW_FCC_FCC2.CCADRCODECO, VIEW_FCC_FCC2.CCORIGINE2, VIEW_FCC_FCC2.CCTYPEADR, VIEW_FCC_FCC2.CCTYPEADRFA, VIEW_FCC_FCC2.CCTYPEADRCO, VIEW_FCC_FCC2.CCATTETRANSFERT, VIEW_FCC_FCC2.CC2CODE, VIEW_FCC_FCC2.CC2SEQ, 
VIEW_FCC_FCC2.CC2CODEADRFA, VIEW_FCC_FCC2.CC2RAISSOCFA, VIEW_FCC_FCC2.CC2NOMFA, VIEW_FCC_FCC2.CC2PRENOMFA, VIEW_FCC_FCC2.CC2ADR1FA, VIEW_FCC_FCC2.CC2ADR2FA, VIEW_FCC_FCC2.CC2ADR3FA, VIEW_FCC_FCC2.CC2CPFA, VIEW_FCC_FCC2.CC2VILLEFA, VIEW_FCC_FCC2.CC2PYFA, VIEW_FCC_FCC2.CC2PAYSFA, VIEW_FCC_FCC2.CC2CODEADRCO, VIEW_FCC_FCC2.CC2RAISSOCCO, VIEW_FCC_FCC2.CC2NOMCO, VIEW_FCC_FCC2.CC2PRENOMCO, VIEW_FCC_FCC2.CC2ADR1CO, VIEW_FCC_FCC2.CC2ADR2CO, VIEW_FCC_FCC2.CC2ADR3CO, VIEW_FCC_FCC2.CC2CPCO, VIEW_FCC_FCC2.CC2VILLECO, VIEW_FCC_FCC2.CC2PYCO, VIEW_FCC_FCC2.CC2PAYSCO, VIEW_FCC_FCC2.CC2TELFA, VIEW_FCC_FCC2.CC2FAXFA, VIEW_FCC_FCC2.CC2MAILFA, VIEW_FCC_FCC2.CC2TELCO, VIEW_FCC_FCC2.CC2FAXCO, VIEW_FCC_FCC2.CC2MAILCO, VIEW_FCC_FCC2.CC2ENTETEFA, VIEW_FCC_FCC2.CC2ENTETECO, VIEW_FCC_FCC2.CC2DATELIV, VIEW_FCC_FCC2.CC2DATELIV_RET, VIEW_FCC_FCC2.CC2NBCARTON, VIEW_FCC_FCC2.CC2LIV, VIEW_FCC_FCC2.CC2NBIMPR, VIEW_FCC_FCC2.CC2COMMIMP, 
VIEW_FCC_FCC2.CC2URGENT, VIEW_FCC_FCC2.CC2APRENDRE, VIEW_FCC_FCC2.CC2LIV_SEQ, VIEW_FCC_FCC2.CC2GARDE, VIEW_FCC_FCC2.CC2ACCORD, VIEW_FCC_FCC2.CC2COMENTAIRE_ACCORD, VIEW_FCC_FCC2.CC2IMPAYE, VIEW_FCC_FCC2.CC2RETARDIMPAYE, VIEW_FCC_FCC2.CC2MODREG, VIEW_FCC_FCC2.CC2MODREGNORM, VIEW_FCC_FCC2.CC2RETOURLIV, VIEW_FCC_FCC2.CC2AO, VIEW_FCC_FCC2.CC2DEBPREPRAYON, VIEW_FCC_FCC2.CC2FINPREPRAYON, VIEW_FCC_FCC2.CC2FINREGROUPEMENT, VIEW_FCC_FCC2.CC2LOT, VIEW_FCC_FCC2.CC2ENREGTEMP, VIEW_FCC_FCC2.CC2DATERETDATA, VIEW_FCC_FCC2.CC2ARRIVECLIENT, VIEW_FCC_FCC2.CC2DEPARTCLIENT, VIEW_FCC_FCC2.CC2COMMENTLIV, VIEW_FCC_FCC2.CC2LIVRAISON, VIEW_FCC_FCC2.CC2DATELIV_PREVU, VIEW_FCC_FCC2.CC2DATE_ANNULLIV,CC2SPEC
into #FCC
from VIEW_FCC_FCC2 where CCCODE=@Commande

/*prendre la valeur du SPEC et AO*/
select @CC2SPEC=CC2SPEC,@CC2AO=CC2AO from #FCC

/*FRCC pour les commande normale*/
insert into #FRCC
select CCCODE,RCCSEQ, RCCARTICLE, RCCDATE, RCCMOIS, RCCAN, RCCQTE, RCCCL, RCCECH, RCCFACTMAN, RCCENT, RCCQTERES, RCCDATERESFIN, RCCDEPOTRES, RCCQTEPREP, RCCLOT, RCCARM1
from FRCC,FCCL,VIEW_FCC_FCC2
where RCCSEQ=CCLSEQ
and CCLCODE=CCCODE
and CCSTADE_DET>=3
and isnull(CC2AO,0)=0 
and isnull(CC2SPEC,0)=0
and RCCARTICLE in (select CCLARTICLE from #LISTE_ARTICLE)


if(@CC2SPEC>0 or @CC2AO>0)
begin
        insert into #FRCC
        select CCCODE,RCCSEQ, RCCARTICLE, RCCDATE, RCCMOIS, RCCAN, RCCQTE, RCCCL, RCCECH, RCCFACTMAN, RCCENT, RCCQTERES, RCCDATERESFIN, RCCDEPOTRES, RCCQTEPREP, RCCLOT, RCCARM1
        from FRCC,FCCL,VIEW_FCC_FCC2
        where RCCSEQ=CCLSEQ
        and CCLCODE=CCCODE
        and CCCODE=@Commande
end 

/*FSTEMP*/
select VIEW_FSTEMP.STEMPAR, VIEW_FSTEMP.STEMPLETTRE, VIEW_FSTEMP.STEMPDEPOT, VIEW_FSTEMP.STEMPEMP, VIEW_FSTEMP.STEMPQTE, VIEW_FSTEMP.STEMPDATE, VIEW_FSTEMP.STEMPLOT, VIEW_FSTEMP.STEMPUSERCRE, VIEW_FSTEMP.STEMPDATECRE, VIEW_FSTEMP.STEMPUSERMDF, VIEW_FSTEMP.STEMPDATEMDF, VIEW_FSTEMP.STEMPID
into #FSTEMP
from VIEW_FSTEMP,FDP,#LISTE_ARTICLE
where STEMPAR=CCLARTICLE
and STEMPDEPOT=DPCODE
and DPCENTRAL=1

/*FSTOCK*/
select VIEW_FSTOCK.STAR, VIEW_FSTOCK.STDATEMDF, VIEW_FSTOCK.STLETTRE, VIEW_FSTOCK.STQTE, VIEW_FSTOCK.STDATEENTR, VIEW_FSTOCK.STCOMMENT, VIEW_FSTOCK.STPAHT, VIEW_FSTOCK.STPADEV, VIEW_FSTOCK.STNUMARM1, VIEW_FSTOCK.STNUMARM2, VIEW_FSTOCK.STDEPOT, VIEW_FSTOCK.STDEVISE, VIEW_FSTOCK.STFRAIS, VIEW_FSTOCK.STDERUSER, VIEW_FSTOCK.STDATECRE, VIEW_FSTOCK.STUSERCRE, VIEW_FSTOCK.STFO, VIEW_FSTOCK.STUNITE, VIEW_FSTOCK.STEMP, VIEW_FSTOCK.STID, VIEW_FSTOCK.STLOT, VIEW_FSTOCK.ST_UG, VIEW_FSTOCK.ST_QTE_RSRV
into #FSTOCK
from VIEW_FSTOCK,FDP,#LISTE_ARTICLE
where STAR=CCLARTICLE
and STDEPOT=DPCODE
and DPCENTRAL=1



declare @ar char(20),@detail int,@detailres int,@autreStk int ,@ccllot char(20),@cclseq int,@cclSerie char(25),@ssemp char(10),@emp char(10),@qte int,
@CCLQTE int
/*OPHAM RICKY*/
declare lesLignes cursor
for select CCLARTICLE,sum(CCLQTE) from #FCCL  group by CCLARTICLE 
open lesLignes
fetch lesLignes into @ar,@qte
while (@@sqlstatus=0)
begin
	/* on recherche le stock total du rayon detail */

        /* on recherche le stock total du rayon detail */
        select @detail=isnull(sum(STQTE ),0)-isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #FSTOCK   where STAR=@ar and STDEPOT=@Depot  
        
	 /* on recherche ensuite le stock reserve pour cet article precis lot/serie */

        select @detailres=0
        select @detailres=isnull(sum(isnull(RCCQTEPREP,0)),0) 
        from #FRCC
        where CCCODE<>@Commande and RCCARTICLE=@ar
        

        select @emp=max(STEMPEMP) from FSTEMP where STEMPDEPOT=@Depot and  STEMPQTE>0 and STEMPAR=@ar 
   
        select @autreStk=isnull(sum(STQTE ),0)-isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #FSTOCK
        where STAR=@ar and STDEPOT<>@Depot

	select @ssemp=ARESSEMP from VIEW_FARE where AREDEPOT=@Depot and AREEMP=@emp and AREAR=@ar 
	

        select @CCLQTE=sum(CCLQTE-isnull(CCLQTEEXP,0)) from #FCCL where  CCLARTICLE=@ar
        
        insert into #ccl2
        select @Commande,@ar,ARLIB,ARLIBXENO,ARFO,@CCLQTE,@emp,@detail-@detailres, 0,'',@autreStk ,'',@ssemp
        from VIEW_FAR
        where ARCODE=@ar 
	
 
    fetch lesLignes into @ar,@qte
end
close lesLignes
deallocate cursor lesLignes 

	/* recherche stockl */



if (@UntilDate is null)
begin
	insert into #Prep
	select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
	substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
	ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
	isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
	isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,''),isnull(CCLCOLISAGE,''),isnull(CCLNBCOLIS,0),isnull(CCLPACK,0)
	from #FCCL,FAR,#FCC,#FRCC
	where CCLSEQ=RCCSEQ
	and RCCCL=@Client
	and RCCARTICLE=ARCODE
	and #FCC.CCCODE=CCLCODE
	and (@Commande is null or CCLCODE=@Commande)
	and ARNUMEROTE=0
	and isnull(CCVALIDE,0)=0
	and isnull(CCBEBLOQUE,0)=0
	and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	and (isnull(@nom,'') = '' or CCNOM = @nom)
	and (isnull(@adr1,'') = '' or CCADR1 = @adr1)
	and (isnull(@adr2,'') = '' or CCADR2 = @adr2)
	and (isnull(@cp,'') = '' or CCCP = @cp)
	and (isnull(@ville,'') = '' or CCVILLE = @ville)
	and (isnull(@py,'') = '' or CCPY = @py)
	and (isnull(@devise,'') = '' or CCDEV = @devise)
	order by RCCDATE,RCCSEQ
end
else
begin
	insert into #Prep
	select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
	substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
	ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
	isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
	isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,''),isnull(CCLCOLISAGE,''),isnull(CCLNBCOLIS,0),isnull(CCLPACK,0)
	from #FCCL,FAR,#FCC,#FRCC
	where CCLSEQ=RCCSEQ
	and RCCCL=@Client
	/*and RCCDATE<=@UntilDate*/
	and RCCARTICLE=ARCODE
        and CCLCL=CCCLIENT
	and #FCC.CCCODE=CCLCODE
	and (@Commande is null or CCLCODE=@Commande)
	and ARNUMEROTE=0
	and isnull(CCVALIDE,0)=0
	and isnull(CCBEBLOQUE,0)=0
	and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	and (isnull(@nom,'') = '' or CCNOM = @nom)
	and (isnull(@adr1,'') = '' or CCADR1 = @adr1)
	and (isnull(@adr2,'') = '' or CCADR2 = @adr2)
	and (isnull(@cp,'') = '' or CCCP = @cp)
	and (isnull(@ville,'') = '' or CCVILLE = @ville)
	and (isnull(@py,'') = '' or CCPY = @py)
	and (isnull(@devise,'') = '' or CCDEV = @devise)

	order by RCCDATE,RCCSEQ
end
insert into #Articles (CCLARTICLE,ARTYPE)
select distinct CCLARTICLE,ARTYPE from #Prep

create unique clustered index article on #Articles(CCLARTICLE)

declare		@CCLSEQ			int,
			@CCLCODE		char(10),
			@CCLNUM			int,
			@CCLDATE		datetime,
			@CCLARTICLE		char(15),
			@CCLRESTE		int,
			@ARLIB			varchar(80),
			@ARUNITFACT		tinyint,
			@PUHT			numeric(14,3),
			@MODELIV		char(2),
			@CCLLIBRE		varchar(255),
			@CCLTV			char(4),
			@ARREGLE		tinyint,
			@CCLECHSPE		tinyint,
			@CCLFACTMAN		tinyint,
			@CCLOFFERT		tinyint,
			@ARTYPE			tinyint,
			@CCLDEV			char(3),
			@CCLCOURSDEV	numeric(16,10),
			@CCLPHTDEV		numeric(14,3),
			@CCLTOTALHTDEV	numeric(14,3),
			@CCLR1			real,
			@CCLR2			real,
			@CCLR3			real,
			@CCLTOTALHT		numeric(14,3),
			@CCLQTERES		int,
			@CCLDATERESFIN	smalldatetime,
			@CCLDEPOTRES	char(4),
			@ARCOMP			tinyint,
			@CCLQTEPREP		int,
			@CCLATTACHE		char(10),
			@ARREFFOUR		char(20),
			@CCLMARCHE		char(12),
			@CCLCOLIS		numeric(14,3),
			@ARQTECOLIS		int,
			@CCLPAHT		numeric(14,3),
            @CCL_LIBSEQ numeric(18,0),
            @CCL_COMMENT_MAG varchar(255),
            @CCLCOLISAGE	varchar(25),
            @CCLNBCOLIS		int,
            @CCLPACK		int
            
set forceplan on 

/*OPHAM POUR RASSURER QU IL nya pas de B qui bloque les Bon de Preparation*/ 

/*inserer dans la table #FRBP*/


select RBPARTICLE,RBPDEPOT,RBPLETTRE,sum(RBPQTE) as RBPQTE
into #FRBP
from FRBP
where RBPARTICLE in (select CCLARTICLE from #LISTE_ARTICLE) 
group by RBPARTICLE,RBPDEPOT,RBPLETTRE



create table #StockTmp1(
        STEMPAR varchar(50) null,
        STEMPLETTRE varchar(4) null,
        QteLoc int null,
        STEMPDATE smalldatetime null,
        STEMPEMP varchar(10) null,
        STEMPLOT varchar(50) null,
        STEMPDEPOT varchar(20) null       
)


/*ARTICLE STOCKE*/
insert into  #StockTmp1
select STEMPAR,STLETTRE ,sum(STEMPQTE),NLOTDATEPER ,STEMPEMP,STLOT ,STEMPDEPOT
from VIEW_STOCK_LOT_EMPLACEMENT
where STEMPAR in (select CCLARTICLE from #Articles where ARTYPE=0 ) 
and STEMPDEPOT=@Depot
group by STEMPAR,STLETTRE,NLOTDATEPER,STEMPEMP,STLOT,STEMPDEPOT

/*ARTICLE NON STOCKE*/
insert into  #StockTmp1(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
select STEMPAR,STEMPLETTRE,STEMPQTE,null,STEMPEMP,'',STEMPDEPOT
from FSTEMP,#Articles
where STEMPAR=CCLARTICLE
and STEMPDEPOT= @Depot
and ARTYPE>0


 
 update #StockTmp1 set QteLoc=QteLoc-RBPQTE
 from #StockTmp1,#FRBP
 where STEMPAR=RBPARTICLE
 and STEMPDEPOT=RBPDEPOT
 and STEMPLETTRE=RBPLETTRE
 


insert into #Stocktmp (STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
select STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT from #StockTmp1
order by STEMPAR,STEMPDATE

  

/*enlever les stock dejà reservé dans la table FSTOCK pour cette article et lettre + depot*/

        declare 	@qteST 			int,
                        @articleST 		char(15),
                        @lettreST 		char(4),
                        @qtealivrer		int,
                        @emplacement	char(8),
                        @lot			char(12),
                        @depot			char(4),
                        @seq			numeric(14,0),
                        @resteapreparer	int,
                        @stockRSRV_FSTOCK int,@datePer datetime
                
        
        declare stockTmp cursor for select STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT from #Stocktmp order by SEQ 
        open stockTmp
        fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot
        while (@@sqlstatus=0)
        begin
                select @stockRSRV_FSTOCK=0
                select @stockRSRV_FSTOCK=isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #FSTOCK /*VIEW_FSTOCK*/ where STAR=@articleST and STDEPOT=@depot and STLETTRE= @lettreST
                select @qteST=@qteST-@stockRSRV_FSTOCK
                insert into #Stock(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT) values (@articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot)
                
                 fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot 
        end
        close stockTmp
        deallocate cursor stockTmp

        drop table #Stocktmp
        delete from #Prep where not exists (select * from #Stock where STEMPAR=#Prep.CCLARTICLE)
 
declare commandes cursor for
select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,
ARUNITFACT,CCLPHT,MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,CCLOFFERT,
ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,ARCOMP,CCLQTEPREP,CCLATTACHE,ARREFFOUR,CCLMARCHE,CCLCOLIS,ARQTECOLIS,CCLPAHT,CCL_LIBSEQ,CCL_COMMENT_MAG,CCLCOLISAGE,CCLNBCOLIS,CCLPACK
from #Prep
order by CCLDATE,CCLSEQ
for read only

open commandes
fetch commandes
into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV ,
@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK


while (@@sqlstatus = 0)
begin
        
                        select @resteapreparer = @CCLRESTE-@CCLQTEPREP
                        select @stocktotal= isnull(sum(QteLoc),0) from #Stock where STEMPAR=@CCLARTICLE and STEMPDEPOT=@Depot
                
                        /*stocker dans une table tmp le stock*/
                        select #Stock.STEMPAR, #Stock.STEMPLETTRE, #Stock.QteLoc, #Stock.STEMPDATE, #Stock.STEMPEMP, #Stock.STEMPLOT, #Stock.STEMPDEPOT, #Stock.SEQ  into #stockTmp
                        from #Stock 

                        /*parcoourir la ligne de stock*/
                        declare ligneStock cursor for select STEMPAR,STEMPLETTRE,QteLoc,STEMPEMP,STEMPLOT,STEMPDEPOT,SEQ from #stockTmp where STEMPAR=@CCLARTICLE and STEMPDEPOT=@Depot order by SEQ
                        open ligneStock
                        fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                        while (@@sqlstatus=0)
                        begin
                                if(@ARTYPE<>0)
                                begin
                                        select @qtealivrer=@resteapreparer
                                        select @resteapreparer=0
                                end
                                else
                                begin
                                        if(@qteST>=@resteapreparer)/*QTE ligne de stock peut honorer la quantité a preparer*/
                                        begin
                                                select @qtealivrer=@resteapreparer
                                                update #Stock set QteLoc=QteLoc-@qtealivrer where SEQ = @seq
                                                select @resteapreparer=0
                                        end
                                        else 
                                        begin
                                                select @qtealivrer=@qteST/*quantité a lvrer = qte en stock*/
                                                update #Stock set QteLoc=0 where SEQ = @seq
                                                select @resteapreparer= @resteapreparer-@qtealivrer
        
                                        end
                                  end      
                                        
                                        insert into #Liste (Article,Lettre,Designation,LienCode,LienNum,Qte,
                                                                                  UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,
                                                                                  Reglement,Echeancesp,Factman,Offert,Artype,
                                                                                  Devise,Coursdev,PrixHTdev,TotHTdev,Rem1,Rem2,Rem3,
                                                                                  TotPrixHT,Emplacement,Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,seqLib,comment_mag,cclcolisage,cclnbcolis,cclpack)
                                        select @articleST,@lettreST,@ARLIB,@CCLCODE,@CCLNUM,@qtealivrer,
                                                                                  @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,
                                                                                  @CCLTV,@ARREGLE,@CCLECHSPE,@CCLFACTMAN,@CCLOFFERT,@ARTYPE,
                                                                                  @CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,@CCLR1,@CCLR2,@CCLR3,
                                                                                  @CCLTOTALHT,@emplacement,@CCLATTACHE,@lot,@ARREFFOUR,@CCLMARCHE,@CCLDATE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK
                                
                                if @resteapreparer<=0 break
                                
                                fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                        end
                        close ligneStock
                        deallocate cursor ligneStock
                    
        
        /*FIN NEW*/     --delete from #Stock where SEQ=@seq
                        drop table #stockTmp

	fetch commandes
	into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
	@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
	@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
	@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
	@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG,@CCLCOLISAGE,@CCLNBCOLIS,@CCLPACK
end

close commandes
deallocate cursor commandes

delete from #Liste
where Artype=4
and not exists (select * from #Liste as b where #Liste.LienCode=b.LienCode and b.Artype <> 4)
and not exists (select * from FCCL,FAR where CCLCODE=#Liste.LienCode and ARCODE=CCLARTICLE and CCLRESTE > 0 and (ARNUMEROTE=1 or ARCOMP=2))










/*POUR LE BESOIN D APPRO DETAIL*/

create table #Appro (LIB char(255) null,CCLQTE int null,STRESTE int null,STDEPOT char(10) null,STEMPEMP char(10) null, STEMPQTE int null, CCLSEQ int null)

create table #Appro2(
        ARTICLE varchar(50) null,
        LIB varchar(255) null,
        CCLQTE int null,
        STREQTE int null,
        STDEPOT varchar(20) null,
        STEMPQTE int null
        
)
insert into #Appro2
select STEMPAR,rtrim(ARLIB),
CCLQTE,STRESQTE,STDEPOT,'QTE'=sum(STEMPQTE)
from #ccl2,#FSTOCK,#FSTEMP--VIEW_FSTEMP
where STRESQTE<CCLQTE
and STEMPAR=CCLARTICLE
and STEMPAR=STAR
and STEMPLETTRE=STLETTRE
and STEMPDEPOT<>@Depot and  STDEPOT=STEMPDEPOT
--and DPCENTRAL=1 
group by STEMPAR,rtrim(ARLIB),CCLQTE,STRESQTE,STDEPOT



/*traitement special pour le sortie GROS*/
if (@Depot='GROS')
begin
        --verifier colisage standard
        
        create table #QteParColis(
                id int null,
                article varchar(50) null,
                qteInit int null,
                qte int null
        )
        
        select ARCODE,ARFRANCOFO as COLISAGE
        into #colisage
        from VIEW_FAR
        where ARCODE in (select distinct Article from #Liste)
        
        select Article,Lettre,sum(Qte) as Qte,COLISAGE
        into #Liste_Colisage
        from #Liste,#colisage
        where Qte > 0
        and Article*=ARCODE
        group by Article,Lettre,COLISAGE
        
        
        delete from #Liste_Colisage where isnull(COLISAGE,0)=0


        /*parcourir la #iste pour ne pas prendre que des qté correspond au colisage*/
        declare @Article varchar(50),@Lettre varchar(4), @QteCde int,@colis int,@QteColis int,@ArticleInit varchar(50),@LettreInit varchar(4),@QteInit int,@NewQte int,@id int
        
        declare listeColis cursor for select Article, Lettre, Qte, COLISAGE ,(Qte/COLISAGE)*COLISAGE from #Liste_Colisage where Qte>=COLISAGE and Qte>(Qte/COLISAGE)*COLISAGE
        open listeColis 
        fetch listeColis into @Article,@Lettre,@QteCde,@colis,@QteColis
        while (@@sqlstatus=0)
        begin
        
                /*parcourir #Liste  et modifier la Qté selon le colisage */
                declare listeModif cursor for select id,Article,Lettre,Qte from #Liste where Article =@Article and Lettre=@Lettre order by Qte desc 
                open listeModif
                fetch listeModif into @id,@ArticleInit ,@LettreInit ,@QteInit 
                while (@@sqlstatus=0)
                begin
                        if(@QteInit>=@QteColis)
                        begin
                                select @NewQte=@QteColis--@QteInit-@QteColis
                                select @QteColis=0
                        end
                        else
                        begin
                                select @NewQte=@QteInit
                                select @QteColis=@QteColis-@QteInit
                        end
                        insert into #QteParColis values (@id,@ArticleInit,@QteInit,@NewQte)

                        fetch listeModif into @id,@ArticleInit ,@LettreInit ,@QteInit 
                end
                close listeModif
                deallocate cursor listeModif
                
                fetch listeColis into @Article,@Lettre,@QteCde,@colis,@QteColis
        end
        close listeColis
        deallocate cursor listeColis
        
        
        update #Liste set Qte=qte
        from #Liste,#QteParColis
        where #QteParColis.id=#Liste.id
        
        /*supprimer les ligne dans la liste pour les article avec qte en commande< colisage standard*/
        delete from #Liste
        where Article not in (select distinct Article from #Liste_Colisage where Qte>=COLISAGE)
        
             
        drop table #colisage
        drop table #Liste_Colisage
        drop table #QteParColis
        
        
end

/*declare @xVAL int
select @xVAL=convert(int,xVAL) from xMAILAUTO where xKEY='NB_LIGNE_SPECIAL'
*/

/*select distinct top @xVAL   Article
into #limite
from #Liste
*/
select rtrim(Article) as Article,Lettre,rtrim(Designation) as Designation,LienCode,LienNum,Qte,
	   UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,Reglement,
	   Echeancesp,abs(Qte),Factman,isnull(Offert,0),isnull(Artype,0),
	   isnull(Devise,''),isnull(Coursdev,0),isnull(PrixHTdev,0),
	   isnull(TotHTdev,0),Rem1,Rem2,Rem3,TotPrixHT,Emplacement,
	   Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,'',0,0,0,0,0,0,'','','',0,'','',0,'','','',0,0,0,seqLib,comment_mag,cclcolisage,cclnbcolis,cclpack
from #Liste
where Qte > 0
order by LienCode,LienNum


/*pour les article en attente de transfert*/
 select  #Appro2.LIB, #Appro2.CCLQTE, #Appro2.STREQTE, #Appro2.STDEPOT,AREEMP, #Appro2.STEMPQTE,0 
 from #Appro2,VIEW_FARE 
 where ARTICLE*=AREAR
 and STDEPOT*=AREDEPOT
 and AREPICK=1
 
 
/*pour les articles qui n ont pas d emplacement*/
select   CCLARTICLE, VIEW_FAR.ARLIB,   AREEMP, ARESSEMP 
        from #ccl2,VIEW_FAR
        where ARCODE=CCLARTICLE
        and isnull(ARESSEMP,'')=''
        and ARTYPE=0



drop table #Prep
drop table #Articles
drop table #Stock
drop table #Liste

drop table #Appro
drop table #Appro2
drop table #ccl2
drop table #ccl
drop table #FCCL
drop table #LISTE_ARTICLE
drop table #FCC
drop table  #FRCC
drop table #FSTEMP
drop table #FSTOCK

drop table  #FRBP
drop table #StockTmp1



end
go

