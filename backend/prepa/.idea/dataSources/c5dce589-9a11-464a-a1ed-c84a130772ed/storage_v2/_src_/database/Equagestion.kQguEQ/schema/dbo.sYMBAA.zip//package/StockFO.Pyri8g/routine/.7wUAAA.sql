


create procedure StockFO (	@ent			char(5) = null,
							@date1			datetime = null,
						  	@date2			datetime = null,
						  	@depot1			char(4) = null,
						  	@depot2			char(4) = null,
						  	@article1		char(15) = null,
						  	@article2		char(15) = null,
						  	@famille1		char(8) = null,
						  	@famille2		char(8) = null,
						  	@marque1		char(12) = null,
						  	@marque2		char(12) = null,
						  	@emplace1		char(8) = null,
						  	@emplace2		char(8) = null,
						  	@numero			tinyint = null,
						  	@fournisseur1	char(12) = null,
						  	@fournisseur2	char(12) = null)
with recompile
as
begin

set arithabort numeric_truncation off

declare @modevalo 			tinyint,
		@date 				datetime,
		@article			char(15),
		@articleprecedent	char(15),
		@qte				int,
		@PrixRevient		numeric(14,4),
		@PrixRevientLigne	numeric(14,2),
		@seq				int

select @date=getdate()
select @modevalo=PMODEVALO from KParam
select @articleprecedent = ""

create table #Final
(
ARFAM			char(8)			not null,
ARCODE			char(15)		not null,
ARLIB			varchar(80)			null,
ARUNITACHAT		tinyint				null,
ARFO			char(12)		not null,
STLETTRE		char(4)			not	null,
STQTE			int				not null,
STDATEENTR		smalldatetime		null,
AREEMP			char(8)		 		null,
STPAHT			numeric(14,2)		null,
STNUMARM1		char(12)			null,
STNUMARM2		char(12)			null,
STDEPOT			char(4)			not null,
PALIGNE			numeric(14,2)		null,
PREVIENT		numeric(14,4)		null,
PRLIGNE			numeric(14,2)		null,
STFO			char(12)			null,
Seq				numeric(14,0)	identity)


declare st_curs cursor 
for select ARCODE,STQTE,Seq
from #Final
order by Seq
for read only


if @emplace1 is null
begin

 if @modevalo=0							/*--------------------- FIFO  */
  	begin
               	select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
               	STNUMARM1,STNUMARM2,STDEPOT,
               	PrixAchatLigne=(STPAHT/CVLOT)*STQTE,
               	PrixRevient=STPAHT+STFRAIS,
               	PrixRevientLigne=((STPAHT+STFRAIS)/CVLOT)*STQTE,STFO
               	from FAR,FSTOCK,FCV,FARE,FDP
               	where ARCODE=STAR
               	and ARUNITACHAT=CVUNIF
               	and ARCODE*=AREAR
               	and ARELIGNE=1
               	and (@date1 is null or STDATEENTR between @date1 and @date2)
               	and (@depot1 is null or STDEPOT between @depot1 and @depot2)
               	and (@article1 is null or ARCODE between @article1 and @article2)
               	and (@famille1 is null or ARFAM between @famille1 and @famille2)
               	and (@marque1 is null or ARFO between @marque1 and @marque2)
               	and (@fournisseur1 is null or STFO between @fournisseur1 and @fournisseur2)
               	and (@numero is null or ARNUMEROTE=1)
               	and STQTE!=0
               	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
               	order by STFO,ARFAM,ARCODE,STDEPOT
	end
	

 if @modevalo=1						/*--------------------- PRM  */
  	begin
               	select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
               	STNUMARM1,STNUMARM2,STDEPOT,
               	PrixAchatLigne=(STPAHT/CVLOT)*STQTE,
               	PrixRevient=ARPRM,
               	PrixRevientLigne=ARPRM*STQTE,STFO
               	from FAR,FSTOCK,FCV,FARE,FDP
               	where ARCODE=STAR
               	and ARUNITACHAT=CVUNIF
               	and ARCODE*=AREAR
               	and ARELIGNE=1
               	and (@date1 is null or STDATEENTR between @date1 and @date2)
               	and (@depot1 is null or STDEPOT between @depot1 and @depot2)
               	and (@article1 is null or ARCODE between @article1 and @article2)
               	and (@famille1 is null or ARFAM between @famille1 and @famille2)
               	and (@marque1 is null or ARFO between @marque1 and @marque2)
               	and (@fournisseur1 is null or STFO between @fournisseur1 and @fournisseur2)
               	and (@numero is null or ARNUMEROTE=1)
               	and STQTE!=0
               	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
               	order by STFO,ARFAM,ARCODE,STDEPOT
	end
	
if @modevalo in (2,3,4)	  					/*--------------------- PUMP/DPA/PRM Mensuel  */
  	begin
               	insert into #Final (ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
               	STNUMARM1,STNUMARM2,STDEPOT,PALIGNE,PREVIENT,PRLIGNE,STFO)
               	select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
               	STNUMARM1,STNUMARM2,STDEPOT,(STPAHT/CVLOT)*STQTE,0,0,STFO
               	from FAR,FSTOCK,FCV,FARE,FDP
               	where ARCODE=STAR
               	and ARUNITACHAT=CVUNIF
               	and ARCODE*=AREAR
               	and ARELIGNE=1
               	and (@date1 is null or STDATEENTR between @date1 and @date2)
               	and (@depot1 is null or STDEPOT between @depot1 and @depot2)
               	and (@article1 is null or ARCODE between @article1 and @article2)
               	and (@famille1 is null or ARFAM between @famille1 and @famille2)
               	and (@marque1 is null or ARFO between @marque1 and @marque2)
               	and (@fournisseur1 is null or STFO between @fournisseur1 and @fournisseur2)
               	and (@numero is null or ARNUMEROTE=1)
               	and STQTE!=0
               	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
               	order by STFO,ARFAM,ARCODE,STDEPOT
               	
               	create unique index seq on #Final (Seq)
		
		open st_curs
		
		fetch st_curs
		into @article,@qte,@seq
               	
               	
		while (@@sqlstatus = 0)
			begin
			
		  if @articleprecedent != @article
		  begin
			select 	@PrixRevient = 0
			
			if @modevalo = 2									/*--------------------- PUMP */
			begin
			  select @PrixRevient=isnull(PUMP,0)
			  from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			  
			end
			
			else if @modevalo = 3								/*--------------------- PRM Mensuel */
			
			begin
			  set rowcount 1
			  
			  select @PrixRevient=isnull(PRM,0)
			  from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
			
			else  if @modevalo = 4								/*--------------------- DPA unitaire */
			
			begin
			  set rowcount 1			
			
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			  from FBLL,FCV
			  where BLLAR=@article
			  and CVUNIF=BLLUA
			  having BLLAR=@article
			  and CVUNIF=BLLUA
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
			  if isnull(@PrixRevient,0)=0
			  begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
			  set rowcount 0
			  
			  if @PrixRevient is null
				select @PrixRevient = 0
	  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
		  end
		  else if @articleprecedent = @article
		  begin
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end


			update #Final set PREVIENT=@PrixRevient,PRLIGNE=@PrixRevientLigne
			where Seq = @seq
		
			select  @articleprecedent = @article
			
			fetch st_curs
			into @article,@qte,@seq
			
		end
                	
		close st_curs
		
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
		STNUMARM1,STNUMARM2,STDEPOT,PrixAchatLigne=PALIGNE,PrixRevient=PREVIENT,PrixRevientLigne=PRLIGNE,STFO
		from #Final
            	
            	
	end

	
	
end
else if @emplace1 is not null
begin

 if @modevalo=0							/*--------------------- FIFO  */
  	begin
	
          	select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
          	STNUMARM1,STNUMARM2,STDEPOT,
          	PrixAchatLigne=(STPAHT/CVLOT)*STQTE,
          	PrixRevient=STPAHT+STFRAIS,
          	PrixRevientLigne=((STPAHT+STFRAIS)/CVLOT)*STQTE,STFO
          	from FAR,FSTOCK,FCV,FARE,FDP
          	where ARCODE=STAR
          	and ARUNITACHAT=CVUNIF
          	and ARCODE=AREAR
          	and ARELIGNE=1
          	and AREEMP between @emplace1 and @emplace2
          	and (@date1 is null or STDATEENTR between @date1 and @date2)
          	and (@depot1 is null or STDEPOT between @depot1 and @depot2)
          	and (@article1 is null or ARCODE between @article1 and @article2)
          	and (@famille1 is null or ARFAM between @famille1 and @famille2)
          	and (@marque1 is null or ARFO between @marque1 and @marque2)
          	and (@fournisseur1 is null or STFO between @fournisseur1 and @fournisseur2)
          	and (@numero is null or ARNUMEROTE=1)
          	and STQTE!=0
          	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
          	order by AREEMP,ARCODE
	
	end
	

 if @modevalo=1							/*--------------------- PRM  */
  	begin
	
          	select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
          	STNUMARM1,STNUMARM2,STDEPOT,
          	PrixAchatLigne=(STPAHT/CVLOT)*STQTE,
          	PrixRevient=ARPRM,
          	PrixRevientLigne=ARPRM*STQTE,STFO
          	from FAR,FSTOCK,FCV,FARE,FDP
          	where ARCODE=STAR
          	and ARUNITACHAT=CVUNIF
          	and ARCODE=AREAR
          	and ARELIGNE=1
          	and AREEMP between @emplace1 and @emplace2
          	and (@date1 is null or STDATEENTR between @date1 and @date2)
          	and (@depot1 is null or STDEPOT between @depot1 and @depot2)
          	and (@article1 is null or ARCODE between @article1 and @article2)
          	and (@famille1 is null or ARFAM between @famille1 and @famille2)
          	and (@marque1 is null or ARFO between @marque1 and @marque2)
          	and (@fournisseur1 is null or STFO between @fournisseur1 and @fournisseur2)
          	and (@numero is null or ARNUMEROTE=1)
          	and STQTE!=0
          	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
          	order by AREEMP,ARCODE
	
	end
	
	
if @modevalo in (2,3,4)	  					/*--------------------- PUMP/DPA/PRM Mensuel  */
  	begin
               	insert into #Final (ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
               	STNUMARM1,STNUMARM2,STDEPOT,PALIGNE,PREVIENT,PRLIGNE,STFO)
               	select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
          	STNUMARM1,STNUMARM2,STDEPOT,(STPAHT/CVLOT)*STQTE,0,0,STFO
          	from FAR,FSTOCK,FCV,FARE,FDP
          	where ARCODE=STAR
          	and ARUNITACHAT=CVUNIF
          	and ARCODE=AREAR
          	and ARELIGNE=1
          	and AREEMP between @emplace1 and @emplace2
          	and (@date1 is null or STDATEENTR between @date1 and @date2)
          	and (@depot1 is null or STDEPOT between @depot1 and @depot2)
          	and (@article1 is null or ARCODE between @article1 and @article2)
          	and (@famille1 is null or ARFAM between @famille1 and @famille2)
          	and (@marque1 is null or ARFO between @marque1 and @marque2)
          	and (@fournisseur1 is null or STFO between @fournisseur1 and @fournisseur2)
          	and (@numero is null or ARNUMEROTE=1)
          	and STQTE!=0
          	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
          	order by AREEMP,ARCODE
               	
               	create unique index seq on #Final (Seq)
		
		open st_curs
		
		fetch st_curs
		into @article,@qte,@seq
               	
               	
		while (@@sqlstatus = 0)
			begin
			
		  if @articleprecedent != @article
		  begin
			select 	@PrixRevient = 0
			
			if @modevalo = 2									/*--------------------- PUMP */
			begin
			  select @PrixRevient=isnull(PUMP,0)
			  from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			  
			end
			
			else if @modevalo = 3								/*--------------------- PRM Mensuel */
			
			begin
			  set rowcount 1
			  
			  select @PrixRevient=isnull(PRM,0)
			  from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
			
			else  if @modevalo = 4								/*--------------------- DPA unitaire */
			
			begin
			  set rowcount 1			
			
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			  from FBLL,FCV
			  where BLLAR=@article
			  and CVUNIF=BLLUA
			  having BLLAR=@article
			  and CVUNIF=BLLUA
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
			  if isnull(@PrixRevient,0)=0
			  begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
			  set rowcount 0
			  
			  if @PrixRevient is null
				select @PrixRevient = 0
	  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
		  end
		  else if @articleprecedent = @article
		  begin
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end


			update #Final set PREVIENT=@PrixRevient,PRLIGNE=@PrixRevientLigne
			where Seq = @seq
		
			select  @articleprecedent = @article
			
			fetch st_curs
			into @article,@qte,@seq
			
		end
			
		close st_curs
		
		select ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARFO,STLETTRE,STQTE,STDATEENTR,AREEMP,STPAHT,
		STNUMARM1,STNUMARM2,STDEPOT,PrixAchatLigne=PALIGNE,PrixRevient=PREVIENT,PrixRevientLigne=PRLIGNE,STFO
		from #Final
            	
            	
	end	
	
end

drop table #Final	

end	



go

