


/* Procedure generant les lignes d''entree de mouvements de stock */

create procedure StockEntrees  (@Fournisseur	char(12)	= null,
								@Famille		char(8)	= null,
								@Article		char(15)	= null,
								@DuMois			tinyint	= null,
								@AuMois			tinyint	= null,
								@Annee			smallint = null,
								@Depot			tinyint = null)
with recompile
as
begin


select ARCODE,ARFO,ARFAM,ARLIB
into #FAR
from FAR
where (@Fournisseur is null or ARFO=@Fournisseur)
and (@Famille is null or ARFAM=@Famille)
and (@Article is null or ARCODE=@Article)

create unique clustered index code on #FAR(ARCODE)


/* Calcul des valeurs entree pendant la periode demandee (depuis FMS) */

select Article=MSARTICLE,
Quantite=sum(MSQTE),Valeur=sum(MSTOTPR)
into #Final
from FMS,#FAR
where ARCODE=MSARTICLE
and (@Depot is null or MSDEPOT=@Depot)
and MSANNEE=@Annee
and MSMOIS between @DuMois and @AuMois
and MSQTE!=0
and MSTYPE='E'
group by MSARTICLE


select Article,ARLIB,ARFO,FONOM,ARFAM,FPLIB,
Quantite,Cout_Total=Valeur,
Cout_Moyen=isnull(round(Valeur/Quantite,2),0),Depot=@Depot
from #Final,#FAR,FFP,FFO
where Article=ARCODE
and ARFAM=FPCODE
and ARFO=FOCODE
and Quantite!=0
order by ARFO,ARFAM,Article
compute sum(Quantite),sum(Valeur),sum(isnull(round(Valeur/Quantite,2),0))
	by ARFO,ARFAM
compute sum(Quantite),sum(Valeur),sum(isnull(round(Valeur/Quantite,2),0))
	by ARFO
compute sum(Quantite),sum(Valeur),sum(isnull(round(Valeur/Quantite,2),0))


 drop table #FAR
 drop table #Final
 
end



go

