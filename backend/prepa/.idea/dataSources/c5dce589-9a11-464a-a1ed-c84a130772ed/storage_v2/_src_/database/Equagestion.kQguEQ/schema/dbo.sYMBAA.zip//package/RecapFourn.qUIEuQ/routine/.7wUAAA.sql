


create procedure RecapFourn (@ent	char(5)	= null,
							 @date1	datetime,
							 @date2	datetime,
							 @fourn	char(12) = null)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Tab
	(
	Monnaie		char(3) 		not null,
	Fourn	 	char(12) 		not null,
	Livre		numeric(14,2)		null,
	CdeMois_	numeric(14,2)		null,
	CdeMois0	numeric(14,2)		null,
	CdeMois1	numeric(14,2)		null,
	CdeMois2	numeric(14,2)		null,
	CdeMois3	numeric(14,2)		null,
	CdeMois4	numeric(14,2)		null,
	CdeMois5	numeric(14,2)		null,
	CdeMois6	numeric(14,2)		null,
	CdeMois7	numeric(14,2)		null,
	CdeMois8	numeric(14,2)		null,
	CdeMois9	numeric(14,2)		null,
	CdeMois10	numeric(14,2)		null,
	CdeMois11	numeric(14,2)		null,
	CdeMois12	numeric(14,2)		null,
	CdeMois13	numeric(14,2)		null,
	CdeMois14	numeric(14,2)		null,
	CdeMois15	numeric(14,2)		null
	)
	
	declare @an		smallint,
			@mois	smallint
	
	
	/* Livraisons */
	
	insert into #Tab (Monnaie,Fourn,Livre)
	select BLDEVISE,BLFO,sum(BLTOTALHT)
	from FBL
	where BLDATE between @date1 and @date2
	and ((@fourn is null) or (BLFO=@fourn))
	and (@ent is null or BLENT=@ent)
	group by BLDEVISE,BLFO	
	
	insert into #Tab (Monnaie,Fourn,Livre)
	select RFDEVISE,RFFO,sum(-RFTOTALHT)
	from FRF
	where RFDATE between @date1 and @date2
	and ((@fourn is null) or (RFFO=@fourn))
	and (@ent is null or RFENT=@ent)
	group by RFDEVISE,RFFO
	
	
	/* Commandes */
	
	select 	@an   = datepart(yy,@date1),
			@mois = datepart(mm,@date1)
	
	/**** periode anterieure ****/
	
	insert into #Tab (Monnaie,Fourn,CdeMois_)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and ((datepart(yy,CFLDATEP) < @an) or (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) < @mois))
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois en cours ****/
	
	insert into #Tab (Monnaie,Fourn,CdeMois0)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 1 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	
	
	insert into #Tab (Monnaie,Fourn,CdeMois1)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	
	/**** mois + 2 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois2)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 3 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois3)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 4 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois4)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 5 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois5)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 6 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois6)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 7 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois7)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 8 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois8)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 9 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois9)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 10 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois10)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 11 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois11)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 12 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois12)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 13 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois13)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 14 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois14)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
	/**** mois + 15 ****/
		
	select @mois = @mois+1
	if @mois = 13 	select 	@an = @an+1, @mois = 1
	

	insert into #Tab (Monnaie,Fourn,CdeMois15)
	select CFLDEVISE,CFLFO,sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE)
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and (datepart(yy,CFLDATEP) = @an and datepart(mm,CFLDATEP) = @mois)
	and ((@fourn is null) or (RCFFO=@fourn))
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by CFLDEVISE,CFLFO
	having sum(round((CFLTOTALHT/CFLQTE),2)*CFLRESTE) != 0
	
		
	/* Resultat */
	
	select Monnaie,Fourn,sum(isnull(Livre,0)),sum(isnull(CdeMois_,0)),
			sum(isnull(CdeMois0,0)),sum(isnull(CdeMois1,0)),sum(isnull(CdeMois2,0)),
			sum(isnull(CdeMois3,0)),sum(isnull(CdeMois4,0)),sum(isnull(CdeMois5,0)),
			sum(isnull(CdeMois6,0)),sum(isnull(CdeMois7,0)),sum(isnull(CdeMois8,0)),
			sum(isnull(CdeMois9,0)),sum(isnull(CdeMois10,0)),sum(isnull(CdeMois11,0)),
			sum(isnull(CdeMois12,0)),sum(isnull(CdeMois13,0)),sum(isnull(CdeMois14,0)),
			sum(isnull(CdeMois15,0))
	from #Tab
	group by Monnaie,Fourn
	order by Monnaie,Fourn
	compute sum(sum(isnull(Livre,0))),sum(sum(isnull(CdeMois_,0))),
			sum(sum(isnull(CdeMois0,0))),sum(sum(isnull(CdeMois1,0))),
			sum(sum(isnull(CdeMois2,0))),sum(sum(isnull(CdeMois3,0))),
			sum(sum(isnull(CdeMois4,0))),sum(sum(isnull(CdeMois5,0))),
			sum(sum(isnull(CdeMois6,0))),sum(sum(isnull(CdeMois7,0))),
			sum(sum(isnull(CdeMois8,0))),sum(sum(isnull(CdeMois9,0))),
			sum(sum(isnull(CdeMois10,0))),sum(sum(isnull(CdeMois11,0))),
			sum(sum(isnull(CdeMois12,0))),sum(sum(isnull(CdeMois13,0))),
			sum(sum(isnull(CdeMois14,0))),sum(sum(isnull(CdeMois15,0))) by Monnaie
	compute sum(sum(isnull(Livre,0))),sum(sum(isnull(CdeMois_,0))),
			sum(sum(isnull(CdeMois0,0))),sum(sum(isnull(CdeMois1,0))),
			sum(sum(isnull(CdeMois2,0))),sum(sum(isnull(CdeMois3,0))),
			sum(sum(isnull(CdeMois4,0))),sum(sum(isnull(CdeMois5,0))),
			sum(sum(isnull(CdeMois6,0))),sum(sum(isnull(CdeMois7,0))),
			sum(sum(isnull(CdeMois8,0))),sum(sum(isnull(CdeMois9,0))),
			sum(sum(isnull(CdeMois10,0))),sum(sum(isnull(CdeMois11,0))),
			sum(sum(isnull(CdeMois12,0))),sum(sum(isnull(CdeMois13,0))),
			sum(sum(isnull(CdeMois14,0))),sum(sum(isnull(CdeMois15,0)))
			
	drop table #Tab
	
end



go

