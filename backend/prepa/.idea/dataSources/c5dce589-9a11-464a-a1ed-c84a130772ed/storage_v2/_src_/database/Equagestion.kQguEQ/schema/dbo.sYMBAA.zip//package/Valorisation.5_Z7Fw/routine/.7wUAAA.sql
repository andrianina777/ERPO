


create procedure Valorisation (	@ent	char(5)	= null,
								@Date 	smalldatetime = null)
with recompile
as
begin

	set arithabort numeric_truncation off


	select Famille=ARFAM,UnitAchat=ARUNITACHAT,STPAHT,STFRAIS,STQTE,
			TotalLigne=(STPAHT+STFRAIS)/CVLOT*STQTE
	into #Totaux
	from FAR,FSTOCK,FCV,FDP
	where STQTE > 0
	and (@Date is null or STDATEENTR<=@Date)
	and ARCODE=STAR
	and ARUNITACHAT=CVUNIF
	and ARTYPE=0
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))

	select Famille,TotalFamille=convert(numeric(14,2),sum(TotalLigne)),TotalQuantite=sum(STQTE)
	from #Totaux
	group by Famille
	
	select TotalGeneral=convert(numeric(14,2),sum(TotalLigne)) from #Totaux
	
	drop table #Totaux
	
end



go

