


/* Procedure utilisee pour l''enregistrement des stocks constates
	pour un mois et une annee donnes */

create procedure A_SKConst (@Annee		smallint,
							@Mois		tinyint,
							@datephoto	datetime = null,
							@codephoto	char(16) = null
						   )
with recompile
as
begin

declare @dif	int
select @dif=((@Annee-1992)*12)+@Mois

delete FSK
where SKDIF=@dif


declare @date1			datetime
declare @date2			datetime

declare @MoisPrecedent	tinyint
declare @AnneeInit		smallint


if @Mois=1
  begin
	select @MoisPrecedent=12
	select @AnneeInit=@Annee-1
  end
else
  begin
	select @MoisPrecedent=@Mois-1
	select @AnneeInit=@Annee
  end


select @date1=convert(datetime,convert(char(2),@MoisPrecedent)+"/01/"+convert(char(4),@AnneeInit))
select @date2=convert(datetime,convert(char(2),@Mois)+"/01/"+convert(char(4),@Annee))
select @date2=dateadd(dd,-1,@date2)


create table #StockPrec
(
ArticleP		char(15)		not null,
QteP			int					null
)

create table #Stock
(
ArticleS		char(15)	not null,
QteS			int				null
)

if @codephoto is null
begin
  
  /* ''Stock du mois precedent Fichier FSK'' */
  
  insert into #StockPrec (ArticleP, QteP)
  select SKARTICLE,isnull(SKQTE,0)
  from FSK
  where SKDIF=@dif - 1
  and SKARTICLE != "AJOUR"
  
  
  /* ''Stock initial - Fluctuations - Fichier SIL'' */
  
  insert into #StockPrec (ArticleP, QteP)
  select SILARTICLE,sum(isnull(SILQTE,0))
  from FSIL
  where SILDATE between @date1 and @date2
  group by SILARTICLE
  
  
  /* ''Reajustements - Fichier RJL'' */
  
  insert into #StockPrec (ArticleP, QteP)
  select RJLARTICLE,sum(isnull(RJLQTE,0))
  from FRJL
  where RJLDATE between @date1 and @date2
  group by RJLARTICLE
  
  
  /* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */
  
  insert into #StockPrec (ArticleP, QteP)
  select BLLAR,sum(isnull(BLLQTE,0))
  from FBLL
  where BLLDATE between @date1 and @date2
  group by BLLAR
  
  
  /* ''Sorties de douanes & entrees magasin - Fichier DOL'' */
  
  insert into #StockPrec (ArticleP, QteP)
  select DOLAR,sum(isnull(DOLQTE,0))
  from FDOL
  where DOLDATE between @date1 and @date2
  group by DOLAR
  
  
  /* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */
  
  insert into #StockPrec (ArticleP, QteP)
  select RFLARTICLE,-sum(isnull(RFLQTE,0))
  from FRFL
  where RFLDATE between @date1 and @date2
  group by RFLARTICLE
  
  
  /* ""Lignes de BE - Fichier FBEL"" */
  
  insert into #StockPrec (ArticleP, QteP)
  select BELARTICLE,-sum(isnull(BELQTE,0))
  from FBEL
  where BELDATE between @date1 and @date2
  and BELARTICLE != ""
  group by BELARTICLE
  
  
  /* Stock */
  
  
  insert into #Stock (ArticleS, QteS)
  select ArticleP,sum(QteP)
  from #StockPrec
  group by ArticleP
  order by ArticleP
  
  drop table #StockPrec
end
else if @codephoto is not null
begin

  /* Photo du Stock */
  
  
  insert into #Stock (ArticleS, QteS)
  select PSAR,sum(PSQTE)
  from FPS
  where PSDATE=@datephoto
  and PSCODE=@codephoto
  group by PSAR
  order by PSAR
end



insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
select @Annee,@Mois,ArticleS,isnull(QteS,0),((@Annee-1992)*12)+@Mois,getdate()
from #Stock


insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
		values (@Annee,@Mois,"AJOUR",0,((@Annee-1992)*12)+@Mois,getdate())


drop table #Stock

end



go

