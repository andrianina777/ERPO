/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_EmpSTOCK
grant execute on bp_EmpSTOCK to public
*/

CREATE PROCEDURE dbo.bp_EmpSTOCK(@dep char(4),@alle varchar(5)=null,@meuble char(2)=null)

AS
begin
		
        declare @article char(15),@empl char(8)
        
        
        create table #result(
			m_depot char(4),
			m_alle varchar(5),
			m_meuble char(2),
			m_empl char(8),
			m_article char(15) null,
			m_libelle varchar(200) null,
			m_lot char(12) null,
			m_lettre char(4) null,
			m_labo char(15) null,
			m_qte int null,
			m_moyen int null,
        )
        
        create table #PICK(
        	x_article char(15),
        	x_qte int,
        	x_lot char(12) null,
        	x_empl char(8) null,
        	x_lettre char(4) null,
        	x_seq int
        )

		insert into #result select xDEPOTL,xALLEL,xMEUBLEL,xEMPL,xARTICLE,ARLIB,STLOT,STLETTRE,ARFO, isnull(STEMPQTE,0),isnull(MOYENNE_VTE_RESTE_COLIS_MAJORE,0)  from xEMP_DIGUEL left
		join VIEW_STOCK_LOT_EMPLACEMENT on (STEMPEMP=xEMPL and STEMPDEPOT=xDEPOTL and STEMPAR=xARTICLE) left join DBSUIVI..x_MOYENNE_VTE_JOUR_DEPOT on ARCODE=STEMPAR and DEPOT=xDEPOTL
		where (@dep='' or @dep=null or xDEPOTL=@dep)  and (@alle='' or @alle=null or xALLEL=@alle) and
		(xMEUBLEL=@meuble or @meuble=null or @meuble='') and isnull(xACTIF,0)=0

		insert into #PICK
        select distinct RBPARTICLE,RBPQTE,m_lot,RBPEMP,RBPLETTRE,RBPSEQ from FRBP inner join FBPL on BPLSEQ=RBPSEQ inner join h_CCEnPrep on CEPBPCODE=BPLCODE inner join #result on  
        RBPARTICLE=m_article and RBPDEPOT=m_depot and RBPEMP=m_empl and  RBPLETTRE=m_lettre inner join xEMP_DIGUEL on xEMPL=RBPEMP and xDEPOTL=RBPDEPOT inner join xCorrespRAYON_DIGUE on 
        ALLEE=xALLEL and DEPOT=xDEPOTL and RAYON=CEPRAYON
        where isnull(CEPETAT,0)=2

		select m_depot as DEPOT,m_alle as ALLEE,m_meuble as MEUBLE,m_empl as EMPL,m_article as ARTILCE,m_libelle as LIBELLE,m_labo as LABO,m_lot as LOT,sum(m_qte) as Qte,sum(isnull(x_qte,0)) as Qte_Encours,m_moyen as VENTE_MOYENNE_JOUR from #result left join #PICK on x_article=m_article and x_lot=m_lot and x_empl=m_empl and x_lettre=m_lettre
		group by m_depot,m_alle,m_meuble,m_empl,m_article,m_libelle,m_lot,m_moyen
		
		drop table #result
		drop table #PICK


	
end
go

