



create procedure BELRep (@ent	char(5)	= null,
						 @rep	char(8))
with recompile
as
begin

declare @type		tinyint,
		@division	char(8)

select  @type=RETYPE, @division=REDIV
from FREP
where RECODE=@rep


create table #CL
(
CLCODE	char(12)	not null
)

if @type != 2
begin
  insert into #CL (CLCODE)
  select CLCODE
  from FCL
  where CLREP=@rep
  and (@ent is null or CLENT=@ent)
end
else if @type = 2
begin
  insert into #CL (CLCODE)
  select CLRCL
  from FCLR
  where CLRREPDIV=@rep
  and (@ent is null or CLRENT=@ent)
end

create unique clustered index code on #CL (CLCODE)


select BELSEQ,BELCODE,BELARTICLE,BELQTE,BELDATE,BELPRIXHT,BELLIBRE,
BELDEMO,BELLIENCODE,BELLIENNUM,BELCL,BELTOTALHT,BELREMISE1,BELREMISE2,BELREMISE3
from #CL,FRBE,FBEL,FAR
where BELSEQ=RBESEQ
and RBECL=CLCODE
and BELARTICLE=ARCODE
and (@type != 2 or ARDEPART=@division)
and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))

drop table #CL

end



go

