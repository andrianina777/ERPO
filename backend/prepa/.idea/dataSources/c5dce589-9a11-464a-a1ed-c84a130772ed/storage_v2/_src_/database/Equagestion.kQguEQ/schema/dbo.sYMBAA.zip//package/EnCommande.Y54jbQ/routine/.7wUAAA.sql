


create procedure EnCommande (@ent			char(5)	 = null,
							 @Fournisseur	char(12) = null)
with recompile
as
begin

create table #Final
(
Fournisseur	char(12)	not null,
RefFourn	char(20)		null,
Article		char(15)	not null,
Reference	varchar(80)		null,
Stock		int				null,
EnCommande	int				null,
ALivrer		int				null
)


insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
select ARFO,ARREFFOUR,ARCODE,ARLIB,0,0,0
from FAR
where (@Fournisseur is null or ARFO=@Fournisseur)



if (@Fournisseur is null)
begin

	insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
	select ARFO,ARREFFOUR,ARCODE,ARLIB,sum(STQTE),0,0
	from FSTOCK,FAR,FDP
	where ARCODE=STAR
	and STQTE > 0
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by ARFO,ARREFFOUR,ARCODE,ARLIB
	
	insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
	select ARFO,ARREFFOUR,ARCODE,ARLIB,0,sum(CFLRESTE),0
	from FRCF,FCFL,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by ARFO,ARREFFOUR,ARCODE,ARLIB
	
	insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
	select ARFO,ARREFFOUR,ARCODE,ARLIB,0,0,sum(CCLRESTE)
	from FRCC,FCCL,FAR,FCC
	where CCLSEQ=RCCSEQ
	and CCCODE=CCLCODE
	and isnull(CCVALIDE,0)=0
	and ARCODE=RCCARTICLE
	and CCLRESTE>0
	and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT))
	group by ARFO,ARREFFOUR,ARCODE,ARLIB

end
else
begin

	insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
	select ARFO,ARREFFOUR,ARCODE,ARLIB,sum(STQTE),0,0
	from FSTOCK,FAR,FDP
	where ARCODE=STAR
	and STQTE > 0
	and ARFO=@Fournisseur
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by ARFO,ARREFFOUR,ARCODE,ARLIB
	
	insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
	select ARFO,ARREFFOUR,ARCODE,ARLIB,0,sum(CFLRESTE),0
	from FRCF,FCFL,FAR
	where CFLSEQ=RCFSEQ
	and ARCODE=RCFARTICLE
	and ARFO=@Fournisseur
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	group by ARFO,ARREFFOUR,ARCODE,ARLIB
	
	insert into #Final (Fournisseur,RefFourn,Article,Reference,Stock,EnCommande,ALivrer)
	select ARFO,ARREFFOUR,ARCODE,ARLIB,0,0,sum(CCLRESTE)
	from FRCC,FCCL,FAR,FCC
	where CCLSEQ=RCCSEQ
	and CCCODE=CCLCODE
	and isnull(CCVALIDE,0)=0
	and ARCODE=RCCARTICLE
	and ARFO=@Fournisseur
	and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT))
	group by ARFO,ARREFFOUR,ARCODE,ARLIB
end

select 'Fournisseur','Reference Fournisseur','Code Societe',
'Reference Societe','Stock Societe','A Livrer/clients','En Commande/Fourn.',
'Stock Fournisseur','Delai approvisionnement','Qte minimum/cde'

select Fournisseur,RefFourn,Article,Reference,sum(Stock),sum(ALivrer),sum(EnCommande),'','',''
from #Final
group by Fournisseur,RefFourn,Article,Reference
order by Fournisseur,Article


end



go

