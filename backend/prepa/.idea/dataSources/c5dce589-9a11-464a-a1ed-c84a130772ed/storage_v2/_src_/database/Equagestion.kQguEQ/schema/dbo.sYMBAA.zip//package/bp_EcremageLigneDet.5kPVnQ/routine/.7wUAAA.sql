/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_EcremageLigneDet
grant execute on bp_EcremageLigneDet to public
*/

CREATE PROCEDURE bp_EcremageLigneDet(@pArticle char(15),@pDepot char(4),@pnbBoite int,@pNbEmp int)
with recompile
AS
begin

	declare @m_article char(15),@m_lot char(12),@lettre char(4),@m_qte int,@m_emplOrg char(8),@m_depotOrg char(4),@m_depotDest char(4)
	
	declare @x_emplDest char(8),@x_porte char(5),@x_article char(15),@x_lot char(12),@qte_stock int,@qteEncours int
	
	create table #EMPL(
		x_empl char(8),
		x_porte char(5) null,
		x_qte	int null,
		x_article char(15) null,
		x_lot char(12) null
	)
	
	create table #result(
		t_article char(15),
		t_lot	char(12) null,
		t_lettre	char(4),
		t_emplOrg	char(8),
		t_emplDst	char(8) null,
		t_depotOrg	char(4),
		t_depotDst	char(4),
		t_qte		int,
		t_porteDest	char(5) null
	)

	select STEMPAR, STEMPDEPOT, STEMPEMP, STLOT, NLOTDATEPER, STLETTRE, STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS,STFO, STEMPQTE, ARESSEMP, ST_UG,xARTP_FROID,xARTP_STATSPEC,ARLIB,
	(case when  xARTP_FROID=1 then 'FRD' when xARTP_STATSPEC<>0 then 'SPE' else 'DET' end) as DEPOT
    into #VIEW_STOCK_LOT_EMPLACEMENT
    from VIEW_STOCK_LOT_EMPLACEMENT   
    where  STEMPDEPOT=@pDepot
    and STEMPAR=@pArticle 
    
    delete from #VIEW_STOCK_LOT_EMPLACEMENT where ARESSEMP='DIGUE' or STEMPEMP in (select distinct PORTE from xCorrespRAYON_DIGUE where DEPOT=@pDepot)
    
    declare liste cursor for select STEMPAR,STEMPDEPOT, STEMPEMP, STLOT, STLETTRE,STEMPQTE,DEPOT from #VIEW_STOCK_LOT_EMPLACEMENT order by NLOTDATEPER
    open liste
    fetch liste into @m_article,@m_depotOrg,@m_emplOrg,@m_lot,@lettre,@m_qte,@m_depotDest
    while (@@sqlstatus=0)-- and (@pNbEmp>0)
        begin
        
      		truncate table #EMPL
    	
    		insert into #EMPL select distinct xEMPL,PORTE,isnull(STEMPQTE,0),isnull(xARTICLE,''),isnull(STLOT,'') from xEMP_DIGUEL  inner join xCorrespRAYON_DIGUE on (ALLEE=xALLEL and DEPOT=xDEPOTL)
	    	left join VIEW_STOCK_LOT_EMPLACEMENT on (STEMPAR=xARTICLE and STEMPDEPOT=xDEPOTL and STEMPEMP=xEMPL and STEMPQTE>0)
	    	where xARTICLE=@m_article and xDEPOTL=@m_depotDest
	    	order by xEMPL 
	    	
	    	delete from #EMPL where x_empl in (select distinct t_emplDst from #result where t_depotDst=@m_depotDest  and t_article=@pArticle  and 
    		t_qte>=@pnbBoite)
	    	or 
	    	(x_empl in (select distinct t_emplDst from #result where t_depotDst=@m_depotDest  and t_article=@m_article and t_lot<>@m_lot)) or (x_qte>=@pnbBoite)
	    	or (x_article=@m_article and x_lot=@m_lot and x_qte>=@pnbBoite )
	    		   
        	if((select count(*) from #EMPL)>0)
    		begin
    			declare liste_empl cursor for select x_empl,x_porte,isnull(x_article,''),isnull(x_lot,'') from #EMPL
	    		open liste_empl
				fetch liste_empl into @x_emplDest,@x_porte,@x_article,@x_lot
		        while (@@sqlstatus=0)-- and (@pNbEmp>0)
		        begin
		        	select @qte_stock=0	
		        	select @qteEncours=0
		        	select @qte_stock=sum(STEMPQTE) from VIEW_STOCK_LOT_EMPLACEMENT where STEMPDEPOT=@m_depotDest and STEMPAR=@m_article and STLOT=@m_lot and STEMPEMP=@x_emplDest group by STEMPDEPOT,STEMPAR,STEMPEMP,STLOT
		        	
		        	select @qteEncours=t_qte
		        	from #result where t_article=@m_article and t_lot=@m_lot and t_emplDst=@x_emplDest
		        	select @qte_stock=@qte_stock+@qteEncours
		        	if(@m_qte+@qte_stock<=@pnbBoite) and @m_qte>0 and (@x_article=@m_article or @x_article='') and (@m_lot=@x_lot or @x_lot='')
		        	begin
		        	
						insert into #result values(@m_article,@m_lot,@lettre,@m_emplOrg,@x_emplDest,@m_depotOrg,@m_depotDest,@m_qte,@x_porte)
						select @m_qte=0
		        	end
		        	else
		        	begin
		        		
		        		if(@m_qte>0) and (@m_article=@x_article or @x_article='') and (@m_lot=@x_lot or @x_lot='') and (@pnbBoite-@qte_stock)>0
		        		begin
		        			insert into #result values(@m_article,@m_lot,@lettre,@m_emplOrg,@x_emplDest,@m_depotOrg,@m_depotDest,@pnbBoite-@qte_stock,@x_porte)	
							select @m_qte=@m_qte+@qte_stock-@pnbBoite	
							select @qte_stock=0
						end
						
		        	end
		        	
		        	--select @pNbEmp=@pNbEmp-1
		        	
	          		fetch liste_empl into @x_emplDest,@x_porte,@x_article,@x_lot
		        end
	         	close liste_empl
	   			deallocate cursor liste_empl
	        
	        
	        	while(@m_qte>0)-- and (@pNbEmp>0)
        		begin
        			if(@m_qte<=@pnbBoite)
        			begin
        				insert into #result values(@m_article,@m_lot,@lettre,@m_emplOrg,'DIGUE',@m_depotOrg,@m_depotDest,@m_qte,'DIGUE')
        				select @m_qte=0
        			end
	        		else
        			begin
        				insert into #result values(@m_article,@m_lot,@lettre,@m_emplOrg,'DIGUE',@m_depotOrg,@m_depotDest,@pnbBoite,'DIGUE')
        				select @m_qte=@m_qte-@pnbBoite
        			end
        			--select @pNbEmp=@pNbEmp-1
        	  	end
         
         	end
         	else
         	begin
         		while(@m_qte>0)-- and (@pNbEmp>0)
        		begin
        			if(@m_qte<=@pnbBoite)
        			begin
        				insert into #result values(@m_article,@m_lot,@lettre,@m_emplOrg,'DIGUE',@m_depotOrg,@m_depotDest,@m_qte,'DIGUE')
        				select @m_qte=0
        			end
	        		else
        			begin
        				insert into #result values(@m_article,@m_lot,@lettre,@m_emplOrg,'DIGUE',@m_depotOrg,@m_depotDest,@pnbBoite,'DIGUE')
        				select @m_qte=@m_qte-@pnbBoite
        			end
        			--select @pNbEmp=@pNbEmp-1
        	  	end
         	end
         	
         fetch liste into @m_article,@m_depotOrg,@m_emplOrg,@m_lot,@lettre,@m_qte,@m_depotDest
         
     	end
       close liste
       deallocate cursor liste
      
	  select t_article,ARLIB,t_depotOrg,t_lot,NLOTDATEPER,t_lettre,t_emplOrg,t_emplDst,t_porteDest,t_qte,t_depotDst,STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS,STFO,ST_UG from #result
	  inner join #VIEW_STOCK_LOT_EMPLACEMENT on (STEMPAR=t_article and t_lot=STLOT and t_lettre=STLETTRE and t_emplOrg=STEMPEMP and t_depotOrg=STEMPDEPOT) order by (case when t_emplDst='DIGUE' then 1 else 0 end),t_article,t_lot,t_qte desc,t_lettre,t_emplOrg
     drop table #EMPL
     drop table #result
     drop table #VIEW_STOCK_LOT_EMPLACEMENT
	 	
end
go

