


create procedure MAJCL (@ent	char(5)	= null,
						@rep	char(8)				/* VRP general */
					   )
with recompile
as
begin
  create table #dep
  (
  dep	char(4)	not null
  )
	insert into #dep (dep)
	select SEDEP
	from FSECT, FREP
	where SECODE=RESECTEUR
	and RECODE=@rep
	and (@ent is null or (REPENT=@ent and SEENT=REPENT))
	order by SEDEP
	
	declare @secteur	char(8)
	
	select @secteur=RESECTEUR from FREP
	where RECODE=@rep
	
	
	update FCL
	set CLREP=@rep,CLSECT=@secteur
	where exists (select * from #dep 
	  where dep=substring(FCL.CLCP,1,2))
	and (@ent is null or CLENT=@ent)
	drop table #dep
end



go

