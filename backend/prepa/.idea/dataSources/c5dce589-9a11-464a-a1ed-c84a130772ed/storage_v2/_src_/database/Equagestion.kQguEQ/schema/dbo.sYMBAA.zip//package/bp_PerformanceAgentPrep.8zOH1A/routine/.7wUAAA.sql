
/*
DROP PROCEDURE dbo.bp_PerformanceAgentPrep
*/


CREATE PROCEDURE dbo.bp_PerformanceAgentPrep (@annee int,@mois int)


AS
begin
			
			declare @x_code char(10),
					@x_emp   char(10),
					@x_nbLigne int,
					@x_nbAr int
					
			create table #prep(
                agent char(10),
                rayon char(10),
                codeBP char(10),
                date  char(15),
                nbCC	int
        	)
        	
        	create table #xFBPL(
                code char(10),
                dateBP char(15),
                emp char(10),
                nbLig int,
                nbAr int

        	)
        	
        insert into #prep select distinct CEPUSER,CEPRAYON,CEPBPCODE,CONVERT(CHAR,CEPDATEDEB,101),count(CEPBPCODE) from h_CCEnPrep where year(CEPDATEDEB)=@annee and month(CEPDATEDEB)=@mois and CEPETAT=2 AND ISNULL(CEPUSER,'')<>''
		and CEPRAYON in (SELECT DISTINCT xEmp FROM xEMP WHERE xDepot='DET')	group by CEPUSER,CEPRAYON,CONVERT(CHAR,CEPDATEDEB,101)
		
		insert into #xFBPL select distinct BPLCODE,CONVERT(CHAR,BPLDATE,101),BPLEMP,count(*) as nbLigne,sum(BPLQTE) as nbArticle from FBPL 
        where year(BPLDATE)=@annee and month(BPLDATE)=@mois and BPLEMP in (SELECT DISTINCT xEmp FROM xEMP WHERE xDepot='DET')
	    and BPLDEPOT='DET'group by BPLCODE,BPLEMP,CONVERT(CHAR,BPLDATE,101)
	    
	    select distinct agent,rayon,date,nbCC as nbCC,sum(nbLig) as nbLigne,sum(nbAr) as nbArticle from #prep inner join #xFBPL on (codeBP=code and rayon=emp) group by agent,rayon,date
	    order by agent,rayon,date
		
		
	    
	    drop table #prep,#xFBPL
end




go

