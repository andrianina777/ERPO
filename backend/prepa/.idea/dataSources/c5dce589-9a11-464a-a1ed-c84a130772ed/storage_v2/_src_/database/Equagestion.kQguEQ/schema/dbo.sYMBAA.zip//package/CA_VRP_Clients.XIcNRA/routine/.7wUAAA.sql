


create procedure CA_VRP_Clients (@ent		char(5)	= null,
								 @rep 		char(8),		/* VRP general */
								 @an 		int,
								 @moisde 	tinyint,
								 @moisa 	tinyint)
with recompile
as
begin

set arithabort numeric_truncation off


create table #CA
(
STCL	char(12)		not null,
CAN2	numeric(14,2)	not null,
CAN1	numeric(14,2)	not null,
CAN		numeric(14,2)	not null,
CACC	numeric(14,2)	not null,
CAENT	char(5)				null
)


insert into #CA (STCL,CAN2,CAN1,CAN,CACC,CAENT)
select STCL,isnull(sum(case when STAN=@an-2 then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an-1 then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an then STCAFA else 0 end),0),
			0.00,STENT
from FST,FCL
where CLCODE=STCL
and CLREP=@rep
and STAN between @an-2 and @an
and STMOIS between @moisde and @moisa
and (@ent is null or (STENT=@ent and CLENT=STENT))
group by STCL,STENT


insert into #CA (STCL,CAN2,CAN1,CAN,CACC,CAENT)
select CACL,0.00,0.00,0.00,isnull(sum(CACC),0),CAREPENT
from FCAREP
where CAREP=@rep
and CAAN = @an
and CAMOIS = @moisa
and (@ent is null or CAREPENT=@ent)
group by CACL,CAREPENT

create index client on #CA (STCL,CAENT)


select CP=substring(isnull(CLCP,''),1,2),CODE=CLCODE,NOM=CLNOM1,VILLE=CLVILLE,
		CA_AN_2=sum(CAN2),CA_AN_1=sum(CAN1),CA_AN=sum(CAN),CA_CDE=sum(CACC),Agence=CAENT
from FCL,#CA
where CLCODE=STCL
and (@ent is null or CLENT=CAENT)
and (CAN2!=0 or CAN1!=0 or CAN!=0 or CACC!=0)
group by substring(isnull(CLCP,''),1,2),CLCODE,CLNOM1,CLVILLE,CAENT
order by substring(isnull(CLCP,''),1,2),CLCODE,CAENT

drop table #CA

end



go

