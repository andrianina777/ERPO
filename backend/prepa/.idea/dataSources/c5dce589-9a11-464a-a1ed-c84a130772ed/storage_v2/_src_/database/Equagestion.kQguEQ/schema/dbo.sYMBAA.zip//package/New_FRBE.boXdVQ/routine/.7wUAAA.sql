


/* Procedure permettant de recreer le fichier des ''reste a facturer'' clients */

create procedure New_FRBE
with recompile
as
begin

	truncate table FRBE
	
	insert into FRBE (RBESEQ,RBEARTICLE,RBEDATE,RBEQTE,RBECL,RBEDEMO,RBEECH,RBEFACTMAN,RBESTADE,RBEENT)
	select BELSEQ,BELARTICLE,BELDATE,BELRESTE,BELCL,isnull(BEDEMO,0),isnull(BELECHSPE,0),
			isnull(BELFACTMAN,0),isnull(BELSTADE,0),BELENT
	from FBEL,FBE
	where BELCODE=BECODE
	and BELRESTE > 0
	
end



go

