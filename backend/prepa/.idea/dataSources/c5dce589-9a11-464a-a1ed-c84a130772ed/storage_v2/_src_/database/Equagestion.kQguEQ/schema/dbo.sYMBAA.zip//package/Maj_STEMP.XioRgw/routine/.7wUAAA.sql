




create procedure Maj_STEMP
with recompile
as
begin

create table #emp
(
emp		char(8)			not null,
seq		numeric(14,0)	identity
)


declare stock cursor 
for select STAR,STLETTRE,STDEPOT,STQTE,STDATEENTR,isnull(STLOT,""),STID
from FSTOCK
order by STID
for read only


declare @article	char(15),
		@lettre		char(4),
		@depot		char(4),
		@qte		int,
		@dateentr	smalldatetime,
		@lot		char(12),
		@seq		numeric(14,0),
		@emp		char(8),
		@typedepot	tinyint,			/* 0 = douanes, 1 = expeditions, 2 = autres) */
		@maxligne	int,
		@newseq		int
		

declare @user	int
select 	@user=user_id()


   open stock
   
   fetch stock
   into @article,@lettre,@depot,@qte,@dateentr,@lot,@seq
		   
		   
   while (@@sqlstatus = 0)
	begin
	
		select @emp = ""
		
		select @typedepot = DPLOC
		from FDP
		where DPCODE = @depot
		
		if @typedepot != 1			/* le depot n''est pas un depot d''expedition */
		begin
		
			delete from #emp
			
			insert into #emp (emp)
			select AREEMP
			from FARE
			where AREAR = @article
			and AREDEPOT = @depot
		
			if @@rowcount > 0
			begin
				select @emp = emp
				from #emp
				having seq = min(seq)
			end
			else
			begin
				select @emp = "0000"
			
				select @maxligne = max(ARELIGNE)
				from FARE
				where AREAR = @article
				
				execute eq_GetSeq_proc "FARE",1,@newseq output
				
				insert into FARE (ARESEQ,AREEMP,AREAR,ARELIGNE,AREDEPOT,AREPICK,ARERECEP)
				values (@newseq,@emp,@article,@maxligne + 1,@depot,0,0)
			end
		end
		else if @typedepot = 1			/* le depot est un depot d''expedition */
		begin
			
			delete from #emp
			
			insert into #emp (emp)
			select AREEMP
			from FARE
			where AREAR = @article
			and AREDEPOT = @depot
			and AREPICK = 1
			
			if @@rowcount > 0
			begin
				select @emp = emp
				from #emp
				having seq = min(seq)
			end
			else
			begin
				insert into #emp (emp)
				select AREEMP
				from FARE
				where AREAR = @article
				and AREDEPOT = @depot
			
				if @@rowcount > 0
				begin
					select @emp = emp
					from #emp
					having seq = min(seq)
				end
				else
				begin
					select @emp = "0000"
				
					select @maxligne = max(ARELIGNE)
					from FARE
					where AREAR = @article
					
					execute eq_GetSeq_proc "FARE",1,@newseq output
					
					insert into FARE (ARESEQ,AREEMP,AREAR,ARELIGNE,AREDEPOT,AREPICK,ARERECEP)
					values (@newseq,@emp,@article,@maxligne + 1,@depot,0,0)
				end
	   		end
		end
		
		insert into FSTEMP (STEMPAR,STEMPLETTRE,STEMPDEPOT,STEMPEMP,STEMPQTE,STEMPDATE,STEMPLOT,
						   STEMPUSERCRE,STEMPDATECRE,STEMPUSERMDF,STEMPDATEMDF)
		values (@article,@lettre,@depot,@emp,@qte,@dateentr,@lot,
	  			@user,getdate(),@user,getdate())
   

		fetch stock
		into @article,@lettre,@depot,@qte,@dateentr,@lot,@seq
	   
	end
			   
   close stock
   deallocate cursor stock
   
   drop table #emp

end



go

