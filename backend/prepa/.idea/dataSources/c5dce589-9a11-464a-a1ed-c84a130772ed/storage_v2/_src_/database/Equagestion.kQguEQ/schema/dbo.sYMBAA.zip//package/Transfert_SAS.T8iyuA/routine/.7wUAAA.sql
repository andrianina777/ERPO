/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.Transfert_SAS
GRANT EXECUTE ON  dbo.Transfert_SAS To public
*/

CREATE PROCEDURE dbo.Transfert_SAS (
                            @depotdepart	char(4), 
							@depotarrivee	char(4), 
							@datevalide		datetime, 
							@article		char(15), 
							@numarm1		char(12), 
							@numarm2		char(12), 
							@fourn			char(12), 
							@devise			char(4), 
							@padev			numeric(14,3), 
							@paht			numeric(14,3), 
							@frais			numeric(14,3), 
							@silqte			int, 
							@code			char(10), 
							@comment		char(255), 
							@lettredepart	char(4), 
							@empdepart      char(8), 
							@emparrivee     char(8), 
							@numlot         char(12),
							@sil_ug			int		
								 
						   ) 
with recompile 
as 
begin 
 
set arithabort numeric_truncation off 
 
declare @user		int, 
		@numdep		int, 
		@numdep2	int, 
		@an			int, 
		@mois		int, 
		@jour		int, 
        @seq		int ,
	    @nb         int,
	    @numLigne   int
		 
select @user=user_id() 
select @numdep=DPLOC from FDP where DPCODE=@depotarrivee 
select @numdep2=DPLOC from FDP where DPCODE=@depotdepart 
select @an=datepart(yy,getdate())*10000 
select @mois=datepart(mm,getdate())*100 
select @jour=datepart(dd,getdate()) 
select @datevalide=getdate()		 	 	 
 
/***** Sortie de l''''''''ancien depot ******/		 
	 
exec eq_GetSeq_proc 'FSIL', 1, @seq output 
insert into FSIL (SILSEQ,SILARTICLE,SILQTE,SILDATE,SILNUMARM1,SILNUMARM2,SILDEPOT, 
			    SILPADEV,SILPAHT,SILCOMMENT,SILDEVISE,SILLETTRE,SILFRAIS,SILNUMDEP, 
				SILTYPEMV,SILCODE,SILFO,SILLOT,SILEMP,
				SIL_UG) 
values (@seq,@article,-@silqte,@datevalide,@numarm1,@numarm2,@depotdepart, 
	  		    @padev,@paht,isnull(@comment,''),@devise,@lettredepart,@frais,@numdep2, 
			    'TS',@code,@fourn,@numlot,@empdepart,
			    isnull(@sil_ug,0)) 
			   
/***** Transfert vers le nouveau depot - nota : creation code lettre dans trigger FSIL ******/ 
	 
exec eq_GetSeq_proc 'FSIL', 1, @seq output 
insert into FSIL (SILSEQ,SILARTICLE,SILQTE,SILDATE,SILNUMARM1,SILNUMARM2,SILDEPOT, 
					  SILPADEV,SILPAHT,SILCOMMENT,SILDEVISE,SILLETTRE,SILFRAIS,SILNUMDEP, 
					  SILTYPEMV,SILCODE,SILFO,SILLOT,SILEMP,
					  SIL_UG) 
values (@seq,@article,@silqte,@datevalide,@numarm1,@numarm2,@depotarrivee, 
			  @padev,@paht,isnull(@comment,''),@devise,'',@frais,@numdep, 
			  'TS',@code,@fourn,@numlot,@emparrivee,

			  isnull(@sil_ug,0)) 

/*insert Emplcement dans FARE s' il n'existe*/
 select @nb=0
 select @numLigne=0
  select @nb=count(*) from FARE where  AREAR=@article and AREDEPOT=@depotarrivee and  AREEMP=@emparrivee
 if(@nb=0)
  begin
     exec eq_GetSeq_proc "FARE", 1, @seq output 
     select @numLigne=max(ARELIGNE) from FARE where  AREAR=@article
     insert into FARE (ARESEQ,AREEMP,AREAR,ARELIGNE,AREDEPOT,AREPICK,ARERECEP,ARESSEMP,AREVALID) values (@seq,@emparrivee,@article,@numLigne+1,@depotarrivee,0,0,'',1)
  end
 else
 begin
    update FARE set AREVALID=1 where  AREAR=@article and AREDEPOT=@depotarrivee and  AREEMP=@emparrivee 
 end
 

end

go

