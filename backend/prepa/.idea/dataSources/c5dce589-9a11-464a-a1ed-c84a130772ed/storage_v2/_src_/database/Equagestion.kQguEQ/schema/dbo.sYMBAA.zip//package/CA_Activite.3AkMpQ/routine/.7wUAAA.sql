


create procedure CA_Activite (	@ent		char(5) = null,
								@annee		smallint,
							  	@activite	char(6) = null,
							  	@mois1		tinyint = null,
							  	@mois2		tinyint = null,
							  	@tri		tinyint,
							  	@clold		tinyint,
							  	@srfa		tinyint = 0,
							  	@division	char(8) = null
								)
with recompile
as
begin

  set arithabort numeric_truncation off


  if @mois2 is null
  select @mois2=@mois1

  declare @Mois		tinyint

  select @Mois=datepart(mm,getdate())
  
   create table #CA
   (
   VRP			char(8)			not	null,
   Client		char(12)		not null,
   CA_AN_1		numeric(14,2)		null,
   CA_AN_1P		numeric(14,2)		null,
   CA_AN		numeric(14,2)		null,
   )
   
   create index cl on #CA (Client)
   
   create table #Clients
   (
   CLCODE		char(12) 		not null,
   CLSA			char(6)			not null,
   CLNOM1		varchar(35)		not null,
   MRLIB		char(12)			null,
   CLREP		char(8) 		not null,
   RENOM		varchar(25)		not null
   )
   
 if @tri = 3 
   begin
	   insert into #Clients (CLCODE,CLSA,CLNOM1,MRLIB,CLREP,RENOM)
	   select CLCODE,isnull(CLSA,''),CLNOM1,MRLIB,isnull(CLRREPDIV,''),isnull(RENOM,'')
	   from FCL,FTR,FMR,FREP,FCLR
	   where CLMODEREG = TRCODE
	   and MRCODE = TRMODE
	   and RECODE=CLRREPDIV
	   and CLRCL=CLCODE
	   and (@clold=1 or CLSTATUS=0)
	   and (@ent is null or CLENT=@ent)
	   and (@activite is null or CLSA=@activite)
   end
 else  if @tri != 3 
   begin
	   insert into #Clients (CLCODE,CLSA,CLNOM1,MRLIB,CLREP,RENOM)
	   select CLCODE,isnull(CLSA,''),CLNOM1,MRLIB,isnull(CLREP,''),isnull(RENOM,'')
	   from FCL,FTR,FMR,FREP
	   where CLMODEREG = TRCODE
	   and MRCODE = TRMODE
	   and RECODE=CLREP
	   and (@clold=1 or CLSTATUS=0)
	   and (@ent is null or CLENT=@ent)
	   and (@activite is null or CLSA=@activite)
   end
   
   insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
   select CLREP,CLCODE,0.00,0.00,0.00
   from #Clients

if @tri != 3
begin	  
          
          /* AN - 1 complet */
          
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select (case when STREP is null then CLREP else STREP end),CLCODE,isnull(sum(STCAFA),0),0,0
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STAN=@annee-1
        	and (@ent is null or STENT=@ent)
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	group by (case when STREP is null then CLREP else STREP end),CLCODE
          
          /* AN - 1 partiel */
          
          if @mois1 is null
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select (case when STREP is null then CLREP else STREP end),CLCODE,0,isnull(sum(STCAFA),0),0
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STAN=@annee-1
        	and STMOIS between 1 and @Mois
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by (case when STREP is null then CLREP else STREP end),CLCODE
          end
          else
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select (case when STREP is null then CLREP else STREP end),CLCODE,0,isnull(sum(STCAFA),0),0
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STAN=@annee-1
        	and STMOIS between @mois1 and @mois2
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by (case when STREP is null then CLREP else STREP end),CLCODE
          end
          
          /* AN en cours partiel */
          
          if @mois1 is null
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select (case when STREP is null then CLREP else STREP end),CLCODE,0,0,isnull(sum(STCAFA),0)
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STAN=@annee
        	and STMOIS between 1 and @Mois
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by (case when STREP is null then CLREP else STREP end),CLCODE
          end
          else
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select (case when STREP is null then CLREP else STREP end),CLCODE,0,0,isnull(sum(STCAFA),0)
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STAN=@annee
        	and STMOIS between @mois1 and @mois2
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by (case when STREP is null then CLREP else STREP end),CLCODE
          end
 end
 else if @tri=3	 /* Representant division */
 begin
          /* AN - 1 complet */
          
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select isnull(STREPDIV,""),CLCODE,isnull(sum(STCAFA),0),0,0
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STREPDIV=CLREP
        	and STAN=@annee-1
        	and (@ent is null or STENT=@ent)
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	group by STREPDIV,CLCODE
          
          /* AN - 1 partiel */
          
          if @mois1 is null
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select isnull(STREPDIV,""),CLCODE,0,isnull(sum(STCAFA),0),0
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STREPDIV=CLREP
        	and STAN=@annee-1
        	and STMOIS between 1 and @Mois
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
          	group by STREPDIV,CLCODE    	
          end
          else
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select isnull(STREPDIV,""),CLCODE,0,isnull(sum(STCAFA),0),0
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STREPDIV=CLREP
        	and STAN=@annee-1
        	and STMOIS between @mois1 and @mois2
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by STREPDIV,CLCODE
          end
          
          /* AN en cours partiel */
          
          if @mois1 is null
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select isnull(STREPDIV,""),CLCODE,0,0,isnull(sum(STCAFA),0)
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STREPDIV=CLREP
        	and STAN=@annee
        	and STMOIS between 1 and @Mois
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by STREPDIV,CLCODE
          end
          else
          begin
        	insert into #CA (VRP,Client,CA_AN_1,CA_AN_1P,CA_AN)
        	select isnull(STREPDIV,""),CLCODE,0,0,isnull(sum(STCAFA),0)
        	from FST,FAR,#Clients
        	where CLCODE=STCL
        	and ARCODE=START
        	and STREPDIV=CLREP
        	and STAN=@annee
        	and STMOIS between @mois1 and @mois2
        	and (@srfa=0 or ARTYPE != 6)	
        	and (@division is null or ARDEPART=@division)
        	and (@ent is null or STENT=@ent)
        	group by STREPDIV,CLCODE
          end
 
  
 end 
  
  
  
  
  /* select final */
  
  if (@tri = 0)
  begin
	select CLSA,CLCODE,CLNOM1,MRLIB,'','',isnull(sum(CA_AN_1),0),isnull(sum(CA_AN_1P),0),
									isnull(sum(CA_AN),0),isnull((sum(CA_AN)-sum(CA_AN_1P)),0)
	from #CA,#Clients
	where CLCODE = Client
	group by CLSA,CLCODE,CLNOM1,MRLIB
	order by CLSA,CLCODE
  end
  else if (@tri = 1)
   begin
	select CLSA,CLCODE,CLNOM1,MRLIB,'','',isnull(sum(CA_AN_1),0),isnull(sum(CA_AN_1P),0),
									isnull(sum(CA_AN),0),isnull((sum(CA_AN)-sum(CA_AN_1P)),0)
	from #CA,#Clients
	where CLCODE = Client
	group by CLSA,CLCODE,CLNOM1,MRLIB
	order by MRLIB,CLCODE
   end
  else if (@tri = 2 or @tri = 3)
   begin
	select CLSA,CLCODE,CLNOM1,MRLIB,VRP,RENOM,isnull(sum(CA_AN_1),0),isnull(sum(CA_AN_1P),0),
									isnull(sum(CA_AN),0),isnull((sum(CA_AN)-sum(CA_AN_1P)),0)
	from #CA,#Clients
	where CLCODE = Client
	and CLREP=VRP
	group by CLSA,CLCODE,CLNOM1,MRLIB,VRP,RENOM
	order by VRP,MRLIB,CLCODE
   end

  drop table #CA
  drop table #Clients
	
end



go

