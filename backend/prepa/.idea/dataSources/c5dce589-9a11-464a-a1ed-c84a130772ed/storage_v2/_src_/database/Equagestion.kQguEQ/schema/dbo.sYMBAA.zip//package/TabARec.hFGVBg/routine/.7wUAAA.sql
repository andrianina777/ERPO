


create procedure TabARec (@ent		char(5)	 = null,
						  @an		smallint = null,
						  @fourn	char(12) = null,
						  @depart	char(8) = null)
with recompile
as
begin

	create table #liste
	(	fourn		char(12)	not null,
		depart		char(8)		not null,
		codeart 	char(15) 	not null,
		janvier 	int 		null,
		fevrier 	int 		null,
		mars 		int 		null,
		avril 		int 		null,
		mai 		int 		null,
		juin 		int 		null,
		juillet 	int 		null,
		aout 		int 		null,
		septembre 	int 		null,
		octobre 	int 		null,
		novembre 	int 		null,
		decembre 	int 		null,
		total		int			null
	)	

	create index article on #liste(codeart)
	
	create table #Cde
	(
	Fourn		char(12)	not null,
	Depart		char(8)		not null,
	Article 	char(15) 	not null,
	Qte			int			null,
	Date		datetime	null,
	DateCde		datetime	null
	)
	
	
	/* Commandes */
	
	insert into #Cde
	select CFLFO,isnull(ARDEPART,""),CFLARTICLE,CFLRESTE,CFLDATEP,CFLDATE
	from FCFL,FRCF,FAR
	where CFLSEQ=RCFSEQ
	and (@fourn is null or RCFFO=@fourn)
	and ARCODE=CFLARTICLE
	and (@depart is null or ARDEPART=@depart)
	and (@an is null or datepart(yy,RCFDATE)=@an)
	and (@ent is null or RCFENT=@ent)
	
	update #Cde
	set Date=DateCde
	where Date is null
	
	insert into #liste (fourn,depart,codeart)
	select Fourn,Depart,Article
	from #Cde
	group by Fourn,Depart,Article


		update #liste
		set janvier= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=1
					 group by Article)
					 
		update #liste
		set fevrier= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=2
					 group by Article)
		
		update #liste
		set mars= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=3
					 group by Article)

		update #liste
		set avril= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=4
					 group by Article)
			
		update #liste
		set mai= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=5
					 group by Article)

		update #liste
		set juin= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=6
					 group by Article)
		
		update #liste
		set juillet= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=7
					 group by Article)

		update #liste
		set aout= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=8
					 group by Article)
		
		update #liste
		set septembre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=9
					 group by Article)

		update #liste
		set octobre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=10
					 group by Article)

		update #liste
		set novembre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=11
					 group by Article)

		update #liste
		set decembre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=12
					 group by Article)

		drop table #Cde


		update #liste
		set total=isnull(janvier,0)+isnull(fevrier,0)+isnull(mars,0)
		+isnull(avril,0)+isnull(mai,0)+isnull(juin,0)
		+isnull(juillet,0)+isnull(aout,0)+isnull(septembre,0)
		+isnull(octobre,0)+isnull(novembre,0)+isnull(decembre,0)

/*		select ''Reste a recevoir ''+convert(char(4),@an), @fourn  */
			

		select FO=fourn,Departement=depart,REF=codeart,DESIGNATION=ARLIB,
		JANV=isnull(janvier,0),FEVR=isnull(fevrier,0),MARS=isnull(mars,0),
		AVRIL=isnull(avril,0),MAI=isnull(mai,0),JUIN=isnull(juin,0),
		JUIL=isnull(juillet,0),AOUT=isnull(aout,0),SEPT=isnull(septembre,0),
		OCTO=isnull(octobre,0),NOV=isnull(novembre,0),DEC=isnull(decembre,0),
		TOTAL=isnull(total,0)
		from #liste,FAR
		where ARCODE=codeart
		order by fourn,depart,codeart
		compute sum(isnull(janvier,0)),sum(isnull(fevrier,0)),sum(isnull(mars,0)),
				sum(isnull(avril,0)),sum(isnull(mai,0)),sum(isnull(juin,0)),
				sum(isnull(juillet,0)),sum(isnull(aout,0)),sum(isnull(septembre,0)),
				sum(isnull(octobre,0)),sum(isnull(novembre,0)),sum(isnull(decembre,0)),
				sum(isnull(total,0))
					
		drop table #liste
	
end	



go

