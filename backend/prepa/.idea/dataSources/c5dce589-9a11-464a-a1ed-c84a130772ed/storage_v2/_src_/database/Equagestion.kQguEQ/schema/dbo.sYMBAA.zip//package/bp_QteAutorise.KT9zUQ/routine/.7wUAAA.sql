/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_QteAutorise
grant execute on bp_QteAutorise to public
*/

CREATE PROCEDURE dbo.bp_QteAutorise(
		@client char(12),
		@article char(15),
		@qte int
		)
with recompile
AS
begin
	 declare
	 	@qte_encours int,
	 	@is_ok int,
	 	@qte_rest int,
	 	@cat char(15)
	 	
	 	select @qte_encours=0
	 	select @is_ok=0
	 	select @qte_rest=0
	 	
	 	select @cat=CLSA from FCL where CLCODE=@client
	 	
	 	if(select count(*) from b_Qte_Autorise where A_Article=@article and (A_Client=@client or (A_Client='*' and (A_Categorie=@cat or A_Categorie='*'))))>0
	 	begin
	 		select @qte_encours=isnull(sum(isnull(CCLQTE,0)),0) from FCCL where CCLDATE=current_date() and CCLARTICLE=@article and CCLCL=@client group by CCLARTICLE,CCLCL
	 		
	 		select @is_ok=(case when (@qte_encours+@qte)>isnull(A_Qte,0) then 1 else 0 end)  ,@qte_rest=(case when @qte_encours=isnull(A_Qte,0) then 0 when (@qte_encours+@qte)>isnull(A_Qte,0) then (@qte-(@qte+@qte_encours-isnull(A_Qte,0))) else 0 end)  
	 		from b_Qte_Autorise  where A_Article=@article and (A_Client=@client or (A_Client='*' and (A_Categorie=@cat or A_Categorie='*')))
	 		/*if(@is_ok=0)
	 		begin
	 			select @is_ok=(case when (@qte_encours+@qte)<=isnull(A_Qte,0) then 1 else 0 end)  ,@qte_rest=(case when @qte_encours=isnull(A_Qte,0) then 0 when (@qte_encours+@qte)>isnull(A_Qte,0) then (@qte-(@qte+@qte_encours-isnull(A_Qte,0))) else 0 end)
	 			 from b_Qte_Autorise  where A_Article=@article and (A_Client='*' and (A_Categorie=@cat or  A_Categorie='*'))
	 		end*/
	 	end
	 	
		select @is_ok,@qte_rest
end
go

