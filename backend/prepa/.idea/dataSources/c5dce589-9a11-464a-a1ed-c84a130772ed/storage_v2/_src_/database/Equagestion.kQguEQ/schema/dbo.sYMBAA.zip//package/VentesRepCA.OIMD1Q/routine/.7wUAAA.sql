


create procedure VentesRepCA   (@ent			char(5)	 = null,
								@Fournisseur	char(12) = null,
							 	@Famille		char(8)  = null
								)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1		datetime
declare @date2		datetime
declare @an			smallint

select @an=datepart(yy,getdate())


create table #temp
(
Client			char(12)		not null,
CA_Annee1		numeric(14,2)		null,
CA_AnneeP		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null
)

create table #Final
(
Client			char(12)		not null,
CA_Annee1		numeric(14,2)		null,
CA_AnneeP		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null
)

create table #Far
(
Article		char(15)		not null
)

create table #Far2
(
Article		char(15)			null
)

/* Recuperation des articles souhaites */

if (@Fournisseur is null) and (@Famille is null)
	begin
		insert into #Far
		select ARCODE from FAR
	end
else if (@Fournisseur is null) and (@Famille is not null)
	begin
		insert into #Far
		select ARCODE from FAR
		where ARFAM!=@Famille
	end
else if (@Fournisseur is not null) and (@Famille is null)
	begin
		insert into #Far
		select ARCODE from FAR
		where ARFO=@Fournisseur
	end
else if (@Fournisseur is not null) and (@Famille is not null)
	begin
		insert into #Far
		select ARCODE from FAR
		where ARFO=@Fournisseur
		and ARFAM!=@Famille
	end


insert into #Far2
select Article from #Far


/* Quantites et CA pour An-1 */


insert into #temp (Client,CA_Annee1)
select STCL,sum(STCAFA)
from FST,#Far
where Article=START
and STAN=@an-1
and (@ent is null or STENT=@ent)
group by STCL


/* Quantites et CA pour An-1 du 1er Janvier a la date du jour */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an-1))
select @date2=convert(datetime,convert(varchar(2),datepart(mm,getdate()))+"/"+
			convert(varchar(2),datepart(dd,getdate()))+"/"+convert(varchar(4),@an-1))


insert into #temp (Client,CA_AnneeP)
select FALCL,sum(FALTOTALHT)
from FFAL (index artdate),#Far2
where Article=FALARTICLE
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by FALCL

drop table #Far2

/* Quantites et CA pour Annee en cours */


insert into #temp (Client,CA_Annee)
select STCL,sum(STCAFA)
from FST,#Far
where Article=START
and STAN=@an
and (@ent is null or STENT=@ent)
group by STCL


drop table #Far


insert into #Final(Client,CA_Annee1,CA_AnneeP,CA_Annee)
select Client,sum(CA_Annee1),sum(CA_AnneeP),sum(CA_Annee)
from #temp
group by Client

drop table #temp

create unique clustered index client on #Final (Client)


select 	Rep=isnull(CLREP,"        "),
		Client=isnull(Client,"        "),
		Dep=isnull(substring(CLCP,1,2),"  "),
		Ville=isnull(CLVILLE,"        "),
		Adr1=isnull(CLADR1,"        "),
		Adr2=isnull(CLADR2,"        "),
		CP=isnull(CLCP,"        "),
		Tel=isnull(CLTEL1,"        "),
		Fax=isnull(CLTELECOP1,"        "),
		Numcomptable=isnull(CLNUMCOMPTABLE,"        "),
		Nom=isnull(CLNOM1,"        "),
		CA_1=convert(int,isnull(CA_Annee1,0)),
		CA_P=convert(int,isnull(CA_AnneeP,0)),
		CA=convert(int,isnull(CA_Annee,0))
from #Final,FCL
where CLCODE=Client
and (@ent is null or CLENT=@ent)
order by CLREP,CA_Annee1 desc,Client
compute sum(convert(int,isnull(CA_Annee1,0))),sum(convert(int,isnull(CA_AnneeP,0))),
		sum(convert(int,isnull(CA_Annee,0)))
		by CLREP
compute sum(convert(int,isnull(CA_Annee1,0))),sum(convert(int,isnull(CA_AnneeP,0))),
		sum(convert(int,isnull(CA_Annee,0)))


drop table #Final

end



go

