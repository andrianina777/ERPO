


create procedure StatRep (	@ent		char(5) = null,
							@rep		char(8))
with recompile
as
begin

set arithabort numeric_truncation off

create table #MAR
(
marque		char(12)		not null,
famille		char(8)			not null,
article		char(15)		not null,
ventes_N2	int				null,
ventes_N1	int				null,
ventes_N1P	int				null,
ventes_N	int				null,
cdes		int				null,
prix_moyen	numeric(14,2)	null,
objectif	int				null,
realise_pc	numeric(14,2)	null,
ca_encours	numeric(14,2)	null
)

create table #Final
(
marque		char(12)		not null,
famille		char(8)			not null,
article		char(15)		not null,
ventes_N2	int				null,
ventes_N1	int				null,
ventes_N1P	int				null,
ventes_N	int				null,
cdes		int				null,
prix_moyen	numeric(14,2)	null,
objectif	int				null,
realise_pc	numeric(14,2)	null,
ca_encours	numeric(14,2)	null
)

declare @an			smallint,
		@mois		tinyint,
		@type		tinyint
		
select  @an  =convert(smallint,datepart(yy,getdate())),
		@mois=convert(tinyint,datepart(mm,getdate()))

select  @type=RETYPE
from FREP
where RECODE=@rep

declare @multient	tinyint

select @multient=KIMULTIENTITE from KInfos

/****** Chiffres sur les annees N-2, N-1 & N ******/

insert into #MAR (marque,famille,article,ventes_N2,ventes_N1,ventes_N,ca_encours)
select ARFO,ARFAM,ARCODE,
sum(STQTEFA*(1-sign(abs(STAN-@an+2)))),
sum(STQTEFA*(1-sign(abs(STAN-@an+1)))),
sum(STQTEFA*(1-sign(abs(STAN-@an)))),
sum(STCAFA*(1-sign(abs(STAN-@an))))
from FST,FAR
where (@multient=0 or @ent is null or STENT=@ent)
and (@type = 2 or STREP=@rep)
and (@type != 2 or STREPDIV=@rep)
and ARCODE=START
group by ARFO,ARFAM,ARCODE

/****** Insertion des chiffres sur l''''annee N-1 partielle ******/

insert into #MAR (marque,famille,article,ventes_N1P)
select ARFO,ARFAM,ARCODE,sum(STQTEFA*(1-sign(abs(STAN-@an+1))))
from FST,FAR
where (@multient=0 or @ent is null or STENT=@ent)
and (@type = 2 or STREP=@rep)
and (@type != 2 or STREPDIV=@rep)
and ARCODE=START
and STAN=@an-1
and STMOIS between 1 and @mois
group by ARFO,ARFAM,ARCODE

/****** Insertion des commandes a livrer ******/

insert into #MAR (marque,famille,article,cdes)
select ARFO,ARFAM,ARCODE,sum(RCCQTE)
from FRCC,FAR,FCCL,FCC
where (@multient=0 or @ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and (@type = 2 or CCLREP=@rep)
and (@type != 2 or CCLREPDIV=@rep)
and ARCODE=RCCARTICLE
group by ARFO,ARFAM,ARCODE

/****** Regroupement dans la table finale ******/

insert into #Final (marque,famille,article,ventes_N2,ventes_N1,ventes_N1P,ventes_N,cdes,objectif,ca_encours)
select marque,famille,article,sum(ventes_N2),sum(ventes_N1),sum(ventes_N1P),sum(ventes_N),
sum(cdes),0,sum(ca_encours)
from #MAR
group by marque,famille,article
drop table #MAR

/******* Maj des valeurs en division *******/

update #Final
set prix_moyen = round(isnull(ca_encours,0)/isnull(convert(numeric(14,2),ventes_N),0),2)
where isnull(ventes_N,0) != 0
update #Final
set prix_moyen = 0.00
where isnull(ventes_N,0) = 0
update #Final
set realise_pc = 0.00

/******** select final *********/

select marque,famille,article,annee_2=isnull(ventes_N2,0),annee_1=isnull(ventes_N1,0),
annee_1_partiel=isnull(ventes_N1P,0),annee_en_cours=isnull(ventes_N,0),
cdes=isnull(cdes,0),abs(prix_moyen),objectifs=objectif,realise_pc,
chiffre_affaires=isnull(ca_encours,0)
from #Final
order by marque,famille,article
drop table #Final
end



go

