


create procedure Stats_Rep (@ent			char(5) = null,
							@rep			char(8) = null,
							@An 			smallint = 0,
							
							@depart			tinyint = null,
							@grfam			tinyint = null,
							@marque			tinyint = null,
							@famille		tinyint = null,
							@article		tinyint = null,
							
							@matiere		tinyint = null,
							@couleur		tinyint = null,
							@grille			tinyint = null,
							@calibre		tinyint = null,
							@produit		tinyint = null,
							@emp			tinyint = null,
							@foreign1		tinyint = null,
							@foreign2		tinyint = null,
							
							@departCode		char(8) = null,
							@grfamCode		char(8) = null,
							@marqueCode		char(12) = null,
							@familleCode	char(8) = null,
							@articleCode	char(15) = null,
							
							@matiereCode	char(14) = null,
							@couleurCode	char(8) = null,
							@grilleCode		char(10) = null,
							@calibreCode	char(14) = null,
							@produitCode	char(15) = null,
							@empCode		char(16) = null,
							@foreign1Code	char(12) = null,
							@foreign2Code	char(12) = null,
													
							@srfa			tinyint = 0)
														
with recompile
as
begin

set arithabort numeric_truncation off

declare @indice	int
select  @indice = 0

if @rep = ''
	select @rep = null

if @rep is null
	select @indice = 1

if @An = 0 or @An is null
	select @An = datepart(year,getdate())


if (@depart is null) and (@grfam is null) 
	and (@marque is null) and (@famille is null)
	and (@article is null)
	and (@matiere is null) and (@couleur is null)
	and (@grille is null) and (@calibre is null)
	and (@produit is null) and (@emp is null)
	and (@foreign1 is null) and (@foreign2 is null)
select @grfam = 1

if @articleCode is not null
select @departCode=null,@grfamCode=null,@marqueCode=null,@familleCode=null,
@matiereCode=null,@couleurCode=null,@grilleCode=null,@calibreCode=null,
@produitCode=null,@empCode=null,@foreign1Code=null,@foreign2Code=null

create table #Finale
(
CODE		char(15)	not null,
LIB			varchar(80)		null,
QteFAN2		int				null,
CAFAN2		numeric(14,2)	null,
QteFAN1		int				null,
CAFAN1		numeric(14,2)	null,
QteFAN0		int				null,
CAFAN0		numeric(14,2)	null,
QteCCN0		int				null,
CACCN0		numeric(14,2)	null,
DEPART		char(8)			null,
CATEG		char(8)			null,
FAM			char(8)			null,
ART			char(15)		null,
MATIERE		char(14)		null,
COULEUR		char(8)			null,
GRILLE		char(10)		null,
CALIBRE		char(14)		null,
PRODUIT		char(15)		null,
EMP			char(16)		null,
FOREIGN1	char(12)		null,
FOREIGN2	char(12)		null
)

declare @type		tinyint		
select  @type=RETYPE from FREP where RECODE=@rep

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos


set forceplan on

if isnull(@depart,0) > 0
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARDEPART,''),isnull(DTLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,ARDEPART,'','','',
		 '','','','','','','',''
from FST,FAR,FDT
where ARCODE=START
and DTCODE=ARDEPART
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARDEPART,DTLIB

union

select isnull(ARDEPART,''),isnull(DTLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 ARDEPART,'','','',
		 '','','','','','','',''
from FAR,FDT,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and DTCODE=ARDEPART
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARDEPART,DTLIB


end
else if isnull(@grfam,0) > 0
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARGRFAM,''),isnull(GFNOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'',ARGRFAM,'','',
		 '','','','','','','',''
from FST,FAR,FGF
where ARCODE=START
and GFCODE=ARGRFAM
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARGRFAM,GFNOM

union

select isnull(ARGRFAM,''),isnull(GFNOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '',ARGRFAM,'','',
		 '','','','','','','',''
from FAR,FGF,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and GFCODE=ARGRFAM
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARGRFAM,GFNOM

end
else if isnull(@marque,0) > 0
begin


insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARFO,''),isnull(FONOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','',ARFO,'',
		 '','','','','','','',''
from FST,FAR,FFO
where ARCODE=START
and FOCODE=ARFO
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFO,FONOM

union

select isnull(ARFO,''),isnull(FONOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','',ARFO,'',
		 '','','','','','','',''
from FAR,FFO,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and FOCODE=ARFO
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFO,FONOM


end
else if isnull(@famille,0) > 0
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARFAM,''),isnull(FPLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','',ARFAM,
		 '','','','','','','',''
from FST,FAR,FFP
where ARCODE=START
and FPCODE=ARFAM
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFAM,FPLIB

union

select isnull(ARFAM,''),isnull(FPLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','',ARFAM,
		 '','','','','','','',''
from FAR,FFP,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and FPCODE=ARFAM
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFAM,FPLIB


end
else if isnull(@matiere,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARMATIERE,''),isnull(MADES,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 ARMATIERE,'','','','','','',''
from FST,FAR,FMA
where ARCODE=START
and MACODE=*ARMATIERE
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARMATIERE,MADES

union

select isnull(ARMATIERE,''),isnull(MADES,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 ARMATIERE,'','','','','','',''
from FAR,FMA,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and MACODE=*ARMATIERE
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARMATIERE,MADES


end
else if isnull(@couleur,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARCOULEUR,''),isnull(CRLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '',ARCOULEUR,'','','','','',''
from FST,FAR,FCR
where ARCODE=START
and CRCODE=*ARCOULEUR
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARCOULEUR,CRLIB

union

select isnull(ARCOULEUR,''),isnull(CRLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '',ARCOULEUR,'','','','','',''
from FAR,FCR,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and CRCODE=*ARCOULEUR
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARCOULEUR,CRLIB


end
else if isnull(@grille,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARGRILLE,''),isnull(TATAILLE,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '','',ARGRILLE,'','','','',''
from FST,FAR,FTA
where ARCODE=START
and TAGRILLE=*ARGRILLE
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARGRILLE,TATAILLE

union

select isnull(ARGRILLE,''),isnull(TATAILLE,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '','',ARGRILLE,'','','','',''
from FAR,FTA,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and TAGRILLE=*ARGRILLE
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARGRILLE,TATAILLE


end
else if isnull(@calibre,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARCALIBRE,''),isnull(CPDES,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '','','',ARCALIBRE,'','','',''
from FST,FAR,FCP
where ARCODE=START
and CPCODE=*ARCALIBRE
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARCALIBRE,CPDES

union

select isnull(ARCALIBRE,''),isnull(CPDES,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '','','',ARCALIBRE,'','','',''
from FAR,FCP,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and CPCODE=*ARCALIBRE
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARCALIBRE,CPDES


end
else if isnull(@produit,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARPRODUIT,''),isnull(GPLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '','','','',ARPRODUIT,'','',''
from FST,FAR,FGP
where ARCODE=START
and GPCODE=*ARPRODUIT
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARPRODUIT,GPLIB

union

select isnull(ARPRODUIT,''),isnull(GPLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '','','','',ARPRODUIT,'','',''
from FAR,FGP,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and GPCODE=*ARPRODUIT
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARPRODUIT,GPLIB


end
else if isnull(@emp,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(AREMP,''),isnull(SP1DES,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '','','','','',AREMP,'',''
from FST,FAR,FSP1
where ARCODE=START
and SP1CODE=*AREMP
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by AREMP,SP1DES

union

select isnull(AREMP,''),isnull(SP1DES,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '','','','','',AREMP,'',''
from FAR,FSP1,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and SP1CODE=*AREMP
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by AREMP,SP1DES


end
else if isnull(@foreign1,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARFOREIGN1,''),isnull(SCT1NOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '','','','','','',ARFOREIGN1,''
from FST,FAR,FSCT1
where ARCODE=START
and SCT1CODE=*ARFOREIGN1
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFOREIGN1,SCT1NOM

union

select isnull(ARFOREIGN1,''),isnull(SCT1NOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '','','','','','',ARFOREIGN1,''
from FAR,FSCT1,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and SCT1CODE=*ARFOREIGN1
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFOREIGN1,SCT1NOM


end
else if isnull(@foreign2,0) > 0  /* --------------------------------------------------------------------------- */
begin

insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARFOREIGN2,''),isnull(SCT2NOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',
		 '','','','','','','',ARFOREIGN2
from FST,FAR,FSCT2
where ARCODE=START
and SCT2CODE=*ARFOREIGN2
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFOREIGN2,SCT2NOM

union

select isnull(ARFOREIGN2,''),isnull(SCT2NOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','','',
		 '','','','','','','',ARFOREIGN2
from FAR,FSCT2,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and SCT2CODE=*ARFOREIGN2
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARFOREIGN2,SCT2NOM


end
else if isnull(@article,0) > 0
begin


insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
						QteCCN0,CACCN0,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2)
select isnull(ARCODE,''),isnull(ARLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,ARDEPART,ARGRFAM,ARFO,ARFAM,
		 ARMATIERE,ARCOULEUR,ARGRILLE,ARCALIBRE,ARPRODUIT,AREMP,ARFOREIGN1,ARFOREIGN2
from FST,FAR
where ARCODE=START
and ((@indice = 1) or (@type = 2 or STREP=@rep))
and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
and STAN >= @An-2
and (@multient=0 or @ent is null or STENT=@ent)
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARDEPART,ARGRFAM,ARFO,ARFAM,
		 ARMATIERE,ARCOULEUR,ARGRILLE,ARCALIBRE,ARPRODUIT,AREMP,ARFOREIGN1,ARFOREIGN2,
		 ARCODE,ARLIB

union

select isnull(ARCODE,''),isnull(ARLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 ARDEPART,ARGRFAM,ARFO,ARFAM,
		 ARMATIERE,ARCOULEUR,ARGRILLE,ARCALIBRE,ARPRODUIT,AREMP,ARFOREIGN1,ARFOREIGN2
from FAR,FRCC,FCCL,FCC
where ARCODE=RCCARTICLE
and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))
and RCCAN >= @An-2
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@multient=0 or @ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
and (@articleCode is null or ARCODE=@articleCode)
and (@departCode is null or ARDEPART=@departCode)
and (@grfamCode is null or ARGRFAM=@grfamCode)
and (@marqueCode is null or ARFO=@marqueCode)
and (@familleCode is null or ARFAM=@familleCode)
and (@matiereCode is null or ARMATIERE = @matiereCode)
and (@couleurCode is null or ARCOULEUR = @couleurCode)
and (@grilleCode is null or ARGRILLE = @grilleCode)
and (@calibreCode is null or ARCALIBRE = @calibreCode)
and (@produitCode is null or ARPRODUIT = @produitCode)
and (@empCode is null or AREMP = @empCode)
and (@foreign1Code is null or ARFOREIGN1 = @foreign1Code)
and (@foreign2Code is null or ARFOREIGN2 = @foreign2Code)
and (@srfa=0 or ARTYPE != 6)
group by ARDEPART,ARGRFAM,ARFO,ARFAM,
		 ARMATIERE,ARCOULEUR,ARGRILLE,ARCALIBRE,ARPRODUIT,AREMP,ARFOREIGN1,ARFOREIGN2,
		 ARCODE,ARLIB


end

set forceplan off

select CODE,LIB,sum(QteFAN2),sum(CAFAN2),sum(QteFAN1),sum(CAFAN1),sum(QteFAN0),sum(CAFAN0),
						sum(QteCCN0),sum(CACCN0),DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2
from #Finale
group by CODE,LIB,DEPART,CATEG,FAM,ART,
						MATIERE,COULEUR,GRILLE,CALIBRE,PRODUIT,EMP,FOREIGN1,FOREIGN2
order by LIB


drop table #Finale
	
end

go

