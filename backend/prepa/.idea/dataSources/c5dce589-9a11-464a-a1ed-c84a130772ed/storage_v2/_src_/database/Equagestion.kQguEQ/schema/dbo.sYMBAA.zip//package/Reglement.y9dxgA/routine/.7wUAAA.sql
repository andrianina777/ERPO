


create procedure Reglement (@ent	char(5)	= null,
						 	@date1	smalldatetime,
						 	@date2	smalldatetime,
						 	@fourn	char(12) = null)
			
with recompile
as
begin

	create table #Stock
	(
	Libelle		char(35)		not null,
	Article		char(15)		not null,
	Lettre		char(4)			not null,
	Famille		char(8)			not null,
	Categorie	char(15)		not null,
	Modele		char(8)			not null,
	Calibre		char(14)		not null,
	Marque		char(12)		not null,
	Provenance	varchar(200)	not null,
	Numserie1	char(12)			null,
	Numserie2	char(12)			null,
	DateStock	datetime			null,	
	Acquereur	char(12)		not null,
	NumAutoris	char(10)			null,
	DateAutoris	datetime			null,
	DateSortie	datetime			null,
	Quantite	int					null,
	Coordonnees	varchar(200)		null,
	Code		char(10)			null
	)

	declare @societe char(12),
		@coordsoc varchar(200)

	select @societe=PSOC,@coordsoc=PNOM1+' '+PADR1+' '+PADR2+' - '+PCP+' '+PVILLE+' '+PSOCPY from KParam

	/*-------------------*/
	/* Materiel en stock */

	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Articles en stock',STAR,STLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,
	STFO+' '+isnull(FONOM,"")+' '+isnull(FOADR1,"")+' '+isnull(FOADR2,"")+' - '+isnull(FOCP,"")+' '+isnull(FOVILLE,"")+' '+isnull(FOPY,""),STNUMARM1,STNUMARM2,
	STDATEENTR,'','',null,null,STQTE,'',''
	from FSTOCK,FAR,FDP,FFO
	where ARCODE=STAR
	and FOCODE=STFO
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STQTE > 0
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	/*-----------------------------------------------------------*/
	/* Ventes : Materiel sorti par BEL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Ventes',BELARTICLE,BELLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,
	STFO+' '+FONOM+' '+FOADR1+' '+FOADR2+' - '+FOCP+' '+FOVILLE+' '+FOPY,STNUMARM1,STNUMARM2,STDATEENTR,BELCL,
	CLNOAGR,CLDATEAGR,BELDATECRE,BELQTE,BENOM+' '+BEADR1+' '+BEADR2+' - '+BECP+' '+BEVILLE+' '+BEPY,BELCODE
	from FBEL,FBE,FAR,FDP,FCL,FSTOCK,FFO
	where ARCODE=STAR and BELCODE=BECODE and BELCL=CLCODE and FOCODE=STFO
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=BELARTICLE
	and STLETTRE=BELLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and BELDATE between @date1 and @date2
	and BELQTE > 0
	and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	
	/*------------------------------------------------------------------*/	
	/* Retour client : Materiel sorti par BEL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Retours Clients',BELARTICLE,BELLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,
	BELCL+' '+BENOM+' '+BEADR1+' '+BEADR2+' - '+BECP+' '+BEVILLE+' '+BEPY,STNUMARM1,STNUMARM2,
	STDATEENTR,@societe,CLNOAGR,CLDATEAGR,BELDATECRE,BELQTE,@coordsoc,BELCODE
	from FBEL,FBE,FAR,FDP,FCL,FSTOCK
	where ARCODE=STAR and BELCODE=BECODE and BELCL=CLCODE
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=BELARTICLE
	and STLETTRE=BELLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and BELDATE between @date1 and @date2
	and BELQTE < 0
	and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	
	/*-----------------------------------------------------------------------*/
	/* Retour fournisseur : Materiel sorti par RFL entre les dates indiquees */		
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Retours Fournisseurs',RFLARTICLE,RFLLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,
	@societe+' '+@coordsoc,STNUMARM1,STNUMARM2,STDATEENTR,RFLFO,'',null,RFLDATECRE,RFLQTE,
	RFNOM+' '+RFADR1+' '+RFADR2+' - '+RFCP+' '+RFVILLE+' '+RFPY,RFLCODE
	from FRFL,FRF,FAR,FDP,FSTOCK
	where ARCODE=STAR and RFLCODE=RFCODE
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=RFLARTICLE
	and STLETTRE=RFLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and RFLDATE between @date1 and @date2
	and DPCODE=STDEPOT and (@ent is null or (RFLENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	
	/*-----------------------------------------------------------------------*/
	/* Ajustements :RJL entre les dates indiquees */		
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Ajustements',RJLARTICLE,RJLLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,@societe+' '+@coordsoc,
	STNUMARM1,STNUMARM2,STDATEENTR,@societe,'',null,RJLDATECRE,RJLQTE,@coordsoc,RJLCODE
	from FRJL,FAR,FDP,FSTOCK
	where ARCODE=STAR 
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=RJLARTICLE
	and STLETTRE=RJLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and RJLDATE between @date1 and @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))



	/*-----------------------------------------------------*/
	/* Stock initial entree :SIL entre les dates indiquees */		
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Stock initial - Transferts entrees',SILARTICLE,SILLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,
	SILFO+' '+isnull(FONOM,"")+' '+isnull(FOADR1,"")+' '+isnull(FOADR2,"")+' - '+isnull(FOCP,"")+' '+isnull(FOVILLE,"")+' '+isnull(FOPY,""),SILNUMARM1,SILNUMARM2,
		SILDATEENTR,@societe,'',null,null,SILQTE,@coordsoc,SILCODE
	from FSIL,FAR,FDP,FFO
	where ARCODE=SILARTICLE and FOCODE=SILFO
	and ARREGLE in (1,3)
	and (@fourn is null or SILFO=@fourn)
	and SILQTE > 0
	and SILDATE between @date1 and @date2
	and DPCODE=SILDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))


	/*-----------------------------------------------------*/
	/* Stock initial sortie :SIL entre les dates indiquees */		
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Stock initial - Transferts sorties',SILARTICLE,SILLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,@societe+' '+@coordsoc,
	STNUMARM1,STNUMARM2,STDATEENTR,@societe,'',null,SILDATEENTR,SILQTE,@coordsoc,SILCODE
	from FSIL,FAR,FDP,FSTOCK
	where ARCODE=STAR 
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=SILARTICLE
	and STLETTRE=SILLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and SILQTE < 0
	and SILDATE between @date1 and @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))


	/*----------------------------------------------------------------------------*/	
	/* Livraisons fournisseurs : Materiel entre par BLL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Livraisons fournisseurs',BLLAR,BLLLET,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,
	BLFO+' '+BLNOM+' '+BLADR1+' '+BLADR2+' - '+BLCP+' '+BLVILLE+' '+BLPY,BLLNARM1,BLLNARM2,
	BLLDATECRE,@societe,'',null,null,BLLQTE,@coordsoc,BLCODE
	from FBLL,FBL,FAR,FDP
	where BLLAR=ARCODE and BLLCODE=BLCODE 
	and ARREGLE in (1,3)
	and (@fourn is null or BLFO=@fourn)
	and BLLDATE between @date1 and @date2
	and BLLLET != ""
	and DPCODE=BLLDEP and (@ent is null or (BLLENT=@ent and DPENT=@ent and DPCENTRAL=0))

	/*----------------------------------------------------------------------------*/	
	/* Sortie de douane : Materiel sorti par DOL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Sorties de douanes',DOLAR,DOLLET,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,@societe+' '+@coordsoc,
	STNUMARM1,STNUMARM2,STDATEENTR,@societe,'',null,DOLDATECRE,DOLQTE,@coordsoc,DOLCODE
	from FDOL,FAR,FDP,FSTOCK
	where ARCODE=STAR 
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=DOLAR
	and STLETTRE=DOLLET
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and DOLDATE between @date1 and @date2
	and DOLQTE < 0
	and DPCODE=STDEPOT and (@ent is null or (DOLENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	/*----------------------------------------------------------------------------*/	
	/* Entree depuis douane : Materiel sorti par DOL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Entrees depuis douanes',DOLAR,DOLLET,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),ARFO,@societe+' '+@coordsoc,
	DOLNARM1,DOLNARM2,DOLDATECRE,@societe,'',null,null,DOLQTE,@coordsoc,DOLCODE
	from FDOL,FAR,FDP
	where ARCODE=DOLAR 
	and ARREGLE in (1,3)
	and (@fourn is null or DOLFO=@fourn)
	and DOLDATE between @date1 and @date2
	and DOLQTE > 0
	and DPCODE=DOLDEP and (@ent is null or (DOLENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	/*----------------------------------------------------------------------------*/	
	/* Assemblage/desassemblage sortie : Materiel sorti par FASL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Assemblages/desassemblages sorties',ASLARTICLE,ASLLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,
	isnull(ARCALIBRE,""),ARFO,@societe+' '+@coordsoc,
	STNUMARM1,STNUMARM2,STDATEENTR,@societe,'',null,ASLDATECRE,ASLQTE,@coordsoc,ASLCODE
	from FASL,FAR,FDP,FSTOCK
	where ARCODE=STAR 
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=ASLARTICLE
	and STLETTRE=ASLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and ASLDATE between @date1 and @date2
	and ASLQTE < 0
	and DPCODE=ASLDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	/*----------------------------------------------------------------------------*/	
	/* Assemblage/desassemblage Entree : Materiel sorti par ASL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Lettre,Famille,Categorie,Modele,Calibre,Marque,Provenance,
				Numserie1,Numserie2,DateStock,Acquereur,NumAutoris,DateAutoris,DateSortie,
				Quantite,Coordonnees,Code)
	select  'Assemblages/desassemblages entrees',ASLARTICLE,ASLLETTRE,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,
	isnull(ARCALIBRE,""),ARFO,@societe+' '+@coordsoc,
	ASLNUMARM1,ASLNUMARM2,ASLDATECRE,@societe,'',null,null,ASLQTE,@coordsoc,ASLCODE
	from FASL,FAR,FDP
	where ARCODE=ASLARTICLE 
	and ARREGLE in (1,3)
	and (@fourn is null or ASLFO=@fourn)
	and ASLDATE between @date1 and @date2
	and ASLQTE > 0
	and DPCODE=ASLDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	
	/* Liste finale */
	
	select Mouvements=Libelle,Article=Article,Lettre=Lettre,Famille=Famille,Categorie=Categorie,Modele=Modele,
	Calibre=Calibre,Marque=Marque,Provenance=Provenance,Numero_de_serie1=Numserie1,Numero_de_serie2=Numserie2,
	Date_entree_en_stock=DateStock,Acquereur=Acquereur,Numero_Autorisation=NumAutoris,Date_Autorisation=DateAutoris,
	Date_de_sortie=DateSortie,Quantite=Quantite,Coordonnees_acquereur=Coordonnees,Code=Code
	from #Stock
	
	drop table #Stock
	
end



go

