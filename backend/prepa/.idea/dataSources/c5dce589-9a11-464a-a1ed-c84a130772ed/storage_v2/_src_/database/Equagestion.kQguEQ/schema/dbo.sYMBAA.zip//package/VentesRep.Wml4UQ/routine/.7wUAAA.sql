


create procedure VentesRep (@ent		 char(5)  = null,
							@Fournisseur char(12) = null,
							@Famille	 char(8)  = null,
							@Article	 char(15) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1		datetime
declare @date2		datetime
declare @an			smallint

select @an=datepart(yy,getdate())


create table #temp
(
Client			char(12)		not null,
Qte_Annee1		int				null,
Qte_AnneeP		int				null,
Qte_Annee		int				null,
Qte_Cde			int				null,
CA_Annee1		numeric(14,2)	null,
CA_AnneeP		numeric(14,2)	null,
CA_Annee		numeric(14,2)	null,
CA_Cde			numeric(14,2)	null
)

create table #Final
(
Client			char(12)			not null,
Qte_Annee1		int					null,
Qte_AnneeP		int					null,
Qte_Annee		int					null,
Qte_Cde			int					null,
CA_Annee1		numeric(14,2)		null,
CA_AnneeP		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null,
CA_Cde			numeric(14,2)		null
)

create table #Far
(
Article		char(15)		not null
)

create table #Far2
(
Article		char(15)			null
)

/* Recuperation des articles souhaites */

insert into #Far
select ARCODE from FAR
where (@Fournisseur is null or ARFO=@Fournisseur)
and (@Famille is null or ARFAM=@Famille)
and (@Article is null or ARCODE=@Article)


insert into #Far2
select Article from #Far

create unique index code on #Far (Article)

create unique index code on #Far2 (Article)

/* Quantites et CA */


insert into #temp (Client,Qte_Annee1,CA_Annee1,Qte_Annee,CA_Annee)
select STCL,sum(case when STAN=@an-1 then STQTEFA else 0 end),
			sum(case when STAN=@an-1 then STCAFA else 0 end),
			sum(case when STAN=@an then STQTEFA else 0 end),
			sum(case when STAN=@an then STCAFA else 0 end)
from FST
where STAN between @an-1 and @an
and (@ent is null or STENT=@ent)
and exists (select * from #Far where Article=FST.START)
group by STCL


/* Quantites et CA pour An-1 du 1er Janvier a la date du jour */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an-1))
select @date2=convert(datetime,convert(varchar(2),datepart(mm,getdate()))+"/"+
			convert(varchar(2),datepart(dd,getdate()))+"/"+convert(varchar(4),@an-1))


insert into #temp (Client,Qte_AnneeP,CA_AnneeP)
select FALCL,
	   isnull(sum(case	when (isnull(FALLETTRE,'') != '') then FALQTE else 0 end),0),
	   sum(FALTOTALHT)
from FFAL
where FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
and exists (select * from #Far2 where Article=FFAL.FALARTICLE)
group by FALCL

drop table #Far2


/* Quantites et CA en commande client */

insert into #temp (Client,Qte_Cde,CA_Cde)
select RCCCL,sum(RCCQTE),sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE)
from FRCC,FCCL,#Far,FCC
where Article=RCCARTICLE
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT))
group by RCCCL

drop table #Far


insert into #Final(Client,Qte_Annee1,Qte_AnneeP,Qte_Annee,Qte_Cde,CA_Annee1,CA_AnneeP,CA_Annee,CA_Cde)
select Client,sum(Qte_Annee1),sum(Qte_AnneeP),sum(Qte_Annee),sum(Qte_Cde),sum(CA_Annee1),
			sum(CA_AnneeP),sum(CA_Annee),sum(CA_Cde)
from #temp
group by Client

drop table #temp

create unique clustered index client on #Final (Client)


select 	Rep=isnull(CLREP,"        "),
		Dep=isnull(substring(CLCP,1,2),"  "),
		Ville=isnull(CLVILLE,"        "),
		Client=isnull(Client,"        "),
		Adr1=isnull(CLADR1,"        "),
		Adr2=isnull(CLADR2,"        "),
		CP=isnull(CLCP,"        "),
		Tel=isnull(CLTEL1,"        "),
		Fax=isnull(CLTELECOP1,"        "),
		Numcomptable=isnull(CLNUMCOMPTABLE,"        "),
		Nom=isnull(CLNOM1,"        "),
		Qte_1=isnull(Qte_Annee1,0),
		Qte_P=isnull(Qte_AnneeP,0),
		Qte=isnull(Qte_Annee,0),
		Qte_Cde=isnull(Qte_Cde,0),
		CA_1=convert(int,isnull(CA_Annee1,0)),
		CA_P=convert(int,isnull(CA_AnneeP,0)),
		CA=convert(int,isnull(CA_Annee,0)),
		CA_Cde=convert(int,isnull(CA_Cde,0))
from #Final,FCL
where CLCODE=Client
order by CLREP,substring(CLCP,1,2),CLVILLE,Client
compute sum(isnull(Qte_Annee1,0)),sum(isnull(Qte_AnneeP,0)),
		sum(isnull(Qte_Annee,0)),sum(isnull(Qte_Cde,0)),
		sum(convert(int,isnull(CA_Annee1,0))),sum(convert(int,isnull(CA_AnneeP,0))),
		sum(convert(int,isnull(CA_Annee,0))),sum(convert(int,isnull(CA_Cde,0)))
		by CLREP,substring(CLCP,1,2)
compute sum(isnull(Qte_Annee1,0)),sum(isnull(Qte_AnneeP,0)),
		sum(isnull(Qte_Annee,0)),sum(isnull(Qte_Cde,0)),
		sum(convert(int,isnull(CA_Annee1,0))),sum(convert(int,isnull(CA_AnneeP,0))),
		sum(convert(int,isnull(CA_Annee,0))),sum(convert(int,isnull(CA_Cde,0)))
		by CLREP
compute sum(isnull(Qte_Annee1,0)),sum(isnull(Qte_AnneeP,0)),
		sum(isnull(Qte_Annee,0)),sum(isnull(Qte_Cde,0)),
		sum(convert(int,isnull(CA_Annee1,0))),sum(convert(int,isnull(CA_AnneeP,0))),
		sum(convert(int,isnull(CA_Annee,0))),sum(convert(int,isnull(CA_Cde,0)))


drop table #Final

end



go

