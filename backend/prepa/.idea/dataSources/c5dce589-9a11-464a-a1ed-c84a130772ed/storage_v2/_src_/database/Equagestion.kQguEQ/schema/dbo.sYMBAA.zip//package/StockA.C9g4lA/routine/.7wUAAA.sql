


/* Procedure permettant de comparer le stock resultant des mouvements 
au fichier FSTOCK pour un article */

create procedure StockA (@Article	char(15),
						 @lettre	char(4) = null)
with recompile
as
begin

set nocount on

declare @reconst	int
declare @base		int
declare @mouv		int

create table #Stock
(
Type		char(14)	null,
Article		char(15)		null,
Qte			int			null
)


/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stock
select 'SIL',SILARTICLE,sum(SILQTE)
from FSIL
where SILARTICLE=@Article
and (@lettre is null or SILLETTRE=@lettre)
group by SILARTICLE


/* ''Reajustements - Fichier RJL'' */

insert into #Stock
select 'RJL',RJLARTICLE,sum(RJLQTE)
from FRJL
where RJLARTICLE=@Article
and (@lettre is null or RJLLETTRE=@lettre)
group by RJLARTICLE


/* ''Lignes de casse - Fichier LCL'' */

insert into #Stock
select 'LCL',LCLARTICLE,sum(LCLQTE)
from FLCL
where LCLARTICLE=@Article
and (@lettre is null or LCLLETTRE=@lettre)
group by LCLARTICLE


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #Stock
select 'ASL',ASLARTICLE,sum(ASLQTE)
from FASL
where ASLARTICLE=@Article
and (@lettre is null or ASLLETTRE=@lettre)
group by ASLARTICLE


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stock
select 'BLL',BLLAR,sum(BLLQTE)
from FBLL
where BLLAR=@Article
and (@lettre is null or BLLLET=@lettre)
group by BLLAR


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stock
select 'DOL',DOLAR,sum(DOLQTE)
from FDOL
where DOLAR=@Article
and (@lettre is null or DOLLET=@lettre)
group by DOLAR


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stock
select 'RFL',RFLARTICLE,-sum(RFLQTE)
from FRFL
where RFLARTICLE=@Article
and (@lettre is null or RFLLETTRE=@lettre)
group by RFLARTICLE


/* ""Lignes de BE - Fichier FBEL"" */

insert into #Stock
select 'BEL',BELARTICLE,-sum(BELQTE)
from FBEL
where BELARTICLE=@Article
and (@lettre is null or BELLETTRE=@lettre)
group by BELARTICLE


/* ""Lignes de FA - Fichier FFAL"" */

insert into #Stock
select 'FAL',FALARTICLE,-sum(FALQTE)
from FFAL
where FALARTICLE=@Article
and isnull(FALLETTRE,'')!=''
and (@lettre is null or FALLETTRE=@lettre)
group by FALARTICLE


/* ""Lignes de RM - Fichier FRM"" */

insert into #Stock
select 'RM',RMARTICLE,sum(RMQTE)
from FRM
where RMARTICLE=@Article
and (@lettre is null or RMLETTRE=@lettre)
group by RMARTICLE



select Type,Article,Qte
from #Stock
where Type in('SIL','RJL','LCL','ASL','BLL','DOL','RFL','BEL')

select ""

select Type,Article,Qte
from #Stock
where Type in('FAL','RM')

select ""

select @reconst=sum(Qte)
from #Stock
where Type in('SIL','RJL','LCL','ASL','BLL','DOL','RFL','BEL')


select @base=sum(STQTE)
from FSTOCK
where STAR=@Article
and (@lettre is null or STLETTRE=@lettre)


select Reconstitution='STOCK reconst.',Article,Qte=sum(Qte)
from #Stock
where Type in('SIL','RJL','LCL','ASL','BLL','DOL','RFL','BEL')
group by Article

/* ''Stock en cours - Fichier FSTOCK'' */
select ""

select FSTOCK='STOCK Societe',Article=STAR,Qte=sum(STQTE)
from FSTOCK
where STAR=@Article
and (@lettre is null or STLETTRE=@lettre)
group by STAR

select ""

if (@reconst != @base)
select Difference="Stock resultant - Stock reconstitue=",Quantite=isnull(@base,0)-isnull(@reconst,0)
else
select "Pas de differences en reconstitution de stock resultant"

select ""

select Reconstitution='STOCK sur mouvements',Article,Qte=sum(Qte)
from #Stock
where Type in('SIL','RJL','LCL','ASL','BLL','DOL','RFL','FAL','RM')
group by Article


select @mouv=sum(Qte)
from #Stock
where Type in('SIL','RJL','LCL','ASL','BLL','DOL','RFL','FAL','RM')

select ""

if (@mouv != @base)
select Difference="Stock resultant - Stock mouvements=",Quantite=isnull(@base,0)-isnull(@mouv,0)
else
select "Pas de differences entre le stock resultant et le stock sur mouvements"

select ""

set nocount off

end



go

