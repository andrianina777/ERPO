



create procedure RubSupplTrans	(@pieceorg		varchar(30) = null,		/* code piece d''origine */
							 	 @seqorg		int		 	= null,		/* sequentiel piece d''origine */
							 	 @fichierorg	varchar(30),			/* fichier d''origine */
							 	 @piececible	varchar(30) = null,		/* code piece cible */
							 	 @seqcible		int		 	= null,		/* sequentiel piece cible */
							 	 @fichiercible	varchar(30)				/* fichier cible */
								)
with recompile
as
begin

declare @requete   	varchar(5000),
		@tableorg	varchar(30),
		@tablecode	varchar(30),
		@tableseq	int,
		@colonne	varchar(30),
		@valchar	varchar(1500),
		@valint		int,
		@valdec		numeric(30,14),
		@valdate	datetime,
		@ident		numeric(14,0),
		@user		int,
		@pluseq		int,
		@count		int

select  @user = user_id()

create table #plus
(
tableorg	varchar(30)		not null,
tablecode	varchar(30)			null,
tableseq	int					null,
colonne		varchar(30)		not null,
valchar		varchar(1500)		null,
valint		int					null,
valdec		numeric(30,14)		null,
valdate		datetime			null,
ident		numeric(14,0)	identity
)

if @pieceorg != null
begin
	insert into #plus (tableorg,tablecode,tableseq,colonne,valchar,valint,valdec,valdate)
	select PLUTABLE,PLUTABLECODE,PLUTABLESEQ,PLUCOL,PLUVALCHAR,PLUVALINT,PLUVALDEC,PLUVALDATE
	from FPLUS
	where PLUTABLECODE = @pieceorg
end
else if @seqorg != null
begin
	insert into #plus (tableorg,tablecode,tableseq,colonne,valchar,valint,valdec,valdate)
	select PLUTABLE,PLUTABLECODE,PLUTABLESEQ,PLUCOL,PLUVALCHAR,PLUVALINT,PLUVALDEC,PLUVALDATE
	from FPLUS
	where PLUTABLESEQ = @seqorg
end


declare pieces cursor 
for select tableorg,tablecode,tableseq,colonne,valchar,valint,valdec,valdate,ident
from #plus
for read only

open pieces

fetch pieces
into @tableorg,@tablecode,@tableseq,@colonne,@valchar,@valint,@valdec,@valdate,@ident

while (@@sqlstatus = 0)
	begin

	select @count = 0
	
	select @count = count(*) from KPLUS
	where KPLUTABLE = @fichiercible
	and KPLUCOL = @colonne
		
	if @count > 0
	begin
		select @pluseq = max(PLUSEQ)+1 from FPLUS
	
		insert into FPLUS (PLUSEQ,PLUDATECREA,PLUDATEMODIF,PLUUSERCREA,PLUUSERMODIF,PLUTABLE,PLUTABLECODE,
							PLUTABLESEQ,PLUCOL,PLUVALCHAR,PLUVALINT,PLUVALDEC,PLUVALDATE)
		values (@pluseq,getdate(),getdate(),@user,@user,@fichiercible,@piececible,
				@seqcible,@colonne,@valchar,@valint,@valdec,@valdate)
	end
	
	fetch pieces
	into @tableorg,@tablecode,@tableseq,@colonne,@valchar,@valint,@valdec,@valdate,@ident
	
end

close pieces
deallocate cursor pieces

end



go

