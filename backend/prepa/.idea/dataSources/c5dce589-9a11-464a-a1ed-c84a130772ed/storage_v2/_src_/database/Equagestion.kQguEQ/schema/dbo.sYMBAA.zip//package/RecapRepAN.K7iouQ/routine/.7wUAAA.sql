


/* Attention, cette procedure force l''index date de FFA portant sur FADATE */
/* Elle ne porte que sur le VRP central */

create procedure RecapRepAN (@ent	char(5)	= null,
							 @rep 	char(8),
							 @an 	int)
with recompile
as
begin

set arithabort numeric_truncation off


declare @mois 		tinyint,
		@datedeb	datetime,
		@datefin	datetime

select  @datedeb=convert(varchar(4),@an)+"0101",
		@datefin=convert(varchar(4),@an)+"1231"



create table #Recap
(
mois			tinyint				null,
ca				numeric(14,2)		null,
marge			numeric(14,2)		null,
janvier			numeric(14,2)		null,
fevrier			numeric(14,2)		null,
mars			numeric(14,2)		null,
avril			numeric(14,2)		null,
mai				numeric(14,2)		null,
juin			numeric(14,2)		null,
juillet			numeric(14,2)		null,
aout			numeric(14,2)		null,
septembre		numeric(14,2)		null,
octobre			numeric(14,2)		null,
novembre		numeric(14,2)		null,
decembre		numeric(14,2)		null,
janvier_1		numeric(14,2)		null,
fevrier_1		numeric(14,2)		null,
mars_1			numeric(14,2)		null
)

create table #Mois
(
num		tinyint		null,
nom		varchar(12)	null
)

insert into #Mois values (1,"JANVIER")
insert into #Mois values (2,"FEVRIER")
insert into #Mois values (3,"MARS")
insert into #Mois values (4,"AVRIL")
insert into #Mois values (5,"MAI")
insert into #Mois values (6,"JUIN")
insert into #Mois values (7,"JUILLET")
insert into #Mois values (8,"AOUT")
insert into #Mois values (9,"SEPTEMBRE")
insert into #Mois values (10,"OCTOBRE")
insert into #Mois values (11,"NOVEMBRE")
insert into #Mois values (12,"DECEMBRE")


create table #Detail
(
an		int				null,
mois	tinyint			null,
aregler	numeric(14,2)	null
)

create table #Group
(
an		int				null,
mois	tinyint			null,
aregler	numeric(14,2)	null
)


insert into #Recap (mois,ca,marge)
select STMOIS,sum(STCAFA),sum(isnull(STCAFA,0)-isnull(STPR,0))
from FST
where STREP=@rep
and STAN=@an
and (@ent is null or STENT=@ent)
group by STMOIS


select @mois=1

while (@mois <=12)
begin
	delete from #Detail
	delete from #Group
	
	
	if @mois=1
		select  @datedeb=convert(varchar(4),@an)+"0101",
				@datefin=convert(varchar(4),@an)+"0131"
	else if @mois=2
		begin
		select  @datedeb=convert(varchar(4),@an)+"0201",
				@datefin=convert(varchar(4),@an)+"0301"
		select  @datefin=dateadd(dd,-1,@datefin)
		end
	else if @mois=3
		select  @datedeb=convert(varchar(4),@an)+"0301",
				@datefin=convert(varchar(4),@an)+"0331"
	else if @mois=4
		select  @datedeb=convert(varchar(4),@an)+"0401",
				@datefin=convert(varchar(4),@an)+"0430"
	else if @mois=5
		select  @datedeb=convert(varchar(4),@an)+"0501",
				@datefin=convert(varchar(4),@an)+"0531"
	else if @mois=6
		select  @datedeb=convert(varchar(4),@an)+"0601",
				@datefin=convert(varchar(4),@an)+"0630"
	else if @mois=7
		select  @datedeb=convert(varchar(4),@an)+"0701",
				@datefin=convert(varchar(4),@an)+"0731"
	else if @mois=8
		select  @datedeb=convert(varchar(4),@an)+"0801",
				@datefin=convert(varchar(4),@an)+"0831"
	else if @mois=9
		select  @datedeb=convert(varchar(4),@an)+"0901",
				@datefin=convert(varchar(4),@an)+"0930"
	else if @mois=10
		select  @datedeb=convert(varchar(4),@an)+"1001",
				@datefin=convert(varchar(4),@an)+"1031"
	else if @mois=11
		select  @datedeb=convert(varchar(4),@an)+"1101",
				@datefin=convert(varchar(4),@an)+"1130"
	else if @mois=12
		select  @datedeb=convert(varchar(4),@an)+"1201",
				@datefin=convert(varchar(4),@an)+"1231"

	
	insert into #Detail (an,mois,aregler)
	select datepart(yy,FATRDATE1),datepart(mm,FATRDATE1),sum(FAREGL1)
	from FFA (index date)
	where FADATE between @datedeb and @datefin
	and FAREP=@rep
	and (@ent is null or FAENT=@ent)
	group by datepart(yy,FATRDATE1),datepart(mm,FATRDATE1)
	
	insert into #Detail (an,mois,aregler)
	select datepart(yy,FATRDATE2),datepart(mm,FATRDATE2),sum(FAREGL2)
	from FFA (index date)
	where FADATE between @datedeb and @datefin
	and FAREP=@rep
	and FAREGL2 != 0
	and (@ent is null or FAENT=@ent)
	group by datepart(yy,FATRDATE2),datepart(mm,FATRDATE2)
	
	insert into #Detail (an,mois,aregler)
	select datepart(yy,FATRDATE3),datepart(mm,FATRDATE3),sum(FAREGL3)
	from FFA (index date)
	where FADATE between @datedeb and @datefin
	and FAREP=@rep
	and FAREGL3 != 0
	and (@ent is null or FAENT=@ent)
	group by datepart(yy,FATRDATE3),datepart(mm,FATRDATE3)
	
	insert into #Detail (an,mois,aregler)
	select datepart(yy,FATRDATE4),datepart(mm,FATRDATE4),sum(FAREGL4)
	from FFA (index date)
	where FADATE between @datedeb and @datefin
	and FAREP=@rep
	and FAREGL4 != 0
	and (@ent is null or FAENT=@ent)
	group by datepart(yy,FATRDATE4),datepart(mm,FATRDATE4)
	
	insert into #Group (an,mois,aregler)
	select an,mois,sum(aregler)
	from #Detail
	group by an,mois

	insert into #Recap (mois,janvier)
	select @mois,aregler
	from #Group
	where mois=1
	and an=@an
	
	insert into #Recap (mois,fevrier)
	select @mois,aregler
	from #Group
	where mois=2
	and an=@an
	
	insert into #Recap (mois,mars)
	select @mois,aregler
	from #Group
	where mois=3
	and an=@an
	
	insert into #Recap (mois,avril)
	select @mois,aregler
	from #Group
	where mois=4
	and an=@an
	
	insert into #Recap (mois,mai)
	select @mois,aregler
	from #Group
	where mois=5
	and an=@an
	
	insert into #Recap (mois,juin)
	select @mois,aregler
	from #Group
	where mois=6
	and an=@an
	
	insert into #Recap (mois,juillet)
	select @mois,aregler
	from #Group
	where mois=7
	and an=@an
	
	insert into #Recap (mois,aout)
	select @mois,aregler
	from #Group
	where mois=8
	and an=@an
	
	insert into #Recap (mois,septembre)
	select @mois,aregler
	from #Group
	where mois=9
	and an=@an
	
	insert into #Recap (mois,octobre)
	select @mois,aregler
	from #Group
	where mois=10
	and an=@an
	
	insert into #Recap (mois,novembre)
	select @mois,aregler
	from #Group
	where mois=11
	and an=@an
	
	insert into #Recap (mois,decembre)
	select @mois,aregler
	from #Group
	where mois=12
	and an=@an
	
	insert into #Recap (mois,janvier_1)
	select @mois,aregler
	from #Group
	where mois=1
	and an=@an+1
	
	insert into #Recap (mois,fevrier_1)
	select @mois,aregler
	from #Group
	where mois=2
	and an=@an+1
	
	insert into #Recap (mois,mars_1)
	select @mois,aregler
	from #Group
	where mois=3
	and an=@an+1

	select @mois=@mois+1
end

drop table #Detail
drop table #Group


select num,nom,sum(ca),"",
		sum(marge),round((sum(marge)*abs(sign(sum(ca))))/(sum(ca)+(1-abs(sign(sum(ca))))),2)*100,"",
		sum(janvier),sum(fevrier),sum(mars),
		sum(avril),sum(mai),sum(juin),
		sum(juillet),sum(aout),sum(septembre),
		sum(octobre),sum(novembre),sum(decembre),
		sum(janvier_1),sum(fevrier_1),sum(mars_1)
from #Recap,#Mois
where num*=mois
group by num,nom
order by num
compute sum(sum(ca)),sum(sum(marge)),
		sum(sum(janvier)),sum(sum(fevrier)),sum(sum(mars)),
		sum(sum(avril)),sum(sum(mai)),sum(sum(juin)),
		sum(sum(juillet)),sum(sum(aout)),sum(sum(septembre)),
		sum(sum(octobre)),sum(sum(novembre)),sum(sum(decembre)),
		sum(sum(janvier_1)),sum(sum(fevrier_1)),sum(sum(mars_1))

drop table #Mois
drop table #Recap

end



go

