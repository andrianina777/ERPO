/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.b_getListRayon_DIG

*/


CREATE PROCEDURE dbo.b_getListRayon_DIG (@cmd char(10),@Rayon varchar(150) output)


AS
begin
	declare @xRayon char(8)
			
			 
	select @Rayon=''
	
	declare liste cursor for 
	/*select rtrim(AREEMP) from FCCL inner join FARE on CCLARTICLE=AREAR where AREDEPOT='DET' and ARERECEP=1 and AREVALID=1 and CCLCODE=rtrim(@cmd)
	group by AREEMP order by AREEMP*/
	/*select rtrim(Descrip) from FCCL inner join FARE on CCLARTICLE=AREAR inner join xRAYON_CORRESP on rtrim(Rayon)=rtrim(AREEMP)
	where AREDEPOT='DET' and ARERECEP=1 and AREVALID=1 and CCLCODE=@cmd
	group by Descrip order by Descrip*/
	
	select rtrim(DESCRIP) from FCCL inner join FARE on CCLARTICLE=AREAR left join xEMP_DIGUEL on xARTICLE=AREAR and xDEPOTL=AREDEPOT and xEMPL=AREEMP left join xCorrespRAYON_DIGUE on ALLEE=xALLEL and DEPOT=xDEPOTL
	where AREDEPOT in (select DPCODE from FDP where DPCENTRAL=1 and xDPVTE=1 and isnull(DPCOLIS,0)=0) and ARERECEP=1 and AREVALID=1 and CCLCODE=@cmd
	group by DESCRIP order by DESCRIP
	
	open liste
    fetch liste into @xRayon
    while (@@sqlstatus=0)
        begin
        if(@Rayon<>'')
       		begin
        		select @Rayon=rtrim(rtrim(@Rayon)+'-'+rtrim(@xRayon))
        	end
        else
        	begin
        		select @Rayon=''+rtrim(@xRayon)
        	end
        fetch liste into @xRayon    
        end
   close liste
   deallocate cursor liste
			
end
go

