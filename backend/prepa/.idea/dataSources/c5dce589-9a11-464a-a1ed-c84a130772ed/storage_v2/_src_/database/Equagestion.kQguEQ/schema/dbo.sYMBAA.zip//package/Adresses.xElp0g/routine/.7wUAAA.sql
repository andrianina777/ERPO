



create procedure Adresses (@ent	char(5)	= null)
as
begin

create table #Adresses
(
client	char(12)	not null,
nom		varchar(50)	not null,
adr1	varchar(50)		null,
adr2	varchar(50)		null,
cp		varchar(50)		null,
ville	varchar(30)		null,
codepy	char(8)			null,
pays	varchar(50)		null,
type	varchar(50)		null
)

insert into #Adresses
select CLCODE,isnull(CLNOM1,''),CLADR1,CLADR2,CLCP,CLVILLE,CLPY,CLPAYS,Type="Adr - Principale"
from FCL
where (@ent is null or CLENT=@ent)
union
select isnull(ADRCODELI,''),isnull(ADRNOM,''),ADRADR1,ADRADR2,ADRCP,ADRVILLE,ADRPY,ADRPAYS,
		(case when ADRTYPEADR="LI" then "Livraison"
			  when ADRTYPEADR="FA" then "Facturation"
			  else "?" 
		 end)
from FADR
where (@ent is null or ADRCODELIENT=@ent)
order by CLCODE

select client,nom,adr1,adr2,cp,ville,codepy,pays,type
from #Adresses
order by client,type

drop table #Adresses
end




go

