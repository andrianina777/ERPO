





/*
Verification des quantites a reserver.
Procedure utilisee par le module """"Reservations et Expeditions""""
		Cette procedure utilise la table FVerifExp			
*/

create procedure VerifRes  (@ent				char(5) = null,
							@process			int
						   )
with recompile
as
begin

declare @count	int,
		@site	int
		
select @site=KISITE from KInfos

create table #Final
(
seq			numeric(14,0)	identity,
code		char(15)		not null,
qteARes		int				not null,
comment		varchar(70)		not null,
qteSt		int				not null,
gravite		tinyint			not null
)


/*--------- Verification des reservations     ----------*/


create table #Stock
(
artSt		char(15)	not null,	/* code article */
qteSt		int			not null,	/* stock total sur l''''article */
qteStRes	int			not null	/* quantite totale reservee sur l''''article */
)

create table #Res
(
artRes		char(15)	not null,
qteRes		int			not null,
qteARes		int			not null
)

insert into #Stock (artSt,qteSt,qteStRes)
select ARTICLE,STOCK,STOCKRES
from FVerifExp, FAR
where ARCODE=ARTICLE
and ARTYPE=0
and SPID=@process
group by ARTICLE,STOCK,STOCKRES


insert into #Res (artRes,qteRes,qteARes)
select ARTICLE,sum(QTERES),sum(QTEARES)
from FVerifExp, FAR
where ARCODE=ARTICLE
and ARTYPE=0
and SPID=@process
group by ARTICLE



select @count=count(*) from #Res,#Stock
where artRes=artSt
and qteSt - qteStRes + qteRes < qteARes
and qteARes > 0


if @count>0
  begin
  	insert into #Final (code,qteARes,comment,qteSt,gravite)
	select artRes,qteARes,"Reservation   -> Stock disponible insuffisant",(case when qteSt - qteStRes + qteRes > 0 then qteSt - qteStRes + qteRes else 0 end),2 			/* erreur bloquante */
		from #Res,#Stock
		where artRes=artSt
		and qteSt - qteStRes + qteRes < qteARes
		and qteARes > 0
		order by artRes
		
	insert into #Final (code,qteARes,comment,qteSt,gravite)
	select "--------",0,"----------------------------------------",0,0
	
  end


/* Renvoi final */

select code,qteARes,comment,qteSt,gravite
from #Final
order by seq


drop table #Final
drop table #Stock
drop table #Res

end



go

