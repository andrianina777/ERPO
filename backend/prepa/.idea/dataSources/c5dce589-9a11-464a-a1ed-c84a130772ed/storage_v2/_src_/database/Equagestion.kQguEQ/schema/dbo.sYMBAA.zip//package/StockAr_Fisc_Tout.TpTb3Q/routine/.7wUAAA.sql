CREATE PROCEDURE dbo.StockAr_Fisc_Tout

AS
begin

        declare @article varchar(50),@depot varchar(50)
        
        
        /*select article, count(distinct depot)as depot 
        into #article_fini
        from  DBSUIVI..FICHE_STOCK 
        group by article order by article
        */

        --select ARCODE from FAR  where  (ARCODE not like 'A%' and ARCODE not like 'B%' ) order by ARCODE
        /*tout les article*/
        declare liste cursor for select ARCODE from FAR where  LEFT(ARCODE,1) not in ('A','B','C','D','E','F','G','H','I','J','K') order by ARCODE
        open liste 
        fetch liste into @article
        while (@@sqlstatus=0)
        begin
                /*parcourir depot*/
                declare liste_depot cursor for select DPCODE from FDP
                open liste_depot
                fetch liste_depot into @depot
                while (@@sqlstatus=0)
                begin
                        exec StockAR_Fisc @article,'01/01/2019',@depot,null
                        fetch liste_depot into @depot
                end
                close liste_depot
                deallocate cursor liste_depot
                
                
                fetch liste into @article
        end
        close liste
        deallocate cursor liste
end
go

