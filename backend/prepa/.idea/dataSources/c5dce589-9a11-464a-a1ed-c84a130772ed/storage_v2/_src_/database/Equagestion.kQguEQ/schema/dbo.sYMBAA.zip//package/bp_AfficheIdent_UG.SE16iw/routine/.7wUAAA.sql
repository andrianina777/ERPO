/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_AfficheIdent_UG
grant execute on bp_AfficheIdent_UG to public
*/

CREATE PROCEDURE dbo.bp_AfficheIdent_UG(@datedeb smalldatetime,@datefin smalldatetime,@labo char(8),@article char(15),@isTous int,@codeBL char(10),@codePR char(10))

AS
begin


	if(@isTous=0)
	begin
		select BLLAR,ARLIB,ARFO,BLLFO,sum(BLLQTE) as BLLQTE,BLLCODE,convert(date,BLLDATE) as BLLDATE,BLLFACT,xRAISON,xDATE_DEB,xDATE_FIN,xCOM
		from FBLL_UG,FBLL,VIEW_FAR_TOUS
		where BLLSEQ=xBLLSEQ
		and ARCODE=BLLAR
		and (ARFO=@labo or @labo=null or @labo='')
		and (BLLAR=@article or @article=null or @article='')
		and (BLLCODE=@codeBL or @codeBL=null or @codeBL='')
		and (BLLFACT=@codePR or @codePR=null or @codePR='')
		and ((BLLDATE between @datedeb and @datefin) or @datefin=null or @datefin='' or @datedeb=null or @datedeb='')
		group by convert(date,BLLDATE),BLLAR,ARLIB,xRAISON,xDATE_DEB,xDATE_FIN,xCOM,BLLCODE,ARFO,BLLFACT,BLLFO
	end
	else if(@isTous=1)
	begin
		select BLLAR,ARLIB,ARFO,BLLFO,sum(BLLQTE) as BLLQTE,BLLCODE,convert(date,BLLDATE) as BLLDATE,BLLFACT,xRAISON,xDATE_DEB,xDATE_FIN,xCOM
		from FBLL_UG,FBLL,VIEW_FAR_TOUS
		where BLLSEQ=xBLLSEQ
		and ARCODE=BLLAR
		and (ARFO=@labo or @labo=null or @labo='')
		and (BLLAR=@article or @article=null or @article='')
		and (BLLCODE=@codeBL or @codeBL=null or @codeBL='')
		and (BLLFACT=@codePR or @codePR=null or @codePR='')
		and ((BLLDATE between @datedeb and @datefin) or @datefin=null or @datefin='' or @datedeb=null or @datedeb='')
		and isnull(xRAISON,'')<>''
		group by convert(date,BLLDATE),BLLAR,ARLIB,xRAISON,xDATE_DEB,xDATE_FIN,xCOM,BLLCODE,ARFO,BLLFACT,BLLFO
	end
	else if(@isTous=2)
	begin
		select BLLAR,ARLIB,ARFO,BLLFO,sum(BLLQTE) as BLLQTE,BLLCODE,convert(date,BLLDATE) as BLLDATE,BLLFACT,xRAISON,xDATE_DEB,xDATE_FIN,xCOM
		from FBLL_UG,FBLL,VIEW_FAR_TOUS
		where BLLSEQ=xBLLSEQ
		and ARCODE=BLLAR
		and (ARFO=@labo or @labo=null or @labo='')
		and (BLLAR=@article or @article=null or @article='')
		and (BLLCODE=@codeBL or @codeBL=null or @codeBL='')
		and (BLLFACT=@codePR or @codePR=null or @codePR='')
		and ((BLLDATE between @datedeb and @datefin) or @datefin=null or @datefin='' or @datedeb=null or @datedeb='')
		and isnull(xRAISON,'')=''
		group by convert(date,BLLDATE),BLLAR,ARLIB,xRAISON,xDATE_DEB,xDATE_FIN,xCOM,BLLCODE,ARFO,BLLFACT,BLLFO
	end
end
go

