


/* Procedure utilisee par le requeteur ""Statistiques Articles plus"" */

create procedure StatARplus (@ent			char(5)		= null,
						 	 @fournisseur	char(12),
							 @famille		char(8)		= null,
							 @article		char(15) 	= null,
							 @ancien		tinyint		= null,
							 @depot			char(4)		= null,
							 @depexclus		char(4)		= null,
							 @chefp			char(8)		= null
							)
with recompile
as
begin

set arithabort numeric_truncation off


declare @An		smallint,
		@mois	tinyint
		
select 	@An = datepart(yy,getdate()),
		@mois = datepart(mm,getdate())

declare @date1	datetime,
		@date2	datetime
		
select @date1=convert(datetime,"01/01/"+convert(varchar,@An))
select @date2=convert(datetime,"12/31/"+convert(varchar,@An))




	create table #liste
	(
		codeart 	char(15) 	not null,
		arfour 		varchar(40) 	null,
		arfam		char(8)			null,
		archefp		char(8)			null,
		valeur 		numeric(14,2)	null,
		designation varchar(80) 	null,
		annee 		int 			null,
		stock 		int 			null,
		stockdouane int 			null,
		cdefour 	int 			null,
		bllfour		int				null,
		belafact	int				null
	)


	/* lecture des articles */
	
if ((@article is null) and (@famille is null))
	begin
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,annee)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,sum(STQTEFA)
		from FAR,FST
		where START=*ARCODE
		and STAN=@An
		and ARFO=@fournisseur
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARPADEV,ARLIB
	end
else if ((@article is null) and (@famille is not null))
	begin
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,annee)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,sum(STQTEFA)
		from FAR,FST
		where START=*ARCODE
		and STAN=@An
		and ARFO=@fournisseur
		and ARFAM=@famille
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB
	end
else if ((@article is not null) and (@famille is null))
	begin
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,annee)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,sum(STQTEFA)
		from FAR,FST
		where START=*ARCODE
		and STAN=@An
		and ARFO=@fournisseur
		and ARCODE=@article
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB
	end	
else if ((@article is not null) and (@famille is not null))
	begin	
		insert into #liste (codeart,arfour,arfam,archefp,valeur,designation,annee)
		select ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB,sum(STQTEFA)
		from FAR,FST
		where START=*ARCODE
		and STAN=@An
		and ARFO=@fournisseur
		and ARCODE=@article
		and ARFAM=@famille
		and (@chefp is null or ARCHEFP = @chefp)
		and (isnull(@ancien,0)=1 or AROLD=0)
		and (@ent is null or STENT=@ent)
		group by ARCODE,ARREFFOUR,ARFAM,ARCHEFP,ARPADEV,ARLIB
	end

	create index article on #liste(codeart)

	select STAR,Depot=DPLOC,Qte=sum(STQTE)
	into #Stock
	from #liste,FSTOCK,FDP
	where STAR=#liste.codeart
	and STQTE > 0
	and (@depot is null or STDEPOT=@depot)
	and (@depexclus is null or STDEPOT != @depexclus)
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by STAR,DPLOC
	
	update #liste
	set stock=#Stock.Qte
	from #Stock
	where STAR=#liste.codeart
	and Depot=1
	
	update #liste
	set stockdouane=(select sum(#Stock.Qte)
					 from #Stock
					 where STAR=#liste.codeart
					 and Depot != 1)
	
	drop table #Stock
			

	update #liste
	set cdefour=(select sum(RCFQTE)
			 from FRCF
			 where RCFARTICLE=#liste.codeart
			 and (@ent is null or RCFENT=@ent))
	
	update #liste
	set bllfour=(select sum(BLLQTE)
			 from FBLL
			 where BLLAR=#liste.codeart
			 and BLLDATE between @date1 and @date2
			 and (@ent is null or BLLENT=@ent))
	
	update #liste
	set belafact=(select sum(RBEQTE)
			 from FRBE
			 where RBEARTICLE=#liste.codeart
			 and (@ent is null or RBEENT=@ent))
	
	
		
	select Code_Article=codeart,Designation=designation,Ref_Fourn=arfour,
		EntreesBL=isnull(bllfour,0),Ventes_Annee_en_cours=isnull(annee,0),
		Stock=isnull(stock,0),Stock_Douane=isnull(stockdouane,0),
		Cde_Fourn=isnull(cdefour,0),Exp_non_fact=isnull(belafact,0)
	from #liste
	order by codeart
			
			
	drop table #liste
	
end	



go

