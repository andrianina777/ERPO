


create procedure StockChef	(@ent	char(5)	= null,
							 @chef	char(8))
with recompile
as
begin

set arithabort numeric_truncation off


create table #Lignes
(
fourn		char(12)		not null,
marque		char(12)		not null,
stock		numeric(14,2)		null,
ventes		numeric(14,2)		null
)

create table #Final
(
fourn		char(12)		not null,
marque		char(12)		not null,
stock		numeric(14,2)		null,
ventes		numeric(14,2)		null,
rapport		numeric(14,2)		null
)

insert into #Lignes (fourn,marque,stock,ventes)
select STFO,ARFO,sum(STQTE*((STPAHT+STFRAIS)/CVLOT)),0.00
from FSTOCK,FAR,FCV,FDP
where ARCODE=STAR
and ARUNITACHAT=CVUNIF
and ARCHEFP=@chef
and STQTE >0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by STFO,ARFO

insert into #Lignes (fourn,marque,stock,ventes)
select STFO,ARFO,0.00,sum(FALTOTALHT)
from FFAL,FSTOCK,FAR,FDP
where ARCODE=FALARTICLE
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and ARCHEFP=@chef
and datepart(yy,FALDATE)=datepart(yy,getdate())
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by STFO,ARFO

insert into #Final (fourn,marque,stock,ventes)
select fourn,marque,sum(stock),sum(ventes)
from #Lignes
group by fourn,marque

update #Final
set rapport = isnull(stock,0)
where isnull(ventes,0) = 0

update #Final
set rapport = (convert(numeric(14,2),ventes/convert(numeric(14,2),stock)))
where isnull(stock,0) != 0

update #Final
set rapport = 0
where rapport is null


select "Fournisseur","Marque","Valeur Stock","Ventes de l'annee","Ratio Ventes/Stock"
select fourn,marque,isnull(stock,0),isnull(ventes,0),rapport
from #Final
order by fourn,marque

drop table #Lignes
drop table #Final

end



go

