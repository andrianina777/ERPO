/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheReste_DET
grant execute on bp_afficheReste_DET to public
*/

CREATE PROCEDURE bp_afficheReste_DET(@is_tous int,@empl char(10),@cNormal int,@cFroid int,@cFrais int,@sNormal int,@sStup int,@sPsy int)
with recompile
AS
begin


	select STEMPAR, STEMPDEPOT,STEMPQTE, STLOT,VIEW_FAR.ARLIB as ARLIB,isnull(xNB_BOITE_DET,0) as xNB_BOITE_DET,STEMPEMP,STLETTRE,ARESSEMP,
	(case when isnull(VIEW_FAR.xARTP_FROID,0)=1 then 'Froid' when isnull(VIEW_FAR.xARTP_FROID,0)=2 then 'Frais' else 'Normal' end) as conservation,
	(case when isnull(VIEW_FAR.xARTP_STATSPEC,0)=1 then 'Stupefiant' when isnull(VIEW_FAR.xARTP_STATSPEC,0)=2 then 'Psychotrope' else 'Normal' end) as statut
    into #VIEW_STOCK_LOT_EMPLACEMENT
    from VIEW_STOCK_LOT_EMPLACEMENT   inner join VIEW_FAR on VIEW_FAR.ARCODE=STEMPAR
    where  STEMPDEPOT='DET'  and (@empl=null or @empl='' or STEMPEMP=@empl)
    and (isnull(VIEW_FAR.xARTP_FROID,0)=(case when @cNormal=1 then 0 else 3 end) or isnull(VIEW_FAR.xARTP_FROID,0)=(case when @cFroid=1 then 1 else 3 end) or 
    isnull(VIEW_FAR.xARTP_FROID,0)=(case when @cFrais=1 then 2 else 3 end)) and
    (isnull(VIEW_FAR.xARTP_STATSPEC,0)=(case when @sNormal=1 then 0 else 3 end) or isnull(VIEW_FAR.xARTP_STATSPEC,0)=(case when @sStup=1 then 1 else 3 end) or 
    isnull(VIEW_FAR.xARTP_STATSPEC,0)=(case when @sPsy=1 then 2 else 3 end))

    delete from #VIEW_STOCK_LOT_EMPLACEMENT where ARESSEMP='DIGUE' or STEMPEMP in (select distinct PORTE from xCorrespRAYON_DIGUE where DEPOT='DET')
	
 	select STEMPAR, STEMPDEPOT, STLOT,ARLIB,sum(STEMPQTE) as STEMPQTE,xNB_BOITE_DET as NB_BOITE,STEMPEMP,
 	(case when xNB_BOITE_DET=0 then 0 when sum(STEMPQTE)%xNB_BOITE_DET=0 then convert(int,(sum(STEMPQTE)/xNB_BOITE_DET)) else convert(int,(sum(STEMPQTE)/xNB_BOITE_DET))+1 end) as NB_EMP_TOTAL,
 	conservation,statut
 	into #result
	from #VIEW_STOCK_LOT_EMPLACEMENT 
	group by STEMPAR, STEMPDEPOT, STLOT,xNB_BOITE_DET,ARLIB,conservation,statut,STEMPEMP
	
	
	select STEMPAR, STEMPDEPOT, STLOT,ARLIB,sum(STEMPQTE) as STEMPQTE,xNB_BOITE_DET as NB_BOITE,STEMPEMP,
 	(case when xNB_BOITE_DET=0 then 0 when sum(STEMPQTE)%xNB_BOITE_DET=0 then convert(int,(sum(STEMPQTE)/xNB_BOITE_DET)) else convert(int,(sum(STEMPQTE)/xNB_BOITE_DET))+1 end) as NB_LIGNE,
 	conservation,statut
 	into #result2
	from #VIEW_STOCK_LOT_EMPLACEMENT 
	group by STEMPAR, STEMPDEPOT, STLOT,xNB_BOITE_DET,ARLIB,conservation,statut,STLETTRE,STEMPEMP
	
	select STEMPAR,ARLIB,STEMPDEPOT,sum(STEMPQTE) as QUANTITE,NB_BOITE,sum(NB_EMP_TOTAL) as NB_EMP_TOTAL,conservation,statut,STEMPEMP  into #result1 from #result  group by STEMPAR,ARLIB,STEMPDEPOT,NB_BOITE,conservation,statut,STEMPEMP
	 	
	select STEMPAR,sum(NB_LIGNE) as NB_LIGNE  into #result3 from #result2  group by STEMPAR,ARLIB,STEMPDEPOT,NB_BOITE
	
	 
	 if(@is_tous=0)
	 begin
		select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR order by #result1.STEMPAR
	 end
	 else if(@is_tous=1)
	 begin
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  NB_BOITE>0  order by #result1.STEMPAR
	 end
	 else if(@is_tous=2)
	 begin
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  NB_BOITE=0  order by #result1.STEMPAR
	 end
	/* else if(@is_tous=3)
	 begin
	 	
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  conservation='Normal' order by #result1.STEMPAR
	 	
	 end
	 else if(@is_tous=4)
	 begin
	 	
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  conservation='Froid' order by #result1.STEMPAR
	 	
	 end
	  else if(@is_tous=5)
	 begin
	 	 	
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  conservation='Frais' order by #result1.STEMPAR
	 	
	 end
	 else if(@is_tous=6)
	 begin
	 	
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  statut='Normal' order by #result1.STEMPAR
	 	
	 end
	 else if(@is_tous=7)
	 begin
	 	
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  statut='Stupefiant' order by #result1.STEMPAR
	 	
	 end
	  else if(@is_tous=8)
	 begin
	 	 	
	 	select #result1.STEMPAR,ARLIB,STEMPDEPOT,STEMPEMP,conservation,statut,QUANTITE,NB_BOITE,NB_EMP_TOTAL,NB_LIGNE from #result1 inner join #result3 on #result3.STEMPAR=#result1.STEMPAR where  statut='Psychotrope' order by #result1.STEMPAR
	 	
	 end*/
	 
	 drop table #VIEW_STOCK_LOT_EMPLACEMENT
	 drop table #result
	 drop table #result1
	 drop table #result2
	 drop table #result3
	 	
end
go

