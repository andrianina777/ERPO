create PROCEDURE bp_PSpecial_FCCL(
		@cccode char(10))
with recompile
AS
begin
	 declare
	 	@is_stup int,
	 	@is_psy int
	 	
		select @is_stup=(case  when SA_STUP=1 then null when SA_STUP=0 then 1 else 1 end),
			   @is_psy=(case  when SA_PSY=1 then null  when SA_PSY=0 then 2 else 2 end) 
		from FSA inner join FCL on SACODE=CLSA  inner join FCC on CCCLIENT=CLCODE where CCCODE=@cccode
		
		if (@is_stup<>null or @is_psy<>null)
			begin
				select CCLARTICLE,ARLIB,CCLQTE, (case when xFARTYPE.xARTP_STATSPEC=1 then 'Stupefiant' when xFARTYPE.xARTP_STATSPEC=2 then 'Psychotrope'else '' end) as xStatut,CCLNUM
				from FCCL inner join xFARTYPE on CCLARTICLE=xFARTYPE.xARTP_ARCODE inner join VIEW_FAR on CCLARTICLE=ARCODE 
				where CCLCODE=@cccode and (xFARTYPE.xARTP_STATSPEC=@is_stup or xFARTYPE.xARTP_STATSPEC=@is_psy) order by xStatut
			end
end
go

