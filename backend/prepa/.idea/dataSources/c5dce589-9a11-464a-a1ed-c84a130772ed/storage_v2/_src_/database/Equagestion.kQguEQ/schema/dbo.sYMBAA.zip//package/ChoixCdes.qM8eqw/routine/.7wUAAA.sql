


create procedure ChoixCdes (@ent		char(5) = null,
							@article 	char(15),
							@fournis 	char(12),
							@source		tinyint,		/* 0 = CF depuis BL ou BP, 1 = CS depuis BL, 2 = BPR depuis BL, 3 = modif depuis BPR */
							@cde		char(10) = null
							)
with recompile
as
begin

if @cde = ''
	select @cde = null

create table #Cdes
(
article	char(15)	not null,
qte 	int			not null,
recu	int		 	not	null,
reste	int			not	null,
code 	char(10)	not null,
num 	int 	 	not null
)


if @source = 0
begin
  insert into #Cdes (article,qte,recu,reste,code,num)
  select CBFARTICLE,0,0,sum(-CBFQTE),CBFCODE,CBFNUM
  from FCBF
  where CBFARTICLE=@article
  and CBFSPID=@@spid
  and (@ent is null or CBFENT=@ent)
  group by CBFARTICLE,CBFCODE,CBFNUM
  having sum(-CBFQTE) != 0
  union
  select CFLARTICLE,CFLQTE,CFLRECU,CFLRESTE,CFLCODE,CFLNUM
  from FRCF,FCFL,FCF
  where RCFSEQ=CFLSEQ
  and RCFARTICLE=@article
  and RCFFO=@fournis
  and CFCODE=CFLCODE
  and CFVALIDE=0
  and (@cde is null or CFLCODE=@cde)
  and (@ent is null or (RCFENT=@ent and CFLENT=@ent and CFENT=@ent))
  
  select article,sum(qte),sum(recu),sum(reste),code,num,CFLDATEP,CFLLIBRE,CFLDEPOT,CFLSTADE,CFLREFFO
  from #Cdes,FCFL
  where code=CFLCODE
  and num=CFLNUM+0
  and (@ent is null or CFLENT=@ent)
  group by article,code,num,CFLDATEP,CFLLIBRE,CFLDEPOT,CFLSTADE,CFLREFFO
  having sum(reste) > 0
  order by CFLDATEP 
end
else if @source = 1
begin
  insert into #Cdes (article,qte,recu,reste,code,num)
  select CBFARTICLE,0,0,sum(-CBFQTE),CBFCODE,CBFNUM
  from FCBF
  where CBFARTICLE=@article
  and CBFSPID=@@spid
  and (@ent is null or CBFENT=@ent)
  group by CBFARTICLE,CBFCODE,CBFNUM
  having sum(-CBFQTE) != 0
  union
  select CSLARTICLE,CSLQTE,CSLRECU,CSLRESTE,CSLCODE,CSLNUM
  from FRCS,FCSL,FCS
  where RCSSEQ=CSLSEQ
  and RCSARTICLE=@article
  and RCSFO=@fournis
  and CSCODE=CSLCODE
  and CSVALIDE=0
  and (@cde is null or CSLCODE=@cde)
  and (@ent is null or (RCSENT=@ent and CSLENT=@ent and CSENT=@ent))
  
  select article,sum(qte),sum(recu),sum(reste),code,num,CSLDELAI,CSLOPCODE
  from #Cdes,FCSL
  where code=CSLCODE
  and num=CSLNUM+0
  and (@ent is null or CSLENT=@ent)
  group by article,code,num,CSLDELAI,CSLOPCODE
  having sum(reste) > 0
  order by CSLDELAI
end
else if @source = 2
begin
  insert into #Cdes (article,qte,recu,reste,code,num)
  select CBFARTICLE,0,0,sum(-CBFQTE),CBFCODE,CBFNUM
  from FCBF
  where CBFARTICLE=@article
  and CBFSPID=@@spid
  and (@ent is null or CBFENT=@ent)
  group by CBFARTICLE,CBFCODE,CBFNUM
  having sum(-CBFQTE) != 0
  union
  select CFLARTICLE,CFLQTE,CFLRECU,CFLRESTE,CFLCODE,CFLNUM
  from FRCF,FCFL,FCF,FBPRL
  where RCFSEQ=CFLSEQ
  and RCFARTICLE=@article
  and RCFFO=@fournis
  and CFCODE=CFLCODE
  and CFVALIDE=0
  and BPRLLIENCODE=CFLCODE
  and BPRLLIENNUM=CFLNUM
  and BPRLAR=CFLARTICLE
  and (@cde is null or BPRLCODE=@cde)
  and (@ent is null or (RCFENT=@ent and CFLENT=@ent and CFENT=@ent and BPRLENT=@ent))
  
  select article,sum(qte),sum(recu),sum(reste),code,num,CFLDATEP,CFLLIBRE,CFLDEPOT,CFLSTADE,CFLREFFO
  from #Cdes,FCFL
  where code=CFLCODE
  and num=CFLNUM+0
  and (@ent is null or CFLENT=@ent)
  group by article,code,num,CFLDATEP,CFLLIBRE,CFLDEPOT,CFLSTADE,CFLREFFO
  having sum(reste) > 0
  order by CFLDATEP 
end
else if @source = 3
begin
  insert into #Cdes (article,qte,recu,reste,code,num)
  select CBFARTICLE,0,0,sum(-CBFQTE),CBFCODE,CBFNUM
  from FCBF
  where CBFARTICLE=@article
  and CBFSPID=@@spid
  and (@ent is null or CBFENT=@ent)
  group by CBFARTICLE,CBFCODE,CBFNUM
  having sum(-CBFQTE) != 0
  union
  select CFLARTICLE,CFLQTE,CFLRECU+BPRLQTE,CFLRESTE-BPRLQTE,CFLCODE,CFLNUM
  from FRCF,FCFL,FCF,FBPRL
  where RCFSEQ=CFLSEQ
  and RCFARTICLE=@article
  and RCFFO=@fournis
  and CFCODE=CFLCODE
  and CFVALIDE=0
  and BPRLLIENCODE=CFLCODE
  and BPRLLIENNUM=CFLNUM
  and BPRLAR=CFLARTICLE
  and (@cde is null or BPRLCODE=@cde)
  and (@ent is null or (RCFENT=@ent and CFLENT=@ent and CFENT=@ent and BPRLENT=@ent))
  and not exists (select * from FCBF where CBFCODE=FCFL.CFLCODE and CBFNUM=FCFL.CFLNUM and CBFSPID=@@spid)
  
  select article,sum(qte),sum(recu),sum(reste),code,num,CFLDATEP,CFLLIBRE,CFLDEPOT,CFLSTADE,CFLREFFO
  from #Cdes,FCFL
  where code=CFLCODE
  and num=CFLNUM+0
  and (@ent is null or CFLENT=@ent)
  group by article,code,num,CFLDATEP,CFLLIBRE,CFLDEPOT,CFLSTADE,CFLREFFO
  having sum(reste) > 0
  order by CFLDATEP 
end


drop table #Cdes

end

go

