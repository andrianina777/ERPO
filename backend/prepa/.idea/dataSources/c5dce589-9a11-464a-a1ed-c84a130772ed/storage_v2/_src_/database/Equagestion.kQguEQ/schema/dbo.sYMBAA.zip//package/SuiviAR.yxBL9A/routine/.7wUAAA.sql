


/* Procedure permettant de suivre les mouvements d''un article par annee */

create procedure SuiviAR (@Article	char(15))
with recompile
as
begin

declare @lot	int

select @lot=CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARCODE=@Article

select Unite_achat_actuel=@lot


select 'Stock initial - Fluctuations - Fichier SIL'

select Article=SILARTICLE,Annee=datepart(yy,SILDATE),Mois=datepart(mm,SILDATE),
Total=sum(SILQTE),PrixRevientTot=sum(round((SILPAHT+SILFRAIS)/@lot,2)*SILQTE),
PRMoyen=round(sum(((SILPAHT+SILFRAIS)/@lot)*SILQTE)/sum(SILQTE),2),
Depot=SILNUMDEP,'F'
from FSIL
where SILARTICLE=@Article
and SILQTE!=0
group by SILARTICLE,datepart(yy,SILDATE),datepart(mm,SILDATE),SILNUMDEP
having sum(SILQTE)!=0
compute sum(sum(SILQTE)),sum(sum(round((SILPAHT+SILFRAIS)/@lot,2)*SILQTE))


select 'Reajustements - Fichier RJL'

select Article=RJLARTICLE,Annee=datepart(yy,RJLDATE),Mois=datepart(mm,RJLDATE),
Total=sum(RJLQTE),PrixRevientTot=sum(round((RJLPAHT+RJLFRAIS)/@lot,2)*RJLQTE),
PRMoyen=round(sum(((RJLPAHT+RJLFRAIS)/@lot)*RJLQTE)/sum(RJLQTE),2),
Depot=RJLNUMDEP,'R'
from FRJL
where RJLARTICLE=@Article
and RJLQTE!=0
group by RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),RJLNUMDEP
having sum(RJLQTE)!=0
compute sum(sum(RJLQTE)),sum(sum(round((RJLPAHT+RJLFRAIS)/@lot,2)*RJLQTE))


select 'Lignes de casse - Fichier LCL'

select Article=LCLARTICLE,Annee=datepart(yy,LCLDATE),Mois=datepart(mm,LCLDATE),
Total=sum(LCLQTE),PrixRevientTot=sum(round((LCLPAHT+LCLFRAIS)/@lot,2)*LCLQTE),
PRMoyen=round(sum(((LCLPAHT+LCLFRAIS)/@lot)*LCLQTE)/sum(LCLQTE),2),
Depot=LCLNUMDEP,'C'
from FLCL
where LCLARTICLE=@Article
and LCLQTE!=0
group by LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),LCLNUMDEP
having sum(LCLQTE)!=0
compute sum(sum(LCLQTE)),sum(sum(round((LCLPAHT+LCLFRAIS)/@lot,2)*LCLQTE))


select 'Assemblage Desassemblage - Fichier ASL'

select Article=ASLARTICLE,Annee=datepart(yy,ASLDATE),Mois=datepart(mm,ASLDATE),
Total=sum(ASLQTE),PrixRevientTot=sum((ASLPAHT+ASLFRAIS)*ASLQTE),
PRMoyen=round(sum((ASLPAHT+ASLFRAIS)*ASLQTE)/sum(ASLQTE),2),
Depot=ASLNUMDEP,'A'
from FASL
where ASLARTICLE=@Article
and ASLQTE!=0
group by ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),ASLNUMDEP
having sum(ASLQTE)!=0
compute sum(sum(ASLQTE)),sum(sum((ASLPAHT+ASLFRAIS)*ASLQTE))


select 'Reajustements des mouvements uniquement - Fichier RM'

select Article=RMARTICLE,Annee=datepart(yy,RMDATE),Mois=datepart(mm,RMDATE),
Total=sum(RMQTE),PrixRevientTot=sum(round((RMPAHT+RMFRAIS)/@lot,2)*RMQTE),
PRMoyen=round(sum(((RMPAHT+RMFRAIS)/@lot)*RMQTE)/sum(RMQTE),2),
Depot=RMNUMDEP,'M'
from FRM
where RMARTICLE=@Article
and RMQTE!=0
group by RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),RMNUMDEP
having sum(RMQTE)!=0
compute sum(sum(RMQTE)),sum(sum(round((RMPAHT+RMFRAIS)/@lot,2)*RMQTE))


select 'Bordereaux de livraisons Fournisseurs - Fichier BLL'

select Article=BLLAR,Annee=datepart(yy,BLLDATE),Mois=datepart(mm,BLLDATE),
Total=sum(BLLQTE),PrixRevientTot=sum(round((BLLPRHT)/@lot,2)*BLLQTE),
PRMoyen=round(sum(((BLLPRHT)/@lot)*BLLQTE)/sum(BLLQTE),2),
Depot=BLLNUMDEP,'E'
from FBLL
where BLLAR=@Article
and BLLQTE!=0
group by BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),BLLNUMDEP
having sum(BLLQTE)!=0
compute sum(sum(BLLQTE)),sum(sum(round((BLLPRHT)/@lot,2)*BLLQTE))

select 'Sorties de douanes & entrees magasin - Fichier DOL'

select Article=DOLAR,Annee=datepart(yy,DOLDATE),Mois=datepart(mm,DOLDATE),
Total=sum(DOLQTE),PrixRevientTot=sum(round((DOLPRHT)/@lot,2)*DOLQTE),
PRMoyen=round(sum(((DOLPRHT)/@lot)*DOLQTE)/sum(DOLQTE),2),
Depot=DOLNUMDEP,'E'
from FDOL
where DOLAR=@Article
and DOLQTE!=0
group by DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),DOLNUMDEP
compute sum(sum(DOLQTE)),sum(sum(round((DOLPRHT)/@lot,2)*DOLQTE))

select 'Retour des marchandises vers Fournisseurs - Fichier RFL'

select Article=RFLARTICLE,Annee=datepart(yy,RFLDATE),Mois=datepart(mm,RFLDATE),
Total=-(sum(RFLQTE)),PrixRevientTot=-(sum(round((RFLPAHT)/@lot,2)*RFLQTE)),
PRMoyen=round(-(sum(((RFLPAHT)/@lot)*RFLQTE))/-(sum(RFLQTE)),2),
Depot=RFLNUMDEP,'E'
from FRFL
where RFLARTICLE=@Article
and RFLQTE!=0
group by RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),RFLNUMDEP
having sum(RFLQTE)!=0
compute sum(-(sum(RFLQTE))),sum(-(sum(round((RFLPAHT)/@lot,2)*RFLQTE)))

select 'Factures - Fichier FAL'

select Article=FALARTICLE,Annee=datepart(yy,FALDATE),Mois=datepart(mm,FALDATE),
Total=sum(FALQTE),PrixRevientTot=sum(round((STPAHT+STFRAIS)/@lot,2)*FALQTE),
PRMoyen=round(sum(((STPAHT+STFRAIS)/@lot)*FALQTE)/sum(FALQTE),2),
Depot=1,'S'
from FFAL,FSTOCK
where FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALARTICLE=@Article
and FALQTE!=0
group by FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE)
having sum(FALQTE)!=0
compute sum(sum(FALQTE)),sum(sum(round((STPAHT+STFRAIS)/@lot,2)*FALQTE))

select "Lignes de BE de 1991 non factures"

select Article=BELARTICLE,Annee=datepart(yy,BELDATE),Mois=datepart(mm,BELDATE),
Total=-(sum(BELQTE)),PrixRevientTot=-(sum(round((STPAHT+STFRAIS)/@lot,2)*BELQTE)),
PRMoyen=round(-(sum(((STPAHT+STFRAIS)/@lot)*BELQTE))/-(sum(BELQTE)),2),
Depot=1,'R'
from FBEL,FSTOCK
where BELARTICLE=STAR
and BELLETTRE=STLETTRE
and BELQTE!=0
and BELARTICLE=@Article
and BELDATE<'01/01/92'
group by BELARTICLE,datepart(yy,BELDATE),datepart(mm,BELDATE)
having sum(BELQTE)!=0
compute sum(-(sum(BELQTE))),sum(-(sum(round((STPAHT+STFRAIS)/@lot,2)*BELQTE)))


select "Lignes de BE depuis 1992 - Fichier FBEL"

select Article=BELARTICLE,Annee=datepart(yy,BELDATE),Mois=datepart(mm,BELDATE),
Total=-(sum(BELQTE)),PrixRevientTot=-(sum(round((STPAHT+STFRAIS)/@lot,2)*BELQTE)),
PRMoyen=round(-(sum(((STPAHT+STFRAIS)/@lot)*BELQTE))/-(sum(BELQTE)),2),
Depot=1,'-'
from FBEL,FSTOCK
where BELARTICLE=STAR
and BELLETTRE=STLETTRE
and BELQTE!=0
and BELARTICLE=@Article
and BELDATE>='01/01/92'
group by BELARTICLE,datepart(yy,BELDATE),datepart(mm,BELDATE)
having sum(BELQTE)!=0
compute sum(-(sum(BELQTE))),sum(-(sum(round((STPAHT+STFRAIS)/@lot,2)*BELQTE)))


select 'Stock positif en cours - Fichier FSTOCK'

select Article=STAR,Annee='           ',Mois='           ',Total=sum(STQTE),
PrixRevientTot=sum(round((STPAHT+STFRAIS)/@lot,2)*STQTE),
PRMoyen=round((sum(((STPAHT+STFRAIS)/@lot)*STQTE))/(sum(STQTE)),2),
Depot=STDEPOT,NÃÂ°=DPLOC
from FSTOCK,FDP
where STAR=@Article
and STQTE > 0
and DPCODE=STDEPOT
group by STAR,STDEPOT,DPLOC
compute sum(sum(STQTE)),sum(sum(round((STPAHT+STFRAIS)/@lot,2)*STQTE))

end



go

