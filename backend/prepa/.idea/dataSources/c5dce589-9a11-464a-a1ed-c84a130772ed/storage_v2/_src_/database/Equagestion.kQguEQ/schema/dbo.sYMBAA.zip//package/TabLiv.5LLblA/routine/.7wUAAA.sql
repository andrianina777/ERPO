


create procedure TabLiv (@ent	char(5)	= null,
						 @fourn	char(12),
						 @an	smallint)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #liste
	(			
		codeart 	char(15) 		not null,
		janvier 	int 				null,
		janvierHT	numeric(14,2)		null,
		fevrier 	int 				null,
		fevrierHT	numeric(14,2)		null,
		mars 		int 				null,
		marsHT		numeric(14,2)		null,
		avril 		int 				null,
		avrilHT		numeric(14,2)		null,
		mai 		int 				null,
		maiHT		numeric(14,2)		null,
		juin 		int 				null,
		juinHT		numeric(14,2)		null,
		juillet 	int 				null,
		juilletHT	numeric(14,2)		null,
		aout 		int 				null,
		aoutHT		numeric(14,2)		null,
		septembre 	int 				null,
		septembreHT	numeric(14,2)		null,
		octobre 	int 				null,
		octobreHT	numeric(14,2)		null,
		novembre 	int 				null,
		novembreHT	numeric(14,2)		null,
		decembre 	int 				null,
		decembreHT	numeric(14,2)		null,
		total		int					null,
		totalHT		numeric(14,2)		null
	)	

	create index article on #liste(codeart)
	
	create table #Liv
	(
	Article		char(15)		not null,
	Qte			int				null,
	PRHT		numeric(14,2)	null,
	Date		datetime		null
	)
	

	/* Livraisons */
	
	insert into #Liv (Article,Qte,PRHT,Date)
	select BLLAR,BLLQTE,(BLLQTE*BLLPRHT),BLLDATE
	from FBLL
	where BLLFO=@fourn
	and datepart(yy,BLLDATE)=@an
	and (@ent is null or BLLENT=@ent)
		
	insert into #liste (codeart)
	select distinct Article
	from #Liv
	
	
		update #liste
		set janvier= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=1
					 group by Article)
		
		  update #liste
		  set janvierHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=1
					   group by Article)
					 
		update #liste
		set fevrier= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=2
					 group by Article)
		
		  update #liste
		  set fevrierHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=2
					   group by Article)
		
		update #liste
		set mars= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=3
					 group by Article)
		
		  update #liste
		  set marsHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=3
					   group by Article)
					 
		update #liste
		set avril= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=4
					 group by Article)
		
		  update #liste
		  set avrilHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=4
					   group by Article)
					 
		update #liste
		set mai= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=5
					 group by Article)
		
		  update #liste
		  set maiHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=5
					   group by Article)
					 
		update #liste
		set juin= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=6
					 group by Article)
		
		  update #liste
		  set juinHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=6
					   group by Article)
					 
		update #liste
		set juillet= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=7
					 group by Article)
		
		  update #liste
		  set juilletHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=7
					   group by Article)
					 
		update #liste
		set aout= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=8
					 group by Article)
		
		  update #liste
		  set aoutHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=8
					   group by Article)
					 
		update #liste
		set septembre= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=9
					 group by Article)
		
		  update #liste
		  set septembreHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=9
					   group by Article)
					 
		update #liste
		set octobre= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=10
					 group by Article)
		
		  update #liste
		  set octobreHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=10
					   group by Article)
					 
		update #liste
		set novembre= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=11
					 group by Article)
		
		  update #liste
		  set novembreHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=11
					   group by Article)
					 
		update #liste
		set decembre= (select sum(Qte)
					 from #Liv
					 where #Liv.Article=#liste.codeart
					 and datepart(mm,#Liv.Date)=12
					 group by Article)
		
		  update #liste
		  set decembreHT= (select sum(PRHT)
					   from #Liv
					   where #Liv.Article=#liste.codeart
					   and datepart(mm,#Liv.Date)=12
					   group by Article)
					 
		drop table #Liv


		update #liste
		set total=isnull(janvier,0)+isnull(fevrier,0)+isnull(mars,0)
		+isnull(avril,0)+isnull(mai,0)+isnull(juin,0)
		+isnull(juillet,0)+isnull(aout,0)+isnull(septembre,0)
		+isnull(octobre,0)+isnull(novembre,0)+isnull(decembre,0),
			totalHT=isnull(janvierHT,0)+isnull(fevrierHT,0)+isnull(marsHT,0)
		+isnull(avrilHT,0)+isnull(maiHT,0)+isnull(juinHT,0)
		+isnull(juilletHT,0)+isnull(aoutHT,0)+isnull(septembreHT,0)
		+isnull(octobreHT,0)+isnull(novembreHT,0)+isnull(decembreHT,0)

			select 'Livraisons '+convert(char(4),@an), @fourn
			
			select 'REF','DESIGNATION',
			'JANV','JANVHT','FEVR','FEVRHT','MARS','MARSHT',
			'AVRIL','AVRILHT','MAI','MAIHT','JUIN','JUINHT',
			'JUIL','JUILHT','AOUT','AOUTHT','SEPT','SEPTHT',
			'OCTO','OCTOHT','NOV','NOVHT','DEC','DECHT',
			'TOTAL','TOTALHT'

			select codeart,ARLIB,
			janvier,janvierHT,fevrier,fevrierHT,mars,marsHT,
			avril,avrilHT,mai,maiHT,juin,juinHT,
			juillet,juilletHT,aout,aoutHT,septembre,septembreHT,
			octobre,octobreHT,novembre,novembreHT,decembre,decembreHT,
			total,totalHT
			from #liste,FAR
			where ARCODE=codeart
			order by codeart
			compute sum(janvier),sum(janvierHT),sum(fevrier),sum(fevrierHT),
					sum(mars),sum(marsHT),sum(avril),sum(avrilHT),
					sum(mai),sum(maiHT),sum(juin),sum(juinHT),
					sum(juillet),sum(juilletHT),sum(aout),sum(aoutHT),
					sum(septembre),sum(septembreHT),sum(octobre),sum(octobreHT),
					sum(novembre),sum(novembreHT),sum(decembre),sum(decembreHT),
					sum(total),sum(totalHT)
					
		drop table #liste
	
end	



go

