



create procedure Meilleures_Ventes (@ent		char(5) = null,
									@an			smallint,
									@marque		char(12) = null,
									@famille	char(8) = null,
								    @activite	char(6) = null,
									@article	char(15) = null,
									@depart		char(8) = null,
									@rep		char(8) = null,
									@pays		char(8) = null,
									@mois1 		tinyint = null,
									@mois2 		tinyint = null,									
									@categorie	char(8) = null,
									@matiere	char(14) = null,
							 		@couleur	char(8) = null,
							 		@grille		char(10) = null,
							 		@calibre	char(14) = null,
							 		@produit	char(15) = null,
							 		@aremp		char(16) = null,
							 		@arforeign1	char(12) = null,
							 		@arforeign2	char(12) = null
									)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Final
	(
	Article		char(15)	not null,
	Qte_AN_1	int				null,
	Qte_AN		int				null,
	CA_AN_1		numeric(14,2)	null,
	CA_AN		numeric(14,2)	null
	)
	
	declare @type		tinyint,
			@division	char(8)

	select  @type = 0

	if @rep is not null
		select  @type=RETYPE, @division=REDIV from FREP where RECODE=@rep


	if (@activite is null and @rep is null and @pays is null)
  	begin
		insert into #Final (Article,Qte_AN_1,Qte_AN,CA_AN_1,CA_AN)
		select	START,
				Qte_AN_1	=sum(case when STAN=@an-1	then STQTEFA	else 0 end),
				Qte_AN		=sum(case when STAN=@an 	then STQTEFA 	else 0 end),
				CA_AN_1		=sum(case when STAN=@an-1 	then STCAFA 	else 0 end),
				CA_AN		=sum(case when STAN=@an 	then STCAFA 	else 0 end)
		from FST,FAR
		where STAN between @an-1 and @an
		and START=ARCODE
		and (@marque	is null or ARFO		=@marque)
		and (@famille 	is null or ARFAM	=@famille)
		and (@depart 	is null or ARDEPART	=@depart)
		and (@article 	is null or START	=@article)
		and (@mois1 	is null or STMOIS between @mois1 and @mois2)
		and (@ent 		is null or STENT=@ent)		
		and (@categorie is null or ARGRFAM = @categorie)
		and (@matiere is null or ARMATIERE = @matiere)
		and (@couleur is null or ARCOULEUR = @couleur)
		and (@grille is null or ARGRILLE = @grille)
		and (@calibre is null or ARCALIBRE = @calibre)
		and (@produit is null or ARPRODUIT = @produit)
		and (@aremp is null or AREMP = @aremp)
		and (@arforeign1 is null or ARFOREIGN1 = @arforeign1)
		and (@arforeign2 is null or ARFOREIGN2 = @arforeign2)		
		group by START
  	end
	else	
  	begin
		if @type != 2
		begin
		  insert into #Final (Article,Qte_AN_1,Qte_AN,CA_AN_1,CA_AN)
		  select START,
				 Qte_AN_1 =sum(case when STAN=@an-1	then STQTEFA	else 0 end),
				 Qte_AN	=sum(case when STAN=@an 	then STQTEFA 	else 0 end),
				 CA_AN_1 =sum(case when STAN=@an-1 	then STCAFA 	else 0 end),
				 CA_AN =sum(case when STAN=@an 	then STCAFA 	else 0 end)
		  from FST,FCL,FAR
		  where STAN between @an-1 and @an
		  and STCL=CLCODE
		  and START=ARCODE
		  and (@activite is null or CLSA		=@activite)
		  and (@rep is null or CLREP = @rep)
		  and (@pays is null or CLPY		=@pays)
		  and (@marque is null or ARFO		=@marque)
		  and (@famille is null or ARFAM	=@famille)
		  and (@depart is null or ARDEPART	=@depart)
		  and (@article is null or START	=@article)
		  and (@mois1 is null or STMOIS between @mois1 and @mois2)
		  and (@ent is null or (STENT=@ent and CLENT=@ent))		  		
			and (@categorie is null or ARGRFAM = @categorie)
			and (@matiere is null or ARMATIERE = @matiere)
			and (@couleur is null or ARCOULEUR = @couleur)
			and (@grille is null or ARGRILLE = @grille)
			and (@calibre is null or ARCALIBRE = @calibre)
			and (@produit is null or ARPRODUIT = @produit)
			and (@aremp is null or AREMP = @aremp)
			and (@arforeign1 is null or ARFOREIGN1 = @arforeign1)
			and (@arforeign2 is null or ARFOREIGN2 = @arforeign2)		
		  group by START
		end
		else if @type = 2
		begin
		  insert into #Final (Article,Qte_AN_1,Qte_AN,CA_AN_1,CA_AN)
		  select START,
				 Qte_AN_1 =sum(case when STAN=@an-1	then STQTEFA	else 0 end),
				 Qte_AN =sum(case when STAN=@an 	then STQTEFA 	else 0 end),
				 CA_AN_1 =sum(case when STAN=@an-1 	then STCAFA 	else 0 end),
				 CA_AN	=sum(case when STAN=@an 	then STCAFA 	else 0 end)
		  from FST,FCL,FAR,FCLR
		  where STAN between @an-1 and @an
		  and STCL=CLCODE
		  and START=ARCODE
		  and CLCODE=CLRCL
		  and (@activite is null or CLSA		=@activite)
		  and (@rep is null or (CLRREPDIV = @rep and ARDEPART= @division))
		  and (@pays is null or CLPY		=@pays)
		  and (@marque is null or ARFO		=@marque)
		  and (@famille is null or ARFAM	=@famille)
		  and (@depart is null or ARDEPART	=@depart)
		  and (@article is null or START	=@article)
		  and (@mois1 is null or STMOIS between @mois1 and @mois2)
		  and (@ent is null or (STENT=@ent and CLENT=@ent))		  		
			and (@categorie is null or ARGRFAM = @categorie)
			and (@matiere is null or ARMATIERE = @matiere)
			and (@couleur is null or ARCOULEUR = @couleur)
			and (@grille is null or ARGRILLE = @grille)
			and (@calibre is null or ARCALIBRE = @calibre)
			and (@produit is null or ARPRODUIT = @produit)
			and (@aremp is null or AREMP = @aremp)
			and (@arforeign1 is null or ARFOREIGN1 = @arforeign1)
			and (@arforeign2 is null or ARFOREIGN2 = @arforeign2)		
		  group by START
		end
 	end


	select Article,ARLIB,Qte_AN_1,Qte_AN,CA_AN_1,CA_AN,ARREFFOUR
	from #Final,FAR
	where ARCODE=Article
	order by Qte_AN desc

	drop table #Final

end

go

