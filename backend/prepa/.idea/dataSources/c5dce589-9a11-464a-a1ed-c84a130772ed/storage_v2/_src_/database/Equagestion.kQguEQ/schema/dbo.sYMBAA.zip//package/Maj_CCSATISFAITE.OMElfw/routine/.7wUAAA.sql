



create procedure Maj_CCSATISFAITE  (@commande	char(10),
									@ent		char(5) = null)
with recompile
as
begin

  declare @seq			int,
		  @qte			int,
		  @reste		int,
		  @artype		tinyint,
		  @lignes		int,
		  @satisfaite	int,
		  @nonlivre		int,
		  @pclivre		real,
		  @site			int,
		  @count		int
		  
  select @satisfaite = 0,
  		 @nonlivre = 0,
		 @pclivre = 0
  
  /** % de livraison effectue **/

  select @pclivre = (
		 			sum(case when CCLTOTALHT !=0 then (convert(float,CCLTOTALHT)/CCLQTE)*(CCLQTE-CCLRESTE)
		 		  			 when CCLTOTALHT  =0 then convert(float,(CCLQTE-CCLRESTE)*(case when isnull(ARPRM,0)=0 then 1 else ARPRM end)) end)
				   /sum(case when CCLTOTALHT !=0 then convert(float,CCLTOTALHT)
				  			 when CCLTOTALHT  =0 then convert(float,CCLQTE*(case when isnull(ARPRM,0)=0 then 1 else ARPRM end)) end)
	   				)
	 				*100
  from FCCL,FAR
  where CCLCODE=@commande and (@ent is null or CCLENT=@ent)
  and ARCODE=CCLARTICLE

  
  /** Maj CCFRANCOBE **/
  
  select @site = KISITE from KInfos
  
  if @site = 6
  	begin
		select @count = count(*) from FCCL
		where CCLRESTE <= 0
		and CCLCODE = @commande
		
		if @count = 0
			update FCC set CCFRANCOBE=0 where CCCODE=@commande
	
	end


  /** Calcul de CCSATISFAITE **/
  
  select @lignes=count(*) from FCCL
  where CCLCODE=@commande and (@ent is null or CCLENT=@ent)
  
  
  if @lignes > 0
  begin
  
	declare commande cursor 
	for select CCLSEQ,CCLQTE,CCLRESTE
	from FCCL,FAR
	where CCLARTICLE=ARCODE
	and CCLCODE=@commande
	and ARTYPE != 4
	and (@ent is null or CCLENT=@ent)
	for read only
	
	
	open commande
	
	fetch commande
	into @seq,@qte,@reste
	
	while (@@sqlstatus = 0)
		begin
		
		
		if @satisfaite = 0
		  begin
		  	if @reste <= 0 select @satisfaite = 2
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
			else select @nonlivre = 1
		  end
		else
		if @satisfaite = 2
		  begin
		  	if @qte = @reste select @satisfaite = 1
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
		  end
	
		
		fetch commande
		into @seq,@qte,@reste
		
	end
	
	close commande
	deallocate cursor commande
	
	if (@satisfaite = 2) and (@nonlivre = 1)
	select @satisfaite = 1
	
	update FCC set CCSATISFAITE = @satisfaite, CCPCLIVRE = @pclivre
	where CCCODE=@commande and (@ent is null or CCENT=@ent)
  
  end
  else if @lignes = 0
  begin
  
	update FCC set CCSATISFAITE = 2, CCPCLIVRE = @pclivre
	where CCCODE=@commande and (@ent is null or CCENT=@ent)
  
  end  

end



go

