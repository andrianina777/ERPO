/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheEmplDig
grant execute on bp_afficheEmplDig to public
*/

CREATE PROCEDURE dbo.bp_afficheEmplDig(@dep char(4),@article char(15),@alle char(5),@sansEmpl int,@default int)

AS
begin
		declare @prepspecif int,@bpcode char(10),@debut_prep datetime,@fin_prep datetime,@debut_ctrl datetime,@fin_ctrl datetime
		
       if(@default=1)
       begin
       		select AREAR,ARLIB,ARFO,isnull(AREEMP,''),1 from VIEW_FARE inner join VIEW_FAR_TOUS on ARCODE=AREAR 
       		inner join xEMP_DIGUEL on (xARTICLE=AREAR and xDEPOTL=AREDEPOT and  xEMPL=AREEMP)
       		inner join xEMP_DIGUE on (xDEPOT=xDEPOTL and xALLE=xALLEL)
       		where AREDEPOT=@dep  and (@article=null or @article='' or AREAR=@article) and (@alle=null or @alle='' or xALLE=@alle)
       		order by AREAR,AREEMP
       end
       else if(@sansEmpl=1)
       begin
       		select distinct  STEMPAR,ARLIB,ARFO,'',0 from VIEW_STOCK_LOT_EMPLACEMENT where STEMPAR not in (select distinct xARTICLE from xEMP_DIGUEL where xDEPOTL=@dep and isnull(xARTICLE,'')<>'') and
       		(@article=null or @article='' or STEMPAR=@article) order by STEMPAR
       end
       else if(@default=0 and @sansEmpl=0 )
       begin
       		select distinct ARCODE,ARLIB,ARFO,xEMPL,case when (AREPICK=1 and ARERECEP=1 and AREVALID=1) then 1 else 0 end from VIEW_FAR 
       		left join xEMP_DIGUEL on (xARTICLE=ARCODE)
       		left join FARE on AREAR=ARCODE and AREEMP=xEMPL
       		left join xEMP_DIGUE on (xDEPOT=xDEPOTL and xALLE=xALLEL) 
       		where xDEPOTL=@dep  and (@article=null or @article='' or ARCODE=@article) and (@alle=null or @alle='' or xALLE=@alle)
       		order by ARCODE,xEMPL
       end
        
end
go

