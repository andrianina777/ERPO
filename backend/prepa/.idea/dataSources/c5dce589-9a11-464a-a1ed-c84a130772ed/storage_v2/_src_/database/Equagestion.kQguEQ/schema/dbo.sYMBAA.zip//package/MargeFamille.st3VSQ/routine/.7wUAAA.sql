


create procedure MargeFamille (	@ent			char(5)	= null,
								@Famille		char(8) = null,
								@Fournisseur 	char(12) = null,
							  	@FromDate		smalldatetime,
								@ToDate			smalldatetime)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Liste
	(
	Article			char(15)	not null,
	Designation		varchar(80)		null,
	Lettre			char(4)		not null,
	Quantite		int				null,
	PrixVenteUHT	numeric(14,2)	null,
	PrixRevientUHT	numeric(14,2)	null,
	BeneficeUHT		numeric(14,2)	null,
	PCMarge			numeric(14,2)	null
	)
	
	insert into #Liste
    select FALARTICLE,ARLIB,FALLETTRE,FALQTE,round(FALTOTALHT/FALQTE,2),0.00,0.00,0
    from FFAL,FAR
    where FALDATE between @FromDate and @ToDate
    and FALARTICLE=ARCODE
	and ((@Famille is null) or (ARFAM=@Famille))
	and ((@Fournisseur is null) or (ARFO=@Fournisseur))
	and FALQTE>0
	and (@ent is null or FALENT=@ent)
	
	
	update #Liste set PrixRevientUHT=round((STPAHT+STFRAIS)/CVLOT,2)
	from #Liste,FSTOCK,FAR,FCV,FDP
	where STAR=Article
	and STLETTRE=Lettre
	and ARCODE=Article
	and CVUNIF=ARUNITACHAT
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
   
	update #Liste set BeneficeUHT=PrixVenteUHT-PrixRevientUHT,
		PCMarge=round((PrixVenteUHT-PrixRevientUHT)/PrixVenteUHT,2)
	where PrixRevientUHT!=0
	
	print	""
	print	""
	print "Articles dont le PRHT est documente au stock pour la famille "
	print	@Famille
	print	""

select Article,Designation,QteTot=sum(Quantite),
	PVMUHT=convert(char(10),avg(PrixVenteUHT)),
	PRMUHT=convert(char(10),convert(numeric(14,2),avg(PrixRevientUHT))),
	BMUHT=convert(char(10),convert(numeric(14,2),avg(BeneficeUHT))),'   ',
	PCMargeM=convert(char(8),round((avg(PCMarge)*100),2)),'%'
from #Liste
where PrixRevientUHT!=0
group by Article,Designation

	print	""
	print ""
	print "Articles dont le PRHT n'est pas documente au stock pour la famille"
	print	@Famille
	print	""

select Article,Designation,QteTot=sum(Quantite),
	PVM=avg(PrixVenteUHT)
from #Liste
where PrixRevientUHT=0
group by Article,Designation

end



go

