


/* Procedure renvoyant les lignes de FA avec la marge par REP sedentaire */

create procedure Marges_FA_REP_Dates (@ent		char(5) 	  = null,
							 		  @date1	smalldatetime,
									  @date2	smalldatetime
						    		)
with recompile
as
begin

set arithabort numeric_truncation off

declare	@mois	tinyint

create table #FA
(
Rep				char(10)		not null,
Date			smalldatetime	not null,
Article			char(15)		not null,
Quantite		int				not null,
Valeur_Vente	numeric(14,2)	not null,
Marge_Val		numeric(14,2)	not null,
ID				numeric(14,0)	identity
)


insert into #FA (Rep,Date,Article,Quantite,Valeur_Vente,Marge_Val)
select CLREP,dateadd(hh,19,FALDATE),FALARTICLE,FALQTE,FALTOTALHT,0
from FFAL,FAR,FCL
where ARCODE=FALARTICLE
and CLCODE=FALCL
and FALDATE between @date1 and @date2
and ARTYPE=0
and FALLETTRE != ""
and (@ent is null or (FALENT=@ent and CLENT=@ent))


declare factures cursor 
for select ID,Date,Article,Quantite,Valeur_Vente
from #FA
for update of Marge_Val

declare @seq			numeric(14,0),
		@date			smalldatetime,
		@article		char(15),
		@qte			int,
		@totalht		numeric(14,2),
		@PrixRevient	numeric(14,4)

open factures

fetch factures
into @seq,@date,@article,@qte,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @PrixRevient=isnull(PUMP,0)
	from FPUM
	where PUMAR = @article
	and PUMDATE <= @date
	having PUMAR = @article
	and PUMDATE <= @date
	and PUMDATE = max(PUMDATE)
	
	if @PrixRevient is null
		select @PrixRevient=0
	
	if @totalht = 0
	begin
		update #FA set Marge_Val=-(@PrixRevient*@qte)
		where current of factures	
	end
	else if @PrixRevient != 0
	begin
		update #FA set Marge_Val=@totalht-(@PrixRevient*@qte)
		where current of factures	
	end
	else
	begin
		update #FA set Marge_Val=@totalht
		where current of factures
	end
	
	
	fetch factures
	into @seq,@date,@article,@qte,@totalht
	
end

close factures
deallocate cursor factures

insert into #FA (Rep,Date,Article,Quantite,Valeur_Vente,Marge_Val)
select CLREP,dateadd(hh,19,FALDATE),FALARTICLE,0,FALTOTALHT,FALTOTALHT
from FFAL,FAR,FCL
where ARCODE=FALARTICLE
and CLCODE=FALCL
and FALDATE between @date1 and @date2
and ARTYPE=0
and FALLETTRE = ""
and (@ent is null or (FALENT=@ent and CLENT=@ent))


select Rep=Rep,
		Qte=sum(Quantite),
		Vente=sum(Valeur_Vente),
		Marge_Valeur=sum(Marge_Val),
		Marge_PC=convert(numeric(14,2),0)
into #Finale
from #FA
group by Rep

drop table #FA


update #Finale
set Marge_PC=(case when Vente != 0 then convert(numeric(14,2),Marge_Valeur/Vente*100)
				      when Vente = 0 then 0 end)


select Date_debut=@date1,Date_fin=@date2,Rep=Rep,Nom=RENOM,Qte=Qte,Vente=Vente,
		Marge_Valeur=Marge_Valeur,Marge_PC=Marge_PC
from #Finale,FREP
where RECODE=Rep
order by Rep

drop table #Finale


end



go

