



create procedure Maj_PVTTC	(@marque	char(12),
							 @coeftxt	char(12)
							)
with recompile
as
begin

declare @coef		numeric(14,4)
select  @coef = convert(numeric(14,4),@coeftxt)


update FAR
set ARPRIXCONST=convert(numeric(14,2),ARPVHT*@coef)
where ARFO=@marque


end



go

