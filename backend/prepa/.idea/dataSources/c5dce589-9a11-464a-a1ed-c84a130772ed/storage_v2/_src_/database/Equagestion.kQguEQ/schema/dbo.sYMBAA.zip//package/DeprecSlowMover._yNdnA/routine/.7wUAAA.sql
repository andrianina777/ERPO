

create procedure DeprecSlowMover (@depot		char(4),
							 	  @codephoto	char(16),
							 	  @datephoto	smalldatetime,
							 	  @type			tinyint	= 0,		/* Rotation : 0 = calcul a partir des qtes, 1 = calcul a partir des valeurs */
							      @activite		char(6) = ""
							     )
with recompile
as
begin

set arithabort numeric_truncation off

declare @article			char(15), 
		@qte				int, 
		@PrixRevient		numeric(14,4),
		@j1deb				int,
		@j1fin				int,
		@pc1				numeric(8,4),
		@j2deb				int,
		@j2fin				int,
		@pc2				numeric(8,4),
		@j3deb				int,
		@pc3				numeric(8,4),
		@derniermouv		smalldatetime,
		@art				char(15),
		@rotation			float,
		@qtegroupe			int
		
		
select  @j1deb = P2SMJROT1DEB, @j1fin = P2SMJROT1FIN, @pc1 = P2SMJROT1PC,
		@j2deb = P2SMJROT2DEB, @j2fin = P2SMJROT2FIN, @pc2 = P2SMJROT2PC,
		@j3deb = P2SMJROT3DEB, @pc3 = P2SMJROT3PC
from KParam2


create table #Articles
(
article		char(15)	not null,
qte			int			not null
)

create table #Finale
(
article		char(15)		not null,
depot		char(4)			not null,
qte			int				not null,
derniermouv	smalldatetime		null,
jourstock	float				null,
pump		numeric(14,4)		null,
valavant	numeric(14,2)		null,
taux		float			not null,
valapres	numeric(14,2)		null,
depgroupe	numeric(14,2)		null
)


insert into #Articles (article,qte)
select PSAR,sum(PSQTE)
from FPS
where PSCODE = @codephoto
and PSDATE = @datephoto
and PSDEPOT = @depot
and not exists (select * from TEMP_MOVER where MOVERSPID = @@spid
										   and MOVERARTICLE = FPS.PSAR
										   and MOVERDEPOT = @depot
										   and MOVERCODEPHOTO = @codephoto
										   and MOVERDATEPHOTO = @datephoto)
group by PSAR



declare articles cursor 
for select article,qte
from #Articles
for read only


open articles

fetch articles
into @article, @qte

while (@@sqlstatus = 0)
	begin
	
	  select @rotation = 0
	  select @qtegroupe = 0

	  select @PrixRevient=isnull(PUMP,0) 
	  from FPUM 
	  where PUMAR = @article 
	  and PUMDATE <= convert (smalldatetime, @datephoto) 
	  having PUMAR = @article 
	  and PUMDATE <= convert (smalldatetime, @datephoto) 
	  and PUMDATE = max(PUMDATE)
	  
	  if @type=0
	  begin
		  select @art = FALARTICLE, @rotation = (@qte / (case when isnull(sum(FALQTE),0)>0 then sum(FALQTE) else 0.0001 end)) * 360
		  from FFAL
		  where FALARTICLE = @article
		  and FALTOTALHT <> 0
		  and isnull(FALLETTRE,"") <> ""
		  and FALDATE between dateadd(mm,-12,@datephoto) and @datephoto
		  group by FALARTICLE
	  end
	  else if @type=1
	  begin
		  select @art = FALARTICLE, @rotation = (@PrixRevient * @qte / (case when isnull(sum(FALTOTALHT),0)>0 then sum(FALTOTALHT) else 0.0001 end)) * 360
		  from FFAL
		  where FALARTICLE = @article
		  and FALTOTALHT <> 0
		  and isnull(FALLETTRE,"") <> ""
		  and FALDATE between dateadd(mm,-12,@datephoto) and @datephoto
		  group by FALARTICLE
	  end
	  
	  
	  if @activite != ""
	  begin
		  select  @qtegroupe = sum(PSQTE)
		  from FPS,FFO
		  where PSCODE = @codephoto
		  and PSDATE = @datephoto
		  and PSAR = @article
		  and PSFO = FOCODE
		  and FOSA = @activite
		  and PSDEPOT = @depot
	  end
	  else
	  begin
	  	  select @qtegroupe = 0
	  end

	  	  
	  if ((@rotation > @j1deb) and (@rotation <= @j1fin))
	  begin
	  	insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  	values (@article,@depot,@qte,null,@rotation,@PrixRevient,@PrixRevient*@qte,@pc1,@PrixRevient*@qte*(@pc1/100),@PrixRevient*@qtegroupe*(@pc1/100))
	  end
	  else
	  if ((@rotation > @j2deb) and (@rotation <= @j2fin))
	  begin
	  	insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  	values (@article,@depot,@qte,null,@rotation,@PrixRevient,@PrixRevient*@qte,@pc2,@PrixRevient*@qte*(@pc2/100),@PrixRevient*@qtegroupe*(@pc2/100))
	  end
	  if (@rotation > @j3deb)
	  begin
	  	insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  	values (@article,@depot,@qte,null,@rotation,@PrixRevient,@PrixRevient*@qte,@pc3,@PrixRevient*@qte*(@pc3/100),@PrixRevient*@qtegroupe*(@pc3/100))
	  end
	  
	
	fetch articles
	into @article, @qte
	
end

close articles
deallocate cursor articles

select article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe,ARLIB,ARFAM
from #Finale,FAR
where ARCODE = article
order by article

drop table #Articles
drop table #Finale


end
go

