/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_ImprimeTRAITE_FA
grant execute on bp_ImprimeTRAITE_FA to public
*/

CREATE PROCEDURE dbo.bp_ImprimeTRAITE_FA(@codecc char(10))
with recompile
AS
begin
	declare @traite_code char(10),
			@seq int,
			@client char(12),
			@is_fin int,
			@m_codecc char(10)


	select @traite_code=isnull(CC_TRAITE,''),@client=CCCLIENT from FCC left join FTRAITE on TRAITE_CODE=CC_TRAITE where CCCODE=@codecc and isnull(TRAITE_ANNULE,0)=0
	select @is_fin=0
	
	if(@traite_code<>'')
	begin
				
		declare liste cursor for  select CCCODE from FCC left join FTRAITE on TRAITE_CODE=CC_TRAITE where CC_TRAITE=@traite_code and CCDATECOM>'2018/01/01' and CCCLIENT=@client and isnull(TRAITE_ANNULE,0)=0
		open liste						 
		fetch liste into @m_codecc
		
		while(@@sqlstatus=0)
		begin
		
			if(select count(*) from FFA where FACC=@m_codecc)>0
				select @is_fin=@is_fin+0			
			else
				select @is_fin=@is_fin+1

			fetch liste into @m_codecc  
		end			
   		close liste
		deallocate cursor liste
		
		execute eq_GetSeq_proc 'FTRAITEL',1,@i = @seq output 
		INSERT INTO Equagestion.dbo.FTRAITEL
		(TRL_SEQ, TRL_CODE, TRL_CL, TRL_DATE, TRL_FA, TRL_FADATE, TRL_FAECH, TRL_MONTANT, TRL_MTPAYE)
	 
		SELECT @seq,@traite_code ,@client,FADATE,FACODE,FADATE,FATRDATE1,FANETAPAYER,FANETAPAYER FROM FFA where FACC=@codecc						
	end

	select @traite_code,@is_fin
end
go

