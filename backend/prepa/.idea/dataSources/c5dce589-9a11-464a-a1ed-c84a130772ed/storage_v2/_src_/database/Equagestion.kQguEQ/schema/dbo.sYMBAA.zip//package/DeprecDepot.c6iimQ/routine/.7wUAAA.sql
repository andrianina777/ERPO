

create procedure DeprecDepot(@depot		char(4),
							 @deprec	float,
							 @codephoto	char(16),
							 @datephoto	smalldatetime,
							 @activite	char(6) = ""
							)
with recompile						
as
begin

set arithabort numeric_truncation off

declare @article			char(15), 
		@qte				int, 
		@PrixRevient		numeric(14,4),
		@qtegroupe			int

create table #Articles
(
article		char(15)	not null,
qte			int			not null
)

create table #Finale
(
article		char(15)		not null,
depot		char(4)			not null,
qte			int				not null,
derniermouv	smalldatetime		null,
jourstock	float				null,
pump		numeric(14,4)		null,
valavant	numeric(14,2)		null,
taux		float			not null,
valapres	numeric(14,2)		null,
depgroupe	numeric(14,2)		null
)


insert into #Articles (article,qte)
select PSAR,sum(PSQTE)
from FPS
where PSCODE = @codephoto
and PSDATE = @datephoto
and PSDEPOT = @depot
group by PSAR



declare articles cursor 
for select article,qte
from #Articles
for read only


open articles

fetch articles
into @article, @qte

while (@@sqlstatus = 0)
	begin
	
	  select @qtegroupe = 0

	  select @PrixRevient=isnull(PUMP,0) 
	  from FPUM 
	  where PUMAR = @article 
	  and PUMDATE <= convert (smalldatetime, @datephoto) 
	  having PUMAR = @article 
	  and PUMDATE <= convert (smalldatetime, @datephoto) 
	  and PUMDATE = max(PUMDATE)
	  
	  if @activite != ""
	  begin
		  select  @qtegroupe = sum(PSQTE)
		  from FPS,FFO
		  where PSCODE = @codephoto
		  and PSDATE = @datephoto
		  and PSAR = @article
		  and PSFO = FOCODE
		  and FOSA = @activite
		  and PSDEPOT = @depot
	  end
	  else
	  begin
	  	  select @qtegroupe = 0
	  end

	  insert into #Finale (article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe)
	  values (@article,@depot,@qte,null,null,@PrixRevient,@PrixRevient*@qte,@deprec,@PrixRevient*@qte*(@deprec/100),@PrixRevient*@qtegroupe*(@deprec/100))
	
	fetch articles
	into @article, @qte
	
end

close articles
deallocate cursor articles

select article,depot,qte,derniermouv,jourstock,pump,valavant,taux,valapres,depgroupe,ARLIB
from #Finale,FAR
where ARCODE = article
order by article

drop table #Articles
drop table #Finale


end
go

