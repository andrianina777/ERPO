


/* Procedure permettant de recuperer l''etat de stock et les commandes clients  */

create procedure Stock_FoCc (	@fourn		char(12) = null,
						    	@sans		smallint = 0)
with recompile
as
begin

set arithabort numeric_truncation off

create table #stock
(
Art			char(15)		not null,
Nom			varchar(80)		not null,
stock_Qte	int				not null,
cde_Qte		int				not null
)

insert into #stock
	select STAR, ARLIB, isnull(sum(isnull(STQTE,0)),0), 0
	from FSTOCK, FAR
	where STAR=ARCODE
	and (@fourn is null or STFO = @fourn)
	group by STAR, ARLIB

insert into #stock
	select RCCARTICLE, ARLIB, 0, isnull(sum(isnull(RCCQTE,0)),0)
	from FRCC, FAR
	where RCCARTICLE=ARCODE
	and exists(select * from FARF where FAR.ARCODE=ARFCODE and ARFFO=@fourn)
	group by RCCARTICLE, ARLIB

if @sans = 0
	select Article=Art, Libelle=Nom, Qte_Stock=stock_Qte, Qte_Cdee=cde_Qte
	from #stock
	where (stock_Qte+cde_Qte)<>0
	order by Art
	
if @sans = 1
	select Article=Art, Libelle=Nom, Qte_Stock=stock_Qte, Qte_Cdee=cde_Qte
	from #stock
	order by Art

end

go

