/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE bp_AlertDureeVie
grant execute on bp_AlertDureeVie to public
*/

CREATE PROCEDURE dbo.bp_AlertDureeVie(@prcode char(10),@article char(15),@lot char(12),@qte int)
with recompile
AS
begin
	 declare @datePer smalldatetime,
	 		 @dureeVie int,
	 		 @taux int,
	 		 @dateVie smalldatetime,
	 		 @limite int
	 		 
	select @taux=66
	select @limite =0
 	 		 
 	select @datePer=NLOTDATEPER from FNLOT where rtrim(NLOTAR)=rtrim(@article) and rtrim(NLOTCODE)=rtrim(@lot)
 	 
 	select @dureeVie=isnull(xARTP_DDV,0) from xFARTYPE where rtrim(xARTP_ARCODE)=rtrim(@article)
 	
 	if (@dureeVie>0)
 	begin
 	      select @limite=round (convert(float,@dureeVie*@taux)/100,0)
 	      select @dateVie=dateadd(mm,@limite,current_date())
 	      
 	      if(@dateVie>@datePer)
 	      begin
                INSERT INTO DBSUIVI..b_alerteDureeVie (xCode, xArticle, xLot, xDatePer, xDureeVie, xEtat,xDate,xQte,xNbMois,xTaux)
                values(@prcode,@article,@lot,@datePer,@dureeVie,0,getdate(),@qte,@limite,@taux)
 	      end
 	end
 	
end
go

