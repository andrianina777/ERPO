


/* Procedure donnant la marge par marques entre 2 dates */


create procedure MargesMarques (@ent		char(5)	= null,
								@FromDate	datetime,
							  	@ToDate		datetime,
								@depart		char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
ARDEPART		char(8)			null,
ARFO			char(12)		null,
ARCODE			char(15)		null,
CVLOT			int				null
)

create table #Fal
(
depart	char(8)			null,
Marque	char(12)		null,
Total	numeric(14,2)	null,
PR		numeric(14,2)	null
)

insert into #Far (ARDEPART,ARFO,ARCODE,CVLOT)
select ARDEPART,ARFO,ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and (@depart is null or ARDEPART=@depart)


create unique clustered index article on #Far(ARCODE)

insert into #Fal (depart,Marque,Total,PR)
select 	ARDEPART,ARFO,sum(FALTOTALHT),round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*FALQTE),2)
from FFAL,#Far,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALDATE between @FromDate and @ToDate
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,ARFO

drop table #Far

/* select final */

select depart,Marque, CA=Total, PAHT=PR,
		MargeFF = Total-PR,
		Marge = round(((Total-PR)*abs(sign(Total)))/(Total+(1-abs(sign(Total)))),2)*100
from #Fal
order by depart,Marque
compute sum(Total),sum(PR),sum(Total-PR) by depart
compute sum(Total),sum(PR),sum(Total-PR)

drop table #Fal

end



go

