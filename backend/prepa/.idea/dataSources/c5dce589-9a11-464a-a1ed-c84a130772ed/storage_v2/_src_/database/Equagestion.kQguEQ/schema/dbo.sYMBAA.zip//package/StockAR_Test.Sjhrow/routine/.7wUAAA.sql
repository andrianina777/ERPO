CREATE PROCEDURE dbo.StockAR_Test (@article		char(15),
						  @date1		smalldatetime,
						  @depot		char(4) = null,
						  @lettre		char(4) = null
						  )
with recompile
as
begin

 declare @id char(32),@qtestock_tmp int,@qtestockres_tmp int

create table #Stockinit
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null
)

create table #Stockperiode
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null,
ent				char(5)			null,
tiers			char(12)	null
)

create table #Stockfinal
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null,
ent				char(5)			null,
tiers			char(12)	null
)

create table #Resultats
(
seq				numeric(14,0)	identity,
tri				tinyint			not null,
date			datetime		not null,
piece			varchar(20)		not null,
qtestock		int				not null,
qtestockres		int				not null,
total			int				not null,
totavecres		int				not null,
ent				char(35)				null,
tiers			char(12)	null,
piece_liee varchar(20) null
)


/*********** AVANT ******************/

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(SILQTE),0),0
from FSIL
where SILARTICLE=@article
--and SILDATE < @date1
and SILDATESIMPLE<convert(date,@date1)
and (@depot is null or SILDEPOT = @depot)
and (@lettre is null or SILLETTRE = @lettre)


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(BLLQTE),0),0
from FBLL
where BLLAR=@article
and BLLDATE < @date1
and isnull(BLLLET,'') != ''
and (@depot is null or BLLDEP = @depot)
and (@lettre is null or BLLLET = @lettre)


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(DOLQTE),0),0
from FDOL
where DOLAR=@article
and DOLDATE < @date1
and (@depot is null or DOLDEP = @depot)
and (@lettre is null or DOLLET = @lettre)


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(ASLQTE),0),0
from FASL
where ASLARTICLE=@article
and ASLDATE < @date1
and (@depot is null or ASLDEPOT = @depot)
and (@lettre is null or ASLLETTRE = @lettre)


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(-sum(RFLQTE),0),0
from FRFL
where RFLARTICLE=@article
and RFLDATE < @date1
and (@depot is null or RFLDEPOT = @depot)
and (@lettre is null or RFLLETTRE = @lettre)


/* ''Reajustements - Fichier RJL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(RJLQTE),0),0
from FRJL
where RJLARTICLE=@article
and RJLDATE < @date1
and (@depot is null or RJLDEPOT = @depot)
and (@lettre is null or RJLLETTRE = @lettre)


/* ''Lignes de casse - Fichier LCL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(LCLQTE),0),0
from FLCL
where LCLARTICLE=@article
and LCLDATE < @date1
and (@depot is null or LCLDEPOT = @depot)
and (@lettre is null or LCLLETTRE = @lettre)


/* ""Lignes de BE - Fichier FBEL"" */

if (@depot is null)
begin
  insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
  select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0)
  from FBEL
  where BELARTICLE=@article
  and BELDATE < @date1
  and BELENT='FR'
  and (@lettre is null or BELLETTRE = @lettre)
end
else if (@depot is not null)
begin


  insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
  select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0)
  from FBEL,FSTOCK
  where BELARTICLE=@article
  and BELDATE < @date1
  and BELARTICLE=STAR
  and BELLETTRE=STLETTRE
  and STDEPOT=@depot
  and BELENT='FR'
  and (@lettre is null or BELLETTRE = @lettre)
  
end

/* ''Atelier - Fichier FWL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(WLQTE),0),0
from FWL
where WLARCODE=@article
and WLDATE < @date1
and isnull(WLSTOCK,'') <> ''
and (@depot is null or WLDPCODE = @depot)
and (@lettre is null or WLSTOCK = @lettre)


delete from #Stockinit
where qtestock = 0
and qtestockres = 0


/********************** PENDANT ************************/

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'SI',1,SILDATE,SILCODE,isnull(sum(SILQTE),0),0,'',SILFO
from FSIL
where SILARTICLE=@article
and SILDATE >= @date1
and (@depot is null or SILDEPOT = @depot)
and (@lettre is null or SILLETTRE = @lettre)
group by SILDATE,SILCODE,SILFO


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'BL',2,BLLDATE,BLLCODE,isnull(sum(BLLQTE),0),0,BLLENT,BLLFO
from FBLL
where BLLAR=@article
and BLLDATE >= @date1
and isnull(BLLLET,'') != ''
and (@depot is null or BLLDEP = @depot)
and (@lettre is null or BLLLET = @lettre)
group by BLLDATE,BLLCODE,BLLENT,BLLFO


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'DO',3,DOLDATE,DOLCODE,isnull(sum(DOLQTE),0),0,DOLENT,DOLFO
from FDOL
where DOLAR=@article
and DOLDATE >= @date1
and (@depot is null or DOLDEP = @depot)
and (@lettre is null or DOLLET = @lettre)
group by DOLDATE,DOLCODE,DOLENT,DOLFO


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'AS',4,ASLDATE,ASLCODE,isnull(sum(ASLQTE),0),0,'',ASLFO
from FASL
where ASLARTICLE=@article
and ASLDATE >= @date1
and (@depot is null or ASLDEPOT = @depot)
and (@lettre is null or ASLLETTRE = @lettre)
group by ASLDATE,ASLCODE,ASLFO


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'RF',5,RFLDATE,RFLCODE,isnull(-sum(RFLQTE),0),0,RFLENT,RFLFO
from FRFL
where RFLARTICLE=@article
and RFLDATE >= @date1
and (@depot is null or RFLDEPOT = @depot)
and (@lettre is null or RFLLETTRE = @lettre)
group by RFLDATE,RFLCODE,RFLENT,RFLFO


/* ''Reajustements - Fichier RJL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'RJ',6,RJLDATE,RJLCODE,isnull(sum(RJLQTE),0),0,'',''
from FRJL
where RJLARTICLE=@article
and RJLDATE >= @date1
and (@depot is null or RJLDEPOT = @depot)
and (@lettre is null or RJLLETTRE = @lettre)
group by RJLDATE,RJLCODE


/* ''Lignes de casse - Fichier LCL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'LC',7,LCLDATE,LCLCODE,isnull(sum(LCLQTE),0),0,'',LCLFO
from FLCL
where LCLARTICLE=@article
and LCLDATE >= @date1
and (@depot is null or LCLDEPOT = @depot)
and (@lettre is null or LCLLETTRE = @lettre)
group by LCLDATE,LCLCODE,LCLFO


/* ""Lignes de BE - Fichier FBEL"" */

if (@depot is null)
begin
  insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
  select 'BE',8,BELDATE,BELCODE,isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0),
		  BELENT,BELCL
  from FBEL
  where BELARTICLE=@article
  and BELDATE >= @date1
  and (@lettre is null or BELLETTRE = @lettre)
  and BELENT='FR'
  group by BELDATE,BELCODE,BELENT,BELCL
end
else if (@depot is not null)
begin



  insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
  select 'BE',8,BELDATE,BELCODE,isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0),
		  BELENT,BELCL
  from FBEL,FSTOCK
  where BELARTICLE=@article
  and BELDATE >= @date1
  and BELARTICLE=STAR
  and BELLETTRE=STLETTRE
  and STDEPOT=@depot
  and BELENT='FR'
  and (@lettre is null or BELLETTRE = @lettre)
  group by BELDATE,BELCODE,BELENT,BELCL
 
  
end

/* ''Atelier - Fichier FWL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'WL',9,WLDATE,WLCODE,isnull(sum(WLQTE),0),0,WLENT,WLCL
from FWL
where WLARCODE=@article
and WLDATE >= @date1
and isnull(WLSTOCK,'') <> ''
and (@depot is null or WLDPCODE = @depot)
and (@lettre is null or WLSTOCK = @lettre)
group by WLDATE,WLCODE,WLENT,WLCL


delete from #Stockperiode
where qtestock = 0
and qtestockres = 0


/******************** Final ********************/



insert into #Stockfinal (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select type,tri,date,piece,sum(qtestock),sum(qtestockres),'',''
from #Stockinit
group by type,tri,date,piece
order by date,tri,piece

insert into #Stockfinal (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select type,tri,date,piece,sum(qtestock),sum(qtestockres),ent,tiers
from #Stockperiode
group by type,tri,date,piece,ent,tiers
order by date,tri,piece,ent


create index tri on #Stockfinal (date,tri,piece,ent,tiers)


drop table #Stockinit
drop table #Stockperiode

declare stock cursor 
for select tri,date,piece,qtestock,qtestockres,ent,tiers
from #Stockfinal
order by date,tri,piece,ent,tiers
for read only

declare @tri			tinyint,
		@date			datetime,
		@piece			varchar(20),
		@qtestock		int,
		@qtestockres	int,
		@total			int,
		@totavecres		int,
		@ent			char(5),
		@tiers			char(12)

select 	@total = 0,
		@totavecres = 0

open stock

fetch stock
into @tri,@date,@piece,@qtestock,@qtestockres,@ent,@tiers

while (@@sqlstatus = 0)
	begin
	
	select 	@total = @total + @qtestock,
			@totavecres = @totavecres + @qtestock + @qtestockres
	
	insert into #Resultats (tri,date,piece,qtestock,qtestockres,total,totavecres,ent,tiers)
	values (@tri,@date,@piece,@qtestock,@qtestockres,@total,@totavecres,@ent,@tiers)
	
	fetch stock
	into @tri,@date,@piece,@qtestock,@qtestockres,@ent,@tiers
	
end

close stock
deallocate cursor stock

drop table #Stockfinal

update #Resultats
set piece_liee=BELLIENCODE
from FBEL
where piece like 'BE%'
and BELCODE=piece
and BELARTICLE=@article

update #Resultats
set ent=CLNOM1 
from FCL 
where CLCODE=tiers
and piece like 'BE%'
 
update #Resultats
set tiers=SILDEPOT
from FSIL where SILCODE=piece
and piece like 'TD%' and SILARTICLE=@article
and SILQTE=(-1*qtestock)
 
select date,
(case when isnull(piece_liee,'')='' then piece else rtrim(piece)+' / '+rtrim(piece_liee) end),
qtestock,qtestockres,total,totavecres,ent,tiers
from #Resultats
order by seq


drop table #Resultats

end





go

