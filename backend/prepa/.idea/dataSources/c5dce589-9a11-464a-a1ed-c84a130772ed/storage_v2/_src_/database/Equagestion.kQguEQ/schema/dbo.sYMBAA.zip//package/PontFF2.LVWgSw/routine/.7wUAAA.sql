CREATE PROCEDURE dbo.PontFF2(@ent 			char(5) = null,
						@LaDate1		datetime = null,
					  	@LaDate2		datetime = null,
					  	@NumFact1		char(10) = null,
					  	@NumFact2		char(10) = null,
						@lejournal		char(4))
with recompile
as
begin

set arithabort numeric_truncation off


declare @Annee		varchar(4),
		@Mois		varchar(2),
		@Jour		varchar(2),
		@DateFact	varchar(8),
		@DateEch	varchar(8),
		@Journal	varchar(4),
		@Num		numeric(10,3),
		@totdebit	numeric(14,2),
		@totcredit	numeric(14,2),
		@debit		numeric(14,2),
		@credit		numeric(14,2),
		@debcre		tinyint,
		@compte		char(12),
		@spid		int,
		@site		int,
		@foclasse	varchar(10)

select	@Num=0.00,
		@spid = @@spid

select @site = KISITE from KInfos

					/*************** Table finale ************/

delete from FPF
where PFSPID = @spid

					/************** Tables de travail *********/

create table #Factures
(
code		char(10)		not null,
coursdev	real			not null,
nom			varchar(35)		null,
date		datetime		not null,
sanstva		tinyint			not null,
totdev		numeric(14,2)	not null,
totfr		numeric(14,2)	not null,
tottvadev	numeric(14,2)	not null,
tottvafr	numeric(14,2)	not null,
netdev		numeric(14,2)	not null,
netfr		numeric(14,2)	not null,
fournis		char(12)		not null,
numcompta	char(12)		not null,
factfo		varchar(12)		not null,
devise		varchar(4)		not null,
fraisfr		numeric(14,2)	not null,
fraisdev	numeric(14,2)	not null,
tafrais		char(4)			not null,
douanesfr	numeric(14,2)	not null,
douanesdev	numeric(14,2)	not null,
tadouanes	char(4)			not null,
transfr		numeric(14,2)	not null,
transdev	numeric(14,2)	not null,
tatrans		char(4)			not null,
tvafr		numeric(14,2)	not null,
tvadev		numeric(14,2)	not null,
tatva		char(4)			not null,
foclasse	varchar(10)		null
)


create table #Lignes
(
totalhtfr		numeric(14,2)	null,
totalhtdev		numeric(14,2)	null,
comptachat		char(12)		null,
taux			real			null,
comptetva		char(12)		null
)

create table #Taxes(
comptetva	 	char(12)		null,
taux			real			null,
taxefr			numeric(14,2)	null,
taxedev			numeric(14,2)	null
)

create table #LesTaxes(
comptetva	 	char(12)		null,
totalfr			numeric(14,2)	null,
totaldev		numeric(14,2)	null
)
					/******************* Selection des factures concernees ********************/

if (@NumFact1 is null) and (@LaDate1 is not null)
begin
  insert into #Factures (code,coursdev,nom,date,sanstva,totdev,totfr,tottvadev,tottvafr,netdev,
  netfr,fournis,numcompta,factfo,devise,fraisfr,fraisdev,tafrais,douanesfr,douanesdev,tadouanes,
  transfr,transdev,tatrans,tvafr,tvadev,tatva,foclasse)
  select FFCODE,FFCDEV,FFNOM,FFDATE,FFSANSTVA,FFTOTDEV,FFTOTFR,FFTOTTVADEV,FFTOTTVAFR,
  			FFNETDEV,FFNETFR,FFFO,FONUMCOMPTABLE,FFFACTFO,FFDEVISE,FFFRAISFR,FFFRAISDEV,
			FFTAFRAIS,FFDOUAFR,FFDOUADEV,FFTADOUA,FFTRANSFR,FFTRANSDEV,FFTATRANS,
			FFTVAFR,FFTVADEV,FFTATVA,FOCLASSE
  from FFF,FFO
  where FOCODE=FFFO
  and FFDATE between @LaDate1 and @LaDate2
  and FFNETFR != 0 and isnull(FFEXPORT,0)=0
  and (@ent is null or FFENT=@ent)
  order by FFCODE
end
else if (@NumFact1 is not null)
begin
  insert into #Factures (code,coursdev,nom,date,sanstva,totdev,totfr,tottvadev,tottvafr,netdev,
  netfr,fournis,numcompta,factfo,devise,fraisfr,fraisdev,tafrais,douanesfr,douanesdev,tadouanes,
  transfr,transdev,tatrans,tvafr,tvadev,tatva,foclasse)
  select FFCODE,FFCDEV,FFNOM,FFDATE,FFSANSTVA,FFTOTDEV,FFTOTFR,FFTOTTVADEV,FFTOTTVAFR,
  			FFNETDEV,FFNETFR,FFFO,FONUMCOMPTABLE,FFFACTFO,FFDEVISE,FFFRAISFR,FFFRAISDEV,
			FFTAFRAIS,FFDOUAFR,FFDOUADEV,FFTADOUA,FFTRANSFR,FFTRANSDEV,FFTATRANS,
			FFTVAFR,FFTVADEV,FFTATVA,FOCLASSE
  from FFF,FFO
  where FOCODE=FFFO
  and FFCODE between @NumFact1 and @NumFact2
  and FFNETFR != 0  and isnull(FFEXPORT,0)=0
  and (@ent is null or FFENT=@ent)
  order by FFCODE
end
  
					/******************* Declaration des curseurs ********************/

declare factures cursor
for select code,coursdev,nom,date,sanstva,totdev,totfr,tottvadev,tottvafr,
		netdev,netfr,fournis,numcompta,factfo,devise,fraisfr,fraisdev,tafrais,
		douanesfr,douanesdev,tadouanes,transfr,transdev,tatrans,tvafr,tvadev,tatva,foclasse
from #Factures
order by code
for read only


declare @code			char(10),
		@coursdev		real,
		@nom			varchar(35),
		@date			datetime,
		@sanstva		tinyint,
		@totdev			numeric(14,2),
		@totfr			numeric(14,2),
		@tottvadev		numeric(14,2),
		@tottvafr		numeric(14,2),
		@netdev			numeric(14,2),
		@netfr			numeric(14,2),
		@fournis		char(12),
		@numcompta		char(12),
		@factfo			varchar(12),
		@devise			varchar(4),
		@fraisfr		numeric(14,2),
		@fraisdev		numeric(14,2),
		@tafrais		char(4),
		@douanesfr		numeric(14,2),
		@douanesdev		numeric(14,2),
		@tadouanes		char(4),
		@transfr		numeric(14,2),
		@transdev		numeric(14,2),
		@tatrans		char(4),
		@tvafr			numeric(14,2),
		@tvadev			numeric(14,2),
		@tatva			char(4)


declare echeances cursor
for select EFDATEECH,EFECHFR,EFMODEREG,EFECHDEV
from FEF
where EFCODE=@code
and (@ent is null or EFENT=@ent)
for read only

declare @dateech	datetime,
		@echfr		numeric(14,2),
		@modereg	tinyint,
		@echdev		numeric(14,2)



declare lestaxes1 cursor
for select comptetva,totalfr
from #LesTaxes
where totalfr>0
for read only

declare lestaxes2 cursor
for select comptetva,totalfr
from #LesTaxes
where totalfr<0
for read only

declare 	@comptetva		char(12),
			@totalfr		numeric(14,2)
			
declare lignes1 cursor
for select comptachat,sum(totalhtfr)
from #Lignes
group by comptachat
having sum(totalhtfr)>0

declare lignes2 cursor
for select comptachat,sum(totalhtfr)
from #Lignes
group by comptachat
having sum(totalhtfr)<0

declare 	@comptachat		char(12),
			@sumtotalhtfr	numeric(14,2)
			
			/****-----------------****/

					/***************** Traitement des factures *****************/

open factures

fetch factures
into @code,@coursdev,@nom,@date,@sanstva,@totdev,@totfr,@tottvadev,
		@tottvafr,@netdev,@netfr,@fournis,@numcompta,@factfo,@devise,
		@fraisfr,@fraisdev,@tafrais,@douanesfr,@douanesdev,@tadouanes,
		@transfr,@transdev,@tatrans,@tvafr,@tvadev,@tatva,@foclasse

while (@@sqlstatus = 0)
begin
	select @Num=convert(int,@Num)+1
	
	select 	@Annee=convert(varchar(4),datepart(yy,@date)),
			@Mois=convert(varchar(2),datepart(mm,@date)),
			@Jour=convert(varchar(2),datepart(dd,@date))

	
	select @Journal=@lejournal
	
	if datalength(@Mois)=1
		select @Mois='0'+@Mois
	if datalength(@Jour)=1
		select @Jour='0'+@Jour
		
	select @DateFact=@Annee+@Mois+@Jour
	
						/************************ Ligne d''ecriture du compte fournisseur ******************/
	
	if @coursdev=1.00
	begin
		select 	@devise = null,
				@netdev = null
	end
	
	if @netfr>0
	begin
	  select @Num=@Num+0.001
	  
	  insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
	  					PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
	  values(@spid,@Journal,@numcompta,@DateFact,@Num,@factfo,
			 convert(varchar(40),(@factfo+' '+@fournis+' '+@devise+' '+convert(varchar(13),@netdev))),
			 null,null,@netfr,null,@devise,@netdev,@ent,@code)
	end
	else if @netfr<0
	begin
	  select @Num=@Num+0.001
	  
	  insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
	  					PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
	  values(@spid,@Journal,@numcompta,@DateFact,@Num,@factfo,
			 convert(varchar(40),(@factfo+' '+@fournis+' '+@devise+' '+convert(varchar(13),@netdev))),
			 null,abs(@netfr),null,null,@devise,abs(@netdev),@ent,@code)
	end
	
						/************************ Echeances ******************/
	
	open echeances
	
	fetch echeances
	into @dateech,@echfr,@modereg,@echdev
	
	while (@@sqlstatus = 0)
	begin
	
		if @devise = null
			select 	@echdev = null

		
		select 	@Annee=convert(varchar(4),datepart(yy,@dateech)),
				@Mois=convert(varchar(2),datepart(mm,@dateech)),
				@Jour=convert(varchar(2),datepart(dd,@dateech))

	
		if datalength(@Mois)=1
			select @Mois='0'+@Mois
		if datalength(@Jour)=1
			select @Jour='0'+@Jour
			
		select @DateEch=@Annee+@Mois+@Jour
		
		if @echfr>0
		begin
		  insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
	  					PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
		  select @spid,null,null,null,null,null,null,@DateEch,null,@echfr,@modereg,@devise,@echdev,@ent,null
		end
		else if @echfr<0
		begin
		  insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
	  					PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
		  select @spid,null,null,null,null,null,null,@DateEch,abs(@echfr),null,@modereg,@devise,abs(@echdev),@ent,null
		end
		
		fetch echeances
		into @dateech,@echfr,@modereg,@echdev
		
	end
		
	close echeances
	
		
						/**************** Lignes de la facture ***************/
		
	truncate table #Lignes
	
	insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
		select FFLTOTHT,FFLTOTDEV,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
		from FFF,FFFL,FFO, FTVL
		where FFCODE=FFLCODE and FFFO=FOCODE and TVLCODE=FFLTYPEVE and TVLCLASSE=FOCLASSE		
		and FFLTOTHT != 0
		and FFLCODE=@code
		and (@ent is null or (FFENT=@ent and FFLENT=@ent and TVLENT=@ent))
	
	if (@tafrais != '' and @fraisfr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @fraisfr,@fraisdev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tafrais
			and (@ent is null or TVLENT=@ent)
	
	if (@tadouanes != '' and @douanesfr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @douanesfr,@douanesdev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tadouanes
			and (@ent is null or TVLENT=@ent)
	
	if (@tatrans != '' and @transfr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @transfr,@transdev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tatrans
			and (@ent is null or TVLENT=@ent)
	
	if (@tatva != '' and @tvafr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @tvafr,@tvadev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tatva
			and (@ent is null or TVLENT=@ent)

	
					/**********   Traitement des Taxes   ****************/
	
   if @sanstva=0
	begin
 
	  truncate table #Taxes
	  
	  insert into #Taxes (comptetva,taux,taxefr,taxedev)
	  select comptetva,taux,
			  round(sum(totalhtfr)*(taux/100),2),
			  round(sum(totalhtdev)*(taux/100),2)
	  from #Lignes
	  group by comptetva,taux
	  
	  truncate table #LesTaxes
	  
	  if @devise = null
	   begin
		insert into #LesTaxes (comptetva,totalfr,totaldev)
		select comptetva,round(sum(taxefr),2),null
		from #Taxes
		group by comptetva
	   end
	  else
	   begin
		insert into #LesTaxes (comptetva,totalfr,totaldev)
		select comptetva,round(sum(taxefr),2),round(sum(taxedev),2)
		from #Taxes
		group by comptetva
	   end
	   
	   
	  open lestaxes1

	  fetch lestaxes1
	  into @comptetva, @totalfr
  
	  while (@@sqlstatus = 0)
	  begin
		select @Num=@Num+0.001
		
		insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
						  PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
		values(@spid,@Journal,@comptetva,@DateFact,@Num,@factfo,
				convert(varchar(40),(@factfo+' '+@fournis+' '+@devise+' '+convert(varchar(13),@netdev))),
				null,@totalfr,null,null,null,null,@ent,@code)
		
		fetch lestaxes1
		into @comptetva, @totalfr
	  end
	
	  close lestaxes1
	  
	  open lestaxes2

	  fetch lestaxes2
	  into @comptetva, @totalfr
  
	  while (@@sqlstatus = 0)
	  begin
		select @Num=@Num+0.001
	  
	    insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
	  					PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
	    values(@spid,@Journal,@comptetva,@DateFact,@Num,@factfo,
			  convert(varchar(40),(@factfo+' '+@fournis+' '+@devise+' '+convert(varchar(13),@netdev))),
			  null,null,abs(@totalfr),null,null,null,@ent,@code)
			  
	  	fetch lestaxes2
		into @comptetva, @totalfr
	  end
	  
	  close lestaxes2
	  
   end
	
	/********* Lignes d''ecritures de contrepartie  ***********/
	
	open lignes1

	fetch lignes1
	into @comptachat,@sumtotalhtfr

	while (@@sqlstatus = 0)
	begin
	  select @Num=@Num+0.001
	  
	  insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
						  PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
	  values(@spid,@Journal,@comptachat,@DateFact,@Num,@factfo,
			   convert(varchar(40),(@factfo+' '+@fournis+' '+@devise+' '+convert(varchar(13),@netdev))),
			   null,@sumtotalhtfr,null,null,null,null,@ent,@code)
			   
	  fetch lignes1
	  into @comptachat,@sumtotalhtfr
	end
	
	close lignes1
	
	open lignes2

	fetch lignes2
	into @comptachat,@sumtotalhtfr

	while (@@sqlstatus = 0)
	begin
	  select @Num=@Num+0.001
	
	  insert into FPF (PFSPID,PFJOURNAL,PFNUMCOMPTA,PFDATE,PFNUM,PFPIECE,PFLIB,PFDATEECH,
						  PFDEBIT,PFCREDIT,PFTRMODE,PFDEVISE,PFMTDEV,PFENT,PFPIECE_INTERNE)
	  values(@spid,@Journal,@comptachat,@DateFact,@Num,@factfo,
			   convert(varchar(40),(@factfo+' '+@fournis+' '+@devise+' '+convert(varchar(13),@netdev))),
			   null,null,abs(@sumtotalhtfr),null,null,null,@ent,@code)
	  
	  fetch lignes2
	  into @comptachat,@sumtotalhtfr
	end
	
	close lignes2
	 
	 				/***************** Traitement des differences de centimes */
	 
	 select @totdebit = 0, @totcredit = 0
	 
	 select @totdebit=sum(PFDEBIT),@totcredit=sum(PFCREDIT)
	 from FPF
	 where PFPIECE=@code
	 and PFSPID=@spid
	 
	 				/******************  debit ou credit *******/
	 select @credit=PFCREDIT
	 from FPF
	 where PFPIECE=@code
	 and PFNUMCOMPTA=@numcompta
	 and PFSPID=@spid
	 
	 if @credit > 0 select @debcre=1 else select @debcre=0
	 
	 				/****************** mise a jour d''une ligne de compte 6 si erreur de centimes < 0,50 *******/
	 
	 if (@totdebit != @totcredit)
	 begin
	 	if (abs(@totdebit - @totcredit) < 0.50)
	 	begin
			set rowcount 1
			
			select @compte=PFNUMCOMPTA
			from FPF
			where PFPIECE=@code
			and PFNUMCOMPTA like '6%'
	 		and PFSPID=@spid
			
			
			if (@debcre=0)
			begin
			  update FPF
			  set PFCREDIT=PFCREDIT+(@totdebit - @totcredit)
			  where PFNUMCOMPTA=@compte
			  and PFPIECE=@code
	 		  and PFSPID=@spid
			end
			else if (@debcre=1)
			begin
			  update FPF
			  set PFDEBIT=PFDEBIT+(@totcredit - @totdebit)
			  where PFNUMCOMPTA=@compte
			  and PFPIECE=@code
	 		  and PFSPID=@spid
			end
			
			set rowcount 0
		end
	 end
	 
	 				/***************** Facture suivante ***********/
	
	fetch factures
	into @code,@coursdev,@nom,@date,@sanstva,@totdev,@totfr,@tottvadev,
		@tottvafr,@netdev,@netfr,@fournis,@numcompta,@factfo,@devise,
		@fraisfr,@fraisdev,@tafrais,@douanesfr,@douanesdev,@tadouanes,
		@transfr,@transdev,@tatrans,@tvafr,@tvadev,@tatva,@foclasse
			
  end
  
  	close factures
	deallocate cursor echeances
	deallocate cursor factures
	deallocate cursor lestaxes1
	deallocate cursor lestaxes2
	deallocate cursor lignes1
	deallocate cursor lignes2
	
	/*------------ Inutilise ---------
	
	if @site=1
	begin
		update FPF
		set PFPIECE = ""EF"" + substring(PFPIECE,3,10)
		where PFPIECE is not null
		and PFSPID=@spid
	end
	
	------------ Fin de inutilise -----*/
	
	drop table #Factures
	drop table #Lignes
	drop table #Taxes
	drop table #LesTaxes
	
	
end
go

