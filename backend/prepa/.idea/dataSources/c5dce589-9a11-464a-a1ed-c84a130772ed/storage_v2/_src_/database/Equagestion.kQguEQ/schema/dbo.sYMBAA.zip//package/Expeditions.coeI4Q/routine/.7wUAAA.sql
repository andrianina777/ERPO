


create procedure Expeditions (	@ent	char(5)	= null,
								@date1	smalldatetime,
								@date2	smalldatetime,
								@client	char(12) = null,
								@repres	char(8) = null		/* VRP general */
							 )
with recompile
as
begin

if (@date2	is null)
select @date2=@date1

	select "Lignes d'expeditions du ",@date1," au ",@date2

	select Client=BELCL,Nom=BENOM,Representant=CCREPRES,
	nÃÂ°_Bordereau=BELCODE,Date=BELDATE,Article=BELARTICLE,
	Designation=ARLIB,Quantite=BELQTE
	from FBEL,FAR,FCC,FBE
	where BELARTICLE=ARCODE
	and BELLIENCODE=CCCODE
	and BELCODE=BECODE
	and BELDATE between @date1 and @date2
	and (@client is null or BELCL=@client)
	and (@repres is null or CCREPRES=@repres)
	and (@ent is null or (BELENT=@ent and BEENT=BELENT and CCENT=BELENT))
	order by BELCL

end



go

