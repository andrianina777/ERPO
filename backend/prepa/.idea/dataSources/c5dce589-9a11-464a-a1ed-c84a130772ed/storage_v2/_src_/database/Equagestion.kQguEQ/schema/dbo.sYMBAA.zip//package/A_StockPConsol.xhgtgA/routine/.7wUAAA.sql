


/* Procedure permettant de recuperer les stocks prevus sur une annee
	pour un ensemble d''articles consolides depuis le fichier FSP  */
	
	
create procedure A_StockPConsol (	@Annee		smallint,
						   		 	@chef		char(8) = null,
								 	@fournis	char(12) = null,
								 	@famille	char(8)	= null
								 )
with recompile
as
begin

set arithabort numeric_truncation off


declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int

declare @Janval		int
declare @Fevval		int
declare @Marval		int
declare @Avrval		int
declare @Maival		int
declare @Junval		int
declare @Juival		int
declare @Aouval		int
declare @Sepval		int
declare @Octval		int
declare @Novval		int
declare @Decval		int


create table #Global
(	
Qte		int				null,
Val		numeric(14,2)	null,
Mois	tinyint			null
)

create table #AR
(
Article		char(15)	not null,
Prix		numeric(14,2)	null
)


if ((@chef is null) and (@fournis is null) and (@famille is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFAM=@famille
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFO=@fournis
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null))
	begin
		insert  into #AR (Article,Prix)
		select ARCODE,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
	end


create unique clustered index article on #AR (Article)


insert into #Global (Qte,Val,Mois)
select sum(SPQTE),sum(SPQTE*Prix),SPMOIS
from FSP,#AR
where SPARTICLE=Article
and SPAN=@Annee
group by SPMOIS

drop table #AR


select @Janvier=Qte,	@Janval=Val	from #Global where Mois=1
select @Fevrier=Qte,	@Fevval=Val	from #Global where Mois=2
select @Mars=Qte,		@Marval=Val	from #Global where Mois=3
select @Avril=Qte,		@Avrval=Val	from #Global where Mois=4
select @Mai=Qte,		@Maival=Val	from #Global where Mois=5
select @Juin=Qte,		@Junval=Val	from #Global where Mois=6
select @Juillet=Qte,	@Juival=Val	from #Global where Mois=7
select @Aout=Qte,		@Aouval=Val	from #Global where Mois=8
select @Septembre=Qte,	@Sepval=Val	from #Global where Mois=9
select @Octobre=Qte,	@Octval=Val	from #Global where Mois=10
select @Novembre=Qte,	@Novval=Val	from #Global where Mois=11
select @Decembre=Qte,	@Decval=Val	from #Global where Mois=12


select 	isnull(@Janvier,0),isnull(@Fevrier,0),isnull(@Mars,0),
		isnull(@Avril,0),isnull(@Mai,0),isnull(@Juin,0),
		isnull(@Juillet,0),isnull(@Aout,0),isnull(@Septembre,0),
		isnull(@Octobre,0),isnull(@Novembre,0),isnull(@Decembre,0),
		isnull(@Janval,0),isnull(@Fevval,0),isnull(@Marval,0),
		isnull(@Avrval,0),isnull(@Maival,0),isnull(@Junval,0),
		isnull(@Juival,0),isnull(@Aouval,0),isnull(@Sepval,0),
		isnull(@Octval,0),isnull(@Novval,0),isnull(@Decval,0)
		
drop table #Global

end



go

