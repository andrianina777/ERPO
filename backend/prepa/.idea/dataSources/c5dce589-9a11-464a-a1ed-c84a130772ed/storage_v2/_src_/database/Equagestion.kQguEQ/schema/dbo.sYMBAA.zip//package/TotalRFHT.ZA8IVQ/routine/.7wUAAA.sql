


create procedure TotalRFHT(	@ent		char(5) = null,
							@code 		char(10))
with recompile
as
begin

	set arithabort numeric_truncation off


	declare @Total 		numeric(14,2),
			@TotalDev	numeric(14,2)
	
	select 	@Total=sum(round(RFLTOTALHT,2)),
			@TotalDev=sum(round(RFLTOTALDEV,2))
	from FRFL
	where RFLCODE=@code
	and (@ent is null or RFLENT=@ent)
	
	
	update FRF set 	RFTOTALHT=@Total+RFPIECESFR,
					RFTOTALDEV=@TotalDev+RFPIECESDEV
	where RFCODE=@code
	and (@ent is null or RFENT=@ent)
	
	
end



go

