/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheFactResv
grant execute  on bp_afficheFactResv to public
*/

CREATE PROCEDURE dbo.bp_afficheFactResv (@facture char(10),@client char(8))




as
begin

select FACTURE,DATE,ARTICLE,LIBELLE,QTE_RESTANTE,CLIENT into #FRS
from VIEW_FACTURE_RESERVE_TOTAL where CLIENT=@client and (FACTURE=@facture or @facture='' or @facture=null)

select FALCODE,FALARTICLE,FALCL,SUM(FALQTE) as TOTAL into #FFAL from FFAL  inner join x_TransfertReservation on x_TR_Client=FALCL and  x_TR_Facture=FALCODE
where FALCL=@client and (FALCODE=@facture or @facture='' or @facture=null) 
group by FALCODE,FALARTICLE,FALCL


select FACTURE,DATE,ARTICLE,LIBELLE,TOTAL,QTE_RESTANTE from #FRS inner join #FFAL on (FALCODE=FACTURE and ARTICLE=FALARTICLE and FALCL=CLIENT)

drop table #FRS,#FFAL

end
go

