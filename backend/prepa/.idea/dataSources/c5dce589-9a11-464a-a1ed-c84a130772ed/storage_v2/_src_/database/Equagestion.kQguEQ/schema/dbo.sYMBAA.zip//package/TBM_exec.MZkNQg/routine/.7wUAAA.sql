



/* Procedure permettant d''appliquer des depreciations par article */
	

create procedure TBM_exec (	@ar		char(15),
							@mois	int,
							@tx		numeric(8,4))
with recompile
as
begin

declare	@pvorig	numeric(14,2),
		@pvold	numeric(14,2),
		@pvnew	numeric(14,2),
		@seq	int

if exists (select * from FARM where ARMAR = @ar)
begin
	select @pvorig = ARMPVOLD from FARM 
		where ARMAR = @ar and ARMDATE = (select min(ARMDATE) from FARM where ARMAR = @ar)
	select @pvold = ARMPVNEW from FARM
		where ARMAR = @ar and ARMDATE = (select max(ARMDATE) from FARM where ARMAR = @ar)
end
else
begin
	select @pvorig = ARPVHT from FAR where ARCODE = @ar
	select @pvold = @pvorig
end

select @pvnew = convert(numeric(14,2),@pvorig * (100 - @tx) / 100)

if @pvnew != @pvold
begin

	exec eq_GetSeq_proc 'FARM',1,@seq output

	insert into FARM (ARMSEQ,ARMAR,ARMDATE,ARMMOIS,ARMTX,ARMPVOLD,ARMPVNEW,ARMDEPREC)
	values (@seq,@ar,getdate(),@mois,@tx,@pvold,@pvnew,1)
	
	update FAR
	set 
	ARPRIXNET = 1,
	ARPVHT =  @pvnew
	where ARCODE = @ar

end

end



go

