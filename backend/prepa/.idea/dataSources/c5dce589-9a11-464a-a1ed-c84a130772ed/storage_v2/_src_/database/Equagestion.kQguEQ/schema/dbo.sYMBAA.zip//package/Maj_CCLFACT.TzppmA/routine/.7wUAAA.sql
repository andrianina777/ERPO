


create procedure Maj_CCLFACT (@facode		char(10),
							  @modif		int			/* 1 = en ajout, -1 = en effacement */
							 )
with recompile
as
begin


select 	CODEBE = FALLIENCODE,
		NUMLIGNE = FALLIENNUM
into #BE
from FFAL
where FALCODE = @facode
group by FALLIENCODE,FALLIENNUM


select CODECC = BELLIENCODE, NUMLIGNECC = BELLIENNUM
into #CC
from FBEL,#BE
where BELCODE = CODEBE
and BELNUM = NUMLIGNE
and BELLIENCODE like 'CC%'
group by BELLIENCODE,BELLIENNUM

declare commandes cursor 
for select CODECC,NUMLIGNECC
from #CC
for read only

declare @code	char(10),
		@ligne	int

open commandes

fetch commandes
into @code,@ligne

while (@@sqlstatus = 0)
	begin
	
	update FCCL
	set CCLFACT = isnull(CCLFACT,0) +  @modif
	where CCLCODE = @code
	and CCLNUM = @ligne
	
	fetch commandes
	into @code,@ligne
	
end

close commandes
deallocate cursor commandes

end



go

