



create procedure annee (@nombre	int output)
with recompile
as
begin

declare @init	int
select 	@init = @nombre

if @nombre < 12 and @nombre > -12
	return(0)

exec modulo @nombre output, 12

if @nombre = 0
	select @nombre = 12
	
select @nombre = (@init - @nombre)/12

end



go

