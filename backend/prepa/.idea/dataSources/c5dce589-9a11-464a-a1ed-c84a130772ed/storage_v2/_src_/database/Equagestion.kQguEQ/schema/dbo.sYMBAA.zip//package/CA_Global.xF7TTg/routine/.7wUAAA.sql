


create procedure CA_Global (@ent	char(5) = null,
							@annee	smallint,
							@mois1	tinyint = null,
							@mois2	tinyint = null,
							@srfa	tinyint = 0,
							@division char(8) = null,
							@nonstats tinyint = 0
							)
with recompile
as
begin

    set arithabort numeric_truncation off


  	if @mois1 is null
  	select @mois1=1,@mois2=12

  	if isnull(@mois2,0)=0
  	select @mois2=@mois1

  
   	create table #CA
   	(
	MOIS		tinyint			not null,
   	CA_AN_1P	numeric(14,2)		null,
   	CA_AN		numeric(14,2)		null
   	)
     
    
  /* AN - 1 partiel */
  
	insert into #CA (MOIS,CA_AN_1P,CA_AN)
	select STMOIS,sum(STCAFA),0
	from FST,FAR
	where ARCODE=START
	and STAN=@annee-1
	and STMOIS between @mois1 and @mois2
	and (@ent is null or STENT=@ent)
	and (@srfa=0 or ARTYPE != 6)
	and (@nonstats=0 or ARTYPE != 8)
	and (@division is null or ARDEPART=@division)	
	group by STMOIS
  
  /* AN en cours partiel */
  
	insert into #CA (MOIS,CA_AN_1P,CA_AN)
	select STMOIS,0,sum(STCAFA)
	from FST,FAR
	where ARCODE=START
	and STAN=@annee
	and STMOIS between @mois1 and @mois2
	and (@ent is null or STENT=@ent)
	and (@srfa=0 or ARTYPE != 6)
	and (@nonstats=0 or ARTYPE != 8)
	and (@division is null or ARDEPART=@division)
	group by STMOIS

 	
  	select MOIS,sum(CA_AN_1P),sum(CA_AN),(sum(CA_AN)-sum(CA_AN_1P))
  	from #CA
  	group by MOIS
 	
  drop table #CA
	
end



go

