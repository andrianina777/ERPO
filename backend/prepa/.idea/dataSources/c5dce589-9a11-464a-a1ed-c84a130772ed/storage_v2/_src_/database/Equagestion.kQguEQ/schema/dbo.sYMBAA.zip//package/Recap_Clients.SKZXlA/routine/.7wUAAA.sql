





create procedure Recap_Clients ( @ent		char(5)		= null)
with recompile
as
begin

set arithabort numeric_truncation off

create table #Finale
(
client		char(12)		not null,
factnonexp	numeric(14,2)	not null,
benonfact	numeric(14,2)	not null,
ccreliquats	numeric(14,2)	not null
)


insert into #Finale (client,factnonexp,benonfact,ccreliquats)
select FACL,isnull(sum(FANETAPAYER),0),0,0
from FFA,FRFA
where RFASEQ=FASEQ
and FANETAPAYER != 0
group by FACL

insert into #Finale (client,factnonexp,benonfact,ccreliquats)
select BELCL,0,isnull(sum(BELTOTALHT),0),0
from FBEL,FRBE
where RBESEQ=BELSEQ
and BELTOTALHT != 0
group by BELCL

insert into #Finale (client,factnonexp,benonfact,ccreliquats)
select CCLCL,0,0,isnull(sum(CCLTOTALHT/CCLQTE*RCCQTE),0)
from FCCL,FRCC
where RCCSEQ=CCLSEQ
and CCLTOTALHT != 0
group by CCLCL

create index client on #Finale(client)


select Sedentaire=CLREP,Client=client,Nom=CLNOM1,Num_Comptable=CLNUMCOMPTABLE,
		FacturesTTC_nonexportees=isnull(sum(factnonexp),0),
		BE_nonfactures=isnull(sum(benonfact),0),
		Cdes_a_expedier=isnull(sum(ccreliquats),0)
from #Finale,FCL
where CLCODE=client
group by CLREP,client,CLNOM1,CLNUMCOMPTABLE
order by client


drop table #Finale


end



go

