



create procedure Tarif_Manquant (@ent	 char(5)  = null,
								 @devise char(3))
as
begin

declare @lignes		int,
		@labase		varchar(30),
		@encours	int,
		@compteur	int,
		@groupe		char(16)
select  @labase = db_name(),
		@lignes = 0,
		@encours = 0,
		@compteur = 0


create table #Finale
(
code	char(15)		null,
arfour	char(30)	null,
arlib	varchar(80)	null,
tfcode	char(8)		null
)

select @lignes = 0

declare boucle cursor 
for select ARCODE,ARREFFOUR,ARLIB
from FAR
where AROLD=0
for read only

declare @code	char(15),
		@arfour	char(30),
		@arlib	varchar(80)

open boucle

fetch boucle
into @code,@arfour,@arlib

while (@@sqlstatus = 0)
	begin
		
	insert into #Finale (code,arfour,arlib,tfcode)
	select @code,@arfour,@arlib,TFCODE
	from FTF
	where not exists (select * from FTF,FART 
						where ARTAR=@code
						and ARTTARIF=TFCODE
						and ARTDEV=@devise
						and (@ent is null or TFENT=@ent))

	
	fetch boucle
	into @code,@arfour,@arlib
	
end

close boucle
deallocate cursor boucle

select code,arfour,arlib,tfcode
from #Finale
order by code,tfcode

drop table #Finale

end



go

