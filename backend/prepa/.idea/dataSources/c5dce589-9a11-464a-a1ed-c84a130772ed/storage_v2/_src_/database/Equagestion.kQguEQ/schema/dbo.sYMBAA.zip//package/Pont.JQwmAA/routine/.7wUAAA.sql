/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.Pont
grant execute on Pont to public
*/



create procedure Pont(	@ent			char(5) = null,
						@LaDate1		datetime,
					  	@LaDate2		datetime,
					  	@NumFact1		char(10) = null,
					  	@NumFact2		char(10) = null,
					  	@Journal		char(4),
					  	@Exportation	tinyint,
						@valorisation	tinyint	 = 0,		/* 0 = PR FIFO, 1 = PRMP, 2 = PUMP, (3 = PRMU mensuel, 4 = DPA unitaire) */
						@verif			tinyint	 = 0
					 )
with recompile
as
begin

set arithabort numeric_truncation off


declare @Annee			varchar(4),
		@Mois			varchar(2),
		@Jour			varchar(2),
		@DateFact		varchar(8),
		@DateEch		varchar(8),
		@TotEscompte	numeric(14,2),
		@Num			numeric(10,3),
		@totdebit		numeric(14,2),
		@totcredit		numeric(14,2),
		@debit			numeric(14,2),
		@credit			numeric(14,2),
		@debcre			tinyint,
		@compte			char(12),
		@spid			int,
		@site			int,
		@count			int,
		@devref			char(3),
		@article		char(15),
		@PrixRevient		numeric(14,4),
		@PrixRevientLigne	numeric(14,2),
		@qte			int,
		@total			numeric(14,2),
		@totech			numeric(14,2),
		@lib			varchar(40),
		@prefseq		tinyint	

select 	@Num=0.00,
		@spid = @@spid

select @site = KISITE from KInfos

execute eqGetAutorisations_out 'EquaGestion','Factures_Clients','SEQFACT',@prefseq output

if @prefseq is null
	select @prefseq = 0

select @devref=PDEVREF from KParam where (@ent is null or PENT=@ent)

					/*************** Table des differences pour verification **********/
					
create table #Dif
(
code	char(10)		not null,
lib		varchar(40)			null,
differe	numeric(14,2)	not null,
gravite	tinyint			not null,	/* 0 = autorise export tout de meme, 1 = interdit export */
seq		numeric(14,0)	identity
)

		/******************	Maj de la table finale ****************/

delete from FPC
where PCSPID = @spid

		/****************** Tables de travail ***********/


create table #Lignes
(
totalht			numeric(14,2)	null,
comptevente		char(12)		null,
taux			real			null,
sansesc			tinyint			null,
comptetva		char(12)		null,
escompte		numeric(14,2)	null,
comptexo		char(12)		null,
cptchdebit		char(12)		null,
cptchcredit		char(12)		null,
article			char(15)		null,
lettre			char(4)			null,
qte				int				null,
offert			tinyint			null,
compteDEEE		char(12)		null,
ecotaxe			numeric(14,2)	null
)


create table #Factures
(
nom			varchar(40)		null,
date		datetime		null,
tr1			char(8)			null,
tr2			char(8)			null,
tr3			char(8)			null,
tr4			char(8)			null,
trdate1		datetime		null,
trdate2		datetime		null,
trdate3		datetime		null,
trdate4		datetime		null,
regl1		numeric(14,2)	null,
regl2		numeric(14,2)	null,
regl3		numeric(14,2)	null,
regl4		numeric(14,2)	null,
mode1		tinyint			null,
mode2		tinyint			null,
mode3		tinyint			null,
mode4		tinyint			null,
sanstva		tinyint			null,
escompte	numeric(14,2)	null,
netapayer	numeric(14,2)	null,
tauxesc		real			null,
clfact		char(12)		null,
numcompta	char(12)		null,
code		char(15)		null,
devise		char(3)			null,
accepte		tinyint			null,
numlivre	char(12)		null,
codeseq		char(10)		null
)

create table #Taxes
(
comptetva 		char(12)		null,
taux			real			null,
taxe			numeric(14,2)	null
)

create table #LesTaxes
(
comptetva	 	char(12)		null,
totaltaxe		numeric(14,2)	null
)

create table #Offertes
(
cptchdebit		char(12)		null,
cptchcredit		char(12)		null,
total			numeric(14,2)	null,
offertes		tinyint			null
)

			/*********** Selection des factures concernees **********/

if (@Exportation=0 and @NumFact1 is null)
  begin
  	insert into #Factures (nom,date,tr1,tr2,tr3,tr4,trdate1,trdate2,trdate3,trdate4,
							regl1,regl2,regl3,regl4,mode1,mode2,mode3,mode4,sanstva,
							escompte,netapayer,tauxesc,clfact,numcompta,code,devise,
							accepte,numlivre,codeseq)
	select FANOM,FADATE,FATR1,FATR2,FATR3,FATR4,FATRDATE1,FATRDATE2,FATRDATE3,FATRDATE4,
				FAREGL1,FAREGL2,FAREGL3,FAREGL4,FAMODEREG1,FAMODEREG2,FAMODEREG3,FAMODEREG4,
				FASANSTVA,FAESCOMPTE,FANETAPAYER,
				FATAUXESC,FACLFACT,a.CLNUMCOMPTABLE,FACODE,FADEV,isnull(a.CLACCEPTEE,0),b.CLNUMCOMPTABLE,FACODESEQ
	from FFA,FCL a,FCL b
	where a.CLCODE = FACLFACT
	and b.CLCODE = FACL
	and FADATE between @LaDate1 and @LaDate2
	and isnull(FASANSTVA,0)=0
	and isnull(FACOMPTA,0)=0
	and (@ent is null or (FAENT=@ent and a.CLENT=@ent))
	order by FACODE
  end
else if (@Exportation=0 and @NumFact1 is not null)
  begin
    insert into #Factures (nom,date,tr1,tr2,tr3,tr4,trdate1,trdate2,trdate3,trdate4,
							regl1,regl2,regl3,regl4,mode1,mode2,mode3,mode4,sanstva,
							escompte,netapayer,tauxesc,clfact,numcompta,code,devise,
							accepte,numlivre,codeseq)
	select FANOM,FADATE,FATR1,FATR2,FATR3,FATR4,FATRDATE1,FATRDATE2,FATRDATE3,FATRDATE4,
				FAREGL1,FAREGL2,FAREGL3,FAREGL4,FAMODEREG1,FAMODEREG2,FAMODEREG3,FAMODEREG4,
				FASANSTVA,FAESCOMPTE,FANETAPAYER,
				FATAUXESC,FACLFACT,a.CLNUMCOMPTABLE,FACODE,FADEV,isnull(a.CLACCEPTEE,0),b.CLNUMCOMPTABLE,FACODESEQ
	from FFA,FCL a,FCL b
	where a.CLCODE = FACLFACT
	and b.CLCODE = FACL
	and FADATE between @LaDate1 and @LaDate2
	and FACODE between @NumFact1 and @NumFact2
	and isnull(FASANSTVA,0)=0
	and isnull(FACOMPTA,0)=0
	and (@ent is null or (FAENT=@ent and a.CLENT=@ent))
	order by FACODE
  end
else if (@Exportation=1 and @NumFact1 is null)
  begin
    insert into #Factures (nom,date,tr1,tr2,tr3,tr4,trdate1,trdate2,trdate3,trdate4,
							regl1,regl2,regl3,regl4,mode1,mode2,mode3,mode4,sanstva,
							escompte,netapayer,tauxesc,clfact,numcompta,code,devise,
							accepte,numlivre,codeseq)
	select FANOM,FADATE,FATR1,FATR2,FATR3,FATR4,FATRDATE1,FATRDATE2,FATRDATE3,FATRDATE4,
				FAREGL1,FAREGL2,FAREGL3,FAREGL4,FAMODEREG1,FAMODEREG2,FAMODEREG3,FAMODEREG4,
				FASANSTVA,FAESCOMPTE,FANETAPAYER,
				FATAUXESC,FACLFACT,a.CLNUMCOMPTABLE,FACODE,FADEV,isnull(a.CLACCEPTEE,0),b.CLNUMCOMPTABLE,FACODESEQ
	from FFA,FCL a,FCL b
	where a.CLCODE = FACLFACT
	and b.CLCODE = FACL
	and FADATE between @LaDate1 and @LaDate2
	and isnull(FASANSTVA,0)=1
	and isnull(FACOMPTA,0)=0
	and (@ent is null or (FAENT=@ent and a.CLENT=@ent))
	order by FACODE
  end
else if (@Exportation=1 and @NumFact1 is not null)
  begin
    insert into #Factures (nom,date,tr1,tr2,tr3,tr4,trdate1,trdate2,trdate3,trdate4,
							regl1,regl2,regl3,regl4,mode1,mode2,mode3,mode4,sanstva,
							escompte,netapayer,tauxesc,clfact,numcompta,code,devise,
							accepte,numlivre,codeseq)
	select FANOM,FADATE,FATR1,FATR2,FATR3,FATR4,FATRDATE1,FATRDATE2,FATRDATE3,FATRDATE4,
				FAREGL1,FAREGL2,FAREGL3,FAREGL4,FAMODEREG1,FAMODEREG2,FAMODEREG3,FAMODEREG4,
				FASANSTVA,FAESCOMPTE,FANETAPAYER,
				FATAUXESC,FACLFACT,a.CLNUMCOMPTABLE,FACODE,FADEV,isnull(a.CLACCEPTEE,0),b.CLNUMCOMPTABLE,FACODESEQ
	from FFA,FCL a,FCL b
	where a.CLCODE = FACLFACT
	and b.CLCODE = FACL
	and FADATE between @LaDate1 and @LaDate2
	and FACODE between @NumFact1 and @NumFact2
	and isnull(FASANSTVA,0)=1
	and isnull(FACOMPTA,0)=0
	and (@ent is null or (FAENT=@ent and a.CLENT=@ent))
	order by FACODE
  end

create unique index code on #Factures (code)

			/*********** Declaration des curseurs *******************/

declare factures cursor
for select nom,date,tr1,tr2,tr3,tr4,trdate1,trdate2,trdate3,trdate4,regl1,regl2,regl3,regl4,
			mode1,mode2,mode3,mode4,sanstva,escompte,netapayer,tauxesc,clfact,numcompta,code,
			devise,accepte,numlivre,codeseq
from #Factures
order by code
for read only

declare 	@nom			varchar(40),
			@date			datetime,
			@tr1			char(8),
			@tr2			char(8),
			@tr3			char(8),
			@tr4			char(8),
			@trdate1		datetime,
			@trdate2		datetime,
			@trdate3		datetime,
			@trdate4		datetime,
			@regl1			numeric(14,2),
			@regl2			numeric(14,2),
			@regl3			numeric(14,2),
			@regl4			numeric(14,2),
			@mode1			tinyint,
			@mode2			tinyint,
			@mode3			tinyint,
			@mode4			tinyint,
			@sanstva		tinyint,
			@escompte		numeric(14,2),
			@netapayer		numeric(14,2),
			@tauxesc		real,
			@clfact			char(12),
			@numcompta		char(12),
			@code			char(10),
			@devise			char(3),
			@accepte		tinyint,
			@numlivre		char(12),
			@codeseq		char(10)
			
declare 	@comptetva		char(12),
			@totaltaxe		numeric(14,2),
			@comptevente	char(12),
			@sumtotalht		numeric(14,2),
			@cptchdebit		char(12),
			@cptchcredit	char(12),
			@sumPRMP		numeric(14,2),
			@sumFIFO		numeric(14,2),
			@offert			tinyint,
			@comptecotaxe	char(12),
			@sumecotaxe		numeric(14,2)


declare lestaxes1 cursor
for select comptetva,totaltaxe
from #LesTaxes
where totaltaxe>0
for read only

declare lestaxes2 cursor
for select comptetva,totaltaxe
from #LesTaxes
where totaltaxe<0
for read only


			
declare lignes1 cursor
for select comptevente,sum(totalht),sum(ecotaxe)
from #Lignes
where totalht != 0
group by comptevente
having sum(totalht)<>0

declare lignes2 cursor									/* inutilise */
for select comptevente,sum(totalht),sum(ecotaxe)
from #Lignes
where totalht != 0
group by comptevente
having sum(totalht)<0

declare lignes3 cursor
for select cptchdebit,cptchcredit,sum(isnull(ARPRM,0)*qte),round(sum(isnull((STPAHT+STFRAIS),0)/CVLOT*qte),2),offert
from #Lignes,FAR,FSTOCK,FCV
where totalht = 0
and ARCODE=article
and ARUNITACHAT=CVUNIF
and STAR=article
and STLETTRE=lettre
group by cptchdebit,cptchcredit,offert

declare lignes_offertes cursor
for select article,cptchdebit,cptchcredit,sum(qte),offert
from #Lignes,FAR,FSTOCK,FCV
where totalht = 0
and ARCODE=article
and ARUNITACHAT=CVUNIF
and STAR=article
and STLETTRE=lettre
group by article,cptchdebit,cptchcredit,offert

declare tot_offertes cursor
for select cptchdebit,cptchcredit,sum(total),offertes
from #Offertes
group by cptchdebit,cptchcredit,offertes


declare ecotaxes cursor
for select comptevente,sum(totalht),compteDEEE,sum(ecotaxe)
from #Lignes
group by comptevente,compteDEEE		

			/*********** Traitement des factures *********************/


open factures

fetch factures
into @nom,@date,@tr1,@tr2,@tr3,@tr4,@trdate1,@trdate2,@trdate3,@trdate4,
	 @regl1,@regl2,@regl3,@regl4,
	 @mode1,@mode2,@mode3,@mode4,
	 @sanstva,@escompte,@netapayer,@tauxesc,@clfact,@numcompta,@code,@devise,
	 @accepte,@numlivre,@codeseq

while (@@sqlstatus = 0)
begin
	
	select @Num=convert(int,@Num)+1
	
	select 	@Annee=convert(varchar(4),datepart(yy,@date)),
			@Mois=convert(varchar(2),datepart(mm,@date)),
			@Jour=convert(varchar(2),datepart(dd,@date))

	if datalength(@Mois)=1
		select @Mois='0'+@Mois
	if datalength(@Jour)=1
		select @Jour='0'+@Jour
		
	select @DateFact=@Annee+@Mois+@Jour
	
	if @devise=@devref select @devise=''
	
	if @netapayer>0
	begin
	  select @Num=@Num+0.001
	
	  insert into  FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE,PCNUMLIVRE)
	  values(@spid,@Journal,@numcompta,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end)+' '+@devise,substring(@nom,1,36)+' '+@devise,null,@netapayer,null,null,@ent,null,@numlivre)
	end
	else if @netapayer<0
	begin
	  select @Num=@Num+0.001
	
	  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE,PCNUMLIVRE)
	  values(@spid,@Journal,@numcompta,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end)+' '+@devise,substring(@nom,1,36)+' '+@devise,null,null,abs(@netapayer),null,@ent,null,@numlivre)
	end
	
	/************************ Echeances ******************/
	select @totech = 0
		
	if isnull(@tr1,'')!=''
	begin
	
		
		if @verif=1
		begin
		  if (@trdate1='' or @trdate1 is null)
		  begin
			  insert into #Dif (code,lib,differe,gravite)
			  values ((case when @prefseq=0 then @code else @codeseq end),' date d'' echeance 1 manquante : valeur =>',isnull(@regl1,0),1)
		  end
		end
		
		select @totech = @totech + isnull(@regl1,0)
		
		select 	@Annee=convert(varchar(4),datepart(yy,@trdate1)),
				@Mois=convert(varchar(2),datepart(mm,@trdate1)),
				@Jour=convert(varchar(2),datepart(dd,@trdate1))

	
		if datalength(@Mois)=1
			select @Mois='0'+@Mois
		if datalength(@Jour)=1
			select @Jour='0'+@Jour
			
		select @DateEch=@Annee+@Mois+@Jour
		if @mode1 not in (3,4,5,6) select @accepte=0
		
		if @regl1>0
		begin
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,@regl1,null,@mode1,@ent,@accepte
		end
		else if @regl1<0
		begin
		  	insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,null,abs(@regl1),@mode1,@ent,@accepte
		end
		
	end
		
	if isnull(@tr2,'')!=''
	begin

		if @verif=1
		begin
		  if (@trdate2='' or @trdate2 is null)
		  begin
			  insert into #Dif (code,lib,differe,gravite)
			  values ((case when @prefseq=0 then @code else @codeseq end),' date d'' echeance 2 manquante : valeur =>',isnull(@regl2,0),1)
		  end
		end
		  
		select @totech = @totech + isnull(@regl2,0)

		
		select 	@Annee=convert(varchar(4),datepart(yy,@trdate2)),
				@Mois=convert(varchar(2),datepart(mm,@trdate2)),
				@Jour=convert(varchar(2),datepart(dd,@trdate2))

	
		if datalength(@Mois)=1
			select @Mois='0'+@Mois
		if datalength(@Jour)=1
			select @Jour='0'+@Jour
			
		select @DateEch=@Annee+@Mois+@Jour
		if @mode2 not in (3,4,5,6)  select @accepte=0
		
		if @regl2>0
		begin
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,@regl2,null,@mode2,@ent,@accepte
		end
		else if @regl2<0
		begin
		  	insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,null,abs(@regl2),@mode2,@ent,@accepte
		end
		
	end
		
	if isnull(@tr3,'')!=''
	begin
	
		if @verif=1
		begin
		  if (@trdate3='' or @trdate3 is null)
		  begin
			  insert into #Dif (code,lib,differe,gravite)
			  values ((case when @prefseq=0 then @code else @codeseq end),' date d''echeance 3 manquante : valeur =>',isnull(@regl3,0),1)
		  end
		end
		  
		select @totech = @totech + isnull(@regl3,0)
	
		
		select 	@Annee=convert(varchar(4),datepart(yy,@trdate3)),
				@Mois=convert(varchar(2),datepart(mm,@trdate3)),
				@Jour=convert(varchar(2),datepart(dd,@trdate3))

	
		if datalength(@Mois)=1
			select @Mois='0'+@Mois
		if datalength(@Jour)=1
			select @Jour='0'+@Jour
			
		select @DateEch=@Annee+@Mois+@Jour
		if @mode3 not in (3,4,5,6) select @accepte=0
		
		if @regl3>0
		begin
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,@regl3,null,@mode3,@ent,@accepte
		end
		else if @regl3<0
		begin
		  	insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,null,abs(@regl3),@mode3,@ent,@accepte
	 
	end
		
	end
			
	if isnull(@tr4,'')!=''
	begin

		if @verif=1
		begin
		  if (@trdate4='' or @trdate4 is null)
		  begin
			  insert into #Dif (code,lib,differe,gravite)
			  values ((case when @prefseq=0 then @code else @codeseq end),' date d''echeance 4 manquante : valeur =>',isnull(@regl4,0),1)
		  end
		end
		  
		select @totech = @totech + isnull(@regl4,0)

		
		select 	@Annee=convert(varchar(4),datepart(yy,@trdate4)),
				@Mois=convert(varchar(2),datepart(mm,@trdate4)),
				@Jour=convert(varchar(2),datepart(dd,@trdate4))

	
		if datalength(@Mois)=1 

			select @Mois='0'+@Mois
		if datalength(@Jour)=1
			select @Jour='0'+@Jour
			
		select @DateEch=@Annee+@Mois+@Jour
		if @mode4 not in (3,4,5,6) select @accepte=0
		
		if @regl4>0
		begin
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,@regl4,null,@mode4,@ent,@accepte
		end
		else if @regl4<0
		begin
		  	insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
	  					PCDEBIT,PCCREDIT,PCTRMODE,PCENT,PCACCEPTE)
	  		select @spid,null,null,null,null,null,null,@DateEch,null,abs(@regl4),@mode4,@ent,@accepte
		end
		
	end
	
	if @verif=1
	  begin
	  if @totech != @netapayer
		begin
			insert into #Dif (code,lib,differe,gravite)
			values ((case when @prefseq=0 then @code else @codeseq end),' total des echeances - net a payer',isnull(@totech,0)-isnull(@netapayer,0),1)
		end
	  end
		
				/**************** Lignes  de la facture non offertes ****************/
		
	truncate table #Lignes
	
	insert into #Lignes (totalht,comptevente,taux,sansesc,comptetva,escompte,comptexo,compteDEEE,ecotaxe)
	select FALTOTALHT,TVLCPT,TVLTAUXTVA,TVSANSESC,TVLCOMPTETVA,
			round(FALTOTALHT*@tauxesc*(1-TVSANSESC),2),TVLCPTSANSTVA,isnull(TVLCPT3ETTR,''),isnull(FALECOTAXE,0)
	from FFAL,FCL, FTV, FTVL
	where FALCODE=@code and CLCODE=@clfact
	and TVCODE=FALTYPEVE and TVLCODE=FALTYPEVE and TVLCLASSE=CLCLASSE
	and FALTOTALHT!=0
	and (@ent is null or (FALENT=@ent and CLENT=@ent and TVLENT=@ent))
 
	
	if @sanstva=1
		update #Lignes set comptevente=comptexo
	  	
	/**********   Calcul des Taxes   ****************/
	
	
   if @sanstva=0
	begin
	
 	/* faire tous les calculs avec	(totalht-escompte) */
 
 	truncate table #Taxes
	
 	insert into #Taxes (comptetva,taux,taxe)
 	select comptetva,taux,round(sum(totalht-escompte)*(taux/100),2)
	from #Lignes
	group by comptetva,taux
	
	truncate table #LesTaxes
	
	insert into #LesTaxes (comptetva,totaltaxe)
	select comptetva,round(sum(taxe),2)
 
	from #Taxes
	group by comptetva
	
				/*********** Insertion des lignes de taxes **********/
	
	open lestaxes1

	fetch lestaxes1
	into @comptetva, @totaltaxe

	while (@@sqlstatus = 0)
	begin
	  select @Num=@Num+0.001
	  
	  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
						  PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
	  values(@spid,@Journal,@comptetva,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
			  null,null,@totaltaxe,null,@ent)
			  
	  fetch lestaxes1
	  into @comptetva, @totaltaxe
	end
	
	close lestaxes1
	
	open lestaxes2

	fetch lestaxes2
	into @comptetva, @totaltaxe

	while (@@sqlstatus = 0)
	begin	
	  select @Num=@Num+0.001
	  
	  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
						PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
	  values(@spid,@Journal,@comptetva,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
			  null,abs(@totaltaxe),null,null,@ent)
			  
	  fetch lestaxes2
	  into @comptetva, @totaltaxe
	end
	
	close lestaxes2
	  
   end
	
	/********* Lignes d'ecriture ***********/
	
	open lignes1

	fetch lignes1
	into @comptevente,@sumtotalht,@sumecotaxe

	while (@@sqlstatus = 0)
	begin
	  select @Num=@Num+0.001
	  
	  
	  if (@sumtotalht-@sumecotaxe)>0
	  begin
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@comptevente,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
				   null,null,@sumtotalht-@sumecotaxe,null,@ent)
	  end
	  else if (@sumtotalht-@sumecotaxe)<0
	  begin
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@comptevente,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
				   null,abs(@sumtotalht-@sumecotaxe),null,null,@ent)
	  end
	  
	  fetch lignes1
	  into @comptevente,@sumtotalht,@sumecotaxe
	end
	
	close lignes1
	

/* inutilise */
/*	open lignes2

	fetch lignes2
	into @comptevente,@sumtotalht,@sumecotaxe

	while (@@sqlstatus = 0)
	begin	
	  select @Num=@Num+0.001
	  
	  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
						PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
	  values(@spid,@Journal,@comptevente,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
			   null,abs(@sumtotalht-@sumecotaxe),null,null,@ent)
  
	  fetch lignes2
	  into @comptevente,@sumtotalht,@sumecotaxe
	end
	
	close lignes2
*/
	
			/************ calcul de l escompte  ***************/
	
	if @escompte != 0
	begin
	
	  select @TotEscompte=sum(escompte)
	  from #Lignes
	  
		  if @sanstva=1
			begin
				select @compte=PCPTESCET from KParam where (@ent is null or PENT=@ent)

			end
		  else if @sanstva=0
			begin
				select @compte=PCPTESCFR from KParam where (@ent is null or PENT=@ent)

			end
	  
	  if @TotEscompte>0
	  begin
	    select @Num=@Num+0.001
	  
		insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
						PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		select @spid,@Journal,@compte,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
			   null,@TotEscompte,null,null,@ent
	  end
	  else if @TotEscompte<0
	  begin
	    select @Num=@Num+0.001
	  
		insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
						PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		select @spid,@Journal,@compte,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
			   null,null,abs(@TotEscompte),null,@ent
	  end
	
	end
	
		 	/****************--------- Lignes de la facture avec ecotaxe ****************/
		
	truncate table #Lignes
  
	insert into #Lignes (totalht,comptevente,taux,sansesc,comptetva,escompte,comptexo,
							cptchdebit,cptchcredit,article,lettre,qte,offert,compteDEEE,ecotaxe)
	select FALTOTALHT,TVLCPT,TVLTAUXTVA,TVSANSESC,TVLCOMPTETVA,0,TVLCPTSANSTVA,
			TVLCPTCHDEBIT,TVLCPTCHCREDIT,FALARTICLE,FALLETTRE,FALQTE,isnull(FALOFFERT,0),
			isnull(TVLCPT3ETTR,''),isnull(FALECOTAXE,0)
	from FFAL,FCL, FTV, FTVL
	where FALCODE=@code and CLCODE=@clfact
	and TVCODE=FALTYPEVE and TVLCODE=FALTYPEVE and TVLCLASSE=CLCLASSE
	and isnull(FALECOTAXE,0) != 0
	and isnull(FALTOTALHT,0) != 0
	and (@ent is null or (FALENT=@ent and CLENT=@ent and TVLENT=@ent))	
	
	
	open ecotaxes

	fetch ecotaxes
	into @comptevente,@sumtotalht,@comptecotaxe,@sumecotaxe

	while (@@sqlstatus = 0)
	begin
	  select @Num=@Num+0.001
	  
	  
	  if @sumecotaxe>0
	  begin
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@comptecotaxe,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
				   null,null,@sumecotaxe,null,@ent)
	  end
	  else if @sumecotaxe<0
	  begin
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@comptecotaxe,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
				   null,abs(@sumecotaxe),null,null,@ent)
	  end
	  
	  if (@sumtotalht=0 and ((@sumtotalht-@sumecotaxe)>0))
	  begin
	  	  select @Num=@Num+0.001
	  
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@comptevente,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
				   null,null,@sumtotalht-@sumecotaxe,null,@ent)
	  end
	  else if (@sumtotalht=0 and ((@sumtotalht-@sumecotaxe)<0))
	  begin
	  	  select @Num=@Num+0.001
	  
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@comptevente,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),@nom,
				   null,abs(@sumtotalht-@sumecotaxe),null,null,@ent)
	  end
	  
	  
	  fetch ecotaxes
	  into @comptevente,@sumtotalht,@comptecotaxe,@sumecotaxe
	end
	
	close ecotaxes
	
	
			/***************** Traitement des differences de centimes */
	 
	 select @totdebit = 0, @totcredit = 0
	 
	 select @totdebit=sum(PCDEBIT),@totcredit=sum(PCCREDIT)
	 from FPC
	 where PCPIECE like (case when @prefseq=0 then @code else @codeseq end) + '%'
	 and PCSPID=@spid
	 
	 				/******************  debit ou credit *******/
	 select @credit=isnull(PCCREDIT,0)
	 from FPC
	 where PCPIECE=(case when @prefseq=0 then @code else @codeseq end)
	 and PCNUMCOMPTA like @numcompta + '%'
	 and PCSPID=@spid
	 
	 if @credit > 0 select @debcre=1 else select @debcre=0
	 
	 				/****************** mise a jour d'une ligne de compte 7 si erreur de centimes < 0,05 *******/
	 
	 if (@totdebit != @totcredit)
	 begin
	 	if (abs(isnull(@totdebit,0) - isnull(@totcredit,0)) < 0.05)
	 	begin
			set rowcount 1
			
			select @compte=PCNUMCOMPTA
			from FPC
			where PCPIECE=(case when @prefseq=0 then @code else @codeseq end)
			and PCNUMCOMPTA like '7%'
	 	 	and PCSPID=@spid
			
			
			if (@debcre=0)
			begin
			  update FPC
			  set PCDEBIT=PCDEBIT+(@totcredit - @totdebit)
			  where PCNUMCOMPTA=@compte
			  and PCPIECE=(case when @prefseq=0 then @code else @codeseq end)
	 		  and PCSPID=@spid
			end
			else if (@debcre=1)
			begin 
			  update FPC
			  set PCCREDIT=PCCREDIT+(@totdebit - @totcredit)
			  where PCNUMCOMPTA=@compte
			  and PCPIECE=(case when @prefseq=0 then @code else @codeseq end)
	 		  and PCSPID=@spid
			end
			
			set rowcount 0
		end
		else
		if @verif=1
		begin
		  insert into #Dif (code,lib,differe,gravite)
		  values ((case when @prefseq=0 then @code else @codeseq end),' Difference entre debit et credit =>',(abs(isnull(@totdebit,0) - isnull(@totcredit,0))),1)
		end
	 end
	 
	 
	 	/****************--------- Lignes de la facture a 0 ****************/
		
	truncate table #Lignes
  
	insert into #Lignes (totalht,comptevente,taux,sansesc,comptetva,escompte,comptexo,
							cptchdebit,cptchcredit,article,lettre,qte,offert,compteDEEE,ecotaxe)
	select 0,TVLCPT,TVLTAUXTVA,TVSANSESC,TVLCOMPTETVA,0,TVLCPTSANSTVA,
			TVLCPTCHDEBIT,TVLCPTCHCREDIT,FALARTICLE,FALLETTRE,FALQTE,isnull(FALOFFERT,0),
			isnull(TVLCPT3ETTR,''),isnull(FALECOTAXE,0)
	from FFAL,FCL, FTV, FTVL, FAR
	where FALCODE=@code and CLCODE=@clfact
	and TVCODE=FALTYPEVE and TVLCODE=FALTYPEVE and TVLCLASSE=CLCLASSE
	and FALTOTALHT=0
	and ARCODE=FALARTICLE
	and ARTYPE=0
	and (@ent is null or (FALENT=@ent and CLENT=@ent and TVLENT=@ent))
	
	
		/*********------ Lignes d'ecriture des produits factures a 0 ***********/
	
	if (@valorisation=0 or @valorisation=1)
	begin
	
	  open lignes3
  
	  fetch lignes3
	  into @cptchdebit,@cptchcredit,@sumPRMP,@sumFIFO,@offert
  
	  while (@@sqlstatus = 0)
	  begin
		
		if @valorisation=0
		begin
		
		  select @Num=@Num+0.001
		
		  if isnull(@offert,0) = 1
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							  PCDEBIT, PCCREDIT,PCTRMODE,PCENT)
			values(@spid,@Journal,@cptchdebit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
					 null,abs(@sumFIFO),null,null,@ent)
		  else if isnull(@offert,0) = 0
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							  PCDEBIT, PCCREDIT,PCTRMODE,PCENT)
			values(@spid,@Journal,@cptchcredit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
					 null,abs(@sumFIFO),null,null,@ent)
  
		  select @Num=@Num+0.001
				   
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@cptchcredit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
				   null,null,abs(@sumFIFO),null,@ent)
		end
		else if @valorisation=1
		begin
  
		  select @Num=@Num+0.001
  		  
		  if isnull(@offert,0) = 1
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							  PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
			values(@spid,@Journal,@cptchdebit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
					 null,abs(@sumPRMP),null,null,@ent)
  		  else if isnull(@offert,0) = 0
			insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							  PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
			values(@spid,@Journal,@cptchcredit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
					 null,abs(@sumPRMP),null,null,@ent)
  
		  select @Num=@Num+0.001
				   
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values(@spid,@Journal,@cptchcredit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
				   null,null,abs(@sumPRMP),null,@ent)
		end
		
		fetch lignes3
		into @cptchdebit,@cptchcredit,@sumPRMP,@sumFIFO,@offert
	  end
	  
	  close lignes3
 	end
	else if @valorisation=2
	begin
	
	  truncate table #Offertes
	
	  open lignes_offertes
	  
	  fetch lignes_offertes
	  into @article,@cptchdebit,@cptchcredit,@qte,@offert
	  
	  while (@@sqlstatus = 0)
	  begin
		select  @PrixRevient = 0,
				@PrixRevientLigne = 0
	  
		select @PrixRevient=isnull(PUMP,0)
		from FPUM
		where PUMAR = @article
		and PUMDATE <= @date
		having PUMAR = @article
		and PUMDATE <= @date
		and PUMDATE = max(PUMDATE)
			  
		select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		
		insert into #Offertes (cptchdebit,cptchcredit,total,offertes)
		values (@cptchdebit,@cptchcredit,@PrixRevientLigne,@offert)
	  
		fetch lignes_offertes
		into @article,@cptchdebit,@cptchcredit,@qte,@offert
	  end
	
	  close lignes_offertes
	  
	  open tot_offertes
	  
	  fetch tot_offertes
	  into @cptchdebit,@cptchcredit,@total,@offert
	  
	  while (@@sqlstatus = 0)
	  begin
	  
		select @Num=@Num+0.001
	    
		if isnull(@offert,0) = 1
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values (@spid,@Journal,@cptchdebit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
				   null,abs(@total),null,null,@ent)
		else if isnull(@offert,0) = 0
		  insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
							PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		  values (@spid,@Journal,@cptchcredit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
				   null,abs(@total),null,null,@ent)
		
		select @Num=@Num+0.001
				 
		insert into FPC (PCSPID,PCJOURNAL,PCNUMCOMPTA,PCDATE,PCNUM,PCPIECE,PCLIB,PCDATEECH,
						  PCDEBIT,PCCREDIT,PCTRMODE,PCENT)
		values (@spid,@Journal,@cptchcredit,@DateFact,@Num,(case when @prefseq=0 then @code else @codeseq end),'Fact 0 '+@numcompta+' '+@nom,
				 null,null,abs(@total),null,@ent)	  
	  
		fetch tot_offertes
		into @cptchdebit,@cptchcredit,@total,@offert
	  
	  end
	  
	  close tot_offertes
	  
	end
	
	
			/************* Facture suivante **********/
	
	fetch factures into @nom,@date,@tr1,@tr2,@tr3,@tr4,@trdate1,@trdate2,@trdate3,@trdate4,
	 	 @regl1,@regl2,@regl3,@regl4,
	 	 @mode1,@mode2,@mode3,@mode4,
	 	 @sanstva,@escompte,@netapayer,@tauxesc,@clfact,@numcompta,@code,@devise,@accepte,@numlivre,@codeseq
			
  end	
	
	close factures
	deallocate cursor factures
	deallocate cursor lestaxes1
	deallocate cursor lestaxes2
	deallocate cursor lignes1
	deallocate cursor lignes2
	deallocate cursor lignes3
	deallocate cursor ecotaxes


	if @verif=1
	begin
	  insert into #Dif (code,lib,differe,gravite)
	  select PCPIECE,'Debit et credit a 0 - '+PCNUMCOMPTA,0,0
	  from FPC
	  where isnull(PCNUMCOMPTA,'') != ''
	  and isnull(PCDEBIT,0) = 0
	  and isnull(PCCREDIT,0) = 0
	  and PCSPID = @spid
	  order by syb_identity
	end
	
	drop table #Lignes
	drop table #Factures
	drop table #Taxes
	drop  table #LesTaxes
	drop  table #Offertes

	if @verif=0
	begin
	  delete from FPC
	  where PCSPID=@spid
	  and isnull(PCDEBIT,0)=0
	  and isnull(PCCREDIT,0)=0
	end
	else
	if @verif=1
	begin
	  select code,lib,differe,gravite
	  from #Dif
	  order by syb_identity
	  
	  drop table #Dif
	end
	 
end
go

