


/* recherche des marges anormales 
   marge < 0% et > 35%				
   Le 20 Aout 1993                 */

create procedure MargesHN (@ent		char(5)	 = null,
						   @fourn	char(12) = null)
with recompile
as
begin

	select STAR,STLETTRE,ARLIB,PRevient=(STPAHT+STFRAIS),FALPRIXHT,
	marge=round((FALPRIXHT-(STPAHT+STFRAIS))/(((STPAHT+STFRAIS+(1-abs(sign(STPAHT+STFRAIS)))))/100),2)
	into #temp
	from FSTOCK,FFAL,FAR,FDP
	where STAR=FALARTICLE
	and STLETTRE=FALLETTRE
	and STAR=ARCODE
	and (@fourn is null or ARFO=@fourn)
	and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))

	select 'Code','Lettre','Designation','Prix de revient','Prix de vente','Marge'

	select STAR,STLETTRE,ARLIB,PRevient,FALPRIXHT,marge
	from #temp
	where marge<0 or marge>35
	order by STAR,STLETTRE

	drop table #temp
end



go

