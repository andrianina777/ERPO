


/* Procedure permettant de generer les stocks projetes sur les 12 prochains mois 
	pour un article */

create procedure A_STProjetAR (@Article	char(15))
with recompile
as
begin

declare @date1	datetime
declare @date2	datetime
declare @Mois	tinyint
declare @An		smallint
declare @i		tinyint

declare @MoisEnCours	tinyint
declare @Annee			smallint

select @Mois=datepart(mm,getdate())
select @An=datepart(yy,getdate())

select @Mois=@Mois + 1
  
if @Mois=13
  begin
	select @Mois = 1
	select @An = @An+1
	select @MoisEnCours = 12
	select @Annee = @An-1
  end
else
  begin
	select @MoisEnCours = @Mois-1
	select @Annee = @An
  end


declare @dif	int
select @dif=((@Annee-1992)*12)+@Mois

delete FSK
where SKDIF>=@dif
and SKARTICLE=@Article


select @date1=convert(datetime,convert(char(2),@MoisEnCours)+"/01/"+convert(char(4),@Annee))
select @date2=dateadd(mm,1,@date1)
select @date2=dateadd(dd,-1,@date2)


create table #Stock
(
Article		char(15)	not null,
Qte			int			not null
)

insert into #Stock (Article,Qte)
select STAR, sum(STQTE)
from FSTOCK
where STQTE > 0
and STAR=@Article
group by STAR

insert into #Stock (Article,Qte)
select RCFARTICLE, sum(RCFQTE)
from FRCF
where RCFQTE > 0
and RCFDATE <= @date2
and RCFARTICLE=@Article
group by RCFARTICLE


insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
select @An, @Mois, Article, sum(Qte), ((@An-1992)*12)+@Mois, getdate()
from #Stock
group by Article

/* Traitement des 11 mois suivants */

select @i=1

while (@i <= 11)
begin

  select @Mois=@Mois + 1
  
  if @Mois=13
	begin
	  select @Mois = 1
	  select @An = @An+1
	  select @MoisEnCours = 12
	  select @Annee = @An-1
	end
  else
	begin
	  select @MoisEnCours = @Mois-1
	  select @Annee = @An
	end
  
  insert into #Stock (Article,Qte)
  select RCFARTICLE, sum(RCFQTE)
  from FRCF
  where RCFQTE > 0
  and RCFMOIS = @MoisEnCours
  and RCFAN = @Annee
  and RCFARTICLE=@Article
  group by RCFARTICLE
  
    
  insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
  select @An, @Mois, Article, sum(Qte), ((@An-1992)*12)+@Mois, getdate()
  from #Stock
  group by Article
  
  select @i = @i+1

end

drop table #Stock

end



go

