



create procedure TotalAcomptes (@facode		char(10))
with recompile
as
begin


declare @TotalAcomptes	numeric(14,2)

select 	CODEBE = FALLIENCODE,
		NUMLIGNE = FALLIENNUM
into #BE
from FFAL
where FALCODE = @facode
group by FALLIENCODE,FALLIENNUM


select CODECC = BELLIENCODE
into #CC
from FBEL,#BE
where BELCODE = CODEBE
and BELNUM = NUMLIGNE
and BELLIENCODE like 'CC%'
group by BELLIENCODE

select @TotalAcomptes = 0

declare commandes cursor 
for select CODECC
from #CC
for read only

declare @code	char(10)	

open commandes

fetch commandes
into @code

while (@@sqlstatus = 0)
	begin
	
	select @TotalAcomptes = @TotalAcomptes + isnull(CCRESTEACOMPTE,0)
	from FCC
	where CCCODE = @code
	
	update FCC
	set CCRESTEACOMPTE = 0
	where CCCODE = @code
	
	fetch commandes
	into @code
	
end

close commandes
deallocate cursor commandes

select @TotalAcomptes

end



go

