


/* Procedure utilisee pour le calcul d un prix de vente a partir des promotions */
/* sur une ligne de devis, commande ou expedition */
/* renvoie la liste la plus precise des rubriques d une ligne de promotion */

CREATE PROCEDURE dbo.Promotions (@ent		char(5)            = null,
							 @date		smalldatetime,
							 @client	char(12),
							 @tarif		char(8),
							 @article	char(15),
							 @qte		int,
							 @numlot	char(12)
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @depart				char(8),
		@marque				char(12),
		@fam				char(8),
		@categ				char(8),
		@activite			char(6),
		@seq				int,
		@pvht_out      		numeric(14,2),
		@remise3_out        numeric(8,4),
		@cumulremises_out   tinyint,
		@typeve_out     	char(4),
		@articleoffert_out 	char(15),
		@qteoffert_out    	int,
		@valide_out        	int
		
select @seq = 0        
select @depart=ARDEPART, @marque=ARFO, @fam=ARFAM, @categ=ARGRFAM, @pvht_out=ARPVHT
from FAR
where ARCODE=@article
select @activite = CLSA
from FCL
where CLCODE = @client

create table #Seq
(
seq     int              not null,
prio    int              not null,
id      numeric(14,0)    identity
)


insert into #Seq (seq,prio)
select
(case
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL=@client and PROMOTARIF=@tarif then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL=@client and PROMOTARIF=''  then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA='' then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF='' and PROMOSA='' then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA='' then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite then PROMOSEQ
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then PROMOSEQ
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then PROMOSEQ
else 0 end),
(case
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL=@client and PROMOTARIF=@tarif then 1
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL=@client and PROMOTARIF='' then 2
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite then 3
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA='' then 4
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite then 5
when PROMOARTICLE=@article and PROMOLOT=@numlot and PROMOCL='' and PROMOTARIF='' and PROMOSA='' then 6
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif then 7
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' then 8
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite then 9
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA='' then 10
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite then 11
when PROMOARTICLE=@article and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' then 12
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 13
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 14
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 15
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 16
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 17
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 18
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 19
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 20
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 21
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 22
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 23
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 24
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 25
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 26
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 27
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF=@tarif and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 28
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 29
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 30
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 31
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 32
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 33
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 34
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 35
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 36
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 37
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 38
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 39
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 40
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 41
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 42
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 43
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL=@client and PROMOTARIF='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 44
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 45
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 46
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 47
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 48
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 49
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 50
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 51
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 52
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 53
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 54
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 55
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 56
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 57
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 58
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 59
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF=@tarif and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 60
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 61
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 62
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 63
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 64
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 65
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 66
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 67
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 68
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 69
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 70
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 71
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 72
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 73
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 74
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 75
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA=@activite and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 76
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 77
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 78
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 79
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 80
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 81
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 82
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 83
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG=@categ and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 84
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART=@depart then 85
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE=@marque and PROMODEPART='' then 86
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART=@depart then 87
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM=@fam and PROMOMARQUE='' and PROMODEPART='' then 88
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART=@depart then 89
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE=@marque and PROMODEPART='' then 90
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART=@depart then 91
when PROMOARTICLE='' and PROMOLOT='' and PROMOCL='' and PROMOTARIF='' and PROMOSA='' and PROMOCATEG='' and PROMOFAM='' and PROMOMARQUE='' and PROMODEPART='' then 92
else 0 end)
from FPROMO
--where convert(char,PROMODATEDEB,101) <= convert(char,@date,101) and convert(char,@date,101) <= convert(char,PROMODATEFIN,101) 
where convert(smalldatetime,PROMODATEDEB) <= convert(smalldatetime,current_date()) and convert(smalldatetime,current_date()) <= convert(smalldatetime,PROMODATEFIN) 

and PROMOQTEBASE <= @qte
and PROMOARTICLE=@article
order by PROMOQTEBASE DESC

set rowcount 1

select @seq = seq
from #Seq
where seq != 0
order by prio

set rowcount 0

if @seq is null or @seq = 0
begin
	select @pvht_out = 0, @remise3_out = 0, @cumulremises_out = 0,
	@typeve_out = '', @articleoffert_out = '', @qteoffert_out = 0,
	@valide_out = 0
	select @pvht_out, @remise3_out, @cumulremises_out,
	@typeve_out, @articleoffert_out, @qteoffert_out,
	@valide_out
end
else
begin
                select top 1 pvht_out = @pvht_out, remise3_out = isnull(PROMOPC,0), cumulremises_out = isnull(PROMOCUMULREM,0),
                typeve_out = isnull(PROMOTYPEVE,''), articleoffert_out = isnull(PROMOARTICLEOFFERT,''),
                qteoffert_out = isnull(PROMOQTEOFFERT,0)*(@qte/(case when isnull(PROMOQTEBASE,0)=0 then 1 else isnull(PROMOQTEBASE,1) end)),
                valide_out = PROMOSEQ
        from FPROMO
        --where convert(char,PROMODATEDEB,101) <= convert(char,@date,101) and convert(char,@date,101) <= convert(char,PROMODATEFIN,101) 
        where convert(smalldatetime,PROMODATEDEB) <= convert(smalldatetime,current_date()) and convert(smalldatetime,current_date()) <= convert(smalldatetime,PROMODATEFIN) 

        and PROMOQTEBASE <= @qte
        and PROMOARTICLE=@article
        order by PROMOQTEBASE DESC
        end
end





go

