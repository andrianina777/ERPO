



create procedure ConfirmeBE (	@ent		char(5) = null,
								@numBE		char(10))
as
begin

update FBEL
set BELSTADE=3
where BELCODE=@numBE
and BELSTADE=1
and (@ent is null or BELENT=@ent)


declare @num	int
select @num = 0

select @num = isnull(min(BELSTADE),0) from FBEL where BELCODE = @numBE and (@ent is null or BELENT=@ent)

if @num <> 0  update FBE set BESTADE = @num where BECODE = @numBE and (@ent is null or BEENT=@ent)

end



go

