CREATE PROCEDURE dbo.bp_BlocageMedic(
		@codeClient char(25),
		@codeArticle char(30))
with recompile
AS
begin
	 declare @count int		 
 	 
 	 select @count=count(*) from VIEW_FAR where ARDEPART='MEDIC' and ARCODE=@codeArticle

 	 if(@count>0)
 		begin
 			select case when isnull(SA_MEDIC,0)=1 then 0 else 1 end ,SALIB from FSA inner join FCL on CLSA=SACODE where  CLCODE=@codeClient
 		end
end
go

