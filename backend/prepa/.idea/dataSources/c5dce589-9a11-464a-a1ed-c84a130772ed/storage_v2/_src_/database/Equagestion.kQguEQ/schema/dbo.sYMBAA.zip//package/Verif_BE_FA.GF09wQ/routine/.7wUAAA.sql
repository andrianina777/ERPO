


/* Procedure de verification des correspondances BE et FA.
	Verifie aussi les anomalies sur factures				*/


create procedure Verif_BE_FA (@ent		char(5)  = null,
							  @datedeb	smalldatetime,
							  @datefin	smalldatetime,
							  @article	char(15) = null,
							  @artype	tinyint	 = null)
with recompile
as
begin

print""
print "Comparatif des lignes de factures avec les lignes de BE correspondantes"
print""

select FALCODE,FALNUM,BELCODE,BELNUM,FALTOTALHT,BELTOTALHT,Difference=FALTOTALHT-BELTOTALHT
from FFAL(index date),FBEL,FAR
where FALLIENCODE=BELCODE
and FALLIENNUM=BELNUM
and ARCODE=FALARTICLE
and (@artype is null or ARTYPE=@artype)
and FALTOTALHT != BELTOTALHT
and FALDATE between @datedeb and @datefin
and (@article is null or FALARTICLE=@article)
and (@ent is null or FALENT=@ent)
order by FALCODE,FALNUM
compute sum(FALTOTALHT),sum(BELTOTALHT),sum(FALTOTALHT-BELTOTALHT)

print""
print "Lignes de factures avec lien BE sans correspondance en BE"
print""

select FALCODE,FALNUM,FALTOTALHT,FALLIENCODE,FALLIENNUM
from FFAL(index date),FAR
where isnull(FALLIENCODE,"")!=""
and ARCODE=FALARTICLE
and (@artype is null or ARTYPE=@artype)
and FALDATE between @datedeb and @datefin
and (@article is null or FALARTICLE=@article)
and (@ent is null or FALENT=@ent)
and not exists(select * from FBEL where BELCODE=FFAL.FALLIENCODE and BELNUM=FFAL.FALLIENNUM)
order by FALCODE,FALNUM
compute sum(FALTOTALHT)


print""
print "Lignes de factures sans correspondance en BE"
print""

select FALCODE,FALNUM,FALTOTALHT
from FFAL(index date),FAR
where FALLIENCODE=""
and ARCODE=FALARTICLE
and (@artype is null or ARTYPE=@artype)
and FALDATE between @datedeb and @datefin
and (@article is null or FALARTICLE=@article)
and (@ent is null or FALENT=@ent)
order by FALCODE,FALNUM
compute sum(FALTOTALHT)

print""
print "Lignes de BE considerees comme facturees sans lignes de factures correspondantes"
print""

select BELCODE,BELNUM,BELTOTALHT,BELDATE
from FBEL(index date),FAR
where BELRESTE=0
and ARCODE=BELARTICLE
and (@artype is null or ARTYPE=@artype)
and BELDATE between @datedeb and @datefin
and (@article is null or BELARTICLE=@article)
and not exists (select * from FFAL
				where FALLIENCODE=FBEL.BELCODE 
				and FALLIENNUM=FBEL.BELNUM
				and (@ent is null or FALENT=@ent))
and (@ent is null or BELENT=@ent)
order by BELCODE,BELNUM
compute sum(BELTOTALHT)

/*
print""""
print ""Factures presentant des anomalies entre le total des lignes et""
print ""le total HT escomptable + le total HT non escomptable""
print""""

select FACODE,Difference=sum(FALTOTALHT)-(FATOTESC+FATOTNONESC)
from FFA,FFAL,FAR
where FACODE=FALCODE
and ARCODE=FALARTICLE
and (@artype is null or ARTYPE=@artype)
and FADATE between @datedeb and @datefin
and (@article is null or FALARTICLE=@article)
group by FALCODE
having FACODE=FALCODE
and sum(FALTOTALHT) != (FATOTESC+FATOTNONESC)
and (@ent is null or (FALENT=@ent and FAENT=@ent))
*/
 
end



go

