




create procedure Verif_Stock_FA (@ent			char(5) = null,
								 @code_article	char(15)
								)
								 
with recompile
as
begin

create table #Articles
(
article		char(15) not null,
lettre		char(4)	not null,
lignes		int		not null
)


declare @lignes		int,
		@labase		varchar(30),
		@encours	int,
		@compteur	int,
		@correspond	int,
		@numerote	tinyint
		
select  @labase = db_name(),
		@lignes = 0,
		@encours = 0,
		@compteur = 0,
		@correspond = 0,
		@numerote = 0
		
select @numerote=ARNUMEROTE from FAR where ARCODE=@code_article

select @lignes=count(*)
from FSTOCK,FDP
where STAR=@code_article
and STQTE<=0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))

print "->  %1! lignes a traiter", @lignes

select @lignes = 0

declare articles cursor 
for select STAR,STLETTRE
from FSTOCK,FDP
where STAR=@code_article
and STQTE<=0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
for read only

declare @article	char(15),
		@lettre		char(4)

open articles

fetch articles
into @article,@lettre	

while (@@sqlstatus = 0)
	begin
	
	select @lignes=@lignes+1
	
	select @correspond = 0
	select @correspond=count(*)
	from FFAL
	where FALARTICLE=@article
	and FALLETTRE=@lettre
	and (@ent is null or FALENT=@ent)
	
	select @compteur = @compteur + @@rowcount
	
	if @correspond = 0
	insert into #Articles (article,lettre,lignes)
	values(@article,@lettre,@correspond)

	if (@numerote=1 and @correspond > 1)
	insert into #Articles (article,lettre,lignes)
	values(@article,@lettre,@correspond)

	if (@lignes >= 1000)
	begin
		select @encours = @encours + @lignes
		dump tran @labase with truncate_only
		select @lignes = 0
		print "->  %1! lignes scannees", @encours
	end
	
	fetch articles
	into @article,@lettre
	
end

close articles
deallocate cursor articles

select @encours = @encours + @lignes
dump tran @labase with truncate_only
print "->  %1! lignes scannees", @encours
print "->  %1! lignes traitees", @compteur

select article,lettre,lignes
from #Articles
order by article,lettre

drop table #Articles

end



go

