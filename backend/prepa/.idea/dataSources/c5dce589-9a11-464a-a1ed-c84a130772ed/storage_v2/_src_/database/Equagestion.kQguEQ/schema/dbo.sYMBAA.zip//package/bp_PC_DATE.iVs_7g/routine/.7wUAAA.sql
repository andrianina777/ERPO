/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_PC_DATE
grant all on bp_PC_DATE to public
*/

CREATE PROCEDURE dbo.bp_PC_DATE(@dates date)
with recompile
AS
begin
	select xBPRLCODE as CODE_PC,xBPRLAR as ARTICLE,ARLIB as LIBELLE,xBPRLQTE as QUANTITE,xBPRLLOT as LOT,xBPRLFO as LABO,f1.FONOM as NOM_LABO,xARTP_FAB as FABRICANT,
	f2.FONOM as NOM_FABRICANT from xFBPRL
	left join VIEW_FAR on ARCODE=xBPRLAR
	left join FFO f1 on f1.FOCODE=xBPRLFO
	left join FFO f2 on f2.FOCODE=VIEW_FAR.xARTP_FAB
	 where xBPRLDATE=@dates
	 
end
go

