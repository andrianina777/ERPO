CREATE PROCEDURE dbo.b_Histo_AO (@client char(10),@libelle_client varchar(80),@attrib int)

AS
begin

  		if(@attrib=0)
  		begin
			select xAOLARTICLE,xAOLCDT,xAOMARCHE,xAODATE,case when isnull(xAOLQTEDEMANDE,0)=0 then xAOLPREVISION else xAOLQTEDEMANDE end,bAOLARCODE,ARLIB,bAOLPRIXUNIT,bAOLQTEATTRIB,QTE_DISPO from bAOL
			inner join xAOL on xAOLSEQ=bAOL_xAOLSEQ and xAOLCODE=bAOL_xAOLCODE
			inner join xAO on xAOCODE=bAOL_xAOLCODE
			inner join VIEW_FAR_TOUS on ARCODE=bAOLARCODE
			inner join VIEW_STOCK_DISPO on CODE=bAOLARCODE
			where (@client='' or @client=null or xAOCLIENT=@client) 
			and (@libelle_client='' or @libelle_client=null or xAOLARTICLE like upper('%'+@libelle_client+'%')) order by xAODATE desc,xAOLARTICLE
		end
		if(@attrib=1)
			begin
				select xAOLARTICLE,xAOLCDT,xAOMARCHE,xAODATE,case when isnull(xAOLQTEDEMANDE,0)=0 then xAOLPREVISION else xAOLQTEDEMANDE end,bAOLARCODE,ARLIB,bAOLPRIXUNIT,bAOLQTEATTRIB,QTE_DISPO from bAOL
				inner join xAOL on xAOLSEQ=bAOL_xAOLSEQ and xAOLCODE=bAOL_xAOLCODE
				inner join xAO on xAOCODE=bAOL_xAOLCODE
				inner join VIEW_FAR_TOUS on ARCODE=bAOLARCODE
				inner join VIEW_STOCK_DISPO on CODE=bAOLARCODE
				where (@client='' or @client=null or xAOCLIENT=@client) 
				and (@libelle_client='' or @libelle_client=null or xAOLARTICLE like upper('%'+@libelle_client+'%')) 
				and isnull(bAOLQTEATTRIB,0)<>0
				order by xAODATE desc,xAOLARTICLE
			end
	  	if(@attrib=2)
			begin
				select xAOLARTICLE,xAOLCDT,xAOMARCHE,xAODATE,case when isnull(xAOLQTEDEMANDE,0)=0 then xAOLPREVISION else xAOLQTEDEMANDE end,bAOLARCODE,ARLIB,bAOLPRIXUNIT,bAOLQTEATTRIB,QTE_DISPO from bAOL
				inner join xAOL on xAOLSEQ=bAOL_xAOLSEQ and xAOLCODE=bAOL_xAOLCODE
				inner join xAO on xAOCODE=bAOL_xAOLCODE
				inner join VIEW_FAR_TOUS on ARCODE=bAOLARCODE
				inner join VIEW_STOCK_DISPO on CODE=bAOLARCODE
				where (@client='' or @client=null or xAOCLIENT=@client) 
				and (@libelle_client='' or @libelle_client=null or xAOLARTICLE like upper('%'+@libelle_client+'%')) 
				and isnull(bAOLQTEATTRIB,0)=0
				order by xAODATE desc,xAOLARTICLE
			end
end

go

