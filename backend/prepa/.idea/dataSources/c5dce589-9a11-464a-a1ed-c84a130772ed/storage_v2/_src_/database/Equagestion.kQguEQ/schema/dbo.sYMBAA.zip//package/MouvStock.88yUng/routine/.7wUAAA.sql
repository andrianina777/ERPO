



/* Procedure generant les lignes de mouvements de stock */

create procedure MouvStock (@Fournisseur	char(12)	= null,
							@Famille		char(8)		= null,
							@Article		char(15)	= null,
							@DuMois			tinyint,
							@AuMois			tinyint,
							@Annee			smallint,
							@Depot			tinyint,
							@depart			char(8)		= null)
with recompile
as
begin

set arithabort numeric_truncation off


/* 	@Depot = 0 => tout le stock 
	@Depot = 1 => le stock local
	@Depot = 2 => le stock sous douanes
*/

declare @MoisPrecedent	tinyint
declare @AnneeInit		smallint
declare @count			int


if (@DuMois=1)
	begin
	select @MoisPrecedent=12
	select @AnneeInit=@Annee-1
	end
else
	begin
	select @MoisPrecedent=@DuMois-1
	select @AnneeInit=@Annee
	end
	
/******* table des articles ******/
	
create table #FAR
(
ARCODE	char(15)		not null,
ARFO	char(12)			null,
ARFAM	char(8)				null,
ARLIB	varchar(80)			null
)

/******* table de l''inventaire initial ******/

create table #Init
(
ArticleInit		char(15)		null,
QuantiteInit	int				null,
CoutInit		numeric(14,2)	null,
DepotInit		tinyint			null
)


/******* table des entrees pendant la periode ******/

create table #Entree
(
ArticleIn	char(15)			null,
QuantiteIn	int					null,
CoutIn		numeric(14,2)		null,
DepotIn		tinyint				null
)

/******* table des valeurs reajustees pendant la periode ******/

create table #Reajust
(
ArticleReajust	char(15)			null,
QuantiteReajust	int					null,
CoutReajust		numeric(14,2)		null,
DepotReajust	tinyint				null
)

/******* table des sorties pendant la periode ******/

create table #Sortie
(
ArticleOut	char(15)			null,
QuantiteOut	int					null,
CoutOut		numeric(14,2)		null,
DepotOut	tinyint				null
)

/******************* Traitement ********************/

select @count=count(*) from FMOIS
where MOISMOIS=@MoisPrecedent
and MOISANNEE=@AnneeInit


if (@count=0)	/* si le mois precedent n''a pas ete stocke, renvoie -1 sur @count */
	begin
	select @count=-1
	select '','','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,'','','',@count
	end
else
	begin


	 if ((@Fournisseur is null) and (@Famille is null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is null) and (@Famille is null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is null) and (@Famille is not null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFAM=@Famille
			 and (@depart is null or ARDEPART=@depart)
		 end	
	 else if ((@Fournisseur is null) and (@Famille is not null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFAM=@Famille
			 and ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end		
	 else if ((@Fournisseur is not null) and (@Famille is null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is not null) and (@Famille is null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is not null) and (@Famille is not null) and (@Article is null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and ARFAM=@Famille
			 and (@depart is null or ARDEPART=@depart)
		 end
	 else if ((@Fournisseur is not null) and (@Famille is not null) and (@Article is not null))
		 begin
			 insert into #FAR
			 select ARCODE,ARFO,ARFAM,ARLIB
			 from FAR
			 where ARFO=@Fournisseur
			 and ARFAM=@Famille
			 and ARCODE=@Article
			 and (@depart is null or ARDEPART=@depart)
		 end
	 
	 
	 create unique clustered index article on #FAR(ARCODE)
	 
	 
	 /****** Information initiale stockee le mois precedent dans FMOIS ******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #Init (ArticleInit,QuantiteInit,CoutInit,DepotInit)
			 select MOISARTICLE,MOISQTE,MOISTOTPR,MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@AnneeInit
			 and MOISMOIS=@MoisPrecedent
			 and MOISQTE != 0
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #Init (ArticleInit,QuantiteInit,CoutInit,DepotInit)
			 select MOISARTICLE,MOISQTE,MOISTOTPR,MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@AnneeInit
			 and MOISMOIS=@MoisPrecedent
			 and MOISDEPOT=1
			 and MOISQTE != 0
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Init (ArticleInit,QuantiteInit,CoutInit,DepotInit)
			 select MOISARTICLE,MOISQTE,MOISTOTPR,MOISDEPOT
			 from #FAR,FMOIS
			 where ARCODE=MOISARTICLE
			 and MOISANNEE=@AnneeInit
			 and MOISMOIS=@MoisPrecedent
			 and MOISDEPOT in (0,2)
			 and MOISQTE != 0
		 end
	 
	 create clustered index ardep on #Init(ArticleInit,DepotInit)
	 
	 
	 
	 /******* Calcul des valeurs entree pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #Entree (ArticleIn,QuantiteIn,CoutIn,DepotIn)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSTYPE='E'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #Entree (ArticleIn,QuantiteIn,CoutIn,DepotIn)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSTYPE='E'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Entree (ArticleIn,QuantiteIn,CoutIn,DepotIn)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSTYPE='E'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 
	 create clustered index ardep on #Entree(ArticleIn,DepotIn)
	 
	 /******* Calcul des valeurs reajustees pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #Reajust (ArticleReajust,QuantiteReajust,CoutReajust,DepotReajust)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSTYPE in ('F','R','A','C','M')
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #Reajust (ArticleReajust,QuantiteReajust,CoutReajust,DepotReajust)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSTYPE in ('F','R','A','C','M')
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Reajust (ArticleReajust,QuantiteReajust,CoutReajust,DepotReajust)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSTYPE in ('F','R','A','C','M')
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 
	 
	 create clustered index ardep on #Reajust(ArticleReajust,DepotReajust)
	 
	 /******* Calcul des valeurs sorties pendant la periode demandee (depuis FMS) *******/
	 
	 
	 if (@Depot=0)			/* Tout le stock */
		 begin
			 insert into #Sortie (ArticleOut,QuantiteOut,CoutOut,DepotOut)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSTYPE='S'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT	
		 end
	 else if (@Depot=1)		/* Le stock local */
		 begin
			 insert into #Sortie (ArticleOut,QuantiteOut,CoutOut,DepotOut)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT=1
			 and MSTYPE='S'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT
		 end
	 else if (@Depot=2)		/* Le stock sous douanes */
		 begin
			 insert into #Sortie (ArticleOut,QuantiteOut,CoutOut,DepotOut)
			 select MSARTICLE,sum(MSQTE),sum(MSTOTPR),MSDEPOT
			 from #FAR,FMS
			 where ARCODE=MSARTICLE
			 and MSANNEE=@Annee
			 and MSMOIS between @DuMois and @AuMois
			 and MSDEPOT in (0,2)
			 and MSTYPE='S'
			 and MSQTE != 0
			 group by MSARTICLE,MSDEPOT
		 end
	 
	 create clustered index ardep on #Sortie(ArticleOut,DepotOut)
	 
	 
	 /* Creation du fichier final avec insertion des articles de #Init et de #Reajust */
	 
	 select Article=ArticleInit,
	 QteInit=isnull(QuantiteInit,0),ValeurInit=isnull(CoutInit,0),
	 QteRJ=0,ValeurRJ=convert(numeric(14,2),0),
	 QteIn=0,ValeurIn=convert(numeric(14,2),0),
	 QteOut=0,ValeurOut=convert(numeric(14,2),0),
	 QteFinale=0,ValeurFinale=convert(numeric(14,2),0),
	 Depot=DepotInit
	 into #Final
	 from #Init
	 
	 drop table #Init
	 
	 create clustered index ardep on #Final(Article,Depot)
	 
	 /* Insertion dans #Final des articles entres sans correpondance dans #Final */
	 
	 insert into #Final
	 select ArticleIn,0,0,0,0,0,0,0,0,0,0,DepotIn
	 from #Entree
	 where not exists (select * from #Final 
					   where Article=#Entree.ArticleIn
					   and Depot=#Entree.DepotIn)
	 
	 /* Mise a jour de #Final avec les valeurs de #Entree */
	 
	 update #Final
	 set QteIn=isnull(QuantiteIn,0),ValeurIn=isnull(CoutIn,0)
	 from #Entree
	 where Article=ArticleIn
	 and Depot=DepotIn
	 
	 drop table #Entree
	 
	 /* Insertion dans #Final des articles reajustes sans correspondance dans #Final */
	 
	 insert into #Final
	 select ArticleReajust,0,0,0,0,0,0,0,0,0,0,DepotReajust
	 from #Reajust
	 where not exists (select * from #Final 
					   where Article=#Reajust.ArticleReajust
					   and Depot=#Reajust.DepotReajust)
	 
	 /* Mise a jour de #Final avec les valeurs de #Reajust */
	 
	 update #Final
	 set QteRJ=isnull(QuantiteReajust,0),ValeurRJ=isnull(CoutReajust,0)
	 from #Reajust
	 where Article=ArticleReajust
	 and Depot=DepotReajust
	 
	 drop table #Reajust
	 
	 
	 /* Insertion dans #Final des articles sortis sans correspondance dans #Final */
	 
	 insert into #Final
	 select ArticleOut,0,0,0,0,0,0,0,0,0,0,DepotOut
	 from #Sortie
	 where not exists (select * from #Final 
					   where Article=#Sortie.ArticleOut
					   and Depot=#Sortie.DepotOut)
	 
	 /* Mise a jour de #Final avec les valeurs de #Sortie */
	 
	 update #Final
	 set QteOut=isnull(QuantiteOut,0),ValeurOut=isnull(CoutOut,0)
	 from #Sortie
	 where Article=ArticleOut
	 and Depot=DepotOut
	 
	 drop table #Sortie
	 
	 
	 /* Mise a jour des valeurs finales de #Final */
	 
	 select Article=Article,QteInit=isnull(sum(QteInit),0),ValeurInit=isnull(sum(ValeurInit),0),
		 QteRJ=isnull(sum(QteRJ),0),ValeurRJ=isnull(sum(ValeurRJ),0),
		 QteIn=isnull(sum(QteIn),0),ValeurIn=isnull(sum(ValeurIn),0),
		 QteOut=isnull(sum(QteOut),0),ValeurOut=isnull(sum(ValeurOut),0),
		 QteFinale=sum(isnull(QteInit,0)+isnull(QteRJ,0)+isnull(QteIn,0)-isnull(QteOut,0)),
		 ValeurFinale=convert(numeric(14,2),0)
	 into #Final2
	 from #Final
	 group by Article
	 
	 drop table #Final
	 
	 update #Final2
	 set ValeurInit=0
	 where QteInit=0
	 
	 update #Final2
	 set ValeurFinale=isnull(ValeurInit,0)+isnull(ValeurRJ,0)+isnull(ValeurIn,0)-isnull(ValeurOut,0)
	 where QteFinale != 0
	 
	 
	 select @count=count(*) from #Final2
	 
	 if @count>0
	   begin
		 select Article,ARFAM,ARFO,
		 QteInit,ValeurInit,round(ValeurInit*abs(sign(QteInit))/(QteInit+(1-abs(sign(QteInit)))),2),
		 QteRJ,ValeurRJ,
		 QteIn,ValeurIn,round(ValeurIn*abs(sign(QteIn))/(QteIn+(1-abs(sign(QteIn)))),2),
		 QteOut,ValeurOut,round(ValeurOut*abs(sign(QteOut))/(QteOut+(1-abs(sign(QteOut)))),2),
		 QteFinale,ValeurFinale,round(ValeurFinale*abs(sign(QteFinale))/(QteFinale+(1-abs(sign(QteFinale)))),2),
		 ARLIB,FPLIB,FONOM,@count
		 from #Final2,#FAR,FFP,FFO
		 where Article=ARCODE
		 and ARFAM=FPCODE
		 and ARFO=FOCODE
		 order by ARFO,ARFAM,Article
	   end
	  else
	   begin
		 select '','','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,'','','',@count
	   end
	 
	   
		 drop table #FAR
		 drop table #Final2
 
	end		/* else de if (@count=0) */
end



go

