/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.CC_AvecBAC_Pret
grant execute on CC_AvecBAC_Pret to public
*/

CREATE PROCEDURE dbo.CC_AvecBAC_Pret
@numCC VARCHAR(10) 
AS
BEGIN
                  
select distinct CCBACLNUMBAC
from h_CCBACL,h_ImpRayon,zp_CC_EN_PREP
where CCBACLNUMCC=@numCC
and IRRAYON=CCBACRAYON
and IRREGROUPEMENT<>0 
and CCCODE=CCBACLNUMCC
and isnull(CCBACLNUMBAC,'')<>''
       
END

go

