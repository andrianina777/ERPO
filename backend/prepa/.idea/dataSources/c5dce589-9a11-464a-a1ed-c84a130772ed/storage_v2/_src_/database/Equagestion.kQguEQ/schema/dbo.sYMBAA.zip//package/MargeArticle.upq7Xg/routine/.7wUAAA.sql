


create procedure MargeArticle (	@ent			char(5)	= null,
								@FromArticle	char(15),
								@ToArticle		char(15),
							  	@FromDate		smalldatetime,
								@ToDate			smalldatetime)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Liste
	(
	Article			char(15)	not null,
	Designation		varchar(80)		null,
	Lettre			char(4)		not null,
	Quantite		int				null,
	PrixVenteUHT	numeric(14,2)	null,
	PrixRevientUHT	numeric(14,2)	null,
	BeneficeUHT		numeric(14,2)	null,
	Coeff			numeric(14,2)	null
	)
	
	
	insert into #Liste
    select FALARTICLE,ARLIB,FALLETTRE,FALQTE,round(FALTOTALHT/FALQTE,2),0.00,0.00,0.00
    from FFAL,FAR
    where FALDATE between @FromDate and @ToDate
   	and FALARTICLE between @FromArticle and @ToArticle
	and FALQTE!=0
	and ARCODE=FALARTICLE
	and (@ent is null or FALENT=@ent)
	
	update #Liste set PrixRevientUHT=round((STPAHT+STFRAIS)/CVLOT,2)
	from #Liste,FSTOCK,FAR,FCV,FDP
	where STAR=Article
	and STLETTRE=Lettre
	and ARCODE=Article
	and CVUNIF=ARUNITACHAT
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
   
	update #Liste set BeneficeUHT=PrixVenteUHT-PrixRevientUHT,
		Coeff=round(PrixVenteUHT/PrixRevientUHT,2)
	where PrixRevientUHT!=0
	
	print	""
	print	""
	print "Articles dont le PRHT est documente au stock"	
	print	""
	print	""

select Article,Designation,QteTot=sum(Quantite),
	PVMUHT=convert(char(10),avg(PrixVenteUHT)),
	PRMUHT=convert(char(10),convert(numeric(14,2),avg(PrixRevientUHT))),
	BMUHT=convert(char(10),convert(numeric(14,2),avg(BeneficeUHT))),
	CoefM=convert(char(10),convert(numeric(14,2),avg(Coeff)))
from #Liste
where PrixRevientUHT!=0
group by Article,Designation

	print	""
	print ""
	print "Articles dont le PRHT n'est pas documente au stock"
	print	""
	print	""

select Article,Designation,QteTot=sum(Quantite),
	PVMUHT=avg(PrixVenteUHT)
from #Liste
where PrixRevientUHT=0
group by Article,Designation

end



go

