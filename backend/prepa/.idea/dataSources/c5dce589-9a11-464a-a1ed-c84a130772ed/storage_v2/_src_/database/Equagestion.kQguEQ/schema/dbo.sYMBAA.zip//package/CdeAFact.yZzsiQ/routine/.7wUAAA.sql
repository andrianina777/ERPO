


/* Procedure donnant la liste des commandes clients non facturees
appartenant a des commandes entierement livrees
pouvant etre facturees en automatique */
/* Modification le 060204 - ajout des fiches atelier */

create procedure CdeAFact	(@ent	char(5) = null)
with recompile
as
begin
	set arithabort numeric_truncation off

	create table #Bel
	(
	LienCode	char(10)	not null,
	Client		char(12)	not null
	)

	declare @saisondeb	char(5),
		@saisonfin	char(5),
		@datesaisondeb	datetime,
		@datesaisonfin	datetime
		
	select @saisondeb=PSAISONDEB,@saisonfin=PSAISONFIN from KParam
	where (@ent is null or PENT=@ent)

	set dateformat dmy
	select @datesaisondeb=convert(datetime,@saisondeb+"/"+convert(varchar(4),datepart(yy,getdate())))
	select @datesaisonfin=convert(datetime,@saisonfin+"/"+convert(varchar(4),datepart(yy,getdate())))
	set dateformat mdy

	insert into #Bel (LienCode,Client)
	select BELLIENCODE,BELCL
	from FBEL, FRBE
	where RBESEQ=BELSEQ
	and RBEFACTMAN=0
	and RBEDEMO=0
	and RBESTADE in (2,3)
	and ((RBEECH=0) or (RBEECH=1 and RBEDATE < @datesaisondeb) or (RBEECH=1 and RBEDATE > @datesaisonfin))
	and BELLIENCODE like 'CC%'
	and BELQTE >= 0
	and (@ent is null or (BELENT=@ent and RBEENT=@ent))
	group by BELLIENCODE,BELCL

	select distinct incomplet=LienCode
	into #Inc
	from #Bel,FCCL,FRCC
	where RCCSEQ=CCLSEQ
	and LienCode=CCLCODE
	and (@ent is null or (CCLENT=@ent and RCCENT=@ent))

	delete #Bel
	from #Inc
	where incomplet=LienCode

	/* atelier */
	insert into #Bel (LienCode,Client)
	select WBLFICHE,WBLCL
	from FWBL, FRWB
	where RWBSEQ=WBLSEQ
	and WBLFICHE like 'W%'
	and WBLQTE >= 0
	and (@ent is null or (WBLENT=@ent and RWBENT=@ent))
	group by WBLFICHE,WBLCL

	select LienCode,Client
	from #Bel
	order by LienCode

	drop table #Inc
	drop table #Bel
end



go

