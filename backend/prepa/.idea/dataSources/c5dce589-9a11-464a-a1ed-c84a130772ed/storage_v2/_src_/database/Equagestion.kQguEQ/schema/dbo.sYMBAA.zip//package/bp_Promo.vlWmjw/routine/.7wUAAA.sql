/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_Promo
grant execute on bp_Promo to public

*/

CREATE PROCEDURE dbo.bp_Promo(@codeClient char(12),@codeArticle char(15),@Qte	int)
with recompile
AS
begin
 declare  @pvht numeric (14,2),
          @labo char(6),
          @remise numeric(8,4),
          @libre int,
          @tarif char(8)
          
	 	select @pvht=0,@remise=0
	 	
	 	select @labo=CLSA,@tarif=CLTARIF from FCL where CLCODE=@codeClient
	 	
		set rowcount 1
		select @remise=isnull(ARTREMISE,0),@pvht=isnull(ARTPVHT,0),@libre=ARTLIBRE   
		from xFART where ((ARTCL=@codeClient) or (ARTCLSA=@labo and ARTCL='*') or  (ARTCLSA='*')) and ARTAR=@codeArticle and ARTQTE<=@Qte 
		and (convert (DATE,ARTDATEDEB,103)<=convert(DATE,getDate(),103) and convert(DATE,ARTDATEFIN,103)>=convert(DATE,getDate(),103) or(ARTDATEDEB is null and ARTDATEFIN is null))
		order by ARTQTE desc
		set rowcount 0
		
		if(@remise<>0)
			begin
				select @pvht=ARTPVHT from FART where ARTAR=@codeArticle and ARTTARIF=@tarif
				select @pvht,isnull(@libre,0),@remise
			end
		else if(@pvht<>0)
			begin
				select @pvht,isnull(@libre,0),0
			end
		else
			begin
				select @pvht=isnull(pNewPrix,0) from xPromoflash where pArticle=@codeArticle and isnull(pEnvoi,0)=0 and current_date() between convert(Date,pDatedebut) and convert(Date,pDatefin)  and pDateReinit is null order by pfSeq desc
				if(@pvht<>0) select @pvht,1,0
				else select 0,0,0
			end
end
go

