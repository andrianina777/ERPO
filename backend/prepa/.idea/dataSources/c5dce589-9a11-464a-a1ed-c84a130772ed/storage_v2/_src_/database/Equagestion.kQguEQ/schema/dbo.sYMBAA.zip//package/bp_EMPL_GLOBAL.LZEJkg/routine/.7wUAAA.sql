/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_EMPL_GLOBAL
grant execute on bp_EMPL_GLOBAL to public
*/

CREATE PROCEDURE bp_EMPL_GLOBAL( @dep char(4))
with recompile
AS
begin


 	 
 	 create table #EMPL(
 	 	m_dep char(4),
 	 	m_emp char(8),
 	 	m_empl char(8),
 	 	m_local char(15)
 	 )
 	 

 
 	  	insert into #EMPL select xDepotl,xEmpl,case when (isnull(xEmplSTEMP,'')<>'') then upper(xEmplSTEMP) else upper(xEmpExact) end,'Ankorondrano' from xEMPL where xDepotl=@dep and isnull(xArticlel,'')='' 
 	  	order by xEmpl,case when (isnull(xEmplSTEMP,'')<>'') then upper(xEmplSTEMP) else upper(xEmpExact) end
 	  	
 	  	insert into #EMPL select xDEPOTL,xALLEL,xEMPL,'DIG' from xEMP_DIGUEL where xDEPOTL=@dep and isnull(xARTICLE,'')='' order by xDEPOTL,xALLEL,xEMPL
 	
 	  
	 
	 
	 select #EMPL.m_dep, #EMPL.m_emp, #EMPL.m_empl, #EMPL.m_local from #EMPL
	 
	 drop table #EMPL
	 
	 	
end
go

