


create procedure Stock_mini_depasse
as
begin

select Article=STAR, Designation = ARLIB, StockMini = ARSTOCKMINI, Stock = sum(STQTE)
from FSTOCK,FAR
where ARCODE=STAR
and AROLD = 0
group by STAR,ARLIB,ARSTOCKMINI
having ARSTOCKMINI > sum(STQTE)
order by STAR

end



go

