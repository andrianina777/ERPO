


create procedure TotalFactman(	@ent			char(5) = null,
								@code 			char(10),
							  	@TauxEscompte	real,
							  	@sanstva		tinyint,
						      	@date			smalldatetime,
							  	@spid			int,
							  	@clfact			char(12)
							  )
with recompile
as
begin

set arithabort numeric_truncation off


/* cette procedure ne peut etre efficacement utilisee que depuis OMNIS 
	car elle utilise le contenu de la table FFATEMP */


declare @clclasse	char(10)

create table #Lignes
(
FALTOTALHT		numeric(14,2)		null,
TAUXTVA			real				null,
TVSANSESC		tinyint				null,
CPTETVA			char(12)			null,
MTESCOMPTE		numeric(14,2)		null
)

select @clclasse = CLCLASSE 
from FCL
where CLCODE = @clfact
and (@ent is null or CLENT=@ent)

insert into #Lignes
	select FALTOTALHT=FATPTOTALHT, TVLTAUXTVA, TVSANSESC, TVLCOMPTETVA,
		MTESCOMPTE=round(FATPTOTALHT*@TauxEscompte*(1-TVSANSESC),2)
	from FFATEMP, FTV, FTVL
	where FATPCODE=@code and FATPUSERID=@spid  
	and TVLCODE=FATPTYPEVE
	and TVCODE=TVLCODE
	and TVLCLASSE=@clclasse
	and (@ent is null or (FATEMPENT=@ent and TVLENT=@ent))
	
	
 /* faire tous les calculs avec	(FALTOTALHT-MTESCOMPTE) */
 
 	select CPTETVA,TAUXTVA,TotalLigneHT=round(sum(FALTOTALHT-MTESCOMPTE),2),
			Taxe=round(sum(FALTOTALHT-MTESCOMPTE)*(TAUXTVA/100),2)
	into #Taxes
	from #Lignes
	group by CPTETVA,TAUXTVA
	
	
	select TAUXTVA,TotalHT=round(sum(TotalLigneHT),2),
			TotalTaxe=round(sum(Taxe),2),TypeTaxe=0
	into #LesTaxes
	from #Taxes
	group by TAUXTVA
	
	
 /* Mise en place des taux de TVA des differents articles */
	
	declare @taux		real			/* rubrique de test du taux de TVA */
	declare @basetaxe1	numeric(14,2)	/* base taxee de la TVA 1 */
	declare @basetaxe2	numeric(14,2)	/* base taxee de la TVA 2 */
	declare @basetaxe3	numeric(14,2)	/* base taxee de la TVA 3 */
	declare @tauxtaxe1	real			/* taux de la taxe 1 */
	declare @tauxtaxe2	real			/* taux de la taxe 2 */
	declare @tauxtaxe3	real			/* taux de la taxe 3 */
	declare @typetaxe1	char(10)		/* nom de la taxe 1 */
	declare @typetaxe2	char(10)		/* nom de la taxe 2 */
	declare @typetaxe3	char(10)		/* nom de la taxe 3 */
	declare @maxtot		numeric(14,2)	/* variable de test */
	declare @num		tinyint			/* rubrique de numerotation des taxes */
	select 	@num=0
	
	select @taux=max(TAUXTVA)
	from #LesTaxes
	
	while @taux is not null
		begin	
			select @num=@num+1
			update #LesTaxes set TypeTaxe=@num where TAUXTVA=@taux
			if @num=1
				begin
					select @tauxtaxe1=@taux
					select @typetaxe1='TVA 1'
				end
			if @num=2
				begin
					select @tauxtaxe2=@taux
					select @typetaxe2='TVA 2'
				end
			if @num=3
				begin
					select @tauxtaxe3=@taux
					select @typetaxe3='Autres'
				end
			
			select @taux=max(TAUXTVA)
			from #LesTaxes
			where TAUXTVA<@taux
		end
		
		if @tauxtaxe1 is null
		select @tauxtaxe1=0
		
		if @tauxtaxe2 is null
		select @tauxtaxe2=0
		
		if @tauxtaxe3 is null
		select @tauxtaxe3=0
		
		if @typetaxe1 is null
		select @typetaxe1=''
		
		if @typetaxe2 is null
		select @typetaxe2=''
		
		if @typetaxe3 is null
		select @typetaxe3=''
	
 /* Calculs des totaux escomptables et non escomptables */	
	
	declare @TotEsc numeric(14,2)		/* total escomptable */
	declare @TotNonEsc numeric(14,2)	/* total non escomptable */
	select @TotEsc=round(sum(FALTOTALHT),2)
	from #Lignes
	where TVSANSESC=0
	
	if @TotEsc is null
		select @TotEsc=0
	
	select @TotNonEsc=round(sum(FALTOTALHT),2)
	from #Lignes
	where TVSANSESC=1
	
	if @TotNonEsc is null
		select @TotNonEsc=0
	
 /* Calcul et repartition des taxes */	
	
	
	declare @taxe1		numeric(14,2)			/* total de la taxe 1 */
	declare @taxe2		numeric(14,2)			/* total de la taxe 2 */
	declare @taxe3		numeric(14,2)			/* total de la taxe 3 */
	declare @totalht	numeric(14,2)			/* total HT */
	declare @netapayer	numeric(14,2)			/* net a payer */
	declare @escompte	numeric(14,2)			/* total escompte */
	
	
	
	if @sanstva=1
	  begin
			select @sanstva=1
			select @tauxtaxe1=0
			select @tauxtaxe2=0
			select @tauxtaxe3=0
			select @basetaxe1=0
			select @basetaxe2=0
			select @basetaxe3=0
			select @taxe1=0
			select @taxe2=0
			select @taxe3=0
			select @escompte=round(sum(MTESCOMPTE),2) from #Lignes
			select @totalht=round(sum(TotalHT),2) from #LesTaxes
			select @netapayer=@totalht
			select @typetaxe1='Exoneree'
			select @typetaxe2=''
			select @typetaxe3=''
			
	  end
	else
	  begin
		  
		  select @basetaxe1=round(TotalHT,2),@taxe1=round(TotalTaxe,2)
		  from #LesTaxes
		  where TypeTaxe=1
		  
		  
		  select @basetaxe2=round(TotalHT,2),@taxe2=round(TotalTaxe,2)
		  from #LesTaxes
		  where TypeTaxe=2
		  
		  
		  select @basetaxe3=round(sum(TotalHT),2),@taxe3=round(sum(TotalTaxe),2)
		  from #LesTaxes
		  where TypeTaxe>2
		  
		  select @escompte=round(sum(MTESCOMPTE),2) from #Lignes
		  select @totalht=round(isnull(@basetaxe1,0)+isnull(@basetaxe2,0)+isnull(@basetaxe3,0),2)
		  select @netapayer=round(@totalht+isnull(@taxe1,0)+isnull(@taxe2,0)+isnull(@taxe3,0),2)
		  
		  
	  end
	
		
 /* renvoi des resultats a la procedure appelante */
 
 	select totalht=@totalht,TauxEscompte=@TauxEscompte,escompte=@escompte,
			typetaxe1=@typetaxe1,typetaxe2=@typetaxe2,typetaxe3=@typetaxe3,
			tauxtaxe1=@tauxtaxe1,tauxtaxe2=@tauxtaxe2,tauxtaxe3=@tauxtaxe3,
			basetaxe1=isnull(@basetaxe1,0),
			basetaxe2=isnull(@basetaxe2,0),
			basetaxe3=isnull(@basetaxe3,0),
			netapayer=@netapayer,sanstva=@sanstva,
			taxe1=isnull(@taxe1,0),
			taxe2=isnull(@taxe2,0),
			taxe3=isnull(@taxe3,0),
			TotEsc=@TotEsc,TotNonEsc=@TotNonEsc
			
drop table #Lignes
drop table #Taxes
drop table #LesTaxes
	 
end



go

