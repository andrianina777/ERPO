


/* Renvoie la liste des remises pour un client - en devis et commandes */

create procedure RC_Liste (	@ent		char(5) = null,
							@client 	char(12),
						   	@an 		smallint
						  )
with recompile
as
begin

set arithabort numeric_truncation off


declare @clcodegroupe	char(12),
		@cltypecli		tinyint

create table #Liste
(
RCCL		char(12)		not	null,
RCDEPART	char(8)			not null,
RCFO		char(12)		not	null,
RCFAM		char(8)			not	null,
RCCATEG		char(8)			not	null,
RCARTICLE	char(15)		not	null,
RCTARIF		char(8)			not	null,
RCPR1		tinyint			not	null,
RCR1		numeric(8,4)	not	null,
RCPR2		tinyint			not	null,
RCR2		numeric(8,4)	not	null,
RCPR3		tinyint			not	null,
RCR3		numeric(8,4)	not	null,
RCPRFA		tinyint			not	null,
RCRFA		numeric(8,4)	not	null,
RCCONTRAT	char(10)		not null,
RCID		numeric(14,0)	identity
)


select @clcodegroupe=CLCODEGROUPE,@cltypecli=CLTYPECLI
from FCL
where CLCODE=@client
and (@ent is null or CLENT=@ent)


insert into #Liste (RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,RCCONTRAT)
select isnull(RCCL,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),isnull(RCCATEG,''),
		isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCPR1,0),isnull(RCR1,0),isnull(RCPR2,0),
		isnull(RCR2,0),isnull(RCPR3,0),isnull(RCR3,0),isnull(RCPRFA,0),isnull(RCRFA,0),isnull(RCCONTRAT,'')
from FRC
where RCCL=@client
and RCAN=@an
and (@ent is null or RCENT=@ent)
order by RCCONTRAT,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF

insert into #Liste (RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,RCCONTRAT)
select isnull(RCCL,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),isnull(RCCATEG,''),
		isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCPR1,0),isnull(RCR1,0),isnull(RCPR2,0),
		isnull(RCR2,0),isnull(RCPR3,0),isnull(RCR3,0),isnull(RCPRFA,0),isnull(RCRFA,0),isnull(RCCONTRAT,'')
from FRC
where RCCL=@client
and RCAN=0
and (@ent is null or RCENT=@ent)
order by RCCONTRAT,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF


if isnull(@clcodegroupe,'') != '' and isnull(@cltypecli,0) = 2
begin

  insert into #Liste (RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,RCCONTRAT)
  select isnull(RCCL,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),isnull(RCCATEG,''),
		  isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCPR1,0),isnull(RCR1,0),isnull(RCPR2,0),
		  isnull(RCR2,0),isnull(RCPR3,0),isnull(RCR3,0),isnull(RCPRFA,0),isnull(RCRFA,0),isnull(RCCONTRAT,'')
  from FRC
  where RCCL=@clcodegroupe
  and RCAN=@an
  and (@ent is null or RCENT=@ent)
  order by RCCONTRAT,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF
  
  insert into #Liste (RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,RCCONTRAT)
  select isnull(RCCL,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),isnull(RCCATEG,''),
		  isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCPR1,0),isnull(RCR1,0),isnull(RCPR2,0),
		  isnull(RCR2,0),isnull(RCPR3,0),isnull(RCR3,0),isnull(RCPRFA,0),isnull(RCRFA,0),isnull(RCCONTRAT,'')
  from FRC
  where RCCL=@clcodegroupe
  and RCAN=0
  and (@ent is null or RCENT=@ent)
  order by RCCONTRAT,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF

end


insert into #Liste (RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,RCCONTRAT)
select isnull(RCCL,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),isnull(RCCATEG,''),
		isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCPR1,0),isnull(RCR1,0),isnull(RCPR2,0),
		isnull(RCR2,0),isnull(RCPR3,0),isnull(RCR3,0),isnull(RCPRFA,0),isnull(RCRFA,0),isnull(RCCONTRAT,'')
from FRC
where RCCL=''
and RCAN=@an
and (@ent is null or RCENT=@ent)
order by RCCONTRAT,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF

insert into #Liste (RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA,RCCONTRAT)
select isnull(RCCL,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),isnull(RCCATEG,''),
		isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCPR1,0),isnull(RCR1,0),isnull(RCPR2,0),
		isnull(RCR2,0),isnull(RCPR3,0),isnull(RCR3,0),isnull(RCPRFA,0),isnull(RCRFA,0),isnull(RCCONTRAT,'')
from FRC
where RCCL=''
and RCAN=0
and (@ent is null or RCENT=@ent)
order by RCCONTRAT,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF


select RCCL,RCDEPART,RCFO,RCFAM,RCCATEG,RCARTICLE,RCTARIF,RCPR1,RCR1,RCPR2,RCR2,RCPR3,RCR3,RCPRFA,RCRFA
from #Liste
order by RCID

drop table #Liste

end



go

