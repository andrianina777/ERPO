


/* Procedure qui met a jour le PUMP en entree de stock */

create procedure MAJ_PUMP ( @type		char(8),			/* insert, delete, annule, update */
							@article	char(15),
							@qtein		int,
							@qtedel		int = 0,
							@prumin		numeric(14,4),
							@prumout	numeric(14,4),
							@datecre	smalldatetime = "",	/* date de creation de la ligne de mouvement de stock */
							@ent		char(5)	= null
						  )
with recompile
as
begin

set arithabort numeric_truncation off

declare	@stock 			int,				/* qte en stock au moment de la demande */
		@qteoldin		int,
		@pump			numeric(14,4),
		@newpump		numeric(14,4),
		@seq			int,
		@count			int,
		@datearrete		datetime,
		@multient		tinyint,
		@ligne			int,
		@PUMSEQ			int,
		@PUMDATE		smalldatetime,
		@PUMQTESTOCK	int,
		@PUMQTEIN		int,
		@PUMPRU			numeric(14,4),
		@PUMOLD			numeric(14,4),
		@PUMP			numeric(14,4),
		@newPUMQTESTOCK	int,
		@newPUMQTEIN	int,
		@newPUMPRU		numeric(14,4),
		@newPUMOLD		numeric(14,4),
		@newPUMP		numeric(14,4),
		@oldPUMQTESTOCK	int,
		@oldPUMQTEIN	int,
		@oldPUMPRU		numeric(14,4),
		@oldPUMOLD		numeric(14,4),
		@oldPUMP		numeric(14,4),
		@date			smalldatetime

			


  select @stock = isnull(sum(STQTE),0) from FSTOCK where STQTE > 0 and STAR=@article
  select @qteoldin = 0
  select @newPUMQTESTOCK = 0,
  		 @newPUMQTEIN = 0,
		 @newPUMPRU = 0,
		 @newPUMOLD = 0,
		 @newPUMP = 0
  
  select @multient=KIMULTIENTITE from KInfos
  select @datearrete=PARRETSTOCK from KParam where (@multient = 0 or isnull(PENT,'')=isnull(@ent,''))
  select @date=getdate()

/*-----------------------------------------------  Cas insert -----------------------------------*/

if (@type="insert" and @date > @datearrete)
begin

  select @seq=PUMSEQ, @pump=PUMP, @qteoldin=PUMQTEIN
  from FPUM
  where PUMAR = @article
  and PUMDATE = convert(smalldatetime,getdate())
  
  select @count=@@rowcount

  
  if @count = 0
  begin
  
	select @pump=PUMP
	from FPUM
	where PUMAR = @article
	and PUMDATE < convert(smalldatetime,getdate())
	having PUMAR = @article
	and PUMDATE < convert(smalldatetime,getdate())
	and PUMDATE = max(PUMDATE)
  
    if @@rowcount = 0
	begin
	  select @pump=@prumin
	end

	exec eq_GetSeq_proc "FPUM", 1, @seq output
	
	select @newpump = convert(numeric(14,4),round(((@pump*@stock)+(@prumin*@qtein))/(@stock+@qtein),4))
	
		
	insert into FPUM (PUMSEQ,PUMAR,PUMDATE,PUMQTESTOCK,PUMQTEIN,PUMPRU,PUMOLD,PUMP,PUMMODIF)
	values (@seq,@article,convert(smalldatetime,getdate()),isnull(@stock,0),@qtein-@qtedel,@prumin,@pump,@newpump,0)
	
				/* quantite entree = @qtein-@qtedel => souplesse sur insert. Voir si utile */

  end
  else if @count = 1
  begin
    
   if (@stock-@qteoldin) > 0
	  update FPUM
	  set PUMQTESTOCK = @stock-PUMQTEIN,
		  PUMQTEIN = PUMQTEIN+@qtein,
		  PUMPRU = convert(numeric(14,4),round(((PUMPRU*PUMQTEIN)+(@prumin*@qtein))/(PUMQTEIN+@qtein),4)),
		  PUMP = convert(numeric(14,4),round(((PUMOLD*(@stock-PUMQTEIN))+(@prumin*@qtein)+(PUMPRU*PUMQTEIN))/(@stock+@qtein),4)),
		  PUMMODIF = 0
	  where PUMSEQ=@seq
   else
   if (@stock-@qteoldin) <= 0
	  update FPUM
	  set PUMQTESTOCK = 0,
		  PUMQTEIN = @stock+@qtein,
		  PUMPRU = convert(numeric(14,4),round(((PUMPRU*@stock)+(@prumin*@qtein))/(@stock+@qtein),4)),
		  PUMP = convert(numeric(14,4),round(((PUMPRU*@stock)+(@prumin*@qtein))/(@stock+@qtein),4)),
		  PUMMODIF = 0
	  where PUMSEQ=@seq
	  
  end
end

/*-----------------------------------------------  Cas delete -----------------------------------*/

else if (@type="delete" and @datecre > @datearrete)
begin

  select @ligne = 0

  declare pump cursor 
  for 
  select PUMSEQ,PUMDATE,PUMQTESTOCK,PUMQTEIN,PUMPRU,PUMOLD,PUMP
  from FPUM
  where PUMAR=@article
  and PUMDATE>=@datecre
  order by PUMDATE
  
  open pump
  
  fetch pump
  into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP
  
  while (@@sqlstatus = 0)
  begin
	
	select @ligne = @ligne + 1
	
	/*------------ Rencontre d''une ligne de generation manuelle du PUMP ------------*/
  
  	if (@PUMQTESTOCK + @PUMQTEIN = 0 and @PUMOLD = @PUMP)
	  begin

		/*------------ Nous traitons la premiere ligne a recalculer dans ce cas -------------*/
		
			select @newPUMQTESTOCK = @PUMQTESTOCK-@qtedel
			select @newPUMQTEIN = @PUMQTEIN+@qtedel

			if @ligne > 1
			  select @newPUMPRU = @oldPUMP,
					 @newPUMOLD = @oldPUMP,
					 @newPUMP = @oldPUMP
			
			if @ligne = 1   
			   update FPUM
			   set PUMQTESTOCK = @newPUMQTESTOCK,
				   PUMQTEIN = @newPUMQTEIN,
				   PUMMODIF = 1
				 where PUMSEQ=@PUMSEQ
	  		else if @ligne > 1
			   update FPUM
			   set PUMQTESTOCK = @newPUMQTESTOCK,
				   PUMQTEIN = @newPUMQTEIN,
				   PUMPRU = @newPUMPRU,
				   PUMOLD = @newPUMOLD,
				   PUMP = @newPUMP,
				   PUMMODIF = 1
				 where PUMSEQ=@PUMSEQ
	  
			fetch pump
			into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP
	  
	   /*------------ Nous traitons la seconde ligne a recalculer dans ce cas -------------*/
	   	  
			if @ligne = 1   
			  update FPUM
			  set PUMQTEIN = @newPUMQTESTOCK,
				  PUMMODIF = 1
				where PUMSEQ=@PUMSEQ
			else if @ligne > 1
			  update FPUM
			  set PUMQTEIN = @newPUMQTESTOCK,
				  PUMOLD = @newPUMOLD,
				  PUMMODIF = 1
				where PUMSEQ=@PUMSEQ
	
 			/*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
			  
			select @oldPUMQTESTOCK = 0,						/* inutilise actuellement */
				   @oldPUMQTEIN = @newPUMQTEIN,				/* inutilise actuellement */
				   @oldPUMPRU = @PUMPRU,					/* inutilise actuellement */
				   @oldPUMOLD = @newPUMOLD,					/* inutilise actuellement */
				   @oldPUMP = @PUMP		  
	
	  end
  else if @ligne = 1
  
  						/*------------ Rencontre d''une ligne de generation normale du PUMP ------------*/
						/*------------ Nous traitons la premiere ligne a recalculer -------------*/
	 begin
	   select @newPUMQTEIN = @PUMQTEIN-@qtedel
	   if @newPUMQTEIN <= 0
		 begin	  
		   select @newPUMQTEIN=0, @newPUMPRU=@PUMOLD, @newPUMP=@PUMOLD
		 end
	   else if @newPUMQTEIN > 0
		 begin
		   select @newPUMPRU = convert(numeric(14,4),round(((@PUMQTEIN*@PUMPRU)-(@qtedel*@prumout))/@newPUMQTEIN,4))
		   select @newPUMP = convert(numeric(14,4),round(((@PUMQTESTOCK*@PUMOLD)+(@newPUMQTEIN*@newPUMPRU))/(@PUMQTESTOCK+@newPUMQTEIN),4))
		 end
		 
	   update FPUM
	   set PUMQTEIN = @newPUMQTEIN,
		   PUMPRU = @newPUMPRU,
		   PUMP = @newPUMP,
		   PUMMODIF = 1
		 where PUMSEQ=@PUMSEQ
   
		 /*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
   
	   select @oldPUMQTESTOCK = @PUMQTESTOCK,	/* inutilise actuellement */
			  @oldPUMQTEIN = @newPUMQTEIN,		/* inutilise actuellement */
			  @oldPUMPRU = @newPUMPRU,			/* inutilise actuellement */
			  @oldPUMOLD = @PUMOLD,				/* inutilise actuellement */
			  @oldPUMP = @newPUMP		  
		 
	 end

  /*----------------- Nous traitons les lignes suivantes -------------------*/

  else if @ligne > 1
	 begin
	   select @newPUMQTESTOCK = @PUMQTESTOCK-@qtedel
	   select @newPUMOLD = @oldPUMP
	   if @newPUMQTESTOCK <= 0
		 begin	  
		   select @newPUMQTESTOCK=0, @newPUMP=@PUMPRU
		 end
	   else if @newPUMQTESTOCK > 0
		 begin	  
		   select @newPUMP = convert(numeric(14,4),round(((@newPUMQTESTOCK*@newPUMOLD)+(@PUMQTEIN*@PUMPRU))/(@newPUMQTESTOCK+@PUMQTEIN),4))
		 end
		 
	   update FPUM
	   set PUMQTESTOCK = @newPUMQTESTOCK,
		   PUMOLD = @newPUMOLD,
		   PUMP = @newPUMP,
		   PUMMODIF = 1
		 where PUMSEQ=@PUMSEQ
   
		 /*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
		 
	   select @oldPUMQTESTOCK = @newPUMQTESTOCK,	/* inutilise actuellement */
		  @oldPUMQTEIN = @PUMQTEIN,					/* inutilise actuellement */
		  @oldPUMPRU = @PUMPRU,						/* inutilise actuellement */
		  @oldPUMOLD = @newPUMOLD,					/* inutilise actuellement */
		  @oldPUMP = @newPUMP		  
		 
	 end
	
  
  fetch pump
  into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP

  end
	
  close pump
  deallocate cursor pump

end

/*-----------------------------------------------  Cas annule : traitement des effacements d''entrees negatives -------*/

else if (@type="annule" and @datecre > @datearrete)
begin

  select @ligne = 0

  declare pumpannule cursor 
  for 
  select PUMSEQ,PUMDATE,PUMQTESTOCK,PUMQTEIN,PUMPRU,PUMOLD,PUMP
  from FPUM
  where PUMAR=@article
  and PUMDATE>=@datecre
  order by PUMDATE
  
  open pumpannule
  
  fetch pumpannule
  into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP
  
  while (@@sqlstatus = 0)
  begin
	
	select @ligne = @ligne + 1
	
	/*------------ Rencontre d''une ligne de generation manuelle du PUMP ------------*/
  
  	if (@PUMQTESTOCK + @PUMQTEIN = 0 and @PUMOLD = @PUMP)
	  begin

		/*------------ Nous traitons la premiere ligne a recalculer dans ce cas -------------*/
		
			select @newPUMQTESTOCK = @PUMQTESTOCK+@qtedel
			select @newPUMQTEIN = @PUMQTEIN-@qtedel


			if @ligne > 1
			  select @newPUMPRU = @oldPUMP,
					 @newPUMOLD = @oldPUMP,
					 @newPUMP = @oldPUMP
			
			if @ligne = 1   
			   update FPUM
			   set PUMQTESTOCK = @newPUMQTESTOCK,
				   PUMQTEIN = @newPUMQTEIN,
				   PUMMODIF = 1
				 where PUMSEQ=@PUMSEQ
	  		else if @ligne > 1
			   update FPUM
			   set PUMQTESTOCK = @newPUMQTESTOCK,
				   PUMQTEIN = @newPUMQTEIN,
				   PUMPRU = @newPUMPRU,
				   PUMOLD = @newPUMOLD,
				   PUMP = @newPUMP,
				   PUMMODIF = 1
				 where PUMSEQ=@PUMSEQ
	  
	  
			fetch pumpannule
			into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP
	  
	   /*------------ Nous traitons la seconde ligne a recalculer dans ce cas -------------*/


			if @ligne = 1   
			  update FPUM
			  set PUMQTEIN = @newPUMQTESTOCK,
				  PUMMODIF = 1
				where PUMSEQ=@PUMSEQ
			else if @ligne > 1
			  update FPUM
			  set PUMQTEIN = @newPUMQTESTOCK,
				  PUMOLD = @newPUMOLD,
				  PUMMODIF = 1
				where PUMSEQ=@PUMSEQ
	   	  	
 		/*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
			  
			select @oldPUMQTESTOCK = 0,						/* inutilise actuellement */
				   @oldPUMQTEIN = @newPUMQTEIN,				/* inutilise actuellement */
				   @oldPUMPRU = @PUMPRU,					/* inutilise actuellement */
				   @oldPUMOLD = @newPUMOLD,					/* inutilise actuellement */
				   @oldPUMP = @PUMP		  
	
	  end
  else if @ligne = 1
  
  						/*------------ Rencontre d''une ligne de generation normale du PUMP ------------*/
						/*------------ Nous traitons la premiere ligne a recalculer -------------*/
	 begin
	   select @newPUMQTESTOCK = @PUMQTESTOCK+@qtedel
	   if @newPUMQTESTOCK <= 0
		 begin	  
		   select @newPUMQTESTOCK=0, @newPUMP=@PUMPRU
		 end
	   else if @newPUMQTESTOCK > 0
		 begin	  
		   select @newPUMP = convert(numeric(14,4),round(((@newPUMQTESTOCK*@PUMOLD)+(@PUMQTEIN*@PUMPRU))/(@newPUMQTESTOCK+@PUMQTEIN),4))
		 end
		 
	   update FPUM
	   set PUMQTESTOCK = @newPUMQTESTOCK,
		   PUMP = @newPUMP,
		   PUMMODIF = 1
		 where PUMSEQ=@PUMSEQ
   
		 /*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
   
	   select @oldPUMQTESTOCK = @newPUMQTESTOCK,	/* inutilise actuellement */
			  @oldPUMQTEIN = @newPUMQTEIN,			/* inutilise actuellement */
			  @oldPUMPRU = @newPUMPRU,				/* inutilise actuellement */
			  @oldPUMOLD = @PUMOLD,					/* inutilise actuellement */
			  @oldPUMP = @newPUMP		  
		 
	 end

  /*----------------- Nous traitons les lignes suivantes -------------------*/

  else if @ligne > 1
	 begin
	   select @newPUMQTESTOCK = @PUMQTESTOCK+@qtedel
	   select @newPUMOLD = @oldPUMP
	   if @newPUMQTESTOCK <= 0
		 begin	  
		   select @newPUMQTESTOCK=0, @newPUMP=@PUMPRU
		 end
	   else if @newPUMQTESTOCK > 0
		 begin	  
		   select @newPUMP = convert(numeric(14,4),round(((@newPUMQTESTOCK*@newPUMOLD)+(@PUMQTEIN*@PUMPRU))/(@newPUMQTESTOCK+@PUMQTEIN),4))
		 end
		 
	   update FPUM
	   set PUMQTESTOCK = @newPUMQTESTOCK,
		   PUMOLD = @newPUMOLD,
		   PUMP = @newPUMP,
		   PUMMODIF = 1
		 where PUMSEQ=@PUMSEQ
   
		 /*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
		 
	   select @oldPUMQTESTOCK = @newPUMQTESTOCK,	/* inutilise actuellement */
		  @oldPUMQTEIN = @PUMQTEIN,					/* inutilise actuellement */
		  @oldPUMPRU = @PUMPRU,						/* inutilise actuellement */
		  @oldPUMOLD = @newPUMOLD,					/* inutilise actuellement */
		  @oldPUMP = @newPUMP		  
		 
	 end
	
  
  fetch pumpannule
  into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP

  end
	
  close pumpannule
  deallocate cursor pumpannule

end


/*-----------------------------------------------  Cas update -----------------------------------*/

else if (@type="update" and @datecre > @datearrete)
begin

  select @ligne = 0

  declare pumpupdate cursor 
  for 
  select PUMSEQ,PUMDATE,PUMQTESTOCK,PUMQTEIN,PUMPRU,PUMOLD,PUMP
  from FPUM
  where PUMAR=@article
  and PUMDATE>=@datecre
  order by PUMDATE
  
  open pumpupdate
  
  fetch pumpupdate
  into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP
  
  while (@@sqlstatus = 0)
  begin
	
	select @ligne = @ligne + 1
	
	/*------------ Rencontre d''une ligne de generation manuelle du PUMP ------------*/
  
  	if (@PUMQTESTOCK + @PUMQTEIN = 0 and @PUMOLD = @PUMP)
	begin
	
		/*------------ Nous traitons la premiere ligne a recalculer dans ce cas -------------*/

		select @newPUMQTESTOCK = @PUMQTESTOCK+@qtein-@qtedel
		select @newPUMQTEIN = @PUMQTEIN+@qtedel-@qtein

		if @ligne > 1
		  select @newPUMPRU = @oldPUMP,
				 @newPUMOLD = @oldPUMP,
				 @newPUMP = @oldPUMP
		
		if @ligne = 1   
		   update FPUM
		   set PUMQTESTOCK = @newPUMQTESTOCK,
			   PUMQTEIN = @newPUMQTEIN,
			   PUMMODIF = 1
			 where PUMSEQ=@PUMSEQ
		else if @ligne > 1
		   update FPUM
		   set PUMQTESTOCK = @newPUMQTESTOCK,
			   PUMQTEIN = @newPUMQTEIN,
			   PUMPRU = @newPUMPRU,
			   PUMOLD = @newPUMOLD,
			   PUMP = @newPUMP,
			   PUMMODIF = 1
			 where PUMSEQ=@PUMSEQ

  
		fetch pumpupdate
		into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP
		
	   /*------------ Nous traitons la seconde ligne a recalculer dans ce cas -------------*/
  
		 if @ligne = 1   
		   update FPUM
		   set PUMQTEIN = @newPUMQTESTOCK,
			   PUMMODIF = 1
			 where PUMSEQ=@PUMSEQ
		 else if @ligne > 1
		   update FPUM
		   set PUMQTEIN = @newPUMQTESTOCK,
			   PUMOLD = @newPUMOLD,
			   PUMMODIF = 1
			 where PUMSEQ=@PUMSEQ

  
		/*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
		  
		select @oldPUMQTESTOCK = 0,						/* inutilise actuellement */
		   	   @oldPUMQTEIN = @newPUMQTEIN,				/* inutilise actuellement */
		   	   @oldPUMPRU = @PUMPRU,					/* inutilise actuellement */
		       @oldPUMOLD = @newPUMOLD,					/* inutilise actuellement */
		       @oldPUMP = @PUMP		  

	end
  else  if @ligne = 1
  
  				/*------------ Rencontre d''une ligne de generation normale du PUMP ------------*/
				/*------------ Nous traitons la premiere ligne a recalculer -------------*/
  begin
	select @newPUMQTEIN = @PUMQTEIN+@qtein-@qtedel
	if @newPUMQTEIN <= 0
	  begin	  
		select @newPUMQTEIN=0, @newPUMPRU=@PUMOLD, @newPUMP=@PUMOLD
	  end
	else if @newPUMQTEIN > 0
	  begin	  
		select @newPUMPRU = convert(numeric(14,4),round((((@PUMQTEIN*@PUMPRU)-(@qtedel*@prumout))+(@qtein*@prumin))/@newPUMQTEIN,4))
		select @newPUMP = convert(numeric(14,4),round(((@PUMQTESTOCK*@PUMOLD)+(@newPUMQTEIN*@newPUMPRU))/(@PUMQTESTOCK+@newPUMQTEIN),4))
	  end
	  
	update FPUM
	set PUMQTEIN = @newPUMQTEIN,
		PUMPRU = @newPUMPRU,
		PUMP = @newPUMP,
		PUMMODIF = 1
	  where PUMSEQ=@PUMSEQ

	  /*------------ memorisation des valeurs pour enregistrement suivant ----------------*/

	select @oldPUMQTESTOCK = @PUMQTESTOCK,		/* inutilise actuellement */
	       @oldPUMQTEIN = @newPUMQTEIN,			/* inutilise actuellement */
	       @oldPUMPRU = @newPUMPRU,				/* inutilise actuellement */
	       @oldPUMOLD = @PUMOLD,				/* inutilise actuellement */
	       @oldPUMP = @newPUMP		  
	  
  end

  /*----------------- Nous traitons les lignes suivantes -------------------*/

  else if @ligne > 1
  begin
	select @newPUMQTESTOCK = @PUMQTESTOCK+@qtein-@qtedel
	select @newPUMOLD = @oldPUMP
	if @newPUMQTESTOCK <= 0
	  begin	  
		select @newPUMQTESTOCK=0,@newPUMP=@PUMPRU
	  end
	else if @newPUMQTESTOCK > 0
	  begin	  
		select @newPUMP = convert(numeric(14,4),round(((@newPUMQTESTOCK*@newPUMOLD)+(@PUMQTEIN*@PUMPRU))/(@newPUMQTESTOCK+@PUMQTEIN),4))
	  end
	  
	update FPUM
	set PUMQTESTOCK = @newPUMQTESTOCK,
		PUMOLD = @newPUMOLD,
		PUMP = @newPUMP,
		PUMMODIF = 1
	  where PUMSEQ=@PUMSEQ

	  /*------------ memorisation des valeurs pour enregistrement suivant ----------------*/
	  
	select @oldPUMQTESTOCK = @newPUMQTESTOCK,		/* inutilise actuellement */
	   	   @oldPUMQTEIN = @PUMQTEIN,				/* inutilise actuellement */
	       @oldPUMPRU = @PUMPRU,					/* inutilise actuellement */
	       @oldPUMOLD = @newPUMOLD,					/* inutilise actuellement */
	       @oldPUMP = @newPUMP
	  
  end
	
  
  fetch pumpupdate
  into @PUMSEQ,@PUMDATE,@PUMQTESTOCK,@PUMQTEIN,@PUMPRU,@PUMOLD,@PUMP

  end
	
  close pumpupdate
  deallocate cursor pumpupdate

end

end



go

