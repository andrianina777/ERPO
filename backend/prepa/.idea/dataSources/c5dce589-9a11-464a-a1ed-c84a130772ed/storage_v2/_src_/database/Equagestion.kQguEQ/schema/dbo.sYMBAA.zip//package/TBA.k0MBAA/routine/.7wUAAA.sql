
/* Procedure permettant de crer un nouveau tableau de bord des achats par chef de produits */
/* Modification le 141207 par SP et JG */
/* Modification le 220508 par JG/SP : ajout retours fournisseurs */
	

create procedure TBA (	@siphoto		tinyint,			/* 0=pas de photo de stock 1=Photo de stock */
						@pscode			char(16),
						@psdate			datetime,
						@chcode			char(8),			/* Chef de produit */
						@annee			int,
						@typevalo		tinyint,			/* type de valorisation 0=FIFO, 1=PRM, 2=PUMP */
						@marque			char(12),			/* marque dans le cas de l'ajout manuel d'une ligne */
						@famille		char(8) )			/* famille dans le cas de l'ajout manuel d'une ligne */
with recompile
as
begin

/* version du 220508 */

declare @daterefsup	smalldatetime,
		@daterefinf	smalldatetime,
		@datedebut	smalldatetime,
		@anneeinf	int,
		@an 		char(4)
				
select @an=convert(char,@annee)

select @daterefsup=@an+"1231"
select @daterefinf=@an+"0101"

/* on ne veut pas les elements de commandes clients et fournisseurs de plus de 2 ans */

select @datedebut = dateadd(yy,-2,@daterefinf)

create table #tba
(
fo			char(12)		null,
fam			char(8)			null,
stinit		numeric(14,0)	null,
achats		numeric(14,0)	null,
ca			numeric(14,0)	null,
pr			numeric(14,0)	null,
cdefo		numeric(14,0)	null,
cdecl		numeric(14,0)	null
)

/* select marques et familles du chef de produits */

insert into #tba
select ARFO,ARFAM,0,0,0,0,0,0
from FAR
where ARCHEFP=@chcode
and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
group by ARFO,ARFAM

/* select stock initial */

if @siphoto=1 /* sinon stinit a zero, donc select precedent suffisant */

begin

	if @typevalo=0	/* FIFO */
	begin
		insert into #tba
		select ARFO,ARFAM,
		convert(numeric(14,0),sum(round(isnull((PSPAHT+PSFRAIS)/CVLOT,4)*PSQTE,0))),
		0,0,0,0,0
		from FAR,FPS,FCV
		where PSAR=ARCODE and CVUNIF=ARUNITACHAT
		and ARCHEFP=@chcode	and PSCODE=@pscode 
		and convert(char(8),PSDATE,112)=convert(char(8),@psdate,112)
		and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
		group by ARFO, ARFAM
	
		insert into #tba
		select ARFO,ARFAM,
		convert(numeric(14,0),sum(round(isnull((PBPAHT+PBFRAIS)/CVLOT,4)*PBQTE,0))),
		0,0,0,0,0
		from FAR,FPB,FCV
		where PBAR=ARCODE and CVUNIF=ARUNITACHAT
		and ARCHEFP=@chcode	and PBCODE=@pscode 
		and convert(char(8),PBDATE,112)=convert(char(8),@psdate,112)
		and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
		group by ARFO, ARFAM
	end	

	else if @typevalo=1	/* PRM */
	begin
		insert into #tba
		select ARFO,ARFAM,
		convert(numeric(14,0),sum(isnull(ARPRM*PSQTE,0))),
		0,0,0,0,0
		from FAR,FPS
		where PSAR=ARCODE
		and ARCHEFP=@chcode	and PSCODE=@pscode
		and convert(char(8),PSDATE,112)=convert(char(8),@psdate,112)
		and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
		group by ARFO, ARFAM

		insert into #tba
		select ARFO,ARFAM,
		convert(numeric(14,0),sum(isnull(ARPRM*PBQTE,0))),
		0,0,0,0,0
		from FAR,FPB
		where PBAR=ARCODE
		and ARCHEFP=@chcode	and PBCODE=@pscode 
		and convert(char(8),PBDATE,112)=convert(char(8),@psdate,112)
		and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
		group by ARFO, ARFAM
	end

	else	/* PUMP */
	begin
		insert into #tba
		select ARFO,ARFAM,
		convert(numeric(14,0),sum(isnull(PUMP*PSQTE,0))),
		0,0,0,0,0
		from FAR,FPS,FPUM
		where PSAR=ARCODE and PUMAR=ARCODE
		and ARCHEFP=@chcode	and PSCODE=@pscode 
		and convert(char(8),PSDATE,112)=convert(char(8),@psdate,112)
		and PUMDATE=(select max(PUMDATE) from FPUM where PUMAR=FAR.ARCODE and PUMDATE<=FPS.PSDATE)
		and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
		group by ARFO, ARFAM

		insert into #tba
		select ARFO,ARFAM,
		convert(numeric(14,0),sum(isnull(PUMP*PBQTE,0))),
		0,0,0,0,0
		from FAR,FPB,FPUM
		where PBAR=ARCODE and PUMAR=ARCODE
		and ARCHEFP=@chcode	and PBCODE=@pscode 
		and convert(char(8),PBDATE,112)=convert(char(8),@psdate,112)
		and PUMDATE=(select max(PUMDATE) from FPUM where PUMAR=FAR.ARCODE and PUMDATE<=FPB.PBDATE)
		and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
		group by ARFO, ARFAM
	end
	
end

/* select achats */

insert into #tba
select ARFO,ARFAM,0,convert(numeric(14,0),sum(isnull(BLLTOTHT,0))),0,0,0,0
from FAR,FBLL
where BLLAR=ARCODE
	and ARCHEFP=@chcode
	and BLLDATE>=@daterefinf and BLLDATE<=@daterefsup
	and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
group by ARFO, ARFAM


/* - select retours fournisseurs */

insert into #tba
select ARFO,ARFAM,0,convert(numeric(14,0),-(sum(isnull(RFLTOTALHT,0)))),0,0,0,0
from FAR,FRFL
where RFLARTICLE=ARCODE
	and ARCHEFP=@chcode
	and RFLDATE>=@daterefinf and RFLDATE<=@daterefsup
	and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
group by ARFO,ARFAM

/* select chiffres d'affaire, marges */

insert into #tba
select 	ARFO,ARFAM,0,0,convert(numeric(14,0),sum(isnull(STCAFA,0))),
				(case	when @typevalo=0 then convert(numeric(14,0),isnull(sum(STPR),0))
				when @typevalo=1 then convert(numeric(14,0),isnull(sum(STPRM),0))
				else convert(numeric(14,0),isnull(sum(STPUM),0))end),
				0,0
from FAR,FST
where START=ARCODE
	and ARCHEFP=@chcode 
	and (STAN=@annee)
	and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)	
group by ARFO, ARFAM


/* select cdes fournisseurs */

insert into #tba
select ARFO,ARFAM,0,0,0,0,
convert(numeric(14,0),sum(case when CFLQTE=0 then 0 else isnull(CFLTOTALHT/CFLQTE*RCFQTE,0) end)),0
from FAR,FRCF,FCFL,FCF
where RCFARTICLE=ARCODE and CFLSEQ=RCFSEQ and CFCODE=CFLCODE 
	and ARCHEFP=@chcode
	and CFLDATEP between @datedebut and @daterefsup
	and CFVALIDE=0
	and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
group by ARFO, ARFAM


/* select cdes clients */

insert into #tba
select ARFO,ARFAM,0,0,0,0,0,
convert(numeric(14,0),sum(case when CCLQTE=0 then 0 else isnull(CCLTOTALHT/CCLQTE*RCCQTE,0) end))
from FAR,FRCC,FCCL,FCC
where RCCARTICLE=ARCODE and CCLSEQ=RCCSEQ and CCCODE=CCLCODE
	and ARCHEFP=@chcode 
	and CCLDATE between @datedebut and @daterefsup
	and CCVALIDE=0
	and (isnull(@marque,"")="" or ARFO=@marque and ARFAM=@famille)
group by ARFO,ARFAM


/* select final */

select fo,fam,
sum(stinit),0,0,0,0,0,
sum(achats),sum(ca),convert(numeric(14,2),(case when sum(ca)=0 then 0 else 100*(sum(ca)-isnull(sum(pr),0))/sum(ca) end)),0,
sum(cdefo),sum(cdecl),0,0,0,FODEVISE,
isnull(@pscode,''),@psdate,@typevalo,@chcode,@annee
from #tba,FFO
where FOCODE=fo
group by fo,fam,FODEVISE
order by fo,fam,FODEVISE


drop table #tba
end
go

