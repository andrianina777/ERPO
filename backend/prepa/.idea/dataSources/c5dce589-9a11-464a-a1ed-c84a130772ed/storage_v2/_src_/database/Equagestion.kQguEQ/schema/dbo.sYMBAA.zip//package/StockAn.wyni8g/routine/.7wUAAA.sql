


/* Procedure permettant de suivre l''evolution du stock pour un article 
	sur une annee */

create procedure StockAn (@Article	char(15),
						  @An		smallint)
with recompile
as
begin

set nocount on


declare	@date		datetime
declare @anterieur	int
declare @Jan		int
declare @Fev		int
declare @Mar		int
declare @Avr		int
declare @Mai		int
declare @Jun		int
declare @Jul		int
declare @Aou		int
declare @Sep		int
declare @Oct		int
declare @Nov		int
declare @Dec		int


select @date=convert(datetime,"01/01/"+convert(char(4),@An))


create table #StockPrec
(
ArticleP		char(15)	null,
QteP			int			null
)

create table #StockAn
(
Article		char(15)	null,
Qte1		int			null,
Qte2		int			null,
Qte3		int			null,
Qte4		int			null,
Qte5		int			null,
Qte6		int			null,
Qte7		int			null,
Qte8		int			null,
Qte9		int			null,
Qte10		int			null,
Qte11		int			null,
Qte12		int			null
)

create table #Cdes
(
Article		char(15)	null,
Qte1		int			null,
Qte2		int			null,
Qte3		int			null,
Qte4		int			null,
Qte5		int			null,
Qte6		int			null,
Qte7		int			null,
Qte8		int			null,
Qte9		int			null,
Qte10		int			null,
Qte11		int			null,
Qte12		int			null
)

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #StockPrec
select SILARTICLE,sum(SILQTE)
from FSIL
where SILARTICLE=@Article
and SILDATE<@date
group by SILARTICLE


/* ''Reajustements - Fichier RJL'' */

insert into #StockPrec
select RJLARTICLE,sum(RJLQTE)
from FRJL
where RJLARTICLE=@Article
and RJLDATE<@date
group by RJLARTICLE


/* ''Lignes de casse - Fichier LCL'' */

insert into #StockPrec
select LCLARTICLE,sum(LCLQTE)
from FLCL
where LCLARTICLE=@Article
and LCLDATE<@date
group by LCLARTICLE


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #StockPrec
select ASLARTICLE,sum(ASLQTE)
from FASL
where ASLARTICLE=@Article
and ASLDATE<@date
group by ASLARTICLE


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #StockPrec
select BLLAR,sum(BLLQTE)
from FBLL
where BLLAR=@Article
and BLLDATE<@date
group by BLLAR


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #StockPrec
select DOLAR,sum(DOLQTE)
from FDOL
where DOLAR=@Article
and DOLDATE<@date
group by DOLAR


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #StockPrec
select RFLARTICLE,-sum(RFLQTE)
from FRFL
where RFLARTICLE=@Article
and RFLDATE<@date
group by RFLARTICLE


/* ""Lignes de BE - Fichier FBEL"" */

insert into #StockPrec
select BELARTICLE,-sum(BELQTE)
from FBEL
where BELARTICLE=@Article
and BELDATE<@date
group by BELARTICLE


/* Stock anterieur */

select @anterieur=sum(isnull(QteP,0)) from #StockPrec

/* Evolution sur SIL */

insert into #StockAn
select SILARTICLE,
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-1)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-2)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-3)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-4)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-5)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-6)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-7)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-8)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-9)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-10)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-11)))),
		sum(SILQTE*(1-abs(sign(datepart(mm,SILDATEENTR)-12))))
from FSIL
where SILARTICLE=@Article
and SILDATEENTR between @date and dateadd(mm,12,@date)
group by SILARTICLE

/* Evolution sur RJL */

insert into #StockAn
select RJLARTICLE,
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-1)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-2)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-3)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-4)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-5)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-6)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-7)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-8)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-9)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-10)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-11)))),
		sum(RJLQTE*(1-abs(sign(datepart(mm,RJLDATE)-12))))
from FRJL
where RJLARTICLE=@Article
and RJLDATE between @date and dateadd(mm,12,@date)
group by RJLARTICLE


/* Evolution sur LCL */

insert into #StockAn
select LCLARTICLE,
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-1)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-2)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-3)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-4)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-5)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-6)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-7)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-8)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-9)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-10)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-11)))),
		sum(LCLQTE*(1-abs(sign(datepart(mm,LCLDATE)-12))))
from FLCL
where LCLARTICLE=@Article
and LCLDATE between @date and dateadd(mm,12,@date)
group by LCLARTICLE


/* Evolution sur ASL */

insert into #StockAn
select ASLARTICLE,
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-1)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-2)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-3)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-4)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-5)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-6)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-7)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-8)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-9)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-10)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-11)))),
		sum(ASLQTE*(1-abs(sign(datepart(mm,ASLDATE)-12))))
from FASL
where ASLARTICLE=@Article
and ASLDATE between @date and dateadd(mm,12,@date)
group by ASLARTICLE


/* Evolution sur BLL */

insert into #StockAn
select BLLAR,
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-1)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-2)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-3)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-4)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-5)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-6)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-7)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-8)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-9)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-10)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-11)))),
		sum(BLLQTE*(1-abs(sign(datepart(mm,BLLDATE)-12))))
from FBLL
where BLLAR=@Article
and BLLDATE between @date and dateadd(mm,12,@date)
group by BLLAR


/* Evolution sur DOL */

insert into #StockAn
select DOLAR,
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-1)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-2)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-3)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-4)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-5)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-6)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-7)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-8)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-9)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-10)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-11)))),
		sum(DOLQTE*(1-abs(sign(datepart(mm,DOLDATE)-12))))
from FDOL
where DOLAR=@Article
and DOLDATE between @date and dateadd(mm,12,@date)
group by DOLAR

/* Evolution sur RFL */

insert into #StockAn
select RFLARTICLE,
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-1)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-2)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-3)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-4)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-5)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-6)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-7)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-8)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-9)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-10)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-11)))),
		-sum(RFLQTE*(1-abs(sign(datepart(mm,RFLDATE)-12))))
from FRFL
where RFLARTICLE=@Article
and RFLDATE between @date and dateadd(mm,12,@date)
group by RFLARTICLE

/* Evolution sur BEL */

insert into #StockAn
select BELARTICLE,
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-1)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-2)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-3)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-4)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-5)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-6)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-7)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-8)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-9)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-10)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-11)))),
		-sum(BELQTE*(1-abs(sign(datepart(mm,BELDATE)-12))))
from FBEL
where BELARTICLE=@Article
and BELDATE between @date and dateadd(mm,12,@date)
group by BELARTICLE

/* Totaux par mois */

select @Jan=isnull(sum(Qte1),0),@Fev=isnull(sum(Qte2),0),@Mar=isnull(sum(Qte3),0),
	   @Avr=isnull(sum(Qte4),0),@Mai=isnull(sum(Qte5),0),@Jun=isnull(sum(Qte6),0),
	   @Jul=isnull(sum(Qte7),0),@Aou=isnull(sum(Qte8),0),@Sep=isnull(sum(Qte9),0),
	   @Oct=isnull(sum(Qte10),0),@Nov=isnull(sum(Qte11),0),@Dec=isnull(sum(Qte12),0)
from #StockAn


insert into #Cdes
select CCLARTICLE,
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-1)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-2)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-3)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-4)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-5)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-6)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-7)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-8)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-9)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-10)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-11)))),
		sum(CCLQTE*(1-abs(sign(datepart(mm,CCLDATE)-12))))
from FCCL,FCC
where CCLARTICLE=@Article
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and CCLDATE between @date and dateadd(mm,12,@date)
group by CCLARTICLE



select 	"Stock",Annee=@An,Article=@Article,
		Janvier=@anterieur+@Jan,
		Fevrier=@anterieur+@Jan+@Fev,
		Mars=@anterieur+@Jan+@Fev+@Mar,
		Avril=@anterieur+@Jan+@Fev+@Mar+@Avr,
		Mai=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai,
		Juin=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun,
		Juillet=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun+@Jul,
		Aout=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun+@Jul+@Aou,
		Septembre=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun+@Jul+@Aou+@Sep,
		Octobre=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun+@Jul+@Aou+@Sep+@Oct,
		Novembre=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun+@Jul+@Aou+@Sep+@Oct+@Nov,
		Decembre=@anterieur+@Jan+@Fev+@Mar+@Avr+@Mai+@Jun+@Jul+@Aou+@Sep+@Oct+@Nov+@Dec

union

select 	"Cdes ",Annee=@An,Article=@Article,
		Janvier=Qte1,Fevrier=Qte2,Mars=Qte3,
		Avril=Qte4,Mai=Qte5,Juin=Qte6,
		Juillet=Qte7,Aout=Qte8,Septembre=Qte9,
		Octobre=Qte10,Novembre=Qte11,Decembre=Qte12
from #Cdes


drop table #StockPrec
drop table #StockAn
drop table #Cdes


set nocount off

end



go

