




/* Procedure permettant de recreer le fichier des reste a livrer clients */

create procedure New_FRCC
with recompile
as
begin

	truncate table FRCC
	
	insert into FRCC (RCCSEQ,RCCARTICLE,RCCDATE,RCCMOIS,RCCAN,RCCQTE,RCCCL,RCCECH,RCCFACTMAN,RCCENT,
				RCCQTERES,RCCDATERESFIN,RCCDEPOTRES,RCCQTEPREP,RCCLOT)
	select CCLSEQ,CCLARTICLE,CCLDATE,datepart(mm,CCLDATE),datepart(yy,CCLDATE),
			CCLRESTE,CCLCL,isnull(CCLECHSPE,0),isnull(CCLFACTMAN,0),CCLENT,
			isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,""),isnull(CCLQTEPREP,0),
			isnull(CCLLOT,"")
	from FCCL
	where CCLRESTE > 0
	
end



go

