


create procedure BEVal (@ent			char(5)		= null,
						@date1			datetime 	= null,
						@date2			datetime 	= null,
						@depart			char(8) 	= null,
						@marque			char(12) 	= null,
						@famille		char(8) 	= null,
						@article		char(15) 	= null,
						@typeBE			tinyint 	= 0,
						@stade			tinyint 	= 5,
						@sansretours	tinyint 	= 0,
						@modevalo		tinyint 	= 0,		/* 0 = FIFO, 1 = PRM Global, 2 = PUMP, 3 = PRM Mensuel, 4 = DPA unitaire, 5 = PA unitaire HT	*/
						@client			char(12)	= null,
						@clsa			char(6)		= null
						)
with recompile
as
begin

set arithabort numeric_truncation off

create table #Final
(
BELARTICLE			char(15)		not null,
BELQTE				int				not null,
BELSTADE			tinyint			not null,
BELOFFERT			tinyint			not null,
PrixRevient			numeric(14,4)	not null,
PrixRevientLigne	numeric(14,2)	not null,
BELTOTALHT			numeric(14,2)	not null,
BELDATE				smalldatetime	not null,
BELCODE				char(10)		not null,
BELCL				char(12)		not null,
BELPAHT			numeric(14,2)	not null,
Seq					numeric(14,0)	identity
)



declare @articleBE			char(15),
		@articleprecedent	char(15),
		@qte				int,
		@PrixRevient		numeric(14,4),
		@PrixRevientLigne	numeric(14,2),
		@seq				int,
		@prep				tinyint,
		@trans				tinyint,
		@modif				tinyint,
		@confirme			tinyint,
		@date				smalldatetime,
		@belpaht		numeric(14,2)
		
select  @articleprecedent = ""

if @stade = 0
	select 	@prep = 0,
			@trans = 20,
			@modif = 20,
			@confirme = 20
else if @stade = 1
	select 	@prep = 20,
			@trans = 1,
			@modif = 20,
			@confirme = 20
else if @stade = 2
	select 	@prep = 20,
			@trans = 20,
			@modif = 2,
			@confirme = 20
else if @stade = 3
	select 	@prep = 20,
			@trans = 20,
			@modif = 20,
			@confirme = 3
else if @stade = 4
	select 	@prep = 20,
			@trans = 20,
			@modif = 2,
			@confirme = 3
else if @stade = 5
	select 	@prep = 0,
			@trans = 1,
			@modif = 2,
			@confirme = 3


declare valorisation cursor 
for select BELARTICLE,BELQTE,BELDATE,BELPAHT,Seq
from #Final
order by Seq
for read only


  if @modevalo in (0,1)
	begin
	  select ARFO,BELARTICLE,ARREFFOUR,ARLIB,isnull(BELSTADE,0),isnull(BELOFFERT,0),Qte=sum(BELQTE),
	  PrixRevient=sum(case when @modevalo=0 then ((STPAHT+STFRAIS)/CVLOT)*BELQTE
							 when @modevalo=1 then isnull(ARPRM,0)*BELQTE
							 else ((STPAHT+STFRAIS)/CVLOT)*BELQTE end)/sum(BELQTE),
	  PrixRevientLigne=sum(case when @modevalo=0 then ((STPAHT+STFRAIS)/CVLOT)*BELQTE
							 when @modevalo=1 then isnull(ARPRM,0)*BELQTE
							 else ((STPAHT+STFRAIS)/CVLOT)*BELQTE end),
	  Total_ventes=sum(BELTOTALHT),
	  BELCODE,BELCL
	  from FAR,FSTOCK,FCV,FBEL,FDP,FRBE,FCL
	  where BELARTICLE=STAR
	  and BELLETTRE=STLETTRE
	  and BELCL = CLCODE
	  and RBESEQ=BELSEQ
	  and RBEARTICLE=ARCODE
	  and RBEARTICLE=STAR
	  and ARUNITACHAT=CVUNIF
	  and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	  and (@date1 is null or RBEDATE between @date1 and @date2)
	  and (@depart is null or ARDEPART = @depart)
	  and (@marque is null or ARFO = @marque)
	  and (@famille is null or ARFAM = @famille)
	  and (@article is null or BELARTICLE = @article)
	  and (@client is null or CLCODE = @client)
	  and (@clsa is null or CLSA = @clsa)
	  and RBEDEMO = (case when @typeBE=1 then 0 
						  when @typeBE=2 then 1
					else RBEDEMO end)
	  and isnull(BELOFFERT,0) = (case when (@typeBE=1 or @typeBE=4) then 0 
									  when @typeBE=3 then 1
									  else isnull(BELOFFERT,0) end)
	  and BELTOTALHT = (case when @typeBE=4 then 0 else BELTOTALHT end)
	  and (@typeBE !=1 or BELTOTALHT != 0)
	  and (@sansretours = 0 or BELQTE >= 0)
	  and RBESTADE in (@prep, @trans, @modif,@confirme)
	  group by ARFO,BELARTICLE,ARREFFOUR,ARLIB,BELSTADE,BELOFFERT,BELCODE,BELCL
	  having sum(BELQTE) != 0
	  order by ARFO,BELARTICLE
	end
  else if @modevalo in (2,3,4,5)
	begin
	  insert into #Final (BELARTICLE,BELQTE,BELSTADE,BELOFFERT,PrixRevient,PrixRevientLigne,BELTOTALHT,BELDATE,BELCODE,BELCL,BELPAHT)
	  select BELARTICLE,BELQTE,isnull(BELSTADE,0),isnull(BELOFFERT,0),0,0,BELTOTALHT,dateadd(hh,19,BELDATE),BELCODE,BELCL,isnull(BELPAHT,0)
	  from FAR,FSTOCK,FCV,FBEL,FDP,FRBE,FCL
	  where BELARTICLE=STAR
	  and BELLETTRE=STLETTRE
	  and BELCL = CLCODE
	  and RBESEQ=BELSEQ
	  and RBEARTICLE=ARCODE
	  and RBEARTICLE=STAR
	  and ARUNITACHAT=CVUNIF
	  and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	  and (@date1 is null or RBEDATE between @date1 and @date2)
	  and (@depart is null or ARDEPART = @depart)
	  and (@marque is null or ARFO = @marque)
	  and (@famille is null or ARFAM = @famille)
	  and (@article is null or BELARTICLE = @article)
	  and (@client is null or CLCODE = @client)
	  and (@clsa is null or CLSA = @clsa)
	  and RBEDEMO = (case when @typeBE=1 then 0 
						  when @typeBE=2 then 1
					else RBEDEMO end)
	  and isnull(BELOFFERT,0) = (case when (@typeBE=1 or @typeBE=4) then 0 
									  when @typeBE=3 then 1
									  else isnull(BELOFFERT,0) end)
	  and BELTOTALHT = (case when @typeBE=4 then 0 else BELTOTALHT end)
	  and (@typeBE !=1 or BELTOTALHT != 0)
	  and (@sansretours = 0 or BELQTE >= 0)
	  and RBESTADE in (@prep, @trans, @modif,@confirme)
	  order by BELARTICLE
	  
	  create unique index seq on #Final (Seq)
	  

	  open valorisation
	  
	  fetch valorisation
	  into @article,@qte,@date,@belpaht,@seq
	  
	  while (@@sqlstatus = 0)
		  begin  
		  
		if @articleprecedent != @article
		begin
		  select @PrixRevient = 0,
				 @PrixRevientLigne = 0
		  
		  if @modevalo = 2									/*--------------------- PUMP */
		  begin
			select @PrixRevient=isnull(PUMP,0)
			from FPUM
			where PUMAR = @article
			and PUMDATE <= convert (smalldatetime, @date)
			having PUMAR = @article
			and PUMDATE <= convert (smalldatetime, @date)
			and PUMDATE = max(PUMDATE)
			
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end
		  else if @modevalo = 3								/*--------------------- PRM Mensuel */
		  begin
			set rowcount 1
			
			select @PrixRevient=isnull(PRM,0)
			from FPRM
			where PRMAR = @article
			and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			and PRMAR = @article
			order by PRMAN desc,PRMMOIS desc
			
			set rowcount 0
			
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
		  end
		  else  if @modevalo = 4								/*--------------------- DPA unitaire */
		  begin
			set rowcount 1
		  
			select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			from FBLL,FCV
			where BLLAR=@article
			and CVUNIF=BLLUA
			having BLLAR=@article
			and CVUNIF=BLLUA
			and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		  
			if isnull(@PrixRevient,0)=0
			begin
			  select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
			  from FSIL,FAR,FCV
			  where SILARTICLE=@article
			  and ARCODE = SILARTICLE
			  and ARUNITACHAT = CVUNIF
			  having SILARTICLE=@article
			  and ARCODE = SILARTICLE
			  and ARUNITACHAT = CVUNIF
			  and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			end
			
			set rowcount 0
					
			if @PrixRevient is null
			  select @PrixRevient = 0
  
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end
		  else  if @modevalo = 5									/*--------------------- PA Unitaire HT */   
			begin
			select @PrixRevient = @belpaht   
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end   

		end
		else if @articleprecedent = @article
		begin
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		end


		  update #Final set PrixRevient = @PrixRevient, PrixRevientLigne = @PrixRevientLigne
		  where Seq = @seq
	  
		  select  @articleprecedent = @article
		  
		  fetch valorisation
		  into @article,@qte,@date,@belpaht,@seq
		  
	  end

	  close valorisation
	  deallocate cursor valorisation
  
	  select ARFO,BELARTICLE,ARREFFOUR,ARLIB,BELSTADE,BELOFFERT,sum(BELQTE),PrixRevient,sum(PrixRevientLigne),sum(BELTOTALHT),BELCODE,BELCL
	  from #Final,FAR
	  where BELARTICLE=ARCODE
	  group by ARFO,BELARTICLE,ARREFFOUR,ARLIB,BELSTADE,BELOFFERT,PrixRevient,BELCODE,BELCL
	  order by ARFO,BELARTICLE
	  
	  drop table #Final
	end
end	
go

