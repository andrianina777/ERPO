/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheCC_Traite
grant execute on bp_afficheCC_Traite to public
*/

CREATE PROCEDURE dbo.bp_afficheCC_Traite(@code char(10),@client char(12))
with recompile
AS
begin
	declare @x_code char(10),@total numeric(18,3) 

	create table #tmp (
		m_code char(10) null,
		m_date smalldatetime null,
		m_traite char(10) null,
		m_ok int null
	)
	
	create table #results (
		t_code char(10) ,
		t_total numeric(18,3) null
	)
	if(select count(*) from FTRAITEL where TRL_CODE=@code)>0
		begin
		insert into #tmp select rtrim(CCCODE),CCDATECOM,CC_TRAITE,1 from FCC inner join FCC2 on CC2CODE=CCCODE inner join FTR on TRCODE=CC2MODREG where CC_TRAITE=@code and CCDATECOM>'2018/01/01' and CCCLIENT=@client and TRMODE=5
		end
	else
		begin
		insert into #tmp select rtrim(CCCODE),CCDATECOM,isnull(CC_TRAITE,''),case when isnull(CC_TRAITE,'')<>'' then 1 else 0 end from FCC left join FTRAITE on TRAITE_CODE=CC_TRAITE 
	    where CCDATE_6 is null and CCDATECOM>'2018/01/01' and CCCLIENT=@client and CCSTADE_DET>2
	    end
    
    declare liste cursor for  select m_code from #tmp  where m_traite=@code or isnull(m_traite,'')='' order by m_code
	open liste						 
	fetch liste into @x_code
	
	while(@@sqlstatus=0)
		begin
			select @total=0

			select @total=isnull(sum (isnull(CCLTOTALHT,0)*(1+(isnull(TVLTAUXTVA,0)/100))),0) from FCCL inner join FTVL on TVLCODE=CCLTV 
			inner join FCL on (CLCODE=CCLCL and rtrim(CLCLASSE)=rtrim(TVLCLASSE))
			where  CCLCODE=@x_code 
			
			insert into #results values (@x_code,@total)
			
			
			fetch liste into @x_code  
		end			
   close liste
   deallocate cursor liste
    
    
    --select m_code,m_date,t_total,m_ok from #tmp  inner join #FCCL on t_code=m_code where m_traite=@code or isnull(m_traite,'')='' order by m_code
    select m_code,m_date,t_total,m_ok from #tmp  inner join #results on t_code=m_code   where m_traite=@code or isnull(m_traite,'')='' order by m_code

    drop table #tmp
    drop table #results 

end
go

