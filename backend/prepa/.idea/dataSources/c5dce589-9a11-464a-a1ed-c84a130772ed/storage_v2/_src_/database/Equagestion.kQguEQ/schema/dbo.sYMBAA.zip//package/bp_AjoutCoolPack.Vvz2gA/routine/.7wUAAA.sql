/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_AjoutCoolPack

*/

CREATE PROCEDURE bp_AjoutCoolPack(@xSeq int)
with recompile
AS
begin
	 declare @article char(15),
	 		 @qte int,
	 		 @xtype char(4),
	 		 @Qte_f	int,	 
 	 		 @Qte_m int
 	 		 
 	 create table #xpCrm_froid(
                ARTICLE char(15),
                QUANTITE int,
                type char(4)
      )
     if(select count(*) from diera.xpCrmCCL where xArticle='COOLP' and xCCSeq=@xSeq)=0
     begin
     	insert into #xpCrm_froid select xArticle,xQte,xTypeVente from diera.xpCrmCCL inner join xFARTYPE on xARTP_ARCODE=xArticle where xARTP_FROID=1 and xCCSeq=@xSeq
	
	     declare liste cursor for select ARTICLE,QUANTITE,type from #xpCrm_froid
	     open liste						 
		 fetch liste into @article,@qte, @xtype
		 select @Qte_f=0
		 while(@@sqlstatus=0)
			begin
			
				select @Qte_m=0
				
				select @Qte_m=isnull(CPQNBR,0) from wp_CPQ where CPQ_ARCODE = @article and ((CPQQTEMIN <= @qte and CPQQTEMAX >=@qte) or (CPQQTEMIN <=@qte and CPQQTEMAX = 0))
				select @Qte_f=@Qte_f+@Qte_m
				
				fetch liste into @article,@qte, @xtype
			end		
			
			insert into diera.xpCrmCCL(xCCSeq,xArticle,xQte,xTypeVente) values (@xSeq,'COOLP',@Qte_f,@xtype)
			
			close liste
			deallocate cursor liste
			
			
	end	
	drop table #xpCrm_froid
end
go

