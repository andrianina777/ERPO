




create procedure New_FSTCC	(@an	smallint,
							 @mois	tinyint)
with recompile
as
begin
		
declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@date1			datetime,
		@date2			datetime,
		@result			int

if @mois=1
	begin
		select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'01/31/'+convert(varchar(4),@an))
	end
else if @mois=2
	begin
		select @smalldate1=convert(smalldatetime,'02/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		select @smalldate2=dateadd(dd,-1,@smalldate2)
	end
else if @mois=3
	begin
		select @smalldate1=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'03/31/'+convert(varchar(4),@an))
	end
else if @mois=4
	begin
		select @smalldate1=convert(smalldatetime,'04/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'04/30/'+convert(varchar(4),@an))
	end
else if @mois=5
	begin
		select @smalldate1=convert(smalldatetime,'05/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'05/31/'+convert(varchar(4),@an))
	end
else if @mois=6
	begin
		select @smalldate1=convert(smalldatetime,'06/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'06/30/'+convert(varchar(4),@an))
	end
else if @mois=7
	begin
		select @smalldate1=convert(smalldatetime,'07/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'07/31/'+convert(varchar(4),@an))
	end
else if @mois=8
	begin
		select @smalldate1=convert(smalldatetime,'08/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'08/31/'+convert(varchar(4),@an))
	end
else if @mois=9
	begin
		select @smalldate1=convert(smalldatetime,'09/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'09/30/'+convert(varchar(4),@an))
	end
else if @mois=10
	begin
		select @smalldate1=convert(smalldatetime,'10/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'10/31/'+convert(varchar(4),@an))
	end
else if @mois=11
	begin
		select @smalldate1=convert(smalldatetime,'11/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'11/30/'+convert(varchar(4),@an))
	end
else if @mois=12
	begin
		select @smalldate1=convert(smalldatetime,'12/01/'+convert(varchar(4),@an))
		select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))
	end
		
		
select 	@date1=convert(datetime,@smalldate1),
		@date2=convert(datetime,@smalldate2)

execute @result = New_FSTCC_ @smalldate1,@smalldate2

return (@result)

end



go

