


/* Procedure calculant la valeur du stock de janvier au mois donne pour l''annee choisie
	a partir des lignes de mouvement de stock */


create procedure StockMarque(@an	int,
							 @mois	int)
with recompile
as
begin

set arithabort numeric_truncation off


if @mois<1 select @mois=1
if @mois>12 select @mois=12


create table #Stock
(
marque		char(12)		not null,
famille		char(8)			not null,
valstock	numeric(14,2)	not null,
valventes	numeric(14,2)	not null,
valachat	numeric(14,2)	not null
)


insert into #Stock (marque,famille,valstock,valventes,valachat)
select ARFO,ARFAM,sum(isnull(MOISTOTPR,0)),0,0
from FMOIS,FAR
where ARCODE=MOISARTICLE
and MOISANNEE=@an-1
and MOISMOIS=12
and MOISQTE != 0
group by ARFO,ARFAM

insert into #Stock (marque,famille,valstock,valventes,valachat)
select ARFO,ARFAM,sum(isnull(MSTOTPR,0)),0,0
from FMS,FAR
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE in ("E","F","R","C","A","M")
and MSQTE != 0
group by ARFO,ARFAM

insert into #Stock (marque,famille,valstock,valventes,valachat)
select ARFO,ARFAM,-sum(isnull(MSTOTPR,0)),0,0
from FMS,FAR
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE="S"
and MSQTE != 0
group by ARFO,ARFAM

insert into #Stock (marque,famille,valstock,valventes,valachat)
select ARFO,ARFAM,0,sum(isnull(STCAFA,0)),0
from FST,FAR
where ARCODE=START
and STAN=@an
and STMOIS between 1 and @mois
and STQTEFA != 0
group by ARFO,ARFAM


insert into #Stock (marque,famille,valstock,valventes,valachat)
select SFFO,SFFAM,0,0,sum(isnull(SFCABL,0))
from FSF
where SFAN=@an
and SFMOIS between 1 and @mois
and SFQTEBL != 0
group by SFFO,SFFAM


select marque,famille,sum(valstock),sum(valventes),sum(valachat)
from #Stock
group by marque,famille
order by marque,famille

drop table #Stock

end



go

