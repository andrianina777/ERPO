


create procedure BTransp(@ent		char(5)	= null,
						 @LeTransp 	tinyint,
						 @transp1	char(8) = null,
						 @transp2	char(8) = null,
						 @NumDebut	char(10) = null,
						 @NumFin	char(10) = null,
						 @datedebut	smalldatetime = null,
						 @datefin	smalldatetime = null)
with recompile
as
begin

	select EXTRANSP,EXCL,EXNOM,EXADR1,EXADR2,EXCP,EXVILLE,EXPAYS,
	EXAPAYER,EXOBS,EXTOTCOLIS,EXTOTPOIDS,EXRECOM,EXTOTALTR
	from FEX
	where ((@NumDebut is null) or (EXCODE between @NumDebut and @NumFin))
	and ((@LeTransp=0) or (EXTRANSP between @transp1 and @transp2))
	and ((@datedebut is null) or (EXDATE between @datedebut and @datefin))
	and (@ent is null or EXENT=@ent)
	order by EXTRANSP,EXCL
	
end



go

