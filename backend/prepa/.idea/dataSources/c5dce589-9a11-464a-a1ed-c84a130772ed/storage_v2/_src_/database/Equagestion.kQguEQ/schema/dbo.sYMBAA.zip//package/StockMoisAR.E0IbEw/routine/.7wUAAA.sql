


/* Procedure utilisee pour l''enregistrement des mouvements de stock
	pour un mois et une annee donnes sur un article donne */

create procedure StockMoisAR (@Mois			tinyint,
							  @Annee		smallint,
							  @article		char(15)
							  )
with recompile
as
begin

set arithabort numeric_truncation off


delete FMOIS
where MOISMOIS=@Mois
and MOISANNEE=@Annee
and MOISARTICLE=@article

declare @MoisPrecedent	tinyint
declare @AnneeInit		smallint
declare @count			int
declare @date			datetime
declare @utilisateur	int

select @date=getdate()
select @utilisateur=user_id()


select @MoisPrecedent=12
select @AnneeInit=@Annee-1

	
/* Information articles stockes le mois de Decembre de l''annee precedente dans FMOIS */


select ArticleInit=MOISARTICLE,QuantiteInit=MOISQTE,
CoutInit=MOISTOTPR,DepotInit=MOISDEPOT
into #Init
from FMOIS
where MOISANNEE=@AnneeInit
and MOISMOIS=@MoisPrecedent
and MOISQTE != 0
and MOISARTICLE=@article

create clustered index ardep on #Init(ArticleInit,DepotInit)


/* Calcul des valeurs entrees pendant la periode demandee (depuis FMS) */


select ArticleIn=MSARTICLE,
QuantiteIn=sum(MSQTE),CoutIn=sum(MSTOTPR),DepotIn=MSDEPOT
into #Entree
from FMS
where MSANNEE=@Annee
and MSMOIS between 1 and @Mois
and MSQTE != 0
and MSTYPE='E'
and MSARTICLE=@article
group by MSARTICLE,MSDEPOT

create clustered index ardep on #Entree(ArticleIn,DepotIn)

/* Calcul des valeurs reajustees pendant la periode demandee (depuis FMS) */

select ArticleReajust=MSARTICLE,
QuantiteReajust=sum(MSQTE),CoutReajust=sum(MSTOTPR),DepotReajust=MSDEPOT
into #Reajust
from FMS
where MSANNEE=@Annee
and MSMOIS between 1 and @Mois
and MSQTE != 0
and MSTYPE in ('F','R','A','C','M')
and MSARTICLE=@article
group by MSARTICLE,MSDEPOT

create clustered index ardep on #Reajust(ArticleReajust,DepotReajust)

/* Calcul des valeurs sorties pendant la periode demandee (depuis FMS) */

select ArticleOut=MSARTICLE,
QuantiteOut=sum(MSQTE),CoutOut=sum(MSTOTPR),DepotOut=MSDEPOT
into #Sortie
from FMS
where MSANNEE=@Annee
and MSMOIS between 1 and @Mois
and MSQTE != 0
and MSTYPE='S'
and MSARTICLE=@article
group by MSARTICLE,MSDEPOT

create clustered index ardep on #Sortie(ArticleOut,DepotOut)


/* Creation du fichier final avec insertion des articles de #Init et de #Reajust */

select Article=ArticleInit,
QteInit=isnull(QuantiteInit,0),ValeurInit=isnull(CoutInit,0),
QteRJ=0,ValeurRJ=convert(numeric(14,2),0),
QteIn=0,ValeurIn=convert(numeric(14,2),0),
QteOut=0,ValeurOut=convert(numeric(14,2),0),
QteFinale=0,ValeurFinale=convert(numeric(14,2),0),
Depot=DepotInit
into #Final
from #Init

drop table #Init

create clustered index ardep on #Final(Article,Depot)

/* Insertion dans #Final des articles entres sans correpondance dans #Final */

insert into #Final
select ArticleIn,0,0,0,0,0,0,0,0,0,0,DepotIn
from #Entree
where not exists (select * from #Final 
				  where Article=#Entree.ArticleIn
				  and Depot=#Entree.DepotIn)


/* Mise a jour de #Final avec les valeurs de #Entree */

update #Final
set QteIn=isnull(QuantiteIn,0),ValeurIn=isnull(CoutIn,0)
from #Entree
where Article=ArticleIn
and Depot=DepotIn

drop table #Entree

/* Insertion dans #Final des articles reajustes sans correspondance dans #Final */

insert into #Final
select ArticleReajust,0,0,0,0,0,0,0,0,0,0,DepotReajust
from #Reajust
where not exists (select * from #Final 
				  where Article=#Reajust.ArticleReajust
				  and Depot=#Reajust.DepotReajust)

/* Mise a jour de #Final avec les valeurs de #Reajust */

update #Final
set QteRJ=isnull(QuantiteReajust,0),ValeurRJ=isnull(CoutReajust,0)
from #Reajust
where Article=ArticleReajust
and Depot=DepotReajust

drop table #Reajust


/* Insertion dans #Final des articles sortis sans correspondance dans #Final */

insert into #Final
select ArticleOut,0,0,0,0,0,0,0,0,0,0,DepotOut
from #Sortie
where not exists (select * from #Final 
				  where Article=#Sortie.ArticleOut
				  and Depot=#Sortie.DepotOut)

/* Mise a jour de #Final avec les valeurs de #Sortie */

update #Final
set QteOut=isnull(QuantiteOut,0),ValeurOut=isnull(CoutOut,0)
from #Sortie
where Article=ArticleOut
and Depot=DepotOut

drop table #Sortie


/* Mise a jour des valeurs finales de #Final */


select Article=Article,QteInit=isnull(sum(QteInit),0),ValeurInit=isnull(sum(ValeurInit),0),
	QteRJ=isnull(sum(QteRJ),0),ValeurRJ=isnull(sum(ValeurRJ),0),
	QteIn=isnull(sum(QteIn),0),ValeurIn=isnull(sum(ValeurIn),0),
	QteOut=isnull(sum(QteOut),0),ValeurOut=isnull(sum(ValeurOut),0),
	QteFinale=sum(isnull(QteInit,0)+isnull(QteRJ,0)+isnull(QteIn,0)-isnull(QteOut,0)),
	ValeurFinale=convert(numeric(14,2),0),Depot
into #Final2
from #Final
group by Article,Depot

drop table #Final

update #Final2
set ValeurInit=0
where QteInit=0

update #Final2
set ValeurFinale=isnull(ValeurInit,0)+isnull(ValeurRJ,0)+isnull(ValeurIn,0)-isnull(ValeurOut,0)
where QteFinale != 0

select @count=count(*) from #Final2

if @count>0
  begin
  	insert into FMOIS(MOISARTICLE,MOISANNEE,MOISMOIS,MOISQTE,MOISTOTPR,MOISDEPOT,MOISDATE,MOISUSERID)
	select Article,@Annee,@Mois,
	QteFinale,ValeurFinale,Depot,
	@date,@utilisateur
	from #Final2
  end
  
drop table #Final2
 
end



go

