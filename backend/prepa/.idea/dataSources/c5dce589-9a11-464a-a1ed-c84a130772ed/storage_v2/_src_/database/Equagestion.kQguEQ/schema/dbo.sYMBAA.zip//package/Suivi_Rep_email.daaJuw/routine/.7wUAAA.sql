



create procedure Suivi_Rep_email (@ent		char(5)	= null,
								  @rep		char(8) = null,
								  @marque	char(12) = null
								 )
with recompile
as
begin

set arithabort numeric_truncation off

declare @labase		varchar(30),
		@lignes		int,
		@an			smallint,
		@mois		tinyint
		
select  @labase = db_name()
select 	@lignes = 0
select	@an = datepart(yy,getdate())
select	@mois = datepart(mm,getdate())


dump tran @labase with truncate_only

create table #Finale
(
seq			numeric(14,0)	identity,
rep			char(8)			not null,
marque		char(12)		not null,
CA_annee_1	numeric(14,2)		null,
CA_annee	numeric(14,2)		null,
BE_encours	numeric(14,2)		null,
CC_encours	numeric(14,2)		null
)

declare @type	tinyint
select  @type=RETYPE from FREP where RECODE=@rep

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos

if @type != 2
begin
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select CLREP,ARFO,
		  isnull(sum(case	when STAN=@an-1 then STCAFA else 0 end),0),
		  isnull(sum(case	when STAN=@an then STCAFA else 0 end),0),0,0
  from FST,FAR,FCL
  where START=ARCODE
  and STAN between @an-1 and @an
  and STMOIS between 1 and @mois
  and ARCODE=START
  and CLCODE=STCL
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (STENT=@ent and CLENT=STENT))
  group by CLREP,ARFO
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLREP,ARFO,0,0,isnull(sum(BELTOTALHT),0),0
  from FRBE,FBEL,FAR,FCL
  where BELSEQ=RBESEQ
  and CLCODE=RBECL
  and ARCODE=RBEARTICLE
  and RBEDEMO=0
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RBEENT=@ent and BELENT=RBEENT and CLENT=RBEENT))
  group by CLREP,ARFO
  
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLREP,ARFO,0,0,0,isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0)
  from FRCC,FCCL,FAR,FCL,FCC
  where CCLSEQ=RCCSEQ
  and CLCODE=RCCCL
  and ARCODE=RCCARTICLE
  and CCCODE=CCLCODE
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CLENT=RCCENT and CCENT=RCCENT))
  group by CLREP,ARFO
end
else if @type = 2
begin
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select CLRREPDIV,ARFO,
		  isnull(sum(case	when STAN=@an-1 then STCAFA else 0 end),0),
		  isnull(sum(case	when STAN=@an then STCAFA else 0 end),0),0,0
  from FST,FAR,FCL,FCLR
  where START=ARCODE
  and STAN between @an-1 and @an
  and STMOIS between 1 and @mois
  and ARCODE=START
  and CLCODE=STCL
  and CLRCL=CLCODE
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (STENT=@ent and CLENT=STENT))
  group by CLRREPDIV,ARFO
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLRREPDIV,ARFO,0,0,isnull(sum(BELTOTALHT),0),0
  from FRBE,FBEL,FAR,FCL,FCLR
  where BELSEQ=RBESEQ
  and CLCODE=RBECL
  and ARCODE=RBEARTICLE
  and RBEDEMO=0
  and CLRCL=CLCODE
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RBEENT=@ent and BELENT=RBEENT and CLENT=RBEENT))
  group by CLRREPDIV,ARFO
  
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLRREPDIV,ARFO,0,0,0,isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0)
  from FRCC,FCCL,FAR,FCL,FCC,FCLR
  where CCLSEQ=RCCSEQ
  and CLCODE=RCCCL
  and ARCODE=RCCARTICLE
  and CCCODE=CCLCODE
  and CLRCL=CLCODE
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CLENT=RCCENT and CCENT=RCCENT))
  group by CLRREPDIV,ARFO
end





declare @vrp	char(8),
		@mark	char(12),
		@an_1	numeric(15,0),
		@an_0	numeric(15,0),
		@dif	numeric(15,0),
		@be		numeric(15,0),
		@cc		numeric(15,0),
		@texte	varchar(20),
		@text1	char(8),
		@text2	char(8),
		@text3	char(9),
		@text4	char(9),
		@text5	char(9),
		@text6	char(9),
		@text7	char(9)

select  @text1 = "VRP"
select  @text2 = "Marque"
select  @texte = "CA " + convert(varchar,@an - 1)
select  @text3 = right("           " + @texte,9)
select  @texte = "CA "+ convert(varchar,@an)
select  @text4 = right("           " + @texte,9)
select  @texte = "Diff"
select  @text5 = right("           " + @texte,9)
select  @texte = "BE"
select  @text6 = right("           " + @texte,9)
select  @texte = "Cdes_CL"
select  @text7 = right("           " + @texte,9)

print "%1! %2! %3! %4! %5! %6! %7!",@text1,@text2,@text3,@text4,@text5,@text6,@text7

declare suivi cursor
for
select 	rep,marque,
		convert(numeric(15,0),isnull(sum(CA_annee_1),0)),
		convert(numeric(15,0),isnull(sum(CA_annee),0)),
		convert(numeric(15,0),isnull(sum(CA_annee),0)) - convert(numeric(15,0),isnull(sum(CA_annee_1),0)),
		convert(numeric(15,0),isnull(sum(BE_encours),0)),
		convert(numeric(15,0),isnull(sum(CC_encours),0))
from #Finale
group by rep,marque
having 	convert(numeric(15,0),isnull(sum(CA_annee_1),0)) != 0 or
		convert(numeric(15,0),isnull(sum(CA_annee),0)) != 0 or
		convert(numeric(15,0),isnull(sum(BE_encours),0)) != 0 or
		convert(numeric(15,0),isnull(sum(CC_encours),0)) != 0
order by rep,marque
for read only

open suivi

fetch suivi into @vrp,@mark,@an_1,@an_0,@dif,@be,@cc

while (@@sqlstatus = 0)
  begin
  
  
  select  @text1 = @vrp
  select  @text2 = @mark
  select  @texte = convert(char(9),@an_1)
  select  @text3 = right("           " + @texte,9)
  select  @texte = convert(char(9),@an_0)
  select  @text4 = right("           " + @texte,9)
  select  @texte = convert(char(9),@dif)
  select  @text5 = right("           " + @texte,9)
  select  @texte = convert(char(9),@be)
  select  @text6 = right("           " + @texte,9)
  select  @texte = convert(char(9),@cc)
  select  @text7 = right("           " + @texte,9)
  
  print "%1! %2! %3! %4! %5! %6! %7!",@text1,@text2,@text3,@text4,@text5,@text6,@text7

  fetch suivi into @vrp,@mark,@an_1,@an_0,@dif,@be,@cc
  
  end
  
close suivi
deallocate cursor suivi

drop table #Finale


end



go

