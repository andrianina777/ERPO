


create procedure StockNul
with recompile
as
begin

	select CodeArticle=STAR,Designation=ARLIB,StockTotal=sum(STQTE) 
	into #Stock
	from FSTOCK,FAR
	where ARCODE=STAR
	group by STAR
	having ARCODE=STAR


	delete from #Stock where StockTotal>0


	select CodeArticle,Designation,StockTotal
	from #Stock
	order by CodeArticle
	
end



go

