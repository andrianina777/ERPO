CREATE PROCEDURE dbo.TotalFactMulti (	@ent		char(5) = null,
									@code 		char(10),
						   		 	@date		datetime,
									@tr1		char(20),
									@tr2		char(20),
									@tr3		char(20),
									@tr4		char(20),
									@pc1		real,
									@pc2		real,
									@pc3		real,
									@pc4		real,
									@datefixe1	smalldatetime,
									@datefixe2	smalldatetime,
									@datefixe3	smalldatetime,
									@datefixe4	smalldatetime
									)
with recompile
as
begin

/* Modification le 04-01-08 par SP : suite ajout notion preference traitement escompte au niveau du BE : on recupere FATAUXESC et non pas CLTAUXESC */
/* pm : FATAUXESC a la val de BEESCOMPTE si VPREFESCOMPTE=1 sinon il a la val de CLESCOMPTE (voir code dans EFactAuto)*/


set arithabort numeric_truncation off


 /* Lignes facturees a totaliser */
 
 declare @client		char(12)
 declare @modereg		tinyint
 declare @exo			tinyint			/* variable indiquant si le client est exonere de TVA */
 declare @TauxEscompte	real			/* % de l'escompte de la facture */
 declare @clfact		char(12)
 declare @trmono		char(20)

select @exo=CLSANSTVA
from FCL,FFA
where CLCODE=FACL
and FACODE=@code
and (@ent is null or (CLENT=@ent and FAENT=@ent))

select @trmono=CLMODEREG, @TauxEscompte=FATAUXESC, @clfact=FACLFACT
from FCL,FFA
where CLCODE=FACLFACT
and FACODE=@code
and (@ent is null or (CLENT=@ent and FAENT=@ent))

select @modereg=TRMODE from FTR where TRCODE=@trmono

if isnull(@tr1,'')=''
  begin
	select @tr1 = @trmono,
		   @pc1 = 100
  end

if @TauxEscompte is null
	select @TauxEscompte=0
	
	
/* Test de verification de type de reglement a echeance fixe */

declare @typeech		tinyint,
		@trdate1		smalldatetime,
		@nbrjours		int,
		@depasse		int
select 	@typeech=TRTYPEECH from FTR where TRCODE=@tr1
select 	@depasse=0

if @typeech=3
begin
	select @trdate1=FATRDATE1 from FFA where FACODE=@code
	select @nbrjours=PPASSAGETRCL from KParam
	
	if datediff(dd,getdate(),@trdate1) <= @nbrjours
		select @depasse=1,
			   @tr1 = @trmono, @pc1 = 100, @datefixe1 = null,
			   @tr2 = '', @pc2 = 0, @datefixe2 = null,
			   @tr3 = '', @pc3 = 0, @datefixe3 = null,
			   @tr4 = '', @pc4 = 0, @datefixe4 = null
end



create table #Lignes
(
FALTOTALHT		numeric(14,2)	null,
TAUXTVA			real			null,
TVSANSESC		tinyint			null,
CPTETVA			char(12)		null,
MTESCOMPTE		numeric(14,2)	null
)

	insert into #Lignes
	select FALTOTALHT,TVLTAUXTVA,TVSANSESC,TVLCOMPTETVA,
		MTESCOMPTE=round(FALTOTALHT*@TauxEscompte*(1-TVSANSESC),2)
	from FFAL, FCL, FTV, FTVL
	where FALCODE=@code and CLCODE=@clfact
	and TVCODE=TVLCODE and TVLCLASSE=CLCLASSE and TVLCODE=FALTYPEVE
	and (@ent is null or (FALENT=@ent and CLENT=@ent and TVLENT=@ent))

	
 /* faire tous les calculs avec	(FALTOTALHT-MTESCOMPTE) */
 
 	select CPTETVA,TAUXTVA,TotalLigneHT=round(sum(FALTOTALHT-MTESCOMPTE),2),
			Taxe=round(sum(FALTOTALHT-MTESCOMPTE)*(TAUXTVA/100),2)
	into #Taxes
	from #Lignes
	group by CPTETVA,TAUXTVA
	
	
	select TAUXTVA,TotalHT=round(sum(TotalLigneHT),2),
			TotalTaxe=round(sum(Taxe),2),TypeTaxe=0
	into #LesTaxes
	from #Taxes
	group by TAUXTVA
	
	
 /* Mise en place des taux de TVA des differents articles */
	
	declare @taux		real			/* rubrique de test du taux de TVA */
	declare @basetaxe1	numeric(14,2)	/* base taxee de la TVA 1 */
	declare @basetaxe2	numeric(14,2)	/* base taxee de la TVA 2 */
	declare @basetaxe3	numeric(14,2)	/* base taxee de la TVA 3 */
	declare @tauxtaxe1	real			/* taux de la taxe 1 */
	declare @tauxtaxe2	real			/* taux de la taxe 2 */
	declare @tauxtaxe3	real			/* taux de la taxe 3 */
	declare @typetaxe1	char(10)		/* nom de la taxe 1 */
	declare @typetaxe2	char(10)		/* nom de la taxe 2 */
	declare @typetaxe3	char(10)		/* nom de la taxe 3 */
	declare @maxtot		numeric(14,2)	/* variable de test */
	declare @num		tinyint			/* rubrique de numerotation des taxes */
	select @num=0
	
	select @taux=max(TAUXTVA)
	from #LesTaxes
	
	while @taux is not null
		begin	
			select @num=@num+1
			update #LesTaxes set TypeTaxe=@num where TAUXTVA=@taux
			if @num=1
				begin
					select @tauxtaxe1=@taux
					select @typetaxe1='TVA 1'
				end
			if @num=2
				begin
					select @tauxtaxe2=@taux
					select @typetaxe2='TVA 2'
				end
			if @num=3
				begin
					select @tauxtaxe3=@taux
					select @typetaxe3='Autres'
				end
			
			select @taux=max(TAUXTVA)
			from #LesTaxes
			where TAUXTVA<@taux
		end
		
		if @tauxtaxe1 is null
		select @tauxtaxe1=0
		
		if @tauxtaxe2 is null
		select @tauxtaxe2=0
		
		if @tauxtaxe3 is null
		select @tauxtaxe3=0
		
		if @typetaxe1 is null
		select @typetaxe1=''
		
		if @typetaxe2 is null
		select @typetaxe2=''
		
		if @typetaxe3 is null
		select @typetaxe3=''
	
 /* Calculs des totaux escomptables et non escomptables */	
	
	declare @TotEsc numeric(14,2)				/* total escomptable */
	declare @TotNonEsc numeric(14,2)			/* total non escomptable */
	select @TotEsc=round(sum(FALTOTALHT),2)
	from #Lignes
	where TVSANSESC=0
	
	if @TotEsc is null
		select @TotEsc=0
	
	select @TotNonEsc=round(sum(FALTOTALHT),2)
	from #Lignes
	where TVSANSESC=1
	
	if @TotNonEsc is null
		select @TotNonEsc=0
	
 /* Calcul et repartition des taxes */	
	
	
	declare @taxe1		numeric(14,2)			/* total de la taxe 1 */
	declare @taxe2		numeric(14,2)			/* total de la taxe 2 */
	declare @taxe3		numeric(14,2)			/* total de la taxe 3 */
	declare @totalht	numeric(14,2)			/* total HT */
	declare @netapayer	numeric(14,2)			/* net a payer */
	declare @escompte	numeric(14,2)			/* total escompte */
	declare @sanstva	tinyint
	select  @sanstva=0
	
	
	if @exo=1
	  begin
			select @sanstva=1
			select @tauxtaxe1=0
			select @tauxtaxe2=0
			select @tauxtaxe3=0
			select @basetaxe1=0
			select @basetaxe2=0
			select @basetaxe3=0
			select @taxe1=0
			select @taxe2=0
			select @taxe3=0
			select @escompte=round(sum(MTESCOMPTE),2) from #Lignes
			select @totalht=round(sum(TotalHT),2) from #LesTaxes
			select @netapayer=@totalht
			select @typetaxe1='Exoneree'
			select @typetaxe2=''
			select @typetaxe3=''
			
	  end
	else
	  begin
	
		  select @sanstva=0
		  
		  select @basetaxe1=TotalHT,@taxe1=TotalTaxe
		  from #LesTaxes
		  where TypeTaxe=1
		  
		  
		  select @basetaxe2=TotalHT,@taxe2=TotalTaxe
		  from #LesTaxes
		  where TypeTaxe=2
		  
		  
		  select @basetaxe3=round(sum(TotalHT),2),@taxe3=round(sum(TotalTaxe),2)
		  from #LesTaxes
		  where TypeTaxe>2
		  
		  select @escompte=round(sum(MTESCOMPTE),2) from #Lignes
		  select @totalht=isnull(@basetaxe1,0)+isnull(@basetaxe2,0)+isnull(@basetaxe3,0)
		  select @netapayer=@totalht+isnull(@taxe1,0)+isnull(@taxe2,0)+isnull(@taxe3,0)
		  
		  
	  end
	
 /* Calcul des echeances */	
	
	declare @date1		datetime			/* date de reglement de l'echeance nÂ° 1 */
	declare @regle1		numeric(14,2)		/* total a regler pour l'echeance nÂ° 1 */
	declare @date2		datetime			/* date de reglement de l'echeance nÂ° 2 */
	declare @regle2		numeric(14,2)		/* total a regler pour l'echeance nÂ° 2 */
	declare @date3		datetime			/* date de reglement de l'echeance nÂ° 3 */
	declare @regle3		numeric(14,2)		/* total a regler pour l'echeance nÂ° 3 */
	declare @date4		datetime			/* date de reglement de l'echeance nÂ° 4 */
	declare @regle4		numeric(14,2)		/* total a regler pour l'echeance nÂ° 4 */
	declare @modereg1	tinyint				/* mode de reglement echeance 1 */
	declare @modereg2	tinyint				/* mode de reglement echeance 2 */
	declare @modereg3	tinyint				/* mode de reglement echeance 3 */
	declare @modereg4	tinyint				/* mode de reglement echeance 4 */
	declare @trdec		int					/* jours de decalage de l'echeance */
	declare @trtypeech	tinyint				/* type d'echeance */
	declare @trjourech	tinyint				/* jour de l'echeance */
	declare @trdate		datetime			/* date calculee de l'echeance */
 	declare @nombre		int					/* variable pour decalage en mois entiers */
	
	select @trdec=TRDEC,@trtypeech=TRTYPEECH,@trjourech=TRJOURECH,@modereg1=TRMODE
	from FTR
	where TRCODE=@tr1
	
	select @nombre = @trdec
	exec modulo @nombre output,30
	
	if @trtypeech=0
		begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
									+'/1/'+convert(char(4),datepart(yy,@trdate)))
			select @trdate=dateadd(dy,-1,@trdate)
		end
		
	if @trtypeech=1
		begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
				+'/'+convert(char(2),@trjourech)+'/'+convert(char(4),datepart(yy,@trdate)))
		end
		
	if @trtypeech=2
		begin
			
			if @nombre <> 0
				select @trdate=dateadd(dy,@trdec,@date)
			else
				select @trdate=dateadd(mm,@trdec/30,@date)
				
		end

	if @trtypeech=3
		begin
			
			select @trdate=@datefixe1
				
		end
		
			
	select @date1 = @trdate
	
	if isnull(@tr2,'') != ''
		select @regle1 = round(@netapayer*(@pc1/100),2)
	else
		select @regle1 = @netapayer


	if isnull(@tr2,'') != ''
	begin
	  select @trdec=TRDEC,@trtypeech=TRTYPEECH,@trjourech=TRJOURECH,@modereg2=TRMODE
	  from FTR
	  where TRCODE=@tr2
	
	  select @nombre = @trdec
	  exec modulo @nombre output,30

	  if @trtypeech=0
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			  select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
									  +'/1/'+convert(char(4),datepart(yy,@trdate)))
			  select @trdate=dateadd(dy,-1,@trdate)
		  end
		  
	  if @trtypeech=1
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			  select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
				  +'/'+convert(char(2),@trjourech)+'/'+convert(char(4),datepart(yy,@trdate)))
		  end
		  
	  if @trtypeech=2
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(dy,@trdec,@date)
			else
				select @trdate=dateadd(mm,@trdec/30,@date)
		  end
		  
	  if @trtypeech=3
		  begin
			  
			  select @trdate=@datefixe2
				  
		  end

			  
	  select @date2 = @trdate
	  
	  if isnull(@tr3,'') != ''
		select @regle2 = round(@netapayer*(@pc2/100),2)
	  else
		select @regle2 = @netapayer - @regle1
	  end

	if isnull(@tr3,'') != ''
	begin
	  select @trdec=TRDEC,@trtypeech=TRTYPEECH,@trjourech=TRJOURECH,@modereg3=TRMODE
	  from FTR
	  where TRCODE=@tr3
	
	  select @nombre = @trdec
	  exec modulo @nombre output,30
	  
	  if @trtypeech=0
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			  select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
									  +'/1/'+convert(char(4),datepart(yy,@trdate)))
			  select @trdate=dateadd(dy,-1,@trdate)
		  end
		  
	  if @trtypeech=1
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			  select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
				  +'/'+convert(char(2),@trjourech)+'/'+convert(char(4),datepart(yy,@trdate)))
		  end
		  
	  if @trtypeech=2
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(dy,@trdec,@date)
			else
				select @trdate=dateadd(mm,@trdec/30,@date)
		  end


	  if @trtypeech=3
		  begin
			  
			  select @trdate=@datefixe3
				  
		  end
			  
	  select @date3 = @trdate
	  
	  if isnull(@tr4,'') != ''
		select @regle3 = round(@netapayer*(@pc3/100),2)
	  else
		select @regle3 = @netapayer - @regle1 - @regle2
	  end
		
	if isnull(@tr4,'') != ''
	begin
	  select @trdec=TRDEC,@trtypeech=TRTYPEECH,@trjourech=TRJOURECH,@modereg4=TRMODE
	  from FTR
	  where TRCODE=@tr4
	
	  select @nombre = @trdec
	  exec modulo @nombre output,30
	  
	  if @trtypeech=0
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			  select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
									  +'/1/'+convert(char(4),datepart(yy,@trdate)))
			  select @trdate=dateadd(dy,-1,@trdate)
		  end
		  
	  if @trtypeech=1
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			  select @trdate=convert(smalldatetime,convert(char(4),datepart(mm,@trdate))
				  +'/'+convert(char(2),@trjourech)+'/'+convert(char(4),datepart(yy,@trdate)))
		  end
		  
	  if @trtypeech=2
		  begin
			
			if @nombre <> 0
				select @trdate=dateadd(dy,@trdec,@date)
			else
				select @trdate=dateadd(mm,@trdec/30,@date)
		  end


	  if @trtypeech=3
		  begin
			  
			  select @trdate=@datefixe4
				  
		  end

			  
	  select @date4 = @trdate
	  
	  select @regle4 = @netapayer - @regle1 - @regle2 - @regle3
	end
	
			
 /* mise a jour de la facture concernee */
 
 	update FFA set FATOTALHT=@totalht,FATAUXESC=@TauxEscompte,FAESCOMPTE=@escompte,
			FATYPETAXE1=@typetaxe1,FATYPETAXE2=@typetaxe2,FATYPETAXE3=@typetaxe3,
			FATAUXTAXE1=@tauxtaxe1,FATAUXTAXE2=@tauxtaxe2,FATAUXTAXE3=@tauxtaxe3,
			FABASETAXE1=isnull(@basetaxe1,0),
			FABASETAXE2=isnull(@basetaxe2,0),
			FABASETAXE3=isnull(@basetaxe3,0),
			FANETAPAYER=@netapayer,FASANSTVA=@sanstva,
			FATAXE1=isnull(@taxe1,0),
			FATAXE2=isnull(@taxe2,0),
			FATAXE3=isnull(@taxe3,0),
			FATOTESC=@TotEsc,FATOTNONESC=@TotNonEsc,
			FATR1=@tr1,FAMODEREG1=@modereg1,FATRDATE1=@date1,FAPC1=@pc1,FAREGL1=@regle1,
			FATR2=@tr2,FAMODEREG2=@modereg2,FATRDATE2=@date2,FAPC2=@pc2,FAREGL2=@regle2,
			FATR3=@tr3,FAMODEREG3=@modereg3,FATRDATE3=@date3,FAPC3=@pc3,FAREGL3=@regle3,
			FATR4=@tr4,FAMODEREG4=@modereg4,FATRDATE4=@date4,FAPC4=@pc4,FAREGL4=@regle4
	where FACODE=@code
	and (@ent is null or FAENT=@ent)
	
		
drop table #Lignes
drop table #Taxes
drop table #LesTaxes

end
go

