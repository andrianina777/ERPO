



create procedure StockQteVal  (	@ent		char(5)	= null,
								@marque		char(12))
as
begin

set arithabort numeric_truncation off


create table #Finale
(
marque		char(12)		not null,
article		char(15)		not null,
lib			varchar(80)		null,
emp1		char(8)			null,
emp2		char(8)			null,
emp3		char(8)			null,
emp4		char(8)			null,
qte			int				not null,
valeur		numeric(14,2)	not null
)




insert into #Finale (marque,article,lib,emp1,emp2,emp3,emp4,qte,valeur)
select ARFO,ARCODE,ARLIB,'','','','',sum(STQTE),sum((STPAHT+STFRAIS)/CVLOT*STQTE)
from FSTOCK,FAR,FCV,FDP
where ARCODE=STAR
and ARUNITACHAT=CVUNIF
and STQTE != 0
and ARFO = @marque
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ARFO,ARCODE,ARLIB


update #Finale
set emp1=isnull(AREEMP,'')
from FARE
where AREAR=#Finale.article
and ARELIGNE=1

update #Finale
set emp2=isnull(AREEMP,'')
from FARE
where AREAR=#Finale.article
and ARELIGNE=2

update #Finale
set emp3=isnull(AREEMP,'')
from FARE
where AREAR=#Finale.article
and ARELIGNE=3

update #Finale
set emp4=isnull(AREEMP,'')
from FARE
where AREAR=#Finale.article
and ARELIGNE=4


select marque,article,lib,emp1,emp2,emp3,emp4,qte,valeur
from #Finale
order by marque,article
compute sum(qte),sum(valeur)

drop table #Finale

end



go

