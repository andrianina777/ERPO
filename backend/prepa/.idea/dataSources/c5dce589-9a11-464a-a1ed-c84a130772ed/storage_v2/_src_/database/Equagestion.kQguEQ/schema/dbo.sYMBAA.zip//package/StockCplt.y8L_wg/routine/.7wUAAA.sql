


create procedure StockCplt (@ent		char(5)	= null,
							@depot1		char(4) = null,
							@depot2		char(4) = null,
							@article1	char(15) = null,
							@article2	char(15) = null,
							@famille1	char(8) = null,
							@famille2	char(8) = null,
							@marque1	char(12) = null,
							@marque2	char(12) = null,
							@grfam1		char(8) = null,
							@grfam2		char(8) = null,
							@depart		char(8) = null)
with recompile
as
begin


create table #Final
(
ARFAM		char(8)		not null,
ARCODE		char(15)	not null,
ARLIB		varchar(80)		null,
ARFO		char(12)	not null,
AREMP		char(8)			null,
ARNUMEROTE	tinyint			null,
ARREFFOUR	char(20)		null
)

create table #Far
(
Article		char(15)	not null,
Depot		char(4)			null,
Stock		int				null
)


if ((@article1 is null) and (@famille1 is null) and (@marque1 is null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is null) and (@famille1 is null) and (@marque1 is not null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARFO between @marque1 and @marque2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is null) and (@famille1 is not null) and (@marque1 is null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARFAM between @famille1 and @famille2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is null) and (@famille1 is not null) and (@marque1 is not null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARFAM between @famille1 and @famille2
		and ARFO between @marque1 and @marque2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is not null) and (@famille1 is null) and (@marque1 is null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARCODE between @article1 and @article2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is not null) and (@famille1 is null) and (@marque1 is not null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARCODE between @article1 and @article2
		and ARFO between @marque1 and @marque2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is not null) and (@famille1 is not null) and (@marque1 is null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARCODE between @article1 and @article2
		and ARFAM between @famille1 and @famille2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end
else if ((@article1 is not null) and (@famille1 is not null) and (@marque1 is not null))
	begin
		insert into #Final (ARFAM,ARCODE,ARLIB,ARFO,AREMP,ARNUMEROTE,ARREFFOUR)
		select ARFAM,ARCODE,ARLIB,ARFO,AREEMP,ARNUMEROTE,ARREFFOUR
		from FAR,FARE
		where ARCODE*=AREAR
		and ARELIGNE=1
		and ARCODE between @article1 and @article2
		and ARFAM between @famille1 and @famille2
		and ARFO between @marque1 and @marque2
		and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
		and (@depart is null or ARDEPART=@depart)
		and AROLD=0
		order by ARFO,ARFAM,ARCODE
	end



if (@depot1 is null)
	begin
		insert into #Far (Article,Depot,Stock)
		select ARCODE,STDEPOT,sum(STQTE)
		from #Final,FSTOCK,FDP
		where ARCODE=STAR
		and STDEPOT=DPCODE
		and ((ARNUMEROTE=0)
			or (ARNUMEROTE=1 and STQTE!=0)
			or (ARNUMEROTE=1 and STQTE=0 and DPLOC != 1))
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		group by ARCODE,STDEPOT
		order by ARCODE,STDEPOT
		
		select ARFAM,ARCODE,ARLIB,ARFO,AREMP,isnull(Depot,''),isnull(Stock,0),ARREFFOUR
		from #Final,#Far
		where Article=*ARCODE
	end
else
	begin
		insert into #Far (Article,Depot,Stock)
		select ARCODE,STDEPOT,sum(STQTE)
		from #Final,FSTOCK,FDP
		where ARCODE=STAR
		and STDEPOT=DPCODE
		and STDEPOT between @depot1 and @depot2
		and ((ARNUMEROTE=0)
			or (ARNUMEROTE=1 and STQTE!=0)
			or (ARNUMEROTE=1 and STQTE=0 and DPLOC != 1))
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		group by ARCODE,STDEPOT
		order by ARCODE,STDEPOT
		
		select ARFAM,ARCODE,ARLIB,ARFO,AREMP,isnull(Depot,''),isnull(Stock,0),ARREFFOUR
		from #Final,#Far
		where Article=ARCODE
	end


drop table #Final
drop table #Far

end



go

