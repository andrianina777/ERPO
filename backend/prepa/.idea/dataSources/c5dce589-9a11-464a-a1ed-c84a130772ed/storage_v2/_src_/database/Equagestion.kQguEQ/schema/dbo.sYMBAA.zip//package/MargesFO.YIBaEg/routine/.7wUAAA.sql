


/* Procedure donnant la marge par fournisseurs entre 2 dates */


create procedure MargesFO (@ent			char(5)	= null,
						   @FromDate	datetime,
						   @ToDate		datetime,
						   @depart 		char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
ARDEPART		char(8)			null,
ARCODE			char(8)			null,
CVLOT			int				null
)

create table #Fal
(
depart	char(8)			null,
Four	char(8)			null,
PADEV	numeric(14,2)	null,
PAHT	numeric(14,2)	null,
devise	char(3)			null,
Total	numeric(14,2)	null,
PR		numeric(14,2)	null
)

insert into #Far (ARDEPART,ARCODE,CVLOT)
select ARDEPART,ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and (@depart is null or ARDEPART=@depart)


create index article on #Far(ARCODE)

insert into #Fal (depart,Four,PADEV,PAHT,devise,Total,PR)
select ARDEPART,STFO,sum(round((isnull(STPADEV,0)/CVLOT),2)*FALQTE),
					  sum(round((isnull(STPAHT,0)/CVLOT),2)*FALQTE),STDEVISE,
			  		  sum(FALTOTALHT),
			  		  sum(round(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT),2)*FALQTE)
from FFAL,#Far,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALDATE between @FromDate and @ToDate
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,STFO,STDEVISE

drop table #Far

/* select final */

select Departement=depart,Fournisseur=Four,Prix_Achat_Devise=PADEV,Prix_Achat_HT=PAHT,
		Cours_Devise=convert(numeric(15,6),(case when PADEV = 0 then 0 else PAHT/PADEV end)),
		Devise=devise, CA=Total, PRHT=PR,
		Marge_Valeur = Total-PR,
		Marge = (case when Total = 0 then 0 else round((Total-PR)/Total,2)*100 end)
from #Fal
order by depart,Four
/* compute sum(PAHT),sum(Total),sum(PR),sum(Total-PR) by depart
compute sum(PAHT),sum(Total),sum(PR),sum(Total-PR) */

drop table #Fal

end



go

