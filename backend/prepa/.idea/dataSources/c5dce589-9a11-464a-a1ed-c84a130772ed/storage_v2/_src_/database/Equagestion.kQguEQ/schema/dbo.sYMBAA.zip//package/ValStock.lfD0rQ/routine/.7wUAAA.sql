


/* Procedure calculant la valeur du stock pour un mois d''une annee
	a partir des lignes de mouvement de stock */


create procedure ValStock  (@an		int,
							@mois	int)
with recompile
as
begin

set arithabort numeric_truncation off


declare @avant	numeric(14,2),
		@entree	numeric(14,2),
		@sortie	numeric(14,2)


select @avant=sum(MOISTOTPR)
from FMOIS
where MOISANNEE=@an-1
and MOISMOIS=12
and MOISQTE != 0


select @entree=sum(MSTOTPR)
from FMS
where MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE in ("E","F","R","C","A","M")
and MSQTE != 0


select @sortie=sum(MSTOTPR)
from FMS
where MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE="S"
and MSQTE != 0


select an=@an,mois=@mois,Total=@avant+@entree-@sortie

end



go

