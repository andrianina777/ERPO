/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.b_getListRayon

*/


CREATE PROCEDURE dbo.b_getListRayon_old (@cmd char(10),@Rayon varchar(150) output)


AS
begin
	declare @xRayon char(8)
			
			 
	select @Rayon=''
	
	declare liste cursor for 
	/*select rtrim(AREEMP) from FCCL inner join FARE on CCLARTICLE=AREAR where AREDEPOT='DET' and ARERECEP=1 and AREVALID=1 and CCLCODE=rtrim(@cmd)
	group by AREEMP order by AREEMP*/
	select rtrim(Descrip) from FCCL inner join FARE on CCLARTICLE=AREAR inner join xRAYON_CORRESP on rtrim(Rayon)=rtrim(AREEMP)
	where AREDEPOT='DET' and ARERECEP=1 and AREVALID=1 and CCLCODE=@cmd
	group by Descrip order by Descrip
	
	open liste
    fetch liste into @xRayon
    while (@@sqlstatus=0)
        begin
        if(@Rayon<>'')
       		begin
        		select @Rayon=rtrim(rtrim(@Rayon)+' - '+rtrim(@xRayon))
        	end
        else
        	begin
        		select @Rayon=''+rtrim(@xRayon)
        	end
        fetch liste into @xRayon    
        end
   close liste
   deallocate cursor liste
			
end
go

