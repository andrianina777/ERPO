



create procedure Maj_AGSATISFAITE  (@accord	char(10),
									@ent	char(5) = null)
with recompile
as
begin

  declare @seq			int,
		  @qte			int,
		  @reste		int,
		  @lignes		int,
		  @satisfaite	int,
		  @nonlivre		int,
		  @pcvalidee	real,
		  @site			int,
		  @count		int
		  
  select @satisfaite = 0,
  		 @nonlivre = 0,
		 @pcvalidee = 0
  
  /** % de validation effectue **/

  select @pcvalidee = (
		 			sum(case when AGLTOTALHT !=0 then (convert(float,AGLTOTALHT)/AGLQTE)*(AGLQTE-AGLRESTE)
		 		  			 when AGLTOTALHT  =0 then convert(float,(AGLQTE-AGLRESTE)*(case when isnull(ARPRM,0)=0 then 1 else ARPRM end)) end)
				   /sum(case when AGLTOTALHT !=0 then convert(float,AGLTOTALHT)
				  			 when AGLTOTALHT  =0 then convert(float,AGLQTE*(case when isnull(ARPRM,0)=0 then 1 else ARPRM end)) end)
	   				)
	 				*100
  from FAGL,FAR
  where AGLCODE=@accord and (@ent is null or AGLENT=@ent)
  and ARCODE=AGLARTICLE


  /** Calcul de AGSATISFAITE **/
  
  select @lignes=count(*) from FAGL
  where AGLCODE=@accord and (@ent is null or AGLENT=@ent)
  
  
  if @lignes > 0
  begin
  
	declare accord cursor 
	for select AGLSEQ,AGLQTE,AGLRESTE
	from FAGL,FAR
	where AGLARTICLE=ARCODE
	and AGLCODE=@accord
	and ARTYPE != 4
	and (@ent is null or AGLENT=@ent)
	for read only
	
	
	open accord
	
	fetch accord
	into @seq,@qte,@reste
	
	while (@@sqlstatus = 0)
		begin
		
		
		if @satisfaite = 0
		  begin
		  	if @reste <= 0 select @satisfaite = 2
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
			else select @nonlivre = 1
		  end
		else
		if @satisfaite = 2
		  begin
		  	if @qte = @reste select @satisfaite = 1
			else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
		  end
	
		
		fetch accord
		into @seq,@qte,@reste
		
	end
	
	close accord
	deallocate cursor accord
	
	if (@satisfaite = 2) and (@nonlivre = 1)
	select @satisfaite = 1
	
	update FAG set AGSATISFAITE = @satisfaite
	where AGCODE=@accord and (@ent is null or AGENT=@ent)
  
  end
  else if @lignes = 0
  begin
  
	update FAG set AGSATISFAITE = 2
	where AGCODE=@accord and (@ent is null or AGENT=@ent)
  
  end  

end



go

