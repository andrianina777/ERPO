


create procedure RepStat (	@ent		char(5)	= null,
							@rep 		char(8) = null,
							@An 		smallint,
							@client 	char(12) = null
						 )
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #temp
	(
		client	char(12) 	not null,
		grfam	char(8) 		null,
		qtean_2	int 			null,
		qtean_1	int				null,
		qtean_0	int				null,
		qtecde	int				null,
		caan_2	numeric(14,2)	null,
		caan_1	numeric(14,2)	null,
		caan_0	numeric(14,2)	null,
		cacde	numeric(14,2)	null,
		carfa_1	numeric(14,2)	null,
		carfa_0	numeric(14,2)	null,
		rfact_1	numeric(14,2)	null,
		rfact_0	numeric(14,2)	null
	)	
	
	declare @type		tinyint,
		@division	char(8)

	select  @type = 0
	
	if @rep is not null
		select  @type=RETYPE, @division=REDIV from FREP where RECODE=@rep
	
	declare @multient	tinyint
	
	select @multient=KIMULTIENTITE from KInfos

	if @type != 2
	begin
	  insert into #temp (client,grfam,qtean_2,caan_2,qtean_1,caan_1,qtean_0,
						  caan_0,qtecde,cacde,carfa_1,carfa_0,rfact_1,rfact_0)
	  select STCL,ARGRFAM,
			  isnull(sum(case when STAN = @An-2 then STQTEFA else 0 end),0),
			  isnull(sum(case when STAN = @An-2 then STCAFA else 0 end),0),
			  isnull(sum(case when STAN = @An-1 then STQTEFA else 0 end),0),
			  isnull(sum(case when STAN = @An-1 then STCAFA else 0 end),0),
			  isnull(sum(case when STAN = @An then STQTEFA else 0 end),0),
			  isnull(sum(case when STAN = @An then STCAFA else 0 end),0),
			  0,0,
			  isnull(sum(case when STAN = @An-1 then STCARFA else 0 end),0),
			  isnull(sum(case when STAN = @An then STCARFA else 0 end),0),
			  isnull(sum(case when STAN = @An-1 then STRFACT else 0 end),0),
			  isnull(sum(case when STAN = @An then STRFACT else 0 end),0)
	  from FST,FAR,FCL
	  where ARCODE=START
	  and CLCODE=STCL
	  and STAN >= @An-2
	  and (@rep is null or CLREP=@rep)
	  and (@client is null or STCL=@client)
	  and (@multient = 0 or @ent is null or (STENT=@ent and CLENT=STENT))
	  group by STCL,ARGRFAM
	  
	  union
	  
	  select RCCCL,ARGRFAM,0,0,0,0,0,0,
			  isnull(sum(RCCQTE),0),isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0),
			  0,0,0,0
	  from FRCC,FCCL,FAR,FCC,FCL
	  where ARCODE=RCCARTICLE
	  and CCLSEQ=RCCSEQ
	  and CLCODE=RCCCL
	  and RCCAN >= @An-2
	  and CCCODE=CCLCODE
	  and isnull(CCVALIDE,0)=0
	  and (@rep is null or CLREP=@rep)
	  and (@client is null or RCCCL=@client)
	  and (@multient = 0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
	  group by RCCCL,ARGRFAM
	end
	else if @type = 2
	begin
	  insert into #temp (client,grfam,qtean_2,caan_2,qtean_1,caan_1,qtean_0,
						  caan_0,qtecde,cacde,carfa_1,carfa_0,rfact_1,rfact_0)
	  select STCL,ARGRFAM,
			  isnull(sum(case when STAN = @An-2 then STQTEFA else 0 end),0),
			  isnull(sum(case when STAN = @An-2 then STCAFA else 0 end),0),
			  isnull(sum(case when STAN = @An-1 then STQTEFA else 0 end),0),
			  isnull(sum(case when STAN = @An-1 then STCAFA else 0 end),0),
			  isnull(sum(case when STAN = @An then STQTEFA else 0 end),0),
			  isnull(sum(case when STAN = @An then STCAFA else 0 end),0),
			  0,0,
			  isnull(sum(case when STAN = @An-1 then STCARFA else 0 end),0),
			  isnull(sum(case when STAN = @An then STCARFA else 0 end),0),
			  isnull(sum(case when STAN = @An-1 then STRFACT else 0 end),0),
			  isnull(sum(case when STAN = @An then STRFACT else 0 end),0)
	  from FST,FAR,FCL,FCLR
	  where ARCODE=START
	  and CLCODE=STCL
	  and CLRCL=CLCODE
	  and STAN >= @An-2
	  and CLRREPDIV=@rep
	  and CLRDIV=ARDEPART
	  and (@client is null or STCL=@client)
	  and (@multient = 0 or @ent is null or (STENT=@ent and CLENT=STENT))
	  group by STCL,ARGRFAM
	  
	  union
	  
	  select RCCCL,ARGRFAM,0,0,0,0,0,0,
			  isnull(sum(RCCQTE),0),isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0),
			  0,0,0,0
	  from FRCC,FCCL,FAR,FCC,FCL,FCLR
	  where ARCODE=RCCARTICLE
	  and CCLSEQ=RCCSEQ
	  and CLCODE=RCCCL
	  and CLRCL=CLCODE
	  and RCCAN >= @An-2
	  and CCCODE=CCLCODE
	  and isnull(CCVALIDE,0)=0
	  and CLRREPDIV=@rep
	  and CLRDIV=ARDEPART
	  and (@client is null or RCCCL=@client)
	  and (@multient = 0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
	  group by RCCCL,ARGRFAM
	end
	
	

	select rtrim(client),rtrim(grfam),
			sum(isnull(qtean_2,0)),sum(isnull(qtean_1,0)),sum(isnull(qtean_0,0)),
			sum(isnull(caan_2,0)),sum(isnull(caan_1,0)),sum(isnull(caan_0,0)),
			sum(isnull(qtecde,0)),sum(isnull(cacde,0)),
			sum(isnull(carfa_1,0)),sum(isnull(carfa_0,0)),
			sum(isnull(rfact_1,0)),sum(isnull(rfact_0,0))
	from #temp
	group by client,grfam
	
	drop table #temp
	
end



go

