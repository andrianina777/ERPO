


/* Procedure donnant la marge par article entre 2 dates ainsi que le stock au moment de la requete */

create procedure MargesFIFOComp (@ent		char(5)	 = null,
								 @FromDate	smalldatetime,
								 @ToDate	smalldatetime,
								 @depart	char(8)  = null,
								 @chefprod	char(8)  = null,
								 @marque	char(12) = null,
								 @famille	char(8)  = null,
								 @categorie	char(8)  = null,
								 @article	char(15) = null
								)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
ARDEPART		char(8)			null,
ARCHEFP			char(8)			null,
ARFO			char(8)			null,
ARFAM			char(8)			null,
ARGRFAM			char(8)			null,
ARCODE			char(15)	not null,
CVLOT			int				null,
AROLD			tinyint			null
)

create table #Final
(
article		char(15)		not null,
Total_1		numeric(14,2)		null,
Total		numeric(14,2)		null,
PR_1		numeric(14,2)		null,
PR			numeric(14,2)		null,
valeurST	int					null,
valeurbe	int					null,
valeurcf	int					null,
valeurcc	int					null,
devise		char(3)			not null
)


insert into #Far (ARDEPART,ARCHEFP,ARFO,ARFAM,ARGRFAM,ARCODE,CVLOT,AROLD)
select ARDEPART,ARCHEFP,ARFO,ARFAM,ARGRFAM,ARCODE,CVLOT,AROLD
from FAR,FCV
where ARUNITACHAT=CVUNIF
and (@depart is null or ARDEPART=@depart)
and (@chefprod is null or ARCHEFP=@chefprod)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@categorie is null or ARGRFAM=@categorie)
and (@article is null or ARCODE=@article)


create unique index article on #Far(ARCODE)


insert into #Final (article,Total_1,Total,PR_1,PR,valeurST,valeurbe,valeurcf,valeurcc,devise)
select 	FALARTICLE,
		sum(FALTOTALHT),0,
		isnull(round(sum(((STPAHT+STFRAIS)/CVLOT)*FALQTE),2),0),0,
		0,0,0,0,STDEVISE
from FFAL,#Far,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALDATE between dateadd(yy,-1,@FromDate) and dateadd(yy,-1,@ToDate)
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by FALARTICLE,STDEVISE


insert into #Final (article,Total_1,Total,PR_1,PR,valeurST,valeurbe,valeurcf,valeurcc,devise)
select 	FALARTICLE,
		0,sum(FALTOTALHT),
		0,isnull(round(sum(((STPAHT+STFRAIS)/CVLOT)*FALQTE),2),0),
		0,0,0,0,STDEVISE
from FFAL,#Far,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALDATE between @FromDate and @ToDate
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by FALARTICLE,STDEVISE



insert into #Final (article,Total_1,Total,PR_1,PR,valeurST,valeurbe,valeurcf,valeurcc,devise)
select ARCODE,0,0,0,0,isnull(round(sum((STPAHT+STFRAIS)/CVLOT*STQTE),0),0),0,0,0,STDEVISE
from FSTOCK,#Far,FDP
where STAR=ARCODE
and AROLD = 0
and STQTE > 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ARCODE,STDEVISE



insert into #Final (article,Total_1,Total,PR_1,PR,valeurST,valeurbe,valeurcf,valeurcc,devise)
select ARCODE,0,0,0,0,0,isnull(round(sum((STPAHT+STFRAIS)/CVLOT*BELQTE),0),0),0,0,STDEVISE
from FBEL,FRBE,FSTOCK,#Far,FDP
where BELSEQ=RBESEQ
and ARCODE=RBEARTICLE
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and STQTE > 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ARCODE,STDEVISE


insert into #Final (article,Total_1,Total,PR_1,PR,valeurST,valeurbe,valeurcf,valeurcc,devise)
select ARCODE,0,0,0,0,0,0,isnull(round(sum(((CFLTOTALHT/CFLQTE)*RCFQTE)),0),0),0,CFLDEVISE
from FCFL,FRCF,#Far
where CFLSEQ=RCFSEQ
and ARCODE=RCFARTICLE
and CFLQTE > 0
and (@ent is null or CFLENT=@ent)
group by ARCODE,CFLDEVISE


insert into #Final (article,Total_1,Total,PR_1,PR,valeurST,valeurbe,valeurcf,valeurcc,devise)
select ARCODE,0,0,0,0,0,0,0,isnull(round(sum(((CCLTOTALHT/CCLQTE)*RCCQTE)),0),0),CCLDEV
from FCCL,FRCC,#Far
where CCLSEQ=RCCSEQ
and ARCODE=RCCARTICLE
and CCLQTE > 0
and (@ent is null or CCLENT=@ent)
group by ARCODE,CCLDEV



/* select final */


select Departement = ARDEPART, Chef_Produit=ARCHEFP, Marque = ARFO, Famille = ARFAM,
		Categorie = ARGRFAM, Article = ARCODE,
		CA_HT_Periode_prec=sum(isnull(Total_1,0)),
		CA_HT=sum(isnull(Total,0)),
		PAHT_Periode_prec=sum(isnull(PR_1,0)),
		PAHT=sum(isnull(PR,0)),
		Marge_Valeur_Periode_prec = sum(isnull(Total_1-PR_1,0)),
		Marge_Valeur = sum(isnull(Total-PR,0)),
		Marge_Periode_prec = isnull(round(sum(((Total_1-PR_1)*abs(sign(Total_1)))/(Total_1+(1-abs(sign(Total_1)))))*100,2),0),
		Marge = isnull(round(sum(((Total-PR)*abs(sign(Total)))/(Total+(1-abs(sign(Total)))))*100,2),0),
		Valeur_Stock = sum(isnull(valeurST,0)),
		Valeur_BE = sum(isnull(valeurbe,0)),
		A_Recevoir = sum(isnull(valeurcf,0)),
		En_Cdes_Clients= sum(isnull(valeurcc,0)),
		Devise_Achat_Vente=isnull(devise,"")
from #Final,#Far
where ARCODE *= article
group by ARDEPART,ARCHEFP,ARFO,ARFAM,ARGRFAM,ARCODE,devise
having sum(isnull(Total_1,0)) !=0 or  sum(isnull(Total,0)) != 0
	or sum(isnull(PR_1,0)) != 0 or sum(isnull(PR,0)) != 0
	or sum(isnull(valeurST,0)) != 0
	or sum(isnull(valeurbe,0)) != 0
	or sum(isnull(valeurcf,0)) != 0
	or sum(isnull(valeurcc,0)) != 0
order by ARDEPART,ARCHEFP,ARFO,ARFAM,ARGRFAM,ARCODE,isnull(devise,"")


drop table #Final
drop table #Far


end



go

