


create procedure BEBP_GenBP (   @Depot      char(4),                         
                                @ent        char(5) = null, 
                                @result     tinyint = 0,        /* = 1 si affiche nb de BE Traites    */ 
                                @debug      tinyint = 0         /* = 0 sans debug  = 1 avec message pour debug    */ 
                            )    
with recompile                         
as 
begin 
 
set arithabort numeric_truncation off 
 
/* ************************************************************************************************ */ 
/*                        base - VGSPID - VGSITE - VGENT                                                */ 
/* ************************************************************************************************ */ 
 
declare @base         varchar(50) 
select @base=db_name() 
 
declare @vgsite    int 
select @vgsite = KISITE from KInfos 
 
/*    dump tran @base with truncate_only    */ 
 
declare @vgspid    int 
select @vgspid = @@spid 
 
declare @Pdevref       char(3), 
        @vgent         char(5), 
        @Pdepot        char(4) 
         
select     @Pdevref=PDEVREF, @vgent = PENT, @Pdepot = PDEPOT    from KParam 
 
declare @bp_prepares    int 
select     @bp_prepares = 0 
 
declare @countligne    int 
select  @countligne = count(*) from PREP_TEMP where TEMP_ID=@vgspid and TEMP_VATEST2=1 
 
if @countligne=0 
begin 
    if @result = 1 
        select @bp_prepares,"AUCUNE LIGNE A PREPARER"                        /*    pas de lignes a preparer    */ 
         
    return 
end 
 
 
declare     @seq            int, 
            @vatest2        numeric(14,2), 
            @vaqte            int, 
            @cclcl            char(12), 
            @cclcode        char(10), 
            @ccldev            char(3), 
            @cclcoursdev    numeric(16,10), 
            @ccnom            varchar(35), 
            @ccnom2            varchar(50), 
            @ccprenom        varchar(35), 
            @ccadr1            varchar(50), 
            @ccadr2            varchar(50), 
            @cccp            varchar(12), 
            @ccville        varchar(30), 
            @ccpy            char(8), 
            @ccdateliv        smalldatetime, 
            @cctransporteur        char(8), 
            @ccmodetransp    char(10), 
            @ccprepspecif    tinyint, 
            @ccescompte        real, 
            @ccmodeliv        varchar(30) 
                     
declare     @bpseq            int, 
            @bpcode            char(10), 
            @bpcodepg        char(10), 
            @codebppg        char(10), 
            @bpattache        char(10), 
            @bpdate            smalldatetime, 
            @bpmotifbloc    varchar(16), 
            @yy                char(4), 
            @mm                char(2), 
            @jj                char(2), 
            @bpan            char(2), 
            @bpmois            char(2), 
            @numint            int, 
            @numchar        char(4), 
            @an                int, 
            @mois            int, 
            @bpcl            char(12), 
            @bpcoursdev        numeric(16,10), 
            @bpdev            char(3), 
            @bpstade        tinyint, 
            @client            char(12), 
            @nom            varchar(35), 
              @adr1            varchar(50), 
              @cp                varchar(12), 
              @devise            varchar(3), 
              @commande        char(10), 
              @artype            int, 
              @bpregle        int, 
              @bpcc            char(10), 
              @bpechspe        tinyint, 
              @bptotalht        numeric(14,2), 
              @bptotalhtdev    numeric(14,2), 
              @bpobservations    varchar(255), 
              @bptarif        char(8), 
              @bpent            char(5), 
              @bplent            char(5), 
              @cclattache        char(10) 
 
declare     @bpltypemv        char(2), 
            @bplseq            int, 
            @bplcode        char(10), 
            @bplcodepg        char(10), 
            @bpldate        smalldatetime, 
            @bplcl            char(12), 
            @bplusercre        int, 
            @bpldatecre        smalldatetime, 
            @bplusermdf        int, 
            @bpldatemdf        smalldatetime, 
            @bpldev            char(3), 
            @bplcoursdev    numeric(16,10), 
            @bplstade        tinyint, 
            @bplattache        char(10), 
            @bplarticle        char(15), 
            @bplprixht        numeric(14,2), 
            @bpltotalht        numeric(14,2), 
            @bplunitfact    tinyint, 
            @bpltypeve        char(4), 
            @bpltype        tinyint, 
            @bpllibre        varchar(255), 
            @bpldemo        int, 
            @bplliencode    char(10), 
            @bplliennum        int, 
            @bplechspe        tinyint, 
            @bplremise1        real, 
            @bplremise2        real, 
            @bplremise3        real, 
            @bplremise4     real, 
            @bplremise5        real, 
            @bplfactman        tinyint, 
            @bpl_factman    tinyint, 
            @bploffert        tinyint, 
            @bpldotation    tinyint, 
            @bplprixhtdev    numeric(14,2), 
            @bpltotalhtdev    numeric(14,2), 
            @bplqte            int, 
            @bpllettre        char(4), 
            @bplreste        int, 
            @bplqteres        int, 
            @bpldepot        char(4), 
            @nbfranco        int,            /* Il suffit que 1 seule commande ne soit pas franco pour appliquer les frais de Port    */ 
            @numcde            char(10), 
            @bplmarche        char(12), 
            @bpl_num        int, 
            @bplnum            int, 
            @bplordre        int, 
            @bpl_ordre        int, 
            @bplemp            char(8) 
 
declare     @cclarticle        char(15), 
            @clccbe            tinyint, 
            @cclpht            numeric(14,2), 
            @ccltotalht        numeric(14,2), 
            @cclunitfact    tinyint, 
            @ccltv            char(4), 
            @ccltype        tinyint, 
            @ccllibre        varchar(255), 
            @ccechspe        int, 
            @cclr1            real, 
            @cclr2            real, 
            @cclr3            real, 
            @cclfactman        tinyint, 
            @ccloffert        tinyint, 
            @cclphtdev        numeric(14,2), 
            @ccltotalhtdev    numeric(14,2), 
            @ccfranco        int, 
            @ccfrancobe        int, 
            @cclmarche        char(12), 
            @arcomp            tinyint, 
            @cclnum            int, 
            @cccommentaires    varchar(255), 
            @cctarif        char(8), 
            @passage        tinyint 
 
declare     @stempar        char(15), 
            @stemplettre    char(4), 
            @stempqte        int, 
            @stempdepot        char(4), 
            @stempemp        char(8) 
             
declare        @count            int 
 
declare LigneStock cursor 
for select STEMPAR,STEMPLETTRE,
STEMPQTE - isnull((select sum(BPLQTE) from FBPL where 
	BPLARTICLE=FSTEMP.STEMPAR and BPLDEPOT=FSTEMP.STEMPDEPOT and BPLEMP=FSTEMP.STEMPEMP and BPLLETTRE=FSTEMP.STEMPLETTRE
	and BPLSTADE < 4),0), STEMPDEPOT,STEMPEMP 
from FSTEMP,FDP,FARE 
where STEMPAR = @bplarticle 
and AREAR=STEMPAR 
and AREDEPOT=STEMPDEPOT 
and AREEMP=STEMPEMP 
and DPLOC=1 and DPCODE=@Depot 
and STEMPQTE - isnull((select sum(BPLQTE) from FBPL where 
	BPLARTICLE=FSTEMP.STEMPAR and BPLDEPOT=FSTEMP.STEMPDEPOT and BPLEMP=FSTEMP.STEMPEMP and BPLLETTRE=FSTEMP.STEMPLETTRE
	and BPLSTADE < 4),0)> 0 
and STEMPDEPOT=DPCODE and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
order by AREPICK desc, ltrim(case when charindex(' ',STEMPLETTRE) != 0 then ("*"+STEMPLETTRE) else STEMPLETTRE end) 
for read only 
 
declare LigneCde cursor 
for select  TEMP_CCLSEQ,TEMP_CCLCL, TEMP_CCNOM, TEMP_CCADR1, TEMP_CCCP, TEMP_CCLDEV, TEMP_CCLCODE,TEMP_VATEST2, TEMP_VAQTE, 
            TEMP_CCLDEV,TEMP_CCLCOURSDEV,TEMP_CCNOM2,TEMP_CCPRENOM,TEMP_CCADR1,TEMP_CCADR2,TEMP_CCCP,TEMP_CCVILLE,TEMP_CCPY, 
            TEMP_CCLARTICLE,TEMP_CCLPHT,TEMP_CCLTOTALHT,TEMP_CCLUNITFACT,TEMP_CCLTV,TEMP_CCLTYPE,TEMP_CCLLIBRE,TEMP_CCECHSPE, 
            TEMP_CCLR1,TEMP_CCLR2,TEMP_CCLR3,TEMP_CCLFACTMAN,TEMP_CCLOFFERT,TEMP_CCLPHTDEV,TEMP_CCLTOTALHTDEV, 
            TEMP_CCFRANCO,TEMP_CCFRANCOBE,TEMP_CCLMARCHE,TEMP_ARCOMP,TEMP_CCLNUM,TEMP_CLCCBE,TEMP_CCCOMMENTAIRES, 
            TEMP_CCTARIF,TEMP_CCLATTACHE,TEMP_ARTYPE 
from PREP_TEMP 
where TEMP_ID = @vgspid 
and TEMP_VATEST2 = 1 
order by TEMP_CCLCL, TEMP_CCNOM, TEMP_CCPAYS, TEMP_CCVILLE, TEMP_CCCP, TEMP_CCADR1, TEMP_CCLDEV, TEMP_CCLCODE, TEMP_CCLNUM 
for read only 
 
select @client = '-' 
select @nom = '-' 
select @adr1 = '-' 
select @cp = '-' 
select @devise = '-' 
select @commande = '-' 
 
select @bpcode = '', @passage = 0, @bp_prepares = 0 
 
if @debug = 1 
    select 'debug','DEBUT ', @Depot, @ent, @vgent 
 
/* ********************************************************************************************************* */ 
/*                         DEBUT         TRAITEMENT                 :   NUMEROTATION DE PREPARATION GLOBALE         */ 
/* ********************************************************************************************************* */ 
             
select @an     = datepart(year,getdate()) 
select @mois = datepart(month,getdate()) 
 
if @ent is null 
    execute eq_GetNum_proc @vgent,'PG',@an,@mois,1,@i = @numint output 
else 
    execute eq_GetNum_proc @ent,'PG',@an,@mois,1,@i = @numint output 
             
select @numchar=right('0000'+convert(varchar,@numint),4) 
select @bpan=right('00'+convert(varchar,datepart(yy,getdate())),2) 
select @bpmois=right('00'+convert(varchar,datepart(month,getdate())),2) 
select @bpcodepg = 'PG' + @bpan + @bpmois + @numchar 
 
select @codebppg = @bpcodepg 
 
/* ********************************************************************************************************* */ 
/*                             DEBUT         TRAITEMENT                                                           */ 
/* ********************************************************************************************************* */ 
 
open LigneCde 
fetch LigneCde into     @seq, @cclcl, @ccnom, @ccadr1, @cccp, @ccldev, @cclcode, @vatest2, @vaqte, 
                        @ccldev, @cclcoursdev,@ccnom2,@ccprenom,@ccadr1,@ccadr2,@cccp,@ccville,@ccpy, 
                        @cclarticle,@cclpht,@ccltotalht,@cclunitfact,@ccltv,@ccltype,@ccllibre,@ccechspe, 
                        @cclr1,@cclr2,@cclr3,@cclfactman,@ccloffert,@cclphtdev,@ccltotalhtdev, 
                        @ccfranco,@ccfrancobe,@cclmarche,@arcomp,@cclnum,@clccbe,@cccommentaires, 
                        @cctarif,@cclattache,@artype 
 
while (@@sqlstatus=0) 
begin  
 
    if @debug = 1 
        select 'debug','entre boucle',@bpcode,@vatest2,@vaqte,@passage 
     
    if @vatest2=1 and @vaqte>0 
    begin 
 
        if @debug = 1 
            select 'debug','int @cclcl=@client',@cclcl,@client,@ccnom,@nom,@ccadr1,@adr1,@cccp,@cp,@ccldev,@devise,@commande,@cclcode,@clccbe 
     
        if ((@cclcl<>@client) or (@ccnom<>@nom) or (@ccadr1<>@adr1) or (@cccp<>@cp) 
                              or (@ccldev<>@devise) or (@commande<>@cclcode and @clccbe=1)) 
        begin 
             
            if @debug = 1 
                select 'debug','@cclcl<>@client',@bpcode,@passage,@vatest2 
             
            /* ********************************************************************************************************* */ 
            /*                         Traitement en fin du BP                                                               */ 
            /* ********************************************************************************************************* */ 
            if @passage = 1    and @bpcode <> '' 
            begin 
                if @debug = 1 
                    select 'debug',"fin BP",@bpcode,"a suivre" 
                 
                /*        Maj de BEMARCHE en fonction du nombre de lignes contenant un BELMARCHE        */ 
                select @countligne = 0 
                select @countligne = count(*) from FBPL where BPLCODE=@bpcode and isnull(BPLMARCHE,"")<>"" 
                 
                if @debug = 1 
                    select 'debug','fin BP',@bpcode,'BPMARCHE',@countligne 
                 
                if @countligne > 1 
                    update FBP set BPMARCHE=1 where BPCODE=@bpcode and (@ent is null or BPENT=@ent) 
                                         
                /*        Recupere BPCC        */ 
                select @bpcc = '',@ccdateliv=null,@cctransporteur='',@ccmodetransp='', @ccprepspecif=0 
                select @countligne = 0 
                select @countligne = count(distinct BPLLIENCODE) from FBPL where BPLCODE=@bpcode and (@ent is null or BPLENT=@ent) 
                 
                if @countligne = 1 
                begin 
                    select @bpcc = isnull(BPLLIENCODE,'') from FBPL where BPLCODE=@bpcode and (@ent is null or BPLENT=@ent) 
                    group by BPLCODE 
                     
                    select @ccdateliv=CCDATELIV, @cctransporteur=isnull(CCTRANSPORTEUR,''), @ccmodetransp=isnull(CCMODETRANSP,''), 
                           @ccprepspecif=isnull(CCPREPSPECIF,0), @ccescompte = isnull(CCESCOMPTE,0), 
                           @ccmodeliv = isnull(CCMODELIV,'') 
                    from FCC 
                    where CCCODE = @bpcc 
                end 
                else 
                if @countligne > 1 
                begin 
                    select @ccprepspecif=max(CCPREPSPECIF) 
                    from FCC,FBPL 
                    where BPLCODE = @bpcode 
                    and CCCODE = isnull(BPLLIENCODE,'') 
                    and (@ent is null or BPLENT=@ent) 
                     
                    select @ccdateliv=min(CCDATELIV) 
                    from FCC,FBPL 
                    where BPLCODE = @bpcode 
                    and CCCODE = isnull(BPLLIENCODE,'') 
                    and (@ent is null or BPLENT=@ent) 
                     
                    select @cctransporteur = max(CCTRANSPORTEUR) 
                    from FCC,FBPL 
                    where BPLCODE = @bpcode 
                    and CCCODE = isnull(BPLLIENCODE,'') 
                    and (@ent is null or BPLENT=@ent) 
                     
                    select @ccmodetransp = max(CCMODETRANSP) 
                    from FCC,FBPL 
                    where BPLCODE = @bpcode 
                    and CCCODE = isnull(BPLLIENCODE,'') 
                    and (@ent is null or BPLENT=@ent) 
                     
                    select @ccmodeliv = max(CCMODELIV) 
                    from FCC,FBPL 
                    where BPLCODE = @bpcode 
                    and CCCODE = isnull(BPLLIENCODE,'') 
                    and (@ent is null or BPLENT=@ent) 
                     
                    select @count = 0 
                    select @count = count(distinct isnull(CCESCOMPTE,0)) from FCC,FBPL 
                                    where BPLCODE=@bpcode 
                                    and CCCODE = isnull(BPLLIENCODE,'') 
                                    and (@ent is null or BPLENT=@ent) 
                 
                    if @count = 1 
                        select @ccescompte = isnull(CCESCOMPTE,0) from FCC,FBPL 
                                    where BPLCODE=@bpcode 
                                    and CCCODE = isnull(BPLLIENCODE,'') 
                                    and (@ent is null or BPLENT=@ent) 
                                    group by CCESCOMPTE 
                    else 
                        select @ccescompte = 0 
                     
                end 
                 
                update FBP set     BPESCOMPTE = @ccescompte 
                where BPCODE=@bpcode and (@ent is null or BPENT=@ent) 
 
                                 
                select @bpechspe = min(BPLECHSPE), @bptotalht = sum(BPLTOTALHT), @bptotalhtdev = sum(BPLTOTALHTDEV) from FBPL 
                where BPLCODE=@bpcode and (@ent is null or BPLENT=@ent) 
                     
                select @bpregle = 0 
                select @bpregle = count(*) from FAR,FBPL where BPLCODE=@bpcode and BPLARTICLE=ARCODE and ARREGLE > 0 and (@ent is null or BPLENT=@ent) 
                 
                /*    Ctrl blocage Bon de preparation        */     
                select @bpstade = 1                    /*    A preparer - VALIDE        */ 
                execute eq_CalculStadeBP_proc @ent, @bpcode, @debug, @bpmotifbloc output 
                 
                if @bpmotifbloc <> '' 
                    select @bpstade = 0            /*    A preparer - BLOQUE        */ 
                 
                /*    update FBP        */ 
                update FBP set     BPECHSPE=@bpechspe, BPTOTALHT=@bptotalht, BPTOTALHTDEV=@bptotalhtdev, BPREGLE=@bpregle, 
                                BPOBSERVATIONS=@bpobservations, BPCC=@bpcc, BPSTADE=@bpstade, BPMOTIFBLOC = @bpmotifbloc, 
                                BPDATELIV=@ccdateliv, BPTRANSPORTEUR=@cctransporteur, BPMODETRANSP=@ccmodetransp, 
                                BPPREPSPECIF = @ccprepspecif, BPMODELIV = @ccmodeliv 
                where BPCODE=@bpcode and (@ent is null or BPENT=@ent) 
                 
                update FBPL  
                set BPLSTADE = BPSTADE 
                from FBP 
                where BPCODE = @bpcode 
                and BPLCODE = BPCODE 
 
                                 
            end        /*        @passage = 1    and @bpcode <>      */ 
             
            if @debug = 1 
                select 'debug','int valeur client pour NOUVEAU BP' 
             
            select @client = @cclcl 
            select @nom = @ccnom 
            select @adr1 = @ccadr1 
            select @cp = @cccp 
            select @devise = @ccldev 
            select @commande = @cclcode 
         
/* **********************************************************/ 
/* 1.Insertion dans FBP  ************************************/ 
/* **********************************************************/ 
                     
            select @bpdate = getdate() 
            select @yy = convert(char(4),datepart(yy,@bpdate)) 
            select @mm = right('00'+convert(varchar,datepart(month,@bpdate)),2) 
            select @jj = right('00'+convert(varchar,datepart(day,@bpdate)),2) 
                         
            select @an     = datepart(year,@bpdate) 
            select @mois = datepart(month,@bpdate) 
             
            if @ent is null 
                execute eq_GetNum_proc @vgent,'FBP',@an,@mois,1,@i = @numint output 
            else 
                execute eq_GetNum_proc @ent,'FBP',@an,@mois,1,@i = @numint output 
                         
            select @numchar=right('0000'+convert(varchar,@numint),4) 
             
            select @bpan=right('00'+convert(varchar,datepart(yy,@bpdate)),2) 
            select @bpmois=right('00'+convert(varchar,datepart(month,@bpdate)),2) 
             
            execute eq_GetSeq_proc 'FBP',1,@i = @bpseq output 
             
            select @bpcode = 'BP'+@bpan+@bpmois+@numchar 
            select @bpcodepg = @codebppg 
            select @bpdate = convert(smalldatetime,@yy+@mm+@jj) 
             
            select @bpcc='', @bptarif=@cctarif, @bpcl=@cclcl, @bpdev=@ccldev, @bpcoursdev=@cclcoursdev, 
                         @bpstade=1,         /*    prepare / valide    */ 
                         @nbfranco=0, @bptotalht=0, @bptotalhtdev=0, @bpregle=0, 
                         @bpechspe=0,@bpobservations='',@bpent=@vgent, @bpattache=@cclattache 
                     
            if @debug = 1 
                select 'debug','insert FBP',@bpcode,@passage,@bpdate,@bpcl,@bpstade   
             
            select @bp_prepares = @bp_prepares + 1 
             
            insert into FBP (BPCODE,BPCODEPG,BPSEQ,BPDATE,BPDEPOT,BPCL,BPNOM,BPADR1,BPADR2,BPCP,BPVILLE,BPPY,BPDEMO, 
                    BPCC,BPTARIF,BPTOTALHT,BPDEV,BPCOURSDEV,BPTOTALHTDEV,BPREGLE,BPECHSPE,BPSTADE,BPENT, 
                    BPOBSERVATIONS,BPBE,BPUSERCRE,BPDATECRE,BPUSERMDF,BPDATEMDF,BPEXPEDIE,BPCCOMP,BPATTACHE,BPMARCHE, 
                    BPNOM2,BPPRENOM,BPUNLOCKUSER,BPUNLOCKDATE) 
                values     (@bpcode,@bpcodepg,@bpseq,@bpdate,'',@bpcl,@ccnom,@ccadr1,@ccadr2,@cccp,@ccville,@ccpy,0, 
                    @bpcc,@bptarif,@bptotalht,@bpdev,@bpcoursdev,@bptotalhtdev,@bpregle,@bpechspe,@bpstade,@bpent, 
                    @bpobservations,'',@vgspid,getdate(),@vgspid,getdate(),0,0,@bpattache,0, 
                    @ccnom2,@ccprenom,null,null) 
 
/* ******************************************************************/ 
/* 2.prep dans FBPL    *************************************************/ 
/* ******************************************************************/ 
     
            select     @bpltypemv='BP', 
                    @bplcode=@bpcode, 
                    @bplcodepg=@bpcodepg, 
                    @bpldate=@bpdate, 
                    @bplcl=@bpcl, 
                    @bplusercre=@vgspid, 
                    @bpldatecre=getdate(), 
                    @bplusermdf=@vgspid, 
                    @bpldatemdf=getdate(), 
                    @bpldev=@bpdev, 
                    @bplcoursdev=@bpcoursdev, 
                    @bplstade=@bpstade 
             
            select     @bpl_num = 0, @bpl_ordre = 0, @bplnum = 0, @bplordre = 0 
     
                     
            select @passage = 1 
             
            if @debug = 1 
                select 'debug','init FBPL',@bplcode,@bpldate,@bplstade 
             
        end 
         
        if @debug = 1 
            select 'debug','compare @cclcl=@client',@cclcl,@client,@ccnom,@nom,@ccadr1,@adr1,@cccp,@cp,@ccldev,@devise,@commande,@cclcode,@clccbe 
         
        if ((@cclcl=@client) and (@ccnom=@nom) and (@ccadr1=@adr1) and (@cccp=@cp) and (@ccldev=@devise) 
                             and (@commande=@cclcode or @clccbe=0)) 
        begin 
 
            if @debug = 1 
                select 'debug','@cclcl=@client',@bpcode,@passage,@vatest2 
             
            if @vatest2=1 
            begin 
                    /*    Initialisation des variables de FBPL    */ 
                     
                    select @bplcodepg=@codebppg, @bplstade=1, @bplarticle=@cclarticle, @bplprixht=@cclpht, @bplunitfact=@cclunitfact  
                    select @bpltypeve=@ccltv, @bpltype=@ccltype, @bpllibre=@ccllibre, @bpldemo = 0, @bplliencode=@cclcode 
                    select @bplliennum=@cclnum, @bplechspe=@ccechspe, @bplremise1=@cclr1, @bplremise2=@cclr2, @bplremise3=@cclr3 
                    select @bplremise4=0, @bplremise5=0, @bplfactman=@cclfactman, @bpl_factman=@bplfactman, @bploffert=@ccloffert 
                    select @bpldotation=0, @bplprixhtdev=@cclphtdev, @bplattache = @cclattache 
                     
                     
                    /*    ajout de ligne de port si (@ccfranco=0 and @ccfrancobe=0)    */ 
                     
                    select @nbfranco = @nbfranco + (case when (@ccfranco=0 and @ccfrancobe=0) then 1 else 0 end) 
                     
                    select @numcde=@cclcode, @bplmarche=@cclmarche 
 
                    if @debug = 1 
                        select 'debug','init ligne article',@bplcode,@passage,@bplstade,@bplarticle,@artype,@vaqte                     
                     
                    /*        Ajout ligne de BP        */ 
 
                    if @artype=0 and @vaqte>0 
                    begin                 
                        if @debug = 1 
                            select 'debug','Ajout des lignes BP    ' 
                                     
                        open LigneStock 
                        fetch LigneStock into     @stempar, @stemplettre, @stempqte, @stempdepot, @stempemp 
                                     
                        while (@@sqlstatus=0) and @vaqte > 0 
                        begin  
                                     
                            if @vaqte < @stempqte 
                                    select @bplqte = @vaqte 
                            else  
                                    select @bplqte = @stempqte 
                                     
                            select @bplnum = @bplnum + 1  
                            select @bpl_num = @bplnum 
                            select @bplordre = @bplordre + 32 
                            select @bpl_ordre = @bplordre 
                                         
                            select @bpllettre = @stemplettre 
                            select @bplreste = @bplqte 
                            select @bplqteres = @bplqte 
                            select @bpldepot = @stempdepot 
                            select @bplemp = @stempemp 
                                     
                            execute eq_GetSeq_proc 'FBPL',1,@i = @bplseq output 
                                         
                            execute eq_CalculTotal_proc  @bplprixhtdev,@bplunitfact,@bplqte,@bplremise1,@bplremise2,@bplremise3,@totalht = @bpltotalhtdev output 
                                                                                     
                            if @bpdev <> @Pdevref 
                                    select @bpltotalht = @bpltotalhtdev 
                            else 
                                    execute eq_CalculTotal_proc  @bplprixht,@bplunitfact,@bplqte,@bplremise1,@bplremise2,@bplremise3,@totalht = @bpltotalht output 
                             
                            select @bplent = @vgent                         
                                     
                            insert into FBPL (BPLSEQ,BPLCODE,BPLCODEPG,BPLDEPOT,BPLARTICLE,BPLQTE,BPLQTERES,BPLDATE,BPLPRIXHT, 
                                    BPLORDRE,BPLUNITFACT,BPLTYPEVE,BPLTYPE,BPLLIBRE,BPLNUM,BPLDEMO,BPLLETTRE,BPLRESTE,BPLLIENCODE, 
                                    BPLLIENNUM,BPLCL,BPLTOTALHT,BPLECHSPE,BPLREMISE1,BPLREMISE2,BPLREMISE3,BPLREMISE4,BPLREMISE5, 
                                    BPLTYPEMV,BPLUSERCRE,BPLDATECRE,BPLUSERMDF,BPLDATEMDF,BPLFACTMAN,BPLOFFERT,BPLDOTATION,BPLDEV, 
                                    BPLCOURSDEV,BPLPRIXHTDEV,BPLTOTALHTDEV,BPLSTADE,BPLENT,BPLATTACHE,BPLEMP,BPLMARCHE) 
                                values     (@bplseq,@bplcode,@bplcodepg,@bpldepot,@bplarticle,@bplqte,@bplqteres,@bpldate,@bplprixht, 
                                    @bplordre,@bplunitfact,@bpltypeve,@bpltype,@bpllibre,@bplnum,@bpldemo,@bpllettre,@bplreste,@bplliencode, 
                                    @bplliennum,@bplcl,@bpltotalht,@bplechspe,@bplremise1,@bplremise2,@bplremise3,@bplremise4,@bplremise5, 
                                    @bpltypemv,@bplusermdf,@bpldatemdf,@bplusercre,@bpldatecre,@bplfactman,@bploffert,@bpldotation,@bpldev, 
                                    @bplcoursdev,@bplprixhtdev,@bpltotalhtdev,@bplstade,@bplent,@bplattache,@bplemp,@bplmarche) 
                                 
                            if @cccommentaires <> '' and (case when charindex(@cclcode,@bpobservations)>0 then 1 else 0 end)=0 
                                    select @bpobservations = @bpobservations + ' +(' + @cclcode + ') ' + @cccommentaires 
                                                                      
                            select @vaqte = @vaqte - @bplqte 
                                         
                            fetch LigneStock into     @stempar, @stemplettre, @stempqte, @stempdepot, @stempemp 
                        end 
                        close LigneStock 
                    end 
                    else if @artype<>0 and @vaqte>0 
                    begin 
                        if @debug = 1 
                            select 'debug','Ajout des lignes articles non stockes',@artype,@vaqte,@vgsite 
 
                        select @bpllettre = 'AAAA', @bpldepot=@Pdepot, @bplemp = '0000' 
                                                                             
                        select @bplnum = @bplnum + 1 
                        select @bpl_num = @bplnum 
                        select @bplordre = @bplordre + 32 
                        select @bpl_ordre = @bplordre 
                             
                        select @bplqte = @vaqte 
                        select @bplreste = @bplqte 
                        select @bplqteres = @bplqte 
                         
                        execute eq_GetSeq_proc 'FBPL',1,@i = @bplseq output 
                             
                        execute eq_CalculTotal_proc  @bplprixhtdev,@bplunitfact,@bplqte,@bplremise1,@bplremise2,@bplremise3,@totalht = @bpltotalhtdev output 
                         
                        if @bpdev <> @Pdevref 
                            select @bpltotalht = @bpltotalhtdev 
                        else 
                            execute eq_CalculTotal_proc  @bplprixht,@bplunitfact,@bplqte,@bplremise1,@bplremise2,@bplremise3,@totalht = @bpltotalht output 
                         
                        select @bplent = @vgent 
                         
                        insert into FBPL (BPLSEQ,BPLCODE,BPLCODEPG,BPLDEPOT,BPLARTICLE,BPLQTE,BPLQTERES,BPLDATE,BPLPRIXHT, 
                                BPLORDRE,BPLUNITFACT,BPLTYPEVE,BPLTYPE,BPLLIBRE,BPLNUM,BPLDEMO,BPLLETTRE,BPLRESTE,BPLLIENCODE, 
                                BPLLIENNUM,BPLCL,BPLTOTALHT,BPLECHSPE,BPLREMISE1,BPLREMISE2,BPLREMISE3,BPLREMISE4,BPLREMISE5, 
                                BPLTYPEMV,BPLUSERCRE,BPLDATECRE,BPLUSERMDF,BPLDATEMDF,BPLFACTMAN,BPLOFFERT,BPLDOTATION,BPLDEV, 
                                BPLCOURSDEV,BPLPRIXHTDEV,BPLTOTALHTDEV,BPLSTADE,BPLENT,BPLATTACHE,BPLEMP,BPLMARCHE) 
                            values     (@bplseq,@bplcode,@bplcodepg,@bpldepot,@bplarticle,@bplqte,@bplqteres,@bpldate,@bplprixht, 
                                @bplordre,@bplunitfact,@bpltypeve,@bpltype,@bpllibre,@bplnum,@bpldemo,@bpllettre,@bplreste,@bplliencode, 
                                @bplliennum,@bplcl,@bpltotalht,@bplechspe,@bplremise1,@bplremise2,@bplremise3,@bplremise4,@bplremise5, 
                                @bpltypemv,@bplusermdf,@bpldatemdf,@bplusercre,@bpldatecre,@bplfactman,@bploffert,@bpldotation,@bpldev, 
                                @bplcoursdev,@bplprixhtdev,@bpltotalhtdev,@bplstade,@bplent,@bplattache,@bplemp,@bplmarche) 
                             
                        if @cccommentaires <> '' and (case when charindex(@cclcode,@bpobservations)>0 then 1 else 0 end)=0 
                                select @bpobservations = @bpobservations + ' +(' + @cclcode + ') ' + @cccommentaires 
                                                                  
                        select @vaqte = @vaqte - @bplqte 
        end 
            end 
        end 
    end 
     
    if @debug = 1 
        select 'debug','fetch boucle',@bpcode,@passage 
 
    fetch LigneCde into     @seq, @cclcl, @ccnom, @ccadr1, @cccp, @ccldev, @cclcode, @vatest2, @vaqte, 
                            @ccldev, @cclcoursdev,@ccnom2,@ccprenom,@ccadr1,@ccadr2,@cccp,@ccville,@ccpy, 
                            @cclarticle,@cclpht,@ccltotalht,@cclunitfact,@ccltv,@ccltype,@ccllibre,@ccechspe, 
                            @cclr1,@cclr2,@cclr3,@cclfactman,@ccloffert,@cclphtdev,@ccltotalhtdev, 
                            @ccfranco,@ccfrancobe,@cclmarche,@arcomp,@cclnum,@clccbe,@cccommentaires, 
                            @cctarif,@cclattache,@artype 
end 
 
/* ********************************************************************************************************* */ 
/*                                 Traitement en fin du BE                                                       */ 
/* ********************************************************************************************************* */ 
if @passage = 1    and @bpcode <> ''                 
begin 
    if @debug = 1 
        select 'debug',"fin BP",@bpcode,"a suivre" 
                 
        /*        Maj de BEMARCHE en fonction du nombre de lignes contenant un BELMARCHE        */ 
        select @countligne = 0 
        select @countligne = count(*) from FBPL where BPLCODE=@bpcode and isnull(BPLMARCHE,"")<>"" 
                 
    if @debug = 1 
        select 'debug','fin BP',@bpcode,'BPMARCHE',@countligne 
                 
    if @countligne > 1 
        update FBP set BPMARCHE=1 where BPCODE=@bpcode and (@ent is null or BPENT=@ent) 
                             
    /*        Recupere BPCC        */ 
    select @bpcc = '',@ccdateliv=null,@cctransporteur='',@ccmodetransp='', @ccprepspecif=0 
    select @countligne = 0 
    select @countligne = count(distinct BPLLIENCODE) from FBPL where BPLCODE=@bpcode and (@ent is null or BPLENT=@ent) 
     
    if @countligne = 1 
    begin 
        select @bpcc = isnull(BPLLIENCODE,'') from FBPL where BPLCODE=@bpcode and (@ent is null or BPLENT=@ent) 
        group by BPLCODE 
         
        select @ccdateliv=CCDATELIV, @cctransporteur=isnull(CCTRANSPORTEUR,''), @ccmodetransp=isnull(CCMODETRANSP,''), 
               @ccprepspecif=isnull(CCPREPSPECIF,0), @ccescompte = isnull(CCESCOMPTE,0), 
               @ccmodeliv = isnull(CCMODELIV,'') 
        from FCC 
        where CCCODE = @bpcc 
    end 
    else 
    if @countligne > 1 
    begin 
        select @ccprepspecif=max(CCPREPSPECIF) 
        from FCC,FBPL 
        where BPLCODE = @bpcode 
        and CCCODE = isnull(BPLLIENCODE,'') 
        and (@ent is null or BPLENT=@ent) 
         
        select @ccdateliv=min(CCDATELIV) 
        from FCC,FBPL 
        where BPLCODE = @bpcode 
        and CCCODE = isnull(BPLLIENCODE,'') 
        and (@ent is null or BPLENT=@ent) 
         
        select @cctransporteur = max(CCTRANSPORTEUR) 
        from FCC,FBPL 
        where BPLCODE = @bpcode 
        and CCCODE = isnull(BPLLIENCODE,'') 
        and (@ent is null or BPLENT=@ent) 
         
        select @ccmodetransp = max(CCMODETRANSP) 
        from FCC,FBPL 
        where BPLCODE = @bpcode 
        and CCCODE = isnull(BPLLIENCODE,'') 
        and (@ent is null or BPLENT=@ent) 
         
        select @ccmodeliv = max(CCMODELIV) 
        from FCC,FBPL 
        where BPLCODE = @bpcode 
        and CCCODE = isnull(BPLLIENCODE,'') 
        and (@ent is null or BPLENT=@ent) 
         
        select @count = 0 
        select @count = count(distinct isnull(CCESCOMPTE,0)) from FCC,FBPL 
                        where BPLCODE=@bpcode 
                        and CCCODE = isnull(BPLLIENCODE,'') 
                        and (@ent is null or BPLENT=@ent) 
     
        if @count = 1 
            select @ccescompte = isnull(CCESCOMPTE,0) from FCC,FBPL 
                        where BPLCODE=@bpcode 
                        and CCCODE = isnull(BPLLIENCODE,'') 
                        and (@ent is null or BPLENT=@ent) 
                        group by CCESCOMPTE 
        else 
            select @ccescompte = 0 
         
    end 
     
    update FBP set     BPESCOMPTE = @ccescompte 
    where BPCODE=@bpcode and (@ent is null or BPENT=@ent) 
                                 
    select @bpechspe = min(BPLECHSPE), @bptotalht = sum(BPLTOTALHT), @bptotalhtdev = sum(BPLTOTALHTDEV) from FBPL 
    where BPLCODE=@bpcode and (@ent is null or BPLENT=@ent) 
                     
    select @bpregle = 0 
    select @bpregle = count(*) from FAR,FBPL where BPLCODE=@bpcode and BPLARTICLE=ARCODE and ARREGLE > 0 and (@ent is null or BPLENT=@ent) 
     
    /*    Ctrl blocage Bon de preparation        */     
    select @bpstade = 1                    /*    A preparer - VALIDE        */ 
    execute eq_CalculStadeBP_proc @ent, @bpcode, @debug, @bpmotifbloc output 
     
    if @bpmotifbloc <> '' 
        select @bpstade = 0            /*    A preparer - BLOQUE            */ 
             
    /*    update FBP        */ 
     
    update FBP set     BPECHSPE=@bpechspe, BPTOTALHT=@bptotalht, BPTOTALHTDEV=@bptotalhtdev, BPREGLE=@bpregle, 
                    BPOBSERVATIONS=@bpobservations, BPCC=@bpcc, BPSTADE=@bpstade, BPMOTIFBLOC = @bpmotifbloc, 
                    BPDATELIV=@ccdateliv, BPTRANSPORTEUR=@cctransporteur, BPMODETRANSP=@ccmodetransp, 
                    BPPREPSPECIF = @ccprepspecif, BPMODELIV = @ccmodeliv 
    where BPCODE=@bpcode and (@ent is null or BPENT=@ent) 
     
    update FBPL  
    set BPLSTADE = BPSTADE 
    from FBP 
    where BPCODE = @bpcode 
    and BPLCODE = BPCODE 
                 
end        /*        @passage = 1    and @bpcode <>      */ 
 
 
/*    nombre de BE traites        */ 
 
if @debug = 1 
    select "Nbre de BP crees : ",@bp_prepares 
 
if @result = 1 
    select @bp_prepares, "BON(S) DE PREPARATION GENERE(S)"   
     
end 




go

