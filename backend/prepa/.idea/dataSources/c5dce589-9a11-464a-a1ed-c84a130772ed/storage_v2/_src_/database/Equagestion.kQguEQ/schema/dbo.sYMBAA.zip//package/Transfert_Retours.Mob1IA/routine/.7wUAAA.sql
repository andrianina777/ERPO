



CREATE PROCEDURE dbo.Transfert_Retours (@depotdepart	char(4),
									@depotarrivee	char(4),
									@datevalide		datetime,
									@article		char(15),
									@lettre			char(4),
									@qte			int,			/* cette quantite est ici negative */
									@code			char(10),
									@piece			varchar(15),
									@empdepart		char(8),
									@emparrivee		char(8)
						   			)
with recompile
as
begin

set arithabort numeric_truncation off


declare @seq		int,
		@lettrefin	char(4),
		@numdep		int,
		@numdep2	int,
		@an			int,
		@mois		int,
		@jour		int,
		@user		int,
		@lettreout	char(4),
		@qtetemp	int

			
select @user=user_id()
select @numdep=DPLOC from FDP where DPCODE=@depotarrivee
select @numdep2=DPLOC from FDP where DPCODE=@depotdepart
select @an=datepart(yy,getdate())*10000
select @mois=datepart(mm,getdate())*100
select @jour=datepart(dd,getdate())
select @qtetemp=abs(@qte)

declare @articleST	char(15),
		@numarm1ST	char(12),
		@numarm2ST	char(12),
		@qteST		int,
		@deviseST	char(3),
		@padevST	numeric(14,2),
		@pahtST		numeric(14,2),
		@fraisST	numeric(14,2),
		@fournST	char(12),
		@lot		char(12)


select @articleST=STAR,@numarm1ST=STNUMARM1,@numarm2ST=STNUMARM2,
	@qteST=STQTE,@deviseST=STDEVISE,@padevST=STPADEV,@pahtST=STPAHT,
	@fraisST=STFRAIS,@fournST=STFO, @lot=isnull(STLOT,'')
from FSTOCK
where STAR=@article
and STLETTRE=@lettre


if @@rowcount > 0
begin
	
	if (@qteST >= @qtetemp)
	begin
	
	/***** Sortie de l''ancien depot ******/
	
	  exec eq_GetSeq_proc 'FSIL', 1, @seq output
	  
	  insert into FSIL (SILSEQ,SILARTICLE,SILQTE,SILDATE,SILNUMARM1,SILNUMARM2,SILDEPOT,
						  SILPADEV,SILPAHT,
						  SILCOMMENT,
						  SILDEVISE,SILLETTRE,SILFRAIS,SILNUMDEP,
						  SILTYPEMV,SILCODE,SILFO,SILLOT,SILEMP)
	  values (@seq,@article,-(@qtetemp),@datevalide,@numarm1ST,@numarm2ST,@depotdepart,
	  		  @padevST,@pahtST,
			  @depotdepart+'=>'+@depotarrivee+' '+@piece,
			  @deviseST,@lettre,@fraisST,@numdep2,
			  'BE',@code,@fournST,@lot,@empdepart)
			  
			  
	/***** Transfert vers le nouveau depot ******/
	
					 
	   exec eq_GetSeq_proc 'FSIL', 1, @seq output
		 
	   insert into FSIL (SILSEQ,SILARTICLE,SILQTE,SILDATE,SILNUMARM1,SILNUMARM2,SILDEPOT,
				   SILPADEV,SILPAHT,SILCOMMENT,
				   SILDEVISE,SILLETTRE,SILFRAIS,SILNUMDEP,
				   SILTYPEMV,SILCODE,SILFO,SILLOT,SILEMP)
	   values (@seq,@article,@qtetemp,@datevalide,@numarm1ST,@numarm2ST,@depotarrivee,
		   @padevST,@pahtST, @depotdepart+'=>'+@depotarrivee+' '+@piece,
		   @deviseST,'',@fraisST,@numdep,
		   'BE',@code,@fournST,@lot,@emparrivee)
		  		
	end
  end
	
end



go

