


create procedure Previsions(@ent			char(5) = null,
							@FromFourn		char(12) = null,
							@ToFourn		char(12) = null,
							@FromFam		char(8) = null,
							@ToFam			char(8) = null,
							@FromDate		datetime = null,
							@ToDate			datetime = null,
							@FromClient		char(12) = null,
							@ToClient		char(12) = null,
							@FromArticle	char(15) = null,
							@ToArticle		char(15) = null,
							@FromRep		char(8) = null,
							@ToRep			char(8) = null,
							@Pays			char(8)	= null)
with recompile
as
begin

if @FromDate is null
begin
select @FromDate=convert(datetime,'01/01/'+convert(char(4),datepart(yy,getdate())))
select @ToDate=convert(datetime,'12/31/'+convert(char(4),datepart(yy,getdate())))
end

select 	RCCARTICLE,ARLIB,ARFAM,FPLIB,
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-1)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-2)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-3)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-4)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-5)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-6)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-7)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-8)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-9)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-10)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-11)))),0),
		isnull(sum(RCCQTE*(1-abs(sign(datepart(mm,RCCDATE)-12)))),0),
		isnull(sum(RCCQTE),0),
		ARREFFOUR
from FCCL,FAR,FFP,FCC,FRCC,FCL
where ARCODE=RCCARTICLE
and CCLSEQ=RCCSEQ
and CLCODE=RCCCL
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and RCCDATE between @FromDate and @ToDate
and FPCODE=ARFAM
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@FromClient is null or RCCCL between @FromClient and @ToClient)
and (@FromFourn is null or ARFO between @FromFourn and @ToFourn)
and (@FromFam is null or ARFAM between @FromFam and @ToFam)
and (@FromArticle is null or RCCARTICLE between @FromArticle and @ToArticle)
and (@FromRep is null or CCREPRES between @FromRep and @ToRep)
and (@Pays is null or CLPY=@Pays)
and (@ent is null or (CCLENT=RCCENT and CCENT=RCCENT and RCCENT=@ent and CLENT=RCCENT))
group by RCCARTICLE,ARLIB,ARFAM,FPLIB,ARREFFOUR
order by ARFAM,RCCARTICLE


end



go

