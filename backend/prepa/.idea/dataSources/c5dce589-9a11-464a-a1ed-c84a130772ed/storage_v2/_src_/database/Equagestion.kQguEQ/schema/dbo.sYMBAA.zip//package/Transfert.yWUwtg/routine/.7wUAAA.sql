/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.Transfert
grant execute on Transfert to public

*/







CREATE PROCEDURE dbo.Transfert (@depotdepart	char(4), 
							@depotarrivee	char(4), 
							@datevalide		datetime, 
							@article		char(15), 
							@numarm1		char(12), 
							@numarm2		char(12), 
							@fourn			char(12), 
							@devise			char(4), 
							@padev			numeric(14,3), 
							@paht			numeric(14,3), 
							@frais			numeric(14,3), 
							@silqte			int, 
							@code			char(10), 
							@comment		char(255), 
							@lettredepart	char(4), 
							@empdepart      char(8), 
							@emparrivee     char(8), 
							@numlot         char(12),
							/*@ssempdepart	char(10),
							@ssemparrivee	char(10),*/
							/*@sil_assur		numeric(14,4),
							@sil_fret		numeric(14,4),	
							@sil_transit	numeric(14,4),	
							@sil_gasyn_pgn	numeric(14,4),	
							@sil_gasyn_tvg	numeric(14,4),	
							@sil_transport	numeric(14,4),	
							@sil_douane		numeric(14,4),	
							@sil_douane_tva	numeric(14,4),
							@sil_autre		numeric(14,4),*/
							@sil_ug			int,
							@sil_motif varchar(50)=null		
								 
						   ) 
with recompile 
as 
begin 
 
set arithabort numeric_truncation off 
 
declare @user		int, 
		@numdep		int, 
		@numdep2	int, 
		@an			int, 
		@mois		int, 
		@jour		int, 
        @seq		int ,
@nb int,@numLigne int
		 
select @user=user_id() 
select @numdep=DPLOC from FDP where DPCODE=@depotarrivee 
select @numdep2=DPLOC from FDP where DPCODE=@depotdepart 
select @an=datepart(yy,getdate())*10000 
select @mois=datepart(mm,getdate())*100 
select @jour=datepart(dd,getdate()) 
		 	 	 
 
/***** Sortie de l''''''''ancien depot ******/		 
	 
exec eq_GetSeq_proc 'FSIL', 1, @seq output 
insert into FSIL (SILSEQ,SILARTICLE,SILQTE,SILDATE,SILNUMARM1,SILNUMARM2,SILDEPOT, 
			    SILPADEV,SILPAHT,SILCOMMENT,SILDEVISE,SILLETTRE,SILFRAIS,SILNUMDEP, 
				SILTYPEMV,SILCODE,SILFO,SILLOT,SILEMP,
				/*SILSSEMP,
				SIL_ASSUR,SIL_FRET,SIL_TRANSIT,SIL_GASYN_PGN,SIL_GASYN_TVG,SIL_TRANSPORT,SIL_DOUANE,SIL_DOUANE_TVA,SIL_AUTRE,*/
				SIL_UG,SIL_MOTIF) 
values (@seq,@article,-@silqte,@datevalide,@numarm1,@numarm2,@depotdepart, 
	  		    @padev,@paht,isnull(@comment,''),@devise,@lettredepart,@frais,@numdep2, 
			    'TD',@code,@fourn,@numlot,@empdepart,
			    /*@ssempdepart,
			    @sil_assur,@sil_fret,@sil_transit,@sil_gasyn_pgn,@sil_gasyn_tvg,@sil_transport,@sil_douane,@sil_douane_tva,@sil_autre,*/
			    isnull(@sil_ug,0),isnull(@sil_motif,'')) 
			   
/***** Transfert vers le nouveau depot - nota : creation code lettre dans trigger FSIL ******/ 
	 
exec eq_GetSeq_proc 'FSIL', 1, @seq output 
insert into FSIL (SILSEQ,SILARTICLE,SILQTE,SILDATE,SILNUMARM1,SILNUMARM2,SILDEPOT, 
					  SILPADEV,SILPAHT,SILCOMMENT,SILDEVISE,SILLETTRE,SILFRAIS,SILNUMDEP, 
					  SILTYPEMV,SILCODE,SILFO,SILLOT,SILEMP,
					  --SILSSEMP,
					  --SIL_ASSUR,SIL_FRET,SIL_TRANSIT,SIL_GASYN_PGN,SIL_GASYN_TVG,SIL_TRANSPORT,SIL_DOUANE,SIL_DOUANE_TVA,SIL_AUTRE,
					  SIL_UG,SIL_MOTIF) 
values (@seq,@article,@silqte,@datevalide,@numarm1,@numarm2,@depotarrivee, 
			  @padev,@paht,isnull(@comment,''),@devise,'',@frais,@numdep, 
			  'TD',@code,@fourn,@numlot,@emparrivee,
			  --@ssemparrivee,
			  --@sil_assur,@sil_fret,@sil_transit,@sil_gasyn_pgn,@sil_gasyn_tvg,@sil_transport,@sil_douane,@sil_douane_tva,@sil_autre,
			  isnull(@sil_ug,0),isnull(@sil_motif,'')) 

/*insert Emplcement dans FARE s' il n'existe*/

 declare @empDigue varchar(50)
        select @nb=0
        select @nb=count(*) from xEMP_DIGUEL where xEMPL=@emparrivee and xDEPOTL=@depotarrivee
        
        if (@nb=1)
        begin
                exec x_ExisteFARE @article,@depotarrivee,@emparrivee,'DIGUE'
        end
        
 --x_ExisteFARE(@pArticle varchar(50), @pDepot varchar(50) ,@empl varchar(20),@ssemp varchar(50))
 /*if(@depotdepart='SAS')
	begin
		exec bp_Update_TD_Sas_Det @depotdepart,@article,@lettredepart,@empdepart,@silqte
	end
*/
end
go

