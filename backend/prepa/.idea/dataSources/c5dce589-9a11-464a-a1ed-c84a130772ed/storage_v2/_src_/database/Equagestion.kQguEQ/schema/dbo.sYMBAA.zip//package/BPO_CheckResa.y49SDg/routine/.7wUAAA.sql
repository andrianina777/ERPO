


create proc BPO_CheckResa
as
begin

	/* rercherche et suppression des dates de reservation arrivees a echeances */
	/* *********************************************************************** */

	select CCLCODE,CCLNUM,CCLCL,CCLDATE,CCLQTE,CCLQTEEXP,CCLQTERES from FCCL
	where CCLDATERESFIN<=getdate() and CCLQTERES>0

	update FCCL set CCLQTERES=null,CCLDATERESFIN=null,CCLDEPOTRES=null 
	where CCLDATERESFIN<=getdate() and CCLQTERES>0

	/* recherche et presentation des incoherences de reservations (dans le cas d''un mouvement de stock annexe) */
	/* ******************************************************************************************************* */

	select RCCARTICLE,RCCDEPOTRES,QTERES=sum(isnull(RCCQTERES,0)) into #resa from FRCC
	group by RCCARTICLE,RCCDEPOTRES 

	select STAR,STDEPOT,QTESTOCK=sum(isnull(STQTE,0)) into #stock from FSTOCK
	group by STAR,STDEPOT

	select STAR,STDEPOT,QTERES,QTESTOCK,QTESTOCK-QTERES from #resa,#stock 
	where STAR=RCCARTICLE and STDEPOT=RCCDEPOTRES and QTERES>QTESTOCK
end



go

