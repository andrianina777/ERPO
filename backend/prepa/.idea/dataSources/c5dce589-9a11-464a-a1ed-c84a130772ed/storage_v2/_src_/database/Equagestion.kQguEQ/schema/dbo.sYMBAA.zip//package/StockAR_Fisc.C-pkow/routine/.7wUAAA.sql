CREATE PROCEDURE dbo.StockAR_Fisc (@article		char(15),
						  @date1		smalldatetime,
						  @depot		char(4) = null,
						  @lettre		char(4) = null
						  )
with recompile
as
begin

 declare @id char(32),@qtestock_tmp int,@qtestockres_tmp int


create table #Stockinit
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null
)

create table #Stockperiode
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null,
ent				char(5)			null,
tiers			char(12)	null
)

create table #Stockfinal
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null,
ent				char(5)			null,
tiers			char(12)	null
)

create table #Resultats
(
seq				numeric(14,0)	identity,
tri				tinyint			not null,
date			datetime		not null,
piece			varchar(20)		not null,
qtestock		int				not null,
qtestockres		int				not null,
total			int				not null,
totavecres		int				not null,
ent				char(35)				null,
tiers			char(12)	null,
piece_liee varchar(20) null
)


/*********** AVANT ******************/

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(SILQTE),0),0
from FSIL
where SILARTICLE=@article
--and SILDATE < @date1
and SILDATESIMPLE<convert(date,@date1)
and (@depot is null or SILDEPOT = @depot)
and (@lettre is null or SILLETTRE = @lettre)


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(BLLQTE),0),0
from FBLL
where BLLAR=@article
and BLLDATE < @date1
and isnull(BLLLET,'') != ''
and (@depot is null or BLLDEP = @depot)
and (@lettre is null or BLLLET = @lettre)


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(DOLQTE),0),0
from FDOL
where DOLAR=@article
and DOLDATE < @date1
and (@depot is null or DOLDEP = @depot)
and (@lettre is null or DOLLET = @lettre)


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(ASLQTE),0),0
from FASL
where ASLARTICLE=@article
and ASLDATE < @date1
and (@depot is null or ASLDEPOT = @depot)
and (@lettre is null or ASLLETTRE = @lettre)


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(-sum(RFLQTE),0),0
from FRFL
where RFLARTICLE=@article
and RFLDATE < @date1
and (@depot is null or RFLDEPOT = @depot)
and (@lettre is null or RFLLETTRE = @lettre)


/* ''Reajustements - Fichier RJL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(RJLQTE),0),0
from FRJL
where RJLARTICLE=@article
and RJLDATE < @date1
and (@depot is null or RJLDEPOT = @depot)
and (@lettre is null or RJLLETTRE = @lettre)


/* ''Lignes de casse - Fichier LCL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(LCLQTE),0),0
from FLCL
where LCLARTICLE=@article
and LCLDATE < @date1
and (@depot is null or LCLDEPOT = @depot)
and (@lettre is null or LCLLETTRE = @lettre)


/* ""Lignes de BE - Fichier FBEL"" */

if (@depot is null)
begin
  insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
  select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0)
  from FBEL
  where BELARTICLE=@article
  and BELDATE < @date1
  and BELENT='FR'
  and (@lettre is null or BELLETTRE = @lettre)
end
else if (@depot is not null)
begin


  insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
  select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0)
  from FBEL,FSTOCK
  where BELARTICLE=@article
  and BELDATE < @date1
  and BELARTICLE=STAR
  and BELLETTRE=STLETTRE
  and STDEPOT=@depot
  and BELENT='FR'
  and (@lettre is null or BELLETTRE = @lettre)
  
end

/* ''Atelier - Fichier FWL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(WLQTE),0),0
from FWL
where WLARCODE=@article
and WLDATE < @date1
and isnull(WLSTOCK,'') <> ''
and (@depot is null or WLDPCODE = @depot)
and (@lettre is null or WLSTOCK = @lettre)


delete from #Stockinit
where qtestock = 0
and qtestockres = 0


/********************** PENDANT ************************/

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select 'SI',1,convert(date,SILDATE),SILCODE,isnull(sum(SILQTE),0),0,'',SILFO--,SILDATEENTR
from FSIL
where SILARTICLE=@article
and SILDATE >= @date1
and (@depot is null or SILDEPOT = @depot)
and (@lettre is null or SILLETTRE = @lettre)
group by convert(date,SILDATE),SILCODE,SILFO--,SILDATEENTR


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'BL',2,convert(date,BLLDATE),BLLCODE,isnull(sum(BLLQTE),0),0,BLLENT,BLLFO--,BLLDATECRE
from FBLL
where BLLAR=@article
and BLLDATE >= @date1
and isnull(BLLLET,'') != ''
and (@depot is null or BLLDEP = @depot)
and (@lettre is null or BLLLET = @lettre)
group by convert(date,BLLDATE),BLLCODE,BLLENT,BLLFO--,BLLDATECRE


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'DO',3,convert(date,DOLDATE),DOLCODE,isnull(sum(DOLQTE),0),0,DOLENT,DOLFO--,DOLDATECRE
from FDOL
where DOLAR=@article
and DOLDATE >= @date1
and (@depot is null or DOLDEP = @depot)
and (@lettre is null or DOLLET = @lettre)
group by convert(date,DOLDATE),DOLCODE,DOLENT,DOLFO--,DOLDATECRE


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'AS',4,convert(date,ASLDATE),ASLCODE,isnull(sum(ASLQTE),0),0,'',ASLFO--,ASLDATECRE
from FASL
where ASLARTICLE=@article
and ASLDATE >= @date1
and (@depot is null or ASLDEPOT = @depot)
and (@lettre is null or ASLLETTRE = @lettre)
group by convert(date,ASLDATE),ASLCODE,ASLFO--,ASLDATECRE


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'RF',5,convert(date,RFLDATE),RFLCODE,isnull(-sum(RFLQTE),0),0,RFLENT,RFLFO--,RFLDATECRE
from FRFL
where RFLARTICLE=@article
and RFLDATE >= @date1
and (@depot is null or RFLDEPOT = @depot)
and (@lettre is null or RFLLETTRE = @lettre)
group by convert(date,RFLDATE),RFLCODE,RFLENT,RFLFO--,RFLDATECRE


/* ''Reajustements - Fichier RJL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'RJ',6,convert(date,RJLDATE),RJLCODE,isnull(sum(RJLQTE),0),0,'',''--,RJLDATECRE
from FRJL
where RJLARTICLE=@article
and RJLDATE >= @date1
and (@depot is null or RJLDEPOT = @depot)
and (@lettre is null or RJLLETTRE = @lettre)
group by convert(date,RJLDATE),RJLCODE--,RJLDATECRE


/* ''Lignes de casse - Fichier LCL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'LC',7,convert(date,LCLDATE),LCLCODE,isnull(sum(LCLQTE),0),0,'',LCLFO--,LCLDATECRE
from FLCL
where LCLARTICLE=@article
and LCLDATE >= @date1
and (@depot is null or LCLDEPOT = @depot)
and (@lettre is null or LCLLETTRE = @lettre)
group by convert(date,LCLDATE),LCLCODE,LCLFO--,LCLDATECRE


/* ""Lignes de BE - Fichier FBEL"" */

if (@depot is null)
begin
  insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
  select 'BE',8,convert(date,BELDATE),BELCODE,isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0),
		  BELENT,BELCL--,BELDATECRE
  from FBEL
  where BELARTICLE=@article
  and BELDATE >= @date1
  and (@lettre is null or BELLETTRE = @lettre)
  and BELENT='FR'
  group by convert(date,BELDATE),BELCODE,BELENT,BELCL--,BELDATECRE
end
else if (@depot is not null)
begin



  insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
  select 'BE',8,convert(date,BELDATE),BELCODE,isnull(-sum(BELQTE),0),
		  isnull(sum(case when isnull(BELSTADE,0) < 2 then BELQTE else 0 end),0),
		  BELENT,BELCL--,BELDATECRE
  from FBEL,FSTOCK
  where BELARTICLE=@article
  and BELDATE >= @date1
  and BELARTICLE=STAR
  and BELLETTRE=STLETTRE
  and STDEPOT=@depot
  and BELENT='FR'
  and (@lettre is null or BELLETTRE = @lettre)
  group by convert(date,BELDATE),BELCODE,BELENT,BELCL--,BELDATECRE
 
  
end

/* ''Atelier - Fichier FWL'' */

insert into #Stockperiode (type,tri,date,piece,qtestock,qtestockres,ent,tiers)--,datecre)
select 'WL',9,convert(date,WLDATE),WLCODE,isnull(sum(WLQTE),0),0,WLENT,WLCL--,WLDATE         
from FWL
where WLARCODE=@article
and WLDATE >= @date1
and isnull(WLSTOCK,'') <> ''
and (@depot is null or WLDPCODE = @depot)
and (@lettre is null or WLSTOCK = @lettre)
group by convert(date,WLDATE),WLCODE,WLENT,WLCL--,WLDATE


delete from #Stockperiode
where qtestock = 0
and qtestockres = 0



/*select type, tri, date, piece, qtestock, qtestockres, ent, tiers, datecre 
from #Stockperiode

select type, tri, date, piece,sum(qtestock) as qtestock,sum(qtestockres) as qtestockres,ent, tiers, datecre 
from #Stockperiode
group by type, tri, date, piece,ent, tiers, datecre 
order by datecre
*/

/******************** Final ********************/



insert into #Stockfinal (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select type,tri,date,piece,sum(qtestock),sum(qtestockres),'',''
from #Stockinit
group by type,tri,date,piece
order by date,tri,piece

insert into #Stockfinal (type,tri,date,piece,qtestock,qtestockres,ent,tiers)
select type,tri,date,piece,sum(qtestock),sum(qtestockres),ent,tiers
from #Stockperiode
group by type,tri,date,piece,ent,tiers
order by date,tri,piece,ent
--order by datecre,tri asc--,piece,ent


create index tri on #Stockfinal (date,tri,piece,ent,tiers)


drop table #Stockinit
drop table #Stockperiode

declare stock cursor 
for select tri,date,piece,qtestock,qtestockres,ent,tiers
from #Stockfinal
order by date,tri,piece,ent,tiers
for read only

declare @tri			tinyint,
		@date			datetime,
		@piece			varchar(20),
		@qtestock		int,
		@qtestockres	int,
		@total			int,
		@totavecres		int,
		@ent			char(5),
		@tiers			char(12)

select 	@total = 0,
		@totavecres = 0

open stock

fetch stock
into @tri,@date,@piece,@qtestock,@qtestockres,@ent,@tiers

while (@@sqlstatus = 0)
	begin
	
	select 	@total = @total + @qtestock,
			@totavecres = @totavecres + @qtestock + @qtestockres
	
	insert into #Resultats (tri,date,piece,qtestock,qtestockres,total,totavecres,ent,tiers)
	values (@tri,@date,@piece,@qtestock,@qtestockres,@total,@totavecres,@ent,@tiers)
	
	fetch stock
	into @tri,@date,@piece,@qtestock,@qtestockres,@ent,@tiers
	
end

close stock
deallocate cursor stock

drop table #Stockfinal

update #Resultats
set piece_liee=BELLIENCODE
from FBEL
where piece like 'BE%'
and BELCODE=piece
and BELARTICLE=@article

update #Resultats
set ent='VENTE-> '+CLNOM1 
from FCL 
where CLCODE=tiers
and piece like 'BE%'

update #Resultats
set ent='ENTREE_FNRS' 
where piece like 'BL%'

update #Resultats
set ent='DESTRUCTION' 
where piece like 'LC%'

update #Resultats
set ent='REAJUSTEMENT' 
where piece like 'RJ%'

update #Resultats
set ent='STOCK INITIAL' 
where piece like 'SI%'


 
/*select seq,@depot,@article as article,convert(date,date) as date,
(case when isnull(piece_liee,'')='' then piece else rtrim(piece)+' / '+rtrim(piece_liee) end),
qtestock as qte,total as Stock,ent,tiers
from #Resultats
order by seq
*/
declare @seq int,@reference varchar(50),@depot_dest varchar(50)

declare liste cursor for select seq,piece from #Resultats where ent='' and (piece like 'TD%' or piece like 'TS%') order by seq
open liste
fetch liste into @seq,@reference
while (@@sqlstatus=0)
begin

        select distinct @depot_dest=SILDEPOT from FSIL where SILCODE=@reference and SILDEPOT <>@depot and SILARTICLE=@article
        
        update #Resultats set tiers=@depot_dest where seq=@seq
fetch liste into @seq,@reference

end
close liste 
deallocate cursor liste


update #Resultats
set ent='TRANSFERT_DEPOT'
from FSIL where SILCODE=piece
and (piece like 'TD%' or piece like 'TS%') and SILARTICLE=@article
/*and SILQTE=(-1*qtestock)*/

select seq,@depot as depot ,@article as article,convert(date,date) as date,
(case when isnull(piece_liee,'')='' then piece else rtrim(piece) end)as reference,
qtestock as qte,total as Stock,ent as nature,tiers,convert(varchar(50),null) as Facture
into #Final
from #Resultats
order by seq

 create index FIN_idx0001 on #Final(article)
 create index FIN_idx0002 on #Final(reference)


/*detection numero facture VENTE*/
select article,reference 
into #vente
from #Final 
where reference like 'BE%' order by seq

create index VTE_idx0001 on #vente(article)
create index VTE_idx0002 on #vente(reference)

select distinct FALCODE,FALLIENCODE 
into #facture
from FFAL,#vente
where FALLIENCODE=reference and FALARTICLE=article

create index CDE_idx0001 on #facture(FALCODE)
create index CDE_idx0002 on #facture(FALLIENCODE)

update #Final set Facture=FALCODE
from #Final,#facture
where reference=FALLIENCODE


/*detection facture fournisseur*/
select article,reference 
into #achat
from #Final 
where reference like 'BL%' order by seq

create index ACH_idx0001 on #achat(article)
create index ACH_idx0002 on #achat(reference)

select distinct FFLCODE,FFLLIENCODE 
into #factureFF
from FFFL,#achat
where FFLLIENCODE=reference and FFLAR=article

create index FF_idx0001 on #factureFF(FFLCODE)
create index FF_idx0002 on #factureFF(FFLLIENCODE)


update #Final set Facture=FFLCODE
from #Final,#factureFF
where reference=FFLLIENCODE

/*Destruction*/
select article,reference 
into #destruct
from #Final 
where reference like 'LC%' order by seq

create index DES_idx0001 on #destruct(article)
create index DES_idx0002 on #destruct(reference)

select distinct LCLCODE,LCLDEPOT 
into #Ligne_casse
from FLCL,#destruct
where LCLCODE=reference and LCLARTICLE=article

update #Final set tiers=LCLDEPOT
from #Final,#Ligne_casse
where reference=LCLCODE

/*verifier s'il ny a pas de MVT*/
declare @nb int

select @nb=0

select @nb=count(*) from #Final
if (@nb>1)
begin
        insert into DBSUIVI..FICHE_STOCK (seq, depot, article, date, reference, qte, Stock, nature, tiers, Facture )  
        select convert(int,seq) as seq, depot, article, date, reference, qte, Stock, nature, tiers, isnull(Facture,'') as Facture 
        --into DBSUIVI..FICHE_STOCK
        from #Final
end

drop table #Resultats
drop table #Final
drop table #facture
drop table #vente
drop table #factureFF
drop table #achat
drop TABLE #Ligne_casse

end
go

