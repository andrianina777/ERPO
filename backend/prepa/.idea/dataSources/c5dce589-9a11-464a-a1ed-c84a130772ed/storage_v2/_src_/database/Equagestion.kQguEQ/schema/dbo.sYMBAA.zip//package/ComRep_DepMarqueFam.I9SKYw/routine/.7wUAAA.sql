
create procedure ComRep_DepMarqueFam (@Rep 			char(8),
									  @TypeDate		tinyint,		/* 0 = mois d'une annee - 1 = entre deux dates */
									  @AnneeFact	char(4),
									  @MoisFact		int,
									  @DateDeb		smalldatetime,	
									  @DateFin		smalldatetime
									 )
with recompile
as
begin

/* Version du 14 03 08 */

set arithabort numeric_truncation off

if @TypeDate=0
begin
	declare @FactAnMois char(9)
	if @MoisFact<10 
		select @FactAnMois='FA'+right(@AnneeFact,2)+'0'+convert(char,@MoisFact)
	else 
		select @FactAnMois='FA'+right(@AnneeFact,2)+convert(char,@MoisFact)

	select @FactAnMois=rtrim(@FactAnMois)+'%'
end

declare @TypeRep	tinyint
select 	@TypeRep=RETYPE from FREP where RECODE=@Rep


create table #LignesCom
(	
LCdepartement	char(8)				null,	/* Utile pour entete seulement : correspond a une ligne de FCOM */
LCmarque		char(12)			null,	/* Utile pour entete seulement : correspond a une ligne de FCOM */
LCfamille		char(8)				null,	/* Utile pour entete seulement : correspond a une ligne de FCOM */
LCarticle		char(15)		not null,
LCcom			numeric(8,4)		null
)

insert into #LignesCom
select COMDEPART,COMMARQUE,COMFAM,ARCODE,COMPC
from FAR,FCOM 
where COMCODEREP=@Rep
and (isnull(COMDEPART,'')="" or COMDEPART=ARDEPART)
and (isnull(COMMARQUE,'')="" or COMMARQUE=ARFO)
and (isnull(COMFAM,'')="" or COMFAM=ARFAM)


create table #LignesFactures
(	
Departement			char(8)				null,	/* Utile pour entete seulement : correspond a une ligne de FCOM */
Marque				char(12)			null,	/* Utile pour entete seulement : correspond a une ligne de FCOM */
Famille				char(8)				null,	/* Utile pour entete seulement : correspond a une ligne de FCOM */
CodeFacture			char(10)		not null,
DateFact			datetime			null,
CodeClient			char(12)		not null,
NomClient			char(35)			null,
CodeArticle			char(15)		not null,
TotLigneHT			numeric(8,4)		null,
Escompte			real				null,
TotLigneHTesc		numeric(8,4)		null,
TauxCom				numeric(8,4)		null,
MontantCom			numeric(8,4)		null,
DateEch1			datetime			null,
DateEch2			datetime			null,
DateEch3			datetime			null,
DateEch4			datetime			null,
TauxEch1			real				null,
TauxEch2			real				null,
TauxEch3			real				null,
TauxEch4			real				null
)

declare 	@departement	char(8),		
			@marque			char(12),
			@famille		char(8),
			@article		char(15),
			@com			numeric(8,4)	


	declare CursLignesCom cursor 
	for select LCdepartement,LCmarque,LCfamille,LCarticle,LCcom
	from #LignesCom

	open CursLignesCom

	fetch CursLignesCom
	into @departement,@marque,@famille,@article,@com

	while (@@sqlstatus = 0)
		begin
	
		insert into #LignesFactures 
						(Departement,Marque,Famille,
						CodeFacture,DateFact,CodeClient,NomClient,CodeArticle,
						TotLigneHT,Escompte,TotLigneHTesc,
						TauxCom,MontantCom,
						DateEch1,DateEch2,DateEch3,DateEch4,TauxEch1,TauxEch2,TauxEch3,TauxEch4)
		select 	@departement,@marque,@famille,
						FACODE,FADATE,FACL,FANOM,FALARTICLE,
						isnull(FALTOTALHT,0),isnull(FATAUXESC,0),isnull(FALTOTALHT,0)*(1-isnull(FATAUXESC,0)),
						@com,isnull(FALTOTALHT,0)*(1-isnull(FATAUXESC,0))*@com,
						FATRDATE1,FATRDATE2,FATRDATE3,FATRDATE4,FAPC1,FAPC2,FAPC3,FAPC4
		from FFA,FFAL
		where FALCODE=FACODE
		and FALARTICLE=@article
		
		and (@TypeRep=2 or FALREP=@Rep)
		and (@TypeRep<>2 or FALREPDIV=@Rep) /* @TypeRep=2 : Division */
		
		and (@TypeDate=1 or FACODE like @FactAnMois)
		and (@TypeDate=0 or FADATE between @DateDeb and @DateFin)

		fetch CursLignesCom
		into @departement,@marque,@famille,@article,@com
	
	end

	close CursLignesCom
	deallocate cursor CursLignesCom


select 	Departement,Marque,Famille,
				CodeFacture,DateFact,CodeClient,NomClient,
				sum(TotLigneHTesc),sum(MontantCom),
				DateEch1,DateEch2,DateEch3,DateEch4,TauxEch1,TauxEch2,TauxEch3,TauxEch4
from #LignesFactures
group by Departement,Marque,Famille,CodeFacture,DateFact,CodeClient,NomClient,DateEch1,DateEch2,DateEch3,DateEch4,TauxEch1,TauxEch2,TauxEch3,TauxEch4
order by Departement,Marque,Famille,CodeFacture,NomClient,DateEch1,DateEch2,DateEch3,DateEch4

drop table #LignesCom
drop table #LignesFactures

end
go

