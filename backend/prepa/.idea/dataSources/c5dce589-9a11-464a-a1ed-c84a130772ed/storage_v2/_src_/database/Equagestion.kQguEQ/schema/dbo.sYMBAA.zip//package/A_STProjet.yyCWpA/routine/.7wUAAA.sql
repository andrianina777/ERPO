


/* Procedure permettant de generer les stocks projetes sur les 12 prochains mois */

create procedure A_STProjet
with recompile
as
begin

declare @date1	datetime
declare @date2	datetime
declare @Mois	tinyint
declare @An		smallint
declare @i		tinyint

declare @MoisEnCours	tinyint
declare @Annee			smallint

select @Mois=datepart(mm,getdate())
select @An=datepart(yy,getdate())


declare @dif	int
select @dif=((@An-1992)*12)+@Mois


/****** boucle de delete des lignes a remplacer *****/

declare @rc		int,
		@base	varchar(30)

select @base=db_name()
dump tran @base with truncate_only

set rowcount 1000
select @rc=1
while @rc>0
begin
	delete FSK where SKDIF>@dif
	select @rc=@@rowcount
	dump tran @base with truncate_only
end
set rowcount 0

/****** fin boucle de delete des lignes a remplacer *****/


select @Mois=@Mois + 1
  
if @Mois=13
  begin
	select @Mois = 1
	select @An = @An+1
	select @MoisEnCours = 12
	select @Annee = @An-1
  end
else
  begin
	select @MoisEnCours = @Mois-1
	select @Annee = @An
  end


select @date1=convert(datetime,convert(char(2),@MoisEnCours)+"/01/"+convert(char(4),@Annee))
select @date2=dateadd(mm,1,@date1)
select @date2=dateadd(dd,-1,@date2)


create table #Stock
(
Article		char(15)	not null,
Qte			int			not null
)

/* traitement du mois en cours */


insert into #Stock (Article,Qte)
select STAR, sum(STQTE)
from FSTOCK
where STQTE > 0
group by STAR


insert into #Stock (Article,Qte)
select RCFARTICLE, sum(RCFQTE)
from FRCF
where RCFQTE > 0
and RCFDATE <= @date2
group by RCFARTICLE


insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
select @An, @Mois, Article, sum(Qte), ((@An-1992)*12)+@Mois, getdate()
from #Stock
group by Article

/* fin de traitement du mois en cours */

/* Insertion des 11 mois suivants */


select @i=1

while (@i <= 11)
begin

  select @Mois=@Mois + 1
  
  if @Mois=13
	begin
	  select @Mois = 1
	  select @An = @An+1
	  select @MoisEnCours = 12
	  select @Annee = @An-1
	end
  else
	begin
	  select @MoisEnCours = @Mois-1
	  select @Annee = @An
	end
  
  
  insert into #Stock (Article,Qte)
  select RCFARTICLE, sum(RCFQTE)
  from FRCF
  where RCFQTE > 0
  and RCFMOIS = @MoisEnCours
  and RCFAN = @Annee
  group by RCFARTICLE
   
    
  insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
  select @An, @Mois, Article, sum(Qte), ((@An-1992)*12)+@Mois, getdate()
  from #Stock
  group by Article
  
  select @i = @i+1

end

drop table #Stock

end



go

