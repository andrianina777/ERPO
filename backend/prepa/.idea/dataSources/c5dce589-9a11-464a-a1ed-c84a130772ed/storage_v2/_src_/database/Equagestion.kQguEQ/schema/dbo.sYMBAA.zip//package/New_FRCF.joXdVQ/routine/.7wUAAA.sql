


/* Procedure permettant de recreer le fichier des ""reste a recevoir"" fournisseurs */

create procedure New_FRCF
with recompile
as
begin

	truncate table FRCF
	
	insert into FRCF (RCFSEQ,RCFARTICLE,RCFDATE,RCFMOIS,RCFAN,RCFQTE,RCFFO,RCFENT)
	select CFLSEQ,CFLARTICLE,
			isnull(CFLDATEP,dateadd(dd,30,CFDATE)),
			datepart(mm,isnull(CFLDATEP,dateadd(dd,30,CFDATE))),
			datepart(yy,isnull(CFLDATEP,dateadd(dd,30,CFDATE))),
			CFLRESTE,CFLFO,CFLENT
	from FCFL,FCF
	where CFLCODE=CFCODE
	and CFLRESTE > 0
	
end



go

