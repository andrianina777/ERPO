


/* Renvoie les remises d''un client sur un article a travers RC_CL */

create procedure RC_CL_Omnis   (@ent		char(5) = null,
								@client		char(12),
								@annee		smallint,
								@article	char(15)
								)
with recompile
as
begin

set arithabort numeric_truncation off


declare @rcr1	numeric(8,4),
		@rcr2	numeric(8,4),
		@rcr3	numeric(8,4)


execute RC_CL @ent,@client,@annee,@article,@rcr1 output,@rcr2 output,@rcr3 output

select @rcr1,@rcr2,@rcr3

end



go

