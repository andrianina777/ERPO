

                                                                               
create procedure NumComptaLibre	(@prefixe	varchar(13),
								 @type		int	= 0 )
as
begin

	set arithabort numeric_truncation off

	declare @numprecedant	char(12)

	select  @numprecedant=""
	select  @prefixe = @prefixe + "%"
	if @type = 0
	begin

		declare numeros cursor
		for select CLNUMCOMPTABLE
		from FCL
		where CLNUMCOMPTABLE like @prefixe
		and charindex('A',CLNUMCOMPTABLE) = 0
		and charindex('B',CLNUMCOMPTABLE) = 0
		and charindex('C',CLNUMCOMPTABLE) = 0
		and charindex('D',CLNUMCOMPTABLE) = 0
		and charindex('E',CLNUMCOMPTABLE) = 0
		and charindex('F',CLNUMCOMPTABLE) = 0
		and charindex('G',CLNUMCOMPTABLE) = 0
		and charindex('H',CLNUMCOMPTABLE) = 0
		and charindex('I',CLNUMCOMPTABLE) = 0
		and charindex('J',CLNUMCOMPTABLE) = 0
		and charindex('K',CLNUMCOMPTABLE) = 0
		and charindex('L',CLNUMCOMPTABLE) = 0
		and charindex('M',CLNUMCOMPTABLE) = 0
		and charindex('N',CLNUMCOMPTABLE) = 0
		and charindex('O',CLNUMCOMPTABLE) = 0
		and charindex('P',CLNUMCOMPTABLE) = 0
		and charindex('Q',CLNUMCOMPTABLE) = 0
		and charindex('R',CLNUMCOMPTABLE) = 0
		and charindex('S',CLNUMCOMPTABLE) = 0
		and charindex('T',CLNUMCOMPTABLE) = 0
		and charindex('U',CLNUMCOMPTABLE) = 0
		and charindex('V',CLNUMCOMPTABLE) = 0
		and charindex('W',CLNUMCOMPTABLE) = 0
		and charindex('X',CLNUMCOMPTABLE) = 0
		and charindex('Y',CLNUMCOMPTABLE) = 0
		and charindex('Z',CLNUMCOMPTABLE) = 0
		order by CLNUMCOMPTABLE

		declare @code	char(12)

		open numeros

		fetch numeros into @code
		select  @numprecedant=@code

		while (@@sqlstatus = 0)
		begin

			if convert(numeric(12,0),@code)-convert(numeric(12,0),@numprecedant)>1
			begin
				select @numprecedant
				return (0)
			end
			else
			begin
				select @numprecedant=@code
			end

			fetch numeros into @code
		end
	end
	else if @type=1
	begin

		select @code=max(CLNUMCOMPTABLE)
		from FCL
		where CLNUMCOMPTABLE like @prefixe
		and charindex('A',CLNUMCOMPTABLE) = 0
		and charindex('B',CLNUMCOMPTABLE) = 0
		and charindex('C',CLNUMCOMPTABLE) = 0
		and charindex('D',CLNUMCOMPTABLE) = 0
		and charindex('E',CLNUMCOMPTABLE) = 0
		and charindex('F',CLNUMCOMPTABLE) = 0
		and charindex('G',CLNUMCOMPTABLE) = 0
		and charindex('H',CLNUMCOMPTABLE) = 0
		and charindex('I',CLNUMCOMPTABLE) = 0
		and charindex('J',CLNUMCOMPTABLE) = 0
		and charindex('K',CLNUMCOMPTABLE) = 0
		and charindex('L',CLNUMCOMPTABLE) = 0
		and charindex('M',CLNUMCOMPTABLE) = 0
		and charindex('N',CLNUMCOMPTABLE) = 0
		and charindex('O',CLNUMCOMPTABLE) = 0
		and charindex('P',CLNUMCOMPTABLE) = 0
		and charindex('Q',CLNUMCOMPTABLE) = 0
		and charindex('R',CLNUMCOMPTABLE) = 0
		and charindex('S',CLNUMCOMPTABLE) = 0
		and charindex('T',CLNUMCOMPTABLE) = 0
		and charindex('U',CLNUMCOMPTABLE) = 0
		and charindex('V',CLNUMCOMPTABLE) = 0
		and charindex('W',CLNUMCOMPTABLE) = 0
		and charindex('X',CLNUMCOMPTABLE) = 0
		and charindex('Y',CLNUMCOMPTABLE) = 0
		and charindex('Z',CLNUMCOMPTABLE) = 0
	end

	select @code

end



go

