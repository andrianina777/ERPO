/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_LiberationBac
grant all on bp_LiberationBac to public
*/

CREATE PROCEDURE dbo.bp_LiberationBac(
		@bac char(3))
with recompile
AS
begin
	 declare
	 	@transf int,
	 	@count int,
	 	@nb_bac int,
	 	@codeBP char(10),
	 	@commentaire varchar(255)
	 	
	 	select @count =0,@commentaire=''
	 	
	 	select @count=count(*),@transf=isnull(CCBACETAT,0) from h_CCBAC where CCBACNUM=@bac group by CCBACNUM
	 	
	 	


	 	
	 	if(@count=0)
	 	begin
	 		select @commentaire='NUMERO BAC INVALIDE'
	 	end
	 	else if((@count=1) and (@transf=0))
	 	begin
	 		select @commentaire='BAC '||@bac||' est déjà libéré'
	 	end
	 	else
	 	begin
	 		select @codeBP=CCBACLBP from h_CCBACL inner join h_CCBAC on CCBACLNUMBAC=CCBACNUM  inner join FBP on BPCODE=CCBACLBP inner join VIEW_COMMANDE_ENCOURS on CODE=BPCC 
        	where BPPREPSPECIF<2 and CCBACLNUMBAC=@bac and isnull(CCBACLTRANSFERE,0)=0
        	
        	select @nb_bac=count(*) from h_CCBACL inner join h_CCBAC on CCBACLNUMBAC=CCBACNUM  
        	where  isnull(CCBACLTRANSFERE,0)=0 and CCBACLBP=@codeBP
        	group by CCBACLBP
        	
	 		if((@nb_bac<2) and (@count=1))
		 	begin
		 		select @commentaire='IMPOSSIBLE DE LIBERER UN BAC(au moins un bac dans un BP) '||@codeBP
		 	end
		 	else if((@count=1) and (@transf=1) and (@nb_bac>1))
		 	begin
		 		 update  h_CCBACL set CCBACLTRANSFERE=1 where CCBACLBP=@codeBP and CCBACLNUMBAC=@bac
	 			 update h_CCBAC set CCBACETAT=0 where CCBACNUM=@bac
	 			 
	 			 select @commentaire='succes'
		 	end
		 	else
		 	begin
		 		select @commentaire='Bac invalide'
		 	end
	 	end
		select @commentaire
end
go

