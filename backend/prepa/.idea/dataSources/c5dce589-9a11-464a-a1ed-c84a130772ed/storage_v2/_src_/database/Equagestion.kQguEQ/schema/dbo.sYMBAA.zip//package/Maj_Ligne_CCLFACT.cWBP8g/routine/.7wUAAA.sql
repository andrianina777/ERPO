



create procedure Maj_Ligne_CCLFACT (@falseq		int,
							  		@modif		int			/* 1 = en ajout, -1 = en effacement */
							 	   )
with recompile
as
begin

declare @code	char(10),
		@ligne	int


select @code = BELLIENCODE, @ligne = BELLIENNUM
from FFAL,FBEL
where FALSEQ = @falseq
and BELCODE = FALLIENCODE
and BELNUM = FALLIENNUM
and BELLIENCODE like 'CC%'

	
update FCCL
set CCLFACT = isnull(CCLFACT,0) +  @modif
where CCLCODE = @code
and CCLNUM = @ligne
	

end



go

