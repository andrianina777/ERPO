


/* Procedure utilisee par le module ""Preparation des factures"" 	*/
/* Modifiee le 040204 --> ajout des lignes atelier		*/
/* Modifiee le 090204 --> suppression affichage fiches atelier 	*/

create procedure AFacturer(	@ent		char(5)  = null,
							@client 	char(12) = null,
							@datedeb 	datetime = null,
							@datefin 	datetime = null,
							@activite	char(6)  = null,
							@rep		char(8)	 = null,	/* VRP general */
							@groupe		char(12) = null,
							@stade		tinyint	 = 5,
							@offerts	tinyint	 = 0,
							@dotations	tinyint	 = 0,
							@cldivision	tinyint	 = 0,
							@periodique	tinyint	 = 0
						 )
with recompile
as
begin

set arithabort numeric_truncation off


if @datefin is null
select @datefin=@datedeb

create table #SeqA
(
RWBSEQ		int	not null
)

create table #FinaleA
(
Client		char(12)		not null,
Nom			varchar(35)		not null,
CodeBE		char(10)		not null,
DateBE		datetime		not null,
Montant		numeric(14,2)		null
)

create table #Seq
(
RBESEQ		int	not null
)

create table #Finale
(
Client		char(12)		not null,
Nom			varchar(35)		not null,
CodeBE		char(10)		not null,
DateBE		datetime		not null,
Montant		numeric(14,2)		null
)


if (@stade=6 or @stade=5)   /* Atelier */
begin

	insert into #SeqA
	select RWBSEQ
	from FRWB,FCL,FWBL
 	where CLCODE=RWBCL
 	and WBLSEQ=RWBSEQ
  	and RWBARTICLE!=''
 	and (@client is null or RWBCL = @client)
 	and (@datedeb is null or RWBDATE between @datedeb and @datefin)
  	and (@activite is null or CLSA = @activite)
  	and (@rep is null or CLREP = @rep)
  	and (@groupe is null or CLCODEGROUPE = @groupe)
  	and (@cldivision = 0 or CLENTETE = 1)
  	and (@periodique = 0 or CLFACTPERIODE = 1)
  	and (@ent is null or (RWBENT=@ent and CLENT=@ent and WBLENT=@ent))
  	order by RWBSEQ

	select WBLDATE,WBLCL,WBLQTE,WBLARTICLE,WBLTOTALHT,WBLCODE
	into #FactA
	from #SeqA,FWBL
	where WBLSEQ=RWBSEQ
	and (@ent is null or WBLENT=@ent)
	order by WBLCL
	
	insert into #FinaleA (Client,Nom,CodeBE,DateBE,Montant)
	select Client=WBLCL,Nom=CLNOM1,WBLCODE,WBLDATE,Montant=sum(isnull(WBLTOTALHT,0))
	from #FactA,FCL
	where CLCODE=WBLCL
	and (@ent is null or CLENT=@ent)
	group by WBLCL,CLNOM1,WBLCODE,WBLDATE
	order by WBLCL,WBLCODE
	
	if @stade=6
	begin
	 select Client,Nom,CodeBE,DateBE,Montant,''
	 from #FinaleA
	 order by Client,CodeBE	
	end
end	


if @stade != 6 
begin

	insert into #Seq
	select RBESEQ
	from FRBE,FCL,FBEL
 	where CLCODE=RBECL
 	and BELSEQ=RBESEQ
  	and RBEARTICLE!=''
  	and RBEDEMO=0
 	and (@client is null or RBECL = @client)
 	and (@datedeb is null or RBEDATE between @datedeb and @datefin)
  	and (@activite is null or CLSA = @activite)
  	and (@rep is null or CLREP = @rep)
  	and (@groupe is null or CLCODEGROUPE = @groupe)
  	and (@stade = 5 or (@stade = 4 and RBESTADE >= 2) or (@stade < 4 and RBESTADE = @stade))
  	and (@offerts = 1 or isnull(BELOFFERT,0) = 0)
  	and (@dotations = 1 or isnull(BELDOTATION,0) = 0)
  	and (@cldivision = 0 or CLENTETE = 1)
  	and (@periodique = 0 or CLFACTPERIODE = 1)
  	and (@ent is null or (RBEENT=@ent and CLENT=@ent and BELENT=@ent))
  	order by RBESEQ

	select BELDATE,BELCL,BELQTE,BELARTICLE,BELTOTALHT,BELCODE
	into #Fact
	from #Seq,FBEL
	where BELSEQ=RBESEQ
	and (@ent is null or BELENT=@ent)
	order by BELCL

	insert into #Finale (Client,Nom,CodeBE,DateBE,Montant)
	select Client=BELCL,Nom=CLNOM1,BELCODE,BELDATE,Montant=sum(isnull(BELTOTALHT,0))
	from #Fact,FCL
	where CLCODE=BELCL
	and (@ent is null or CLENT=@ent)
	group by BELCL,CLNOM1,BELCODE,BELDATE
	order by BELCL,BELCODE
	
	if @stade != 5
	begin
	  select Client,Nom,CodeBE,DateBE,Montant,BECC
	  from #Finale,FBE
	  where BECODE=CodeBE
	  and (@ent is null or BEENT=@ent)
	  order by Client,CodeBE
	end
	else
	begin
	 select Client,Nom,CodeBE,DateBE,Montant,BECC
	 from #Finale,FBE
	 where BECODE=CodeBE
	 and (@ent is null or BEENT=@ent)
	union
	 select Client,Nom,CodeBE,DateBE,Montant,''
	 from #FinaleA
	 order by Client,CodeBE
	end
	
end

  drop table #Fact
  drop table #Seq
  drop table #Finale	
  drop table #FactA
  drop table #SeqA
  drop table #FinaleA	

end



go

