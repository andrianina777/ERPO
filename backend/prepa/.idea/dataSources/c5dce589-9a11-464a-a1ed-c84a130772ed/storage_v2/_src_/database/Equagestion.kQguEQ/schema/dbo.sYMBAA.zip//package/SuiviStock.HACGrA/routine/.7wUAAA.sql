


/* Cette procedure renvoie :																				*/
/*	chef de produits, marque, fournisseur, famille, valeur stock de la photo 1, CA annee1, marge annee1,	*/
/*  CA annee1, marge annee1, valeur stock de la photo 2, valeur achat annee2, devise achat					*/


create procedure SuiviStock (@ent			char(5)	 = null,
							 @datephotox	datetime,
							 @codephotox	char(16),
							 @datedebCAx	smalldatetime,
							 @datefinCAx	smalldatetime,
							 @datedebCAy	smalldatetime,
							 @datefinCAy	smalldatetime,
							 @datephotoy	datetime = null,
							 @codephotoy	char(16) = null
							)
as
begin

set arithabort numeric_truncation off

declare @anneeachat	smallint

if @datedebCAy is not null
	select  @anneeachat = datepart(yy,@datedebCAy)
else
	select  @anneeachat = datepart(yy,getdate())



create table #Suivi
(
chefprod		char(8)			not null,
marque			char(12)		not null,
fourn			char(12)		not null,
famille			char(8)			not null,
stock_an_x		numeric(14,2)		null,
BE_an_x			numeric(14,2)		null,
CA_an_x			numeric(14,2)		null,
pr_an_x			numeric(14,2)		null,
CA_an_y			numeric(14,2)		null,
pr_an_y			numeric(14,2)		null,
stock_an_y		numeric(14,2)		null,
BE_an_y			numeric(14,2)		null,
achats_an_y		numeric(14,2)		null,
devise			char(3)				null
)


/* Valeur du stock de la photo x - en principe photo de la fin de l''annee precedente */

insert into #Suivi (chefprod,marque,fourn,famille,stock_an_x,devise)
select ARCHEFP,ARFO,PSFO,ARFAM,round(sum(((isnull(PSPAHT,0)+isnull(PSFRAIS,0))/CVLOT)*PSQTE),2),PSDEV
from FPS,FAR,FCV
where ARCODE=PSAR
and ARUNITACHAT=CVUNIF
and PSDATE=@datephotox
and PSCODE=@codephotox
group by ARCHEFP,ARFO,PSFO,ARFAM,PSDEV

/* Valeur du prix de revient des BE non factures dont la date est inferieure ou egale a la date de la photo x */

insert into #Suivi (chefprod,marque,fourn,famille,BE_an_x,devise)
select ARCHEFP,ARFO,STFO,ARFAM,round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*BELQTE),2),STDEVISE
from FSTOCK,FAR,FBEL,FRBE,FCV
where ARCODE=STAR
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and ARUNITACHAT=CVUNIF
and BELSEQ=RBESEQ
and RBEDATE <= @datephotox
and (@ent is null or BELENT=@ent)
group by ARCHEFP,ARFO,STFO,ARFAM,STDEVISE


/* CA et prix de revient des ventes de l''annee x - en principe de l''annee precedente */

insert into #Suivi (chefprod,marque,fourn,famille,CA_an_x,pr_an_x,devise)
select ARCHEFP,ARFO,STFO,ARFAM,sum(FALTOTALHT),round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*FALQTE),2),STDEVISE
from FFAL,FAR,FSTOCK,FCV
where ARCODE=FALARTICLE
and ARUNITACHAT=CVUNIF
and FALDATE between @datedebCAx and @datefinCAx	
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and (@ent is null or FALENT=@ent)
group by ARCHEFP,ARFO,STFO,ARFAM,STDEVISE


/* CA et prix de revient des ventes de l''annee y - en principe de l''annee en cours */

insert into #Suivi (chefprod,marque,fourn,famille,CA_an_y,pr_an_y,devise)
select ARCHEFP,ARFO,STFO,ARFAM,sum(FALTOTALHT),round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*FALQTE),2),STDEVISE
from FFAL,FAR,FSTOCK,FCV
where ARCODE=FALARTICLE
and ARUNITACHAT=CVUNIF
and FALDATE between @datedebCAy and @datefinCAy	
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and (@ent is null or FALENT=@ent)
group by ARCHEFP,ARFO,STFO,ARFAM,STDEVISE



/* Valeur du stock en cours ou valeur du stock de la photo y - en principe la derniere photo de stock */

if @datephotoy is null
begin
  insert into #Suivi (chefprod,marque,fourn,famille,stock_an_y,devise)
  select ARCHEFP,ARFO,STFO,ARFAM,round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*STQTE),2),STDEVISE
  from FSTOCK,FAR,FCV
  where ARCODE=STAR
  and ARUNITACHAT=CVUNIF
  group by ARCHEFP,ARFO,STFO,ARFAM,STDEVISE
end
else
begin
  insert into #Suivi (chefprod,marque,fourn,famille,stock_an_y,devise)
  select ARCHEFP,ARFO,PSFO,ARFAM,round(sum(((isnull(PSPAHT,0)+isnull(PSFRAIS,0))/CVLOT)*PSQTE),2),PSDEV
  from FPS,FAR,FCV
  where ARCODE=PSAR
  and PSDATE=@datephotoy
  and PSCODE=@codephotoy
  and ARUNITACHAT=CVUNIF
  group by ARCHEFP,ARFO,PSFO,ARFAM,PSDEV
end


/* Valeur du prix de revient des BE non factures en cours */

insert into #Suivi (chefprod,marque,fourn,famille,BE_an_y,devise)
select ARCHEFP,ARFO,STFO,ARFAM,round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*BELQTE),2),STDEVISE
from FSTOCK,FAR,FBEL,FRBE,FCV
where ARCODE=STAR
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and ARUNITACHAT=CVUNIF
and BELSEQ=RBESEQ
and (@ent is null or BELENT=@ent)
group by ARCHEFP,ARFO,STFO,ARFAM,STDEVISE



/* Valeur des achats de l''annee choisie */

insert into #Suivi (chefprod,marque,fourn,famille,achats_an_y,devise)
select ARCHEFP,ARFO,BLLFO,ARFAM,round(sum(isnull(BLLTOTHT,0)),2),BLLDEV
from FAR,FBLL
where ARCODE=BLLAR
and datepart(yy,BLLDATE)=@anneeachat
and (@ent is null or BLLENT=@ent)
group by ARCHEFP,ARFO,BLLFO,ARFAM,BLLDEV


/* Valeur des retours fournisseurs de l''annee choisie */

insert into #Suivi (chefprod,marque,fourn,famille,achats_an_y,devise)
select ARCHEFP,ARFO,RFLFO,ARFAM,-(round(sum(isnull(RFLTOTALHT,0)),2)),RFLDEVISE
from FAR,FRFL
where ARCODE=RFLARTICLE
and datepart(yy,RFLDATE)=@anneeachat
and (@ent is null or RFLENT=@ent)
group by ARCHEFP,ARFO,RFLFO,ARFAM,RFLDEVISE


/* Liste Finale */

select Chef_produits=chefprod, Marque=marque, Fournisseur=fourn, Famille=famille,
		Stock_1=isnull(sum(stock_an_x),0), BE_1=isnull(sum(BE_an_x),0), 
		CA_1=isnull(sum(CA_an_x),0), Marge_1=isnull(sum(CA_an_x-pr_an_x),0),
		CA_prevu=0, CA_2=isnull(sum(CA_an_y),0), Marge_prevuee=0, Marge_2=isnull(sum(CA_an_y-pr_an_y),0),
		Stock_prevu=0, Stock_2=isnull(sum(stock_an_y),0), BE_2=isnull(sum(BE_an_y),0),
		Achats_prevus=0, Achats=isnull(sum(achats_an_y),0), Devise_achat=devise
from #Suivi
group by chefprod,marque,fourn,famille,devise
order by chefprod,marque,fourn,famille,devise

drop table #Suivi

end



go

