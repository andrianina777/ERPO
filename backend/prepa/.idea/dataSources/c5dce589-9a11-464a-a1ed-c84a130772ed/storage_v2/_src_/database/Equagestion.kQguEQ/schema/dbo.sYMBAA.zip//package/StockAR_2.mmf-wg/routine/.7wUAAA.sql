CREATE PROCEDURE dbo.StockAR_2 (@article		char(15),
						  @date1		smalldatetime,
						  @depot		char(4) = null,
						  @lettre		char(4) = null
						  )
with recompile
as
begin

 declare @id char(32),@qtestock_tmp int,@qtestockres_tmp int

create table #Stockinit
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null
)

create table #Stockperiode
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null,
ent				char(5)			null,
tiers			char(12)	null
)

create table #Stockfinal
(
type			char(5)		not null,
tri				tinyint		not null,
date			datetime	not null,
piece			varchar(20)	not null,
qtestock		int			not null,
qtestockres		int			not null,
ent				char(5)			null,
tiers			char(12)	null
)

create table #Resultats
(
seq				numeric(14,0)	identity,
tri				tinyint			not null,
date			datetime		not null,
piece			varchar(20)		not null,
qtestock		int				not null,
qtestockres		int				not null,
total			int				not null,
totavecres		int				not null,
ent				char(35)				null,
tiers			char(12)	null,
piece_liee varchar(20) null
)


/*********** AVANT ******************/

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stockinit (type,tri,date,piece,qtestock,qtestockres)
select 'AVANT',0,dateadd(dd,-1,@date1),'RECAPITULATIF',isnull(sum(SILQTE),0),0
from FSIL
where SILARTICLE=@article
--and SILDATE < @date1
and SILDATESIMPLE<convert(date,@date1)
and (@depot is null or SILDEPOT = @depot)
and (@lettre is null or SILLETTRE = @lettre)



drop table #Resultats

end





go

