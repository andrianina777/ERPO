/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_ImportPrepGros
grant execute on bp_ImportPrepGros to public
*/

CREATE PROCEDURE dbo.bp_ImportPrepGros(@article char(15),@qteVte int,@nbCC int)
with recompile
AS
begin

	if((select count(*) from bPrepGros where bgArticle=@article)>0)
		begin
			update bPrepGros set bgNbCCJ=@nbCC,bgQteVenteJ=@qteVte,bgDateDerMaj=getDate()  where bgArticle=@article
		end
	else
		begin
			INSERT INTO bPrepGros (bgArticle, bgQteVenteJ, bgNbCCJ, bgDateDerMaj, bgDateCre)
			VALUES (@article,@qteVte ,@nbCC ,getDate() ,getDate() )
		end

end
go

