


create procedure StockDep	(@ent	char(5)	= null,
							 @dep	char(8))
with recompile
as
begin

set arithabort numeric_truncation off


declare @datedeb	datetime
select 	@datedeb = convert(datetime,("01/01/" + convert(varchar(4),datepart(yy,getdate()))))


create table #Lignes
(
fourn		char(12)		not null,
marque		char(12)		not null,
stock		numeric(14,2)	null,
ventes		numeric(14,2)	null,
be_encours	numeric(14,2)	null,
be_demo		numeric(14,2)	null
)

create table #Final
(
fourn		char(12)		not null,
marque		char(12)		not null,
stock		numeric(14,2)	null,
ventes		numeric(14,2)	null,
be_encours	numeric(14,2)	null,
be_demo		numeric(14,2)	null,
rapport		numeric(14,2)	null
)


insert into #Lignes (fourn,marque,stock,ventes,be_encours,be_demo)
select STFO,ARFO,isnull(sum(STQTE*((STPAHT+STFRAIS)/CVLOT)),0),0.00,0.00,0.00
from FSTOCK,FAR,FCV,FDP
where ARCODE=STAR
and ARUNITACHAT=CVUNIF
and ARDEPART=@dep
and STQTE > 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by STFO,ARFO


insert into #Lignes (fourn,marque,stock,ventes,be_encours,be_demo)
select STFO,ARFO,0.00,isnull(sum(FALTOTALHT),0),0.00,0.00
from FFAL,FSTOCK,FAR,FDP
where ARCODE=FALARTICLE
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and ARDEPART=@dep
and FALDATE between @datedeb and getdate()
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by STFO,ARFO


insert into #Lignes (fourn,marque,stock,ventes,be_encours,be_demo)
select STFO,ARFO,0.00,0.00,
		isnull(sum(case when RBEDEMO=0 then BELTOTALHT else 0 end),0),
		isnull(sum(case when RBEDEMO=1 then BELTOTALHT else 0 end),0)
from FBEL,FSTOCK,FAR,FRBE,FDP
where ARCODE=BELARTICLE
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and RBESEQ=BELSEQ
and ARDEPART=@dep
and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and RBEENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by STFO,ARFO


insert into #Final (fourn,marque,stock,ventes,be_encours,be_demo)
select fourn,marque,sum(stock),sum(ventes),sum(be_encours),sum(be_demo)
from #Lignes
group by fourn,marque


update #Final
set rapport = isnull(stock,0)
where isnull(ventes,0) = 0

update #Final
set rapport = (convert(numeric(14,2),ventes/convert(numeric(14,2),stock)))
where isnull(stock,0) != 0

update #Final
set rapport = 0
where rapport is null


select "Fournisseur","Marque","Valeur Stock","Ventes de l'annee","Ratio Ventes/Stock","BE a facturer","BE de demo"
select fourn,marque,stock,ventes,rapport,be_encours,be_demo
from #Final
order by fourn,marque

drop table #Lignes
drop table #Final


end



go

