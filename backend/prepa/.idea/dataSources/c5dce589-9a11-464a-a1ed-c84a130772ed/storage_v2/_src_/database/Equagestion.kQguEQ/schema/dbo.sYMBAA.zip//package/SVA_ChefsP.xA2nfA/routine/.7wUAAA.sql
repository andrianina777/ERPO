


/* Procedure calculant la valeur du stock de janvier au mois donne pour l''annee choisie
	a partir des lignes de mouvement de stock */


create procedure SVA_ChefsP (@an		int,
							@mois		int,
							@compare	int = 0,
							@chefp		char(8) = null,
							@sansval	tinyint = 0,
							@marque		char(12) = null,
							@famille	char(8) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off


if (@mois<1 or @mois>12) 
select @mois=12


create table #Stock
(
chefp			char(8)			not null,
marque			char(12)		not null,
famille			char(8)			not null,
valstock		numeric(14,2)	not null,
valventes		numeric(14,2)	not null,
valmarge		numeric(14,2)	not null,
valachat		numeric(14,2)	not null,
valstock_1		numeric(14,2)	not null,
valventes_1		numeric(14,2)	not null,
valmarge_1		numeric(14,2)	not null,
valachat_1		numeric(14,2)	not null
)

insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARCHEFP,ARFO,ARFAM,sum(isnull(MOISTOTPR,0)),0,0,0,0,0,0,0
from FMOIS,FAR
where ARCODE=MOISARTICLE
and MOISANNEE=@an-1
and MOISMOIS=12
and MOISQTE != 0
and (@chefp is null or ARCHEFP=@chefp)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (0,2,5)
group by ARCHEFP,ARFO,ARFAM


insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARCHEFP,ARFO,ARFAM,sum(isnull(MSTOTPR,0)),0,0,0,0,0,0,0
from FMS,FAR
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE in ("E","F","R","C","A","M")
and (@chefp is null or ARCHEFP=@chefp)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (0,2,5)
group by ARCHEFP,ARFO,ARFAM


insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARCHEFP,ARFO,ARFAM,-sum(isnull(MSTOTPR,0)),0,0,0,0,0,0,0
from FMS,FAR
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE="S"
and (@chefp is null or ARCHEFP=@chefp)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (0,2,5)
group by ARCHEFP,ARFO,ARFAM


insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARCHEFP,ARFO,ARFAM,0,sum(isnull(STCAFA,0)),sum(isnull(STCAFA,0))-sum(isnull(STPR,0)),0,0,0,0,0
from FST,FAR
where ARCODE=START
and STAN=@an
and STMOIS between 1 and @mois
and (@chefp is null or ARCHEFP=@chefp)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (0,2,5)
group by ARCHEFP,ARFO,ARFAM



insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARCHEFP,ARFO,ARFAM,0,0,0,sum(isnull(round(BLLPRHT*BLLQTE/CVLOT,2),0)),0,0,0,0
from FBLL,FAR,FCV
where ARCODE=BLLAR
and CVUNIF=BLLUA
and datepart(yy,BLLDATE)=@an
and datepart(mm,BLLDATE) between 1 and @mois
and (@chefp is null or ARCHEFP=@chefp)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (0,2,5)
group by ARCHEFP,ARFO,ARFAM


insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARCHEFP,ARFO,ARFAM,0,0,0,-sum(isnull(RFLTOTALHT,0)),0,0,0,0
from FRFL(index date),FAR
where ARCODE=RFLARTICLE
and datepart(yy,RFLDATE)=@an
and datepart(mm,RFLDATE) between 1 and @mois
and (@chefp is null or ARCHEFP=@chefp)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (0,2,5)
group by ARCHEFP,ARFO,ARFAM



if @compare=1
  begin
  
	insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARCHEFP,ARFO,ARFAM,0,0,0,0,sum(isnull(MOISTOTPR,0)),0,0,0
	from FMOIS,FAR
	where ARCODE=MOISARTICLE
	and MOISANNEE=@an-2
	and MOISMOIS=12
	and MOISQTE != 0
	and (@chefp is null or ARCHEFP=@chefp)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (0,2,5)
	group by ARCHEFP,ARFO,ARFAM


	insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARCHEFP,ARFO,ARFAM,0,0,0,0,sum(isnull(MSTOTPR,0)),0,0,0
	from FMS,FAR
	where ARCODE=MSARTICLE
	and MSANNEE=@an-1
	and MSMOIS between 1 and @mois
	and MSTYPE in ("E","F","R","C","A","M")
	and (@chefp is null or ARCHEFP=@chefp)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (0,2,5)
	group by ARCHEFP,ARFO,ARFAM


	insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARCHEFP,ARFO,ARFAM,0,0,0,0,-sum(isnull(MSTOTPR,0)),0,0,0
	from FMS,FAR
	where ARCODE=MSARTICLE
	and MSANNEE=@an-1
	and MSMOIS between 1 and @mois
	and MSTYPE="S"
	and (@chefp is null or ARCHEFP=@chefp)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (0,2,5)
	group by ARCHEFP,ARFO,ARFAM


	insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARCHEFP,ARFO,ARFAM,0,0,0,0,0,sum(isnull(STCAFA,0)),sum(isnull(STCAFA,0))-sum(isnull(STPR,0)),0
	from FST,FAR
	where ARCODE=START
	and STAN=@an-1
	and STMOIS between 1 and @mois
	and (@chefp is null or ARCHEFP=@chefp)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (0,2,5)
	group by ARCHEFP,ARFO,ARFAM


	insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARCHEFP,ARFO,ARFAM,0,0,0,0,0,0,0,sum(isnull(round(BLLPRHT*BLLQTE/CVLOT,2),0))
	from FBLL,FAR,FCV
	where ARCODE=BLLAR
	and CVUNIF=BLLUA
	and datepart(yy,BLLDATE)=@an-1
	and datepart(mm,BLLDATE) between 1 and @mois
	and (@chefp is null or ARCHEFP=@chefp)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (0,2,5)
	group by ARCHEFP,ARFO,ARFAM

	
	insert into #Stock (chefp,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARCHEFP,ARFO,ARFAM,0,0,0,0,0,0,0,-sum(isnull(RFLTOTALHT,0))
	from FRFL(index date),FAR
	where ARCODE=RFLARTICLE
	and datepart(yy,RFLDATE)=@an-1
	and datepart(mm,RFLDATE) between 1 and @mois
	and (@chefp is null or ARCHEFP=@chefp)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (0,2,5)
	group by ARCHEFP,ARFO,ARFAM
	
  end

if @sansval = 0
	begin
	  select ChefP=chefp,Marque=marque,Famille=famille,
	  		 Val_Stock=sum(valstock),Ventes=sum(valventes),
			 Marge=sum(valmarge),Achats=sum(valachat),
			 Valstock_1=sum(valstock_1),Ventes_1=sum(valventes_1),
			 Marge_1=sum(valmarge_1),Achats_1=sum(valachat_1)
	  from #Stock
	  group by chefp,marque,famille
	  order by chefp,marque,famille
	end
else if @sansval = 1
	begin
	  select ChefP=chefp,Marque=marque,Famille=famille,
	  		 Val_Stock=sum(valstock),Ventes=sum(valventes),
			 Marge=sum(valmarge),Achats=sum(valachat),
			 Valstock_1=sum(valstock_1),Ventes_1=sum(valventes_1),
			 Marge_1=sum(valmarge_1),Achats_1=sum(valachat_1)
	  from #Stock
	  group by chefp,marque,famille
	  having sum(valstock) != 0
	  	or  sum(valventes) != 0
		or  sum(valachat) != 0
		or  sum(valstock_1) != 0
		or  sum(valventes_1) != 0
		or  sum(valachat_1) != 0
	  order by chefp,marque,famille
	end


drop table #Stock

end



go

