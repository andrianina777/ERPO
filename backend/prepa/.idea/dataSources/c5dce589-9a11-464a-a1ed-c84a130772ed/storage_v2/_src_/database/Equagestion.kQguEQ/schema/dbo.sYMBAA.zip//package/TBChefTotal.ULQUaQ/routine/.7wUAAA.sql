



create procedure TBChefTotal(@ent		char(5) = null,
							@chef	 	char(8),
							@sans_rfa	tinyint,
							@atcurdate 	tinyint,
							@annee		int,
							@modevalo	tinyint = 0)
with recompile
as
begin

	set arithabort numeric_truncation off
	
	if @modevalo = 4		/**** pas de statistiques au DPA unitaire *****/
	  select @modevalo = 0


	declare @curyear int,@curmonth int,@curday int,@factor float
	
	if @atcurdate=null
		select @atcurdate=1
	
	if (@annee is null) or (@annee=datepart(year,getdate()))
		select @curyear=datepart(year,getdate()),
			   @curmonth=datepart(month,getdate()),
			   @curday=datepart(day,getdate()),
			   @annee=datepart(year,getdate())
			  			   
	if @annee != datepart(year,getdate())
		select @curyear=@annee,
			   @curmonth=12,
			   @curday=31,
			   @atcurdate=0
	
	
	create table #S1
	(
	MOIS		tinyint 			not null,
	QTECDE		int 				not null,			/* reliquats de commandes */
	CACDE		numeric(14,2) 		not null,			/* CA des reliquats de commandes */
	QTEFACT_2	int 				not null,			/* quantite facturee annee -2 */
	QTEFACT_1	int 				not null,			/* quantite facturee annee -1 */
	QTEFACT		int 				not null,			/* quantite facturee annee en cours */
	CAFACT_2	numeric(14,2)	 	not null,			/* CA facturee annee -2 */
	CAFACT_1	numeric(14,2)	 	not null,			/* CA facturee annee -1 */
	CAFACT		numeric(14,2)	 	not null,			/* CA facturee annee en cours */
	PR_2		numeric(14,2)	 	not null,			/* prix de revient annee -2 */
	PR_1		numeric(14,2)	 	not null,			/* prix de revient annee -1 */
	PR			numeric(14,2)	 	not null,			/* prix de revient annee en cours */
	MARGE_2		numeric(14,2)	 	not null,			/* marge en valeur annee -2 */
	MARGE_1		numeric(14,2)	 	not null,			/* marge en valeur annee -1 */
	MARGE		numeric(14,2)	 	not null,			/* marge en valeur annee en cours */
	PA_2		numeric(14,2)	 	not null,			/* prix d''achat a la commande annee -2 */
	PA_1		numeric(14,2)	 	not null,			/* prix d''achat a la commande annee -1 */
	PA			numeric(14,2)	 	not null,			/* prix d''achat a la commande annee en cours */
	QTESTOCK	int 				not null,			/* stock au jour de la consultation */
	VALSTOCK	numeric(14,2)	 	not null			/* valeur du stock au jour de la consultation */
	)
	
	create table #Stock
	(
	ARTST	char(15)			not null,			/* code article */
	QTEST	int 				not null,			/* stock au jour de la consultation */
	VALST	numeric(14,2)	 	not null,			/* valeur du stock au jour de la consultation */
	SEQ		numeric(14,0)		identity			/* sequentiel */
	)
	
	
	create table #Finale
	(
	MOIS		tinyint 			not null,
	QTECDE		int 				not null,			/* reliquats de commandes */
	CACDE		numeric(14,2)	 	not null,			/* CA des reliquats de commandes */
	QTEFACT_2	int 				not null,			/* quantite facturee annee -2 */
	QTEFACT_1	int 				not null,			/* quantite facturee annee -1 */
	QTEFACT		int 				not null,			/* quantite facturee annee en cours */
	CAFACT_2	numeric(14,2)	 	not null,			/* CA facturee annee -2 */
	CAFACT_1	numeric(14,2)	 	not null,			/* CA facturee annee -1 */
	CAFACT		numeric(14,2)	 	not null,			/* CA facturee annee en cours */
	PR_2		numeric(14,2)	 	not null,			/* prix de revient annee -2 */
	PR_1		numeric(14,2)	 	not null,			/* prix de revient annee -1 */
	PR			numeric(14,2)	 	not null,			/* prix de revient annee en cours */
	MARGE_2		numeric(14,2)	 	not null,			/* marge en valeur annee -2 */
	MARGE_1		numeric(14,2)	 	not null,			/* marge en valeur annee -1 */
	MARGE		numeric(14,2)	 	not null,			/* marge en valeur annee en cours */
	PA_2		numeric(14,2)	 	not null,			/* prix d''achat a la commande annee -2 */
	PA_1		numeric(14,2)	 	not null,			/* prix d''achat a la commande annee -1 */
	PA			numeric(14,2)	 	not null,			/* prix d''achat a la commande annee en cours */
	QTESTOCK	int 				not null,			/* stock au jour de la consultation */
	VALSTOCK	numeric(14,2)	 	not null			/* valeur du stock au jour de la consultation */
	)
	
	/* stats de bases */
	
	if @sans_rfa=0
	begin
		insert into #S1 (MOIS,QTECDE,CACDE,QTEFACT_2,QTEFACT_1,QTEFACT,CAFACT_2,CAFACT_1,CAFACT,
					PR_2,PR_1,PR,MARGE_2,MARGE_1,MARGE,PA_2,PA_1,PA,QTESTOCK,VALSTOCK)
		select STMOIS,0,0.00,
			   isnull(sum(case 	when STAN=@curyear-2 then STQTEFA
						   else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then STQTEFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then STQTEFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-2 then STCAFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then STCAFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then STCAFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-2 then (case when @modevalo = 0 then isnull(STPR,0)
			   													when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   		when @modevalo = 2 then isnull(STPUM,0)
														   		when @modevalo = 3 then isnull(STPRM,0)
														   		else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then (case when @modevalo = 0 then isnull(STPR,0)
			   													when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   		when @modevalo = 2 then isnull(STPUM,0)
														   		when @modevalo = 3 then isnull(STPRM,0)
														   		else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then (case when @modevalo = 0 then isnull(STPR,0)
			   													when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   		when @modevalo = 2 then isnull(STPUM,0)
														   		when @modevalo = 3 then isnull(STPRM,0)
														   		else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-2 then isnull(STCAFA,0)-(case when @modevalo = 0 then isnull(STPR,0)
			   																	 when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   						 when @modevalo = 2 then isnull(STPUM,0)
														   						 when @modevalo = 3 then isnull(STPRM,0)
														   						 else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then isnull(STCAFA,0)-(case when @modevalo = 0 then isnull(STPR,0)
			   																	 when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   						 when @modevalo = 2 then isnull(STPUM,0)
														   						 when @modevalo = 3 then isnull(STPRM,0)
														   						 else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then isnull(STCAFA,0)-(case when @modevalo = 0 then isnull(STPR,0)
			   																	 when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   						 when @modevalo = 2 then isnull(STPUM,0)
														   						 when @modevalo = 3 then isnull(STPRM,0)
														   						 else isnull(STPR,0) end)
						  else 0
				   end),0),
			   0.00,0.00,0.00,0,0.00
		from FST,FAR
		where (@ent is null or STENT=@ent)
		and STAN between @curyear-2 and @curyear
		and ARCODE=START
		and ARCHEFP = @chef
		and ARTYPE in (0,1,2,3,5,6,7)
		group by STMOIS
	end
	else if @sans_rfa=1
	begin
		insert into #S1 (MOIS,QTECDE,CACDE,QTEFACT_2,QTEFACT_1,QTEFACT,CAFACT_2,CAFACT_1,CAFACT,
					PR_2,PR_1,PR,MARGE_2,MARGE_1,MARGE,PA_2,PA_1,PA,QTESTOCK,VALSTOCK)
		select STMOIS,0,0.00,
			   isnull(sum(case 	when STAN=@curyear-2 then STQTEFA
						   else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then STQTEFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then STQTEFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-2 then STCAFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then STCAFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then STCAFA
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-2 then (case when @modevalo = 0 then isnull(STPR,0)
			   													when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   		when @modevalo = 2 then isnull(STPUM,0)
														   		when @modevalo = 3 then isnull(STPRM,0)
														   		else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then (case when @modevalo = 0 then isnull(STPR,0)
			   													when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   		when @modevalo = 2 then isnull(STPUM,0)
														   		when @modevalo = 3 then isnull(STPRM,0)
														   		else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then (case when @modevalo = 0 then isnull(STPR,0)
			   													when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   		when @modevalo = 2 then isnull(STPUM,0)
														   		when @modevalo = 3 then isnull(STPRM,0)
														   		else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-2 then isnull(STCAFA,0)-(case when @modevalo = 0 then isnull(STPR,0)
			   																	 when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   						 when @modevalo = 2 then isnull(STPUM,0)
														   						 when @modevalo = 3 then isnull(STPRM,0)
														   						 else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear-1 then isnull(STCAFA,0)-(case when @modevalo = 0 then isnull(STPR,0)
			   																	 when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   						 when @modevalo = 2 then isnull(STPUM,0)
														   						 when @modevalo = 3 then isnull(STPRM,0)
														   						 else isnull(STPR,0) end)
						  else 0
				   end),0),
			   isnull(sum(case 	when STAN=@curyear then isnull(STCAFA,0)-(case when @modevalo = 0 then isnull(STPR,0)
			   																	 when @modevalo = 1 then isnull(ARPRM,0)*STQTEFA
			   											   						 when @modevalo = 2 then isnull(STPUM,0)
														   						 when @modevalo = 3 then isnull(STPRM,0)
														   						 else isnull(STPR,0) end)
						  else 0
				   end),0),
			   0.00,0.00,0.00,0,0.00
		from FST,FAR
		where (@ent is null or STENT=@ent)
		and STAN between @curyear-2 and @curyear
		and ARCODE=START
		and ARCHEFP = @chef
		and ARTYPE in  (0,1,2,3,5,7)
		group by STMOIS
	end
	
	
	/* Ajout des stats sur les achats */
	
	
	insert into #S1 (MOIS,QTECDE,CACDE,QTEFACT_2,QTEFACT_1,QTEFACT,CAFACT_2,CAFACT_1,CAFACT,
				PR_2,PR_1,PR,MARGE_2,MARGE_1,MARGE,PA_2,PA_1,PA,QTESTOCK,VALSTOCK)
	select datepart(month,CFLDATEP),0,0.00,0,0,0,0.00,0.00,0.00,
				0.00,0.00,0.00,0.00,0.00,0.00,
				isnull(sum(case 	when datepart(year,CFLDATEP)=@curyear-2 then CFLTOTALHT
									else 0.00
							 end),0),
				isnull(sum(case 	when datepart(year,CFLDATEP)=@curyear-1 then CFLTOTALHT
									else 0.00
							 end),0),
				isnull(sum(case 	when datepart(year,CFLDATEP)=@curyear then CFLTOTALHT
									else 0.00
							 end),0),
				0,0.00
	from FCFL,FAR,FCF
	where (@ent is null or CFLENT=@ent)
	and datepart(year,CFLDATEP) between @curyear-2 and @curyear
	and ARCODE=CFLARTICLE
	and ARCHEFP = @chef
	and ARTYPE in (0,1,2,3,5,7)
	and CFCODE=CFLCODE
	and isnull(CFVALIDE,0)=0
	group by datepart(month,CFLDATEP)
	
		
	/* Ajout des stats de commandes clients */
	
	insert into #S1 (MOIS,QTECDE,
			CACDE,QTEFACT_2,QTEFACT_1,QTEFACT,CAFACT_2,CAFACT_1,CAFACT,
				PR_2,PR_1,PR,MARGE_2,MARGE_1,MARGE,PA_2,PA_1,PA,QTESTOCK,VALSTOCK)
	select RCCMOIS,sum(isnull(RCCQTE,0)),
			sum(round(isnull(CCLTOTALHT,0)/CCLQTE,2)*isnull(RCCQTE,0)),0,0,0,0.00,0.00,0.00,
				0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00
	from FRCC,FCCL,FAR,FCC
	where (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
	and ARCODE=RCCARTICLE
	and RCCSEQ=CCLSEQ
 	and CCCODE=CCLCODE
 	and isnull(CCVALIDE,0)=0
	and CCLQTE != 0
	and ARCHEFP = @chef
	and ARTYPE in (0,1,2,3,5,7)
	group by RCCMOIS
	

	
	/* Ajout des valeurs du Stock au moment de la consultation */
	
	if @modevalo = 0
	begin
	  insert into #S1 (MOIS,QTECDE,CACDE,QTEFACT_2,QTEFACT_1,QTEFACT,CAFACT_2,CAFACT_1,CAFACT,
				  PR_2,PR_1,PR,MARGE_2,MARGE_1,MARGE,PA_2,PA_1,PA,QTESTOCK,VALSTOCK)
	  select 0,0,0.00,0,0,0,0.00,0.00,0.00,
			  0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,isnull(sum(STQTE),0),
			  isnull(sum(round((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT,2)*STQTE),0)
	  from FSTOCK,FCV,FAR,FDP
	  where DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	  and ARCODE=STAR
	  and ARUNITACHAT=CVUNIF
	  and ARTYPE  in (0,1,2,3,5,7)
	  and ARCHEFP = @chef
	  and STQTE > 0
	end
	else
	begin
	  insert into #Stock (ARTST,QTEST,VALST)
	  select STAR,sum(STQTE),0
	  from FSTOCK,FAR,FDP
	  where DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	  and ARCODE=STAR
	  and ARTYPE  in (0,1,2,3,5,7)
	  and ARCHEFP = @chef
	  and STQTE > 0
	  group by STAR
	  
	  
	  declare @article	char(15),
			  @seq		int,
			  @qte		int,
			  @previent	numeric(14,4)
	
	  
	  create index seq on #Stock (SEQ)

	  declare stock cursor
	  for
	  select ARTST,QTEST,SEQ
	  from #Stock
	  where QTEST != 0
	  order by ARTST
	  for read only

	  open stock
	  
	  fetch stock
	  into @article,@qte,@seq
	  
	  while (@@sqlstatus = 0)
		begin
		  if @modevalo=3								/*--------------------- PRM mensuel */
		  begin
			  select @previent = 0
			  
			  set rowcount 1
			  
			  select @previent = PRM from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  if @previent is null
				  select @previent = 0
		  end
		  else if @modevalo=2								/*--------------------- PUMP */
		  begin
			  select @previent = 0
			  
			  select @previent = PUMP from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  and PUMDATE = max(PUMDATE)
			  
			  if @previent is null
				  select @previent = 0
		  end
		  else if @modevalo=1								/*--------------------- PRM global */
		  begin
			  select @previent = 0
			  
			  select @previent = isnull(ARPRM,0) from FAR
			  where ARCODE = @article
			  
			  if @previent is null
				  select @previent = 0
		  end
	
			  update #Stock
			  set VALST = isnull(@previent*@qte,0)
			  where SEQ=@seq
	
		  
			  fetch stock
			  into @article,@qte,@seq
		end

	  close stock
	  deallocate cursor stock
	
	  insert into #S1 (MOIS,QTECDE,CACDE,QTEFACT_2,QTEFACT_1,QTEFACT,CAFACT_2,CAFACT_1,CAFACT,
				  PR_2,PR_1,PR,MARGE_2,MARGE_1,MARGE,PA_2,PA_1,PA,QTESTOCK,VALSTOCK)
	  select 0,0,0.00,0,0,0,0.00,0.00,0.00,
			  0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,isnull(sum(QTEST),0),
			  isnull(sum(VALST),0)
	  from #Stock
	
	end
	
	
	/* Agregation des quatre */
	
	insert into #Finale
	select MOIS,QTECDE=sum(QTECDE),CACDE=sum(CACDE),
			QTEFACT_2=sum(QTEFACT_2),QTEFACT_1=sum(QTEFACT_1),QTEFACT=sum(QTEFACT),
			CAFACT_2=sum(CAFACT_2),CAFACT_1=sum(CAFACT_1),CAFACT=sum(CAFACT),
			PR_2=sum(PR_2),PR_1=sum(PR_1),PR=sum(PR),
			MARGE_2=sum(MARGE_2),MARGE_1=sum(MARGE_1),MARGE=sum(MARGE),
			PA_2=sum(PA_2),PA_1=sum(PA_1),PA=sum(PA),
			QTESTOCK=sum(QTESTOCK),VALSTOCK=sum(VALSTOCK)
	from #S1
	group by MOIS
	
	
	drop table #S1
	
	/* ne considere que les mois precedents et le prorata du mois en cours */
	
	if @atcurdate!=0
	begin
		delete from #Finale where MOIS>@curmonth
		
		select @factor=convert(float,@curday)/
			   datepart(day,dateadd(day,-1,dateadd(month,1,convert(datetime,convert(char,@curyear*10000+@curmonth*100+1)))))
			   
		update #Finale set 	QTEFACT_2=isnull(QTEFACT_2,0)*@factor,
							QTEFACT_1=isnull(QTEFACT_1,0)*@factor,
							CAFACT_2=isnull(CAFACT_2,0)*@factor,
							CAFACT_1=isnull(CAFACT_1,0)*@factor,
							PR_2=isnull(PR_2,0)*@factor,
							PR_1=isnull(PR_1,0)*@factor,
							MARGE_2=isnull(MARGE_2,0)*@factor,
							MARGE_1=isnull(MARGE_1,0)*@factor,
							PA_2=isnull(PA_2,0)*@factor,
							PA_1=isnull(PA_1,0)*@factor
			where MOIS=datepart(month,getdate())
	end
	
	
	select QTECDE=sum(isnull(QTECDE,0)),CACDE=sum(isnull(CACDE,0)),
			QTEFACT_2=sum(QTEFACT_2),QTEFACT_1=sum(QTEFACT_1),QTEFACT=sum(QTEFACT),
			CAFACT_2=sum(CAFACT_2),CAFACT_1=sum(CAFACT_1),CAFACT=sum(CAFACT),
			PR_2=sum(PR_2),PR_1=sum(PR_1),PR=sum(PR),
			MARGE_2=sum(MARGE_2),MARGE_1=sum(MARGE_1),MARGE=sum(MARGE),
			PA_2=sum(PA_2),PA_1=sum(PA_1),PA=sum(PA),
			QTESTOCK=sum(QTESTOCK),VALSTOCK=sum(VALSTOCK)
	from #Finale
	
	
	drop table #Finale
	
end



go

