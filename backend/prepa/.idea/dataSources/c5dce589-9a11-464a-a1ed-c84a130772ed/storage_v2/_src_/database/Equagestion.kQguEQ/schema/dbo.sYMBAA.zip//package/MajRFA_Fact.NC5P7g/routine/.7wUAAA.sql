



create procedure MajRFA_Fact	(@an	smallint)
with recompile
as
begin

set arithabort numeric_truncation off
  
 
declare clients cursor
for select STCL
from FST
where STAN=@an
group by STCL
for read only

declare @client	char(12)

open clients

fetch clients into @client


while (@@sqlstatus = 0)
begin
	
	execute MajRFA_FACL null,@client,@an
	
	select @client
		
	fetch clients into @client
		
end

close clients
deallocate cursor clients


end



go

