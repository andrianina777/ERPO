


create procedure Valo_ASL (@date1		datetime,
						   @date2		datetime,
						   @detail 		tinyint,
						   @chefprod	char(8) = null,
						   @depot		char(4) = null,
						   @code		char(10)= null,
						   @code_art	char(15)= null
						   )
with recompile
as
begin

declare @modevalo 			tinyint,
		@date 				datetime,
		@article			char(15),
		@articleprecedent	char(15),
		@qte				int,
		@PrixRevient		numeric(14,4),
		@PrixRevientLigne	numeric(14,2),
		@seq				int


select @modevalo=PMODEVALO from KParam
select @articleprecedent = ""

create table #Final
(
ASLARTICLE	char(15)		not null,
ANNEE		int					null,
ARLIB		varchar(80)			null,
ASLDEPOT	char(4) 		not null,
ASLQTE		int					null,
VALEURFINAL	numeric(14,2)		null,
ASLCOMMENT	varchar(255)		null,
ASLDATE		datetime		not null,
ARREFFOUR	char(20)			null,
STNUMARM1	char(12)			null,
STNUMARM2	char(12)			null,
ASLCODE		char(10)		not null,
Seq			numeric(14,0)	identity
)


declare st_curs cursor 
for select ASLARTICLE,ASLQTE,ASLDATE,Seq
from #Final
order by Seq
for read only



if @modevalo=0
	insert into #Final (ASLARTICLE,ANNEE,ARLIB,ASLDEPOT,ASLQTE,
      	VALEURFINAL,ASLCOMMENT,ASLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,ASLCODE)
	select ASLARTICLE,datepart(yy,ASLDATE),ARLIB,ASLDEPOT,ASLQTE,(ASLPAHT+ASLFRAIS)*ASLQTE,
	ASLCOMMENT,ASLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,ASLCODE
	from FASL,FAR,FSTOCK 
	where ARCODE=ASLARTICLE 
	and STAR=ASLARTICLE 
	and STLETTRE=ASLLETTRE
	and (@chefprod is null or ARCHEFP = @chefprod)
	and (@depot is null or ASLDEPOT=@depot)
	and (@code_art is null or ASLARTICLE=@code_art)
	and (@code is null or ASLCODE like @code+"%")
	and ASLDATE between @date1 and @date2
	
else if @modevalo=1
	insert into #Final (ASLARTICLE,ANNEE,ARLIB,ASLDEPOT,ASLQTE,
      	VALEURFINAL,ASLCOMMENT,ASLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,ASLCODE)
	select ASLARTICLE,datepart(yy,ASLDATE),ARLIB,ASLDEPOT,ASLQTE,
	isnull(ARPRM,0)*ASLQTE,ASLCOMMENT,ASLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,ASLCODE
	from FASL,FAR,FSTOCK 
	where ARCODE=ASLARTICLE 
	and STAR=ASLARTICLE 
	and STLETTRE=ASLLETTRE
	and (@chefprod is null or ARCHEFP = @chefprod)
	and (@depot is null or ASLDEPOT=@depot)
	and (@code_art is null or ASLARTICLE=@code_art)
	and (@code is null or ASLCODE like @code+"%")
	and ASLDATE between @date1 and @date2

else
        begin
             insert into #Final (ASLARTICLE,ANNEE,ARLIB,ASLDEPOT,ASLQTE,
      	     VALEURFINAL,ASLCOMMENT,ASLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,ASLCODE)
             select ASLARTICLE,datepart(yy,ASLDATE),ARLIB,ASLDEPOT,ASLQTE,0,
	     ASLCOMMENT,ASLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,ASLCODE
	     from FASL,FAR,FSTOCK 
	     where ARCODE=ASLARTICLE 
	     and STAR=ASLARTICLE 
	     and STLETTRE=ASLLETTRE
	     and (@chefprod is null or ARCHEFP = @chefprod)
	     and (@depot is null or ASLDEPOT=@depot)
	     and (@code_art is null or ASLARTICLE=@code_art)
	     and (@code is null or ASLCODE like @code+"%")
	     and ASLDATE between @date1 and @date2
            
            	              	
               	create unique index seq on #Final (Seq)
		
		open st_curs
		
		fetch st_curs
		into @article,@qte,@date,@seq
               	
               	
		while (@@sqlstatus = 0)
			begin
			
		  if @articleprecedent != @article
		  begin
			select 	@PrixRevient = 0
			
			if @modevalo = 2			/*--------------------- PUMP */
			begin
			  select @PrixRevient=isnull(PUMP,0)
			  from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, @date)
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, @date)
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			  
			end
			
			else if @modevalo = 3			/*--------------------- PRM Mensuel */
			
			begin
			  set rowcount 1
			  
			  select @PrixRevient=isnull(PRM,0)
			  from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
			
			else  if @modevalo = 4 			/*--------------------- DPA unitaire */
			
			begin
			  set rowcount 1			
			
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			  from FBLL,FCV
			  where BLLAR=@article
			  and CVUNIF=BLLUA
			  having BLLAR=@article
			  and CVUNIF=BLLUA
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
			  if isnull(@PrixRevient,0)=0
			  begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
			  set rowcount 0
			  
			  if @PrixRevient is null
				select @PrixRevient = 0
	  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
		  end
		  else if @articleprecedent = @article
		  begin
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end


			update #Final set VALEURFINAL=@PrixRevientLigne
			where Seq = @seq
		
			select  @articleprecedent = @article
			
			fetch st_curs
			into @article,@qte,@date,@seq
			
		end
                	
                close st_curs
                           
            	
	end

/*--- renvoi les lignes --*/

if @detail=1
   select ASLARTICLE,ANNEE,ARLIB,ASLDEPOT,ASLQTE,VALEURFINAL,ASLCOMMENT,ASLDATE,ARREFFOUR,
   STNUMARM1,STNUMARM2,ASLCODE from #Final
   order by ASLCODE,ASLARTICLE,ANNEE,ARLIB,ASLDEPOT
else
   select ASLARTICLE,ANNEE,ARLIB,ASLDEPOT,sum(ASLQTE),sum(VALEURFINAL),ASLCOMMENT,ASLDATE,ARREFFOUR,'','','' from #Final
   group by ASLARTICLE,ANNEE,ARLIB,ASLDEPOT,ASLCOMMENT,ASLDATE,ARREFFOUR
   order by ASLARTICLE,ANNEE,ARLIB,ASLDEPOT
   

drop table #Final	

end	



go

