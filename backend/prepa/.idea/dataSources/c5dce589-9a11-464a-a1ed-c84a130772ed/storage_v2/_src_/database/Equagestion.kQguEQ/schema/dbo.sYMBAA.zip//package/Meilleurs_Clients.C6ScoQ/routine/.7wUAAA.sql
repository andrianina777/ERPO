



create procedure Meilleurs_Clients (@ent	char(5) = null,
									@an		smallint)
with recompile
as
begin

set arithabort numeric_truncation off

declare @labase		varchar(30),
		@lignes		int
		
select  @labase = db_name()
select 	@lignes = 0

dump tran @labase with truncate_only

select 	@lignes = count(*) from FME

set rowcount 1000

while @lignes > 0
begin

delete from FME
dump tran @labase with truncate_only

select 	@lignes = count(*) from FME
end

set rowcount 0

dump tran @labase with truncate_only

declare clients cursor
for select STCL
from FST
where STAN between @an-1 and @an
and (@ent is null or STENT=@ent)
group by STCL
for read only

declare @rep		char(8),		/* code du representant */
		@client		char(8),
		@CA			numeric(14,2),
		@repdiv		char(8)			/* code du representant division */

open clients

fetch clients
into @client


while (@@sqlstatus = 0)
begin
	
	select @lignes=@lignes+1
	
	if (@lignes >= 1000)
	begin
		dump tran @labase with truncate_only
		select @lignes = 0
	end
	
	select @rep=isnull(CLREP,'')
	from FCL
	where CLCODE=@client
	and (@ent is null or CLENT=@ent)
		
	
	insert into FME (MEDEP,MEREP,MEREPDIV,MECL,MEGROUPE,MECAAN,MECAAN_1,MEJAN,MEJAN_1,MEFEV,MEFEV_1,
					MEMAR,MEMAR_1,MEAVR,MEAVR_1,MEMAI,MEMAI_1,MEJUN,MEJUN_1,
					MEJUL,MEJUL_1,MEAOU,MEAOU_1,MESEP,MESEP_1,MEOCT,MEOCT_1,
					MENOV,MENOV_1,MEDEC,MEDEC_1,MEDATE,MESANSRFA,MEENT)
	select isnull(ARDEPART,''),@rep,isnull(CLRREPDIV,''),@client,0,
			isnull(sum(case when STAN=@an then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an-1 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS=1 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS=1 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 2 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 2 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 3 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 3 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 4 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 4 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 5 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 5 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 6 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 6 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 7 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 7 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 8 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 8 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 9 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 9 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 10 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 10 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 11 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 11 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 12 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 12 then STCAFA else 0 end),0),
			getdate(),0,STENT
	from FST,FAR,FCLR
	where START=ARCODE
	and STAN between @an-1 and @an
	and STCL=@client
	and CLRCL=@client
	and CLRDIV=*ARDEPART
	and (@ent is null or STENT=@ent)
	group by ARDEPART,CLRREPDIV,STENT
	
	insert into FME (MEDEP,MEREP,MEREPDIV,MECL,MEGROUPE,MECAAN,MECAAN_1,MEJAN,MEJAN_1,MEFEV,MEFEV_1,
					MEMAR,MEMAR_1,MEAVR,MEAVR_1,MEMAI,MEMAI_1,MEJUN,MEJUN_1,
					MEJUL,MEJUL_1,MEAOU,MEAOU_1,MESEP,MESEP_1,MEOCT,MEOCT_1,
					MENOV,MENOV_1,MEDEC,MEDEC_1,MEDATE,MESANSRFA,MEENT)
	select isnull(ARDEPART,''),@rep,isnull(CLRREPDIV,''),@client,0,
			isnull(sum(case when STAN=@an then STCAFA else 0 end),0),
			isnull(sum(case when STAN=@an-1 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS=1 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS=1 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 2 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 2 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 3 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 3 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 4 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 4 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 5 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 5 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 6 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 6 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 7 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 7 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 8 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 8 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 9 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 9 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 10 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 10 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 11 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 11 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an and STMOIS between 1 and 12 then STCAFA else 0 end),0),
			isnull(sum(case	when STAN=@an-1 and STMOIS between 1 and 12 then STCAFA else 0 end),0),
			getdate(),1,STENT
	from FST,FAR,FCLR
	where START=ARCODE
	and CLRCL=@client
	and CLRDIV=*ARDEPART
	and ARTYPE != 6
	and STAN between @an-1 and @an
	and STCL=@client
	and (@ent is null or STENT=@ent)
	group by ARDEPART,CLRREPDIV,STENT
	

	fetch clients
	into @client
		
end

close clients
deallocate cursor clients

dump tran @labase with truncate_only

end



go

