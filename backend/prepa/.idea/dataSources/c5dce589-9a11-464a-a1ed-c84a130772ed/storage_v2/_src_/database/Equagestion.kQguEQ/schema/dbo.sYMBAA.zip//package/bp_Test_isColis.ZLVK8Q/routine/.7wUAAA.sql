/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_Test_isColis
grant execute on bp_Test_isColis to public
@code+'-'@i+'-'@colis
*/

CREATE PROCEDURE dbo.bp_Test_isColis(@codeArticle char(15),@qte int,@ordre int,@test int,@tarif char(10))
with recompile
AS
begin
	declare @colisage int,
			@pvht	numeric(14,2),
			@rest int,
			@nb	int,
			@m_count int,
			@total int,
			@taux numeric(14,2),
			@prixNormal numeric(14,2)
			
			
	create table #result(
		m_colisage int null,
		--m_prix_total numeric(14,2) null,
		m_qteVendu int null,
		m_propos varchar(25) null,
		m_reste	int null,
		m_prix_pack	numeric(14,2) null,
		m_nb	int
	)
	
	select @prixNormal=ARTPVHT from FART where ARTAR=@codeArticle  and ARTTARIF=@tarif
	
	select @taux=xTaux from xTarifSpecial where xTarif=@tarif 
	
	select @m_count=count(*) from xParColis where xColis_Article=@codeArticle and current_date()  between convert(Date,xColis_DateDeb) and convert(Date,xColis_DateFin) and xColis_Article not in 
	
	(select 	distinct PROMOARTICLE     from FPROMO where convert(smalldatetime,PROMODATEDEB) <= convert(smalldatetime,current_date()) and convert(smalldatetime,current_date()) <= convert(smalldatetime,PROMODATEFIN)  and PROMOQTEBASE <= @qte
     and (PROMOARTICLE=@codeArticle) ) group by xColis_Article
	 
	select @total=@m_count
	 
	if(@m_count>1)	
	begin 
		declare liste cursor for select xColis_Colisage,xColis_PVHT*(1+@taux/100) from xParColis where xColis_Article=@codeArticle and current_date()  between convert(Date,xColis_DateDeb) and convert(Date,xColis_DateFin) 
		order by case when @ordre=0 or min(xColis_Colisage)>@qte  then xColis_Colisage end , case when @ordre=1 then xColis_Colisage end desc
	
		open liste
		fetch liste into @colisage,@pvht
		while (@@sqlstatus=0)
		begin
				select @m_count=@m_count-1
				select @nb=round(@qte/@colisage,0)
				select @rest=0
				
				if(@colisage=@qte) 
					begin
						insert into #result select @colisage,@qte,'1 pack de '+convert(char,@colisage),0,@pvht,1
						select @qte=0 
					end			
				else if (0.50*@colisage<=@qte and @qte<@colisage /*and @m_count<2*/ and @test=1)
					 begin
						 insert into #result select @colisage,@colisage,'1 pack de '+rtrim(convert(char,@colisage)),0,@pvht,1
						 select @qte=0
					 end
				else if(@colisage<@qte) 
					begin
						if(@test=1)
							begin
								select @rest=@qte%@colisage
								if((@colisage/2)<=@rest) select @nb=round(@qte/@colisage,0)+1
								else select @nb=round(@qte/@colisage,0)
							end
						
						insert into #result select @colisage,@nb*@colisage,case when @nb>1 then rtrim(convert(char,@nb))+' packs de '+rtrim(convert(char,@colisage)) else 
						rtrim(convert(char,@nb))+' pack de '+rtrim(convert(char,@colisage)) end,case when (@qte-(round(@qte/@colisage,0)*@colisage))<0 then 0 else @qte-(round(@qte/@colisage,0)*@colisage) end,@pvht,round(@qte/@colisage,0)
						select @qte=@qte-@nb*@colisage	
					end
				else if(@m_count=1) and (0.50*@colisage>@qte) 
				   begin		   	  	
				 	   insert into #result select 0,@qte,'',0,0,0 where @qte>0
					   select @qte=0
				   end
				
	
		fetch liste into @colisage,@pvht
		end 
		close liste
		deallocate cursor liste	
	end
	
	else if(@m_count=1)
	begin
		select @colisage=xColis_Colisage,@pvht=xColis_PVHT*(1+@taux/100) from xParColis where xColis_Article=@codeArticle and current_date()  between convert(Date,xColis_DateDeb) and convert(Date,xColis_DateFin) order by xColis_Colisage desc
		
		select @rest=@qte%@colisage
		
		if((@colisage/2)<=@rest) select @nb=round(@qte/@colisage,0)+1
		else select @nb=round(@qte/@colisage,0)
	
		if(@colisage=@qte) 
			insert into #result select @colisage,@qte,'1 pack de '+convert(char,@colisage),0,@pvht,1 			
		else if (0.50*@colisage<=@qte and @qte<@colisage)
			insert into #result select @colisage,@colisage,'1 pack de '+rtrim(convert(char,@colisage)),0,@pvht,1
		else if(@colisage<@qte)
			insert into #result select @colisage,@nb*@colisage,case when @nb>1 then rtrim(convert(char,@nb))+' packs de '+rtrim(convert(char,@colisage)) else rtrim(convert(char,@nb))+' pack de '+rtrim(convert(char,@colisage)) end,@qte-(round(@qte/@colisage,0)*@colisage),@pvht,round(@qte/@colisage,0)
		else
		   insert into #result select 0,@qte,'',0,0,0
	end
	
	select isnull(m_colisage,0),isnull(m_qteVendu,0), isnull(m_propos,''),isnull(m_reste,0),isnull(m_prix_pack,0),isnull(m_nb,0),sum(isnull(m_qteVendu,0)),0,@total,@prixNormal from #result where isnull(m_qteVendu,0)>0
	
	drop table #result
end
go

