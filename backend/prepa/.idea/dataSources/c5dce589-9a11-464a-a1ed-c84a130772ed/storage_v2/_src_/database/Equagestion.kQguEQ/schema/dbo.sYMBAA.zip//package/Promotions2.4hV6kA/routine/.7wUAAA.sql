/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.Promotions2
grant execute on Promotions2 to public
*/




/* Procedure utilisee pour le calcul d un prix de vente a partir des promotions */
/* sur une ligne de devis, commande ou expedition */
/* renvoie la liste la plus precise des rubriques d une ligne de promotion */

CREATE PROCEDURE dbo.Promotions2 (@ent		char(5)            = null,
							 @date		smalldatetime,
							 @client	char(12),
							 @tarif		char(8),
							 @article	char(15),
							 @qte		int,
							 @numlot	char(12)
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @depart				char(8),
		@marque				char(12),
		@fam				char(8),
		@categ				char(8),
		@activite			char(6),
		@seq				int,
		@pvht_out      		numeric(14,2),
		@remise3_out        numeric(8,4),
		@cumulremises_out   tinyint,
		@typeve_out     	char(4),
		@articleoffert_out 	char(15),
		@qteoffert_out    	int,
		@valide_out        	int
		
		
		select @seq = 0        
		select @depart=ARDEPART, @marque=ARFO, @fam=ARFAM, @categ=ARGRFAM,@typeve_out=ARTYPEVE
		from FAR
		where ARCODE=@article
		
		select @pvht_out=ARTPVHT from FART where ARTAR=@article and ARTTARIF=@tarif  
		
		select @activite = CLSA
		from FCL
		where CLCODE = @client

		set rowcount 1
       	 select  case when isnull(PROMOPRIX,0)<>0 and isnull(PROMOPC,0)=0    then isnull(PROMOPRIX,0) 
       	 		/*when isnull(PROMOPC,0)<>0 and isnull(PROMOPRIX,0)=0  then @pvht_out*(1-isnull(PROMOPC,0)/100) 
       	 		when isnull(PROMOPC,0)<>0 and isnull(PROMOPRIX,0)<>0  then isnull(PROMOPRIX,0)*(1-isnull(PROMOPC,0)/100) */
       	 		else  @pvht_out end, isnull(PROMOPC,0) as remise, isnull(PROMOCUMULREM,0) as cumul,
             isnull(PROMOTYPEVE,'') as Typedeve, articleoffert_out = isnull(PROMOARTICLEOFFERT,''),
           ( isnull(PROMOQTEOFFERT,0)*(@qte/(case when isnull(PROMOQTEBASE,0)=0 then 1 else isnull(PROMOQTEBASE,1) end))) as qteoffert,
             PROMOSEQ
        from FPROMO
 
        where convert(smalldatetime,PROMODATEDEB) <= convert(smalldatetime,current_date()) and convert(smalldatetime,current_date()) <= convert(smalldatetime,PROMODATEFIN) 

        and PROMOQTEBASE <= @qte
        and (PROMOARTICLE=@article or PROMOARTICLE='' or PROMOARTICLE=null)  
        and (PROMOLOT= @numlot or PROMOLOT='' or PROMOLOT=null)
        and  (PROMOCATEG=@categ or PROMOCATEG='' or PROMOCATEG=null)
        and ( PROMOFAM=@fam or PROMOFAM='' or PROMOFAM=null)
        and (PROMOMARQUE=@marque or  PROMOMARQUE='' or PROMOMARQUE=null)
        and (PROMODEPART=@depart or PROMODEPART='' or PROMODEPART=null) 
        and (PROMOTYPEVE=@typeve_out or PROMOTYPEVE='' or PROMOTYPEVE=null) 
        and (PROMOTARIF=@tarif or PROMOTARIF=null or PROMOTARIF='')
        and (PROMOCL=@client or PROMOCL='' or PROMOCL=null)
        and (PROMOSA=@activite or  PROMOSA='' or PROMOSA=null)
        order by PROMOQTEBASE DESC
        
        set rowcount 0
       -- end
end
go

