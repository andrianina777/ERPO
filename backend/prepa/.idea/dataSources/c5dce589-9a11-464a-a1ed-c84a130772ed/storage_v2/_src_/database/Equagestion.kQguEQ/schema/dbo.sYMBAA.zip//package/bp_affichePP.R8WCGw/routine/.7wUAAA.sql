/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_affichePP
grant execute on bp_affichePP to public
*/

CREATE PROCEDURE dbo.bp_affichePP(@client char(10),@facture char(10))
with recompile
AS
begin
	select CLIENT,NOM,FACTURE,DATE,ARTICLE,LIBELLE,TOTAL,QTE_RESTANTE from VIEW_FACTURE_RESERVE_TOTAL
	where (CLIENT=@client or @client='' or @client=null) and (FACTURE=@facture or @facture='' or @facture=null)
	order by DATE,CLIENT,NOM,ARTICLE,LIBELLE
end
go

