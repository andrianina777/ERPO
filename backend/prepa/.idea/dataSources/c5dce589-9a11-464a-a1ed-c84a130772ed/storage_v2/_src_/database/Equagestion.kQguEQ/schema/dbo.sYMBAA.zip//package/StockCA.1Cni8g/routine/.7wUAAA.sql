


create procedure StockCA(@ent		char(5)	= null,
						 @Famille	char(8) = null,
						 @Article	char(15)	= null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1	datetime
declare @date2	datetime
select @date1 = convert (datetime,("01/01/"+convert(char(4),datepart(yy,getdate()))))
select @date2 = convert (datetime,("12/31/"+convert(char(4),datepart(yy,getdate()))))

create table #Stock
(
Article_ST		char(15)		null,
Qte_ST			int				null,
PR_ST			numeric(14,2)	null,
Cdes_CF			int				null,
Valeur_CF		numeric(14,2)		null,
Ventes			int				null,
CA				numeric(14,2)	null,
Ratio			numeric(14,2)	null,
Marge			numeric(14,2)	null
)

create table #Fal
(
Article_FA		char(15)		null,
Qte_FA			int				null,
PV_FA			numeric(14,2)	null
)

create table #Bel
(
Article_BE		char(15)		null,
Qte_BE			int				null,
PV_BE			numeric(14,2)	null
)

create table #Cfl
(
Article_CF		char(15)		null,
Qte_CF			int				null,
PA_CF			numeric(14,2)	null
)

create table #Far
(
ARFAM			char(8)			null,
ARFO			char(12)		null,
ARCODE			char(15)		null,
ARLIB			varchar(80)		null,
CVLOT			int				null
)

create table #Far2
(
ARFAM			char(8)			null,
ARFO			char(12)		null,
ARCODE			char(15)	not null,
ARLIB			varchar(80)		null,
CVLOT			int				null
)


if ((@Famille is null) and (@Article is null))
	begin
		insert into #Far (ARFAM,ARFO,ARCODE,ARLIB,CVLOT)
		select ARFAM,ARFO,ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARUNITACHAT=CVUNIF
	end
else if ((@Famille is null) and (@Article is not null))
	begin
		insert into #Far (ARFAM,ARFO,ARCODE,ARLIB,CVLOT)
		select ARFAM,ARFO,ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARCODE=@Article
		and ARUNITACHAT=CVUNIF
	end
else if ((@Famille is not null) and (@Article is null))
	begin
		insert into #Far (ARFAM,ARFO,ARCODE,ARLIB,CVLOT)
		select ARFAM,ARFO,ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFAM=@Famille
		and ARUNITACHAT=CVUNIF
	end
else if ((@Famille is not null) and (@Article is not null))
	begin
		insert into #Far (ARFAM,ARFO,ARCODE,ARLIB,CVLOT)
		select ARFAM,ARFO,ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFAM=@Famille
		and ARCODE=@Article
		and ARUNITACHAT=CVUNIF
	end

/* Adaptive Server has expanded all ''*'' elements in the following statement */ insert into #Far2
select #Far.ARFAM, #Far.ARFO, #Far.ARCODE, #Far.ARLIB, #Far.CVLOT from #Far

create unique clustered index code on #Far(ARCODE)
create unique clustered index code on #Far2(ARCODE)




insert into #Stock (Article_ST,Qte_ST,PR_ST,Cdes_CF,Valeur_CF,Ventes,CA,Ratio,Marge)
select STAR,sum(STQTE),sum(round(((STPAHT+STFRAIS)/CVLOT),2)*STQTE),
0,0,0,0,0,0
from #Far2,FSTOCK,FDP
where ARCODE=STAR
and STQTE > 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by STAR

insert into #Cfl (Article_CF,Qte_CF,PA_CF)
select ARCODE,sum(RCFQTE),sum(round((CFLTOTALHT/CFLQTE),2)*RCFQTE*(1+CFFRAIS/100))
from #Far2,FRCF,FCFL,FCF
where ARCODE=RCFARTICLE
and CFLSEQ=RCFSEQ
and CFLCODE=CFCODE
and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT and CFENT=RCFENT))
group by ARCODE


insert into #Fal (Article_FA,Qte_FA,PV_FA)
select ARCODE,sum(FALQTE),sum(FALTOTALHT)
from #Far,FFAL(4)
where ARCODE=FALARTICLE
and isnull(FALLETTRE,'') != ''
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
union
select ARCODE,0,sum(FALTOTALHT)
from #Far,FFAL(4)
where ARCODE=FALARTICLE
and isnull(FALLETTRE,'') = ''
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by ARCODE


insert into #Bel
select Article_BE=ARCODE,Qte_BE=sum(BELQTE),PV_BE=sum(BELTOTALHT)
from #Far2,FRBE,FBEL
where RBEDATE between @date1 and @date2
and RBEARTICLE=ARCODE
and RBESEQ=BELSEQ
and RBEDEMO=0
and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))
group by ARCODE


drop table #Far2

create unique clustered index code on #Stock(Article_ST)
create unique clustered index code on #Fal(Article_FA)
create unique clustered index code on #Bel(Article_BE)
create unique clustered index code on #Cfl(Article_CF)

insert into #Stock
select Article_CF,0,0,0,0,0,0,0,0
from #Cfl
where Article_CF not in(select Article_ST from #Stock)

update #Stock
set Cdes_CF=Qte_CF,Valeur_CF=PA_CF
from #Cfl
where Article_CF=Article_ST

insert into #Fal
select Article_BE,0,0
from #Bel
where Article_BE not in(select Article_FA from #Fal)

update #Fal
set Qte_FA = Qte_FA+Qte_BE, PV_FA = PV_FA+PV_BE
from #Bel
where Article_BE=Article_FA

insert into #Stock
select Article_FA,0,0,0,0,0,0,0,0
from #Fal
where Article_FA not in(select Article_ST from #Stock)

update #Stock
set Ventes=Qte_FA,CA=PV_FA
from #Fal
where Article_FA=Article_ST

update #Stock
set Ratio=isnull(round(CA/PR_ST,2),0)
where PR_ST != 0

update #Stock
set Marge=isnull(round(((CA/(Ventes+(1-abs(sign(Ventes)))))
			-(PR_ST/(Qte_ST+(1-abs(sign(Qte_ST))))))/
			(CA/(Ventes+(1-abs(sign(Ventes))))),2),0)
where CA != 0


select Fournisseur=ARFO,Famille=ARFAM,Article=Article_ST,
Designation=ARLIB,Qte_en_Stock=Qte_ST,Prix_de_revient=PR_ST,
Commandes_Fournis=Cdes_CF,Prix_achat_Fournis=convert(numeric(14,2),Valeur_CF),
Ventes=Ventes,Ca_realise=convert(numeric(14,2),CA),Ratio=convert(numeric(14,2),Ratio),
Marge=convert(numeric(14,2),Marge*100),'%'
from #Stock,#Far
where ARCODE=Article_ST
order by ARFO,ARFAM,Article_ST
compute sum(Qte_ST),sum(PR_ST),sum(Cdes_CF),sum(convert(numeric(14,2),Valeur_CF)),sum(Ventes),sum(convert(numeric(14,2),CA)) by ARFO,ARFAM
compute sum(Qte_ST),sum(PR_ST),sum(Cdes_CF),sum(convert(numeric(14,2),Valeur_CF)),sum(Ventes),sum(convert(numeric(14,2),CA)) by ARFO
compute sum(Qte_ST),sum(PR_ST),sum(Cdes_CF),sum(convert(numeric(14,2),Valeur_CF)),sum(Ventes),sum(convert(numeric(14,2),CA))


drop table #Cfl
drop table #Bel
drop table #Fal
drop table #Stock
drop table #Far


end



go

