


/* Procedure utilisee pour l''enregistrement des stocks constates
	pour un mois et une annee donnes.
	Cette procedure cree le premier mois de la table FSK */

create procedure A_SKConst1 (@Annee		smallint,
							 @Mois		tinyint)
with recompile
as
begin

delete FSK
where SKAN=@Annee
and SKMOIS=@Mois

declare @date			datetime

select @date=convert(datetime,convert(char(2),@Mois)+"/01/"+convert(char(4),@Annee))

create table #StockPrec
(
ArticleP		char(15)	not null,
QteP			int				null
)

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #StockPrec
select SILARTICLE,sum(SILQTE)
from FSIL
where SILDATE < @date
group by SILARTICLE


/* ''Reajustements - Fichier RJL'' */

insert into #StockPrec
select RJLARTICLE,sum(RJLQTE)
from FRJL
where RJLDATE < @date
group by RJLARTICLE


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #StockPrec
select BLLAR,sum(BLLQTE)
from FBLL
where BLLDATE < @date
group by BLLAR


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #StockPrec
select DOLAR,sum(DOLQTE)
from FDOL
where DOLDATE < @date
group by DOLAR


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #StockPrec
select RFLARTICLE,-sum(RFLQTE)
from FRFL
where RFLDATE < @date
group by RFLARTICLE


/* ""Lignes de BE - Fichier FBEL"" */

insert into #StockPrec
select BELARTICLE,-sum(BELQTE)
from FBEL
where BELDATE < @date
and BELARTICLE != ""
group by BELARTICLE


/* Stock */

insert into FSK (SKAN, SKMOIS, SKARTICLE, SKQTE, SKDIF, SKDATEMAJ)
select @Annee, @Mois, ArticleP, sum(isnull(QteP,0)), ((@Annee-1992)*12)+@Mois, getdate()
from #StockPrec
group by ArticleP

drop table #StockPrec

end



go

