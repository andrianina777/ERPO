


/* Procedure permettant de recuperer les commandes clients sur une annee
	pour un article dans le fichier FSP  */
	
	
create procedure A_StockP (	@Article	char(8),
						    @Annee	smallint)
with recompile
as
begin

set arithabort numeric_truncation off


declare @Janvier	int
declare @Fevrier	int
declare @Mars		int
declare @Avril		int
declare @Mai		int
declare @Juin		int
declare @Juillet	int
declare @Aout		int
declare @Septembre	int
declare @Octobre	int
declare @Novembre	int
declare @Decembre	int

declare @Janval		int
declare @Fevval		int
declare @Marval		int
declare @Avrval		int
declare @Maival		int
declare @Junval		int
declare @Juival		int
declare @Aouval		int
declare @Sepval		int
declare @Octval		int
declare @Novval		int
declare @Decval		int

declare @Prix		numeric(14,2)

select @Prix=ARPRM from FAR where ARCODE=@Article


select @Janvier=SPQTE,	@Janval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=1
select @Fevrier=SPQTE,	@Fevval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=2
select @Mars=SPQTE,		@Marval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=3
select @Avril=SPQTE,	@Avrval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=4
select @Mai=SPQTE,		@Maival=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=5
select @Juin=SPQTE,		@Junval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=6
select @Juillet=SPQTE,	@Juival=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=7
select @Aout=SPQTE,		@Aouval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=8
select @Septembre=SPQTE,@Sepval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=9
select @Octobre=SPQTE,	@Octval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=10
select @Novembre=SPQTE,	@Novval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=11
select @Decembre=SPQTE,	@Decval=SPQTE * @Prix from FSP where SPARTICLE=@Article and SPAN=@Annee and SPMOIS=12


select 	isnull(@Janvier,0),isnull(@Fevrier,0),isnull(@Mars,0),
		isnull(@Avril,0),isnull(@Mai,0),isnull(@Juin,0),
		isnull(@Juillet,0),isnull(@Aout,0),isnull(@Septembre,0),
		isnull(@Octobre,0),isnull(@Novembre,0),isnull(@Decembre,0),
		isnull(@Janval,0),isnull(@Fevval,0),isnull(@Marval,0),
		isnull(@Avrval,0),isnull(@Maival,0),isnull(@Junval,0),
		isnull(@Juival,0),isnull(@Aouval,0),isnull(@Sepval,0),
		isnull(@Octval,0),isnull(@Novval,0),isnull(@Decval,0)
end



go

