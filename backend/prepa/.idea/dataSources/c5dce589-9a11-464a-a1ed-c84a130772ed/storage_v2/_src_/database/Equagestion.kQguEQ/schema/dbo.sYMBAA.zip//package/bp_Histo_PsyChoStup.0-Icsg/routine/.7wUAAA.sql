CREATE PROCEDURE dbo.bp_Histo_PsyChoStup (@CodeCient char(25), @CodeArticle char(30))--, @Stup int,@psycho int, @datedeb Smalldatetime ,@datefin smalldatetime)

AS
begin

select FALARTICLE, ARLIB, FACL, FANOM, FALDATECRE, xARTP_STUPEFIANT, xARTP_PSYCHOTROPE, xStatut, FALQTE 
from bp_Histo_PSpecial
--where    (@CodeCient='' or @CodeCient=NULL or CLCODE=@CodeCient) 
/*and (@CodeArticle='' or @CodeArticle=NULL or ARCODE=@CodeArticle)

*/
--where CLCODE='PT114'
end
go

