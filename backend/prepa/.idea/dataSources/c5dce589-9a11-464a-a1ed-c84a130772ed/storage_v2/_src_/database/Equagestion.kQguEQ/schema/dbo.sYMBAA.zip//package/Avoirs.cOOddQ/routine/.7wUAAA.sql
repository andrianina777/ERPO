

create procedure Avoirs	(	@ent			char(5) = null,
							@FromClient 	char(12) = null,
						 	@ToClient 		char(12) = null,
						 	@FromDate 		smalldatetime = null,
						 	@ToDate 		smalldatetime = null,
							@modefact		tinyint		  = 0,		/* 0 = tous les BE, 1 = par BE et autres */
							@periode		tinyint	 	  = 0
						   )
with recompile
as
begin

if @ToClient is null
select @ToClient=@FromClient

if @ToDate is null
select @ToDate=@FromDate

declare	@mode0	tinyint,
		@mode1	tinyint,
		@mode2	tinyint,
		@mode3	tinyint

if @modefact=0
	select	@mode0=0, @mode1=0, @mode2=0, @mode3=0
else
	select	@mode0=1, @mode1=1, @mode2=2, @mode3=3


select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
 BELREMISE1,BELREMISE2,BELREMISE3,
 BELUNITFACT,BELTYPE=isnull(BELTYPE,0),BELLIBRE,BELTOTALHT,BELTYPEVE,BELMOTIF,
 BELDEV,BETARIF,BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,
 BEADR1=isnull(BEADR1,""),BEADR2=isnull(BEADR2,""),BECP=isnull(BECP,""),BELOFFERT=isnull(BELOFFERT,0),
 BELMARCHE=isnull(BELMARCHE,""),BELCOLIS=isnull(BELCOLIS,0)
into #BE
from FBEL,FRBE,FBE,FCL
 where BELSEQ=RBESEQ
 and RBECL=CLCODE
 and CLMODEFACT in (@mode0, @mode1, @mode2, @mode3)
 and RBEARTICLE != ''
 and RBEDEMO=0
 and (@FromClient is null or RBECL between @FromClient and @ToClient)
 and (@FromDate is null or RBEDATE between @FromDate and @ToDate)
 and RBEECH=0
 and BECODE=BELCODE
 and isnull(BELTYPEVE,'')!=''
 and BELQTE < 0
 and (@ent is null or (BELENT=@ent and RBEENT=@ent and BEENT=@ent)) 
 and CLFACTPERIODE = @periode


if @modefact = 0
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,"",BELMOTIF,BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,"","",0,BELCOLIS
	from #BE
	order by BELCL,BELDEV,BEADR1,BEADR2,BECP,BELCODE,BELNUM
	
	drop table #BE
end
else if @modefact = 1
begin
	select BELCL,BELCODE,BELNUM,BELARTICLE,BELLETTRE,BELQTE,BELPRIXHT,
	 BELREMISE1,BELREMISE2,BELREMISE3,
	 BELUNITFACT,BELTYPE,BELLIBRE,BELTOTALHT,BELTYPEVE,"",BELMOTIF,BELDEV,BETARIF,
	 BELPRIXHTDEV,BELTOTALHTDEV,BELCOURSDEV,BEADR1,BEADR2,BECP,BELOFFERT,BELMARCHE,"","",0,BELCOLIS
	from #BE
	order by BELCODE,BELNUM
	
	drop table #BE
end

end
go

