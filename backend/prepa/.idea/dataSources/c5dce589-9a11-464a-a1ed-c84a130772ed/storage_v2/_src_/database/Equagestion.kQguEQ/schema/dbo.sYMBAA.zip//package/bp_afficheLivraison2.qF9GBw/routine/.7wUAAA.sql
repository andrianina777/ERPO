/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheLivraison
grant execute on bp_afficheLivraison to public
*/

CREATE PROCEDURE dbo.bp_afficheLivraison2(@code_liv char(10),@code_commande char(10),@date smalldatetime,@chaf varchar(25),@voit varchar(25),@m_saisie int)

AS
begin
	if (@m_saisie=0)
	begin
		select distinct xLIV_CODE,xLIV_SORTIE,xLIV_COM,xLIV_CHAUF,xLIV_VOIT,(case when xLIVSAISIE=1 then 'OUI' else 'NON' end) as x_saisie,xLIV_LIVREUR,xLIV_AXE,xLIVREMPLI,xLIVSAISIE,xLIV_SEQ2,xLIV_SEQ,isnull(xLIV_TYPE,0) ,convert(varchar(50),xLIV_SEQ2),convert(varchar(50),xLIV_SEQ)
		from xCH_LIVRAISON inner join xVOITURE on xNUM=xLIV_VOIT where /*xCode<>'11111' and */
		(upper(xLIV_CODE) like upper('%'+convert(varchar,@code_liv)+'%') or @code_liv='' or @code_liv=null)
		and (upper(xLIV_COM) like upper('%'+convert(varchar,@code_commande)+'%') or @code_commande='' or @code_commande=null)
		and convert(date,xLIV_SORTIE)=@date
		and (upper(xLIV_CHAUF) like upper('%'+convert(varchar,@chaf)+'%') or @chaf='' or @chaf=null)
		and (upper(xLIV_VOIT) like upper('%'+convert(varchar,@voit)+'%') or @voit='' or @voit=null)
		and isnull(xLIVSAISIE,0)=1 
		and isnull(xType_Service,'')=(case when (select count(*) from EquaPRO..KGroupes_Membres where upper(KGMGPEID) in (upper('OPH_ASTDIR')) and KGMUSRID=suser_name())>0
		then 'ADMIN' else '' end)
		order by xLIV_SORTIE desc,xLIV_CHAUF
	end
	else if(@m_saisie=1)
	begin
		select distinct xLIV_CODE,xLIV_SORTIE,xLIV_COM,xLIV_CHAUF,xLIV_VOIT,(case when xLIVSAISIE=1 then 'OUI' else 'NON' end) as x_saisie,xLIV_LIVREUR,xLIV_AXE,xLIVREMPLI,xLIVSAISIE,xLIV_SEQ2,xLIV_SEQ,isnull(xLIV_TYPE,0)  ,convert(varchar(50),xLIV_SEQ2),convert(varchar(50),xLIV_SEQ)
		from xCH_LIVRAISON inner join xVOITURE on xNUM=xLIV_VOIT where /*xCode<>'11111' and */(upper(xLIV_CODE) like upper('%'+convert(varchar,@code_liv)+'%') or @code_liv='' or @code_liv=null)
		and 
		(upper(xLIV_COM) like upper('%'+convert(varchar,@code_commande)+'%') or @code_commande='' or @code_commande=null)
		and convert(date,xLIV_SORTIE)=@date
		and (upper(xLIV_CHAUF) like upper('%'+convert(varchar,@chaf)+'%') or @chaf='' or @chaf=null)
		and (upper(xLIV_VOIT) like upper('%'+convert(varchar,@voit)+'%') or @voit='' or @voit=null)
		and isnull(xLIVSAISIE,0)=0
		and isnull(xType_Service,'')=(case when (select count(*) from EquaPRO..KGroupes_Membres where upper(KGMGPEID) in (upper('OPH_ASTDIR')) and KGMUSRID=suser_name())>0
		then 'ADMIN' else '' end)
		order by xLIV_SORTIE desc,xLIV_CHAUF
	end
	else
	begin
		select distinct xLIV_CODE,xLIV_SORTIE,xLIV_COM,xLIV_CHAUF,xLIV_VOIT,(case when xLIVSAISIE=1 then 'OUI' else 'NON' end) as x_saisie,xLIV_LIVREUR,xLIV_AXE,xLIVREMPLI,xLIVSAISIE,xLIV_SEQ2,xLIV_SEQ,isnull(xLIV_TYPE,0)  ,convert(varchar(50),xLIV_SEQ2),convert(varchar(50),xLIV_SEQ)
		from xCH_LIVRAISON inner join xVOITURE on xNUM=xLIV_VOIT where /*xCode<>'11111' and*/ 
		(upper(xLIV_CODE) like upper('%'+convert(varchar,@code_liv)+'%') or @code_liv='' or @code_liv=null)
		and (upper(xLIV_COM) like upper('%'+convert(varchar,@code_commande)+'%') or @code_commande='' or @code_commande=null)
		and convert(date,xLIV_SORTIE)=@date
		and (upper(xLIV_CHAUF) like upper('%'+convert(varchar,@chaf)+'%') or @chaf='' or @chaf=null)
		and (upper(xLIV_VOIT) like upper('%'+convert(varchar,@voit)+'%') or @voit='' or @voit=null)
		and isnull(xType_Service,'')=(case when (select count(*) from EquaPRO..KGroupes_Membres where upper(KGMGPEID) in (upper('OPH_ASTDIR')) and KGMUSRID=suser_name())>0
		then 'ADMIN' else '' end)
		order by xLIV_SORTIE desc,xLIV_CHAUF
	end
	
end
go

