




create procedure TotalBEHT(	@ent	char(5) = null,
							@code 	char(10))
as
begin

	set arithabort numeric_truncation off


	declare @Total numeric(14,2),
			@TotalDev numeric(14,2)
			
	select @Total=sum(BELTOTALHT), @TotalDev=round(sum(BELTOTALHT*BECOURSDEV),2)
	from FBEL,FBE
	where BELCODE=@code
	and BECODE=BELCODE
	and BELQTE!=0
	and (@ent is null or BELENT=@ent)
	
	
	update FBE
	set BETOTALHT=@Total,BETOTALHTDEV=@TotalDev
	where BECODE=@code and (@ent is null or BEENT=@ent)
	
	
end



go

