


create procedure VentesChef	(@ent	char(5)	= null,
							 @chef	char(8),
							 @date1 datetime,
							 @date2 datetime)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Lignes
(
fourn		char(12)		not null,
marque		char(12)		not null,
ventes		numeric(14,2)		null
)


insert into #Lignes (fourn,marque,ventes)
select STFO,ARFO,sum(FALTOTALHT)
from FFAL(4),FSTOCK,FAR
where ARCODE=FALARTICLE
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and ARCHEFP=@chef
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by STFO,ARFO


select "Fournisseur","Marque","Ventes"
select fourn,marque,isnull(ventes,0)
from #Lignes
order by fourn,marque

drop table #Lignes

end



go

