

/* Procedure calculant la valeur du stock de janvier au mois donne pour l'annee choisie
	a partir des lignes de mouvement de stock */


create procedure Stock_Ventes_Achats(@an		int,
							 		 @mois		int,
									 @compare	int = 0,
									 @depart	char(8) = null,
									 @produits	smallint = 0,
									 @prodnsto	smallint = 1,
									 @services	smallint = 2,
									 @ports		smallint = 3,
									 @comments	smallint = 4,
									 @remises	smallint = 5,
									 @rfa		smallint = 6,
									 @assur		smallint = 7,
									 @sansval	tinyint = 0,		/* sans les valeurs a 0 */
									 @marque	char(12) = null,
									 @famille	char(8) = null
									 )
with recompile
as
begin

set arithabort numeric_truncation off

declare @modevalo	int
select  @modevalo = PMODEVALO from KParam

if (@mois<1 or @mois>12) 
select @mois=12

declare @datedeb	smalldatetime,
		@datefin	smalldatetime

select  @datedeb = convert(smalldatetime,convert(varchar,@an)+"0101")

if @mois=1
	select  @datefin=convert(varchar(4),@an)+"0131"
else if @mois=2
	begin
	select  @datefin=convert(varchar(4),@an)+"0301"
	select  @datefin=dateadd(dd,-1,@datefin)
	end
else if @mois=3
	select  @datefin=convert(varchar(4),@an)+"0331"
else if @mois=4
	select  @datefin=convert(varchar(4),@an)+"0430"
else if @mois=5
	select  @datefin=convert(varchar(4),@an)+"0531"
else if @mois=6
	select  @datefin=convert(varchar(4),@an)+"0630"
else if @mois=7
	select  @datefin=convert(varchar(4),@an)+"0731"
else if @mois=8
	select  @datefin=convert(varchar(4),@an)+"0831"
else if @mois=9
	select  @datefin=convert(varchar(4),@an)+"0930"
else if @mois=10
	select  @datefin=convert(varchar(4),@an)+"1031"
else if @mois=11
	select  @datefin=convert(varchar(4),@an)+"1130"
else if @mois=12
	select  @datefin=convert(varchar(4),@an)+"1231"


select  @datefin = dateadd(hh,19,@datefin)

create table #Stock
(
depart			char(8)			not null,
marque			char(12)		not null,
famille			char(8)			not null,
valstock		numeric(14,2)	not null,
valventes		numeric(14,2)	not null,
valmarge		numeric(14,2)	not null,
valachat		numeric(14,2)	not null,
valstock_1		numeric(14,2)	not null,
valventes_1		numeric(14,2)	not null,
valmarge_1		numeric(14,2)	not null,
valachat_1		numeric(14,2)	not null
)

create table #Stock2
(
article			char(15)		not null,
qte				int				not null,
valstock		numeric(14,2)	not null,
valventes		numeric(14,2)	not null,
valmarge		numeric(14,2)	not null,
valachat		numeric(14,2)	not null,
valstock_1		numeric(14,2)	not null,
valventes_1		numeric(14,2)	not null,
valmarge_1		numeric(14,2)	not null,
valachat_1		numeric(14,2)	not null,
annee			int				not null,
fact			tinyint			not null,
frais			numeric(14,2)	not null,
seq				numeric(14,0)	identity
)


if @modevalo=0
begin

insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARDEPART,ARFO,ARFAM,sum(isnull(MOISTOTPR,0)),0,0,0,0,0,0,0
from FMOIS,FAR
where ARCODE=MOISARTICLE
and MOISANNEE=@an-1
and MOISMOIS=12
and MOISQTE != 0
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM


insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARDEPART,ARFO,ARFAM,sum(isnull(MSTOTPR,0)),0,0,0,0,0,0,0
from FMS,FAR
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE in ("E","F","R","C","A","M")
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM


insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARDEPART,ARFO,ARFAM,-sum(isnull(MSTOTPR,0)),0,0,0,0,0,0,0
from FMS,FAR
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and @mois
and MSTYPE="S"
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM


insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARDEPART,ARFO,ARFAM,0,sum(isnull(STCAFA,0)),sum(isnull(STCAFA,0))-sum(isnull(STPR,0)),0,0,0,0,0
from FST,FAR
where ARCODE=START
and STAN=@an
and STMOIS between 1 and @mois
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM



insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARDEPART,ARFO,ARFAM,0,0,0,sum(isnull(round(BLLPRHT*BLLQTE/CVLOT,2),0)),0,0,0,0
from FBLL,FAR,FCV
where ARCODE=BLLAR
and CVUNIF=BLLUA
and datepart(yy,BLLDATE)=@an
and datepart(mm,BLLDATE) between 1 and @mois
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM


insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
select ARDEPART,ARFO,ARFAM,0,0,0,-sum(isnull(RFLTOTALHT,0)),0,0,0,0
from FRFL(index date),FAR
where ARCODE=RFLARTICLE
and datepart(yy,RFLDATE)=@an
and datepart(mm,RFLDATE) between 1 and @mois
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM



if @compare=1
  begin
  
	insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,0,0,0,0,sum(isnull(MOISTOTPR,0)),0,0,0
	from FMOIS,FAR
	where ARCODE=MOISARTICLE
	and MOISANNEE=@an-2
	and MOISMOIS=12
	and MOISQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ARDEPART,ARFO,ARFAM


	insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,0,0,0,0,sum(isnull(MSTOTPR,0)),0,0,0
	from FMS,FAR
	where ARCODE=MSARTICLE
	and MSANNEE=@an-1
	and MSMOIS between 1 and @mois
	and MSTYPE in ("E","F","R","C","A","M")
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ARDEPART,ARFO,ARFAM


	insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,0,0,0,0,-sum(isnull(MSTOTPR,0)),0,0,0
	from FMS,FAR
	where ARCODE=MSARTICLE
	and MSANNEE=@an-1
	and MSMOIS between 1 and @mois
	and MSTYPE="S"
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ARDEPART,ARFO,ARFAM


	insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,0,0,0,0,0,sum(isnull(STCAFA,0)),sum(isnull(STCAFA,0))-sum(isnull(STPR,0)),0
	from FST,FAR
	where ARCODE=START
	and STAN=@an-1
	and STMOIS between 1 and @mois
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ARDEPART,ARFO,ARFAM


	insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,0,0,0,0,0,0,0,sum(isnull(round(BLLPRHT*BLLQTE/CVLOT,2),0))
	from FBLL,FAR,FCV
	where ARCODE=BLLAR
	and CVUNIF=BLLUA
	and datepart(yy,BLLDATE)=@an-1
	and datepart(mm,BLLDATE) between 1 and @mois
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ARDEPART,ARFO,ARFAM

	
	insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,0,0,0,0,0,0,0,-sum(isnull(RFLTOTALHT,0))
	from FRFL(index date),FAR
	where ARCODE=RFLARTICLE
	and datepart(yy,RFLDATE)=@an-1
	and datepart(mm,RFLDATE) between 1 and @mois
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ARDEPART,ARFO,ARFAM
	
  end
end
else if @modevalo in (1,2,3,4)
begin

	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select MOISARTICLE,sum(MOISQTE),0,0,0,0,0,0,0,0,1,0,0
	from FMOIS,FAR
	where ARCODE=MOISARTICLE
	and MOISANNEE=@an-1
	and MOISMOIS=12
	and MOISQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by MOISARTICLE
	
	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select BLLAR,sum(BLLQTE),0,0,0,sum(isnull(round(BLLPRHT*BLLQTE/CVLOT,2),0)),0,0,0,0,1,0,0
	from FBLL,FAR,FCV
	where ARCODE=BLLAR
	and CVUNIF=BLLUA
	and BLLDATE between @datedeb and @datefin
	and BLLQTE != 0
	and isnull(BLLLET,"") != ""
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by BLLAR
	
	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select RFLARTICLE,sum(RFLQTE),0,0,0,-sum(isnull(RFLTOTALHT,0)),0,0,0,0,1,0,0
	from FRFL,FAR
	where ARCODE=RFLARTICLE
	and RFLDATE between @datedeb and @datefin
	and RFLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by RFLARTICLE
	

	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select DOLAR,sum(DOLQTE),0,0,0,sum(isnull(round(DOLPRHT*DOLQTE/CVLOT,2),0)),0,0,0,0,1,0,0
	from FDOL,FAR,FCV
	where ARCODE=DOLAR
	and CVUNIF=DOLUA
	and DOLDATE between @datedeb and @datefin
	and DOLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by DOLAR


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select SILARTICLE,sum(SILQTE),0,0,0,0,0,0,0,0,1,0,0
	from FSIL,FAR
	where ARCODE=SILARTICLE
	and SILDATE between @datedeb and @datefin
	and SILQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by SILARTICLE


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select RJLARTICLE,sum(RJLQTE),0,0,0,0,0,0,0,0,1,0,0
	from FRJL,FAR
	where ARCODE=RJLARTICLE
	and RJLDATE between @datedeb and @datefin
	and RJLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by RJLARTICLE


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select ASLARTICLE,sum(ASLQTE),0,0,0,0,0,0,0,0,1,0,0
	from FASL,FAR
	where ARCODE=ASLARTICLE
	and ASLDATE between @datedeb and @datefin
	and ASLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ASLARTICLE


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select LCLARTICLE,sum(LCLQTE),0,0,0,0,0,0,0,0,1,0,0
	from FLCL,FAR
	where ARCODE=LCLARTICLE
	and LCLDATE between @datedeb and @datefin
	and LCLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by LCLARTICLE
	

	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select FALARTICLE,-sum(FALQTE),0,sum(FALTOTALHT),0,0,0,0,0,0,1,1,sum(isnull(FALFRAIS,0))
	from FFAL,FAR
	where ARCODE=FALARTICLE
	and FALDATE between @datedeb and @datefin
	and FALQTE != 0
	and isnull(FALLETTRE,"") != ""
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by FALARTICLE
	
	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select FALARTICLE,0,0,sum(FALTOTALHT),0,0,0,0,0,0,1,1,0
	from FFAL,FAR
	where ARCODE=FALARTICLE
	and FALDATE between @datedeb and @datefin
	and FALQTE != 0
	and isnull(FALLETTRE,"") = ""
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by FALARTICLE

	
	create unique index seq on #Stock2 (seq)
	

	declare stock cursor 
	for select article,qte,fact,frais,seq
	from #Stock2
	where qte != 0
	order by seq
	for read only

	declare @article			char(15),
			@qte				int,
			@fact				tinyint,
			@seq				numeric(14,0),
			@PrixRevient		numeric(14,4),
			@PrixRevientLigne 	numeric(14,2),
			@frais				numeric(14,2)

	
	open stock
	
	fetch stock
	into @article,@qte,@fact,@frais,@seq
	
	while (@@sqlstatus = 0)
		begin
		
		select 	@PrixRevient = 0,
				@PrixRevientLigne = 0
		
		if @modevalo = 1								/*--------------------- PRM Annuel */
		begin
		  
		  select @PrixRevient=isnull(ARPRM,0)
		  from FAR
		  where ARCODE = @article
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais		
		end
		else if @modevalo = 2									/*--------------------- PUMP */
		begin
		  select @PrixRevient=isnull(PUMP,0)
		  from FPUM
		  where PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @datefin)
		  having PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @datefin)
		  and PUMDATE = max(PUMDATE)
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais
		end
		else if @modevalo = 3								/*--------------------- PRM Mensuel */
		begin
		  set rowcount 1
		  
		  select @PrixRevient=isnull(PRM,0)
		  from FPRM
		  where PRMAR = @article
		  and ((PRMAN = datepart(yy,@datefin) and PRMMOIS <= datepart(mm,@datefin)) or PRMAN < datepart(yy,@datefin))
		  having ((PRMAN = datepart(yy,@datefin) and PRMMOIS <= datepart(mm,@datefin)) or PRMAN < datepart(yy,@datefin))
		  and PRMAR = @article
		  order by PRMAN desc,PRMMOIS desc
		  
		  set rowcount 0
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais		
		end
		else  if @modevalo = 4								/*--------------------- DPA unitaire */
		begin
		  set rowcount 1			
		
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
		  from FBLL,FCV
		  where BLLAR=@article
		  and CVUNIF=BLLUA
		  having BLLAR=@article
		  and CVUNIF=BLLUA
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		
		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
			from FSIL,FAR,FCV
			where SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			having SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end
		  
		  set rowcount 0
		  
		  if @PrixRevient is null
			select @PrixRevient = 0
  
		  	select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais		  
		end

		if @fact=0
			update #Stock2 set valstock = @PrixRevientLigne where seq = @seq
		else if @fact=1			
			update #Stock2 set valstock = @PrixRevientLigne, valmarge = valventes + @PrixRevientLigne where seq = @seq /* PR negatif */
		
		fetch stock
		into @article,@qte,@fact,@frais,@seq
		
	end

	close stock
	deallocate cursor stock

  if @compare=1
  begin
  
  	select @datedeb = dateadd(yy,-1,@datedeb)
	select @datefin = dateadd(yy,-1,@datefin)
  	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select MOISARTICLE,sum(MOISQTE),0,0,0,0,0,0,0,0,-1,0,0
	from FMOIS,FAR
	where ARCODE=MOISARTICLE
	and MOISANNEE=@an-2
	and MOISMOIS=12
	and MOISQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by MOISARTICLE
	
	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select BLLAR,sum(BLLQTE),0,0,0,0,0,0,0,sum(isnull(round(BLLPRHT*BLLQTE/CVLOT,2),0)),-1,0,0
	from FBLL,FAR,FCV
	where ARCODE=BLLAR
	and CVUNIF=BLLUA
	and BLLDATE between @datedeb and @datefin
	and BLLQTE != 0
	and isnull(BLLLET,"") != ""
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by BLLAR
	
	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select RFLARTICLE,sum(RFLQTE),0,0,0,0,0,0,0,-sum(isnull(RFLTOTALHT,0)),-1,0,0
	from FRFL,FAR
	where ARCODE=RFLARTICLE
	and RFLDATE between @datedeb and @datefin
	and RFLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by RFLARTICLE
	

	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select DOLAR,sum(DOLQTE),0,0,0,0,0,0,0,sum(isnull(round(DOLPRHT*DOLQTE/CVLOT,2),0)),-1,0,0
	from FDOL,FAR,FCV
	where ARCODE=DOLAR
	and CVUNIF=DOLUA
	and DOLDATE between @datedeb and @datefin
	and DOLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by DOLAR


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select SILARTICLE,sum(SILQTE),0,0,0,0,0,0,0,0,-1,0,0
	from FSIL,FAR
	where ARCODE=SILARTICLE
	and SILDATE between @datedeb and @datefin
	and SILQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by SILARTICLE


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select RJLARTICLE,sum(RJLQTE),0,0,0,0,0,0,0,0,-1,0,0
	from FRJL,FAR
	where ARCODE=RJLARTICLE
	and RJLDATE between @datedeb and @datefin
	and RJLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by RJLARTICLE


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select ASLARTICLE,sum(ASLQTE),0,0,0,0,0,0,0,0,-1,0,0
	from FASL,FAR
	where ARCODE=ASLARTICLE
	and ASLDATE between @datedeb and @datefin
	and ASLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by ASLARTICLE


	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select LCLARTICLE,sum(LCLQTE),0,0,0,0,0,0,0,0,-1,0,0
	from FLCL,FAR
	where ARCODE=LCLARTICLE
	and LCLDATE between @datedeb and @datefin
	and LCLQTE != 0
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by LCLARTICLE
	

	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select FALARTICLE,-sum(FALQTE),0,0,0,0,0,sum(FALTOTALHT),0,0,-1,1,sum(isnull(FALFRAIS,0))
	from FFAL,FAR
	where ARCODE=FALARTICLE
	and FALDATE between @datedeb and @datefin
	and FALQTE != 0
	and isnull(FALLETTRE,"") != ""
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by FALARTICLE
	
	insert into #Stock2 (article,qte,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,annee,fact,frais)
	select FALARTICLE,0,0,0,0,0,0,sum(FALTOTALHT),0,0,-1,1,0
	from FFAL,FAR
	where ARCODE=FALARTICLE
	and FALDATE between @datedeb and @datefin
	and FALQTE != 0
	and isnull(FALLETTRE,"") = ""
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
	group by FALARTICLE
	

	declare stock cursor 
	for select article,qte,fact,frais,seq
	from #Stock2
	where annee = -1
	and qte != 0
	order by seq
	for read only
	
	open stock
	
	fetch stock
	into @article,@qte,@fact,@frais,@seq
	
	while (@@sqlstatus = 0)
		begin
		
		select 	@PrixRevient = 0,
				@PrixRevientLigne = 0
		
		if @modevalo = 1								/*--------------------- PRM Annuel */
		begin
		  
		  select @PrixRevient=isnull(ARPRM,0)
		  from FAR
		  where ARCODE = @article
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais			
		end
		else if @modevalo = 2									/*--------------------- PUMP */
		begin
		  select @PrixRevient=isnull(PUMP,0)
		  from FPUM
		  where PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @datefin)
		  having PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @datefin)
		  and PUMDATE = max(PUMDATE)
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais
		end
		else if @modevalo = 3								/*--------------------- PRM Mensuel */
		begin
		  set rowcount 1
		  
		  select @PrixRevient=isnull(PRM,0)
		  from FPRM
		  where PRMAR = @article
		  and ((PRMAN = datepart(yy,@datefin) and PRMMOIS <= datepart(mm,@datefin)) or PRMAN < datepart(yy,@datefin))
		  having ((PRMAN = datepart(yy,@datefin) and PRMMOIS <= datepart(mm,@datefin)) or PRMAN < datepart(yy,@datefin))
		  and PRMAR = @article
		  order by PRMAN desc,PRMMOIS desc
		  
		  set rowcount 0
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais			
		end
		else  if @modevalo = 4								/*--------------------- DPA unitaire */
		begin
		  set rowcount 1			
		
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
		  from FBLL,FCV
		  where BLLAR=@article
		  and CVUNIF=BLLUA
		  having BLLAR=@article
		  and CVUNIF=BLLUA
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		
		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
			from FSIL,FAR,FCV
			where SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			having SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end
		  
		  set rowcount 0
		  
		  if @PrixRevient is null
			select @PrixRevient = 0
  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @frais			
		end


		if @fact=0
			update #Stock2 set valstock_1 = @PrixRevientLigne where seq = @seq
		else if @fact=1
			update #Stock2 set valstock_1 = @PrixRevientLigne, valmarge_1 = valventes_1 + @PrixRevientLigne where seq = @seq /* PR negatif */
		
		fetch stock
		into @article,@qte,@fact,@frais,@seq
		
	end

	close stock
	deallocate cursor stock

  end
  
  insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1)
	select ARDEPART,ARFO,ARFAM,sum(valstock),sum(valventes),sum(valmarge),sum(valachat),
							   sum(valstock_1),sum(valventes_1),sum(valmarge_1),sum(valachat_1)
  from #Stock2,FAR
  where ARCODE=article
  group by ARDEPART,ARFO,ARFAM

  drop table #Stock2

end

if @sansval = 0
	begin
	  select depart,marque,famille,FPLIB,sum(valstock),sum(valventes),sum(valmarge),sum(valachat),
								   sum(valstock_1),sum(valventes_1),sum(valmarge_1),sum(valachat_1)
	  from #Stock,FFP
	  where FPCODE=famille
	  group by depart,marque,famille,FPLIB
	  order by depart,marque,famille,FPLIB
	end
else if @sansval = 1
	begin
	  select depart,marque,famille,FPLIB,sum(valstock),sum(valventes),sum(valmarge),sum(valachat),
								   sum(valstock_1),sum(valventes_1),sum(valmarge_1),sum(valachat_1)
	  from #Stock,FFP
	  where FPCODE=famille
	  group by depart,marque,famille,FPLIB
	  having sum(valstock) != 0
	  	or  sum(valventes) != 0
		or  sum(valachat) != 0
		or  sum(valstock_1) != 0
		or  sum(valventes_1) != 0
		or  sum(valachat_1) != 0
	  order by depart,marque,famille,FPLIB
	end


drop table #Stock


end
go

