/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.b_Affice_PC
grant execute on b_Affice_PC to public
*/


CREATE PROCEDURE dbo.b_Affice_PC (@code_PC char(10),@param int)


AS
begin
			declare @xArcode char(15)
			
			create table #stock_rupture(
                ARTICLE char(15),
                RUPTURE int null
        	)
        	
        	create table #xFare(
                xARTICLE char(15),
                xAREEMP char(8),
                xSE char(4)
        	)
        	
        	declare liste cursor for select distinct xBPRLAR from xFBPRL where xBPRLCODE=@code_PC and isnull(xBPRL_PR,'')=''						
			open liste
			fetch liste into @xArcode
        	
        	while(@@sqlstatus=0)
			begin
				
				insert into #stock_rupture (ARTICLE) values (@xArcode)
				update #stock_rupture set RUPTURE=(select isnull(count(*),0) from DBSUIVI..STOCK_MOYENNE_VTE_3DM where ARTICLE=@xArcode and TOTAL<=MOYENNE_HEBDO) where ARTICLE=@xArcode
				--select ARTICLE,(case when TOTAL<=MOYENNE_HEBDO then 1 else 0 end) from VIEW_STOCK_MOYENNE_VTE_3DM where ARTICLE=@xArcode
				insert into #xFare select AREAR,AREEMP, (case when  AREEMP in (select  rtrim(xEmplSTEMP) from xEMPL where xDepotl='GROS' and xTypel=2) then '*SE*' else '' end) 
				from FARE where AREAR=@xArcode and ARERECEP=1 and AREVALID=1 and AREDEPOT='GROS'
				
				fetch liste into @xArcode
				 
			end
			close liste
			deallocate cursor liste
			if @param=0
				begin
			 		 select distinct xBPRLSEQ,xBPRLAR,ARLIB,
					 xBPRLQTE,xBPRLPAFO,xBPRLRFO,xBPRLPADEV,
					 xBPRLPRHT,xBPRLUA,xBPRLNCAR,xBPRLACCORD,xBPRLNUM,
					 xBPRLLIENCODE,xBPRLLIENNUM,xBPRLNARM1,xBPRLNARM2,
					 xBPRLDEP,xBPRLPCTR,xBPRLPCDN,xBPRLEPR,xBPRLLIBRE,xBPRLTYPEVE,xBPRLLET,xBPRLTOTDEV,xBPRLTOTHT,xBPRLCDEV,xBPRLPAHT,xBPRLORDRE,xBPRLFACT,CVLOT,xBPRLFOREIGN1,xBPRLFOREIGN2,0,xBPRLBLCODE,xBPRLLOT,xBPRLEMP,ARLOT,xBPRLCLIENT,isnull(xBPRLSOLDER,0),xBPRLREFFO,xBPRLFRAIS,isnull(ARQTECOLIS,1),
					 xBPRLCCLCODE,xBPRLCCLNUM,xBPRLREFCOMCL,xBPRLREFCL,0,xBPRLQTE,0,1,NLOTDATEPER,xBPRLETAT,xBPRLCODE,isnull(xBPRL_INTERDIT,0),isnull(xBPRLUG,0),(case when isnull(xBPRLUG,0)=0 then ' ' else 'UG' end) as p_UG,
					 xSE,xAREEMP,RUPTURE					 
					 from xFBPRL,FCV,VIEW_FAR,FNLOT,#stock_rupture,#xFare
					 where xBPRLCODE=@code_PC
					 and NLOTAR=*xBPRLAR
					 and ARTICLE=xBPRLAR
					 and xARTICLE=xBPRLAR
					 and xBPRLLOT*=NLOTCODE
					 and CVUNIF=xBPRLUA
					 and ARCODE=xBPRLAR
					 and isnull(xBPRL_PR,'')=''
					 order by xBPRLORDRE
			    end
			 if @param=1
				begin
			 		 select distinct xBPRLSEQ,xBPRLAR,ARLIB,
					 xBPRLQTE,xBPRLPAFO,xBPRLRFO,xBPRLPADEV,
					 xBPRLPRHT,xBPRLUA,xBPRLNCAR,xBPRLACCORD,xBPRLNUM,
					 xBPRLLIENCODE,xBPRLLIENNUM,xBPRLNARM1,xBPRLNARM2,
					 xBPRLDEP,xBPRLPCTR,xBPRLPCDN,xBPRLEPR,xBPRLLIBRE,xBPRLTYPEVE,xBPRLLET,xBPRLTOTDEV,xBPRLTOTHT,xBPRLCDEV,xBPRLPAHT,xBPRLORDRE,xBPRLFACT,CVLOT,xBPRLFOREIGN1,xBPRLFOREIGN2,0,xBPRLBLCODE,xBPRLLOT,xBPRLEMP,ARLOT,xBPRLCLIENT,isnull(xBPRLSOLDER,0),xBPRLREFFO,xBPRLFRAIS,isnull(ARQTECOLIS,1),
					 xBPRLCCLCODE,xBPRLCCLNUM,xBPRLREFCOMCL,xBPRLREFCL,0,xBPRLQTE,0,1,NLOTDATEPER,xBPRLETAT,xBPRLCODE,isnull(xBPRL_INTERDIT,0),isnull(xBPRLUG,0),(case when isnull(xBPRLUG,0)=0 then ' ' else 'UG' end) as p_UG,
					 xSE,xAREEMP,RUPTURE					 
					 from xFBPRL,FCV,VIEW_FAR,FNLOT,#stock_rupture,#xFare
					 where xBPRLCODE=@code_PC
					 and NLOTAR=*xBPRLAR
					 and ARTICLE=xBPRLAR
					 and xARTICLE=xBPRLAR
					 and xBPRLLOT*=NLOTCODE
					 and CVUNIF=xBPRLUA
					 and ARCODE=xBPRLAR
					 and isnull(xBPRL_INTERDIT,0)=0
					 and isnull(xBPRL_PR,'')=''
					 order by xBPRLORDRE
			    end
			   if @param=2
				begin
			 		 select distinct xBPRLSEQ,xBPRLAR,ARLIB,
					 xBPRLQTE,xBPRLPAFO,xBPRLRFO,xBPRLPADEV,
					 xBPRLPRHT,xBPRLUA,xBPRLNCAR,xBPRLACCORD,xBPRLNUM,
					 xBPRLLIENCODE,xBPRLLIENNUM,xBPRLNARM1,xBPRLNARM2,
					 xBPRLDEP,xBPRLPCTR,xBPRLPCDN,xBPRLEPR,xBPRLLIBRE,xBPRLTYPEVE,xBPRLLET,xBPRLTOTDEV,xBPRLTOTHT,xBPRLCDEV,xBPRLPAHT,xBPRLORDRE,xBPRLFACT,CVLOT,xBPRLFOREIGN1,xBPRLFOREIGN2,0,xBPRLBLCODE,xBPRLLOT,xBPRLEMP,ARLOT,xBPRLCLIENT,isnull(xBPRLSOLDER,0),xBPRLREFFO,xBPRLFRAIS,isnull(ARQTECOLIS,1),
					 xBPRLCCLCODE,xBPRLCCLNUM,xBPRLREFCOMCL,xBPRLREFCL,0,xBPRLQTE,0,1,NLOTDATEPER,xBPRLETAT,xBPRLCODE,isnull(xBPRL_INTERDIT,0),isnull(xBPRLUG,0),(case when isnull(xBPRLUG,0)=0 then ' ' else 'UG' end) as p_UG,
					 xSE,xAREEMP,RUPTURE					 
					 from xFBPRL,FCV,VIEW_FAR,FNLOT,#stock_rupture,#xFare
					 where xBPRLCODE=@code_PC
					 and NLOTAR=*xBPRLAR
					 and ARTICLE=xBPRLAR
					 and xARTICLE=xBPRLAR
					 and xBPRLLOT*=NLOTCODE
					 and CVUNIF=xBPRLUA
					 and ARCODE=xBPRLAR
					 and isnull(xBPRL_INTERDIT,0)=1
					 and isnull(xBPRL_PR,'')=''
					 order by xBPRLORDRE
			    end
	    drop table #stock_rupture,#xFare
end
go

