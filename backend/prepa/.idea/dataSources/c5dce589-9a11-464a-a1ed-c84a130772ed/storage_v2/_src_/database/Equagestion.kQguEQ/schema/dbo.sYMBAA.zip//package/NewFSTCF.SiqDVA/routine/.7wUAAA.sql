




create procedure NewFSTCF	(	@an_in		int,
								@mois_in	int,
								@frs_in		char(12) = null	
							)
as
begin

  	declare	@fournis	char(12),
	  		@article	char(15),
			@an			int,
	  		@mois		int,
	  		@qte		int,
	  		@total		numeric(14,2),
	  		@cfcode		char(10),
	  		@ent		char(5)
	
	delete from FSTCF
	  where STCFAN=@an_in and STCFMOIS=@mois_in
	  and (@frs_in is null or STCFFO=@frs_in) 
	
	declare pointeur cursor
	  for select CFLFO, CFLARTICLE,
	  			 AN=datepart(yy,CFLDATE),MOIS=datepart(mm,CFLDATE),
				 QTE=sum(CFLQTE),TOTAL=sum(CFLTOTALHT),CFLCODE,isnull(CFLENT,'')
	  from FCFL,FAR
	  where ARCODE=CFLARTICLE
	  and datepart(yy,CFLDATE)=@an_in and datepart(mm,CFLDATE)=@mois_in
	  and (@frs_in is null or CFLFO=@frs_in) 
	  and CFLQTE > 0
	  group by CFLFO,CFLARTICLE,datepart(yy,CFLDATE),datepart(mm,CFLDATE),isnull(CFLENT,''),CFLCODE
	  for read only
  
	open pointeur

	  fetch pointeur
	  into @fournis,@article,@an,@mois,@qte,@total,@cfcode,@ent
	  
	  while (@@sqlstatus = 0)
		begin
		
			if exists (select * from FSTCF where STCFFO=@fournis and STCFART=@article and STCFAN=@an and STCFMOIS=@mois)
		 		update FSTCF
				set STCFQTE=STCFQTE+@qte,
			 		STCFCA=STCFCA+@total
		 		where STCFFO=@fournis
		  		and STCFART=@article
				and STCFAN=@an
		   		and STCFMOIS=@mois
		   	else
				insert into FSTCF(STCFFO,STCFART,STCFAN,STCFMOIS,STCFQTE,STCFCA)
		 		values (@fournis,@article,@an,@mois,@qte,@total)
		
				
			fetch pointeur
	    		into @fournis,@article,@an,@mois,@qte,@total,@cfcode,@ent
	  
	  	end
	
	  close pointeur
	  deallocate cursor pointeur
end



go

