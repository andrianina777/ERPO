/*
DROP PROCEDURE dbo.bp_PerformanceAgentPrep2
grant execute on bp_PerformanceAgentPrep2 to public
*/


CREATE PROCEDURE dbo.bp_PerformanceAgentPrep2 (@datedeb smalldatetime,@datefin smalldatetime)


AS
begin
			
			declare @x_code char(10),
					@x_emp   char(10),
					@x_nbLigne int,
					@x_nbAr int
					
			create table #prep(
                agent char(10),
                rayon char(10) null,
                codeBP char(10),
                date  char(15),
                nbCC	int,
                moyen int,
        	)
        	
        	create table #xFBPL(
                code char(10),
                dateBP char(15),
                emp char(10) null,
                nbLig int,
                nbAr int

        	)
        	
        insert into #prep select  CEPUSER,CEPRAYON,CEPBPCODE,convert(date,CEPDATEDEBSIMPLE),count(CEPBPCODE),AVG(DATEDIFF(mi,CEPDATEDEB,CEPDATEFIN)) from h_CCEnPrep where (CEPDATEDEBSIMPLE between @datedeb and @datefin)  and CEPETAT=2 AND ISNULL(CEPUSER,'')<>''
		--and CEPRAYON in (SELECT DISTINCT rtrim(upper(xEmp)) FROM xEMP WHERE xDepot='DET')	
		group by CEPUSER,CEPRAYON,convert(date,CEPDATEDEBSIMPLE)
		
		insert into #xFBPL select  BPLCODE,CONVERT(date,BPLDATE),RAYON,count(*) as nbLigne,sum(BPLQTE) as nbArticle from FBPL left join xEMP_DIGUEL on (xEMPL=BPLEMP and xDEPOTL=BPLDEPOT) 
		left join xCorrespRAYON_DIGUE on (ALLEE= xALLEL and DEPOT=xDEPOTL)
        where (BPLDATE between @datedeb  and  @datefin) 
       -- and BPLEMP in (SELECT DISTINCT rtrim(upper(xEmp)) FROM xEMP WHERE xDepot='DET') and BPLDEPOT='DET'
	    group by BPLCODE,RAYON,CONVERT(date,BPLDATE)
	    
	    select  distinct agent,rayon,convert(date,date) as date,nbCC as nbBP,sum(nbLig) as nbLigne,sum(nbAr) as nbArticle,moyen as delai_Moy_Prep from #prep inner join #xFBPL on (codeBP=code and rayon=emp) group by agent,rayon,date
	    order by agent,rayon,date
		
		
	    
	    drop table #prep,#xFBPL
end
go

