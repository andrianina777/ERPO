


/* Cette procedure verifie les marges anormales en plus ou en moins
		sur les lignes de factures  (par rapport au tarif article) */


create procedure VerifMargesFA (@ent			char(5)	= null,
								@fournisseur	char(12),
								@date1	smalldatetime,
								@date2	smalldatetime)
with recompile
as
begin

select ARCODE,ARPVHT
into #Far
from FAR
where ARFO=@fournisseur
and ARLIB!=''

create unique clustered index article on #Far(ARCODE)

select Code_FA=FALCODE,Ligne_FA=FALNUM,Article=FALARTICLE,
PrixHT_facture=FALPRIXHT,PVHT_article=ARPVHT,
Pourcentage=isnull(round(FALPRIXHT/ARPVHT,2),0),
Code_BE=FALLIENCODE,Ligne_BE=FALLIENNUM
from FFAL (index article),#Far
where ARCODE=FALARTICLE
and ARPVHT!=0
and ((FALPRIXHT>(ARPVHT*1.08)) or (FALPRIXHT<(ARPVHT*0.75)))
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
order by FALARTICLE

drop table #Far

end



go

