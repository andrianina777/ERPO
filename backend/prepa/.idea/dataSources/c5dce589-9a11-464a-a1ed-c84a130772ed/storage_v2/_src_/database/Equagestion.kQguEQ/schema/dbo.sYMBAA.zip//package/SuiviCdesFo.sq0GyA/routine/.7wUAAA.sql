

create procedure SuiviCdesFo (
						 @ent			char(5)		= null,   
						 @an			smallint,   
						 @moisdeb		tinyint,   
						 @moisfin		tinyint,   
						 @chefprod		char(8) 	= null,   
						 @depart		char(8) 	= null,   
						 @marque		char(12) 	= null,   
						 @famille		char(8) 	= null,   
						 @categorie		char(8) 	= null,   
						 @article		char(15) 	= null,   
						 @frs			char(12) 	= null,   
						 @produits		tinyint 	= 0,   
						 @prodnsto		tinyint 	= 1,   
						 @services		tinyint 	= 2,   
						 @ports			tinyint 	= 3,   
						 @comments		tinyint 	= 4,   
						 @remises		tinyint 	= 5,   
						 @rfa			tinyint 	= 6,   
						 @assur			tinyint 	= 7,   
						 @livraison		char(10) 	= null,   
						 @article_groupe	char(16) = null,  
						 @datedeb		smalldatetime = null,  
						 @datefin		smalldatetime = null,  
						 @fosa			char(6)	 	= null,  
						 @matiere		char(14)	= null,  
						 @couleur		char(8)		= null,  
						 @grille		char(10)	= null,  
						 @calibre		char(14)	= null,  
						 @foreign1		char(12)	= null,  
						 @foreign2		char(12)	= null, 
						 @offert		tinyint		= null, 
						 @foclasse		char(10) 	= null, 
						 @axe			char(12)	= null, 
						 @section		char(12)	= null,
						 @devise		char(3)		= null,
						 @choixcdes	int	= 0
						 )   
with recompile   
as   
begin   
  
set arithabort numeric_truncation off   
   
   
declare	@date1			smalldatetime,   
				@date2			smalldatetime   
  
  
if (@datedeb is null)  
begin  
	select @date1=convert(datetime,convert(char(2),@moisdeb)+"/01/"+convert(char(4),@an))   
	select @date2=convert(datetime,convert(char(2),@moisfin)+"/01/"+convert(char(4),@an))   
	select @date2=dateadd(mm,1,@date2)   
	select @date2=dateadd(dd,-1,@date2)  
end  
else  
begin  
	select @date1=@datedeb  
	select @date2=@datefin		  
end  
   

delete from FTCF where TCFSPID=@@spid   
   
if @choixcdes=0 /* toutes les cdes */
begin
   
insert into FTCF (TCFCHEFP,TCFDEPART,TCFMARQUE,TCFFAM,TCFARTICLE,TCFLIB,
				TCFFO,TCFQTE,TCFTOTHT,TCFTOTDEV,TCFDEV,
				TCFSPID,TCFCODE, 
				TCFGRFAM,TCFSA,TCFPAYS,TCFCLASSE,TCFCOMPTE)   
select 	isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(CFLARTICLE,""),isnull(ARLIB,""),
		isnull(CFLFO,""),CFLQTE,isnull(CFLTOTALHT,0),isnull(CFLTOTALDEV,0),CFLDEVISE,
		@@spid,CFLCODE, 
		isnull(ARGRFAM,''),isnull(FOSA,''),isnull(FOPAYS,''),isnull(FOCLASSE,''),
		isnull((case when FOSANSTVA=0 then TVLCPT else TVLCPTSANSTVA end),'')  	
  from FCFL,FAR,FCF,FFO,FTVL   
  where ARCODE=CFLARTICLE 
  and CFCODE=CFLCODE 
  and FOCODE=CFFO 
  and ARTYPEVE=TVLCODE and FOCLASSE=TVLCLASSE 
  and CFLDATE between @date1 and @date2    
  and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)   
  and (@chefprod is null or ARCHEFP = @chefprod)   
  and (@depart is null or ARDEPART = @depart)   
  and (@marque is null or ARFO = @marque)   
  and (@famille is null or ARFAM = @famille)   
  and (@categorie is null or ARGRFAM = @categorie)   
  and (@article is null or ARCODE = @article)   
  and (@frs is null or CFLFO = @frs)   
  and (@livraison is null or CFLCODE = @livraison)   
  and (@article_groupe is null or ARREGROUPE = @article_groupe) 
  and (@fosa is null or FOSA = @fosa) 
  and (@foclasse is null or FOCLASSE = @foclasse)      
  and (@matiere is null or ARMATIERE = @matiere)  
  and (@couleur is null or ARCOULEUR = @couleur)  
  and (@grille is null or ARGRILLE = @grille)  
  and (@calibre is null or ARCALIBRE = @calibre)  
  and (@foreign1 is null or ARFOREIGN1 = @foreign1)  
  and (@foreign2 is null or ARFOREIGN2 = @foreign2)  
  and (@offert is null or isnull(CFLTOTALHT,0)!=0) 
  and (@section is null or exists (select * from FCLAX where FFO.FOCODE=CLAXCLE and (@ent is null or CLAXENT=@ent) and CLAXAX=@axe and CLAXSECTION=@section)) 
  and (@devise is null or CFLDEVISE=@devise)    

end
 
if @choixcdes=1 /* Les reste a livrer seulement */
begin

insert into FTCF (TCFCHEFP,TCFDEPART,TCFMARQUE,TCFFAM,TCFARTICLE,TCFLIB,
				TCFFO,TCFQTE,TCFTOTHT,TCFTOTDEV,TCFDEV,
				TCFSPID,TCFCODE, 
				TCFGRFAM,TCFSA,TCFPAYS,TCFCLASSE,TCFCOMPTE)   
select 	isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),isnull(CFLARTICLE,""),isnull(ARLIB,""),
		isnull(CFLFO,""),RCFQTE,isnull(CFLTOTALHT,0)/CFLQTE*RCFQTE,isnull(CFLTOTALDEV,0)/CFLQTE*RCFQTE,CFLDEVISE,
		@@spid,CFLCODE, 
		isnull(ARGRFAM,''),isnull(FOSA,''),isnull(FOPAYS,''),isnull(FOCLASSE,''),
		isnull((case when FOSANSTVA=0 then TVLCPT else TVLCPTSANSTVA end),'') 
  from FCFL,FAR,FCF,FFO,FTVL,FRCF   
  where ARCODE=CFLARTICLE 
  and RCFSEQ=CFLSEQ
  and CFCODE=CFLCODE 
  and FOCODE=CFFO
  and ARTYPEVE=TVLCODE and FOCLASSE=TVLCLASSE 
  and CFLDATE between @date1 and @date2    
  and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)   
  and (@chefprod is null or ARCHEFP = @chefprod)   
  and (@depart is null or ARDEPART = @depart)   
  and (@marque is null or ARFO = @marque)   
  and (@famille is null or ARFAM = @famille)   
  and (@categorie is null or ARGRFAM = @categorie)   
  and (@article is null or ARCODE = @article)   
  and (@frs is null or CFLFO = @frs)   
  and (@livraison is null or CFLCODE = @livraison)   
  and (@article_groupe is null or ARREGROUPE = @article_groupe) 
  and (@fosa is null or FOSA = @fosa) 
  and (@foclasse is null or FOCLASSE = @foclasse)      
  and (@matiere is null or ARMATIERE = @matiere)  
  and (@couleur is null or ARCOULEUR = @couleur)  
  and (@grille is null or ARGRILLE = @grille)  
  and (@calibre is null or ARCALIBRE = @calibre)  
  and (@foreign1 is null or ARFOREIGN1 = @foreign1)  
  and (@foreign2 is null or ARFOREIGN2 = @foreign2)  
  and (@offert is null or isnull(CFLTOTALHT,0)!=0) 
  and (@section is null or exists (select * from FCLAX where FFO.FOCODE=CLAXCLE and (@ent is null or CLAXENT=@ent) and CLAXAX=@axe and CLAXSECTION=@section)) 
  and (@devise is null or CFLDEVISE=@devise)    

end  
  
  
end
go

