/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.b_Corresp_AO

*/


CREATE PROCEDURE dbo.b_Corresp_AO (@client char(10),@item varchar(25),@libelle_client varchar(162),@cdt varchar(25),@qte int)


AS
begin

			create table #view(
				ITEM varchar(25),
                ARTICLE varchar(162) null,
                CDT varchar(80),
                QTE int null,
                CLIENT char(10)
        
        	)
        	
        	declare @xCount int
        	
        	if(@libelle_client is not null)
        		begin
        			insert into #view(ITEM,ARTICLE,CDT,QTE,CLIENT) values(@item,@libelle_client,@cdt,@qte,@client)
        		end
        		
			select @xCount=count(*) from xAOL where xAOLARTICLE=@libelle_client
			
			if @xCount > 0
				begin
					select distinct ITEM,ARTICLE,CDT,QTE,bAOLARCODE,ARLIB,bAOLPRIXUNIT,xAODATE,case when isnull(bAOLDECISION,0)=0 
					then 'NON' else 'OUI' end,QTE_DISPO,ARFO,bAOLDATEPER from #view inner join xAO on xAOCLIENT=CLIENT
					left join xAOL on xAOLCODE=xAOCODE and xAOLARTICLE=ARTICLE
					inner join bAOL on bAOL_xAOLSEQ=xAOLSEQ and bAOL_xAOLCODE=xAOLCODE
					inner join VIEW_FAR_TOUS on ARCODE=bAOLARCODE
					inner join VIEW_STOCK_DISPO on CODE=bAOLARCODE
					where CLIENT=@client
					and ARTICLE=@libelle_client
				end
			else
				begin
					select ITEM,ARTICLE,CDT,QTE from #view
				end
			
			
		
end

go

