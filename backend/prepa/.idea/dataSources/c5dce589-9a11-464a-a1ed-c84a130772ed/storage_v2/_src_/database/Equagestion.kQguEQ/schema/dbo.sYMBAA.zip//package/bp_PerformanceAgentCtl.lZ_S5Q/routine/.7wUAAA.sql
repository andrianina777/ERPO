/*
DROP PROCEDURE dbo.bp_PerformanceAgentCtl
grant execute on bp_PerformanceAgentCtl to public
*/


CREATE PROCEDURE dbo.bp_PerformanceAgentCtl (@datedeb smalldatetime,@datefin smalldatetime)


AS
begin
			
			declare @x_code char(10),
					@x_emp   char(10),
					@x_nbLigne int,
					@x_nbAr int
					
			create table #prep(
                agent char(10) null,
                date  char(15) null,
                codeBP	char(10) null,
                nbBP	int
        	)
        	
        	create table #xFBPL(
                code char(10),
                dateBP char(15),
                nbLig int,
                nbAr int

        	)
       insert into #prep select xControleur,CONVERT(CHAR,xDateSimpleFinCtrl,101),xCode,count(xCode) from xpCTRL_PLUS where (xDateSimpleFinCtrl between @datedeb and @datefin) and isnull(xPrepSpecif,0)>2  and isnull(xControleur,'')<>''
       group by xControleur,CONVERT(CHAR,xDateSimpleFinCtrl,101),xCode
        	
		
		insert into #xFBPL select  BPLCODE,CONVERT(CHAR,BPLDATE,101),count(*) as nbLigne,sum(BPLQTE) as nbArticle from FBPL 
        where (BPLDATE between @datedeb  and  @datefin) 
       -- and BPLEMP in (SELECT DISTINCT rtrim(upper(xEmp)) FROM xEMP WHERE xDepot='DET') and BPLDEPOT='DET'
	    group by BPLCODE,CONVERT(CHAR,BPLDATE,101)
	    
	    select  distinct agent,date,count(nbBP) as nbBP,sum(nbLig) as nbLigne,sum(nbAr) as nbArticle from #prep inner join #xFBPL on codeBP=code group by agent,date
	    order by agent,date
		
		
	    
	    drop table #prep,#xFBPL
end
go

