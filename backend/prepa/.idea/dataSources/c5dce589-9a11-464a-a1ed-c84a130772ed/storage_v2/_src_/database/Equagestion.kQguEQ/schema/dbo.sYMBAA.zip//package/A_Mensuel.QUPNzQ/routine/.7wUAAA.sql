


/* Procedure permettant de faire la mise a jour mensuelle des informations
	necessaires aux statistiques achats */

create procedure A_Mensuel (@An			smallint,
							@Mois		tinyint,
							@datephoto	datetime = null,
							@codephoto	char(16) = null
						   )
with recompile
as
begin


/* mise a jour des quantites reelles en stock au 1er du mois indique */

if @codephoto is null
begin
	execute A_SKConst @An,@Mois,null,null
end
else
begin
	execute A_SKConst @An,@Mois,@datephoto,@codephoto
end

	
	
end



go

