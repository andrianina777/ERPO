/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheRotation2
grant execute on bp_afficheRotation2 to public
*/

CREATE PROCEDURE dbo.bp_afficheRotation2(@depot char(4),@alle varchar(15))

AS
begin

		
		
 		declare  @STEMPID numeric(18,0),@STEMPQTE int ,@STEMPEMP varchar(15),@xSTLETTRE char(4),@STLOT varchar(25),@qteNonEt int ,@qteEncoursEt int,@qteEt  int,@ARCODE char(15)
 		
 		
 		declare @xMEUBLEL varchar(10), 
                @xNIVEAUL varchar(10), 
                @xRANGL varchar(10), 
                @xARTICLE varchar(50) ,
                @xEMPL varchar(20),
                @NIVEAU_SUP int,
                @nb int,
                @xEMPL_DEST varchar(50),
                @xALLEL varchar(10),
                @xSTOCK int,
                @xLOT varchar(50),
                @NB int,
                @STAR varchar(50),
                @STQTE int,
                @STLETTRE varchar(4),
                @STDEPOT varchar(50),
                @ST_QTE_RSRV int,
                @qte int,@id numeric(18,0),
                @lettre varchar(4),@dispo int

        create table #resultTmp (
                STEMPID numeric(18,0) null,
                STEMPAR char(50) null,
                STEMPLETTRE char(4) null,
                STEMPDEPOT char(10) null,
                STEMPQTE int null,
        )
            
        create table #appro(
            xSTID numeric (18,0) null,
            xQTE_NONETIQ int,
            xQTE_ENCOURSETIQ int,
            xQTE_ETIQ	int,
    	)       
        
        select STEMPID, STEMPAR, STEMPDEPOT, STEMPEMP, STLOT, NLOTDATEPER, xDPVTE, xDPCENTRAL, STFO, STDATEENTR, STLETTRE, STNUMARM1, STNUMARM2, STDEVISE, STPADEV, STPAHT, STFRAIS, ARLIB, ARQTEPALETTE, ARFO, ARREFFOUR, ARPRM, ARUNITACHAT, ARNUMEROTE, ARFRANCOFO, STEMPQTE, VALEUR, ARESSEMP, ST_UG, 
                ARPVHT, xARTP_STATSPEC, xARTP_FROID, RBPARTICLE, RBPDEPOT, RBPLETTRE, RBPEMP, RBPQTE, QTE_DISPO 
        into #view_Stock_Lot_Emplacement
        from VIEW_STOCK_LOT_EMPL_FRBP
        where STEMPDEPOT=@depot
       -- and QTE_DISPO>0

        create index article_idx0001 on #view_Stock_Lot_Emplacement(STEMPDEPOT)
        create index article_idx0002 on #view_Stock_Lot_Emplacement(STEMPEMP)
        
        
        /*RESERVATOIN STOCK GILES*/
        declare reservation cursor for select STAR,STQTE,STLETTRE,STDEPOT,ST_QTE_RSRV from VIEW_FSTOCK  where isnull(ST_QTE_RSRV,0)>0 and STDEPOT=@depot
        open reservation
        fetch reservation into @STAR,@STQTE,@STLETTRE,@STDEPOT,@ST_QTE_RSRV
        while (@@sqlstatus=0)
        begin
                
                declare ligneStock cursor  for select STEMPID,STLETTRE,STEMPDEPOT,QTE_DISPO from #view_Stock_Lot_Emplacement where STEMPAR=@STAR and STEMPDEPOT=@STDEPOT and STLETTRE=@STLETTRE
                open ligneStock
                fetch ligneStock into @id,@lettre,@depot,@qte
                while (@@sqlstatus=0)
                begin
                        select @dispo=0
                        select @dispo=@qte-@ST_QTE_RSRV
                        
                        if @dispo<=0
                        begin
                                insert into #resultTmp values (@id,@STAR,@lettre,@depot,0)
                        end
                        else
                        begin
                                insert into #resultTmp values (@id,@STAR,@lettre,@depot,@dispo)
                        end
                        select @ST_QTE_RSRV=@ST_QTE_RSRV-@qte
                        
                        fetch ligneStock into @id,@lettre,@depot,@qte
                end
                close ligneStock
                deallocate cursor ligneStock

                fetch reservation into @STAR,@STQTE,@STLETTRE,@STDEPOT,@ST_QTE_RSRV
        end
        close reservation
        deallocate cursor reservation
        
       update #view_Stock_Lot_Emplacement set QTE_DISPO=#resultTmp.STEMPQTE
       from #view_Stock_Lot_Emplacement,#resultTmp
       where #resultTmp.STEMPID=#view_Stock_Lot_Emplacement.STEMPID

       /*supprimer les stock 0*/
       --delete from #view_Stock_Lot_Emplacement where QTE_DISPO=0 

        /*LES EMPLAEMENT MAPPE DE CET ARTICLE*/
        select xDEPOTL, xALLEL, xMEUBLEL, xNIVEAUL, xRANGL, xEMPL, xACTIF, xARTICLE, xLONG, xLARGE, xHAUT, xCOL, xSENS, xCOMMENTAIRE, xDATE_DESACTIV, xUSER_DESACTIV, xDEPOT, xALLE, xNBCOL, xNIVEAUG, xNIVEAUD, xRANG, xMEUBLEG, xMEUBLED, xFICTIF 
        into #xEmp_Diguel
        from VIEW_EMPL_DIGUE_ACTIF
        where 
        (@alle=null or @alle='' or xALLEL=@alle)
        and xDEPOTL=@depot
        --and isnull(xFICTIF,0)=0
        and xSTATUTL=0       

        create index idx0001 on #xEmp_Diguel(xDEPOTL)
        create index idx0002 on #xEmp_Diguel(xEMPL)
        

        /*EMPLACEMENT TOTAL AVEC STOCK*/
        select  xDEPOTL, xALLEL, xMEUBLEL, xNIVEAUL, xRANGL, xEMPL, xACTIF, rtrim(xARTICLE) as xARTICLE,STLOT,convert(date,NLOTDATEPER) as NLOTDATEPER,sum(STEMPQTE)as STEMPQTE,sum(QTE_DISPO) as QTE_DISPO 
        into #Emplacement
        from #xEmp_Diguel,#view_Stock_Lot_Emplacement
        where xDEPOTL*=STEMPDEPOT
        and xEMPL*=STEMPEMP
        group by xDEPOTL, xALLEL, xMEUBLEL, xNIVEAUL, xRANGL, xEMPL, xACTIF, xARTICLE,STLOT,NLOTDATEPER
        order by xALLEL,convert(int,xMEUBLEL),xRANGL,convert(int,xNIVEAUL) desc 

        /*supprimer les emplacement avec qte<>qtedispo*/
        delete from #Emplacement where isnull(STEMPQTE,0)>0 and isnull(QTE_DISPO ,0)<=0
        
        /*STOCK LOT VENTE*/
        select xDEPOTL, xALLEL, xMEUBLEL, xNIVEAUL, xRANGL, xEMPL, xACTIF, xARTICLE, STLOT, convert(date,NLOTDATEPER) as NLOTDATEPER, STEMPQTE, QTE_DISPO 
        into #VIEW_LOT_VENTE_DEPOT
        from #Emplacement  
        where STEMPQTE>0
        GROUP BY xARTICLE,xDEPOTL
        HAVING MIN (NLOTDATEPER)=NLOTDATEPER
        
        /*EMPLACEMENT DEST DISPO*/
         select xDEPOTL, xALLEL, xMEUBLEL, xNIVEAUL, xRANGL, xEMPL, xACTIF, xARTICLE,  convert(varchar(50),'') as EMP_DEPART,convert(varchar(50),'') as LOT,convert(int,0) as STOCK
         into #EmplDest  
         from #Emplacement
         where isnull(STEMPQTE,0)=0
         and convert(int,xNIVEAUL)<=2
         and isnull(xARTICLE,'')<>''
         order by convert(int,xNIVEAUL),convert(int,xMEUBLEL)
         
         /*STOCK A DEPLACER*/
        select #Emplacement.xDEPOTL, #Emplacement.xALLEL, #Emplacement.xMEUBLEL, #Emplacement.xNIVEAUL, #Emplacement.xRANGL, #Emplacement.xEMPL, #Emplacement.xACTIF, #Emplacement.xARTICLE, #Emplacement.STLOT, #Emplacement.NLOTDATEPER, #Emplacement.STEMPQTE, #Emplacement.QTE_DISPO         
        into #A_deplacer 
        from #Emplacement,#VIEW_LOT_VENTE_DEPOT
        where #Emplacement.xDEPOTL=#VIEW_LOT_VENTE_DEPOT.xDEPOTL
        and #Emplacement.xARTICLE=#VIEW_LOT_VENTE_DEPOT.xARTICLE
        and #Emplacement.xEMPL=#VIEW_LOT_VENTE_DEPOT.xEMPL 
        and convert(int,#Emplacement.xNIVEAUL)>=2
        and #Emplacement.xARTICLE in (select xARTICLE from #EmplDest)
        order by convert(int,#Emplacement.xNIVEAUL) desc ,convert(int,#Emplacement.xMEUBLEL) desc ,#Emplacement.xRANGL
       
       declare liste cursor for select xARTICLE,xEMPL,xNIVEAUL,STEMPQTE,STLOT from #A_deplacer
        open liste
        fetch liste into @xARTICLE,@xEMPL,@xNIVEAUL,@xSTOCK,@xLOT
        while (@@sqlstatus=0)
        begin
                select @xEMPL_DEST=''
                select top 1 @xEMPL_DEST=xEMPL from #EmplDest where xARTICLE=@xARTICLE and EMP_DEPART='' and xNIVEAUL<@xNIVEAUL
                
                if (@xEMPL_DEST<>'')
                begin
                        update #EmplDest set EMP_DEPART=@xEMPL, LOT=@xLOT ,STOCK=@xSTOCK where xARTICLE=@xARTICLE and xEMPL=@xEMPL_DEST
                end
                
                fetch liste into @xARTICLE,@xEMPL,@xNIVEAUL,@xSTOCK,@xLOT
        end
        close liste
        deallocate cursor liste
        
        delete from #EmplDest where isnull(EMP_DEPART,'')='' 
 
   

        
        select xDEPOTL as xDEPOT,rtrim(xARTICLE) as xArticle, EMP_DEPART as xEMP_ORG,LOT as xLOT,STOCK as xSTOCK,xEMPL as xEMP_DEST 
        into #resultats
        from #EmplDest
        order by xARTICLE,convert(int,xNIVEAUL),convert(int,xMEUBLEL)
        
        
		select STEMPID,STEMPAR,ARLIB,STFO,STEMPEMP,#resultats.xDEPOT,xEMP_ORG,STLOT,NLOTDATEPER,STLETTRE,STEMPQTE,STNUMARM1,STNUMARM2,STDEVISE,STPADEV,STPAHT,STFRAIS,isnull(ST_UG,0) as UG,xEMP_DEST,ARFRANCOFO 
		into #result 
		from #resultats 
		inner join #view_Stock_Lot_Emplacement on STEMPAR=xArticle and STEMPDEPOT=#resultats.xDEPOT and STLOT=xLOT and STEMPEMP=xEMP_ORG
		left join #xEmp_Diguel on STEMPAR=xArticle and xDEPOTL=#resultats.xDEPOT and xEMPL=xEMP_ORG 
		where #resultats.xDEPOT=@depot
		and (@alle=null or @alle='' or xALLEL=@alle)
		
		select STEMPAR,ARLIB,STLOT,NLOTDATEPER,xDEPOT,xEMP_ORG,ARFRANCOFO,xDEPOT,xEMP_DEST,sum(STEMPQTE) as QUANTITE,0 
		from #result  
		group by xEMP_DEST,STEMPAR,xEMP_ORG,ARLIB,STLOT,NLOTDATEPER,xDEPOT,xDEPOT,ARFRANCOFO
		--order by xEMP_ORG,STEMPAR

		
		/*declare stock cursor for  select STEMPID,STEMPQTE,STEMPEMP,STLETTRE, STLOT,STEMPAR from #result 
        open stock
        fetch stock into @STEMPID,@STEMPQTE,@STEMPEMP,@xSTLETTRE,@STLOT,@ARCODE 
        while (@@sqlstatus=0)
        begin
            
        		exec hp_GetQteArticleEtiquette @ARCODE,@STEMPQTE,@xSTLETTRE,@STEMPEMP,@STLOT ,@qteNonEt  output ,@qteEncoursEt  output,@qteEt  output
        		
                insert into #appro (xSTID,xQTE_NONETIQ,xQTE_ENCOURSETIQ,xQTE_ETIQ) values (@STEMPID,@qteNonEt,@qteEncoursEt,@qteEt)
               

                fetch stock into @STEMPID,@STEMPQTE,@STEMPEMP,@xSTLETTRE,@STLOT, @ARCODE 
        end
        close stock 
        deallocate cursor stock*/
        
        --select * from #appro
        
        select STEMPAR,ARLIB,STFO,xDEPOT,xEMP_ORG,xDEPOT,xEMP_DEST,STLOT,NLOTDATEPER,STLETTRE,STEMPQTE,STNUMARM1,STNUMARM2,STDEVISE,STPADEV,STPAHT,STFRAIS,UG,0,0,0
        --xQTE_NONETIQ,xQTE_ENCOURSETIQ,xQTE_ETIQ 
        from #result --inner join  #appro on xSTID=STEMPID 
        order by xEMP_DEST,STEMPAR
        --xARTICLE,convert(int,xNIVEAUL),convert(int,xMEUBLEL)
						
							 
		drop table #result 
		drop table #appro
	
        --drop table #reservation
        drop table #Emplacement
        drop table #resultTmp
        drop table #xEmp_Diguel 
        drop table #VIEW_LOT_VENTE_DEPOT 
        drop table #EmplDest
        drop table #A_deplacer
        drop table #resultats

	
end
go

