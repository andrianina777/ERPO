





create procedure Journal_Inventaire (@ent		char(5)	= null, 
									 @code		char(8) = null, 
									 @depot		char(4) = null, 
									 @emp		char(9) = null, 
									 @type		tinyint) 
with recompile 
as 
begin 
 
declare @modevalo 			tinyint, 
 		@date 				datetime, 
 		@article			char(15), 
		@articleprecedent	char(15), 
		@qte				int, 
		@PrixRevient		numeric(14,4), 
		@PrixRevientLigne	numeric(14,2), 
		@seq				int 
 
select @date=getdate() 
select @modevalo=PMODEVALO from KParam 
select @articleprecedent = "" 
 
if isnull(@emp,'')<>'' select @emp=rtrim(@emp)+'%' 
 
create table #Final 
( 
ARFO			char(12)		not null, 
ARFAM			char(8)			not null, 
ARCODE			char(15)		not null, 
INSLETTRE		char(4) 			null, 
INSDEPOT		char(4)			not null, 
INSEMP			char(8)				null, 
ARLIB			varchar(80)			null, 
INSQTE			int				not null, 
VALEURFINAL		numeric(14,2)		null, 
Seq				numeric(14,0)	identity 
) 
 
 
declare st_curs cursor  
for select ARCODE,INSQTE,Seq 
from #Final 
order by Seq 
for read only 
 
if @type=0 
begin 
	if @modevalo=1 
               select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,INSQTE*ARPRM 
               from FINS,FDP,FAR 
               where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
               and ARCODE=INSAR and INSCODE=@code 
               and (@emp is null or INSEMP like @emp) 
               and (@depot is null or INSDEPOT=@depot) 
               order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP 
        else 
               insert into #Final (ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,VALEURFINAL) 
               select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,0 
               from FINS,FDP,FAR 
               where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
               and ARCODE=INSAR and INSCODE=@code 
               and (@emp is null or INSEMP like @emp) 
               and (@depot is null or INSDEPOT=@depot) 
               order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP 
end 
 
if @type=1 
begin 
     	if @modevalo=1 
               select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,INSQTE*ARPRM 
               from FINS,FDP,FAR 
               where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
               and ARCODE=INSAR and ARNUMEROTE=0 and INSCODE=@code 
               and (@emp is null or INSEMP like @emp) 
               and (@depot is null or INSDEPOT=@depot) 
               order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP  
        else 
               insert into #Final (ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,VALEURFINAL) 
               select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,0 
               from FINS,FDP,FAR 
               where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
               and ARCODE=INSAR and ARNUMEROTE=0 and INSCODE=@code 
               and (@emp is null or INSEMP like @emp) 
               and (@depot is null or INSDEPOT=@depot) 
               order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP 
end 
 
if @type=2 or @type=3  
begin 
     	if @modevalo=1 
               begin 
                    if @type=2 
                         select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,INSQTE*ARPRM 
                         from FINS,FDP,FAR 
                         where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
                         and ARCODE=INSAR and ARNUMEROTE=1 and INSCODE=@code 
                         and (@emp is null or INSEMP like @emp) 
                         and (@depot is null or INSDEPOT=@depot) 
                         order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP 
                    else 
                         select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,sum(INSQTE),sum(INSQTE*ARPRM) 
                         from FINS,FDP,FAR 
                         where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
                         and ARCODE=INSAR and ARNUMEROTE=1 and INSCODE=@code 
                         and (@emp is null or INSEMP like @emp) 
                         and (@depot is null or INSDEPOT=@depot) 
                         group by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB 
                         order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP                       
               end 
        else             
               begin 
               insert into #Final (ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,VALEURFINAL) 
               select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,0 
               from FINS,FDP,FAR 
               where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
               and ARCODE=INSAR and ARNUMEROTE=1 and INSCODE=@code 
               and (@emp is null or INSEMP like @emp) 
               and (@depot is null or INSDEPOT=@depot) 
               order by ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP 
               end 
end 
 
 
if @modevalo in (0,2,3,4)	  					/*--------------------- FIFO/PUMP/DPA/PRM Mensuel  */ 
  	begin 
               	              	 
               	create unique index seq on #Final (Seq) 
		 
		open st_curs 
		 
		fetch st_curs 
		into @article,@qte,@seq 
               	 
               	 
		while (@@sqlstatus = 0) 
			begin 
			 
		  if @articleprecedent != @article 
		  begin 
			select 	@PrixRevient = 0 
			 
			if @modevalo = 2									/*--------------------- PUMP */ 
			begin 
			  select @PrixRevient=isnull(PUMP,0) 
			  from FPUM 
			  where PUMAR = @article 
			  and PUMDATE <= convert (smalldatetime, getdate()) 
			  having PUMAR = @article 
			  and PUMDATE <= convert (smalldatetime, getdate()) 
			  and PUMDATE = max(PUMDATE) 
			   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
			   
			end 
			 
			else if @modevalo = 3								/*--------------------- PRM Mensuel */ 
			 
			begin 
			  set rowcount 1 
			   
			  select @PrixRevient=isnull(PRM,0) 
			  from FPRM 
			  where PRMAR = @article 
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate())) 
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate())) 
			  and PRMAR = @article 
			  order by PRMAN desc,PRMMOIS desc 
			   
			  set rowcount 0 
			   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
			end 
			 
			else  if @modevalo = 4 or @modevalo = 0				/*--------------------- DPA unitaire /FIFO */ 
			 
			begin 
			  set rowcount 1			 
			 
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4) 
			  from FBLL,FCV 
			  where BLLAR=@article 
			  and CVUNIF=BLLUA 
			  having BLLAR=@article 
			  and CVUNIF=BLLUA 
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end)) 
			 
			  if isnull(@PrixRevient,0)=0 
			  begin 
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4) 
				from FSIL,FAR,FCV 
				where SILARTICLE=@article 
				and ARCODE = SILARTICLE 
				and ARUNITACHAT = CVUNIF 
				having SILARTICLE=@article 
				and ARCODE = SILARTICLE 
				and ARUNITACHAT = CVUNIF 
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end)) 
			  end 
			   
			  set rowcount 0 
			   
			  if @PrixRevient is null 
				select @PrixRevient = 0 
	   
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
			end 
		  end 
		  else if @articleprecedent = @article 
		  begin 
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
		  end 
 
 
			update #Final set VALEURFINAL=@PrixRevientLigne 
			where Seq = @seq 
		 
			select  @articleprecedent = @article 
			 
			fetch st_curs 
			into @article,@qte,@seq 
			 
		end 
                	 
                close st_curs 
                 
                 
            	select ARFO,ARFAM,ARCODE,INSLETTRE,INSDEPOT,INSEMP,ARLIB,INSQTE,VALEURFINAL from #Final 
            	 
            	 
	end 
 
 
drop table #Final	 
 
end	 




go

