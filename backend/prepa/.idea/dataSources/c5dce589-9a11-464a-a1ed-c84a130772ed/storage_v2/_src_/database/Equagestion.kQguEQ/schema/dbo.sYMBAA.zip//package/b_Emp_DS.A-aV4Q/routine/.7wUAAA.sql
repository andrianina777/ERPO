CREATE PROCEDURE dbo.b_Emp_DS (@num_DS char(10))


AS
begin
			declare @xArcode char(15)
			
			create table #VIEW_FDSL(
                ARTICLE char(15),
                QUANTITE int
                
        	)
        	
        	create table #xFare_DET(
                xARTICLE char(15),
                xAREEMP char(8) null,
                xSSEMP char(8) null,
                xDEPOT char(8) null
        	)
        	create table #xFare_GROS(
                xARTICLES char(15),
                xAREEMPS char(8) null,
                xDEPOTS char(8) null
        	)
        	if(@num_DS!='' and @num_DS is not null)
        		begin
        			insert into #VIEW_FDSL select DSL_ARCODE,sum(DSLARQTE) from TRT_Opham..FDSL where DSL_DSCODE=@num_DS group by DSL_ARCODE
        			insert into #xFare_DET select  ARTICLE,AREEMP,ARESSEMP,AREDEPOT from #VIEW_FDSL left join FARE on ARTICLE=AREAR where AREPICK=1 and ARERECEP=1 and AREVALID=1 and AREDEPOT='DET'
        			insert into #xFare_GROS select  ARTICLE,AREEMP,AREDEPOT from #VIEW_FDSL left join FARE on ARTICLE=AREAR where AREPICK=1 and ARERECEP=1 and AREVALID=1 and AREDEPOT='GROS'
        			
        			select distinct @num_DS as NUMERO_DS,ARTICLE as CODE_ARTICLE,ARLIB as LIBELLE,QUANTITE,xDEPOT as DEPOT_DET,xAREEMP as RAYON,xSSEMP as SSEMPL_DET,xDEPOTS as DEPOT_GROS,xAREEMPS as EMPLACEMT_GROS from #VIEW_FDSL
        			inner join #xFare_DET on ARTICLE=xARTICLE inner join #xFare_GROS on ARTICLE=xARTICLES inner join VIEW_FAR_TOUS on ARCODE=ARTICLE order by ARCODE
        		end
        	
        	
	    drop table #VIEW_FDSL,#xFare_DET,#xFare_GROS
end

go

