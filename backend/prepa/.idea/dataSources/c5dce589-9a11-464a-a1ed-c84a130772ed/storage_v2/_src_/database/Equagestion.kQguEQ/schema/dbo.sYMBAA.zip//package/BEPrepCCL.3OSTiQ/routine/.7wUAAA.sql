


create procedure BEPrepCCL (@ent		char(5)	= null,
							@Client 	char(12),
							@Commande	char(10),
							@Depot		char(4) = null
							)
with recompile
as
begin

create table #Stock
(
ArticleCde	char(15)	not null,
QteLoc		int				null,
QteAutre	int				null,
QteDepot	int				null
)

create table #StockDep
(
Article		char(15)	not null,
Qte			int				null,
Depot		char(4)			null,
Emplace		char(8)			null
)

create table #Articles
(
CCLARTICLE	char(15)	not null,
ALivrer		int				null
)

create table #Art
(
CCLARTICLE	char(15)	not null
)

select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLLIBRE,
CCLRESTE,MODELIV=substring(CCMODELIV,1,2),CLNOM1,CLPREP=isnull(CLPREP,0),
CCPREP=isnull(CCPREP,0),CCLQTEPREP=isnull(CCLQTEPREP,0),CCFRANCO=isnull(CCFRANCO,0),
CCFRANCOBE=isnull(CCFRANCOBE,0)
into #Prep
from FCCL,FAR,FCC,FCL
where CCLARTICLE=ARCODE
and CCLCODE=CCCODE
and CCLCL=CLCODE
and CCLCL=@Client
and CCLCODE=@Commande
and CCLRESTE > 0
and CCLRESTE - isnull(CCLQTEPREP,0) > 0
and (@ent is null or (CCLENT=@ent and CCENT=CCLENT and CLENT=CCLENT))
and isnull(CCVALIDE,0)=0
and isnull(CCBEBLOQUE,0)=0
and CCLDATE <= dateadd(dd,5,getdate())

	
insert into #Art
select CCLARTICLE
from #Prep
group by CCLARTICLE

insert into #Articles
select RCCARTICLE,sum(RCCQTE)
from FRCC,#Art
where RCCARTICLE=CCLARTICLE
and (@ent is null or RCCENT=@ent)
group by RCCARTICLE

create unique index art on #Articles (CCLARTICLE)

drop table #Art


insert into #StockDep (Article,Qte,Depot,Emplace)
select CCLARTICLE,isnull(sum(STEMPQTE),0),isnull(STEMPDEPOT,''),STEMPEMP
from #Articles,FSTEMP,FDP
where STEMPAR=*CCLARTICLE
and DPCODE*=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by CCLARTICLE,STEMPDEPOT,STEMPEMP


create unique index ardep on #StockDep (Article,Depot,Emplace)


if @Depot is null
begin
  insert into #Stock (ArticleCde,QteLoc,QteAutre,QteDepot)
  select Article,sum(case when DPLOC = 1 then Qte else 0 end),
				 sum(case when DPLOC != 1 then Qte else 0 end),
				 sum(case when DPLOC = 1 then Qte else 0 end)
  from #StockDep,FDP
  where Depot*=DPCODE
  group by Article
end
else
begin
  insert into #Stock (ArticleCde,QteLoc,QteAutre,QteDepot)
  select Article,sum(case when Depot = @Depot then Qte else 0 end),
				 sum(case when Depot != @Depot then Qte else 0 end),
				 sum(case when Depot = @Depot then Qte else 0 end)
  from #StockDep
  group by Article
end


create unique index article on #Stock (ArticleCde)

select Cde=CCLCODE,Article=CCLARTICLE,Qte=CCLRESTE,ARTYPE
into #Complet
from #Prep,FAR
where (CLPREP=1 or CCPREP=1)
and ARCODE=CCLARTICLE
and ARCOMP != 2

delete #Prep
from #Stock,#Complet
where Cde=CCLCODE
and ArticleCde=Article
and Qte > (QteLoc+QteAutre)
and ARTYPE = 0

drop table #Complet


select CCLSEQ,CCLCL,CCLCODE,CCLNUM,CCLDATE,#Prep.CCLARTICLE,CCLLIBRE,
		CCLRESTE,ARLIB,MODELIV,isnull(QteLoc,0),isnull(QteLoc,0)+isnull(QteAutre,0),
		ALivrer,CLNOM1,ARCOMP,ARREFFOUR,ARNUMEROTE,CCLQTEPREP,CCFRANCO,CCFRANCOBE,isnull(QteDepot,0)
from #Prep,#Stock,#Articles,FAR
where #Prep.CCLARTICLE = ARCODE
and #Stock.ArticleCde=*ARCODE
and #Articles.CCLARTICLE = ARCODE
and ((isnull(QteLoc,0)+isnull(QteAutre,0)>0) or (ARTYPE <> 0))
order by CCLCL,CCLCODE,CCLNUM



drop table #Prep
drop table #Articles
drop table #Stock

end



go

