

create procedure Conversion_div_proc   (@mtdev 	numeric(14,3),
							 	 		@cours	numeric(16,10),
							 	 		@tronc	tinyint = 3,
										@mt		float output
								 		)
with recompile
as
begin

set arithabort numeric_truncation off


if @tronc > 6
	select @tronc = 6

if @tronc = 0
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*1))/1
else if @tronc = 1
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*10))/10
else if @tronc = 2
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*100))/100
else if @tronc = 3
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*1000))/1000
else if @tronc = 4
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*10000))/10000
else if @tronc = 5
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*100000))/100000
else if @tronc = 6
	select @mt = convert(float,convert(numeric(38,0),convert(float,@mtdev/@cours)*1000000))/1000000


end

go

