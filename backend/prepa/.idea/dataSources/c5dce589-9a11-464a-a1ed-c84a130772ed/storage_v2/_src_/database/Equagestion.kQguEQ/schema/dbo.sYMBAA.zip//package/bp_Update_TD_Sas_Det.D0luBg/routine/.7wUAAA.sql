/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_Update_TD_Sas_Det
grant execute on bp_Update_TD_Sas_Det to public
*/

CREATE PROCEDURE dbo.bp_Update_TD_Sas_Det(@org char(10),@article char(15),@lettre char(4),@emp_org char(8),@qte int)
with recompile
AS
begin
	 declare
	 	@seq int,
	 	@qteCtrl int,
	 	@qteTD_SAS int
	 	
	 	
	 	declare liste cursor for select SILSEQ,isnull(SILQTECTRL,0),isnull(SILTD_SAS_DET,0) from FSIL where SILARTICLE=@article and SILLETTRE=@lettre and SILDEPOT=@org and SILTYPEMV in ('TD','SI','BE') and SILQTE>0 
	 							 and isnull(SILSTADE,0)>1 and isnull(SILQTECTRL,0)<>0 and SILEMP=@emp_org and 
	 							 isnull(SILQTECTRL,0)<>isnull(SILTD_SAS_DET,0) 
	 							  order by SILSEQ asc
	 	open liste						 
		fetch liste into @seq,@qteCtrl,@qteTD_SAS
		
		while(@@sqlstatus=0)
			begin
				if(@qteCtrl<=@qte)
					begin
						update FSIL set SILTD_SAS_DET=@qteCtrl where SILSEQ=@seq
						select @qte=@qte-@qteCtrl+@qteTD_SAS
					end
				else
					begin
						if(@qteTD_SAS+@qte<=@qteCtrl)
							begin
								update FSIL set SILTD_SAS_DET=isnull(SILTD_SAS_DET,0)+@qte where SILSEQ=@seq
								select @qte=0
							end
						else
							begin
								update FSIL set SILTD_SAS_DET=@qteCtrl where SILSEQ=@seq
								select @qte=@qteTD_SAS+@qte-@qteCtrl
							end
					end	
				fetch liste into @seq,@qteCtrl,@qteTD_SAS
			end
		close liste
		deallocate cursor liste
end
go

