


create procedure Reglem	(@ent	char(5)	= null,
						 @date1	smalldatetime,
						 @date2	smalldatetime,
						 @fourn	char(12) = null)
			
with recompile
as
begin


	/* Materiel en stock */

	select Fournisseur=STFO,ArticleST=STAR,LettreST=STLETTRE,Arme1ST=STNUMARM1,
			Arme2ST=STNUMARM2,DateST=STDATEENTR,Qte=STQTE
	into #Stock
	from FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STQTE > 0
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	/* Reintegration en stock des produits sortis apres @date2 */
	
	insert into #Stock
	select STFO,BELARTICLE,BELLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,BELQTE
	from FBEL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=BELARTICLE
	and STLETTRE=BELLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and BELDATE > @date2
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	insert into #Stock
	select STFO,RFLARTICLE,RFLLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,RFLQTE
	from FRFL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=RFLARTICLE
	and STLETTRE=RFLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and RFLDATE > @date2
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (RFLENT=@ent and DPENT=@ent and DPCENTRAL=0))

	
	insert into #Stock
	select STFO,SILARTICLE,SILLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,-SILQTE
	from FSIL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=SILARTICLE
	and STLETTRE=SILLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and SILDATE > @date2
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	insert into #Stock
	select STFO,RJLARTICLE,RJLLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,-RJLQTE
	from FRJL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=RJLARTICLE
	and STLETTRE=RJLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and RJLDATE > @date2
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	insert into #Stock
	select STFO,LCLARTICLE,LCLLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,-LCLQTE
	from FLCL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=LCLARTICLE
	and STLETTRE=LCLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and LCLDATE > @date2
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	insert into #Stock
	select STFO,ASLARTICLE,ASLLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,-ASLQTE
	from FASL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=ASLARTICLE
	and STLETTRE=ASLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and ASLDATE > @date2
	and STDATEENTR <= @date2
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	
	
	select Fournisseur,ArticleST,LettreST,Arme1ST,Arme2ST,DateST,Qte=sum(Qte)
	into #StockReconstruit
	from #Stock
	group by Fournisseur,ArticleST,LettreST,Arme1ST,Arme2ST,DateST
	
	drop table #Stock
	
	
	/* Materiel sorti par BEL entre les dates indiquees */
	
	select Fournisseur=STFO,ArticleBE=BELARTICLE,LettreBE=BELLETTRE,Arme1BE=STNUMARM1,Arme2BE=STNUMARM2,
			EntreeBE=STDATEENTR,ClientBE=BELCL,SortieBE=BELDATE,CodeBE=BELCODE,QteBE=BELQTE
	into #BEL
	from FBEL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=BELARTICLE
	and STLETTRE=BELLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and BELDATE between @date1 and @date2
	and BELQTE > 0
	and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	/* Materiel sorti par RFL entre les dates indiquees */	
	
	insert into #BEL
	select STFO,RFLARTICLE,RFLLETTRE,STNUMARM1,STNUMARM2,STDATEENTR,STFO,RFLDATE,RFLCODE,RFLQTE
	from FRFL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=RFLARTICLE
	and STLETTRE=RFLLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and RFLDATE between @date1 and @date2
	and DPCODE=STDEPOT and (@ent is null or (RFLENT=@ent and DPENT=@ent and DPCENTRAL=0))
	

	
	/* Materiel en retour entre les dates indiquees */
	
	insert into #BEL
	select Fournisseur=BELCL,ArticleBE=BELARTICLE,LettreBE=BELLETTRE,Arme1BE=STNUMARM1,Arme2BE=STNUMARM2,
			EntreeBE=BELDATE,ClientBE='',SortieBE=null,CodeBE=BELCODE,QteBE=BELQTE
	from FBEL,FSTOCK,FAR,FDP
	where ARCODE=STAR
	and ARREGLE in (1,3)
	and (@fourn is null or STFO=@fourn)
	and STAR=BELARTICLE
	and STLETTRE=BELLETTRE
	and (STNUMARM1 != '' or STNUMARM2 != '')
	and BELDATE between @date1 and @date2
	and BELQTE < 0
	and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and DPENT=@ent and DPCENTRAL=0))
	
	
	/* Liste finale */
	
	select AREMP,ARCALIBRE,ARFO,Arme1ST+" "+Arme2ST,convert(char,DateST,103),Fournisseur,
			'','',null,Qte,ArticleST,LettreST
	from #StockReconstruit,FAR
	where ARCODE=ArticleST
	and Qte > 0
	
	union
	
	select AREMP,ARCALIBRE,ARFO,Arme1BE+" "+Arme2BE,convert(char,EntreeBE,103),Fournisseur,
			(case when convert(char(11),SortieBE) != null
					then BENOM+' '+BEADR1+' '+BEADR2+' - '+BECP+' '+BEVILLE
				  else '' end),
			CLNOAGR,convert(char,SortieBE,103),QteBE,ArticleBE,LettreBE
	from #BEL,FAR,FCL,FBE
	where ARCODE=ArticleBE
	and BECODE=CodeBE
	and CLCODE=*ClientBE
	and (@ent is null or (BEENT=@ent and CLENT=@ent))
	order by ARFO,convert(char,DateST,103)
	
	
	drop table #StockReconstruit
	drop table #BEL
	
end



go

