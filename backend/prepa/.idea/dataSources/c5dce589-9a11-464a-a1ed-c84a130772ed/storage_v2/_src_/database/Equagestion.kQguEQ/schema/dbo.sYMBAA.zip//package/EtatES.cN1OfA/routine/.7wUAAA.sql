


create procedure EtatES (	@ent 	char(5) = null,
							@date	smalldatetime, 
						 	@varfo	varchar(12)
						)
with recompile
as
begin
	
	create table #temp1
	(
		codeseq 		int 		not null,
		declarentree 	varchar(12) 	null,
		declarsortie 	varchar(12) 	null,
		date 			smalldatetime 	null,
		fournisseur 	varchar(12) 	null,
		reffour 		varchar(35) 	null,
		article 		varchar(15) 	null,
		designation 	varchar(80) 	null,
		numfac 			varchar(12) 	null,
		codedouane 		varchar(16) 	null,
		nbcolis 		int 			null,
		qteentree 		int 			null,
		qtesortie 		int 			null
	)	
	
	/* les entrees */
	
	if @varfo=''
	
		insert #temp1 (codeseq,declarentree,date,fournisseur,
		reffour,article,designation,numfac,codedouane,nbcolis,qteentree)
		(select BLLSEQ,BLLM7,BLLDATE,BLLFO,FONOM,BLLAR,
				ARLIB,BLLNFACT,ARCODEDOUA,BLLNCAR,BLLQTE
			from FBLL,FAR,FFO
			where BLLAR=ARCODE and BLLFO=FOCODE and BLLDEP='DOUA' and BLLM7<>''
			and BLLDATE<=@date and BLLCM=1
			and (@ent is null or BLLENT=@ent))

	else

		insert #temp1 (codeseq,declarentree,date,fournisseur,
		reffour,article,designation,numfac,codedouane,nbcolis,qteentree)
		(select BLLSEQ,BLLM7,BLLDATE,BLLFO,FONOM,BLLAR,
				ARLIB,BLLNFACT,ARCODEDOUA,BLLNCAR,BLLQTE
			from FBLL,FAR,FFO
			where BLLAR=ARCODE and BLLFO=FOCODE and BLLDEP='DOUA' and BLLM7<>'' 
			and BLLDATE<=@date and BLLFO=@varfo and BLLCM=1
			and (@ent is null or BLLENT=@ent))

	
	/* les sorties */	
	
	if @varfo=''
	
		insert #temp1 (codeseq,declarentree,declarsortie,date,
		fournisseur,reffour,article,designation,codedouane,nbcolis,qtesortie)
		(select DOLSEQ,DOLM7,DOLCODE,DOLDATE,DOLFO,FONOM,DOLAR,
				ARLIB,ARCODEDOUA,DOLNCAR,DOLQTE
			from FDOL,FAR,FFO
			where DOLAR+""=ARCODE and DOLFO=FOCODE and DOLDEP='DOUA' and DOLCODE<>''
			and DOLDATE<=@date and DOLCM=1
			and (@ent is null or DOLENT=@ent))
	
	else
	
		insert #temp1 (codeseq,declarentree,declarsortie,date,
		fournisseur,reffour,article,designation,codedouane,nbcolis,qtesortie)
		(select DOLSEQ,DOLM7,DOLCODE,DOLDATE,DOLFO,FONOM,DOLAR,
				ARLIB,ARCODEDOUA,DOLNCAR,DOLQTE
			from FDOL,FAR,FFO
			where DOLAR=ARCODE and DOLFO=FOCODE and DOLDEP='DOUA' and DOLCODE<>''
			and DOLDATE<=@date and DOLFO=@varfo and DOLCM=1
			and (@ent is null or DOLENT=@ent))
	
	
	/* retour des valeurs */	
	
	select codeseq,declarentree,declarsortie,date,reffour,designation,numfac,
	codedouane,nbcolis,qteentree,qtesortie
	from #temp1
	order by fournisseur,declarentree,article,declarsortie
	
	drop table #temp1
	
end	



go

