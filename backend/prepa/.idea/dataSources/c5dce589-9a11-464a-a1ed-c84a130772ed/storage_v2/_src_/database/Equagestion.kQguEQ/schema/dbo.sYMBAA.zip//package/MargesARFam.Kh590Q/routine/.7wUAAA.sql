


/* Procedure donnant la marge des articles d''une famille entre 2 dates */


create procedure MargesARFam(@ent		char(5)	= null,
							 @annee		smallint,
							 @moisdeb	tinyint,
							 @moisfin	tinyint,
							 @Fam		char(8))
with recompile
as
begin

select 	FO=ARFO,Art=ARCODE,Lib=ARLIB,
		Qte=sum(STQTEFA),
		Ventes=sum(STCAFA),
		PR=sum(STPR),
		MargeFF=sum(STCAFA)-sum(STPR),
		Marge=round((sum(STCAFA)-sum(STPR))/(case when isnull(sum(STCAFA),0) != 0
												  then isnull(sum(STCAFA),0) 
												  else 1 end),2)
from FST,FAR
where ARCODE=START
and STAN=@annee
and STMOIS between @moisdeb and @moisfin
and ARFAM=@Fam
and (@ent is null or STENT=@ent)
group by ARFO,ARCODE,ARLIB
order by ARFO,ARCODE
compute sum(sum(STQTEFA)),sum(sum(STCAFA)),sum(sum(STPR)),sum(sum(STCAFA)-sum(STPR)) by ARFO
compute sum(sum(STQTEFA)),sum(sum(STCAFA)),sum(sum(STPR)),sum(sum(STCAFA)-sum(STPR))


end



go

