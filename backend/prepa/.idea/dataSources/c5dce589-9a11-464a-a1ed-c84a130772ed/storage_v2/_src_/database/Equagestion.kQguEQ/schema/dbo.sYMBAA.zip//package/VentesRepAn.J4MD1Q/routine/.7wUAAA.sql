


create procedure VentesRepAn (@ent			char(5)	 = null,
							  @an			smallint,
							  @Fournisseur	char(12) = null,
							  @Famille		char(8)  = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1		datetime
declare @date2		datetime


create table #temp
(
Client			char(12)	not null,
Qte_Annee1		int			null,
Qte_Annee		int			null,
Qte_Cde			int			null,
CA_Annee1		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null,
CA_Cde			numeric(14,2)		null
)

create table #Final
(
Client			char(12)	not null,
Qte_Annee1		int			null,
Qte_Annee		int			null,
Qte_Cde			int			null,
CA_Annee1		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null,
CA_Cde			numeric(14,2)		null
)

create table #Far
(
Article		char(15)			null
)

create table #Far2
(
Article		char(15)		not	null
)

/* Recuperation des articles souhaites */

if (@Fournisseur is null) and (@Famille is null)
	begin
		insert into #Far
		select ARCODE from FAR
	end
else if (@Fournisseur is null) and (@Famille is not null)
	begin
		insert into #Far
		select ARCODE from FAR
		where ARFAM=@Famille
	end
else if (@Fournisseur is not null) and (@Famille is null)
	begin
		insert into #Far
		select ARCODE from FAR
		where ARFO=@Fournisseur
	end
else if (@Fournisseur is not null) and (@Famille is not null)
	begin
		insert into #Far
		select ARCODE from FAR
		where ARFO=@Fournisseur
		and ARFAM=@Famille
	end

create unique clustered index  art on #Far (Article)

insert into #Far2
select Article from #Far

create unique clustered index  art on #Far2 (Article)


/* Quantites et CA pour An-1 */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an-1))
select @date2=convert(datetime,'12/31/'+convert(varchar(4),@an-1))

insert into #temp (Client,Qte_Annee1,CA_Annee1)
select FALCL,sum(FALQTE),sum(FALTOTALHT)
from FFAL(4),#Far
where Article=FALARTICLE
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by FALCL


/* Quantites et CA pour Annee en cours */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an))
select @date2=convert(datetime,'12/31/'+convert(varchar(4),@an))

insert into #temp (Client,Qte_Annee,CA_Annee)
select FALCL,sum(FALQTE),sum(FALTOTALHT)
from FFAL(4),#Far
where Article=FALARTICLE
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by FALCL

drop table #Far

/* Quantites et CA en commande client */

insert into #temp (Client,Qte_Cde,CA_Cde)
select RCCCL,sum(RCCQTE),sum(CCLTOTALHT*round(RCCQTE/CCLQTE,2))
from FRCC,FCCL,#Far2,FCC
where Article=RCCARTICLE
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT))
group by RCCCL

drop table #Far2


insert into #Final(Client,Qte_Annee1,Qte_Annee,Qte_Cde,CA_Annee1,CA_Annee,CA_Cde)
select Client,sum(Qte_Annee1),sum(Qte_Annee),sum(Qte_Cde),sum(CA_Annee1),
			sum(CA_Annee),sum(CA_Cde)
from #temp
group by Client

drop table #temp


select 	Rep=isnull(CLREP,"        "),
		Dep=isnull(substring(CLCP,1,2),"  "),
		Ville=isnull(CLVILLE,"        "),
		Client=isnull(Client,"        "),
		Numcomptable=isnull(CLNUMCOMPTABLE,"        "),
		Nom=isnull(CLNOM1,"        "),
		Qte_1=isnull(Qte_Annee1,0),
		Qte=isnull(Qte_Annee,0),
		Qte_Cde=isnull(Qte_Cde,0),
		CA_1=convert(int,isnull(CA_Annee1,0)),
		CA=convert(int,isnull(CA_Annee,0)),
		CA_Cde=convert(int,isnull(CA_Cde,0))
from #Final,FCL
where CLCODE=Client
and (@ent is null or CLENT=@ent)
order by CLREP,substring(CLCP,1,2),CLVILLE,Client
compute sum(isnull(Qte_Annee1,0)),
		sum(isnull(Qte_Annee,0)),sum(isnull(Qte_Cde,0)),
		sum(convert(int,isnull(CA_Annee1,0))),
		sum(convert(int,isnull(CA_Annee,0))),sum(convert(int,isnull(CA_Cde,0)))
		by CLREP,substring(CLCP,1,2)
compute sum(isnull(Qte_Annee1,0)),
		sum(isnull(Qte_Annee,0)),sum(isnull(Qte_Cde,0)),
		sum(convert(int,isnull(CA_Annee1,0))),
		sum(convert(int,isnull(CA_Annee,0))),sum(convert(int,isnull(CA_Cde,0)))
		by CLREP
compute sum(isnull(Qte_Annee1,0)),
		sum(isnull(Qte_Annee,0)),sum(isnull(Qte_Cde,0)),
		sum(convert(int,isnull(CA_Annee1,0))),
		sum(convert(int,isnull(CA_Annee,0))),sum(convert(int,isnull(CA_Cde,0)))


drop table #Final

end



go

