


create procedure Verif_Stock_MouvAR	(@article char(15))
with recompile
as
begin

declare @anmouv		smallint,
		@moismouv	tinyint,
		@datedeb	smalldatetime

select @anmouv=datepart(yy,getdate())-1

select @datedeb=convert(smalldatetime,'01/01/'+convert(char(4),datepart(yy,getdate())))


/***** Mouvements *****/


select MOISARTICLE,moisqte=sum(MOISQTE),moisvaleur=sum(MOISTOTPR)
into #Mouv
from FMOIS,FAR
where MOISARTICLE=ARCODE
and ARTYPE in (0,1)
and MOISARTICLE=@article
and MOISANNEE=@anmouv
and MOISMOIS=12
and MOISQTE != 0
group by MOISARTICLE


insert into #Mouv
select SILARTICLE,sum(SILQTE),sum(round((SILPAHT+SILFRAIS)/CVLOT,2)*SILQTE)
from FSIL,FAR,FCV
where SILDATE >= @datedeb
and SILARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)
and SILARTICLE=@article
group by SILARTICLE

/* having sum(SILQTE)!=0 */


insert into #Mouv
select RJLARTICLE,sum(RJLQTE),sum(round((RJLPAHT+RJLFRAIS)/CVLOT,2)*RJLQTE)
from FRJL,FAR,FCV
where RJLDATE >= @datedeb
and RJLARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and RJLARTICLE=@article
group by RJLARTICLE

/* having sum(RJLQTE)!=0 */


insert into #Mouv
select LCLARTICLE,sum(LCLQTE),sum(round((LCLPAHT+LCLFRAIS)/CVLOT,2)*LCLQTE)
from FLCL,FAR,FCV
where LCLDATE >= @datedeb
and LCLARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and LCLARTICLE=@article
group by LCLARTICLE

/* having sum(LCLQTE)!=0 */


insert into #Mouv
select ASLARTICLE,sum(ASLQTE),sum(round((ASLPAHT+ASLFRAIS)/CVLOT,2)*ASLQTE)
from FASL,FAR,FCV
where ASLDATE >= @datedeb
and ASLARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and ASLARTICLE=@article
group by ASLARTICLE

/* having sum(ASLQTE)!=0 */


insert into #Mouv
select RMARTICLE,sum(RMQTE),sum(round((RMPAHT+RMFRAIS)/CVLOT,2)*RMQTE)
from FRM,FAR,FCV
where RMDATE >= @datedeb
and RMARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and RMARTICLE=@article
group by RMARTICLE

/* having sum(RMQTE)!=0 */


insert into #Mouv
select BLLAR,sum(BLLQTE),sum(BLLTOTHT)
from FBLL
where BLLDATE >= @datedeb
and BLLAR=@article
group by BLLAR

/* having sum(BLLQTE)!=0 */


insert into #Mouv
select DOLAR,sum(DOLQTE),sum(DOLTOTHT)
from FDOL
where DOLDATE >= @datedeb
and DOLAR=@article
group by DOLAR

/* having sum(DOLQTE)!=0*/


insert into #Mouv
select RFLARTICLE,-sum(RFLQTE),-sum(RFLTOTALHT)
from FRFL
where RFLDATE >= @datedeb
and RFLARTICLE=@article
group by RFLARTICLE

/* having sum(RFLQTE)!=0 */


insert into #Mouv
select FALARTICLE,-sum(FALQTE),-sum(round((STPAHT+STFRAIS)/CVLOT,2)*FALQTE)
from FFAL,FSTOCK,FAR,FCV
where FALDATE >= @datedeb
and FALARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)
and FALARTICLE=@article
and isnull(FALLETTRE,'')!=''
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
group by FALARTICLE

/* having sum(FALQTE)!=0 */


/***** Stock *****/


select article=STAR,Qte=sum(STQTE),Valeur=sum(round((STPAHT+STFRAIS)/CVLOT,2)*STQTE)
into #Entree
from FSTOCK,FAR,FCV
where STAR=ARCODE
and ARUNITACHAT=CVUNIF
and STAR=@article
and ARTYPE in (0,1)
and STQTE != 0
group by STAR


insert into #Entree
select RBEARTICLE,sum(BELQTE),sum(round((STPAHT+STFRAIS)/CVLOT,2)*BELQTE)
from FRBE,FAR,FBEL,FCV,FSTOCK
where RBEARTICLE=ARCODE
and ARUNITACHAT=CVUNIF
and ARTYPE in (0,1)
and RBEARTICLE=@article
and RBESEQ=BELSEQ
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
group by RBEARTICLE

/* having sum(BELQTE)!=0 */


select article,stockqte=sum(Qte),stockval=sum(Valeur)
into #Stock
from #Entree
group by article


select MOISARTICLE,moisqte=sum(moisqte),moisvaleur=sum(moisvaleur)
into #Mouvements
from #Mouv
group by MOISARTICLE


select 'Articles presentant des differences'

select article,stockqte,moisqte,difqte=stockqte-moisqte,stockval,moisvaleur,difvaleur=stockval-moisvaleur
from #Stock,#Mouvements
where article=MOISARTICLE
and stockqte-moisqte != 0

select 'Articles sur stock absents des mouvements'

select article,stockqte,stockval
from #Stock
where not exists(select * from #Mouvements where #Stock.article=MOISARTICLE)
and stockqte != 0

select 'Articles sur mouvements absents du stock'

select MOISARTICLE,moisqte,moisvaleur
from #Mouvements
where not exists(select * from #Stock where article=#Mouvements.MOISARTICLE)
and moisqte != 0

drop table #Entree
drop table #Stock
drop table #Mouvements
drop table #Mouv

end



go

