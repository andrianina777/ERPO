/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_DroitCmdSolde

*/

CREATE PROCEDURE bp_DroitCmdSolde
with recompile
AS
begin

	 declare @critaire varchar(100),
	 		 @count int
	 select @critaire ='and CCSTADE_DET<>6 and CCSATISFAITE<>2'
 	 select @count=count(*) from EquaPRO..KGroupes_Membres where upper(KGMGPEID) in (upper('OPH_PC')) and KGMUSRID=suser_name()
 	 select @count,@critaire		  
end
go

