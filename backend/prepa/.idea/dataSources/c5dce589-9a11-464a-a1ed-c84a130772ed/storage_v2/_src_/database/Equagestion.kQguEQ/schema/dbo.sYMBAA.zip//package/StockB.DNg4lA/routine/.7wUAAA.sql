


/* Procedure permettant de comparer le stock resultant des mouvements (avec Stock fige)
au fichier FSTOCK pour un article */

create procedure StockB (@Article	char(15))
with recompile
as
begin

set nocount on

declare @reconst	int,
		@base		int,
		@mouv		int,
		@an			smallint


create table #Stock
(
Type		char(14)	null,
Article		char(15)		null,
Qte			int			null
)

select @an=datepart(yy,getdate())-1

/* Valeur du stock fige l''annee precedente */

insert into #Stock
select 'INI',MOISARTICLE,MOISQTE
from FMOIS
where MOISARTICLE=@Article
and MOISANNEE=@an
and MOISMOIS=12


if @@rowcount=0
	begin
		select "Le stock de l'annee precedente n'a pas ete enregistre ou bien l'article n'a pas ete trouve"
		set nocount off
		return(0)
	end


/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stock
select 'SIL',SILARTICLE,sum(SILQTE)
from FSIL
where SILARTICLE=@Article
and datepart(yy,SILDATE)=datepart(yy,getdate())
group by SILARTICLE


/* ''Reajustements - Fichier RJL'' */

insert into #Stock
select 'RJL',RJLARTICLE,sum(RJLQTE)
from FRJL
where RJLARTICLE=@Article
and datepart(yy,RJLDATE)=datepart(yy,getdate())
group by RJLARTICLE


/* ''Lignes de casse - Fichier LCL'' */

insert into #Stock
select 'LCL',LCLARTICLE,sum(LCLQTE)
from FLCL
where LCLARTICLE=@Article
and datepart(yy,LCLDATE)=datepart(yy,getdate())
group by LCLARTICLE


/* ''Assemblage Desassemblage - Fichier ASL'' */

insert into #Stock
select 'ASL',ASLARTICLE,sum(ASLQTE)
from FASL
where ASLARTICLE=@Article
and datepart(yy,ASLDATE)=datepart(yy,getdate())
group by ASLARTICLE


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stock
select 'BLL',BLLAR,sum(BLLQTE)
from FBLL
where BLLAR=@Article
and datepart(yy,BLLDATE)=datepart(yy,getdate())
group by BLLAR


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stock
select 'DOL',DOLAR,sum(DOLQTE)
from FDOL
where DOLAR=@Article
and datepart(yy,DOLDATE)=datepart(yy,getdate())
group by DOLAR


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stock
select 'RFL',RFLARTICLE,-sum(RFLQTE)
from FRFL
where RFLARTICLE=@Article
and datepart(yy,RFLDATE)=datepart(yy,getdate())
group by RFLARTICLE


/* ""Lignes de FA - Fichier FFAL"" */

insert into #Stock
select 'FAL',FALARTICLE,-sum(FALQTE)
from FFAL
where FALARTICLE=@Article
and datepart(yy,FALDATE)=datepart(yy,getdate())
and isnull(FALLETTRE,'')!=''
group by FALARTICLE


/* ""Lignes de RM - Fichier FRM"" */

insert into #Stock
select 'RM',RMARTICLE,sum(RMQTE)
from FRM
where RMARTICLE=@Article
and datepart(yy,RMDATE)=datepart(yy,getdate())
group by RMARTICLE


/* ""Lignes de BE en cours - Fichier FRBE-FBEL"" */

insert into #Stock
select 'BEL',RBEARTICLE,-sum(RBEQTE*sign(BELQTE))
from FRBE,FBEL
where RBESEQ=BELSEQ
and RBEARTICLE=@Article
group by RBEARTICLE


select Type,Article,Qte
from #Stock
where Type in('INI','SIL','RJL','LCL','ASL','BLL','DOL','RFL','FAL','RM')

select "Articles livres restant a facturer"

select Type,Article,Qte
from #Stock
where Type in('BEL')

select ""

select @reconst=sum(Qte)
from #Stock
where Type in('INI','SIL','RJL','LCL','ASL','BLL','DOL','RFL','FAL','RM','BEL')


select @base=isnull(sum(STQTE),0)
from FSTOCK
where STAR=@Article


select Reconstitution='STOCK reconst.',Article,Qte=sum(Qte)
from #Stock
where Type in('INI','SIL','RJL','LCL','ASL','BLL','DOL','RFL','FAL','RM','BEL')
group by Article

/* ''Stock en cours - Fichier FSTOCK'' */
select ""

select FSTOCK='STOCK resultant Societe',@Article,@base

select ""

if (@reconst != @base)
select Difference="stock resultant - Stock reconstitue avec base initiale =",Quantite=isnull(@base,0)-isnull(@reconst,0)
else
select "Pas de differences en reconstitution de stock resultant - avec base initiale"

select ""

set nocount off

end



go

