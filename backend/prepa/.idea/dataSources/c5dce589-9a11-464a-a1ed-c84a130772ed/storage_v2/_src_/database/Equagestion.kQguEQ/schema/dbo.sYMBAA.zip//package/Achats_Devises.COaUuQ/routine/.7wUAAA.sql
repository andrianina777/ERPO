


create procedure Achats_Devises (@date1		smalldatetime,
								 @date2		smalldatetime,
								 @dev		char(3) = null
							    )
with recompile
as
begin

  set arithabort numeric_truncation off
  
  select Chef_Prod=ARCHEFP,Marque=ARFO,Famille=ARFAM,Article=ARCODE,Fournisseur=BLLFO,Achats_en_Euros=sum(BLLPAHT/CVLOT*BLLQTE), Achats_en_devises=sum(BLLPADEV/CVLOT*BLLQTE),
  Cours_moyen_Achats_en_devises=convert(numeric(20,4),sum(BLLPADEV/CVLOT*BLLQTE)/sum(BLLPAHT/CVLOT*BLLQTE)),Stock_actuel_PR_Monnaie_Ref=0,Stock_au_prix_Achat=0
  into #Finale
  from FBLL,FAR,FCV
  where (@dev is null or BLLDEV = @dev)
  and BLLDATE between @date1 and @date2
  and ARCODE=BLLAR
  and ARUNITACHAT=CVUNIF
  and BLLPAHT != 0
  and BLLQTE != 0
  group by ARCHEFP,ARFO,ARFAM,ARCODE,BLLFO
  having sum(BLLPADEV) != 0
  
  union
  
  select ARCHEFP,ARFO,ARFAM,ARCODE,STFO,0,0,0,sum((STPAHT+STFRAIS)/CVLOT*STQTE),sum(STPAHT/CVLOT*STQTE)
  from FSTOCK,FAR,FCV
  where ARCODE=STAR
  and ARUNITACHAT=CVUNIF
  and STQTE != 0
  and (@dev is null or STDEVISE = @dev)
  group by ARCHEFP,ARFO,ARFAM,ARCODE,STFO
  
  
  select Chef_Prod=Chef_Prod,Marque=Marque,Famille=Famille,Article=Article,Fournisseur=Fournisseur,Achats_en_Euros=sum(Achats_en_Euros),Achats_en_devises=sum(Achats_en_devises),
  Cours_moyen_Achats_en_devises=sum(Cours_moyen_Achats_en_devises),Stock_actuel_PR_Monnaie_Ref=sum(Stock_actuel_PR_Monnaie_Ref),
  Stock_au_prix_Achat=sum(Stock_au_prix_Achat)
  into #Finale2
  from #Finale
  group by Chef_Prod,Marque,Famille,Article,Fournisseur
  
  create index code on #Finale2 (Chef_Prod,Marque,Famille,Article,Fournisseur)
  
  
  select Chef=ARCHEFP,Mark=ARFO,Fam=ARFAM,Art=ARCODE,Four=STFO,Cours=convert(numeric(20,4),sum(STPADEV/CVLOT*STQTE)/sum(STPAHT/CVLOT*STQTE))
  into #Cours
  from FSTOCK,FAR,FCV
  where ARCODE=STAR
  and CVUNIF=ARUNITACHAT
  and STQTE != 0
  and (@dev is null or STDEVISE = @dev)
  and STPAHT != 0
  group by ARCHEFP,ARFO,ARFAM,ARCODE,STFO
  having sum(STPADEV) != 0
  and sum(STPAHT/CVLOT*STQTE) != 0
  
  create index code on #Cours (Chef,Mark,Fam,Art,Four)
  
  
  select Chef_Prod=Chef_Prod,Marque=Marque,Famille=Famille,Article=Article,Fournisseur=Fournisseur,Achats_en_Euros=Achats_en_Euros,Achats_en_devises=Achats_en_devises,
  Cours_moyen_Achats_en_devises=Cours_moyen_Achats_en_devises,Stock_actuel_PR_Monnaie_Ref=Stock_actuel_PR_Monnaie_Ref,
  Stock_au_prix_Achat=Stock_au_prix_Achat,Cours_moyen_devise_Stock=Cours
  from #Finale2,#Cours
  where Chef_Prod=Chef
  and Marque=Mark
  and Famille=Fam
  and Article=Art
  and Fournisseur=Four

  
  drop table #Finale
  drop table #Finale2
  drop table #Cours

end



go

