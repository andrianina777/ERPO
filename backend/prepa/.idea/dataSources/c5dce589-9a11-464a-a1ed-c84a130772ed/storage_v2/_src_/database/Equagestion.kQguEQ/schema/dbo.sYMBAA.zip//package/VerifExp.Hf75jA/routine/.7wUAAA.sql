

/*
Verification des quantites a expedier.
Procedure utilisee par le module "Reservations et Expeditions"
		Cette procedure utilise la table FVerifExp 					
*/

create procedure VerifExp  (@ent				char(5) = null,
							@process			int,
							@SeuilCompletion	numeric(12,2) = 0,
							@SeuilMargin		numeric(12,2) = 0,
							@SeuilQteFranco 	int = 0
					)
with recompile
as
begin

set arithabort numeric_truncation off


declare @count	int,
		@site	int
		
declare @client		char(12),
		@commande	char(10),
		@nom		varchar(35),
		@adr1		varchar(50),
		@cp			varchar(12),
		@ville		varchar(30),
		@py			char(8),
		@pays		varchar(30),
		@dateagr	smalldatetime,
		@categagr	varchar(15),
		@arproduit	varchar(12),
		@article	char(15)
		
select @site=KISITE from KInfos

declare @multient	tinyint
select  @multient=KIMULTIENTITE from KInfos


create table #Final
(
seq			numeric(14,0)	identity,
code		char(15)		not null,
qtePrep		int				not null,
comment		varchar(70)		not null,
qteSt		int				not null,
gravite		tinyint			not null
)


/*--------- Verification du stock disponible    ----------*/


create table #Stock
(
artSt		char(15)	not null,
qteSt		int			not null
)

create table #Prep
(
artPrep		char(15)	not null,
qtePrep		int			not null,
qteRes		int			not null,
qteDejaPrep	int			not null,
qteResTotal	int			not null
)

insert into #Stock (artSt,qteSt)
select ARTICLE,STOCK
from FVerifExp, FAR
where ARCODE=ARTICLE
and ARTYPE=0
and SPID=@process
group by ARTICLE,STOCK


insert into #Prep (artPrep,qtePrep,qteRes,qteDejaPrep,qteResTotal)
select ARTICLE,isnull(sum(QTEPREP),0),isnull(sum(QTERES),0),isnull(sum(QTEDEJAPREP),0),isnull(QTERESTOTAL,0)
from FVerifExp, FAR
where ARCODE=ARTICLE
and ARTYPE=0
and SPID=@process
group by ARTICLE,QTERESTOTAL



select @count=count(*) from #Prep,#Stock
where artPrep=artSt
and qteSt - (qteResTotal - qteRes) < qtePrep  - qteDejaPrep


if @count>0
  begin
  	insert into #Final (code,qtePrep,comment,qteSt,gravite)
	select artPrep,qtePrep,"Prep. Exp.  -> Stock disponible insuffisant",qteSt - (qteResTotal - qteRes),2 			/* erreur bloquante */
		from #Prep,#Stock
		where artPrep=artSt
		and qteSt - (qteResTotal - qteRes) < qtePrep - qteDejaPrep
		order by artPrep
		
	insert into #Final (code,qtePrep,comment,qteSt,gravite)
	select "--------",0,"----------------------------------------",0,0
	
  end
  
/*--------- Verification du stock physique    ----------*/


select @count=count(*) from #Prep,#Stock
where artPrep=artSt
and qteSt < qtePrep


if @count>0
  begin
  	insert into #Final (code,qtePrep,comment,qteSt,gravite)
	select artPrep,qtePrep,"Prep. Exp.  -> Stock total insuffisant",qteSt,2 			/* erreur bloquante */
		from #Prep,#Stock
		where artPrep=artSt
		and qteSt < qtePrep
		order by artPrep
		
	insert into #Final (code,qtePrep,comment,qteSt,gravite)
	select "--------",0,"----------------------------------------",0,0
	
  end




select @count=count(*) from #Prep
where qtePrep=0

if @count>0
  begin
	insert into #Final (code,qtePrep,comment,qteSt,gravite)
	select artPrep,qtePrep,"Prep. Exp.  -> Quantite Prep a 0",0,2 				/* erreur bloquante */
		from #Prep
		where qtePrep=0
		order by artPrep
		
	 
insert into #Final (code,qtePrep,comment,qteSt,gravite)
	select "--------",0,"----------------------------------------",0,0

  end

/*--------- Verification des adresses ----------*/

select @count=0

declare clients cursor 
for select CLIENT,COMMANDE,NOM,ADR1,CP,VILLE,PY,PAYS
from FVerifExp
where SPID=@process
order by CLIENT,COMMANDE
for read only

open clients

fetch clients into @client,@commande,@nom,@adr1,@cp,@ville,@py,@pays

while (@@sqlstatus = 0)
  begin
				
	if isnull(@nom,'') = '' or isnull(@adr1,'') = '' or isnull(@cp,'') = ''
		or isnull(@ville,'') = '' or isnull(@py,'') = '' or  isnull(@pays,'') = ''
	  begin
		insert into #Final (code,qtePrep,comment,qteSt,gravite)
		select @client,0,"Prep. Exp.  -> Adresse client incomplete sur commande -> "+@commande,0,2 /* erreur bloquante */
	  end
				
	fetch clients into @client,@commande,@nom,@adr1,@cp,@ville,@py,@pays
	
  end

close  
clients
deallocate cursor clients

/*--------- Verification de la completion/marge/franco adresses -----------*/
/*
if @site=6
begin

/* completion */
insert into #Final
	select distinct COMMANDE,0,"Prep. Exp.  -> Taux de completion de "+convert(varchar(12),COMPLETION)+" inferieur a "+convert(varchar(12),@SeuilCompletion)+'%',0,1 /* erreur grave */
	from FVerifExp
	where COMPLETION<=@SeuilCompletion

/* Marge */
insert into #Final
	select distinct COMMANDE,0,"Taux de marge de "+convert(varchar(12),MARGIN)+" sur article "+ARTICLE+" inferieur a "+convert(varchar(12),@SeuilMargin)+'%',0,0 /* avertissement*/
	from FVerifExp
	where MARGIN<=@SeuilMargin and TOTALHT>0

/* franco */
select CLIENT,ADR1,ADR2,CP,VILLE,PY,PAYS,QTEPREP=sum(QTEPREP)
into #franco
from FVerifExp
group by CLIENT,ADR1,ADR2,CP,VILLE,PY,PAYS
having sum(QTEPREP)<@SeuilQteFranco

insert into #Final
	select CLIENT,QTEPREP,"Prep. Exp.  -> Expedition de "+convert(varchar(10),QTEPREP)+" Pieces franco client -> "+CLIENT,0,1 /* erreur grave */
	from #franco where not exists
	(select * from FVerifExp where 	FVerifExp.CLIENT=#franco.CLIENT and 
							FVerifExp.ADR1=#franco.ADR1 and
							FVerifExp.ADR2=#franco.ADR2 and
							FVerifExp.CP=#franco.CP and
							FVerifExp.VILLE=#franco.VILLE and
							FVerifExp.PY=#franco.PY and
							FVerifExp.PAYS=#franco.PAYS and 
							FVerifExp.FRANCO=0)

end
*/
/*---------- Bloquage Commandes ------------------*/

insert into #Final
	select distinct COMMANDE,0,"Prep. Exp.  -> Commande Bloquee a l'expedition",0,2 /* erreur bloquante */
	from FVerifExp,FCC
	where COMMANDE=CCCODE and isnull(CCBEBLOQUE,0)=1
	and (@multient = 0 or isnull(CCENT,'')=isnull(@ent,''))


/*--------- Verification des agrements ----------*/

select @count=0

declare agrements cursor 
for select CLIENT,COMMANDE,ARTICLE,isnull(CLDATEAGR,""),isnull(CLCATEGAGR,""),isnull(ARPRODUIT,"")
from FVerifExp,FCL,FAR
where SPID=@process
and CLCODE=CLIENT
and ARCODE=ARTICLE
and ARREGLE>0
and (@multient = 0 or isnull(CLENT,'')=isnull(@ent,''))
order by CLIENT,ARTICLE
for read only

open agrements

fetch agrements into @client,@commande,@article,@dateagr,@categagr,@arproduit

while (@@sqlstatus = 0)
  begin
				
	if charindex(@arproduit,@categagr) = 0
	  begin
		insert into #Final (code,qtePrep,comment,qteSt,gravite)
		select @client,0,"Prep. Exp.  -> Le client n'a pas d'agrement pour ce produit -> "+@article+" "+@commande,0,2 /* erreur bloquante */
	  end
	  
	if @dateagr < getdate()
	  begin
		insert into #Final (code,qtePrep,comment,qteSt,gravite)
		select @client,0,"Prep. Exp.  -> La date d'agrement est depassee -> "+convert(varchar,@dateagr)+" "+@commande,0,2 /* erreur bloquante */
	  end
				
	fetch agrements into @client,@commande,@article,@dateagr,@categagr,@arproduit
	
  end

close agrements
deallocate cursor agrements




/* Renvoi final */

select code,qtePrep,comment,qteSt,gravite
from #Final
order by seq


drop table #Final
drop table #Stock
drop table #Prep
drop table #franco

end
go

