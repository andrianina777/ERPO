


create procedure CA_DEP		(@ent		char(5)	= null,
							 @date1 	datetime,
							 @date2 	datetime,
							 @depart	char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date_1 datetime,
		@date_2 datetime

select @date_1=convert(datetime,convert(varchar(2),datepart(mm,@date1))+"/"
								+convert(varchar(2),datepart(dd,@date1))+"/"
								+convert(varchar(4),datepart(yy,@date1)-1))
select @date_2=convert(datetime,convert(varchar(2),datepart(mm,@date2))+"/"
								+convert(varchar(2),datepart(dd,@date2))+"/"
								+convert(varchar(4),datepart(yy,@date2)-1))

create table #Lignes
(
depart		char(8)		not null,
ventes_1	numeric(14,2)	null,
ventes		numeric(14,2)	null
)

insert into #Lignes (depart,ventes_1)
select ARDEPART,sum(FALTOTALHT)
from FFAL(4),FAR
where ARCODE=FALARTICLE
and (@depart is null or ARDEPART=@depart)
and FALDATE between @date_1 and @date_2
and (@ent is null or FALENT=@ent)
group by ARDEPART


insert into #Lignes (depart,ventes)
select ARDEPART,sum(FALTOTALHT)
from FFAL(4),FAR
where ARCODE=FALARTICLE
and (@depart is null or ARDEPART=@depart)
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by ARDEPART


select "Departement","Ventes N-1","Ventes"
select depart,isnull(sum(ventes_1),0),isnull(sum(ventes),0)
from #Lignes
group by depart
order by depart

drop table #Lignes

end



go

