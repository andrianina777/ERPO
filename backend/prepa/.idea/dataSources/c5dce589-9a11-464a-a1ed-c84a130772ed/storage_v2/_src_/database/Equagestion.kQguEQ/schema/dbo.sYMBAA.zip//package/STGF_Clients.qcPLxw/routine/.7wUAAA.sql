


create procedure STGF_Clients  (@ent		char(5) = null,
								@client		char(12),
								@An 		smallint,
							 	@depart		tinyint = null,
							 	@grfam		tinyint = null,
							 	@marque		tinyint = null,
							 	@famille	tinyint = null,
								@article	tinyint = null,
								@srfa		tinyint = null,
								@chef		tinyint = null
								)
with recompile
as
begin

set arithabort numeric_truncation off


if (@depart is null) and (@grfam is null) and (@marque is null)
	and (@famille is null) and (@article is null) and (@chef is null)
select @grfam = 1

create table #Finale
(
CODE	char(15)		not null,
LIB		varchar(80)		null,
QteFAN2	int				null,
CAFAN2	numeric(14,2)	null,
QteFAN1	int				null,
CAFAN1	numeric(14,2)	null,
QteFAN0	int				null,
CAFAN0	numeric(14,2)	null,
QteCCN0	int				null,
CACCN0	numeric(14,2)	null,
DEPART	char(8)			null,
CATEG	char(8)			null,
MARQUE	char(12)		null,
FAM		char(8)			null,
CHEF	char(8)			null
)


set forceplan on

if isnull(@depart,0) > 0
begin
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARDEPART,''),isnull(DTLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,isnull(ARDEPART,''),'','','',''
  from FST(index client),FAR,FDT
  where ARCODE=START
  and DTCODE=ARDEPART
  and (@srfa=0 or ARTYPE != 6)
  and STCL=@client
  and STAN >= @An-2
  and (@ent is null or STENT=@ent)
  group by ARDEPART,DTLIB
  
  union
  
  select isnull(ARDEPART,''),isnull(DTLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 isnull(ARDEPART,''),'','','',''
  from FRCC,FCCL,FAR,FDT,FCC
  where ARCODE=RCCARTICLE
  and DTCODE=ARDEPART
  and RCCCL=@client
  and RCCAN >= @An-2
  and CCLSEQ=RCCSEQ
  and CCCODE=CCLCODE
  and isnull(CCVALIDE,0)=0
  and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
  group by ARDEPART,DTLIB

end
else if isnull(@grfam,0) > 0
begin
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARGRFAM,''),isnull(GFNOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'',isnull(ARGRFAM,''),'','',''
  from FST(index client),FAR,FGF
  where ARCODE=START
  and GFCODE=ARGRFAM
  and (@srfa=0 or ARTYPE != 6)
  and STCL=@client
  and STAN >= @An-2
  and (@ent is null or STENT=@ent)
  group by ARGRFAM,GFNOM
  
  union
  
  select isnull(ARGRFAM,''),isnull(GFNOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '',isnull(ARGRFAM,''),'','',''
  from FRCC,FCCL,FAR,FGF,FCC
  where ARCODE=RCCARTICLE
  and GFCODE=ARGRFAM
  and RCCCL=@client
  and RCCAN >= @An-2
  and CCLSEQ=RCCSEQ
  and CCCODE=CCLCODE
  and isnull(CCVALIDE,0)=0
  and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
  group by ARGRFAM,GFNOM
  

end
else if isnull(@marque,0) > 0
begin

  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARFO,''),isnull(FONOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','',isnull(ARFO,''),'',''
  from FST(index client),FAR,FFO
  where ARCODE=START
  and FOCODE=ARFO
  and (@srfa=0 or ARTYPE != 6)
  and STCL=@client
  and STAN >= @An-2
  and (@ent is null or STENT=@ent)
  group by ARFO,FONOM
  
  union
  
  select isnull(ARFO,''),isnull(FONOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','',isnull(ARFO,''),'',''
  from FRCC,FCCL,FAR,FFO,FCC
  where ARCODE=RCCARTICLE
  and FOCODE=ARFO
  and RCCCL=@client
  and RCCAN >= @An-2
  and CCLSEQ=RCCSEQ
  and CCCODE=CCLCODE
  and isnull(CCVALIDE,0)=0
  and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
  group by ARFO,FONOM

end
else if isnull(@famille,0) > 0
begin

  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARFAM,''),isnull(FPLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','',isnull(ARFAM,''),''
  from FST(index client),FAR,FFP
  where ARCODE=START
  and FPCODE=ARFAM
  and (@srfa=0 or ARTYPE != 6)
  and STCL=@client
  and STAN >= @An-2
  and (@ent is null or STENT=@ent)
  group by ARFAM,FPLIB
  
  union
  
  select isnull(ARFAM,''),isnull(FPLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 '','','',isnull(ARFAM,''),''
  from FRCC,FCCL,FAR,FFP,FCC
  where ARCODE=RCCARTICLE
  and FPCODE=ARFAM
  and RCCCL=@client
  and RCCAN >= @An-2
  and CCLSEQ=RCCSEQ
  and CCCODE=CCLCODE
  and isnull(CCVALIDE,0)=0
  and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
  group by ARFAM,FPLIB

end
else if isnull(@article,0) > 0
begin

  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARCODE,''),isnull(ARLIB,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,isnull(ARDEPART,''),isnull(ARGRFAM,''),isnull(ARFO,''),
		 isnull(ARFAM,''),isnull(ARCHEFP,'')
  from FST(index client),FAR
  where ARCODE=START
  and (@srfa=0 or ARTYPE != 6)
  and STCL=@client
  and STAN >= @An-2
  and (@ent is null or STENT=@ent)
  group by ARDEPART,ARGRFAM,ARFO,ARFAM,ARCODE,ARLIB,ARCHEFP
  
  union
  
  select isnull(ARCODE,''),isnull(ARLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 isnull(ARDEPART,''),isnull(ARGRFAM,''),isnull(ARFO,''),
		 isnull(ARFAM,''),isnull(ARCHEFP,'')
  from FRCC,FCCL,FAR,FCC
  where ARCODE=RCCARTICLE
  and RCCCL=@client
  and RCCAN >= @An-2
  and CCLSEQ=RCCSEQ
  and CCCODE=CCLCODE
  and isnull(CCVALIDE,0)=0
  and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
  group by ARDEPART,ARGRFAM,ARFO,ARFAM,ARCODE,ARLIB,ARCHEFP

end
else if isnull(@chef,0) > 0
begin
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARCHEFP,''),isnull(CHNOM,''),
		 isnull(sum(case when STAN=@An-2 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-2 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An-1 then STCAFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STQTEFA else 0 end),0),
		 isnull(sum(case when STAN=@An then STCAFA else 0 end),0),
		 0,0,'','','','',isnull(ARCHEFP,'')
  from FST(index client),FAR,FCH
  where ARCODE=START
  and CHCODE=ARCHEFP
  and (@srfa=0 or ARTYPE != 6)
  and STCL=@client
  and STAN >= @An-2
  and (@ent is null or STENT=@ent)
  group by ARCHEFP,CHNOM
  
  union
  
  select isnull(ARCHEFP,''),isnull(CHNOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCCQTE),0),
		 isnull(round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2),0),
		 isnull(ARCHEFP,''),'','','',''
  from FRCC,FCCL,FAR,FCH,FCC
  where ARCODE=RCCARTICLE
  and CHCODE=ARCHEFP
  and RCCCL=@client
  and RCCAN >= @An-2
  and CCLSEQ=RCCSEQ
  and CCCODE=CCLCODE
  and isnull(CCVALIDE,0)=0
  and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CCENT=@ent))
  group by ARCHEFP,CHNOM

end


set forceplan off


select CODE,LIB,sum(QteFAN2),sum(CAFAN2),sum(QteFAN1),sum(CAFAN1),sum(QteFAN0),sum(CAFAN0),
  						sum(QteCCN0),sum(CACCN0),DEPART,CATEG,MARQUE,FAM,CHEF
from #Finale
group by CODE,LIB,DEPART,CATEG,MARQUE,FAM,CHEF
order by LIB


drop table #Finale

	
end



go

