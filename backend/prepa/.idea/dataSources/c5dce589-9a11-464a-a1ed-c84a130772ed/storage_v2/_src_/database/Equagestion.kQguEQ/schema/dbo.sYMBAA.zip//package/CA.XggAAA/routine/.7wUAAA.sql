


create procedure CA (@ent	char(5)	= null,
					 @date1 smalldatetime,
					 @date2 smalldatetime)
with recompile
as
begin
	
	set arithabort numeric_truncation off

	set nocount on
	
	declare @TotalFactures	numeric(14,2)
	declare @TotalBE		numeric(14,2)
	
	select @TotalFactures=sum(FATOTALHT)
	from FFA
	where FADATE between @date1 and @date2
	and (@ent is null or FAENT=@ent)
	
	select @TotalBE=sum(BELTOTALHT)
	from FRBE,FBEL
	where RBESEQ=BELSEQ
	and RBEDEMO=0
	and RBEDATE between @date1 and @date2
	and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))
	
	select TotalFactures=isnull(@TotalFactures,0)
	
	select TotalExpeditions=isnull(@TotalBE,0)
	
	select Total_General=isnull(@TotalFactures,0)+isnull(@TotalBE,0)
	
end



go

