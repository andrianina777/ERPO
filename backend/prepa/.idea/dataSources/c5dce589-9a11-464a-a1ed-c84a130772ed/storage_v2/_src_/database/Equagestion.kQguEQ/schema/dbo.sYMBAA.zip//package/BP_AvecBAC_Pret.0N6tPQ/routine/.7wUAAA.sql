/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.BP_AvecBAC_Pret
grant execute on BP_AvecBAC_Pret to public
*/

CREATE PROCEDURE dbo.BP_AvecBAC_Pret
@bpcode VARCHAR(10) 
AS
BEGIN

create table #BP_PRE(
	bpcode char(10) null
)
 
 insert into  #BP_PRE select BPCODE from FBP inner join FCC on BPCC=CCCODE where   BPPREPSPECIF=0 and BPDATE>='2018/01/01'   AND CCSATISFAITE=0 AND CCPREPSPECIF=0
            
select distinct CCBACLNUMCC,CCBACLBP,CCBACLNUMBAC
from h_CCBACL,h_ImpRayon,#BP_PRE
where CCBACLBP=@bpcode
and CCBACLBP=bpcode
and IRRAYON=CCBACRAYON
and IRREGROUPEMENT<>0 
and isnull(CCBACLNUMBAC,'')<>'' order by CCBACLBP

drop table #BP_PRE
       
END
go

