/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE bp_VALEUR_ECH
grant execute on bp_AlertDureeVie to public
*/

CREATE PROCEDURE dbo.bp_VALEUR_ECH
with recompile
AS
begin
	create table #MAJ_LOT(
		VALEUR numeric(18,3),
		DATE datetime
	)
 	
 
 	insert into #MAJ_LOT select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2018-01-01' and SILDEPOT='ECH' and SIL_MOTIF not in ('PERC','AMM')
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) as VALEUR from #MAJ_LOT where MONTH(DATE)<7 group by YEAR(DATE),MONTH(DATE)
end
go

