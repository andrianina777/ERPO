/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_MailAuto_ClCa_bas20_Bis
grant execute on bp_MailAuto_ClCa_bas20_Bis to public
*/

CREATE PROCEDURE dbo.bp_MailAuto_ClCa_bas20_Bis(@com varchar(50),@jour smalldatetime)

AS
begin
        declare @date_40 smalldatetime,@date_30 smalldatetime,@date_10 smalldatetime
      
        if (@jour=null)
        begin
                select @jour=current_date()
        end
        
        select @date_40=dateadd(dd,-40,@jour)
        select @date_30=dateadd(dd,-30,@jour)
        select @date_10=dateadd(dd,-10,@jour)
        
        select CLIENT,NOM_FICHE,COM,convert(date,DATE) as DATE,VILLE,rtrim(CLSA) as TYPE_CLIENT,sum(TOTALHT)as CA
        into #CA
        from VIEW_LIGNE_FACT
        where DATE>=@date_40 and (@com=null or @com='' or COM=@com)
        group by CLIENT,NOM_FICHE,DATE,CLSA,COM,VILLE
        
        create index ca_idx0001 on #CA(DATE)
        create index ca_idx0002 on #CA(CLIENT)
        create index ca_idx0003 on #CA(COM)
        
        
      /*  select CLIENT,NOM_FICHE,COM,"CA_40"=sum(case when (DATE>=@date_40) then CA else 0 end ),"MOYENNE_J_40"=convert(numeric(14,2),sum(case when (DATE>=@date_40) then CA else 0 end )/40),
        "CA_30"=sum(case when (DATE>=@date_30) then CA else 0 end ),"MOYENNE_J_30"=convert(numeric(14,2),sum(case when (DATE>=@date_30) then CA else 0 end )/30),
        "CA_10"=sum(case when (DATE>=@date_10) then CA else 0 end ),"MOYENNE_J_10"=convert(numeric(14,2),sum(case when (DATE>=@date_10) then CA else 0 end )/10)
        into #MOYENNE
        from #CA
        group by CLIENT,NOM_FICHE,COM
        */
 
       /*  select CLIENT, NOM_FICHE, COM, CA_40, MOYENNE_J_40, 
         CA_30, MOYENNE_J_30, convert(numeric(14,2),((MOYENNE_J_30-MOYENNE_J_40)/MOYENNE_J_40)*100) as EVOL_40_30,
         CA_10, MOYENNE_J_10 ,
         convert(numeric(14,2),((MOYENNE_J_10-MOYENNE_J_30)/MOYENNE_J_30)*100) as EVOL_30_10
         from #MOYENNE
*/

        select CLIENT,NOM_FICHE,COM,TYPE_CLIENT,VILLE,
        "CA_30"=sum(case when (DATE>=@date_30) then CA else 0 end ),
        "CA_30_sur_3"=convert(numeric(14,2),sum(case when (DATE>=@date_30) then CA else 0 end )/3),
        "CA_10"=sum(case when (DATE>=@date_10) then CA else 0 end )
        into #MOYENNE
        from #CA
        group by CLIENT,NOM_FICHE,COM,TYPE_CLIENT,VILLE
        
        select CLIENT, NOM_FICHE, COM,TYPE_CLIENT,VILLE, CA_30, CA_30_sur_3, CA_10 ,case when (CA_30_sur_3>0) then convert(numeric(14,2),((CA_10-CA_30_sur_3)/CA_30_sur_3)*100) else 0 end  as EVOL
        from #MOYENNE
        where case when (CA_30_sur_3>0) then convert(numeric(14,2),((CA_10-CA_30_sur_3)/CA_30_sur_3)*100) else 0 end<=-20
         
         
        drop table #CA
        drop table #MOYENNE

      
end
go

