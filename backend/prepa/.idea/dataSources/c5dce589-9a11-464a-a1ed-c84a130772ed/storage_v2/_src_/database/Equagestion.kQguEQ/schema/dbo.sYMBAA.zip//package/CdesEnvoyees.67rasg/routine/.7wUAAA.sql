




/* Procedure donnant la liste des commandes clients non expediees et non facturees
appartenant a des commandes au stade """"envoyee"""" pouvant etre facturees en automatique */


create procedure CdesEnvoyees	(@ent			char(5) 		= null,
								 @datedeb 		smalldatetime 	= null,
								 @datefin 		smalldatetime 	= null,
								 @clientdeb		char(12)		= null,
								 @clientfin		char(12)		= null,
								 @periode		tinyint			= null,
								 @toutescdes	tinyint			= 0
								)
with recompile
as
begin
	set arithabort numeric_truncation off

	create table #ccl
	(
	Code	char(10)		not null,
	Client	char(12)		not null,
	Date	smalldatetime	not null,
	Ecart	tinyint				null,
	Date_6	smalldatetime		null
	)

	declare @saisondeb	char(5),
			@saisonfin	char(5),
			@datesaisondeb	datetime,
			@datesaisonfin	datetime
		
	select @saisondeb=PSAISONDEB,@saisonfin=PSAISONFIN from KParam
	where (@ent is null or PENT=@ent)

	set dateformat dmy
	select @datesaisondeb=convert(datetime,@saisondeb+"/"+convert(varchar(4),datepart(yy,getdate())))
	select @datesaisonfin=convert(datetime,@saisonfin+"/"+convert(varchar(4),datepart(yy,getdate())))
	set dateformat mdy

	insert into #ccl (Code,Client,Date,Ecart,Date_6)
	select CCCODE,CCCLIENT,CCDATECOM,0,CCDATE_6
	from FCCL, FRCC, FCC,FCL
	where RCCSEQ=CCLSEQ
	and CCCODE = CCLCODE
	and CLCODE = CCCLIENT
	and isnull(RCCFACTMAN,0) = 0
	and isnull(RCCQTEPREP,0) = 0
	and CCSATISFAITE = 0
	and CCVALIDE = 0
	and CCBEBLOQUE = 0
	and CCSTADE_DET = 6
	and ((RCCECH=0) or (RCCECH=2) or (RCCECH=1 and RCCDATE < @datesaisondeb) or (RCCECH=1 and RCCDATE > @datesaisonfin))
	and (@ent is null or (CCLENT=@ent and RCCENT=@ent))
	and (@datedeb is null or CCDATECOM between @datedeb and @datefin)
	and (@clientdeb is null or RCCCL between @clientdeb and @clientfin)
	and (@periode is null or CLFACTPERIODE = @periode)
	group by CCCODE,CCCLIENT
	
	if @toutescdes = 0
	begin
	
	update #ccl
	set Ecart = 1
	where exists (select * from FCC,FCCL,FRCC,FCL where RCCSEQ=CCLSEQ and CCCODE = CCLCODE and CCCLIENT=#ccl.Client
					and isnull(RCCQTEPREP,0) = 0 and CCSATISFAITE = 0 and CLCODE = CCCLIENT
					and ((RCCECH=0) or (RCCECH=2) or (RCCECH=1 and RCCDATE < @datesaisondeb) or (RCCECH=1 and RCCDATE > @datesaisonfin))
					and (@ent is null or (CCLENT=@ent and RCCENT=@ent)) and (@periode is null or CLFACTPERIODE = @periode))
	end
	

	select Code,Client,Date,Ecart,Date_6
	from #ccl
	order by Date_6,Client,Code

	drop table #ccl
end



go

