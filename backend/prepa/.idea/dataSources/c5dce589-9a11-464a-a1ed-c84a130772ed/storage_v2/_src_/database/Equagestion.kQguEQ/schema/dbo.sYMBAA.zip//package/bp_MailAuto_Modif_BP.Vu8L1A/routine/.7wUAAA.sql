/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE bp_MailAuto_Modif_BP
grant execute on bp_MailAuto_Modif_BP to public
*/

CREATE PROCEDURE bp_MailAuto_Modif_BP
with recompile
AS
begin

	SELECT
	pCodeBP as CODE_BP,
	pArticle as ARTICLE,
	ARLIB as LIBELLE,
	pOldEmpl as OLD_EMPL,
	pNewEmpl as NEW_EMPL,
	pOldLot as OLD_LOT,
	pNewLot as NEW_LOT,
	pOldLettre as OLD_LETTRE,
	pNewLettre as NEW_LETTRE,
	pUserCre as Utilisateur,
	pDateCre as DATE_CRE,
	pCommentaire as COMMENTAIRE,
	pQTE as QUANTITE,
	pDepot as DEPOT
FROM
	DBSUIVI.dbo.B_HistoModifBP inner join VIEW_FAR on ARCODE=pArticle
	where isnull(pEtat,0)=0 order by pDateCre

	update DBSUIVI.dbo.B_HistoModifBP set pEtat=1 where isnull(pEtat,0)=0

			
	 	
end
go

