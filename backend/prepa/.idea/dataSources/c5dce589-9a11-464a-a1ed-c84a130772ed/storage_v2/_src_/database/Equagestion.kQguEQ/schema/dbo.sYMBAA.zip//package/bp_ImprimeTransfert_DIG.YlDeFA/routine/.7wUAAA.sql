/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_ImprimeTransfert_DIG
grant execute on bp_ImprimeTransfert_DIG to public
*/



CREATE PROCEDURE dbo.bp_ImprimeTransfert_DIG(@codeTD char(10),@depotOrg char(4),@depotDst char(4))

AS
begin
		
		
		
		create table #td_org(
			o_article char(15),
			o_lot char(12),
			o_depOrg char(4),
			o_empl char(8),
			o_ssemp	varchar(10) null,
			o_col	varchar(5) null,
			o_qte	int 
					
	    )
        
    	
    	
    	create table #td_dst(
    		d_seq int,
			d_article char(15),
			d_lot char(12),
			d_depDest char(4),
			d_empl char(8),
			d_alle	varchar(10) null,
			d_porte	char(5) null,
			d_qte	int 
	    )
        	
       	
       	insert into  #td_org select SILARTICLE,SILLOT,SILDEPOT,SILEMP,ARESSEMP,xALLEL,ABS(SILQTE) from FSIL  left join VIEW_FARE on (AREAR=SILARTICLE and SILEMP=AREEMP and AREDEPOT=SILDEPOT)
       	left join xEMP_DIGUEL on (SILEMP=xEMPL and xDEPOTL=SILDEPOT) left join xCorrespRAYON_DIGUE on (ALLEE=xALLEL and DEPOT=xDEPOTL)
    	where --((ARERECEP=1 and AREPICK=1 and AREDEPOT='DET' ) or (AREDEPOT='GROS')) and 
    	SILCODE=@codeTD and SILDEPOT=@depotOrg and SILQTE<0
    	
        insert into #td_dst select SILSEQ,SILARTICLE,SILLOT,SILDEPOT,SILEMP,xALLEL,isnull(PORTE,''),SILQTE from FSIL left join VIEW_FARE on (AREAR=SILARTICLE and SILEMP=AREEMP and AREDEPOT=SILDEPOT)
       	left join xEMP_DIGUEL on (SILEMP=xEMPL and xDEPOTL=SILDEPOT) left join xCorrespRAYON_DIGUE on (ALLEE=xALLEL and DEPOT=xDEPOTL)
        where SILCODE=@codeTD and SILDEPOT=@depotDst and SILQTE>0
        
       
        
        select distinct d_seq,d_article,ARLIB,ARFO,d_qte,o_depOrg,o_empl,o_col,o_ssemp,d_depDest,d_empl,d_alle,d_porte,d_lot,NLOTDATEPER from #td_dst inner join #td_org
        on (o_article=d_article and o_lot=d_lot and o_qte=d_qte) left join FNLOT on (NLOTAR=d_article and NLOTCODE=d_lot)
        left join VIEW_FAR on d_article=ARCODE
	

    	drop table  #td_org
    	drop table #td_dst
end
go

