


create procedure New_FSTAR	(	@ent		char(5) = null,
								@articleST	char(15),
							 	@an			smallint = null,
							 	@mois		tinyint = null
							)
with recompile
as
begin
	
set arithabort numeric_truncation off

declare @smalldate1		smalldatetime,
		@smalldate2		smalldatetime,
		@date1			datetime,
		@date2			datetime,
		@base			varchar(30),
		@groupe			tinyint

select @base = db_name()

if (@an is null) and (@mois is null)
  begin
	select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),datepart(yy,getdate())-2))
	select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),datepart(yy,getdate())))
	select @date1=convert(datetime,@smalldate1),
		   @date2=convert(datetime,@smalldate2)
  end
else if (@an is not null) and (@mois is null)
  begin
	select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
	select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))
	select @date1=convert(datetime,@smalldate1),
		   @date2=convert(datetime,@smalldate2)
  end
else if (@an is not null) and (@mois is not null)
  begin
  	if @mois=1
	  begin
		  select @smalldate1=convert(smalldatetime,'01/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'01/31/'+convert(varchar(4),@an))
	  end
  	else if @mois=2
	  begin
		  select @smalldate1=convert(smalldatetime,'02/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		  select @smalldate2=dateadd(dd,-1,@smalldate2)
	  end
  	else if @mois=3
	  begin
		  select @smalldate1=convert(smalldatetime,'03/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'03/31/'+convert(varchar(4),@an))
	  end
  	else if @mois=4
	  begin
		  select @smalldate1=convert(smalldatetime,'04/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'04/30/'+convert(varchar(4),@an))
	  end
  	else if @mois=5
	  begin
		  select @smalldate1=convert(smalldatetime,'05/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'05/31/'+convert(varchar(4),@an))
	  end
  	else if @mois=6
	  begin
		  select @smalldate1=convert(smalldatetime,'06/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'06/30/'+convert(varchar(4),@an))
	  end
  	else if @mois=7
	  begin
		  select @smalldate1=convert(smalldatetime,'07/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'07/31/'+convert(varchar(4),@an))
	  end
  	else if @mois=8
	  begin
		  select @smalldate1=convert(smalldatetime,'08/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'08/31/'+convert(varchar(4),@an))
	  end
  	else if @mois=9
	  begin
		  select @smalldate1=convert(smalldatetime,'09/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'09/30/'+convert(varchar(4),@an))
	  end
  	else if @mois=10
	  begin
		  select @smalldate1=convert(smalldatetime,'10/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'10/31/'+convert(varchar(4),@an))
	  end
  	else if @mois=11
	  begin
		  select @smalldate1=convert(smalldatetime,'11/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'11/30/'+convert(varchar(4),@an))
	  end
  	else if @mois=12
	  begin
		  select @smalldate1=convert(smalldatetime,'12/01/'+convert(varchar(4),@an))
		  select @smalldate2=convert(smalldatetime,'12/31/'+convert(varchar(4),@an))
	  end
  
  	select @date1 = convert(datetime,@smalldate1)
  	select @date2 = convert(datetime,@smalldate2)
  end
else 
  return(0)


create table #FST
(
STREP		char(8)			not null,
STGROUPE	char(12)		not null,
STCL		char(12)		not null,
START		char(15)		not null,
STAN		smallint		not null,
STMOIS		tinyint			not null,
STQTEFA		int				not null,
STCAFA		numeric(14,2)	not null,
STPR		numeric(14,2)	not null,
STCARFA		numeric(14,2)	not null,
STRFACT		numeric(14,2)	not null,
STENT		char(5)			not null,
STPRM		numeric(14,4)	not null,
STPUM		numeric(14,4)	not null,
STREPDIV	char(8)			not null,
STDATE		smalldatetime	not null,
CVLOT		int				not null,
LETTRE		char(4)			not null,
STSEQ		numeric(14,0)	identity
)


insert into #FST (STREP,STGROUPE,STCL,START,STAN,STMOIS,STQTEFA,STCAFA,STPR,STCARFA,STRFACT,
				STENT,STPRM,STPUM,STREPDIV,STDATE,CVLOT,LETTRE)
select isnull(FALREP,''),isnull(FALGROUPE,''),FALCL,FALARTICLE,
		datepart(yy,FALDATE),datepart(mm,FALDATE),
		FALQTE,FALTOTALHT,0.00,
		isnull(FALCARFA,0),isnull(FALRFACT,0),FALENT,0,0,isnull(FALREPDIV,''),dateadd(hh,19,FALDATE),CVLOT,FALLETTRE
from FFAL,FAR,FCV
where ARCODE=FALARTICLE
and ARTYPE != 8
and ARUNITACHAT=CVUNIF
and FALDATE between @smalldate1 and @smalldate2
and isnull(FALARTICLE,'')=@articleST
and isnull(FALLETTRE,'') != ''
and (@ent is null or FALENT=@ent)

insert into #FST (STREP,STGROUPE,STCL,START,STAN,STMOIS,STQTEFA,STCAFA,STPR,STCARFA,STRFACT,
				STENT,STPRM,STPUM,STREPDIV,STDATE,CVLOT,LETTRE)
select isnull(FALREP,''),isnull(FALGROUPE,''),FALCL,FALARTICLE,
		datepart(yy,FALDATE),datepart(mm,FALDATE),
		0,FALTOTALHT,0,
		isnull(FALCARFA,0),isnull(FALRFACT,0),FALENT,0,0,isnull(FALREPDIV,''),dateadd(hh,19,FALDATE),1,""
from FFAL,FAR
where ARCODE=FALARTICLE
and ARTYPE != 8
and FALDATE between @smalldate1 and @smalldate2
and isnull(FALARTICLE,'')=@articleST
and isnull(FALLETTRE,'') = ''
and (@ent is null or FALENT=@ent)


create index seq on #FST (STSEQ)


declare stats cursor
for
select START,STSEQ,STQTEFA,STDATE,CVLOT,LETTRE
from #FST
where STQTEFA != 0
order by START
for read only

declare @article	char(15),
		@seq		int,
		@qte		int,
		@prm		numeric(14,4),
		@pump		numeric(14,4),
		@date		smalldatetime,
		@prFIFO		numeric(14,4),
		@cvlot		int,
		@lettre		char(4)
		
open stats

fetch stats
into @article,@seq,@qte,@date,@cvlot,@lettre

while (@@sqlstatus = 0)
  begin
  
  	  select @prFIFO = 0
	  
	  if isnull(@lettre,'') != ''					/*---------- mode de valorisation au FIFO -----------*/
	  begin
	  select @prFIFO = convert(numeric(14,4),(STPAHT+STFRAIS)/@cvlot) from FSTOCK
	  where STAR = @article
	  and STLETTRE = @lettre
	  end
	  
	  
	  if @prFIFO is null
	  	select @prFIFO = 0

	  select @prm = 0								/*---------- mode de valorisation au PRM mensuel -----------*/
	  
	  set rowcount 1
	  
	  select @prm = PRM from FPRM
	  where PRMAR = @article
	  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
	  order by PRMAN desc,PRMMOIS desc
	  
	  set rowcount 0
	  
	  if @prm is null
		  select @prm = 0
	  
	  select @pump = 0								/*---------- mode de valorisation au PUMP -----------*/
	  
	  select @pump = PUMP from FPUM
	  where PUMAR = @article
	  and PUMDATE <= convert (smalldatetime, @date)
	  having PUMAR = @article
	  and PUMDATE <= convert (smalldatetime, @date)
	  and PUMDATE = max(PUMDATE)
	  
	  if @pump is null
		  select @pump = 0
		  
  
	  update #FST
	  set STPR = convert(numeric(14,2),@prFIFO * @qte), STPRM = convert(numeric(14,2),@prm * @qte), STPUM = convert(numeric(14,2),@pump * @qte)
	  where STSEQ=@seq


	fetch stats
	into @article,@seq,@qte,@date,@cvlot,@lettre

  end


close stats
deallocate cursor stats


if (@an is null) and (@mois is null)
  begin
	delete FST
	where STAN between datepart(yy,getdate())-2 and datepart(yy,getdate())
	and START=@articleST
	and (@ent is null or STENT=@ent)
  end
else if (@an is not null) and (@mois is null)  
  begin
	delete FST
	where STAN = @an
	and START=@articleST
	and (@ent is null or STENT=@ent)
  end
else if (@an is not null) and (@mois is not null)
  begin
  	delete FST
  	where STAN = @an
  	and STMOIS = @mois
  	and START = @articleST
	and (@ent is null or STENT=@ent)
  end


insert into FST (STREP,STGROUPE,STCL,START,STAN,STMOIS,STQTEFA,STCAFA,STPR,STCARFA,STRFACT,STENT,STPRM,STPUM,STREPDIV)
select STREP,STGROUPE,STCL,START,STAN,STMOIS,sum(STQTEFA),sum(STCAFA),sum(STPR),sum(STCARFA),sum(STRFACT),
		STENT,sum(STPRM),sum(STPUM),STREPDIV
from #FST
group by STREP,STGROUPE,STCL,START,STAN,STMOIS,STREPDIV,STENT
order by STREP,STGROUPE,STCL,START,STAN,STMOIS,STREPDIV,STENT

drop table #FST

end



go

