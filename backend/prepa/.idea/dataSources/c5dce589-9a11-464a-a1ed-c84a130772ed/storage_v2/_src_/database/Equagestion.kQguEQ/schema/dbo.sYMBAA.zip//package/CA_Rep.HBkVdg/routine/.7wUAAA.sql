


/* Procedure renvoyant les chiffres d''affaires, qtes facturees
	et commandes pour les annees N-2, N-1, annee en cours pour un Representant*/

create procedure CA_Rep (@ent	char(5) = null,
						 @rep	char(8) = null,
						 @An 	smallint = 0,
						 @srfa	tinyint = 0
						)
with recompile
as
begin

	set arithabort numeric_truncation off

	declare @indice	int
	select @indice = 0
	
	if @rep = ''
		select @rep = null
	
	if @rep is null
		select @indice = 1
		
	if @An = 0 or @An is null
		select @An = datepart(year,getdate())

	create table #Final
	(
	CA_2	numeric(14,2)	null,
	CA_1	numeric(14,2)	null,
	CA_0	numeric(14,2)	null,
	CC		numeric(14,2)	null,
	CCAN	numeric(14,2)	null
	)
	
	declare @type	tinyint
	
	if isnull(@rep,"") != ""
	begin
	
		select  @type=RETYPE
		from FREP
		where RECODE=@rep
		
	end
	
				
		insert into #Final (CA_2,CA_1,CA_0)
		select   sum(STCAFA*(1-sign(abs(STAN-@An+2)))),
				 sum(STCAFA*(1-sign(abs(STAN-@An+1)))),
				 sum(STCAFA*(1-sign(abs(STAN-@An))))
		from FST,FAR
		where ARCODE=START
		and (@ent is null or STENT=@ent)
		and (@srfa=0 or ARTYPE != 6)
		and ((@indice = 1) or (@type = 2 or STREP=@rep))
		and ((@indice = 1) or (@type != 2 or STREPDIV=@rep))
	
		
		insert into #Final (CCAN)
		select sum(STCCCA)
		from FSTCC
		where (@ent is null or STCCENT=@ent)
		and STCCAN=@An
		and ((@indice = 1) or (@type = 2 or STCCREP=@rep))
		and ((@indice = 1) or (@type != 2 or STCCREPDIV=@rep))
		
		insert into #Final (CC)
		select round(sum(CCLTOTALHT/CCLQTE*RCCQTE),2)
		from FRCC,FCCL,FCC
		where (@ent is null or (RCCENT=@ent and CCENT=RCCENT and CCLENT=RCCENT))
		and CCLSEQ = RCCSEQ
		and CCCODE = CCLCODE
		and isnull(CCVALIDE,0)=0
		and ((@indice = 1) or (@type = 2 or CCLREP=@rep))
		and ((@indice = 1) or (@type != 2 or CCLREPDIV=@rep))


	select  sum(isnull(CA_2,0)),sum(isnull(CA_1,0)),sum(isnull(CA_0,0)),
			sum(isnull(CC,0)),sum(isnull(CCAN,0))
	from #Final
	
	drop table #Final

end

go

