


/* Procedure permettant de creer un tableau d''edition de depreciations par article */
	

create procedure TBM_nouv (	@ch			char(8),
							@datedeb	datetime,
							@ps			char(16),
							@psdate		datetime)
with recompile
as
begin

create table #art
(
code		char(15)		null,
lib			varchar(80)		null,
fo			char(12)		null,
fp			char(8)			null,
stqte		int				null,
unitfact	int				null,
txnew		numeric(8,4)	null
)

create table #pvorig
(
code		char(15)		null,
pvuorig		numeric(14,2)	null,
dateorig	datetime		null
)

create table #pvactu
(
code		char(15)		null,
pvuactu		numeric(14,2)	null,
moisactu	smallint		null,
txactu		numeric(8,4)	null,
dateactu	datetime		null
)

create table #actions
(
code		char(15)		null,
dateac		datetime		null
)

create table #mois
(
code		char(15)		null,
moisnew		smallint		null
)


/* elements de base */

insert into #art (code,lib,fo,fp,stqte,unitfact,txnew)
select PSAR,ARLIB,ARFO,ARFAM,sum(PSQTE),CVLOT,0
from FPS,FAR,FCV
where CVUNIF=ARUNITFACT and ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
group by PSAR,ARLIB,ARFO,ARFAM,CVLOT


/* elements historiques */

/* pv origine */

insert into #pvorig (code,pvuorig,dateorig)
select PSAR,ARMPVOLD,ARMDATE
from FPS,FAR,FARM
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
and ARMAR = ARCODE and ARMDATE <= @psdate
group by PSAR,ARMPVOLD,ARMDATE

delete from #pvorig where convert(char(15),code) + convert(varchar(30),dateorig) not in
	(select convert(char(15),code) + convert(varchar(30),min(dateorig)) from #pvorig group by code)

insert into #pvorig (code,pvuorig,dateorig)
select PSAR,ARPVHT,ARDATEMDF
from FPS,FAR
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
and PSAR not in (select code from #pvorig)
group by PSAR,ARPVHT,ARDATEMDF

/* pv actuel */

insert into #pvactu (code,pvuactu,moisactu,txactu,dateactu)
select PSAR,ARMPVNEW,ARMMOIS,ARMTX,ARMDATE
from FPS,FAR,FARM
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
and ARMAR = ARCODE and ARMDATE <= @psdate
group by PSAR,ARMPVNEW,ARMMOIS,ARMTX,ARMDATE

delete from #pvactu where convert(char(15),code) + convert(varchar(30),dateactu) not in
	(select convert(char(15),code) + convert(varchar(30),max(dateactu)) from #pvactu group by code)

insert into #pvactu (code,pvuactu,moisactu,txactu,dateactu)
select PSAR,ARPVHT,0,0,ARDATEMDF
from FPS,FAR
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
and PSAR not in (select code from #pvactu)
group by PSAR,ARPVHT,ARDATEMDF


/* nouvelle periode d inactivite */

insert into #actions (code,dateac)
select PSAR,@datedeb
from FPS,FAR
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
group by PSAR

insert into #actions (code,dateac)
select PSAR,isnull(max(BLLDATE),"1900/01/01")
from FPS,FAR,FBLL
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
and BLLAR=ARCODE and BLLDATE between @datedeb and @psdate
group by PSAR

insert into #actions (code,dateac)
select PSAR,isnull(max(BELDATE),"1900/01/01")
from FPS,FAR,FBEL
where ARCODE=PSAR and PSCODE=@ps and PSDATE=@psdate and ARCHEFP=@ch
and BELARTICLE=ARCODE and BELDATE between @datedeb and @psdate
group by PSAR

insert into #mois (code, moisnew)
select code,min(floor((datediff(dd,dateac,@psdate)*12)/(7*52)))
from #actions
group by code

drop table #actions


/* nouveau taux selon table chef de produits */	

declare ar cursor
for select code from #art
for read only

declare @artar char(15)

create table #taux
(
CHMFO	char(12)		null,
CHMFP	char(8)			null,
CHMAR	char(15)		null,
CHMTX	numeric(8,4)	null,
CHMMOIS	smallint		null
)

open ar

fetch ar into @artar

while @@sqlstatus=0
begin
	insert into #taux
	select CHMFO,CHMFP,CHMAR,CHMTX,CHMMOIS 
	from FAR,FCHM,#mois
	where ARCODE=@artar 
	and ((CHMFO=ARFO and CHMFP=ARFAM and CHMAR=@artar) 
		or (CHMFO=ARFO and CHMFP=ARFAM and CHMAR='')
		or (CHMFO=ARFO and CHMFP='' and CHMAR='')
		or (CHMFO='' and CHMFP='' and CHMAR=''))
	and code=@artar
	and CHMMOIS<=moisnew
	and CHMCH=@ch

	if @@rowcount > 0
	  delete from #taux 
	  where CHMMOIS != (select max(CHMMOIS) from #taux)
	
	if not exists (select * from #taux)
		update #art 
		set txnew=0 where code=@artar
	else if exists (select * from #taux 
		where CHMAR != '')
		update #art 
		set txnew= (select CHMTX from #taux 
		where CHMAR != '') where code=@artar
	else if exists (select * from #taux 
		where CHMFP != '')
		update #art 
		set txnew= (select CHMTX from #taux 
		where CHMFP != '') where code=@artar
	else if exists (select * from #taux 
		where CHMFO != '')
		update #art 
		set txnew= (select CHMTX from #taux 
		where CHMFO != '') where code=@artar
	else
		update #art 
		set txnew= (select CHMTX from #taux) where code=@artar
	
	delete from #taux	
	fetch ar into @artar
end
drop table #taux

close ar
deallocate cursor ar


/* select final */

select 0,@ch,@datedeb,@ps,@psdate,#art.code,lib,pvuorig,moisactu,txactu,pvuactu,stqte,
convert(numeric(14,2),stqte*(pvuorig/unitfact)),
moisnew,isnull(txnew,0),
convert(numeric(14,2),pvuorig*isnull(txnew,0)/100),
convert(numeric(14,2),pvuorig-(pvuorig*isnull(txnew,0)/100)),
fo,fp,
convert(numeric(14,2),stqte*(pvuactu/unitfact)),
convert(numeric(14,2),(pvuorig*isnull(txnew,0)/100)-(pvuorig-pvuactu)),
convert(numeric(14,2),stqte*(((pvuorig*isnull(txnew,0)/100)-(pvuorig-pvuactu))/unitfact)),
convert(numeric(14,2),stqte*(pvuorig*isnull(txnew,0)/100)/unitfact),
convert(numeric(14,2),stqte*((pvuorig-(pvuorig*isnull(txnew,0)/100))/unitfact))
from #art,#pvorig,#pvactu,#mois
where #pvorig.code = #art.code and #pvactu.code = #art.code and #mois.code = #art.code 
order by fo,fp,#art.code


drop table #art
drop table #pvorig
drop table #pvactu
drop table #mois

end



go

