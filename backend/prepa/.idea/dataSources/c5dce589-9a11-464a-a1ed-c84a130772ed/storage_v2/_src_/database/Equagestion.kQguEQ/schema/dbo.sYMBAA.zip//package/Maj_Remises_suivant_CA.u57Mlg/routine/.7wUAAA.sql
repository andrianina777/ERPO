




create procedure Maj_Remises_suivant_CA (
								    @AnneeSaisie      smallint,   /* Annee de reference pour le calcul du CA */
								    @ClientSaisi      char(12),   /* Code Client */
								    @ActiviteSaisie   char(6)     /* Code Activite */
								    )
with recompile
as
begin

set arithabort numeric_truncation off

declare @CodeClient	 	char(12),   
  		@CodeRemise	    char(8),
  		@CA             numeric(14,2),
        @NbResultats    int

create table #Clients
(
Client			    char(12)    	    not null,
ChiffreAffaire      numeric (14,2)      not null
)
  
/* TEST sur code client et activite */  
if isnull(@ClientSaisi,"")<>"" and isnull(@ActiviteSaisie,"")<>""
select @NbResultats = count(*) from FCL where CLCODE=@ClientSaisi and CLSA=@ActiviteSaisie
else select @NbResultats=1

if @NbResultats>0 
begin
    			
    if isnull(@ClientSaisi,"")<>""
    insert into #Clients 
    select CLCODE,0 from FCL where CLCODE=@ClientSaisi /* evite creer une ligne si code client errone */
    
    else 
    if isnull(@ActiviteSaisie,"")<>""
    insert into #Clients 
    select CLCODE,0 from FCL where CLSA=@ActiviteSaisie        

    else 
    insert into #Clients 
    select CLCODE,0 from FCL where CLDESAC=0

end

select @NbResultats=count(*) from #Clients

if @NbResultats>0 and isnull(@AnneeSaisie,0)<>0
begin

    /* Ecriture des CA dans la table listant les clients concernes */
    
    declare ca cursor 
    for select Client
    from #Clients
    for read only
		
    open ca
  
    fetch ca
    into @CodeClient
  
    while (@@sqlstatus = 0)
	begin


        select @CA = sum(isnull(STCAFA,0)) 
        from FST
        where STCL=@CodeClient and STAN=@AnneeSaisie
               
        update #Clients 
        set ChiffreAffaire = isnull(@CA,0) 
        where Client=@CodeClient

        fetch ca
        into @CodeClient  
    end

    close ca
    deallocate cursor ca   


    /* Maj remises */

    declare remises cursor 
    for select Client,ChiffreAffaire
    from #Clients
    for read only
		
    open remises
  
    fetch remises
    into @CodeClient,@CA
  
    while (@@sqlstatus = 0)
	begin

        /* On choisit les codes remises dont le CA est inf au CA du client et on prend le maxi */
    	set rowcount 1
        select @CodeRemise=NRCODE from FNR where isnull(NRCA,0) <= @CA having NRCA=max(isnull(NRCA,0))   
        set rowcount 0
      
        /* Mise a jour des remises client */        
        
        update FCL
        set CLNIVREM=@CodeRemise 
        where CLCODE=@CodeClient

        fetch remises
        into @CodeClient,@CA  
    end

    close remises
    deallocate cursor remises   

end

/* select count(*) from #Clients */

drop table #Clients


end	



go

