


/* Procedure renvoyant les lignes de photo du stock entre deux dates */


create procedure Val_Photo	(@datedeb	smalldatetime,
							 @psdate	datetime,
							 @pscode	char(16)
							)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Final
(
article			char(15)			not null,
qte_stock		int					not null,
val_stock		numeric(14,2)		not null
)

create table #BL
(
artBL	char(15)		not null,
date	smalldatetime	not null,
val		numeric(14,2)	not null,
unitach	int				not null
)



insert into #Final(article,qte_stock,val_stock)
select PSAR,sum(PSQTE),sum((PSPAHT+PSFRAIS)/CVLOT*PSQTE)
from FPS,FAR,FCV
where PSDATE=@psdate
and PSCODE=@pscode
and ARCODE=PSAR
and ARUNITACHAT=CVUNIF
group by PSAR


select article
into #art
from #Final


create unique index article on #art (article)

insert into #BL (artBL,date,val,unitach)
select BLLAR,BLLDATE,round(avg(BLLPRHT/CVLOT),2),CVLOT
from FBLL,#art,FCV
where  BLLAR=article
and CVUNIF=BLLUA
and BLLDATE < @datedeb
and BLLDATE = (select max(BLLDATE) from FBLL as b where b.BLLDATE < @datedeb and #art.article=b.BLLAR)
group by BLLAR,BLLDATE,BLLUA


select article=article,qte_stock=qte_stock,val_stock=val_stock,
		date_der_entree=isnull(date,"19900101"),
		val_unit=isnull(val,0),unite_achat=isnull(unitach,0)
from #Final,#BL
where article *= artBL
order by article

drop table #art
drop table #Final
drop table #BL

end



go

