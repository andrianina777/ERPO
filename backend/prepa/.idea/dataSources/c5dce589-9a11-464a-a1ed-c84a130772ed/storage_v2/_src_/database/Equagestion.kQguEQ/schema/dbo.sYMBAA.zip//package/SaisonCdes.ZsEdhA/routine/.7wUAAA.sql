



create procedure SaisonCdes	(@date1		smalldatetime,
							 @date2		smalldatetime,
							 @marque	char(12)	= null,
							 @famille	char(8)		= null,
							 @article	char(15)	= null,
							 @rep		char(8)		= null,
							 @client	char(12)	= null,
							 @ent		char(5)		= null
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @type		tinyint,
		@division	char(8)

select  @type = 0

if @rep is not null
	select  @type=RETYPE, @division=REDIV from FREP where RECODE=@rep

declare @multient	tinyint

select @multient=KIMULTIENTITE from KInfos


create table #Cdes
(
rep			char(8)			not null,
client		char(12)		not null,
article		char(15)		not null,
commandes	int				not null,
livraisons	int				not null,
totalht		numeric(14,2)	not null
)

create table #Articles
(
arcode		char(15)	not null
)

if @type != 2
begin
  insert into #Cdes (rep,client,article,commandes,livraisons,totalht)
  select CCLREP,CCLCL,CCLARTICLE,sum(CCLQTE),sum(CCLQTEEXP),sum(CCLTOTALHT)
  from FCCL,FCC,FAR
  where CCCODE=CCLCODE
  and CCDATECOM between @date1 and @date2
  and ARCODE=CCLARTICLE
  and (@marque is null or ARFO = @marque)
  and (@famille is null or ARFAM = @famille)
  and (@article is null or ARCODE = @article)
  and (@rep is null or CCLREP = @rep)
  and (@client is null or CCCLIENT = @client)
  and (@multient=0 or @ent is null or (CCENT = @ent and CCLENT = @ent))
  group by CCLREP,CCLCL,CCLARTICLE
end
else if @type = 2
begin
  insert into #Cdes (rep,client,article,commandes,livraisons,totalht)
  select CCLREPDIV,CCLCL,CCLARTICLE,sum(CCLQTE),sum(CCLQTEEXP),sum(CCLTOTALHT)
  from FCCL,FCC,FAR
  where CCCODE=CCLCODE
  and CCDATECOM between @date1 and @date2
  and ARCODE=CCLARTICLE
  and (@marque is null or ARFO = @marque)
  and (@famille is null or ARFAM = @famille)
  and (@article is null or ARCODE = @article)
  and CCLREPDIV = @rep
  and (@client is null or CCCLIENT = @client)
  and (@multient=0 or @ent is null or (CCENT = @ent and CCLENT = @ent))
  group by CCLREPDIV,CCLCL,CCLARTICLE
end


create  index arti on #Cdes (article)


insert into #Articles (arcode)
select article
from #Cdes
group by article


create unique index art on #Articles (arcode)


select STAR,STQTE=sum(STQTE),STVALEUR=sum(round((STPAHT+STFRAIS)/CVLOT,2)*STQTE)
into #Stock
from FSTOCK,FCV,FAR,#Articles
where STAR=arcode
and ARCODE=STAR
and CVUNIF=ARUNITACHAT
and STQTE>0
group by STAR

create unique index star on #Stock (STAR)


select Produit=ARCODE,PAHT=ARFPADEV*DECOURS
into #Achat
from FARF,FDE,FAR,#Articles
where DECODE=ARFDEV
and ARCODE=ARFCODE
and ARFO=ARFFO
and ARCODE=arcode

create unique index prod on #Achat (Produit)


select RCFARTICLE,RCFQTE=sum(RCFQTE),RCFVALEUR=sum(round(CFLTOTALHT/CFLQTE,2)*RCFQTE)
into #CFourn
from FRCF,FCFL,#Articles
where RCFARTICLE=arcode
and CFLSEQ=RCFSEQ
and CFLQTE>0
and (@multient=0 or @ent is null or (CFLENT = @ent and RCFENT = @ent))
group by RCFARTICLE


create unique index arti on #CFourn (RCFARTICLE)



select  VRP=rep,Client=client,Marque=ARFO, Famille=ARFAM, Article=article, Designation=ARLIB,
		Qte_Cdes=commandes, Valeur_Cdes=totalht,
		Prix_vente_Unit_Moyen=round(isnull(totalht/commandes,0),2)*a.CVLOT,
		Unite_Vente=convert(varchar,a.CVLOT),
		Prix_Unit_Achat=round(isnull(PAHT,0),2),
		Unite_Achat=convert(varchar,b.CVLOT),
		Qte_livree=livraisons,
		Qte_Stock=isnull(STQTE,0), Valeur_Stock=round(isnull(STVALEUR,0),2),
		Qte_Cdes_FO=isnull(RCFQTE,0),Valeur_Cdes_FO=round(isnull(RCFVALEUR,0),2)
from #Cdes,#Stock,#Achat,#CFourn,FAR,FCV a,FCV b
where ARCODE=article
and a.CVUNIF=ARUNITFACT
and b.CVUNIF=ARUNITACHAT
and STAR=*article
and Produit=*article
and RCFARTICLE=*article
order by rep,client,ARFO,ARFAM,article


drop table #Cdes
drop table #Stock
drop table #Achat
drop table #CFourn
drop table #Articles

end



go

