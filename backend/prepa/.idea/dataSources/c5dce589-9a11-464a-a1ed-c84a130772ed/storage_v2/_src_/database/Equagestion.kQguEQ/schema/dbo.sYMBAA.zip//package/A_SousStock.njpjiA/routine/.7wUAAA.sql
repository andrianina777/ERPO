


/* Procedure donnant la liste des articles en sous-stock
		a l''horizon demande */


create procedure A_SousStock (	@mois		tinyint,
							  	@an			smallint,
							  	@horizon	tinyint,
							  	@pourcent	smallint,
							  	@quantite	int,
							  	@chef		char(8) = null,
							  	@fournis	char(12) = null,
							  	@famille	char(8) = null,
							  	@article	char(15) = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date		datetime
select  @date = convert(datetime,convert(char(2),@mois)+"/01/"+convert(char(4),@an))

declare @dif	int
select @dif = ((@an-1992)*12)+@mois

declare @compteur	int
select @compteur=2

declare @Mois	tinyint
select @Mois=@mois

declare @An	smallint
select @An=@an

create table #Stock
(
Article		char(15)	not null,
Mois		tinyint		not null,
Annee		smallint	not null,
QteST		int				null,
Ventes		int				null,
Dif			int			not null
)

create table #Ventes
(
Article		char(15)	not null,
Mois		tinyint		not null,
Annee		smallint	not null,
Ventes		int				null,
Dif			int			not null
)

create table #AR
(
Article		char(15)		not null,
Designation	varchar(80)			null,
Prix		numeric(14,2)		null
)

create table #Ante
(
Article		char(15)	not null,
Mois		tinyint		not null,
Annee		smallint	not null,
Qte			int				null,
Dif			int			not null
)

create table #Reliq
(
Article		char(15)		not null,
Qte			int					null
)


if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFAM=@famille
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
	end
else if ((@chef is null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCODE=@article
	end
else if ((@chef is null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARCODE=@article
	end	
else if ((@chef is null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end	
else if ((@chef is not null) and (@fournis is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFAM=@famille
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARCODE=@article
	end
else if ((@chef is not null) and (@fournis is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #AR (Article,Designation,Prix)
		select ARCODE,ARLIB,ARPRM
		from FAR
		where ARCHEFP=@chef
		and ARFO=@fournis
		and ARFAM=@famille
		and ARCODE=@article
	end


create unique clustered index article on #AR (Article)

  /* Selection des reliquats de commandes clients */
  
  insert into #Reliq (Article,Qte)
  select RCCARTICLE,sum(RCCQTE)
  from #AR,FRCC
  where RCCARTICLE=#AR.Article
  and RCCDATE < @date
  group by RCCARTICLE

  /* Selection des commandes clients pour la periode demandee */

  set forceplan on

  insert into #Ante (Article,Mois,Annee,Qte,Dif)
  select STCCART,STCCMOIS,STCCAN,sum(STCCQTE),(STCCAN-1992)*12+STCCMOIS
  from #AR,FSTCC
  where STCCART=#AR.Article
  and (STCCAN-1992)*12+STCCMOIS between @dif and (@dif+@horizon)
  and STCCQTE > 0
  group by STCCART,STCCMOIS,STCCAN,(STCCAN-1992)*12+STCCMOIS

  /* Selection des stocks constates */

  insert into #Stock (Article,Mois,Annee,QteST,Ventes,Dif)
  select SKARTICLE,SKMOIS,SKAN,sum(isnull(SKQTE,0)),0,SKDIF
  from #AR,FSK(2)
  where SKARTICLE=#AR.Article
  and SKDIF between @dif and (@dif+@horizon)
  group by SKARTICLE,SKMOIS,SKAN,SKDIF
  
  set forceplan off
  
  /* Insertion des ventes dans le 1er mois des stocks */
  
  insert into #Stock (Article,Mois,Annee,QteST,Ventes,Dif)
  select Article,@mois,@an,0,0,@dif
  from #Reliq
  where not exists (select * from #Stock
					where #Reliq.Article=#Stock.Article
					and #Stock.Dif = @dif)
  
  update #Stock
  set Ventes=#Reliq.Qte
  from #Reliq
  where #Reliq.Article=#Stock.Article
  and #Stock.Dif = @dif
  
  /* Insertion des articles en commande non existants dans #Stock */
    
  insert into #Stock (Article,Mois,Annee,QteST,Ventes,Dif)
  select Article,Mois,Annee,0,0,Dif
  from #Ante
  where not exists (select * from #Stock
					where #Ante.Article=#Stock.Article
					and #Ante.Mois = #Stock.Mois
					and #Ante.Annee = #Stock.Annee)
  
  
  update #Stock
  set Ventes=Ventes+#Ante.Qte
  from #Ante
  where #Ante.Article=#Stock.Article
  and #Ante.Mois = #Stock.Mois
  and #Ante.Annee = #Stock.Annee
  
  
  insert into #Ventes (Article,Mois,Annee,Ventes,Dif)
  select Article,Mois,Annee,Ventes,Dif
  from #Stock
  
  
  update #Stock
  set QteST=QteST-(select sum(Ventes) from #Ventes
				   where #Ventes.Article=#Stock.Article
				   and #Ventes.Dif between @dif and #Stock.Dif-1)
  
if (@quantite != 0)
  begin
	select #Stock.Article,Mois,Annee,QteST,Ventes,(Ventes-QteST),(Ventes-QteST)*100/Ventes,Designation
	from #Stock,#AR
	where #Stock.Article=#AR.Article
	and (Ventes-QteST) > @quantite
	and Ventes > 0
	union
	select #Stock.Article,Mois,Annee,QteST,Ventes,(Ventes-QteST),100,Designation
	from #Stock,#AR
	where #Stock.Article=#AR.Article
	and (Ventes-QteST) > @quantite
	and Ventes = 0
	order by #Stock.Article,Annee,Mois
  end
else
  begin
    select #Stock.Article,Mois,Annee,QteST,Ventes,(Ventes-QteST),(Ventes-QteST)*100/Ventes,Designation
	from #Stock,#AR
	where #Stock.Article=#AR.Article
	and (convert(float,Ventes)/100*@pourcent) < (Ventes-QteST)
	and Ventes > 0
	union
	select #Stock.Article,Mois,Annee,QteST,Ventes,(Ventes-QteST),100,Designation
	from #Stock,#AR
	where #Stock.Article=#AR.Article
	and (convert(float,Ventes)/100*@pourcent) < (Ventes-QteST)
	and Ventes = 0
	order by #Stock.Article,Annee,Mois
  end


drop table #Stock
drop table #AR
drop table #Ante
drop table #Ventes
drop table #Reliq

end



go

