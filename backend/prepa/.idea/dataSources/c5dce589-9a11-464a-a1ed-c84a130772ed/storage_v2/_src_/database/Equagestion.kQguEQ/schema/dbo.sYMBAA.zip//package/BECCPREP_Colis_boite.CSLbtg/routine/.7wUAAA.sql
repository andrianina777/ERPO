CREATE PROCEDURE dbo.BECCPREP_Colis_boite(@cc varchar(10),@depot varchar(10))

AS
begin
        declare @prepa_colis int,@count int

        exec x_MAJ_Article_SansEmp
        exec x_MAJ_Article_SansFARE

        select @prepa_colis=0
        select @prepa_colis=isnull(DPCOLIS,0) from FDP where DPCODE=@depot
        
        select @count=@@rowcount
        if @count>0
        begin
                
                if (@prepa_colis=1)
                begin
                        exec BECCPREP_Colis_New @cc,@depot
                end
                else
                begin
                        exec BECCPREP_Boite @cc,@depot
                end
        end

end
go

