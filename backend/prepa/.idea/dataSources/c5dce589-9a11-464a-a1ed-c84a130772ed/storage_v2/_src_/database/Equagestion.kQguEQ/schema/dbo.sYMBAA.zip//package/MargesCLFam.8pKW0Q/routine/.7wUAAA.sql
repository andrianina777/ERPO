


/* Procedure donnant la marge par client-famille entre 2 dates */

create procedure MargesCLFam (@ent		char(5)	= null,
							  @FromDate	datetime,
							  @ToDate	datetime,
							  @chefProd	char(8) = null,
							  @famille	char(8) = null
							 )
with recompile
as
begin

set arithabort numeric_truncation off


create table #Far
(
ARFAM			char(8)			null,
ARCODE			char(15)		null,
CVLOT			int				null
)

create table #Fal
(
Client	char(12)		null,
Fam		char(8)			null,
Total	numeric(14,2)	null,
PR		numeric(14,2)	null
)



insert into #Far (ARFAM,ARCODE,CVLOT)
select ARFAM,ARCODE,CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and (@chefProd is null or ARCHEFP= @chefProd)
and (@famille is null or ARFAM=@famille)

create unique index article on #Far(ARCODE)


insert into #Fal (Client,Fam,Total,PR)
select 	FALCL,ARFAM,sum(FALTOTALHT),round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*FALQTE),2)
from FFAL,#Far,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALDATE between @FromDate and @ToDate
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by FALCL,ARFAM

drop table #Far

/* select final */


select Client=Client, Famille=Fam, CA_HT=Total, PAHT=PR,
		Marge_Valeur = Total-PR,
		Marge = round(((Total-PR)*abs(sign(Total)))/(Total+(1-abs(sign(Total)))),2)*100
from #Fal
order by Client,Fam


drop table #Fal

end



go

