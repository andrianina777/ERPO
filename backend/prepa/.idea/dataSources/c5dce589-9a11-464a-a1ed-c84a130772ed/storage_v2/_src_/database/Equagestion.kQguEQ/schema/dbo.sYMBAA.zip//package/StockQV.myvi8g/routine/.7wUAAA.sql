


create procedure StockQV (  @ent		char(5)	= null,
							@depot1		char(4) = null,
							@depot2		char(4) = null,
							@article1	char(15) = null,
							@article2	char(15) = null,
							@famille1	char(8) = null,
							@famille2	char(8) = null,
							@marque1	char(12) = null,
							@marque2	char(12) = null,
							@grfam1		char(8) = null,
							@grfam2		char(8) = null,
							@depart		char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off

if @depot1 is not null and @depot2 is null
	select @depot2=@depot1

if @article1 is not null and @article2 is null
	select @article2=@article1

if @famille1 is not null and @famille2 is null
	select @famille2=@famille1

if @marque1 is not null and @marque2 is null
	select @marque2=@marque1

if @grfam1 is not null and @grfam2 is null
	select @grfam2=@grfam1



declare @modevalo 		tinyint,
 	@date 			datetime,
 	@article		char(15),
	@articleprecedent	char(15),
	@qte			int,
	@PrixRevient		numeric(14,4),
	@PrixRevientLigne	numeric(14,2),
	@seq			int

select @date=getdate()
select @modevalo=PMODEVALO from KParam
select  @articleprecedent = ""

create table #Far
(
ARDEPART	char(8)		not null,
ARFO		char(12)	not null,
ARGRFAM		char(8)		not null,
ARFAM		char(8)		not null,
ARCODE		char(15)	not null,
ARLIB		varchar(80)		null,
ARUNITACHAT	tinyint		not null,
ARPRM		numeric(14,4)	null,
ARREFFOUR	char(20)		null
)

create table #Stock
(
ArticleST	char(15)		not null,
QteStock	int				null,
ValStock	numeric(14,2)	null,
QteBE		int				null,
ValBE		numeric(14,2)	null
)


create table #Final
(
ARCODE				char(15)		not null,
STQTE				int			not null,
VALFINAL			numeric(14,2)		null,
Seq				numeric(14,0)	identity)


declare st_curs cursor 
for select ARCODE,STQTE,Seq
from #Final
order by Seq
for read only


/* creation du fichier article epure */

insert into #Far (ARDEPART,ARFO,ARGRFAM,ARFAM,ARCODE,ARLIB,ARUNITACHAT,ARPRM,ARREFFOUR)
select isnull(ARDEPART,''),isnull(ARFO,''),isnull(ARGRFAM,''),isnull(ARFAM,''),ARCODE,ARLIB,isnull(ARUNITACHAT,0),isnull(ARPRM,0),ARREFFOUR
from FAR
where (@depart is null or ARDEPART=@depart)
and (@marque1 is null or ARFO between @marque1 and @marque2)
and (@grfam1 is null or ARGRFAM between @grfam1 and @grfam2)
and (@famille1 is null or ARFAM between @famille1 and @famille2)
and (@article1 is null or ARCODE between @article1 and @article2)
and AROLD=0
order by ARDEPART,ARFO,ARGRFAM,ARFAM,ARCODE

create unique index code on #Far (ARCODE)


/* traitement du stock  */
 if @modevalo=0							/*--------------------- FIFO  */
  	begin
		insert into #Stock (ArticleST,QteStock,ValStock,QteBE,ValBE)
		select ARCODE,sum(STQTE),sum((STPAHT+STFRAIS)/CVLOT*STQTE),0,0.00
		from #Far,FSTOCK,FCV,FDP
		where ARCODE=STAR
		and STQTE != 0
		and ARUNITACHAT=CVUNIF
		and (@depot1 is null or STDEPOT between @depot1 and @depot2)
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		group by ARCODE
	end
  
 if @modevalo=1		  					/*--------------------- PRM  */
	begin
		insert into #Stock (ArticleST,QteStock,ValStock,QteBE,ValBE)
		select ARCODE,sum(STQTE),sum(ARPRM*STQTE),0,0.00
		from #Far,FSTOCK,FDP
		where ARCODE=STAR
		and STQTE != 0
		and (@depot1 is null or STDEPOT between @depot1 and @depot2)
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		group by ARCODE
	
	end


if @modevalo in (2,3,4)	  					/*--------------------- PUMP  */
	begin
		insert into #Final (ARCODE,STQTE,VALFINAL)
		select ARCODE,STQTE,0
		from #Far,FSTOCK,FDP
		where ARCODE=STAR
		and STQTE>0
		and (@depot1 is null or STDEPOT between @depot1 and @depot2)
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		order by ARCODE
	
		create unique index seq on #Final (Seq)
		
		open st_curs
		
		fetch st_curs
		into @article,@qte,@seq
		
		while (@@sqlstatus = 0)
			begin
			
		  if @articleprecedent != @article
		  begin
			select 	@PrixRevient = 0
			
			if @modevalo = 2									/*--------------------- PUMP */
			begin
			  select @PrixRevient=isnull(PUMP,0)
			  from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			  
			end
			
			else if @modevalo = 3								/*--------------------- PRM Mensuel */
			
			begin
			  set rowcount 1
			  
			  select @PrixRevient=isnull(PRM,0)
			  from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
			
			else  if @modevalo = 4								/*--------------------- DPA unitaire */
			
			begin
			  set rowcount 1			
			
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			  from FBLL,FCV
			  where BLLAR=@article
			  and CVUNIF=BLLUA
			  having BLLAR=@article
			  and CVUNIF=BLLUA
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
			  if isnull(@PrixRevient,0)=0
			  begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
			  set rowcount 0
			  
			  if @PrixRevient is null
				select @PrixRevient = 0
	  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
		  end
		  else if @articleprecedent = @article
		  begin
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end


			update #Final set VALFINAL = @PrixRevientLigne
			where Seq = @seq
		
			select  @articleprecedent = @article
			
			fetch st_curs
			into @article,@qte,@seq
			
		end

		close st_curs
  		
	
		insert into #Stock (ArticleST,QteStock,ValStock,QteBE,ValBE)
		select ARCODE,STQTE,VALFINAL,0,0 from #Final
		
	end

delete from  #Final
select  @articleprecedent = ""


/*=======================================================================================================================*/

/* traitement des BE  */
 if @modevalo=0							/*--------------------- FIFO  */
 	begin
		insert into #Stock (ArticleST,QteBE,ValBE)
		select ARCODE,sum(RBEQTE),sum((STPAHT+STFRAIS)/CVLOT*RBEQTE)
		from #Far,FSTOCK,FCV,FBEL,FRBE,FDP
		where ARCODE=STAR
		and ARUNITACHAT=CVUNIF
		and RBESEQ=BELSEQ
		and RBEDEMO=1
		and STAR=BELARTICLE
		and STLETTRE=BELLETTRE
		and (@depot1 is null or STDEPOT between @depot1 and @depot2)
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		group by ARCODE
	end

 if @modevalo=1		  					/*--------------------- PRM  */
	begin
		insert into #Stock (ArticleST,QteBE,ValBE)
		select ARCODE,sum(RBEQTE),sum(ARPRM*RBEQTE)
		from #Far,FSTOCK,FBEL,FRBE,FDP
		where ARCODE=STAR
		and RBESEQ=BELSEQ
		and RBEDEMO=1
		and STAR=BELARTICLE
		and STLETTRE=BELLETTRE
		and (@depot1 is null or STDEPOT between @depot1 and @depot2)
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		group by ARCODE
	
	end


if @modevalo in (2,3,4)	  					/*--------------------- PUMP  */
	begin
		insert into #Final (ARCODE,STQTE,VALFINAL)
		select ARCODE,RBEQTE,0
		from #Far,FSTOCK,FBEL,FRBE,FDP
		where ARCODE=STAR
		and RBESEQ=BELSEQ
		and RBEDEMO=1
		and STAR=BELARTICLE
		and STLETTRE=BELLETTRE
		and (@depot1 is null or STDEPOT between @depot1 and @depot2)
		and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		order by ARCODE
		
		open st_curs
		
		fetch st_curs
		into @article,@qte,@seq
		
		while (@@sqlstatus = 0)
			begin
			
		  if @articleprecedent != @article
		  begin
			select 	@PrixRevient = 0
			
			if @modevalo = 2									/*--------------------- PUMP */
			begin
			  select @PrixRevient=isnull(PUMP,0)
			  from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, getdate())
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			  
			end
			
			else if @modevalo = 3								/*--------------------- PRM Mensuel */
			
			begin
			  set rowcount 1
			  
			  select @PrixRevient=isnull(PRM,0)
			  from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  having ((PRMAN = datepart(yy,getdate()) and PRMMOIS <= datepart(mm,getdate())) or PRMAN < datepart(yy,getdate()))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
			
			else  if @modevalo = 4								/*--------------------- DPA unitaire */
			
			begin
			  set rowcount 1			
			
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			  from FBLL,FCV
			  where BLLAR=@article
			  and CVUNIF=BLLUA
			  having BLLAR=@article
			  and CVUNIF=BLLUA
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
			  if isnull(@PrixRevient,0)=0
			  begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
			  set rowcount 0
			  
			  if @PrixRevient is null
				select @PrixRevient = 0
	  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
		  end
		  else if @articleprecedent = @article
		  begin
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end


			update #Final set VALFINAL = @PrixRevientLigne
			where Seq = @seq
		
			select  @articleprecedent = @article
			
			fetch st_curs
			into @article,@qte,@seq
			
		end

		close st_curs
  		deallocate cursor st_curs
	
		insert into #Stock (ArticleST,QteStock,ValStock,QteBE,ValBE)
		select ARCODE,0,0,STQTE,VALFINAL from #Final
		
	end



/*=======================================================================================================================*/

/* compil des BE et du Stock  */

select ArticleST,QteStock=sum(QteStock),ValStock=sum(ValStock),QteBE=sum(QteBE),ValBE=sum(ValBE)
into #Stock1
from #Stock
group by ArticleST

create unique index code on #Stock1 (ArticleST)

select ARDEPART,ARFO,ARFAM,ARCODE,ARLIB,
		(case when sum(isnull(QteStock,0))+sum(isnull(QteBE,0)) !=0
			then round((sum(isnull(ValStock,0))+sum(isnull(ValBE,0)))/(sum(isnull(QteStock,0))+sum(isnull(QteBE,0))),2)
		 else 0 end),
		 CVLOT,
		sum(isnull(QteStock,0)),sum(isnull(ValStock,0)),
		sum(isnull(QteBE,0)),sum(isnull(ValBE,0)),ARREFFOUR
from #Far,#Stock1,FCV
where ArticleST=ARCODE
and ARUNITACHAT=CVUNIF
group by ARDEPART,ARFO,ARFAM,ARCODE,ARLIB,CVLOT,ARREFFOUR
order by ARDEPART,ARFO,ARFAM,ARCODE

drop table #Far
drop table #Stock
drop table #Stock1
drop table #Final

end



go

