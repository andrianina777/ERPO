/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.BECCPrep
set quoted_identifier off
grant execute on BECCPrep to public
*/


/*  Procedure utilisee par le module 'Expeditions et Bons de Preparation'.	 */
/*	Renvoie les commandes a expedier dont les articles ne sont pas numerotes */
/*	Renvoie le nombre de colis de la commande								 */

CREATE PROCEDURE dbo.BECCPrep_old (@ent		char(5) = null,
							@UntilDate 	datetime = null,
							@Client		char(12),
							@Commande 	char(10) = null,
							@Depot		char(4),
							@nom		varchar(35) = null,
							@adr1		varchar(50) = null,
							@adr2		varchar(50) = null,
							@cp			varchar(12) = null,
							@ville		varchar(30) = null,
							@py			char(8) = null,
							@devise		char(3) = null
						   )
with recompile					
as
begin

set arithabort numeric_truncation off

declare @restotal	int,
		@resligne	int,
		@stocktotal	int

	create table #ccl(
                CCLSEQ int,
                CCLCODE char(15) null,
                CCLARTICLE char(15) null,
                ARLIB char(80) null,
                ARLIBXENO char(50) null,
                ARFO char(30) null,
                CCLNUMARM1 char(50) null,
                CCLLOT char(12) null,
                CCLQTE int not null,
                AREEMP char(10) null,
                STRESQTE int null,
                NLOTDATEPER smalldatetime null,
                xORDRE int null,
                xCONTENT char(50) null,
                xSTKAUTRE int null,
                xCONTENT2 char(50) null,
                ARESSEMP char(10) null
	)

create table #FRCC
(
	RCCSEQ	int		not null	,
	RCCARTICLE	char(15)		not null	,
	RCCDATE	datetime		not null	,
	RCCMOIS	tinyint		not null	,
	RCCAN	smallint		not null	,
	RCCQTE	int		not null	,
	RCCCL	char(12)		not null	,
	RCCECH	tinyint		not null	,
	RCCFACTMAN	tinyint		null	,
	RCCENT	char(5)		null	,
	RCCQTERES	int		null	,
	RCCDATERESFIN	smalldatetime		null	,
	RCCDEPOTRES	char(4)		null	,
	RCCQTEPREP	int		null	,
	RCCLOT	char(12)		null	,
	RCCARM1	char(30)		null	
)
		
create table #Liste
(
Article 		char(15)	not null,
Lettre			char(4)		not null,
Designation		char(80)		null,
LienCode		char(10)	not null,
LienNum			int			not null,
Qte				int				null,
UnitFact		tinyint		not null,
PrixHT			numeric(14,2)	null,
ModeLiv			char(2)			null,
LigneLibre		varchar(255)	null,
TypeVente		char(4)		not null,
Reglement		tinyint			null,
Echeancesp		tinyint			null,
Factman			tinyint			null,
Offert			tinyint			null,
Artype			tinyint			null,
Devise			char(3)		not null,
Coursdev		numeric(16,10)	null,
PrixHTdev		numeric(14,2)	null,
TotHTdev		numeric(14,2)	null,
Rem1			real			null,
Rem2			real			null,
Rem3	 		real			null,
TotPrixHT		numeric(14,2)	null,
Emplacement		char(8)		not null,
Attachement		char(10)		null,
Lot				char(12)	not null,
Arreffour		char(20)		null,
cclmarche		char(12)		null,
ccldate			datetime		null,
cclcolis		numeric(14,2)	null,
arqtecolis		int				null,
cclpaht			numeric(14,2)	null,
seqLib numeric (18,0) null,
comment_mag		varchar(255)	null
)

create table #Prep
(
CCLSEQ			int			not null,
CCLCODE			char(10)	not null,
CCLNUM			int				null,
CCLDATE			datetime		null,
CCLARTICLE		char(15)	not null,
CCLRESTE		int				null,
ARLIB			varchar(80)		null,
ARUNITFACT		tinyint			null,
CCLPHT			numeric(14,2)	null,
MODELIV			char(2)			null,
CCLLIBRE		varchar(255)	null,
CCLTV			char(4)			null,
ARREGLE			tinyint			null,
CCLECHSPE		tinyint			null,
CCLFACTMAN		tinyint			null,
CCLOFFERT		tinyint			null,
ARTYPE			tinyint			null,
CCLDEV			char(3)			null,
CCLCOURSDEV		numeric(16,10)	null,
CCLPHTDEV		numeric(14,2)	null,
CCLTOTALHTDEV	numeric(14,2)	null,
CCLR1			real		 	null,
CCLR2			real			null,
CCLR3			real			null,
CCLTOTALHT		numeric(14,2)	null,
CCLQTERES		int				null,
CCLDATERESFIN	smalldatetime	null,
CCLDEPOTRES		char(4)			null,
ARCOMP			tinyint			null,
CCLQTEPREP		int				null,
CCLATTACHE		char(10)		null,
ARREFFOUR 		char(20)		null,
CCLMARCHE		char(12)		null,
CCLCOLIS		numeric(14,2)	null,
ARQTECOLIS		int				null,
CCLPAHT			numeric(14,2)	null,
CCL_LIBSEQ numeric(18,0) null,
CCL_COMMENT_MAG varchar(255)	null,
)

create table #Articles
(
CCLARTICLE	char(15)		not null
)

create table #Stock
(
STEMPAR			char(15)		not null,
STEMPLETTRE		char(4)			not null,
QteLoc			int					null,
STEMPDATE		datetime			null,
STEMPEMP		char(8)			not null,
STEMPLOT		char(12)		not null,
STEMPDEPOT		char(4)			not null,
SEQ				numeric(14,0)	identity
)

 


create unique clustered index starlet on #Stock(STEMPAR,STEMPLETTRE,STEMPEMP)

/*OPHAM RICKY*/

	/* recherche stockl */
declare lesLignes cursor
for select CCLSEQ,CCLARTICLE,CCLQTE,isnull(CCLNUMARM1,''),isnull(CCLLOT,'') from FCCL where CCLCODE=@Commande

 
declare @ar char(20),@detail int,@detailres int,@autreStk int ,@ccllot char(20),@cclseq int,@cclSerie char(25),@ssemp char(10),@emp char(10),@qte int

open lesLignes
fetch lesLignes into @cclseq,@ar,@qte,@cclSerie,@ccllot
while (@@sqlstatus=0)
begin
	/* on recherche le stock total du rayon detail */

    select @detail=isnull(sum(isnull(FSTOCK.STQTE,0)),0) from FSTOCK
	  where FSTOCK.STAR=@ar and FSTOCK.STDEPOT='DET' and FSTOCK.STQTE<>0
    and ((@cclSerie<>'' and  isnull(FSTOCK.STNUMARM1,'')=@cclSerie) or (@cclSerie='' and ((@ccllot='' or isnull(FSTOCK.STLOT,'')=@ccllot))  ))



	 /* on recherche ensuite le stock reserve pour cet article precis lot/serie */

        insert into #FRCC
        select RCCSEQ		,RCCARTICLE	,RCCDATE		,RCCMOIS	,RCCAN		,RCCQTE		,RCCCL		,RCCECH		,RCCFACTMAN		,RCCENT	,RCCQTERES	,RCCDATERESFIN		,RCCDEPOTRES		,RCCQTEPREP		,RCCLOT		,RCCARM1	 
        from FRCC,FCCL,FCC,FCC2
        where   CCLSEQ=RCCSEQ
        and CCLCODE=CCCODE
        and CCCODE=CC2CODE
        and  RCCARTICLE=@ar
        and CCSTADE_DET>=3
        and isnull(CC2AO,0)=0


select @detailres=isnull(sum(isnull(RCCQTEPREP,0)),0) from #FRCC
    --select @detailres=isnull(sum(isnull(RCCQTE,0)),0) from #FRCC
    where RCCARTICLE=@ar and isnull(RCCLOT,'')=@ccllot and isnull(RCCARM1,'')=@cclSerie and RCCSEQ<>@cclseq 


    select @emp=max(STEMPEMP) from FSTEMP where STEMPDEPOT=@Depot
   and  STEMPQTE>0 and STEMPAR=@ar 
   
	select @autreStk=isnull(sum(isnull(FSTOCK.STQTE,0)),0) from FSTOCK,FDP
	  where FSTOCK.STAR=@ar and FSTOCK.STDEPOT<>@Depot and DPCODE=STDEPOT
	  and DPCENTRAL=1 and DPLOC=1  and (@ccllot='' or isnull(FSTOCK.STLOT,'')=@ccllot)  and (@cclSerie='' or isnull(FSTOCK.STNUMARM1,'')=@cclSerie)


	select @ssemp=ARESSEMP from FARE where AREDEPOT=@Depot and AREEMP=@emp and AREAR=@ar
	

        insert into #ccl
        select @cclseq,@Commande,@ar,
        (case when rtrim(isnull(CCLLIBRE,''))='' then ARLIB else ARLIB + ' - '+ CCLLIBRE end),
        (case when rtrim(isnull(ARLIBXENO,''))<>'' and ARLIBXENO<>ARLIB then ARLIBXENO else '' end),
        (case when ARFO<>'FRNSTMP' then ARFO else '-' end),
        isnull(CCLNUMARM1,''),isnull(CCLLOT,''),
        CCLQTE-isnull(CCLQTEEXP,0),@emp,@detail-@detailres,NLOTDATEPER,0,'',@autreStk,'',@ssemp
        from FCCL,FAR,FNLOT
        where CCLCODE=@Commande
        and ARCODE=CCLARTICLE
        and CCLLOT*=NLOTCODE
        and CCLARTICLE*=NLOTAR
        and ARTYPE=0
        and CCLSEQ=@cclseq
	
  delete from #FRCC
 
    fetch lesLignes into @cclseq,@ar,@qte,@cclSerie,@ccllot
end
close lesLignes
deallocate cursor lesLignes 

/*FIN OPHAM RICKY*/



if (@UntilDate is null)
begin
	insert into #Prep
	select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
	substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
	ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
	isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
	isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,'')
	from FCCL,FAR,FCC,FRCC
	where CCLSEQ=RCCSEQ
	and RCCCL=@Client
	and RCCARTICLE=ARCODE
	and CCCODE=CCLCODE
	and (@Commande is null or CCLCODE=@Commande)
	and ARNUMEROTE=0
	and isnull(CCVALIDE,0)=0
	and isnull(CCBEBLOQUE,0)=0
	and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	and (isnull(@nom,'') = '' or CCNOM = @nom)
	and (isnull(@adr1,'') = '' or CCADR1 = @adr1)
	and (isnull(@adr2,'') = '' or CCADR2 = @adr2)
	and (isnull(@cp,'') = '' or CCCP = @cp)
	and (isnull(@ville,'') = '' or CCVILLE = @ville)
	and (isnull(@py,'') = '' or CCPY = @py)
	and (isnull(@devise,'') = '' or CCDEV = @devise)
	order by RCCDATE,RCCSEQ
end
else
begin
	insert into #Prep
	select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
	substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
	ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
	isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
	isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,'')
	from FCCL,FAR,FCC,FRCC
	where CCLSEQ=RCCSEQ
	and RCCCL=@Client
	/*and RCCDATE<=@UntilDate*/
	and RCCARTICLE=ARCODE


and CCLCL=CCCLIENT

	and CCCODE=CCLCODE
	and (@Commande is null or CCLCODE=@Commande)
	and ARNUMEROTE=0
	and isnull(CCVALIDE,0)=0
	and isnull(CCBEBLOQUE,0)=0
	and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	and (isnull(@nom,'') = '' or CCNOM = @nom)
	and (isnull(@adr1,'') = '' or CCADR1 = @adr1)
	and (isnull(@adr2,'') = '' or CCADR2 = @adr2)
	and (isnull(@cp,'') = '' or CCCP = @cp)
	and (isnull(@ville,'') = '' or CCVILLE = @ville)
	and (isnull(@py,'') = '' or CCPY = @py)
	and (isnull(@devise,'') = '' or CCDEV = @devise)

	order by RCCDATE,RCCSEQ
end


declare commandes cursor
for
select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,
ARUNITFACT,CCLPHT,MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,CCLOFFERT,
ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,ARCOMP,CCLQTEPREP,CCLATTACHE,ARREFFOUR,CCLMARCHE,CCLCOLIS,ARQTECOLIS,CCLPAHT,CCL_LIBSEQ,CCL_COMMENT_MAG
from #Prep
order by CCLDATE,CCLSEQ
for read only


insert into #Articles (CCLARTICLE)
select distinct CCLARTICLE from #Prep

create unique clustered index article on #Articles(CCLARTICLE)

declare		@CCLSEQ			int,
			@CCLCODE		char(10),
			@CCLNUM			int,
			@CCLDATE		datetime,
			@CCLARTICLE		char(15),
			@CCLRESTE		int,
			@ARLIB			varchar(80),
			@ARUNITFACT		tinyint,
			@PUHT			numeric(14,2),
			@MODELIV		char(2),
			@CCLLIBRE		varchar(255),
			@CCLTV			char(4),
			@ARREGLE		tinyint,
			@CCLECHSPE		tinyint,
			@CCLFACTMAN		tinyint,
			@CCLOFFERT		tinyint,
			@ARTYPE			tinyint,
			@CCLDEV			char(3),
			@CCLCOURSDEV	numeric(16,10),
			@CCLPHTDEV		numeric(14,2),
			@CCLTOTALHTDEV	numeric(14,2),
			@CCLR1			real,
			@CCLR2			real,
			@CCLR3			real,
			@CCLTOTALHT		numeric(14,2),
			@CCLQTERES		int,
			@CCLDATERESFIN	smalldatetime,
			@CCLDEPOTRES	char(4),
			@ARCOMP			tinyint,
			@CCLQTEPREP		int,
			@CCLATTACHE		char(10),
			@ARREFFOUR		char(20),
			@CCLMARCHE		char(12),
			@CCLCOLIS		numeric(14,2),
			@ARQTECOLIS		int,
			@CCLPAHT		numeric(14,2),
      		@CCL_LIBSEQ numeric(18,0),
      		@CCL_COMMENT_MAG varchar(255)

set forceplan on
/*  insert into #Stock (STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
  select STEMPAR,STEMPLETTRE,STEMPQTE,STEMPDATE,STEMPEMP,isnull(STEMPLOT,''),STEMPDEPOT
  from #Articles,FSTEMP,FAR,FDP,FARE
  where STEMPAR=CCLARTICLE
  and ARCODE=STEMPAR
  and STEMPDEPOT=@Depot
  and AREAR=STEMPAR and AREDEPOT=STEMPDEPOT and AREEMP=STEMPEMP
  and (ARTYPE <> 0 or STEMPQTE > 0)
  and DPCODE=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
  order by AREPICK desc,STEMPDATE,STEMPAR,STEMPLETTRE
set forceplan off*/

/*OPHAM POUR RASSURER QU IL nya pas de B qui bloque les Bon de Preparation*/ 

/* delete from FBPL where BPLCODE not in (select BPCODE from FBP)*//*permet de supprimer en automatique les reservations dans FRBP qui ne figure plus dans FBP*/
/*FGIN OPHAM*/

 insert into #Stock (STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
 /* select STEMPAR,STEMPLETTRE,(STEMPQTE-sum(isnull(RBPQTE,0))),STEMPDATE,STEMPEMP,isnull(STEMPLOT,''),STEMPDEPOT*/
  select STEMPAR,STEMPLETTRE,(STEMPQTE-sum(isnull(RBPQTE,0))),NLOTDATEPER,STEMPEMP,isnull(STEMPLOT,''),STEMPDEPOT

  from #Articles,FSTEMP,FAR,FDP,FARE,FRBP,FNLOT/*Enlever les qt?s par lot dej? reserv? par un autre bon de preparartion*/ /*OPHAM RICKY*/
  where STEMPAR=CCLARTICLE
  and ARCODE=STEMPAR
  and STEMPDEPOT=@Depot
  and AREAR=STEMPAR and AREDEPOT=STEMPDEPOT and AREEMP=STEMPEMP
  and (ARTYPE <> 0 or STEMPQTE > 0)
  and DPCODE=STEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and  CCLARTICLE*=RBPARTICLE
and STEMPDEPOT*=RBPDEPOT
and STEMPLETTRE*=RBPLETTRE
and STEMPAR*=NLOTAR
and STEMPLOT*=NLOTCODE
group by STEMPAR,STEMPLETTRE,NLOTDATEPER,STEMPEMP,isnull(STEMPLOT,''),STEMPDEPOT,STEMPQTE
order by STEMPAR,NLOTDATEPER
/*  order by AREPICK desc,STEMPDATE,STEMPAR,STEMPLETTRE*/
/*order by AREPICK desc,NLOTDATEPER,STEMPAR,STEMPLETTRE*/


/*select * from #Stock*/

declare LeStock cursor
for select STEMPAR,STEMPLETTRE,QteLoc,STEMPEMP,STEMPLOT,STEMPDEPOT,SEQ
from #Stock,FAR
where ARCODE=STEMPAR
and STEMPAR=@CCLARTICLE
and (ARTYPE <> 0 or QteLoc > 0)
order by SEQ
for read only

delete from #Prep where not exists (select * from #Stock where STEMPAR=#Prep.CCLARTICLE)


declare 	@qteST 			int,
			@articleST 		char(15),
			@lettreST 		char(4),
			@qtealivrer		int,
			@emplacement	char(8),
			@lot			char(12),
			@depot			char(4),
			@seq			numeric(14,0),
			@resteapreparer	int



open commandes

fetch commandes
into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV ,
@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG


while (@@sqlstatus = 0)
begin
	select @resteapreparer = @CCLRESTE-@CCLQTEPREP

	select @restotal = sum(RCCQTERES)
	from FRCC
	where RCCARTICLE = @CCLARTICLE
	and RCCDEPOTRES = @Depot
	
	select @stocktotal = sum(STQTE)
	from FSTOCK
	where STAR = @CCLARTICLE
	and STDEPOT = @Depot
	
	if @restotal is null select @restotal = 0
	
	if @CCLDATERESFIN is not null and @CCLDEPOTRES = @Depot
	select @resligne = @CCLQTERES
	else
	select @resligne = 0
	
	if @resligne is null select @resligne = 0
	
		open LeStock
		
		fetch LeStock
		into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
		
		while (@@sqlstatus = 0)
		begin
		  select @qtealivrer = 0
		  
		  if @ARTYPE <> 0															/* si article non stocke */
			select @qtealivrer = @resteapreparer,
				   @resteapreparer = 0
		  else if @resteapreparer <= @stocktotal-@restotal+@resligne				/* si reste a prep <= stock dispo total */
			begin
				if @resteapreparer <= @qteST										/* si reste a prep <= stock dispo depot */
					select @qtealivrer = @resteapreparer,
				   		   @resteapreparer = 0
				else																/* si reste a prep > stock dispo depot */
					select @qtealivrer = @qteST,
				   		   @resteapreparer = @resteapreparer - @qteST
			end
		  else if @resteapreparer > @stocktotal-@restotal+@resligne					/* si reste a prep > stock dispo total */
			begin
				if @stocktotal-@restotal+@resligne >= @qteST
					select @qtealivrer = @qteST,
				   		   @resteapreparer = @resteapreparer - @qteST
				else if @stocktotal-@restotal+@resligne < @qteST
					select @qtealivrer = @stocktotal-@restotal+@resligne,
				   		   @resteapreparer = @resteapreparer - (@stocktotal-@restotal+@resligne)
			end
	
		  
		  insert into #Liste (Article,Lettre,Designation,LienCode,LienNum,Qte,
							  UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,
							  Reglement,Echeancesp,Factman,Offert,Artype,
							  Devise,Coursdev,PrixHTdev,TotHTdev,Rem1,Rem2,Rem3,
							  TotPrixHT,Emplacement,Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,seqLib,comment_mag)
		  select @articleST,@lettreST,@ARLIB,@CCLCODE,@CCLNUM,@qtealivrer,
							  @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,
							  @CCLTV,@ARREGLE,@CCLECHSPE,@CCLFACTMAN,@CCLOFFERT,@ARTYPE,
							  @CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,@CCLR1,@CCLR2,@CCLR3,
							  @CCLTOTALHT,@emplacement,@CCLATTACHE,@lot,@ARREFFOUR,@CCLMARCHE,@CCLDATE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG
		
	
	
		  update #Stock set QteLoc=QteLoc-@qtealivrer where SEQ = @seq
		  
		  select @stocktotal = @stocktotal - @qtealivrer
		  
		  select @restotal = (case when @qtealivrer >= @resligne then @restotal - @resligne
								   when @qtealivrer < @resligne then @restotal - @qtealivrer end)
		  select @resligne = (case when @qtealivrer >= @resligne then 0
		  else @resligne - @qtealivrer end)
		  
		  if (@resteapreparer <= 0) break
		  
		  fetch LeStock
		  into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
		end

	close LeStock 

	fetch commandes
	into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
	@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
	@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
	@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
	@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG
end

close commandes
deallocate cursor commandes

delete from #Liste
where Artype=4
and not exists (select * from #Liste as b where #Liste.LienCode=b.LienCode and b.Artype <> 4)
and not exists (select * from FCCL,FAR where CCLCODE=#Liste.LienCode and ARCODE=CCLARTICLE and CCLRESTE > 0 and (ARNUMEROTE=1 or ARCOMP=2))

select Article,Lettre,Designation,LienCode,LienNum,Qte,
	   UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,Reglement,
	   Echeancesp,abs(Qte),Factman,isnull(Offert,0),isnull(Artype,0),
	   isnull(Devise,''),isnull(Coursdev,0),isnull(PrixHTdev,0),
	   isnull(TotHTdev,0),Rem1,Rem2,Rem3,TotPrixHT,Emplacement,
	   Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,'',0,0,0,0,0,0,'','','',0,'','',0,'','','',0,0,0,seqLib,comment_mag
from #Liste
where Qte > 0
order by LienCode,LienNum


/*POUR LE BESOIN D APPRO DETAIL*/

create table #Appro (LIB char(255) null,CCLQTE int null,STRESTE int null,STDEPOT char(10) null,STEMPEMP char(10) null, STEMPQTE int null, CCLSEQ int null)

insert into #Appro
select 'LIB'=rtrim(ARLIB),
        /*(case when isnull(CCLNUMARM1,'')<>'' then '- sn:'+rtrim(CCLNUMARM1) when  (isnull(CCLNUMARM1,'')='' AND isnull(CCLLOT,'')<>'') then  '- l:'+rtrim(CCLLOT) else '' end),*/
        CCLQTE,STRESQTE,STDEPOT,STEMPEMP,'QTE'=sum(STEMPQTE),CCLSEQ
        from #ccl,FSTOCK,FDP,FSTEMP
        where STRESQTE<CCLQTE
        and STEMPAR=CCLARTICLE
        and STEMPAR=STAR
        and STEMPLETTRE=STLETTRE
        and FSTEMP.STEMPDEPOT<>@Depot and DPCODE=STEMPDEPOT and STDEPOT=STEMPDEPOT
        and STEMPQTE<>0 and STQTE<>0
        and (isnull(CCLLOT,'')='' or (isnull(STLOT,'')=isnull(CCLLOT,'')))
        and (isnull(CCLNUMARM1,'')='' or (isnull(STNUMARM1,'')=isnull(CCLNUMARM1,'')))
        and DPCENTRAL=1 and DPLOC=1
        group by CCLARTICLE,CCLNUMARM1,CCLLOT,ARLIB,STEMPEMP,CCLQTE,STRESQTE,STEMPDEPOT,STDEPOT,STAR,CCLSEQ
/*FIN APPRO OPHAM*/

/*verifier si cette table possede des enregistrement */

declare @nombre int,@dateAttenteTransfert datetime, @xSeq int,@datejour datetime
select @datejour=getdate()
select @nombre =count(*) from #Appro
if(@nombre>0)
begin
  

select @dateAttenteTransfert=CCATTETRANSFERT from FCC where CCCODE=@Commande
   if (@dateAttenteTransfert=null)
begin
        update FCC set  CCATTETRANSFERT=@datejour where CCCODE=@Commande

        declare appro cursor for select CCLSEQ from #Appro 
        open appro
        fetch  appro into  @xSeq
        while (@@sqlstatus=0)
        begin
                insert into xFCCL (xSeq,xDateAtteTransfert) values (@xSeq,@datejour) 
                
                fetch  appro into  @xSeq
        end
close appro 
deallocate cursor appro
 
   
/*  update FCCL set CCLATTETRANSFERT=getdate() from FCCL,#Appro where FCCL.CCLSEQ=#Appro.CCLSEQ*/
 
  
end

end
/*pour les article en attente de transfert*/
select rtrim(#Appro.LIB), #Appro.CCLQTE, #Appro.STRESTE, #Appro.STDEPOT, #Appro.STEMPEMP, #Appro.STEMPQTE, #Appro.CCLSEQ from #Appro

/*pour les articles qui n ont pas d emplacement*/
select   CCLARTICLE, VIEW_FAR_TOUS.ARLIB,   AREEMP, ARESSEMP 
        from #ccl,VIEW_FAR_TOUS
        where ARCODE=CCLARTICLE
        and isnull(ARESSEMP,'')=''

drop table #Prep
drop table #Articles
drop table #Stock
drop table #Liste

drop table #Appro

drop table #ccl



end













































go

