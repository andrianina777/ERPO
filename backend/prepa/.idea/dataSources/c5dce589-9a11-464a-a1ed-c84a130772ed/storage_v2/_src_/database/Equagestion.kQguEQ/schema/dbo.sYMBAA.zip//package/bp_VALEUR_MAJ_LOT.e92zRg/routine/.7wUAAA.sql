/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE bp_VALEUR_MAJ_LOT
grant execute on bp_AlertDureeVie to public
*/

CREATE PROCEDURE dbo.bp_VALEUR_MAJ_LOT
with recompile
AS
begin
	create table #MAJ_LOT(
		VALEUR numeric(18,3),
		DATE datetime
	)
 	
 	insert into #MAJ_LOT select RJLQTE*RJLPAHT,convert(date,RJLDATE) from FRJL where RJLDATE>'2018-01-01' and upper(RJLCOMMENT) like upper('%MAJ%LOT%')  and RJLDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)
 	insert into #MAJ_LOT select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2018-01-01' and upper(SILCOMMENT) like upper('%MAJ%LOT%')  and SILDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) from #MAJ_LOT where MONTH(DATE)<7 group by YEAR(DATE),MONTH(DATE)
end
go

