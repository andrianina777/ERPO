


/* Procedure utilisee par le Tableau de Bord Client pour les delais de reglement moyen du client */


create procedure Delai_reg_moyen (@ent		char(5),
								  @client 	char(12),
								  @an		smallint	= null
						   		 )
with recompile
as
begin

if @an is null
select @an = datepart(yy,getdate())

declare @date1	smalldatetime
declare @date2	smalldatetime
select @date1 = convert (datetime,"01/01/" + convert(varchar(4),@an))
select @date2 = convert (datetime,"12/31/" + convert(varchar(4),@an))


  select Num_fact=FACODE, Date_fact=FADATE, Mode_Reglement=MRLIB, " 1 ->", Echeance=FATRDATE1, Reglement=FAREGL1, Delai = datediff(dd,FADATE,FATRDATE1)
  from FFA,FCL,FMR
  where FADATE between @date1 and @date2
  and FACL=@client
  and CLCODE=FACL
  and MRCODE=FAMODEREG1
  and FAREGL1 != 0
  and (@ent is null or(FAENT=@ent and CLENT=@ent))
   union
  select FACODE, FADATE, MRLIB, " 2 ->", FATRDATE2, FAREGL2, datediff (dd,FADATE,FATRDATE2)
  from FFA,FCL,FMR
  where FADATE between @date1 and @date2
  and FACL=@client
  and CLCODE=FACL
  and MRCODE=FAMODEREG2
  and FAREGL2 != 0
  and isnull(FATR2,"")<>""
  and (@ent is null or(FAENT=@ent and CLENT=@ent))
   union
  select FACODE, FADATE, MRLIB, " 3 ->", FATRDATE3, FAREGL3, datediff (dd,FADATE,FATRDATE3)
  from FFA,FCL,FMR
  where FADATE between @date1 and @date2
  and FACL=@client
  and CLCODE=FACL
  and MRCODE=FAMODEREG3
  and FAREGL3 != 0
  and isnull(FATR3,"")<>""
  and (@ent is null or(FAENT=@ent and CLENT=@ent))
   union
  select FACODE, FADATE, MRLIB, " 4 ->", FATRDATE4, FAREGL4, datediff (dd,FADATE,FATRDATE4)
  from FFA,FCL,FMR
  where FADATE between @date1 and @date2
  and FACL=@client
  and CLCODE=FACL
  and MRCODE=FAMODEREG4
  and FAREGL4 != 0
  and isnull(FATR4,"")<>""
  and (@ent is null or(FAENT=@ent and CLENT=@ent))
  order by FACODE, FADATE, FATRDATE1


end



go

