



create procedure Stock_Global (@ent		char(5)	= null)		/* procedure a finir en fonction de la nouvelle approche des depots */
with recompile
as
begin

set arithabort numeric_truncation off


create table #Final
(
depart		char(8)		not null,
marque		char(12)	not null,
famille		char(8)		not null,
qte_stock	int				null,
val_stock	numeric(14,2)	null,
qte_bedemo	int				null,
val_bedemo	numeric(14,2)	null,
qte_be		int				null,
val_be		numeric(14,2)	null
)


insert into #Final (depart,marque,famille,qte_stock,val_stock,qte_bedemo,val_bedemo,qte_be,val_be)
select ARDEPART,ARFO,ARFAM,sum(STQTE),sum(round((STPAHT+STFRAIS)/CVLOT,2)*STQTE),0,0,0,0
from FSTOCK,FAR,FCV
where ARCODE=STAR
and ARUNITACHAT=CVUNIF
and STQTE != 0
group by ARDEPART,ARFO,ARFAM
order by ARDEPART,ARFO,ARFAM


insert into #Final (depart,marque,famille,qte_stock,val_stock,qte_bedemo,val_bedemo,qte_be,val_be)
select ARDEPART,ARFO,ARFAM,0,0,sum(BELQTE),sum(round((STPAHT+STFRAIS)/CVLOT,2)*BELQTE),0,0
from FSTOCK,FAR,FCV,FBEL,FRBE
where BELSEQ=RBESEQ
and ARCODE=BELARTICLE
and ARUNITACHAT=CVUNIF
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and ARTYPE=0
and RBEDEMO=1
group by ARDEPART,ARFO,ARFAM
order by ARDEPART,ARFO,ARFAM



insert into #Final (depart,marque,famille,qte_stock,val_stock,qte_bedemo,val_bedemo,qte_be,val_be)
select ARDEPART,ARFO,ARFAM,0,0,0,0,sum(BELQTE),sum(round((STPAHT+STFRAIS)/CVLOT,2)*BELQTE)
from FSTOCK,FAR,FCV,FBEL,FRBE
where BELSEQ=RBESEQ
and ARCODE=BELARTICLE
and ARUNITACHAT=CVUNIF
and STAR=BELARTICLE
and STLETTRE=BELLETTRE
and ARTYPE=0
and RBEDEMO=0
group by ARDEPART,ARFO,ARFAM
order by ARDEPART,ARFO,ARFAM


select Departement=depart,Marque=marque,Famille=famille,
		Qte_Stock=sum(qte_stock),Valeur_Stock=sum(val_stock),
		Qte_Demo=sum(qte_bedemo),Valeur_Demo=sum(val_bedemo),
		Qte_BE=sum(qte_be),Valeur_BE=sum(val_be)
from #Final
group by depart,marque,famille
order by depart,marque,famille

drop table #Final

end



go

