


/* Procedure utilisee pour verifier les stocks constates
	pour un mois et une annee donnes pour un article */

create procedure A_SKVerif (@Mois		tinyint,
							@Annee		smallint,
							@Article	char(15))
with recompile
as
begin

declare @date1			datetime
declare @date2			datetime

declare @MoisPrecedent	tinyint
declare @AnneeInit		smallint


if @Mois=1
  begin
	select @MoisPrecedent=12
	select @AnneeInit=@Annee-1
  end
else
  begin
	select @MoisPrecedent=@Mois-1
	select @AnneeInit=@Annee
  end


select @date1=convert(datetime,convert(char(2),@MoisPrecedent)+"/01/"+convert(char(4),@AnneeInit))
select @date2=convert(datetime,convert(char(2),@Mois)+"/01/"+convert(char(4),@Annee))
select @date2=dateadd(dd,-1,@date2)


create table #Stock
(
Article		char(15)	not null,
Qte			int				null
)

/* ''Stock du mois precedent Fichier FSK'' */

print "Stock indique au mois precedent"

select SKARTICLE,SKQTE
from FSK
where SKAN=@AnneeInit
and SKMOIS=@MoisPrecedent
and SKARTICLE=@Article


/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #Stock (Article, Qte)
select SILARTICLE,sum(SILQTE)
from FSIL
where SILDATE between @date1 and @date2
and SILARTICLE=@Article
group by SILARTICLE


/* ''Reajustements - Fichier RJL'' */

insert into #Stock (Article, Qte)
select RJLARTICLE,sum(RJLQTE)
from FRJL
where RJLDATE between @date1 and @date2
and RJLARTICLE=@Article
group by RJLARTICLE


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #Stock (Article, Qte)
select BLLAR,sum(BLLQTE)
from FBLL
where BLLDATE between @date1 and @date2
and BLLAR=@Article
group by BLLAR


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #Stock (Article, Qte)
select DOLAR,sum(DOLQTE)
from FDOL
where DOLDATE between @date1 and @date2
and DOLAR=@Article
group by DOLAR


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #Stock (Article, Qte)
select RFLARTICLE,-sum(RFLQTE)
from FRFL
where RFLDATE between @date1 and @date2
and RFLARTICLE=@Article
group by RFLARTICLE


/* ""Lignes de BE - Fichier FBEL"" */

insert into #Stock (Article, Qte)
select BELARTICLE,-sum(BELQTE)
from FBEL
where BELDATE between @date1 and @date2
and BELARTICLE=@Article
group by BELARTICLE


/* Stock */

print "Mouvements du mois"

select Article, sum(Qte)
from #Stock
group by Article


drop table #Stock


end



go

