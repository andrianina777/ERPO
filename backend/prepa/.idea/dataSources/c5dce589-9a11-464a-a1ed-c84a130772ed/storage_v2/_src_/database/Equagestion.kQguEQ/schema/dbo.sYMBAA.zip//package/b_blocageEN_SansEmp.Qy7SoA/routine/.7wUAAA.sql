CREATE PROCEDURE dbo.b_blocageEN_SansEmp (@article char(15),@seq int)

AS
begin
	declare @count int,
			@emp char(8)
	
	select @count=0
	
	select @count=count(*),@emp=AREEMP from FARE where ARERECEP=1 and AREVALID=1 and AREDEPOT='GROS'
	and AREEMP in (select  rtrim(xEmplSTEMP) from xEMPL where xDepotl='GROS' and xTypel=2) and AREAR=@article
	
	if(@count>0)
		begin
			update xFBPRL set xBPRL_SANS_EMP=1,xBPRLDATE_SANSEMP=getDate(),xBPRL_EMP_TEMP=@emp where xBPRLSEQ=@seq and isnull(xBPRL_SANS_EMP,0)=0
		end
	select @count
  		
end



go

