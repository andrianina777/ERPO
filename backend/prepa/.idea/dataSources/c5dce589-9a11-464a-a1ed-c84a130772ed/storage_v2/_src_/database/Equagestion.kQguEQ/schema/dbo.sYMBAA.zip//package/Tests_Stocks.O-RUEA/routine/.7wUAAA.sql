



create procedure Tests_Stocks	(@article	char(15),
								 @lettre	char(4)	= null
								)

with recompile
as
begin

set nocount off

select AREAR,AREDEPOT,AREEMP,AREPICK,ARERECEP
from FARE
where AREAR = @article

select STAR,STLETTRE,STDEPOT,STQTE,STNUMARM1,STNUMARM2,STLOT
from FSTOCK
where STAR = @article
and (@lettre is null or STLETTRE = @lettre)
compute sum(STQTE)

select STEMPAR,STEMPLETTRE,STEMPDEPOT,STEMPEMP,STEMPQTE,STEMPLOT
from FSTEMP
where STEMPAR = @article
and (@lettre is null or STEMPLETTRE = @lettre)
compute sum(STEMPQTE)


select RCCARTICLE,RCCCL,CCLCODE,CCLNUM,RCCQTE,RCCQTERES
from FRCC,FCCL
where CCLSEQ=RCCSEQ
and RCCARTICLE=@article
order by RCCCL,CCLCODE,CCLNUM

select "==========================================================================================="

end



go

