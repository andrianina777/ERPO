/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE bp_VALEUR_PRELE
grant execute on bp_AlertDureeVie to public
*/

CREATE PROCEDURE dbo.bp_VALEUR_PRELE
with recompile
AS
begin
	create table #MAJ_LOT(
		VALEUR numeric(18,3),
		DATE datetime
	)
	
	create table #AMM(
		VALEUR numeric(18,3),
		DATE datetime
	)
 	
 	insert into #MAJ_LOT select RJLQTE*RJLPAHT,convert(date,RJLDATE) from FRJL where RJLDATE>'2018-01-01' and upper(RJLCOMMENT) like upper('%PRELEV%')  and RJLDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)
 	
 	--insert into #MAJ_LOT select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2019-01-01' and SILDEPOT='PROM' and SILQTE>0

 	insert into #AMM select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2018-01-01' and upper(SIL_MOTIF) like upper('%AMM%') and SILDEPOT='ECH'
 	
 	
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) as VALEUR_PRL from #MAJ_LOT where MONTH(DATE)<7 group by YEAR(DATE),MONTH(DATE) union
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) as VALEUR_AMM from #AMM where MONTH(DATE)<7 group by YEAR(DATE),MONTH(DATE)
 	
 	drop table #MAJ_LOT
 	
 	drop table  #AMM
end
go

