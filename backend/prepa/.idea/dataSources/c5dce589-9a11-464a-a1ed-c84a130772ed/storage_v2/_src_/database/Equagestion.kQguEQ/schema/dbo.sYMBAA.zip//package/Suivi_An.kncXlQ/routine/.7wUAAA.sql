


/* Procedure permettant de suivre les mouvements mensuels d''un article pour une annee choisie */

create procedure Suivi_An (@Article		char(15),
						   @Annee		smallint)
with recompile
as
begin

declare @lot	int,
		@date1	smalldatetime,
		@date2	smalldatetime

select @lot=CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARCODE=@Article

select Unite_achat_actuel=@lot

select @date1 = convert (datetime,"01/01/" + convert(varchar(4),@Annee))
select @date2 = convert (datetime,"12/31/" + convert(varchar(4),@Annee))


select 'Stock initial - Fluctuations - Fichier SIL'

select 'SIL ',Article=SILARTICLE,Lettre=SILLETTRE,Date=SILDATE,
Quantite=SILQTE,PrixRevient=round((SILPAHT+SILFRAIS)/@lot,2)*SILQTE,
Depot=SILDEPOT,NÃÂ°=SILNUMDEP,'F'
from FSIL
where SILARTICLE=@Article
and SILDATE between @date1 and @date2
order by SILDATE
compute sum(SILQTE),sum(round((SILPAHT+SILFRAIS)/@lot,2)*SILQTE)


select 'Reajustements - Fichier RJL'

select 'RJL',Article=RJLARTICLE,Lettre=RJLLETTRE,Date=RJLDATE,
Quantite=RJLQTE,PrixRevient=round((RJLPAHT+RJLFRAIS)/@lot,2)*RJLQTE,
Depot=RJLDEPOT,NÃÂ°=RJLNUMDEP,'R'
from FRJL
where RJLARTICLE=@Article
and RJLDATE  between @date1 and @date2
order by RJLDATE
compute sum(RJLQTE),sum(round((RJLPAHT+RJLFRAIS)/@lot,2)*RJLQTE)


select 'Lignes de casse - Fichier LCL'

select 'LCL',Article=LCLARTICLE,Lettre=LCLLETTRE,Date=LCLDATE,
Quantite=LCLQTE,PrixRevient=round((LCLPAHT+LCLFRAIS)/@lot,2)*LCLQTE,
Depot=LCLDEPOT,NÃÂ°=LCLNUMDEP,'C'
from FLCL
where LCLARTICLE=@Article
and LCLDATE between @date1 and @date2
order by LCLDATE
compute sum(LCLQTE),sum(round((LCLPAHT+LCLFRAIS)/@lot,2)*LCLQTE)


select 'Assemblage Desassemblage - Fichier ASL'

select 'ASL',Article=ASLARTICLE,Lettre=ASLLETTRE,Date=ASLDATE,
Quantite=ASLQTE,PrixRevient=(ASLPAHT+ASLFRAIS)*ASLQTE,
Depot=ASLDEPOT,NÃÂ°=ASLNUMDEP,'A'
from FASL
where ASLARTICLE=@Article
and ASLDATE between @date1 and @date2
order by ASLDATE
compute sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE)


select 'Reajustements des mouvements uniquement - Fichier RM'

select 'RM ',Article=RMARTICLE,Lettre=RMLETTRE,Date=RMDATE,
Quantite=RMQTE,PrixRevient=round((RMPAHT+RMFRAIS)/@lot,2)*RMQTE,
Depot=RMDEPOT,NÃÂ°=RMNUMDEP,'M'
from FRM
where RMARTICLE=@Article
and RMDATE between @date1 and @date2
order by RMDATE
compute sum(RMQTE),sum(round((RMPAHT+RMFRAIS)/@lot,2)*RMQTE)


select 'Bordereaux de livraisons Fournisseurs - Fichier BLL'

select 'BLL',Article=BLLAR,Lettre=BLLLET,Date=BLLDATE,
Quantite=BLLQTE,PrixRevient=round(BLLPRHT/@lot,2)*BLLQTE,
Depot=BLLDEP,NÃÂ°=BLLNUMDEP,'E',Code=BLLCODE,Ligne=BLLNUM
from FBLL
where BLLAR=@Article
and BLLDATE between @date1 and @date2
order by BLLDATE
compute sum(BLLQTE),sum(round((BLLPRHT)/@lot,2)*BLLQTE)


select 'Sorties de douanes & entrees magasin - Fichier DOL'

select 'DOL',Article=DOLAR,Lettre=DOLLET,Date=DOLDATE,
Quantite=DOLQTE,PrixRevient=round(DOLPRHT/@lot,2)*DOLQTE,
Depot=DOLDEP,NÃÂ°=DOLNUMDEP,'E',Code=DOLCODE,Ligne=DOLNUM
from FDOL
where DOLAR=@Article
and DOLDATE between @date1 and @date2
order by DOLDATE
compute sum(DOLQTE),sum(round((DOLPRHT)/@lot,2)*DOLQTE)


select 'Retour des marchandises vers Fournisseurs - Fichier RFL'

select 'RFL',Article=RFLARTICLE,Lettre=RFLLETTRE,Date=RFLDATE,
Quantite=RFLQTE,PrixRevient=round(RFLPAHT/@lot,2)*RFLQTE,
Depot=RFLDEPOT,NÃÂ°=RFLNUMDEP,'E',Code=RFLCODE,Ligne=RFLNUM
from FRFL
where RFLARTICLE=@Article
and RFLDATE between @date1 and @date2
order by RFLDATE
compute sum(RFLQTE),sum(round((RFLPAHT)/@lot,2)*RFLQTE)


select 'Factures - Fichier FAL'

select count(*) from FFAL where FALARTICLE=@Article and FALDATE between @date1 and @date2

select 'FAL',Article=FALARTICLE,Lettre=FALLETTRE,Date=FALDATE,
Quantite=FALQTE,PrixRevient=round((STPAHT+STFRAIS)/@lot,2)*FALQTE,
Depot='MAG',NÃÂ°='1','S',CodeFA=FALCODE,CodeBE=FALLIENCODE,LigneBE=FALLIENNUM
from FFAL,FSTOCK
where FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALARTICLE=@Article
and FALDATE between @date1 and @date2
order by FALDATE
compute sum(FALQTE),sum(round((STPAHT+STFRAIS)/@lot,2)*FALQTE)


select 'Lignes de BE - Fichier FBEL'
select count(*) from FBEL where BELARTICLE=@Article and BELDATE between @date1 and @date2

select 'BEL',Article=BELARTICLE,Lettre=BELLETTRE,Date=BELDATE,
Quantite=BELQTE,PrixRevient=round((STPAHT+STFRAIS)/@lot,2)*BELQTE,
Depot='MAG',NÃÂ°='1','-',Code=BELCODE,Ligne=BELNUM,BELRESTE
from FBEL,FSTOCK
where BELARTICLE=STAR
and BELLETTRE=STLETTRE
and BELARTICLE=@Article
and BELDATE between @date1 and @date2
order by BELDATE
compute sum(BELQTE),sum(round((STPAHT+STFRAIS)/@lot,2)*BELQTE),sum(BELRESTE)


select "Lignes de RBE - Fichier FRBE"

select RBEARTICLE,RBEDATE,RBEQTE*sign(BELQTE),RBECL,RBEDEMO,RBEECH,RBEFACTMAN
from FRBE,FBEL
where BELSEQ=RBESEQ
and RBEARTICLE=@Article
order by RBEDATE
compute sum(RBEQTE*sign(BELQTE))


select 'Stock en cours - Fichier FSTOCK'
select count(*) from FSTOCK where STAR=@Article

select 'STOCK',Article=STAR,Lettre=STLETTRE,Date=STDATEENTR,
Quantite=STQTE,PrixRevient=round((STPAHT+STFRAIS)/@lot,2)*STQTE,
Depot=STDEPOT,NÃÂ°=DPLOC,Fournisseur=STFO
from FSTOCK,FDP
where STAR=@Article
and DPCODE=STDEPOT
order by STDATEENTR
compute sum(STQTE),sum(round((STPAHT+STFRAIS)/@lot,2)*STQTE)

end



go

