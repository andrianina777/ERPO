
create procedure StockPhoto_Imp (@ent			char(5)	= null, 
								 @datephoto		smalldatetime, 
								 @codephoto		char(16), 
								 @depot1		char(4) = null, 
								 @depot2		char(4) = null, 
								 @article1		char(15) = null, 
								 @article2		char(15) = null, 
								 @famille1		char(8) = null, 
								 @famille2		char(8) = null, 
								 @marque1		char(12) = null, 
								 @marque2		char(12) = null, 
								 @emplace1		char(8) = null, 
								 @emplace2		char(8) = null, 
								 @typeve1		char(8) = null, 
								 @typeve2		char(8) = null, 
								 @depart		char(8) = null, 
								 @chefp			char(8) = null, 
								 @numerote		tinyint = null, 
								 @modevalo		tinyint = 0,		/* 0 = FIFO, 1 = PRM Global, 2 = PUMP, 3 = PRM Mensuel, 4 = DPA unitaire */ 
								 @benonfact		tinyint = 0,
								 @stade1		tinyint = 0,
								 @stade2		tinyint = 0,
								 @stade3		tinyint = 0,
								 @stade4		tinyint = 0
								 ) 
with recompile 
as 
begin 

set arithabort numeric_truncation off 
 
create table #Final 
( 
ARFO						char(12)		not null, 
ARFAM						char(8)			not null, 
ARGRILLE					char(10)			null, 
ARDEPART					char(8)			not null, 
ARCODE						char(15)		not null, 
PSLETTRE					char(4)			not null, 
ARREFFOUR					char(20)		not null, 
ARLIB						char(80)			null, 
ARGRFAM						char(8)				null,
ARCHEFP						char(8)				null,
PSEMPEMP					char(8)				null, 
ARPRM						numeric(14,4)	not null, 
ARFRAIS 					numeric(14,4)	not null, 
ARFRAISV  					numeric(14,4)	not null, 
CVLOT						int				not null, 
PSEMPDEPOT					char(4)			not null, 
PSEMPQTE					int				not null,
PBEMPQTE					int				not null,  
PSSERIE1					char(12)			null, 
PSSERIE2					char(12)			null, 
PSPAHT						numeric(14,2)	not null, 
PSFRAIS						numeric(14,2)	not null, 
PrixRevientLigne			numeric(14,2)	not null, 
Seq							numeric(14,0)	identity 
) 
 
declare @empphoto   char(8) 
declare @val1 tinyint
declare @val2 tinyint
declare @val3 tinyint
declare @val4 tinyint
 
select @empphoto=IPSEMP from FIPS where IPSCODE=@codephoto and IPSDATE=@datephoto 

select @val1=99,@val2=99,@val3=99,@val4=99 

if @stade1=0 and @stade2=0 and @stade3=0 and @stade4=0
	select @val1=0,@val2=1,@val3=2,@val4=3 
else
	begin
		if @stade1=1
			select @val1=0
		if @stade2=1
			select @val2=1
		if @stade3=1
			select @val3=2
		if @stade4=1
			select @val4=3
	end 
 
if isnull(@empphoto,'')='' 
begin 
    
    if @emplace1 is null 
    begin 

        if @benonfact=0        
        		insert into #Final (ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        		PSEMPEMP,ARPRM,ARFRAIS,ARFRAISV,CVLOT,PSEMPDEPOT,PSEMPQTE,PBEMPQTE,
        		PSSERIE1,PSSERIE2,PSPAHT,PSFRAIS,PrixRevientLigne) 
        		select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        		PSEMPEMP,isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PSEMPDEPOT,isnull(PSEMPQTE,0),0,
        		PSSERIE1,PSSERIE2,isnull(PSPAHT,0),isnull(PSFRAIS,0),0.00 
        		from FPS,FAR,FCV,FDP,FPSEMP 
        		where ARCODE=PSAR 
        		and ARUNITACHAT=CVUNIF 
        		and PSEMPAR=PSAR 
        		and PSEMPLETTRE=PSLETTRE 
        		and PSEMPCODE=PSCODE 
		        and PSEMPDATE=PSDATE 
		        and PSDATE=@datephoto 
		        and PSCODE=@codephoto 
		        and (@depot1 is null or PSEMPDEPOT between @depot1 and @depot2) 
		        and (@article1 is null or ARCODE between @article1 and @article2) 
		        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		        and (@marque1 is null or ARFO between @marque1 and @marque2) 
		        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
		        and (@depart is null or ARDEPART = @depart) 
		        and (@chefp is null or ARCHEFP = @chefp) 
		        and (@numerote is null or ARNUMEROTE=1) 
		        and DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
		        order by ARCODE 
        
        if @benonfact=1
        begin		
        		insert into #Final (ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        		PSEMPEMP,ARPRM,ARFRAIS,ARFRAISV,CVLOT,PSEMPDEPOT,PSEMPQTE,PBEMPQTE,
        		PSSERIE1,PSSERIE2,PSPAHT,PSFRAIS,PrixRevientLigne) 
        		
        		select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        		PSEMPEMP,isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PSEMPDEPOT,isnull(PSEMPQTE,0),0,
        		PSSERIE1,PSSERIE2,isnull(PSPAHT,0),isnull(PSFRAIS,0),0.00 
        		from FPS,FAR,FCV,FDP,FPSEMP 
        		where ARCODE=PSAR 
        		and ARUNITACHAT=CVUNIF 
        		and PSEMPAR=PSAR 
        		and PSEMPLETTRE=PSLETTRE 
        		and PSEMPCODE=PSCODE 
		        and PSEMPDATE=PSDATE 
		        and PSDATE=@datephoto 
		        and PSCODE=@codephoto 
		        and (@depot1 is null or PSEMPDEPOT between @depot1 and @depot2) 
		        and (@article1 is null or ARCODE between @article1 and @article2) 
		        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		        and (@marque1 is null or ARFO between @marque1 and @marque2) 
		        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
		        and (@depart is null or ARDEPART = @depart) 
		        and (@chefp is null or ARCHEFP = @chefp) 
		        and (@numerote is null or ARNUMEROTE=1) 
		        and DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
		        
		        union
		        
		        select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PBLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
		        right(PBBE,8),isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PBDEPOT,isnull(PBQTE,0),isnull(PBQTE,0),
		        PBSERIE1,PBSERIE2,isnull(PBPAHT,0),isnull(PBFRAIS,0),0.00 
        		from FPB,FAR,FCV,FDP 
        		where ARCODE=PBAR 
        		and ARUNITACHAT=CVUNIF
		        and PBDATE=@datephoto 
		        and PBCODE=@codephoto 
		        and (@depot1 is null or PBDEPOT between @depot1 and @depot2) 
		        and (@article1 is null or ARCODE between @article1 and @article2) 
		        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
		        and (@marque1 is null or ARFO between @marque1 and @marque2) 
		        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
		        and (@depart is null or ARDEPART = @depart) 
		        and (@chefp is null or ARCHEFP = @chefp) 
		        and (@numerote is null or ARNUMEROTE=1) 
		        and DPCODE=PBDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 		        
		        and PBSTADE in (@val1,@val2,@val3,@val4)  
		        		        
		        order by ARCODE 
		     end   
 
    end 
    else 
    begin 
      
      if @benonfact=0 
        insert into #Final (ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        PSEMPEMP,ARPRM,ARFRAIS,ARFRAISV,CVLOT,PSEMPDEPOT,PSEMPQTE,PBEMPQTE,
        PSSERIE1,PSSERIE2,PSPAHT,PSFRAIS,PrixRevientLigne) 
        select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        PSEMPEMP,isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PSEMPDEPOT,isnull(PSEMPQTE,0),0,
        PSSERIE1,PSSERIE2,isnull(PSPAHT,0),isnull(PSFRAIS,0),0.00 
        from FPS,FAR,FCV,FDP,FPSEMP 
        where ARCODE=PSAR 
        and ARUNITACHAT=CVUNIF 
        and PSEMPAR=PSAR 
        and PSEMPLETTRE=PSLETTRE 
        and PSEMPCODE=PSCODE 
        and PSEMPDATE=PSDATE 
        and PSDATE=@datephoto 
        and PSCODE=@codephoto 
        and PSEMPEMP between @emplace1 and @emplace2 
        and (@depot1 is null or PSEMPDEPOT between @depot1 and @depot2) 
        and (@article1 is null or ARCODE between @article1 and @article2) 
        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
        and (@marque1 is null or ARFO between @marque1 and @marque2) 
        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
        and (@depart is null or ARDEPART = @depart) 
        and (@chefp is null or ARCHEFP = @chefp) 
        and (@numerote is null or ARNUMEROTE=1) 
        and DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
        order by ARCODE 

      if @benonfact=1
      begin	        
        insert into #Final (ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        PSEMPEMP,ARPRM,ARFRAIS,ARFRAISV,CVLOT,PSEMPDEPOT,PSEMPQTE,PBEMPQTE,
        PSSERIE1,PSSERIE2,PSPAHT,PSFRAIS,PrixRevientLigne)        
      	
        select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
        PSEMPEMP,isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PSEMPDEPOT,isnull(PSEMPQTE,0),0,
        PSSERIE1,PSSERIE2,isnull(PSPAHT,0),isnull(PSFRAIS,0),0.00 
        from FPS,FAR,FCV,FDP,FPSEMP 
        where ARCODE=PSAR 
        and ARUNITACHAT=CVUNIF 
        and PSEMPAR=PSAR 
        and PSEMPLETTRE=PSLETTRE 
        and PSEMPCODE=PSCODE 
        and PSEMPDATE=PSDATE 
        and PSDATE=@datephoto 
        and PSCODE=@codephoto 
        and PSEMPEMP between @emplace1 and @emplace2 
        and (@depot1 is null or PSEMPDEPOT between @depot1 and @depot2) 
        and (@article1 is null or ARCODE between @article1 and @article2) 
        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
        and (@marque1 is null or ARFO between @marque1 and @marque2) 
        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
        and (@depart is null or ARDEPART = @depart) 
        and (@chefp is null or ARCHEFP = @chefp) 
        and (@numerote is null or ARNUMEROTE=1) 
        and DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
      	
      	union
      	
      	select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PBLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,
      	right(PBBE,8),isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PBDEPOT,isnull(PBQTE,0),isnull(PBQTE,0),
      	PBSERIE1,PBSERIE2,isnull(PBPAHT,0),isnull(PBFRAIS,0),0.00 
        from FPB,FAR,FCV,FDP 
        where ARCODE=PBAR 
        and ARUNITACHAT=CVUNIF
        and PBDATE=@datephoto 
        and PBCODE=@codephoto
        and (@depot1 is null or PBDEPOT between @depot1 and @depot2) 
        and (@article1 is null or ARCODE between @article1 and @article2) 
        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
        and (@marque1 is null or ARFO between @marque1 and @marque2) 
        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
        and (@depart is null or ARDEPART = @depart) 
        and (@chefp is null or ARCHEFP = @chefp) 
        and (@numerote is null or ARNUMEROTE=1) 
        and DPCODE=PBDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
      	and PBSTADE in (@val1,@val2,@val3,@val4) 
      	
      	order by ARCODE                  
      end
       
    end 
end 
 
if isnull(@empphoto,'')<>'' 
begin  
    if @emplace1 is null 
    begin 
  	
        insert into #Final (ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,PSEMPEMP,ARPRM,ARFRAIS,ARFRAISV,CVLOT,PSEMPDEPOT, 
					  PSEMPQTE,PBEMPQTE,PSSERIE1,PSSERIE2,PSPAHT,PSFRAIS,PrixRevientLigne) 
        select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSEMPLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,PSEMPEMP,isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PSEMPDEPOT, 
					  isnull(PSEMPQTE,0),0,STNUMARM1,STNUMARM2,isnull(STPAHT,0),isnull(STFRAIS,0),0.00 
        from FSTOCK,FAR,FCV,FDP,FPSEMP 
        where ARCODE=PSEMPAR 
        and ARUNITACHAT=CVUNIF 
        and PSEMPAR=STAR 
        and PSEMPLETTRE=STLETTRE 
        and PSEMPDEPOT=STDEPOT 
        and PSEMPDATE=@datephoto 
        and PSEMPCODE=@codephoto 
        and PSEMPEMP=@empphoto 
        and (@depot1 is null or PSEMPDEPOT between @depot1 and @depot2) 
        and (@article1 is null or ARCODE between @article1 and @article2) 
        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
        and (@marque1 is null or ARFO between @marque1 and @marque2) 
        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
        and (@depart is null or ARDEPART = @depart) 
        and (@chefp is null or ARCHEFP = @chefp) 
        and (@numerote is null or ARNUMEROTE=1) 
        and DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
        order by ARCODE        

    end 
    else 
    begin 
        insert into #Final (ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,PSEMPEMP,ARPRM,ARFRAIS,ARFRAISV,CVLOT,PSEMPDEPOT, 
					  PSEMPQTE,PBEMPQTE,PSSERIE1,PSSERIE2,PSPAHT,PSFRAIS,PrixRevientLigne) 
        select ARFO,ARFAM,ARGRILLE,ARDEPART,ARCODE,PSEMPLETTRE,ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,PSEMPEMP,isnull(ARPRM,0),isnull(ARFRAIS,0),isnull(ARFRAISV,0),CVLOT,PSEMPDEPOT, 
					  isnull(PSEMPQTE,0),0,STNUMARM1,STNUMARM2,isnull(STPAHT,0),isnull(STFRAIS,0),0.00 
        from FSTOCK,FAR,FCV,FDP,FPSEMP 
        where ARCODE=PSEMPAR 
        and ARUNITACHAT=CVUNIF 
        and PSEMPAR=STAR 
        and PSEMPLETTRE=STLETTRE 
        and PSEMPDEPOT=STDEPOT 
        and PSEMPDATE=@datephoto 
        and PSEMPCODE=@codephoto 
        and PSEMPEMP=@empphoto 
        and PSEMPEMP between @emplace1 and @emplace2 
        and (@depot1 is null or PSEMPDEPOT between @depot1 and @depot2) 
        and (@article1 is null or ARCODE between @article1 and @article2) 
        and (@famille1 is null or ARFAM between @famille1 and @famille2) 
        and (@marque1 is null or ARFO between @marque1 and @marque2) 
        and (@typeve1 is null or ARTYPEVE between @typeve1 and @typeve2) 
        and (@depart is null or ARDEPART = @depart) 
        and (@chefp is null or ARCHEFP = @chefp) 
        and (@numerote is null or ARNUMEROTE=1) 
        and DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
        order by ARCODE 
    end 
end 
 
  create unique index seq on #Final (Seq) 
 
  declare @article			char(15), 
		  @articleprecedent	char(15), 
		  @qte				int, 
		  @PrixRevient		numeric(14,4), 
		  @PrixRevientLigne	numeric(14,2), 
		  @seq				int, 
		  @cvlot			int, 
		  @arprm			numeric(14,4), 
		  @pspaht			numeric(14,2), 
		  @psfrais			numeric(14,2) 
		   
  select  @articleprecedent = "" 
  select  @datephoto = dateadd(hh,19,@datephoto) 
   
  declare stock cursor  
  for select Seq,ARCODE,PSEMPQTE,PSPAHT,PSFRAIS,ARPRM,CVLOT 
  from #Final 
  order by Seq 
  for read only 
		 
 
  open stock 
   
  fetch stock 
  into @seq,@article,@qte,@pspaht,@psfrais,@arprm,@cvlot
   
  while (@@sqlstatus = 0) 
	begin 
	   
	   
	  if @modevalo = 0											/*--------------------- FIFO */ 
		begin 
			select  @PrixRevient = 0, 
			  		@PrixRevientLigne = 0 
 
			select @PrixRevient = round((@pspaht+@psfrais)/@cvlot,4)		 
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
		end 
	  else if @modevalo = 1 and @articleprecedent != @article	/*--------------------- PRM */ 
		begin 
			select  @PrixRevient = @arprm, 
			  		@PrixRevientLigne = 0 
 
			select @PrixRevientLigne = convert(numeric(14,2),@arprm * @qte) 
		end 
	  else if @modevalo = 2 and @articleprecedent != @article	 	/*--------------------- PUMP */ 
		begin 
		  select  @PrixRevient = 0, 
				  @PrixRevientLigne = 0 
 
		  select @PrixRevient=isnull(PUMP,0) 
		  from FPUM 
		  where PUMAR = @article 
		  and PUMDATE <= @datephoto 
		  having PUMAR = @article 
		  and PUMDATE <= @datephoto 
		  and PUMDATE = max(PUMDATE) 
		   
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
		end 
	  else if @modevalo = 3 and @articleprecedent != @article	/*--------------------- PRM Mensuel */ 
		begin 
		  select  @PrixRevient = 0, 
				  @PrixRevientLigne = 0 
 
		  set rowcount 1 
		   
		  select @PrixRevient=isnull(PRM,0) 
		  from FPRM 
		  where PRMAR = @article 
		  and ((PRMAN = datepart(yy,@datephoto) and PRMMOIS <= datepart(mm,@datephoto)) or PRMAN < datepart(yy,@datephoto)) 
		  having ((PRMAN = datepart(yy,@datephoto) and PRMMOIS <= datepart(mm,@datephoto)) or PRMAN < datepart(yy,@datephoto)) 
		  and PRMAR = @article 
		  order by PRMAN desc,PRMMOIS desc 
		   
		  set rowcount 0 
		   
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
		end 
	  else  if @modevalo = 4 and @articleprecedent != @article	/*--------------------- DPA unitaire */ 
		begin 
		  select  @PrixRevient = 0, 
				  @PrixRevientLigne = 0 
		   
		  set rowcount 1 
		   
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/@cvlot,4) 
		  from FBLL 
		  where BLLAR=@article 
		  having BLLAR=@article 
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end)) 
		 
		  if isnull(@PrixRevient,0)=0 
		  begin 
			select @PrixRevient = round((SILPAHT+SILFRAIS)/@cvlot,4) 
			from FSIL 
			where SILARTICLE=@article 
			having SILARTICLE=@article 
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end)) 
		  end 
		   
		  set rowcount 0 
		   
		  if @PrixRevient is null 
			select @PrixRevient = 0 
   
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			 
		end 
	   
	  if @modevalo != 0 and @articleprecedent = @article 
	  begin 
		select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) 
	  end 
	  
	  update #Final set PrixRevientLigne = @PrixRevientLigne 
	  where Seq = @seq 
   
	  select  @articleprecedent = @article 
	   
	  fetch stock 
	  into @seq,@article,@qte,@pspaht,@psfrais,@arprm,@cvlot 
	   
  end 
 
  close stock 
  deallocate cursor stock 
 
  select ARFO,ARFAM,isnull(ARGRILLE,""),ARDEPART,ARCODE,isnull(PSLETTRE,""),ARREFFOUR,ARLIB,ARGRFAM,ARCHEFP,PSEMPEMP,isnull(PSEMPDEPOT,""), 
					  PSEMPQTE,PBEMPQTE,PSSERIE1,PSSERIE2,isnull(PrixRevientLigne,0),isnull(round(ARFRAIS/CVLOT*PSEMPQTE,2),0),isnull(round(ARFRAISV/CVLOT*PSEMPQTE,2),0)
  from #Final 
  order by Seq 
     
  drop table #Final 
 
end
go

