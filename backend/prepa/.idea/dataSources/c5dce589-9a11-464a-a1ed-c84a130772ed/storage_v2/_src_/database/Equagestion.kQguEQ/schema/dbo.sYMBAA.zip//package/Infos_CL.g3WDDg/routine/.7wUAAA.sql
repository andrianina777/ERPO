




/* Procedure utilisee par le module ""Export Clients"" */


create procedure Infos_CL  (@ent		char(5) = null,
							@an			int,
							@activite	char(8)	= null,
							@dep		varchar(12) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off


if @dep is not null
	select @dep=@dep+"%"

create table #CL
(
CLREP			char(8)		not	null,	/* Code VRP */
CLCODE			char(12)	not	null,	/* Code client */
CLNOM1			varchar(35)		null,	/* Nom 1 du client */
TYPEADR			varchar(20)	not null,	/* Type d''adresse : adresse, livraisons, facturation */
CLADR1			varchar(50)		null,	/* 1ere ligne adresse du client */
CLADR2			varchar(50)		null,	/* 2eme ligne adresse du client */
CLCP			varchar(12)		null,	/* Code postal du client */
CLVILLE			varchar(30)		null,	/* Ville  du client */
CLPY			char(8)			null,	/* Code pays du client */
CLPAYS			varchar(30)		null,	/* Pays du client */
CLPAYEUR		tinyint			null,	/* Type de payeur */
CLTEL1			varchar(20)		null,	/* Numero de telephone 1 */
CLTELECOP1		varchar(20)		null,	/* Numero de fax 1 */
CLSIRET			char(14)		null,	/* NÃÂ° SIRET */
CLNTVA			char(14)		null,	/* NÃÂ° TVA intra-communautaire */
CLAPE			char(4)			null,	/* Code APE du client */
CLNUMCOMPTABLE	char(12)		null,	/* Numero comptable client */
CLCODEGROUPE	char(12)		null,	/* Code du groupement d''achat */
CLSANSTVA		tinyint			null,	/* 1 = client sans TVA */
CLMODEREG		char(8)			null,	/* Type reglement */
CLESCOMPTE		numeric(9,2)	null,	/* Escompte */
CLLIMITE		numeric(14,2)	null,	/* Limite d''achat societe concedee */
CLASSUR			numeric(14,2)	null,	/* Limite d''achat assuree */
CLNOMBANK		varchar(30)		null,	/* Nom de la banque */
CLCODEBANK		char(5)			null,	/* Code de la banque */
CLNUMGUICHET	char(5)			null,	/* NÃÂ° de guichet */
CLNUMCOMPTE		char(12)		null,	/* Numero de compte bancaire */
CLCLERIB		char(2)			null,	/* Cle RIB */
CLSANSPORT		tinyint			null,	/* 1 = client qui ne doit pas payer de port */
CLSANSASSUR		tinyint			null,	/* 1 = client qui ne doit pas payer d''assurance */
CAN_1			numeric(14,2)	null,	/* CA annee N-1 */
CAN				numeric(14,2)	null,	/* CA annee en cours */
CLEMAIL			varchar(50)		null	/* Email societe */
)


insert into #CL (CLREP,CLCODE,CLNOM1,TYPEADR,CLADR1,CLADR2,CLCP,CLVILLE,CLPY,CLPAYS,
				 CLPAYEUR,CLTEL1,CLTELECOP1,CLSIRET,CLNTVA,CLAPE,CLNUMCOMPTABLE,
				 CLCODEGROUPE,CLSANSTVA,CLMODEREG,CLESCOMPTE,CLLIMITE,CLASSUR,
				 CLNOMBANK,CLCODEBANK,CLNUMGUICHET,CLNUMCOMPTE,CLCLERIB,CLSANSPORT,
				 CLSANSASSUR,CAN_1,CAN,CLEMAIL)
select CLREP,CLCODE,isnull(CLNOM1,''),'Adresse',CLADR1,CLADR2,CLCP,CLVILLE,CLPY,CLPAYS,
				 CLPAYEUR,CLTEL1,CLTELECOP1,CLSIRET,CLNTVA,CLAPE,CLNUMCOMPTABLE,
				 CLCODEGROUPE,CLSANSTVA,CLMODEREG,CLESCOMPTE,CLLIMITE,CLASSUR,
				 CLNOMBANK,CLCODEBANK,CLNUMGUICHET,CLNUMCOMPTE,CLCLERIB,CLSANSPORT,
				 CLSANSASSUR,
				 sum(case when STAN=@an-1 then STCAFA else 0 end),
				 sum(case when STAN=@an then STCAFA else 0 end),
				 CLEMAIL
from FCL,FST
where STCL=*CLCODE
and CLSTATUS=0
and (@activite is null or CLSA = @activite)
and (@dep is null or CLCP like @dep)
and STAN between @an-1 and @an
and (@ent is null or (CLENT=@ent and STENT=@ent))
group by CLREP,CLCODE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLPAYS,
				 CLPAYEUR,CLTEL1,CLTELECOP1,CLSIRET,CLNTVA,CLAPE,CLNUMCOMPTABLE,
				 CLCODEGROUPE,CLSANSTVA,CLMODEREG,CLESCOMPTE,CLLIMITE,CLASSUR,
				 CLNOMBANK,CLCODEBANK,CLNUMGUICHET,CLNUMCOMPTE,CLCLERIB,CLSANSPORT,
				 CLSANSASSUR,CLEMAIL



insert into #CL (CLREP,CLCODE,CLNOM1,TYPEADR,CLADR1,CLADR2,CLCP,CLVILLE,CLPY,CLPAYS,
				 CLPAYEUR,CLTEL1,CLTELECOP1,CLSIRET,CLNTVA,CLAPE,CLNUMCOMPTABLE,
				 CLCODEGROUPE,CLSANSTVA,CLMODEREG,CLESCOMPTE,CLLIMITE,CLASSUR,
				 CLNOMBANK,CLCODEBANK,CLNUMGUICHET,CLNUMCOMPTE,CLCLERIB,CLSANSPORT,
				 CLSANSASSUR,CAN_1,CAN,CLEMAIL)
select CLREP,ADRCODELI,isnull(ADRNOM,''),'Livraisons',ADRADR1,ADRADR2,ADRCP,ADRVILLE,ADRPY,ADRPAYS,
				 CLPAYEUR,ADRTEL,'','','','','',
				 '',CLSANSTVA,'',CLESCOMPTE,0,0,
				 '','','','',"",CLSANSPORT,
				 CLSANSASSUR,0,0,ADRMAIL
from FADR,FCL
where CLCODE=ADRCODELI
and (@activite is null or CLSA = @activite)
and (@dep is null or CLCP like @dep)
and ADRTYPEFIC='CL'
and ADRTYPEADR='LI'
and CLSTATUS=0
and (@ent is null or (ADRCODELIENT=@ent and CLENT=@ent))


insert into #CL (CLREP,CLCODE,CLNOM1,TYPEADR,CLADR1,CLADR2,CLCP,CLVILLE,CLPY,CLPAYS,
				 CLPAYEUR,CLTEL1,CLTELECOP1,CLSIRET,CLNTVA,CLAPE,CLNUMCOMPTABLE,
				 CLCODEGROUPE,CLSANSTVA,CLMODEREG,CLESCOMPTE,CLLIMITE,CLASSUR,
				 CLNOMBANK,CLCODEBANK,CLNUMGUICHET,CLNUMCOMPTE,CLCLERIB,CLSANSPORT,
				 CLSANSASSUR,CAN_1,CAN,CLEMAIL)
select CLREP,ADRCODELI,isnull(ADRNOM,''),'Facturation',ADRADR1,ADRADR2,ADRCP,ADRVILLE,ADRPY,ADRPAYS,
				 CLPAYEUR,ADRTEL,'','','','','',
				 '',CLSANSTVA,'',CLESCOMPTE,0,0,
				 '','','','',"",CLSANSPORT,
				 CLSANSASSUR,0,0,ADRMAIL
from FADR,FCL
where CLCODE=ADRCODELI
and (@activite is null or CLSA = @activite)
and (@dep is null or CLCP like @dep)
and ADRTYPEFIC='CL'
and ADRTYPEADR='FA'
and CLSTATUS=0
and (@ent is null or (ADRCODELIENT=@ent and CLENT=@ent))


select CLREP,CLCODE,CLNOM1,TYPEADR,CLADR1,isnull(CLADR2,''),CLCP,CLVILLE,isnull(CLPY,''),isnull(CLPAYS,''),
				 (case when CLPAYEUR = 0 then 'NL'
				 	   when CLPAYEUR = 1 then 'CR'
					   when CLPAYEUR = 2 then 'MP'
					   when CLPAYEUR = 3 then 'CI'
					   else ''
				  end),
				 isnull(CLTEL1,''),isnull(CLTELECOP1,''),isnull(CLSIRET,''),
				 isnull(CLNTVA,''),isnull(CLAPE,''),CLNUMCOMPTABLE,
				 isnull(CLCODEGROUPE,''),
				 (case when CLSANSTVA = 0 then 'avec TVA'
				 	   else 'sans TVA'
				  end),
				 TRNOM,MRLIB,CLESCOMPTE,CLLIMITE,CLASSUR,
				 isnull(CLNOMBANK,''),isnull(CLCODEBANK,''),isnull(CLNUMGUICHET,''),
				 isnull(CLNUMCOMPTE,''),isnull(CLCLERIB,""),
				 (case when CLSANSPORT = 0 then ''
				 	   else 'sans frais port'
				  end),
				 (case when CLSANSASSUR = 0 then ''
				 	   else 'sans assurance'
				  end),
				 CAN_1,CAN,CLEMAIL
from #CL,FTR,FMR
where TRCODE =* CLMODEREG
and MRCODE =* TRMODE
order by CLREP,CLCODE,TYPEADR

drop table #CL

end



go

