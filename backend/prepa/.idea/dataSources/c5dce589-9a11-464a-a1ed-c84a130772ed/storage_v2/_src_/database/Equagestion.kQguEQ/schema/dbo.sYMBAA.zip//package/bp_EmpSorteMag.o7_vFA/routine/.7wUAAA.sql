/*
DROP PROCEDURE dbo.bp_EmpSorteMag
grant execute on bp_EmpSorteMag to public
*/


CREATE PROCEDURE dbo.bp_EmpSorteMag (@datedeb smalldatetime,@datefin smalldatetime,@depot char(4))


AS
begin
			
	select BPLDATE as DATE,BPLEMP as EMPL,BPLDEPOT as DEPOT,BPLQTE as QUANTITE,BPLARTICLE as ARTICLE from FBPL 
	where BPLDATE between @datedeb and @datefin  and BPLDEPOT=@depot
	group by BPLDATE,BPLDEPOT,BPLARTICLE
	
end
go

