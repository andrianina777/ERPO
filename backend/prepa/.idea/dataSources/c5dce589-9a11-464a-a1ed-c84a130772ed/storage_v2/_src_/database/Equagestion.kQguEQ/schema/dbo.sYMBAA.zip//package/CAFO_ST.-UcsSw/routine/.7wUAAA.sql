


/* Procedure renvoyant les chiffres d''affaires, qtes livrees par les fournisseurs
	et commandes pour les annees N-2, N-1, annee en cours */

create procedure CAFO_ST	 (	@fourn	char(12),
					   			@An 	smallint,
							 	@depart		tinyint = null,
							 	@grfam		tinyint = null,
							 	@marque		tinyint = null,
							 	@famille	tinyint = null,
								@article	tinyint = null)
with recompile
as
begin

 set arithabort numeric_truncation off

if (@depart is null) and (@grfam is null) and (@marque is null)
	and (@famille is null) and (@article is null) 
select @grfam = 1

create table #Finale
(
CODE	char(15)		not null,
LIB		varchar(80)		null,
QteFAN2	int				null,
CAFAN2	numeric(14,2)	null,
QteFAN1	int				null,
CAFAN1	numeric(14,2)	null,
QteFAN0	int				null,
CAFAN0	numeric(14,2)	null,
QteCCN0	int				null,
CACCN0	numeric(14,2)	null,
DEPART	char(8)			null,
CATEG	char(8)			null,
MARQUE	char(12)		null,
FAM		char(8)			null,
CHEF	char(8)			null
)

set forceplan on

if isnull(@depart,0) > 0
begin
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARDEPART,''),isnull(DTLIB,''),
		 isnull(sum(case when STBLAN=@An-2 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-2 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLPA else 0 end),0),
		 0,0,isnull(ARDEPART,''),'','','',''
  from FSTBL,FAR,FDT
  where ARCODE=STBLART and ARTYPE in (0,1)
  and DTCODE=ARDEPART
  and STBLFO=@fourn
  and STBLAN >= @An-2
  group by ARDEPART,DTLIB
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARDEPART,''),isnull(DTLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCFQTE),0),
		 isnull(sum((CFLTOTALHT/CFLQTE)*RCFQTE),0),
		 isnull(ARDEPART,''),'','','',''
  from FRCF,FAR,FDT,FCFL
  where ARCODE = RCFARTICLE
  and ARTYPE in (0,1)
  and CFLSEQ = RCFSEQ
  and DTCODE = ARDEPART
  and RCFFO = @fourn
  and RCFAN >= @An-2
  group by ARDEPART,DTLIB

end
else if isnull(@grfam,0) > 0
begin
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARGRFAM,''),isnull(GFNOM,''),
		 isnull(sum(case when STBLAN=@An-2 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-2 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLPA else 0 end),0),
		 0,0,'',isnull(ARGRFAM,''),'','',''
  from FSTBL,FAR,FGF
  where ARCODE=STBLART and ARTYPE in (0,1)
  and GFCODE=ARGRFAM
  and STBLFO=@fourn
  and STBLAN >= @An-2
  group by ARGRFAM,GFNOM
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARGRFAM,''),isnull(GFNOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCFQTE),0),
		 isnull(sum((CFLTOTALHT/CFLQTE)*RCFQTE),0),
		 '',isnull(ARGRFAM,''),'','',''
  from FRCF,FAR,FGF,FCFL
  where ARCODE = RCFARTICLE
  and ARTYPE in (0,1)
  and CFLSEQ = RCFSEQ
  and GFCODE = ARGRFAM
  and RCFFO = @fourn
  and RCFAN >= @An-2
  group by ARGRFAM,GFNOM
  

end
else if isnull(@marque,0) > 0
begin

  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARFO,''),isnull(FONOM,''),
		 isnull(sum(case when STBLAN=@An-2 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-2 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLPA else 0 end),0),
		 0,0,'','',isnull(ARFO,''),'',''
  from FSTBL,FAR,FFO
  where ARCODE=STBLART and ARTYPE in (0,1)
  and FOCODE=ARFO
  and STBLFO=@fourn
  and STBLAN >= @An-2
  group by ARFO,FONOM
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARFO,''),isnull(FONOM,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCFQTE),0),
		 isnull(sum((CFLTOTALHT/CFLQTE)*RCFQTE),0),
		 '','',isnull(ARFO,''),'',''
  from FRCF,FAR,FFO,FCFL
  where ARCODE = RCFARTICLE
  and ARTYPE in (0,1)
  and CFLSEQ = RCFSEQ
  and FOCODE = ARFO
  and RCFFO = @fourn
  and RCFAN >= @An-2
  group by ARFO,FONOM

end
else if isnull(@famille,0) > 0
begin

  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARFAM,''),isnull(FPLIB,''),
		 isnull(sum(case when STBLAN=@An-2 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-2 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLPA else 0 end),0),
		 0,0,'','','',isnull(ARFAM,''),''
  from FSTBL,FAR,FFP
  where ARCODE=STBLART and ARTYPE in (0,1)
  and FPCODE=ARFAM
  and STBLFO=@fourn
  and STBLAN >= @An-2
  group by ARFAM,FPLIB
  
  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARFAM,''),isnull(FPLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCFQTE),0),
		 isnull(sum((CFLTOTALHT/CFLQTE)*RCFQTE),0),
		 '','','',isnull(ARFAM,''),''
  from FRCF,FAR,FFP,FCFL
  where ARCODE = RCFARTICLE
  and ARTYPE in (0,1)
  and CFLSEQ = RCFSEQ
  and FPCODE = ARFAM
  and RCFFO = @fourn
  and RCFAN >= @An-2
  group by ARFAM,FPLIB

end
else if isnull(@article,0) > 0
begin

  insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARCODE,''),isnull(ARLIB,''),
		 isnull(sum(case when STBLAN=@An-2 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-2 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An-1 then STBLPA else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLQTE else 0 end),0),
		 isnull(sum(case when STBLAN=@An then STBLPA else 0 end),0),
		 0,0,isnull(ARDEPART,''),isnull(ARGRFAM,''),isnull(ARFO,''),
		 isnull(ARFAM,''),isnull(ARCHEFP,'')
  from FSTBL,FAR
  where ARCODE=STBLART and ARTYPE in (0,1)
  and STBLFO=@fourn
  and STBLAN >= @An-2
  group by ARDEPART,ARGRFAM,ARFO,ARFAM,ARCODE,ARLIB,ARCHEFP
  
   insert into #Finale (CODE,LIB,QteFAN2,CAFAN2,QteFAN1,CAFAN1,QteFAN0,CAFAN0,
  						QteCCN0,CACCN0,DEPART,CATEG,MARQUE,FAM,CHEF)
  select isnull(ARCODE,''),isnull(ARLIB,''),
		 0,0,0,0,0,0,
		 isnull(sum(RCFQTE),0),
		 isnull(sum((CFLTOTALHT/CFLQTE)*RCFQTE),0),
		 isnull(ARDEPART,''),isnull(ARGRFAM,''),isnull(ARFO,''),
		 isnull(ARFAM,''),isnull(ARCHEFP,'')
  from FRCF,FAR,FCFL
  where ARCODE = RCFARTICLE
  and ARTYPE in (0,1)
  and CFLSEQ = RCFSEQ
  and RCFFO = @fourn
  and RCFAN >= @An-2
  group by ARDEPART,ARGRFAM,ARFO,ARFAM,ARCODE,ARLIB,ARCHEFP

end

set forceplan off

	
select CODE,LIB,sum(QteFAN2),sum(CAFAN2),sum(QteFAN1),sum(CAFAN1),sum(QteFAN0),sum(CAFAN0),
  						sum(QteCCN0),sum(CACCN0),DEPART,CATEG,MARQUE,FAM,CHEF
from #Finale
group by CODE,LIB,DEPART,CATEG,MARQUE,FAM,CHEF
order by LIB


drop table #Finale

end

go

