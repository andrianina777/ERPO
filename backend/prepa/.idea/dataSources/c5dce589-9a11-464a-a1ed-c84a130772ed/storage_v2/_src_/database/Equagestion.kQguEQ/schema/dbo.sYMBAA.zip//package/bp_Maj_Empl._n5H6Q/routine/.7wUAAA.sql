/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_Maj_Empl
grant execute on bp_Maj_Empl to public
*/

CREATE PROCEDURE dbo.bp_Maj_Empl(@article char(15),@depot char(4),@emplOld char(8),@ssemplOld char(8),@emplNew char(8),@ssemplNew char(8))

AS
begin
	declare @xAreligne int,
			@xSeq int,
			@pick int,
			@recep int
		
	if((@depot='GROS') and (select count(*) from xEMP_DIGUEL where xARTICLE=@article  and xEMPL=@emplOld and xDEPOTL=@depot)=0)
	begin
		select @pick=isnull(AREPICK,0),@recep=isnull(ARERECEP,0) from VIEW_FARE where AREDEPOT=@depot and AREAR=@article and upper(AREEMP)=upper(@emplOld)
		delete from FARE where AREDEPOT=@depot and AREAR=@article and upper(AREEMP)=upper(@emplOld)
		delete from FARE where AREDEPOT=@depot and AREAR=@article and upper(AREEMP)=upper(@emplNew)

	end
	else
	begin
		select @pick=isnull(AREPICK,0),@recep=isnull(ARERECEP,0) from VIEW_FARE where AREDEPOT=@depot and AREAR=@article and upper(AREEMP)=upper(@emplOld) and upper(ARESSEMP)=upper(@ssemplOld) 
		delete from FARE where AREDEPOT=@depot and AREAR=@article and rtrim(upper(AREEMP))=upper(@emplOld) and upper(ARESSEMP)=upper(@ssemplOld) 
		delete from FARE where AREDEPOT=@depot and AREAR=@article and upper(AREEMP)=upper(@emplNew) and upper(ARESSEMP)=upper(@ssemplNew)

	end
	

		
	select @xAreligne=0
	select @xSeq=0

	select @xAreligne=ARELIGNE from FARE where AREAR=@article
    select @xAreligne=@xAreligne+1
    exec eq_GetSeq_proc 'FARE', 1, @xSeq output  
    insert into FARE (ARESEQ,AREEMP,AREAR,AREDEPOT,AREPICK,ARERECEP,ARELIGNE,AREVALID,ARESSEMP) values 
    (@xSeq,@emplOld,@article,@depot,0,0,@xAreligne,0,@ssemplOld)

    
   
    
    select @xAreligne=0
	select @xSeq=0

	select @xAreligne=ARELIGNE from FARE where AREAR=@article
    select @xAreligne=@xAreligne+1
    exec eq_GetSeq_proc 'FARE', 1, @xSeq output 
  
    insert into FARE (ARESEQ,AREEMP,AREAR,AREDEPOT,AREPICK,ARERECEP,ARELIGNE,AREVALID,ARESSEMP) values 
    (@xSeq,@emplNew,@article,@depot,@pick,@recep,@xAreligne,1,@ssemplNew)

    
	
   
end
go

