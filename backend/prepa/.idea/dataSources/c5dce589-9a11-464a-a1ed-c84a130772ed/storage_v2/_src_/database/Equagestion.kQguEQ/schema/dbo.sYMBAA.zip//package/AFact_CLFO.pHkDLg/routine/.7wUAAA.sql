


create procedure AFact_CLFO
with recompile
as
begin
	
	set arithabort numeric_truncation off


	set nocount on
	
	declare @date 		smalldatetime,
			@TotBE		numeric(14,2),
			@TotBL		numeric(14,2),
			@TotRF		numeric(14,2),
			@TotFO		numeric(14,2),
			@text1		varchar(20),
			@text2		varchar(20),
			@text3		varchar(20),
			@text4		varchar(20)
	
	select @date = getdate()
	
	/***** Total BE - Clients - *****/
	
	select @TotBE = isnull(sum(BELTOTALHT),0)
	from FBEL,FRBE
	where RBESEQ=BELSEQ
	and RBEARTICLE != ""
	and RBEDEMO = 0
	and RBESTADE in (2,3)
	and isnull(BELOFFERT,0) = 0
	and isnull(BELDOTATION,0) = 0
	

	/***** Total BL - Fournisseurs - *****/

	select @TotBL = isnull(sum(BLTOTALHT),0)
	from FBL
	where BLFACT = 0
	
	
	/***** Total RF - Fournisseurs - *****/

	select @TotRF = isnull(-sum(RFTOTALHT),0)
	from FRF
	where RFFACT = 0
	
	/***** Total Fournisseurs - *****/

	select @TotFO = @TotBL + @TotRF
	


	/***** Formatage de l''affichage *****/


	select @text1   = convert(varchar(20),@TotBE),
		   @text2	= convert(varchar(20),@TotBL),
		   @text3	= convert(varchar(20),@TotRF),
		   @text4	= convert(varchar(20),@TotFO)
	
	exec Milliers @text1 output
	exec Milliers @text2 output
	exec Milliers @text3 output
	exec Milliers @text4 output
	
	
	print "---- BE Clients a facturer au  %1!",@date
	print ""
	print " %1!",@text1
	print ""
	print ""
	
	
	print "---- BL Fournisseurs a facturer au  %1!",@date
	print ""
	print " %1!",@text2
	print ""
	print ""
	
	
	print "---- RF Fournisseurs a facturer au  %1!",@date
	print ""
	print " %1!",@text3
	print ""
	print ""
	
	
	print "---- Total Fournisseurs a facturer au  %1!",@date
	print ""
	print " %1!",@text4
	print ""
	print ""
	
	
end



go

