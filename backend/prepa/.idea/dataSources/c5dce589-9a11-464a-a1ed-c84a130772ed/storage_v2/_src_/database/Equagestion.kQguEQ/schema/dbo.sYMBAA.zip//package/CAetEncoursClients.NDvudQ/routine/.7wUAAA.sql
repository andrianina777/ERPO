



create procedure CAetEncoursClients (@activite	char(6)	= null)
with recompile
as
begin

declare @code			char(12),
		@numcomptable	char(12),
		@basecomptable	varchar(30),
		@pastedu		numeric(14,2),
		@encourstotal	numeric(14,2),
		@encours		numeric(14,2),
		@requete		varchar(255)

select @basecomptable = PCOMPTA from KParam


create table #Clients
(
CLCODE			char(12)	not null,
CLNOM1			varchar(35)		null,
CLADR1			varchar(50)		null,
CLADR2			varchar(50)		null,
CLCP			varchar(12)		null,
CLVILLE			varchar(30)		null,
CLSIRET			char(14)		null,
CLNTVA			char(14)		null,
CLNUMCOMPTABLE	char(12)		null,
CLSA			char(6)			null,
CLLIMITE		numeric(14,2)	null,
CA_1			numeric(14,2)	null,
CA				numeric(14,2)	null,
ENCOURS			numeric(14,2)	null
)

insert into #Clients (CLCODE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLSIRET,CLNTVA,CLNUMCOMPTABLE,CLSA,CLLIMITE,CA_1,CA,ENCOURS)
select CLCODE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLSIRET,CLNTVA,CLNUMCOMPTABLE,CLSA,CLLIMITE,
		sum(case when STAN=datepart(yy,getdate())-1 then STCAFA else 0 end),
		sum(case when STAN=datepart(yy,getdate()) then STCAFA else 0 end),
		0
from FCL,FST
where STCL=CLCODE
and STAN between datepart(yy,getdate())-1 and datepart(yy,getdate())
and (@activite is null or CLSA = @activite)
group by CLCODE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLSIRET,CLNTVA,CLNUMCOMPTABLE


declare boucle cursor
for
select CLCODE,CLNUMCOMPTABLE
from #Clients
for read only

open boucle

fetch boucle into @code,@numcomptable

while (@@sqlstatus=0)
begin

select @requete = @basecomptable + "..EncoursRiv_Out"

execute @requete @numcomptable,@pastedu output,@encourstotal output, @encours output

update #Clients
set ENCOURS = @encours
where CLCODE = @code

fetch boucle into @code,@numcomptable

end

close boucle
deallocate cursor boucle

select CLCODE,CLNOM1,CLADR1,CLADR2,CLCP,CLVILLE,CLSIRET,CLNTVA,CLNUMCOMPTABLE,CLSA,CLLIMITE,CA_1,CA,ENCOURS
from #Clients
order by CLCODE


end



go

