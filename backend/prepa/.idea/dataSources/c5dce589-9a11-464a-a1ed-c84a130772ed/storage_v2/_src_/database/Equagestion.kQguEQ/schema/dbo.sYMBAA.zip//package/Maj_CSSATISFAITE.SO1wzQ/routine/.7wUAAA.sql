



create procedure Maj_CSSATISFAITE 	(@commande	char(10),
					 				 @ent		char(5) = null)
with recompile
as
begin

  	declare @seq			int,
		@qte			int,
		@reste			int,
		@lignes			int,
		@satisfaite		int,
		@nonlivre		int,
		@artype			tinyint
		  
  	select 	@satisfaite = 0,
  	 	@nonlivre = 0
  
  	select @lignes=count(*) from FCSL
  	where CSLCODE=@commande
  	and isnull(CSLENT,'')=isnull(@ent,'')
/* -------------------------------------------------------------------------------------------*/    
  	if @lignes > 0
  	begin
  
		declare commande cursor 
		for select CSLSEQ,CSLQTE,CSLRESTE
		from FCSL,FAR
		where CSLARTICLE=ARCODE
		and CSLCODE=@commande
		and isnull(CSLENT,'')=isnull(@ent,'')
		and ARTYPE in (0,1)
		for read only
	
		open commande
	
		fetch commande
		into @seq,@qte,@reste
	
		while (@@sqlstatus = 0)
		begin
		
			if @satisfaite = 0
		  	begin
		  		if @reste <= 0 select @satisfaite = 2
				else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
				else select @nonlivre = 1
		  	end
		
			else
			if @satisfaite = 2
		  	begin
		  		if @qte = @reste select @satisfaite = 1
				else if (@qte > @reste) and (@reste > 0) select @satisfaite = 1
		  	end
		
			fetch commande
			into @seq,@qte,@reste
		
		end
	
		close commande
		deallocate cursor commande
	
		if (@satisfaite = 2) and (@nonlivre = 1)
		select @satisfaite = 1	
	
		update FCS set CSSATISFAITE = @satisfaite
		where CSCODE=@commande
  		and isnull(CSENT,'')=isnull(@ent,'')
  
  	end
/* -------------------------------------------------------------------------------------------*/  
  	else if @lignes = 0
  	begin
  
		update FCS set CSSATISFAITE = 2
		where CSCODE=@commande
  		and isnull(CSENT,'')=isnull(@ent,'')
  
  	end
/* -------------------------------------------------------------------------------------------*/
end



go

