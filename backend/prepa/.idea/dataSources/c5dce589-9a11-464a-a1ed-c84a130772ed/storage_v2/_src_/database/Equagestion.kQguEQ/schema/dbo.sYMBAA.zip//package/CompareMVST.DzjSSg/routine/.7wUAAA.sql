


/* Procedure permettant de comparer les mouvements de stock enregistres (FMOIS)
	avec les mouvements de stock */

create procedure CompareMVST   (@An			smallint)
with recompile
as
begin


declare	@date		datetime


select @date=convert(datetime,"12/31/"+convert(char(4),@An))


create table #StockPrec
(
ArticleP	char(15)	not null,
QteP		int				null
)

create table #StockAn
(
Article		char(15)	not null,
Qte			int				null
)

create table #StockMois
(
ArticleM	char(15)	not null,
QteM		int				null
)

/* ''Stock initial - Fluctuations - Fichier SIL'' */

insert into #StockPrec
select SILARTICLE,sum(SILQTE)
from FSIL
where SILDATE <= @date
group by SILARTICLE


/* ''Reajustements - Fichier RJL'' */

insert into #StockPrec
select RJLARTICLE,sum(RJLQTE)
from FRJL
where RJLDATE <= @date
group by RJLARTICLE


/* ''Reajustements des mouvements - Fichier RM'' */

insert into #StockPrec
select RMARTICLE,sum(RMQTE)
from FRM
where RMDATE <= @date
group by RMARTICLE


/* ''Bordereaux de livraisons Fournisseurs - Fichier BLL'' */

insert into #StockPrec
select BLLAR,sum(BLLQTE)
from FBLL
where BLLDATE <= @date
group by BLLAR


/* ''Sorties de douanes & entrees magasin - Fichier DOL'' */

insert into #StockPrec
select DOLAR,sum(DOLQTE)
from FDOL
where DOLDATE <= @date
group by DOLAR


/* ''Retour des marchandises vers Fournisseurs - Fichier RFL'' */

insert into #StockPrec
select RFLARTICLE,-sum(RFLQTE)
from FRFL
where RFLDATE <= @date
group by RFLARTICLE


/* ""Lignes de BE - Fichier FBEL"" */

insert into #StockPrec
select BELARTICLE,-sum(BELQTE)
from FBEL
where BELDATE <= @date
group by BELARTICLE


/* Stock reconstitue */

insert into #StockAn (Article, Qte)
select ArticleP,sum(isnull(QteP,0))
from #StockPrec
group by ArticleP


drop table #StockPrec

create unique clustered index article on #StockAn (Article)

/* Insertion dans #StockMois des lignes stockees de decembre de l''annee concernee */

insert into #StockMois (ArticleM, QteM)
select MOISARTICLE, sum(MOISQTE)
from FMOIS
where MOISANNEE=@An
and MOISMOIS=12
group by MOISARTICLE

create unique clustered index article on #StockMois (ArticleM)

/* Visualisation des differences */

select Code_article=Article, Qte_reconstituee=Qte, Qte_indiquee=0
from #StockAn
where Qte != 0
and not exists (select * from #StockMois
				where ArticleM=#StockAn.Article)

union

select Article, Qte, QteM
from #StockAn, #StockMois
where Article=ArticleM
and Qte != QteM
order by Article

drop table #StockAn
drop table #StockMois

end



go

