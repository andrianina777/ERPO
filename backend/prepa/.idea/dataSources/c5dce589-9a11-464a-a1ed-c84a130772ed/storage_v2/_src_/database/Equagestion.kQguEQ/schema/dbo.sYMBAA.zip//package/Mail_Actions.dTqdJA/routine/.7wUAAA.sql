


create procedure Mail_Actions  (@rep		char(8)	= null,
								@nbjours	int = 7	)
with recompile
as
begin

declare @date1	datetime,
		@date2	datetime
		
select 	@date1 = convert(datetime,convert(char(2),datepart(mm,getdate()))+"/"+convert(char(2),datepart(dd,getdate()))+"/"+convert(char(4),datepart(yy,getdate())))
select 	@date2 = dateadd(dd,@nbjours,getdate())
select 	@date2 = convert(datetime,convert(char(2),datepart(mm,@date2))+"/"+convert(char(2),datepart(dd,@date2))+"/"+convert(char(4),datepart(yy,@date2)))



select "Actions a mener entre le ", convert(varchar,@date1,103), " et le ", convert(varchar,@date2,103)


select Code_Representant=CLVREP,Date_Action=convert(varchar(15),CLVDATE,103),Code_Action=CLVACTION,Libelle_Action=ACTDES,Commentaire=CLVCOM
from FCLV, FREP, FACT
where CLVREP=RECODE and CLVACTION=ACTCODE
and isnull(REEMAIL,'')<>''
and (@rep is null or @rep = CLVREP)
and CLVDATE between @date1 and @date2
order by CLVREP,CLVDATE,CLVACTION

end

go

