
CREATE PROCEDURE dbo.TotalFact(	@ent	char(5) = null,
							@code 	char(10),
						   	@date	datetime
						  )
with recompile
as
begin


/* Modification le 04-01-08 par SP : suite ajout notion preference traitement escompte au niveau du BE : on recupere FATAUXESC et non pas CLTAUXESC */
/* pm : FATAUXESC a la val de BEESCOMPTE si VPREFESCOMPTE=1 sinon il a la val de CLESCOMPTE (voir code dans EFactAuto)*/


set arithabort numeric_truncation off


 /* Lignes facturees a totaliser */
 
 declare @client		char(12)
 declare @tr1			char(20)			/* type de reglement de l'echeance nÂ° 1 */
 declare @exo			tinyint			/* variable indiquant si le client est exonere de TVA */
 declare @TauxEscompte	real			/* % de l'escompte de la facture */
 declare @clfact		char(12)		/* client facture	 */
 declare @site			int				/* numero de site du client */


select @site=KISITE from KInfos

select @exo=CLSANSTVA
from FCL,FFA
where CLCODE=FACL
and FACODE=@code
and (@ent is null or (CLENT=@ent and FAENT=@ent))

select @tr1=CLMODEREG,@TauxEscompte=FATAUXESC,@clfact=FACLFACT
from FCL,FFA
where CLCODE=FACLFACT
and FACODE=@code
and (@ent is null or (CLENT=@ent and FAENT=@ent))

	
if @TauxEscompte is null
	select @TauxEscompte=0
	

create table #Lignes
(
FALTOTALHT		numeric(14,2)		null,
TVTAUX			real				null,
TVSANSESC		tinyint				null,
TVCOMPTETVA		char(12)			null,
MTESCOMPTE		numeric(14,2)		null
)

	insert into #Lignes
	select FALTOTALHT,TVLTAUXTVA,TVSANSESC,TVLCOMPTETVA,
		MTESCOMPTE=round(FALTOTALHT*@TauxEscompte*(1-TVSANSESC),2)
	from FFAL, FCL, FTV, FTVL
	where FALCODE=@code and CLCODE=@clfact
	and TVCODE=TVLCODE and TVLCLASSE=CLCLASSE and TVLCODE=FALTYPEVE
	and (@ent is null or (FALENT=@ent and CLENT=@ent and TVLENT=@ent))

	
 /* faire tous les calculs avec	(FALTOTALHT-MTESCOMPTE) */
 
 	select TVCOMPTETVA,TVTAUX,TotalLigneHT=round(sum(FALTOTALHT-MTESCOMPTE),2),
			Taxe=round(sum(FALTOTALHT-MTESCOMPTE)*(TVTAUX/100),2)
	into #Taxes
	from #Lignes
	group by TVCOMPTETVA,TVTAUX
	
	
	select TVTAUX,TotalHT=round(sum(TotalLigneHT),2),
			TotalTaxe=round(sum(Taxe),2),TypeTaxe=0
	into #LesTaxes
	from #Taxes
	group by TVTAUX
	
	
 /* Mise en place des taux de TVA des differents articles */
	
	declare @taux		real			/* rubrique de test du taux de TVA */
	declare @basetaxe1	numeric(14,2)	/* base taxee de la TVA 1 */
	declare @basetaxe2	numeric(14,2)	/* base taxee de la TVA 2 */
	declare @basetaxe3	numeric(14,2)	/* base taxee de la TVA 3 */
	declare @tauxtaxe1	real			/* taux de la taxe 1 */
	declare @tauxtaxe2	real			/* taux de la taxe 2 */
	declare @tauxtaxe3	real			/* taux de la taxe 3 */
	declare @typetaxe1	char(10)		/* nom de la taxe 1 */
	declare @typetaxe2	char(10)		/* nom de la taxe 2 */
	declare @typetaxe3	char(10)		/* nom de la taxe 3 */
	declare @maxtot		numeric(14,2)	/* variable de test */
	declare @num		tinyint			/* rubrique de numerotation des taxes */
	select  @num=0
	
	select @taux=max(TVTAUX)
	from #LesTaxes
	
	while @taux is not null
		begin	
			select @num=@num+1
			update #LesTaxes set TypeTaxe=@num where TVTAUX=@taux
			if @num=1
				begin
					select @tauxtaxe1=@taux
					select @typetaxe1='TVA 1'
				end
			if @num=2
				begin
					select @tauxtaxe2=@taux
					select @typetaxe2='TVA 2'
				end
			if @num=3
				begin
					select @tauxtaxe3=@taux
					select @typetaxe3='Autres'
				end
			
			select @taux=max(TVTAUX)
			from #LesTaxes
			where TVTAUX<@taux
		end
		
		if @tauxtaxe1 is null
		select @tauxtaxe1=0
		
		if @tauxtaxe2 is null
		select @tauxtaxe2=0
		
		if @tauxtaxe3 is null
		select @tauxtaxe3=0
		
		if @typetaxe1 is null
		select @typetaxe1=''
		
		if @typetaxe2 is null
		select @typetaxe2=''
		
		if @typetaxe3 is null
		select @typetaxe3=''
	
 /* Calculs des totaux escomptables et non escomptables */	
	
	declare @TotEsc numeric(14,2)				/* total escomptable */
	declare @TotNonEsc numeric(14,2)			/* total non escomptable */
	select @TotEsc=round(sum(FALTOTALHT),2)
	from #Lignes
	where TVSANSESC=0
	
	if @TotEsc is null
		select @TotEsc=0
	
	select @TotNonEsc=round(sum(FALTOTALHT),2)
	from #Lignes
	where TVSANSESC=1
	
	if @TotNonEsc is null
		select @TotNonEsc=0
	
 /* Calcul et repartition des taxes */	
	
	
	declare @taxe1		numeric(14,2)			/* total de la taxe 1 */
	declare @taxe2		numeric(14,2)			/* total de la taxe 2 */
	declare @taxe3		numeric(14,2)			/* total de la taxe 3 */
	declare @totalht	numeric(14,2)			/* total HT */
	declare @netapayer	numeric(14,2)			/* net a payer */
	declare @escompte	numeric(14,2)			/* total escompte */
	declare @sanstva	tinyint
	select @sanstva=0
	
	
	if @exo=1
	  begin
			select @sanstva=1
			select @tauxtaxe1=0
			select @tauxtaxe2=0
			select @tauxtaxe3=0
			select @basetaxe1=0
			select @basetaxe2=0
			select @basetaxe3=0
			select @taxe1=0
			select @taxe2=0
			select @taxe3=0
			select @escompte=round(sum(MTESCOMPTE),2) from #Lignes
			select @totalht=round(sum(TotalHT),2) from #LesTaxes
			select @netapayer=@totalht
			select @typetaxe1='Exoneree'
			select @typetaxe2=''
			select @typetaxe3=''
			
	  end
	else
	  begin
	
		  select @sanstva=0
		  
		  select @basetaxe1=TotalHT,@taxe1=TotalTaxe
		  from #LesTaxes
		  where TypeTaxe=1
		  
		  
		  select @basetaxe2=TotalHT,@taxe2=TotalTaxe
		  from #LesTaxes
		  where TypeTaxe=2
		  
		  
		  select @basetaxe3=round(sum(TotalHT),2),@taxe3=round(sum(TotalTaxe),2)
		  from #LesTaxes
		  where TypeTaxe>2
		  
		  select @escompte=round(sum(MTESCOMPTE),2) from #Lignes
		  select @totalht=isnull(@basetaxe1,0)+isnull(@basetaxe2,0)+isnull(@basetaxe3,0)
		  select @netapayer=@totalht+isnull(@taxe1,0)+isnull(@taxe2,0)+isnull(@taxe3,0)
		  
		  
	  end
	
 /* Calcul des echeances */	
	
	declare @modereg1	tinyint				/* mode de reglement */
	declare @trdate1	datetime			/* date de reglement de l'echeance nÂ° 1 */
	declare @regle1		numeric(14,2)		/* total a regler pour l'echeance nÂ° 1 */
	declare @pc1		real				/* % du TTC a regler pour l'echeance nÂ° 1 */
	declare @trdec		int					/* jours de decalage de l'echeance */
	declare @trtypeech	tinyint				/* type d'echeance */
	declare @trjourech	tinyint				/* jour de l'echeance */
 	declare @nombre		int					/* variable pour decalage en mois entiers */
 	
	select  @pc1=100
	select  @regle1=@netapayer
	
	
	select @trdec=TRDEC,@trtypeech=TRTYPEECH,@trjourech=TRJOURECH,@modereg1=TRMODE
	from FTR
	where TRCODE=@tr1

	if (@regle1<0 and @site=-1)				/* conserver pour eventuel client special */
	
	begin
		select @tr1=PTRAVOIR from KParam where (@ent is null or PENT=@ent)
		select @trdate1=@date
	end
	
	else
	
	begin
	
	select @nombre = @trdec
	exec modulo @nombre output,30
	
	if @trtypeech=0
		begin
			
			if @nombre <> 0
				select @trdate1=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate1=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
			
			select @trdate1=convert(smalldatetime,convert(char(4),datepart(mm,@trdate1))
									+'/1/'+convert(char(4),datepart(yy,@trdate1)))
			select @trdate1=dateadd(dy,-1,@trdate1)
		end
		
	if @trtypeech=1
		begin
			
			if @nombre <> 0
				select @trdate1=dateadd(mm,1,dateadd(dy,@trdec,@date))
			else
				select @trdate1=dateadd(mm,1,dateadd(mm,@trdec/30,@date))
				
			select @trdate1=convert(smalldatetime,convert(char(4),datepart(mm,@trdate1))
				+'/'+convert(char(2),@trjourech)+'/'+convert(char(4),datepart(yy,@trdate1)))
		end
		
	if @trtypeech=2
		begin
			
			if @nombre <> 0
				select @trdate1=dateadd(dy,@trdec,@date)
			else
				select @trdate1=dateadd(mm,@trdec/30,@date)
		end
	if @trtypeech=4 /*quinzaine*/
		begin
		      declare @jour int,@debutMois smalldatetime,@finMois smalldatetime,@debutMoisProchain smalldatetime
		      select @jour=day(@date)
		      exec x_DateDebutMois @date,@debutMois output
		      exec x_DateFinMois @debutMois,@finMois output
		      
		      select @debutMoisProchain=dateadd(dy,1,@finMois)
		      
		      if (@jour>=1 and @jour<=15)
		      begin
		              if(@trdec=0)/*paiement le15*/
		              begin
		                      select @trdate1=dateadd(dy,15+@trdec-1,@debutMois) 
		              end
		              if(@trdec=15) /*paiement fin du mois*/
		              begin
		                      select @trdate1=@finMois
		              end
		              if(@trdec=30)/*paiement le 15 du mois prochian*/
		              begin
		                      select @trdate1=dateadd(dy,15,@finMois) 
		              end
		      end
		      else
		      begin
		             /* select @debutMois=dateadd(dd,15,@debutMois) 
		              
		              select @trdate1=dateadd(dy,15+@trdec,@debutMois)
*/

		              if(@trdec=0)/*paiement fin du mois*/
		              begin
		                      --select @trdate1=dateadd(dy,15+@trdec,@debutMois) 
		                      select @trdate1=@finMois
		              end
		              if(@trdec=15) /*paiement le 15 du mois prochain*/
		              begin
		                      select @trdate1=dateadd(dy,15,@finMois) 
		              end
		              if(@trdec=30)/*paiement fin du mois prochian*/
		              begin
		                      exec x_DateFinMois @debutMoisProchain,@finMois output
		                      select @trdate1=@finMois
		              end


		      end
			
		end

	end
		
 /* mise a jour de la facture concernee */
 
 	update FFA set FATOTALHT=@totalht,FATAUXESC=@TauxEscompte,FAESCOMPTE=@escompte,
			FATYPETAXE1=@typetaxe1,FATYPETAXE2=@typetaxe2,FATYPETAXE3=@typetaxe3,
			FATAUXTAXE1=@tauxtaxe1,FATAUXTAXE2=@tauxtaxe2,FATAUXTAXE3=@tauxtaxe3,
			FABASETAXE1=isnull(@basetaxe1,0),
			FABASETAXE2=isnull(@basetaxe2,0),
			FABASETAXE3=isnull(@basetaxe3,0),
			FANETAPAYER=@netapayer,FASANSTVA=@sanstva,
			FATAXE1=isnull(@taxe1,0),
			FATAXE2=isnull(@taxe2,0),
			FATAXE3=isnull(@taxe3,0),
			FATOTESC=@TotEsc,FATOTNONESC=@TotNonEsc,
			FATR1=@tr1,FAMODEREG1=@modereg1,FATRDATE1=@trdate1,FAPC1=@pc1,FAREGL1=@regle1
	where FACODE=@code		
	and (@ent is null or FAENT=@ent)
	
		
drop table #Lignes
drop table #Taxes
drop table #LesTaxes

end
go

