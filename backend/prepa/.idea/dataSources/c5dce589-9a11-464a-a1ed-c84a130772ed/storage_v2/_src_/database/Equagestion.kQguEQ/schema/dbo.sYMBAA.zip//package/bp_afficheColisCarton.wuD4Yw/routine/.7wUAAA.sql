/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheColisCarton
grant execute on bp_afficheColisCarton to public
*/

CREATE PROCEDURE dbo.bp_afficheColisCarton(@CC char(10),@BP char(10)=null,@COLIS int=null )

AS
begin
		select BPLARTICLE as ARTICLE,ARLIB as LIBELLE,BPCC as CODE_CC,BPCODE as CODE_BP,xIndex as NUMERO_COLIS,BPLQTE as QUANTITE from FBPL inner join FBP on BPCODE=BPLCODE left join FCC on CCCODE=BPCC
	left join DBSUIVI..xpColis on xCode=BPCODE left join VIEW_FAR_TOUS on ARCODE=BPLARTICLE where (BPCC='' or @CC=null or BPCC=@CC)
	and (BPCODE='' or @BP=null or BPCODE=@BP) and (@COLIS=null or xIndex=@COLIS) order by xIndex

end
go

