
create procedure Convert_devises (@devorg		char(3), 					/* devise origine */							 	
							  	  @valeurorg	numeric(14,2),				/* valeur en devises d'origine */
								  @courspivot	numeric(16,10) = null,		/* cours pivot de la devise */
							  	  @devfinale	char(3), 					/* devise de sortie */
							  	  @valeurfinal	numeric(14,2) output		/* valeur en devises de sortie */
							  	  )						
with recompile
as
begin

set arithabort numeric_truncation off

if @devorg = @devfinale
	begin
		select @valeurfinal = @valeurorg
		return(0)
	end

declare	@cours	numeric(16,10),
		@val_3	numeric(14,3)
		
select @cours=DECOURSPIVOT
from FDE
where DECODE=@devorg

if isnull(@cours,0)=0
  begin
	select @valeurfinal=0
	return (0)
  end
  
execute Conversion_div_proc @valeurorg,@cours,3,@val_3 output

/*
select @cours=DECOURSPIVOT
from FDE
where DECODE=@devfinale

if isnull(@cours,0)=0
  begin
	select @valeurfinal=0
	return (0)
  end
*/  

select @valeurfinal = round(@val_3 * @courspivot,2)
  
end
go

