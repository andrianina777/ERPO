


create procedure StockCAFourn(@ent			char(5)	 = null,
							  @Datedeb		datetime,
							  @Datefin		datetime,
							  @depart		char(8)  = null,
							  @Marque		char(12) = null)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Stock
(
depart_ST	char(8)		not null,
Marque_ST	char(12)	not null,
Article_ST	char(15)	not null,
Qte_ST		int				null,
PR_ST		numeric(14,2)	null,
Ventes		int				null,
CA			numeric(14,2)	null,
Ratio		numeric(14,2)	null,
Marge		numeric(14,2)	null,
PRVT		numeric(14,2)	null
)

create table #Far
(
ARDEPART		char(8)			null,
ARFO			char(12)		null,
ARCODE			char(15)		null,
ARLIB			varchar(80)		null,
CVLOT			int				null
)


if (@Marque is null)
	begin
		insert into #Far (ARDEPART,ARFO,ARCODE,ARLIB,CVLOT)
		select ARDEPART,ARFO,ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARUNITACHAT=CVUNIF
		and (@depart is null or ARDEPART=@depart)
	end
else
	begin
		insert into #Far (ARDEPART,ARFO,ARCODE,ARLIB,CVLOT)
		select ARDEPART,ARFO,ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFO=@Marque
		and ARUNITACHAT=CVUNIF
		and (@depart is null or ARDEPART=@depart)
	end


create unique clustered index code on #Far(ARCODE)


insert into #Stock (depart_ST,Marque_ST,Article_ST,Qte_ST,PR_ST,Ventes,CA,Ratio,Marge,PRVT)
select ARDEPART,ARFO,ARCODE,sum(STQTE),sum(round(((STPAHT+STFRAIS)/CVLOT),2)*STQTE),
		0,0.00,0.00,0.00,0.00
from #Far,FSTOCK,FDP
where ARCODE=STAR
and STQTE > 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,ARFO,ARCODE



insert into #Stock (depart_ST,Marque_ST,Article_ST,Qte_ST,PR_ST,Ventes,CA,Ratio,Marge,PRVT)
select ARDEPART,ARFO,ARCODE,0,0,sum(FALQTE),sum(FALTOTALHT),0,0,sum(round((STPAHT+STFRAIS)/CVLOT,2)*FALQTE)
from #Far,FFAL,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALDATE between @Datedeb and @Datefin
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,ARFO,ARCODE


insert into #Stock (depart_ST,Marque_ST,Article_ST,Qte_ST,PR_ST,Ventes,CA,Ratio,Marge,PRVT)
select ARDEPART,ARFO,ARCODE,0,0,sum(BELQTE),sum(BELTOTALHT),0,0,sum(round((STPAHT+STFRAIS)/CVLOT,2)*BELQTE)
from #Far,FBEL,FBE,FSTOCK,FDP
where BELDATE between @Datedeb and @Datefin
and ARCODE=BELARTICLE
and BELARTICLE=STAR
and BELLETTRE=STLETTRE
and BELRESTE!=0
and BELCODE=BECODE
and BEDEMO=0
and DPCODE=STDEPOT and (@ent is null or (BELENT=@ent and BEENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,ARFO,ARCODE

drop table #Far

select Departement=depart_ST,Fournisseur=Marque_ST,
	Qte_en_Stock=sum(Qte_ST),
	Prix_de_revient=sum(PR_ST),
	Ventes=sum(Ventes),
	Ca_realise=sum(convert(numeric(14,2),CA)),
	Ratio=convert(numeric(14,2),sum(CA)/((sum(PR_ST)+(1-abs(sign(sum(PR_ST))))))),
	Marge=round(((sum(CA)-sum(PRVT)*(abs(sign(sum(CA))))+(1-abs(sign(sum(CA)))))
			/(sum(CA)+(1-abs(sign(sum(CA))))))*100,2)
from #Stock
group by depart_ST,Marque_ST
order by depart_ST,Marque_ST
compute sum(sum(Qte_ST)),sum(sum(PR_ST)),sum(sum(Ventes)),sum(sum(convert(numeric(14,2),CA))) by depart_ST
compute sum(sum(Qte_ST)),sum(sum(PR_ST)),sum(sum(Ventes)),sum(sum(convert(numeric(14,2),CA)))

drop table #Stock

end



go

