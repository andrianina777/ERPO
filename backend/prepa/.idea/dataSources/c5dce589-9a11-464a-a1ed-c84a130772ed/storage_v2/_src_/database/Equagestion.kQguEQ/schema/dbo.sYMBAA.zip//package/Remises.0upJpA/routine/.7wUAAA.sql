


create procedure Remises (@ent	char(5)	= null,
						  @an	smallint)
as
begin

create table #Finale
(
annee		smallint	not null,
marque		char(12)	not null,
famille		char(8)		not null,
client		char(12)	not null,
clnom		varchar(35)	not null,
clrem1		real			null,
clrem2		real			null,
clrem3		real			null,
clRFA		real			null,
groupe		char(12)	not null,
grrem1		real			null,
grrem2		real			null,
grrem3		real			null,
grRFA		real			null
)


create table #Groupe
(
annee		smallint	not null,
marque		char(12)	not null,
famille		char(8)		not null,
groupe		char(12)	not null,
grrem1		real			null,
grrem2		real			null,
grrem3		real			null,
grRFA		real			null
)


insert into #Finale (annee,marque,famille,client,clnom,clrem1,clrem2,clrem3,clRFA,
						groupe,grrem1,grrem2,grrem3,grRFA)
select RCAN,RCFO,RCFAM,RCCL,CLNOM1,RCR1,RCR2,RCR3,RCRFA,
		(case when CLTYPECLI=2 then CLCODEGROUPE else "" end),0,0,0,0
from FRC,FCL
where RCCL=CLCODE
and (RCAN=@an or RCAN=0)
and CLTYPECLI in (0,2)
and (@ent is null or (RCENT=@ent and CLENT=RCENT))



insert into #Groupe (annee,marque,famille,groupe,grrem1,grrem2,grrem3,grRFA)
select RCAN,RCFO,RCFAM,RCCL,RCR1,RCR2,RCR3,RCRFA
from FRC,FCL
where RCCL=CLCODE
and (RCAN=@an or RCAN=0)
and CLTYPECLI = 1
and (@ent is null or (RCENT=@ent and CLENT=RCENT))


update #Finale
set #Finale.grrem1=#Groupe.grrem1,
	#Finale.grrem2=#Groupe.grrem2,
	#Finale.grrem3=#Groupe.grrem3,
	#Finale.grRFA=#Groupe.grRFA
from #Groupe
where #Finale.groupe=#Groupe.groupe
and #Finale.annee=#Groupe.annee
and #Finale.marque=#Groupe.marque
and #Finale.famille=#Groupe.famille


/* inserer les lignes de remises des groupes absentes de #Final avec les clients de ces groupes */


insert into #Finale (annee,marque,famille,client,clnom,clrem1,clrem2,clrem3,clRFA,
						groupe,grrem1,grrem2,grrem3,grRFA)
select #Groupe.annee,#Groupe.marque,#Groupe.famille,CLCODE,CLNOM1,0,0,0,0,
		groupe,grrem1,grrem2,grrem3,grRFA
from #Groupe,FCL
where CLCODEGROUPE=groupe
and CLTYPECLI = 2
and not exists (select * from #Finale where #Finale.groupe=#Groupe.groupe and #Finale.client=FCL.CLCODE)
and (@ent is null or CLENT=@ent)


select annee,marque,famille,client,clnom,clrem1,clrem2,clrem3,clRFA,
						groupe,CLNOM1,grrem1,grrem2,grrem3,grRFA
from #Finale,FCL
where CLCODE=groupe
and (@ent is null or CLENT=@ent)
order by client,annee,marque,famille


drop table #Groupe
drop table #Finale

end



go

