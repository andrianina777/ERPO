


/* Cette procedure permet de constater les ecarts d''inventaire 
		sur une famille	- obsolete car remplacee par EcartsSelect */

create procedure EcartsFam(	@code_inv		char(8),
							@date_photo		datetime,
						    @famille		char(8),
							@code_photo		char(16))
with recompile
as
begin

create table #ecarts
(
article		char(15)	not null,
lettre		char(4)		not null,
qte_inv		int			not null,
qte_stock	int			not null
)

create table #final
(
article		char(15)	not null,
lettre		char(4)		not null,
qte_inv		int			not null,
qte_stock	int			not null
)


insert into #ecarts (article,lettre,qte_inv,qte_stock)
select INSAR,"",sum(INSQTE),0
from FINS,FAR
where ARCODE=INSAR
and ARFAM =@famille
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=0
and INSCODE=@code_inv
group by INSAR

insert into #ecarts (article,lettre,qte_inv,qte_stock)
select PSAR,"",0,sum(PSQTE)
from FPS,FAR
where ARCODE=PSAR
and ARFAM =@famille
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=0
and PSDATE=@date_photo
and PSCODE=@code_photo
group by PSAR


insert into #ecarts (article,lettre,qte_inv,qte_stock)
select INSAR,INSLETTRE,sum(INSQTE),0
from FINS,FAR
where ARCODE=INSAR
and ARFAM =@famille
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=1
and INSCODE=@code_inv
group by INSAR,INSLETTRE

insert into #ecarts (article,lettre,qte_inv,qte_stock)
select PSAR,PSLETTRE,0,sum(PSQTE)
from FPS,FAR,FDP
where ARCODE=PSAR
and DPCODE=PSDEPOT
and ARFAM =@famille
and DPLOC != 0
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=1
and PSDATE=@date_photo
and PSCODE=@code_photo
group by PSAR,PSLETTRE

insert into #ecarts (article,lettre,qte_inv,qte_stock)
select PSAR,"",0,sum(PSQTE)
from FPS,FAR,FDP
where ARCODE=PSAR
and DPCODE=PSDEPOT
and ARFAM =@famille
and DPLOC=0
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=1
and PSDATE=@date_photo
and PSCODE=@code_photo
group by PSAR

insert into #final (article,lettre,qte_inv,qte_stock)
select article,lettre,sum(qte_inv),sum(qte_stock)
from #ecarts
group by article,lettre

drop table #ecarts


select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock
from #final,FAR
where ARCODE=article
and qte_inv != qte_stock
order by ARFO,ARFAM,article,lettre


drop table #final

end



go

