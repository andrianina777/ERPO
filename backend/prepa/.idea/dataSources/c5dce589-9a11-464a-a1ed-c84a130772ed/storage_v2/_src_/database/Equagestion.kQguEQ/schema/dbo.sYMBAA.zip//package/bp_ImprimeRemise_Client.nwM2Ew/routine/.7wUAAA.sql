/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_ImprimeRemise_Client
grant execute on bp_ImprimeRemise_Client to public

*/

CREATE PROCEDURE bp_ImprimeRemise_Client (@code char(10),@etat int)
with recompile
AS
begin
	 declare @dateRemise smalldatetime,@moisfr varchar(25),@clientIP varchar(25)
	 
	 select @dateRemise= DATE_REMISE from DBSUIVI..REMISE_CLIENT where CODE=@code
	 exec Equagestion..bp_dateToFr @dateRemise,@moisfr output
	
	 select  CLIENT,NOM_FICHE,CODE,
	 @moisfr +'_'+datename(yy,DATE_REMISE),CA,convert(varchar,convert(numeric(14,2),TAUX_ACCORDE))+'%' as TAUX,VAL_REMISE,VAL_MALUS,VAL_BONUS,isnull(VAL_REMISE_REELLE,0) as TOTAL_REMISE,
	CLADR1||' '||CLADR2 as ADRS,CLSTAT,CLNIF,CLCORRES1,TYPE,case when isnull(CL2_PAIEMENT_RFM,0)=1 then 'PAIEMENT PAR CHEQUE' 
	when  isnull(CL2_PAIEMENT_RFM,0)=2 then 'PAIEMENT PAR CHEQUE AU NOM DE '|| CL2_NOM_CHEQUE
	when isnull(CL2_PAIEMENT_RFM,0)=0 then 'PAIEMENT PAR NOTE DE CREDIT' end
	
	from DBSUIVI..REMISE_CLIENT inner join Equagestion..FCL on CLCODE=CLIENT 
	inner join Equagestion..FCL2 on CL2CODE=CLIENT 
	where CODE=@code
	
	select @clientIP=ipaddr from master..sysprocesses where spid=@@spid 
	
	update DBSUIVI..REMISE_CLIENT set xPRINT=@etat,DATE_PRINT=getdate(), IP_PRINT=@clientIP,USER_PRINT=(select user_name(user_id())) where  CODE=@code and isnull(xPRINT,0)=0

	
end
go

