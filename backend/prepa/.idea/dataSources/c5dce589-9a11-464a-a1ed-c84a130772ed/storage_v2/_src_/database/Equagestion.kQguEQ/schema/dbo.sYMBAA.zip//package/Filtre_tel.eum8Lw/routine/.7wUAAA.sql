



create procedure Filtre_tel	(@tel_in	varchar(25),
							 @tel_out	varchar(25)		output
							)
with recompile
as
begin

  declare @longueur tinyint
  declare @boucle	tinyint

  select @longueur=datalength(@tel_in)
  select @boucle=1
  select @tel_out=null
  
  while @boucle<=@longueur
  begin
  
  	if substring(@tel_in,@boucle,1) in ("0","1","2","3","4","5","6","7","8","9")
		select @tel_out=@tel_out+substring(@tel_in,@boucle,1)

  
  select @boucle=@boucle+1
  
  end
  
  if @tel_out is null
  select @tel_out=""

end



go

