



create procedure Suivi_CA (	@ent		char(5)	 = null,
							@an			smallint,
							@marque		char(12) = null,
							@rep		char(8) = null,
							@pays		char(8) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @labase		varchar(30),
		@lignes		int
		
select  @labase = db_name()
select 	@lignes = 0

dump tran @labase with truncate_only

create table #Finale
(
seq			numeric(14,0)	identity,
entete		varchar(40)		not null,
annee		smallint		not null,
janvier		int					null,
fevrier		int					null,
mars		int					null,
avril		int					null,
mai			int					null,
juin		int					null,
juillet		int					null,
aout		int					null,
septembre	int					null,
octobre		int					null,
novembre	int					null,
decembre	int					null,
total		int					null
)

declare @type	tinyint
select  @type=RETYPE from FREP where RECODE=@rep

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos

	
insert into #Finale (entete,annee,janvier,fevrier,mars,avril,mai,juin,juillet,aout,
					septembre,octobre,novembre,decembre,total)
select "CA par mois",@an,
		isnull(sum(case	when STAN=@an and STMOIS = 1 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 2 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 3 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 4 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 5 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 6 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 7 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 8 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 9 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 10 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 11 then STCAFA else 0 end),0),
		isnull(sum(case	when STAN=@an and STMOIS = 12 then STCAFA else 0 end),0),
		isnull(sum(case when STAN=@an then STCAFA else 0 end),0)
from FST,FAR,FCL
where START=ARCODE
and STAN = @an
and ARCODE=START
and CLCODE=STCL
and (@rep is null or @type = 2 or STREP=@rep)
and (@rep is null or @type != 2 or STREPDIV=@rep)
and (@marque is null or ARFO=@marque)
and (@pays is null or CLPY=@pays)
and (@multient=0 or @ent is null or (STENT=@ent and CLENT=STENT))
	

insert into #Finale (entete,annee,janvier,fevrier,mars,avril,mai,juin,juillet,aout,
					septembre,octobre,novembre,decembre,total)
select	"Reliquats de commandes",@an,
		0,0,0,0,0,0,0,0,0,0,0,0,
		isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0)
from FRCC,FCCL,FAR,FCL,FCC
where (RCCAN < @an or (RCCAN = @an and RCCMOIS between 1 and datepart(mm,getdate())))
and CCLSEQ=RCCSEQ
and CLCODE=RCCCL
and ARCODE=RCCARTICLE
and CCCODE=CCLCODE
and (@rep is null or @type = 2 or CCLREP=@rep)
and (@rep is null or @type != 2 or CCLREPDIV=@rep)
and (@marque is null or ARFO=@marque)
and (@pays is null or CLPY=@pays)
and (@multient=0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))

if @type != 2
begin
  insert into #Finale (entete,annee,janvier,fevrier,mars,avril,mai,juin,juillet,aout,
					  septembre,octobre,novembre,decembre,total)
  select	"Expeditions non facturees",@an,
		  0,0,0,0,0,0,0,0,0,0,0,0,
		  isnull(sum(BELTOTALHT),0)
  from FRBE,FBEL,FAR,FCL
  where BELSEQ=RBESEQ
  and CLCODE=RBECL
  and ARCODE=RBEARTICLE
  and RBEDEMO=0
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@pays is null or CLPY=@pays)
  and (@multient=0 or @ent is null or (RBEENT=@ent and BELENT=RBEENT and CLENT=RBEENT))
end
else if @type = 2
begin
  insert into #Finale (entete,annee,janvier,fevrier,mars,avril,mai,juin,juillet,aout,
					  septembre,octobre,novembre,decembre,total)
  select	"Expeditions non facturees",@an,
		  0,0,0,0,0,0,0,0,0,0,0,0,
		  isnull(sum(BELTOTALHT),0)
  from FRBE,FBEL,FAR,FCL,FCLR
  where BELSEQ=RBESEQ
  and CLCODE=RBECL
  and CLRCL=CLCODE
  and ARCODE=RBEARTICLE
  and RBEDEMO=0
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@pays is null or CLPY=@pays)
  and (@multient=0 or @ent is null or (RBEENT=@ent and BELENT=RBEENT and CLENT=RBEENT))
end



select "entete","annee","janvier","fevrier","mars","avril","mai","juin","juillet","aout",
					"septembre","octobre","novembre","decembre","total"


select entete,annee,janvier,fevrier,mars,avril,mai,juin,juillet,aout,
					septembre,octobre,novembre,decembre,total
from #Finale

drop table #Finale


end



go

