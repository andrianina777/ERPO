


create procedure Photo_FEXL_insert
	@CODE		char(10),		/* code lien EXCODE */
	@CL			varchar(7),		/* code client (7) */
	@NUMCOLIS	int,
	@POIDS		real,
	@CC			char(10),
	@COLISUIV	varchar(15)		/* identifiant chronopost */

/* creee le 29/07/2006 par xmp
   modifiee le       par  
   
   creation d''une ligne d''expedition selon fichier recapitulatif quotidien Chronopost */
   
as 
begin
	/* sequentiel */
	declare @seq int
	execute eq_GetSeq_proc 'FEXL', 1, @seq output
	if @@error != 0
		return
	
	/* insertion */
	insert into FEXL (EXLSEQ,EXLCODE,EXLTRANSP,EXLCL,EXLFRANCO,
		EXLNUMCOLIS,EXLPOIDS,EXLBE,EXLENT,EXLCOLISUIV)
	values (@seq,@CODE,'CHRONOPO',@CL,1,
		@NUMCOLIS,@POIDS,@CC,'FR',@COLISUIV)
end



go

