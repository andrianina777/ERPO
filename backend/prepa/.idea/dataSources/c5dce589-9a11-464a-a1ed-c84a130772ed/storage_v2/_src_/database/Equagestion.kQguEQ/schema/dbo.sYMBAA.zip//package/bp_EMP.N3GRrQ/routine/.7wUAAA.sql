/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_EMP
grant execute on bp_EMP to public
*/

CREATE PROCEDURE bp_EMP( @dep char(4))
with recompile
AS
begin


 	 
 	 create table #EMPL(
 	 	m_dep char(4),
 	 	m_emp char(8),
 	 	m_local char(15)
 	 )
 	 

 
 	  	insert into #EMPL select distinct xDepot,xEmp,'Ankorondrano' from xEMP where xDepot=@dep order by xDepot,xEmp
 	  	insert into #EMPL select distinct xDEPOT,xALLE,'DIG' from xEMP_DIGUE where xDEPOT=@dep order by xDEPOT,xALLE
 	
 	  
	 
	 
	 select m_dep,m_emp,m_local from #EMPL
	 
	 drop table #EMPL
	 
	 	
end
go

