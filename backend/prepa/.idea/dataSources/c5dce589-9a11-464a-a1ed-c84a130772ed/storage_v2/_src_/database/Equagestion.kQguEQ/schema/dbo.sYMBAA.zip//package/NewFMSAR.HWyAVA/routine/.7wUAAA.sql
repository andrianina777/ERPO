


create procedure NewFMSAR (@Article	char(15))
with recompile
as
begin

declare @lot	smallint,
		@an		smallint,
		@date	datetime
		
select @an=datepart(yy,getdate())
select @date=convert(datetime,"01/01/"+convert(varchar(4),@an-1))

select @lot=CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARCODE=@Article



select Article=SILARTICLE,Annee=datepart(yy,SILDATE),Mois=datepart(mm,SILDATE),
Total=sum(SILQTE),PrixRevientTot=sum(round(((SILPAHT+SILFRAIS)/@lot),2)*SILQTE),Type='F',
Depot=SILNUMDEP
into #Entree
from FSIL
where SILARTICLE=@Article
and SILDATE >= @date
group by SILARTICLE,datepart(yy,SILDATE),datepart(mm,SILDATE),SILNUMDEP
having sum(SILQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),
sum(RJLQTE),sum(round(((RJLPAHT+RJLFRAIS)/@lot),2)*RJLQTE),'R',RJLNUMDEP
from FRJL
where RJLARTICLE=@Article
and RJLDATE >= @date
group by RJLARTICLE,datepart(yy,RJLDATE),datepart(mm,RJLDATE),RJLNUMDEP
having sum(RJLQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),
sum(LCLQTE),sum(round(((LCLPAHT+LCLFRAIS)/@lot),2)*LCLQTE),'C',LCLNUMDEP
from FLCL
where LCLARTICLE=@Article
and LCLDATE >= @date
group by LCLARTICLE,datepart(yy,LCLDATE),datepart(mm,LCLDATE),LCLNUMDEP
having sum(LCLQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),
sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE),'A',ASLNUMDEP
from FASL
where ASLARTICLE=@Article
and ASLDATE >= @date
group by ASLARTICLE,datepart(yy,ASLDATE),datepart(mm,ASLDATE),ASLNUMDEP
having sum(ASLQTE)!=0


insert into #Entree (Article,Annee,Mois,Total,PrixRevientTot,Type,Depot)
select RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),
sum(RMQTE),sum(round(((RMPAHT+RMFRAIS)/@lot),2)*RMQTE),'M',RMNUMDEP
from FRM
where RMARTICLE=@Article
and RMDATE >= @date
group by RMARTICLE,datepart(yy,RMDATE),datepart(mm,RMDATE),RMNUMDEP
having sum(RMQTE)!=0


insert into #Entree
select BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),
sum(BLLQTE),sum(round(((BLLPRHT)/@lot),2)*BLLQTE),'E',BLLNUMDEP
from FBLL
where BLLAR=@Article
and BLLDATE >= @date
group by BLLAR,datepart(yy,BLLDATE),datepart(mm,BLLDATE),BLLNUMDEP
having sum(BLLQTE)!=0


insert into #Entree
select DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),
sum(DOLQTE),sum(round(((DOLPRHT)/@lot),2)*DOLQTE),'E',DOLNUMDEP
from FDOL
where DOLAR=@Article
and DOLDATE >= @date
group by DOLAR,datepart(yy,DOLDATE),datepart(mm,DOLDATE),DOLNUMDEP



insert into #Entree
select RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),
-(sum(RFLQTE)),-(sum(round(((RFLPAHT)/@lot),2)*RFLQTE)),'E',RFLNUMDEP
from FRFL
where RFLARTICLE=@Article
and RFLDATE >= @date
group by RFLARTICLE,datepart(yy,RFLDATE),datepart(mm,RFLDATE),RFLNUMDEP
having sum(RFLQTE)!=0



/* insert into #Entree	*/
/* select BELARTICLE,datepart(yy,BELDATE),datepart(mm,BELDATE), */
/* sum(BELQTE),sum(((STPAHT+STFRAIS)/@lot)*BELQTE),''B'',1 */
/* from FBEL,FSTOCK */
/* where BELARTICLE=STAR */
/* and BELLETTRE=STLETTRE */
/* and BELARTICLE=@Article */
/* and BELDATE >= @date */
/* group by BELARTICLE,datepart(yy,BELDATE),datepart(mm,BELDATE) */
/* having sum(BELQTE)!=0 */


insert into #Entree
select FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE),
sum(FALQTE),sum(round(((STPAHT+STFRAIS)/@lot),2)*FALQTE),'S',1
from FFAL,FSTOCK
where FALARTICLE=STAR
and FALLETTRE=STLETTRE
and FALARTICLE=@Article
and FALDATE >= @date
group by FALARTICLE,datepart(yy,FALDATE),datepart(mm,FALDATE)
having sum(FALQTE)!=0

delete FMS
where MSARTICLE=@Article
and MSANNEE >= (@an-1)


insert into FMS(MSARTICLE,MSANNEE,MSMOIS,MSQTE,MSTOTPR,MSTYPE,MSDEPOT)
select Article,Annee,Mois,QteTot=sum(Total),PrixTot=sum(PrixRevientTot),Type,Depot
from #Entree
group by Article,Annee,Mois,Type,Depot
order by Article,Annee,Mois,Type,Depot

drop table #Entree

end



go

