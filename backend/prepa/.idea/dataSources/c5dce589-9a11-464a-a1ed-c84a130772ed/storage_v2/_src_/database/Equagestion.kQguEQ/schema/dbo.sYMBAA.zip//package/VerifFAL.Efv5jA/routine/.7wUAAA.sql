


/* Cette procedure permet de verifier que toutes les lignes de BE
	ont bien ete facturees */
	
	
create procedure VerifFAL  (@ent		char(5)	= null,
							@datedeb	datetime,
							@datefin	datetime)
with recompile
as
begin

set arithabort numeric_truncation off


create table #Final
(
clientBE	char(12)			null,
article		char(15)			null,
codeBE		char(10)		null,
ligneBE		int				null,
dateBE		datetime		null,
qteBE		int				null,
prixBE		numeric(14,2)	null,
clientFA	char(12)		null,
codeFA		char(10)		null,
ligneFA		int				null,
qteFA		int				null,
prixFA		numeric(14,2)	null
)

create table #Bel
(
client		char(12)		null,
article		char(15)		null,
BE			char(10)		null,
ligne		int				null,
date		datetime		null,
qte			int				null,
prix		numeric(14,2)	null
)


insert into #Bel (client,article,BE,ligne,date,qte,prix)
select client=BELCL,article=BELARTICLE,BE=BELCODE,ligne=BELNUM,
			date=BELDATE,qte=BELQTE,prix=BELTOTALHT
from FBEL
where BELDATE between @datedeb and @datefin
and BELARTICLE not in ('PORTASSU','COMMENTS','MAGASIN')
and BELDEMO=0
and (@ent is null or BELENT=@ent)


create unique index codelien on #Bel(BE,ligne)


insert into #Final (clientBE,article,codeBE,ligneBE,dateBE,qteBE,prixBE,clientFA,
							codeFA,ligneFA,qteFA,prixFA)
select client,article,BE,ligne,date,qte,prix,
		FALCL,FALCODE,FALNUM,FALQTE,FALTOTALHT
from #Bel,FFAL
where FALLIENCODE=BE
and FALLIENNUM=ligne
and ((FALQTE!=qte) or (FALTOTALHT!=prix))
and (@ent is null or FALENT=@ent)



insert into #Final (clientBE,article,codeBE,ligneBE,dateBE,qteBE,prixBE)
select client,article,BE,ligne,date,qte,prix
from #Bel
where not exists (select * from FFAL 
					where FALLIENCODE=#Bel.BE 
					and FALLIENNUM=#Bel.ligne
					and (@ent is null or FALENT=@ent)
)

drop table #Bel



select 'Code client BE','Article','Designation','Code BE',
	'Ligne BE','Date BE','Qte BE','Prix HT BE','Code client livre FA',
	'Code FA','Ligne FA','Qte FA','Prix HT FA','Difference Qtes','Differences Prix'

select clientBE,article,ARLIB,codeBE,ligneBE,dateBE,qteBE,prixBE,
		clientFA,codeFA,ligneFA,qteFA,prixFA,
		difqte=qteBE-qteFA,difprix=prixBE-prixFA
from #Final,FAR
where ARCODE=article
order by dateBE

drop table #Final

end



go

