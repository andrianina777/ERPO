


/* Procedure calculant la Rotation du stock de mois a mois donne pour l''annee choisie
	a partir des lignes de mouvement de stock */


create procedure Rotation  (@an				int,
							@moisdeb		int,
							@moisfin		int,
							@depart			char(8)	= null,
							@marque			char(12) = null,
							@famille		char(8) = null,
							@article		char(15) = null,
							@rot1			numeric(14,2) = null,
							@rot2			numeric(14,2) = null)
with recompile
as
begin

set arithabort numeric_truncation off

if @moisfin < @moisdeb	return(0)

declare @mois	int,
		@spid	int

select 	@mois = @moisfin-@moisdeb+1,
		@spid = @@spid


delete from FROTATION where ROTSPID = @spid


create table #Far
(
ARCODE		char(15)	not null,
ARLIB		char(80)		null,
ARUNIT		int			not null
)


create table #Stock
(
article			char(15)		not null,
mois			int				not null,
qtestock		numeric(20,8)		null,
valstock		numeric(20,8)		null,
qteventes		numeric(20,8)		null,
valventes		numeric(20,8)		null,
qterecu			numeric(20,8)		null,
valrecu			numeric(20,8)		null
)


if ((@marque is null) and (@famille is null) and (@article is null))
	begin
		insert  into #Far (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end
else if ((@marque is null) and (@famille is null) and (@article is not null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARCODE=@article
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end	
else if ((@marque is null) and (@famille is not null) and (@article is null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFAM=@famille
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end	
else if ((@marque is null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFAM=@famille
		and ARCODE=@article
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end	
else if ((@marque is not null) and (@famille is null) and (@article is null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFO=@marque
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end
else if ((@marque is not null) and (@famille is null) and (@article is not null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFO=@marque
		and ARCODE=@article
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end
else if ((@marque is not null) and (@famille is not null) and (@article is null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFO=@marque
		and ARFAM=@famille
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end
else if ((@marque is not null) and (@famille is not null) and (@article is not null))
	begin
		insert  into #Far  (ARCODE,ARLIB,ARUNIT)
		select ARCODE,ARLIB,CVLOT
		from FAR,FCV
		where ARFO=@marque
		and ARFAM=@famille
		and ARCODE=@article
		and ARTYPE=0
		and CVUNIF=ARUNITACHAT
		and (isnull(@depart,'')='' or ARDEPART=@depart)
	end
	

/* creation de toutes les lignes de mois pour les articles choisis */

declare @lemois	int
select  @lemois = @moisdeb

while @lemois <= @moisfin
begin

 insert into #Stock (article,mois,qtestock,valstock,qteventes,valventes,qterecu,valrecu)
 select ARCODE,@lemois,0,0,0,0,0,0
 from #Far
 
 select @lemois = @lemois +1

end


/* Stock au 31/12 de l''annee precedente */

insert into #Stock (article,mois,qtestock,valstock)
select MOISARTICLE,@moisdeb,sum(isnull(MOISQTE,0)),sum(isnull(MOISTOTPR,0))
from FMOIS,#Far
where ARCODE=MOISARTICLE
and MOISANNEE=@an-1
and MOISMOIS=12
and MOISQTE != 0
group by MOISARTICLE


/* Stock entre et sorti pour la periode de janvier au mois precedent la periode choisie */

if @moisdeb != 1
begin
  insert into #Stock (article,mois,qtestock,valstock)
  select MSARTICLE,@moisdeb, sum(case when MSTYPE = 'S' then isnull(-MSQTE,0)
  									  when MSTYPE != 'S' then isnull(MSQTE,0) end),
							 sum(case when MSTYPE = 'S' then isnull(-MSTOTPR,0)
  									  when MSTYPE != 'S' then isnull(MSTOTPR,0) end)
  from FMS,#Far
  where ARCODE=MSARTICLE
  and MSANNEE=@an
  and MSMOIS between 1 and @moisdeb-1
  and MSQTE != 0
  group by MSARTICLE
end


/* Stock entre et sorti pendant la periode choisie */


insert into #Stock (article,mois,qteventes,valventes,qterecu,valrecu)
select MSARTICLE,MSMOIS, sum(case when MSTYPE = 'S' then isnull(MSQTE,0)
							  	  when MSTYPE != 'S' then 0 end),
						 sum(case when MSTYPE = 'S' then isnull(MSTOTPR,0)
							  	  when MSTYPE != 'S' then 0 end),
						 sum(case when MSTYPE = 'S' then 0
							  	  when MSTYPE != 'S' then isnull(MSQTE,0) end),
						 sum(case when MSTYPE = 'S' then 0
							  	  when MSTYPE != 'S' then isnull(MSTOTPR,0) end)
from FMS,#Far
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between @moisdeb and @moisfin
and MSQTE != 0
group by MSARTICLE,MSMOIS


/* tableau recapitulatif des ventes et entres pendant la periode choisie */

insert into FROTATION (ROTAR,ROTMOIS,ROTSTDEB,ROTPRDEB,ROTVENTES,
						ROTCA,ROTQTERECU,ROTPRRECU,ROTSPID)
select article,mois,
		  sum(isnull(qtestock,0)),
		  sum(isnull(valstock,0)),
		  sum(isnull(qteventes,0)),
		  sum(isnull(valventes,0)),
		  sum(isnull(qterecu,0)),
		  sum(isnull(valrecu,0)),
		  @spid
from #Stock
group by article,mois

delete from #Stock

create table #temp
(
t_article		char(15)		not null,
t_qtedeb		int					null,
t_valdeb		numeric(14,2)		null,
t_qteventes		int					null,
t_valventes		numeric(14,2)		null,
t_qterecu		int					null,
t_valrecu		numeric(14,2)		null
)

select  @lemois = @moisdeb + 1

while @lemois <= @moisfin
begin

  insert into #temp (t_article,t_qtedeb,t_valdeb,t_qteventes,t_valventes,t_qterecu,t_valrecu)
  select ROTAR,ROTSTDEB,ROTPRDEB,ROTVENTES,ROTCA,ROTQTERECU,ROTPRRECU
  from FROTATION
  where ROTMOIS = @lemois - 1
  and ROTSPID = @spid
  
  
  update FROTATION
  set ROTSTDEB = t_qtedeb + t_qterecu - t_qteventes,
	  ROTPRDEB = t_valdeb + t_valrecu - t_valventes
  from #temp
  where ROTAR = t_article
  and ROTMOIS = @lemois
  and ROTSPID = @spid
  
  delete from #temp
   
  select @lemois = @lemois +1

end





select 	Article=ROTAR, Designation=ARLIB, Unit=ARUNIT,
		Periode=@mois,
		Qte_moyenne=convert(numeric(20,8),round(sum((((ROTSTDEB + ROTQTERECU) * 2)-ROTVENTES)/2) / @mois,8)),
		Valeur_moyenne=convert(numeric(20,8),round(sum((((ROTPRDEB + ROTPRRECU) * 2)-ROTCA)/2) / @mois,8)),
		Rotation=(case when convert(numeric(20,8),round(sum((((ROTSTDEB + ROTQTERECU) * 2)-ROTVENTES)/2),8)) != 0 
						then convert(numeric(20,8),round(sum(ROTVENTES) * @mois / sum((((ROTSTDEB + ROTQTERECU) * 2)-ROTVENTES)/2),8))
						else 0
						end),
		Taux_couverture=(case when (sum(ROTVENTES)) != 0 
							then convert(numeric(20,8),round(sum((((ROTSTDEB + ROTQTERECU) * 2)-ROTVENTES)/2) / (sum(ROTVENTES)),8))
							else convert(numeric(20,8),round(sum((((ROTSTDEB + ROTQTERECU) * 2)-ROTVENTES)/2 / @mois),8))
							end),
		Ventes_moyenne_qte=convert(numeric(20,8),round((sum(ROTVENTES)/@mois),8)),
		CA_moyen=convert(numeric(20,8),round((sum(ROTCA)/@mois),8))
into #Final
from FROTATION, #Far
where ROTAR=ARCODE
and ROTSPID=@spid
group by ROTAR,ARLIB,ARUNIT
order by ROTAR


/***** select final *****/

if (isnull(@rot1,0) = 0 and isnull(@rot2,0) = 0)
  begin
	select 	Article, Designation,
			Qte_Stock=sum(STQTE),
			Val_Stock=sum(round((STPAHT+STFRAIS)/Unit,2)*STQTE),
			Periode, Qte_moyenne, Valeur_moyenne, Rotation,
			Taux_couverture, Ventes_moyenne_qte, CA_moyen
	from #Final,FSTOCK
	where STAR=Article
	group by Article,Designation,Periode,Qte_moyenne,Valeur_moyenne,Rotation,
			Taux_couverture,Ventes_moyenne_qte,CA_moyen
	order by Article
  end
else if (isnull(@rot1,0) != 0 or isnull(@rot2,0) != 0)
  begin
	select 	Article, Designation,
			Qte_Stock=sum(STQTE),
			Val_Stock=sum(round((STPAHT+STFRAIS)/Unit,2)*STQTE),
			Periode, Qte_moyenne, Valeur_moyenne, Rotation,
			Taux_couverture, Ventes_moyenne_qte, CA_moyen
	from #Final,FSTOCK
	where STAR=Article
	and Rotation between @rot1 and @rot2
	group by Article,Designation,Periode,Qte_moyenne,Valeur_moyenne,Rotation,
			Taux_couverture,Ventes_moyenne_qte,CA_moyen
	order by Article
  end

drop table #Stock
drop table #Far
drop table #temp
drop table #Final

end



go

