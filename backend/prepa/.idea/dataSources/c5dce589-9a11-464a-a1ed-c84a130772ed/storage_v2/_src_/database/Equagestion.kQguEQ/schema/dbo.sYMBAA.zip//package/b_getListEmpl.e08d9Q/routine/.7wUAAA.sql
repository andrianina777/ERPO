/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.b_getListEmpl
grant execute on b_getListEmpl to public
*/


CREATE PROCEDURE dbo.b_getListEmpl(@cmd char(10),@Group char(20))


AS
begin
	declare @Rayon char(8),@empl char(8),@listBac varchar(50)
			
			 
	select @Rayon=''
	select @listBac=''
	
	declare liste cursor for 

	
	select rtrim(xEmp) from xEMP_CTRL where  xCC_Encours=@cmd  and isnull(xEtat,0)=1 and xGroup=@Group  order by xEmp

	open liste
    fetch liste into @empl 
    while (@@sqlstatus=0)
        begin
        if(@Rayon<>'')
       		begin
        		select @Rayon=rtrim(rtrim(@Rayon)+' - '+rtrim(@empl ))
        	end
        else
        	begin
        		select @Rayon=''+rtrim(@empl )
        	end
        fetch liste into @empl     
        end
   close liste
   deallocate cursor liste
   
   exec bp_getlistBac @cmd,@listBac output
	
	select 	(case when @Rayon='' then 'Sans Emplacement' else @Rayon end),@listBac
end
go

