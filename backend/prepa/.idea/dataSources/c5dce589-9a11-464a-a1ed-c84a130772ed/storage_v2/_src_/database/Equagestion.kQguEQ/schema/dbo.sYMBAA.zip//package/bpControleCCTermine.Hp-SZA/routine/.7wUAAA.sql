/*
    drop procedure bpControleCCTermine
    grant execute on bpControleCCTermine to public
*/
create procedure bpControleCCTermine(@cccode char(10))
as begin
    --select count(*)
    --from FBP
    --inner join FCC on CCCODE=BPCC
    --where BPCC=? and BPPREPSPECIF<3 and CCSTADE_DET>3
    
    select count(*) from FCC where CCPREPSPECIF<>3
    and CCCODE=@cccode
end
go

