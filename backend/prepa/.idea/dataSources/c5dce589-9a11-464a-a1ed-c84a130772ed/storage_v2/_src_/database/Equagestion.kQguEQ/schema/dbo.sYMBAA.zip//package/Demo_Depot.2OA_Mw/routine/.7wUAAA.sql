



create procedure Demo_Depot ( @depot		char(4),
							  @repres		char(8)
							)
with recompile
as
begin
	
declare @art	char(15)	
declare @qte	int				
declare @dte	datetime	
declare @be		char(10)	
declare @cl		char(12)	
declare @rep	char(8)		
declare @lot	int 			
declare @type 	tinyint 	
declare @pru	numeric(14,2)			
declare @prt	numeric(14,2)			
declare @lettre char(4)	


create table #depvrp
(
DepRep		char(8)			null,
Article		char(15)		null,
Quantite	int				null,
DateEntre	datetime		null,
PxRevUnit	numeric(14,2)	null,
PxRevTot	numeric(14,2)	null,
CodeBE		char(10)		null,
Client		char(12)		null,
ordre		tinyint		not null
)


/*  traitement sur le stock a partir du depot */
insert into #depvrp (DepRep,Article,Quantite,DateEntre,PxRevUnit,PxRevTot,CodeBE,Client,ordre)
select STDEPOT,STAR,STQTE,STDATEENTR,round((STPAHT+STFRAIS)/CVLOT,2),round(((STPAHT+STFRAIS)/CVLOT)*STQTE,2),'','',1
from FSTOCK,FCV,FAR
where STAR=ARCODE and STQTE<>0
and ARUNITACHAT=CVUNIF 
and STDEPOT = @depot


/*  traitement sur les bon expedition a partir du representant */

declare BonExp cursor
for
select CLREP,BELARTICLE,BELQTE,BELDATE,BELCODE,BELCL,CVLOT,ARTYPE,BELLETTRE
from FBEL,FCV,FAR,FCL,FBE,FRBE
where BELSEQ=RBESEQ
and BECODE=BELCODE
and BELCL=CLCODE
and BELARTICLE=ARCODE
and ARUNITACHAT=CVUNIF 
and isnull(BEDEMO,0)=1
and ARTYPE in (0,1)
and CLREP = @repres

open BonExp

fetch BonExp
into @rep,@art,@qte,@dte,@be,@cl,@lot,@type,@lettre

while (@@sqlstatus = 0)
begin
	
	select @pru=0,@prt=0
		
	if @type=0
		begin
			select @pru=(STPAHT+STFRAIS) from FSTOCK where STAR=@art and STLETTRE=@lettre
			select @pru=round(@pru/@lot,2)
			select @prt=round(@pru*@qte,2)
		end

	insert into #depvrp(DepRep,Article,Quantite,DateEntre,PxRevUnit,PxRevTot,CodeBE,Client,ordre)
	values (@rep,@art,@qte,@dte,@pru,@prt,@be,@cl,2)

	fetch BonExp
	into @rep,@art,@qte,@dte,@be,@cl,@lot,@type,@lettre	
		
end

close BonExp
deallocate cursor BonExp


/* select final */

select Depot_Rep=DepRep,Article=Article,Designation=ARLIB,Date=DateEntre,Code_BE=CodeBE,Client,
Quantite=sum(Quantite),Prix_revient_unitaire_HT=sum(PxRevUnit),Total_HT=sum(PxRevTot)
from #depvrp,FAR
where ARCODE=Article
group by DepRep,Article,ARLIB,DateEntre,CodeBE,Client,ordre
order by ordre,Article,DateEntre,CodeBE,Client

drop table #depvrp

end  



go

