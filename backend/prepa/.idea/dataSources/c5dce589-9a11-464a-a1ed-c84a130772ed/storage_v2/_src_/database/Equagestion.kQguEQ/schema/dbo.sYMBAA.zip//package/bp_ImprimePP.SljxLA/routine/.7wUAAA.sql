/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_ImprimePP
grant execute  on bp_ImprimePP to public
*/

CREATE PROCEDURE dbo.bp_ImprimePP (@CODEPP char(10))




as
begin

select PPCODE,PPNOM_CLIENT,PPLDEPOT,PPLEMP,PPLLOT,PPLQTE,(case when PPLDEPOT='GROS' then rtrim(rtrim(ARLIB)||' ['||rtrim(convert(char,isnull(ARFRANCOFO,0)))||']') else rtrim(ARLIB) end) as LIB into #result from x_PP
inner join x_PPL on PPLCODE=PPCODE
left join VIEW_FAR on ARCODE=PPLARTICLE
where PPCODE=@CODEPP

select PPLEMP,PPLLOT,sum(PPLQTE) as PPLQTE ,LIB from #result group by PPLEMP,PPLLOT,LIB

drop table #result
end
go

