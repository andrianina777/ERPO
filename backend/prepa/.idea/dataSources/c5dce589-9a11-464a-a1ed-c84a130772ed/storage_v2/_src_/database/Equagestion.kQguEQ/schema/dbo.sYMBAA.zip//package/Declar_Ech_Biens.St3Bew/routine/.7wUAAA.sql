


create procedure Declar_Ech_Biens (    @Mois    smallint, 
                                       @Annee   smallint, 
                                       @Flux 	tinyint
                                  ) 
with recompile 
as 
begin 
set arithabort numeric_truncation off 
 
 
create table #EXPEDITION 
( 
NOMENCLATURE 	char(16) null, 
PAYS 			char(2) null, 
VFISCALE 		int null, 
MASSE 			dec(10,3) null, 
UNITE 			char(3) null, 
MODET 			tinyint null, 
NUMTVA 			char(14) null 
) 
 
declare @article 	char(15) 
declare @lettre 	char(4) 
declare @unitAch 	tinyint 
declare @codedoua 	char(16) 
declare @pays 		char(2) 
declare @modeT 		tinyint 
declare @tva 		char(14) 
declare @qte 		int 
declare @fourn 		char(12) 
declare @paht 		dec(9,2) 
declare @lot 		int 
declare @poids 		dec(10,3) 
declare @unit 		char(3) 
declare @totalht 	dec(14,2) 
declare @fdoua 		char(16) 
declare @vfiscale 	int 
declare @vfiscaled 	dec(14,2) 
 
 
    if @Flux=1 
 
        /* ---------------*/     
        /*    Expedition      */ 
        /* ---------------*/ 
        declare CUREXPED cursor 
        for select FALARTICLE,FALLETTRE,ARUNITACHAT,ARCODEDOUA,FAPY,isnull(FAMAM,3),CLNTVA,FALQTE, 
        round(ARPOIDS,0),isnull(ARUNIT,'U'),FALTOTALHT 
        from FFA,FFAL,FPY,FCL,FAR 
        where FACODE=FALCODE and FAPY=PYCODE and FACL=CLCODE and ARCODE=FALARTICLE 
        and PYEUROPE=1 and FANETAPAYER>0 and ARTYPE in (0,1)  
        and datepart(yy,FADATE)=@Annee and datepart(mm,FADATE)=@Mois 
     
    else 
         
        /* -----------------*/     
        /*    Introduction      */ 
        /* -----------------*/ 
        declare CUREXPED cursor 
        for select BLLAR,BLLLET,ARUNITACHAT,ARCODEDOUA,BLPY,isnull(BLMAM,3),'',BLLQTE, 
        round(ARPOIDS,0),isnull(ARUNIT,'U'),BLLTOTDEV 
        from FBL,FBLL,FPY,FAR 
        where BLCODE=BLLCODE and BLPY=PYCODE and ARCODE=BLLAR 
        and PYEUROPE=1 and ARTYPE in (0,1)  
        and datepart(yy,BLDATE)=@Annee and datepart(mm,BLDATE)=@Mois 
 
     
        open CUREXPED 
        fetch CUREXPED into @article,@lettre,@unitAch,@codedoua,@pays,@modeT,@tva,@qte,@poids,@unit,@totalht 
        while (@@sqlstatus=0) 
        begin  
 
            select @fdoua='' 
            select @lot=CVLOT from FCV where CVUNIF=@unitAch 
             
            if @lettre<>'' 
                begin 
                    select @fourn=STFO,@paht=STPAHT from FSTOCK where STAR=@article and STLETTRE=@lettre 
                    select @fdoua=isnull(ARFCODEDOUA,'') from FARF where ARFFO=@fourn and ARFCODE=@article 
                    select @vfiscaled=round((@paht/@lot),2) 
                    select @vfiscale=round((@vfiscaled*@qte),0) 
                end 
                 
            insert into #EXPEDITION (NOMENCLATURE,PAYS,VFISCALE,MASSE,UNITE,MODET,NUMTVA) 
            values ((case when @fdoua='' then @codedoua  
                                                                    else @fdoua  
                                                                    end), 
            @pays, 
            (case when @fdoua='' then @totalht  
                                                    else @vfiscale 
                                                    end), 
            (case when @lettre='' then 0  
                                                        else @poids*@qte  
                                                        end), 
            @unit,@modeT,@tva) 
         
            fetch CUREXPED into @article,@lettre,@unitAch,@codedoua,@pays,@modeT,@tva,@qte,@poids,@unit,@totalht 
        end 
        deallocate cursor CUREXPED 
         
         
        if @Flux=0 
            begin 
             
            /* -----------------------*/     
            /*    Introduction suite    */ 
            /*    Traitement des FRFL      */ 
            /* -----------------------*/ 
                declare CURINTRO cursor 
                for select RFLARTICLE,RFLLETTRE,ARUNITACHAT,ARCODEDOUA,FOPY,3,'',RFLQTE, 
                round(ARPOIDS,0),isnull(ARUNIT,'U'),RFLTOTALHT 
                from FRFL,FPY,FAR,FFO 
                where FOPY=PYCODE and ARCODE=RFLARTICLE and FOCODE=RFLFO 
                and PYEUROPE=1 and ARTYPE in (0,1)  
                and datepart(yy,RFLDATE)=@Annee and datepart(mm,RFLDATE)=@Mois 
     
                open CURINTRO 
                fetch CURINTRO into @article,@lettre,@unitAch,@codedoua,@pays,@modeT,@tva,@qte,@poids,@unit,@totalht 
                while (@@sqlstatus=0) 
                begin  
 
                    select @fdoua='' 
                    select @lot=CVLOT from FCV where CVUNIF=@unitAch 
             
                    if @lettre<>'' 
                        begin 
                            select @fourn=STFO,@paht=STPAHT from FSTOCK where STAR=@article and STLETTRE=@lettre 
                            select @fdoua=isnull(ARFCODEDOUA,'') from FARF where ARFFO=@fourn and ARFCODE=@article 
                            select @vfiscaled=round((@paht/@lot),2) 
                            select @vfiscale=round((@vfiscaled*@qte),0) 
                        end 
                 
                    insert into #EXPEDITION (NOMENCLATURE,PAYS,VFISCALE,MASSE,UNITE,MODET,NUMTVA) 
                    values ((case when @fdoua='' then @codedoua  
                                                                                else @fdoua  
                                                                            end), 
                    @pays, 
                    (case when @fdoua='' then @totalht  
                                                            else @vfiscale 
                                                            end), 
                    (case when @lettre='' then 0  
                                                                else @poids*@qte  
                                                                end), 
                    @unit,@modeT,@tva) 
         
                    fetch CURINTRO into @article,@lettre,@unitAch,@codedoua,@pays,@modeT,@tva,@qte,@poids,@unit,@totalht 
                end 
                deallocate cursor CURINTRO 
         
            end 
             
             
        /* select final*/     
        
/*Adaptive Server has expanded all  *  elements in the following statement */
select #EXPEDITION.NOMENCLATURE, #EXPEDITION.PAYS, #EXPEDITION.VFISCALE, #EXPEDITION.MASSE, #EXPEDITION.UNITE, #EXPEDITION.MODET, #EXPEDITION.NUMTVA from #EXPEDITION 
     
     
end 




go

