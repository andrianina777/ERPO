


create procedure StockBE (@ent			char(5)  = null,
						  @Fournisseur	char(12) = null)
with recompile
as
begin


create table #Stock
(
Fournisseur_ST	char(12)	not null,
Famille_ST		char(8)		not null,
Article_ST		char(15)	not null,
Qte_ST			int			null,
Qte_Demo		int			null,
Qte_Be			int			null,
Qte_Totale		int			null
)

create table #Bed
(
Fournisseur_Bed	char(12)	not null,
Famille_Bed		char(8)		not null,
Article_Bed		char(15)	not null,
Qte_Bed			int			null
)

create table #Bel
(
Fournisseur_Bel	char(12)	not null,
Famille_Bel		char(8)		not null,
Article_Bel		char(15)	not null,
Qte_Bel			int			null
)

if (@Fournisseur is null)
begin
	insert into #Stock
	select ARFO,ARFAM,ARCODE,sum(STQTE),0,0,0
	from FAR,FSTOCK,FDP
	where ARCODE=STAR
	and STQTE!=0
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by ARFO,ARFAM,ARCODE
	
	insert into #Bed
	select ARFO,ARFAM,ARCODE,sum(BELQTE)
	from FAR,FBEL,FRBE
	where ARCODE=RBEARTICLE
	and BELSEQ=RBESEQ
	and RBEDEMO=1
	and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))
	group by ARFO,ARFAM,ARCODE
end
else
begin
	insert into #Stock
	select ARFO,ARFAM,ARCODE,sum(STQTE),0,0,0
	from FAR,FSTOCK,FDP
	where ARCODE=STAR
	and STQTE!=0
	and ARFO=@Fournisseur
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
	group by ARFO,ARFAM,ARCODE
	
	
	insert into #Bed
	select ARFO,ARFAM,ARCODE,sum(BELQTE)
	from FAR,FBEL,FRBE
	where ARCODE=RBEARTICLE
	and BELSEQ=RBESEQ
	and RBEDEMO=1
	and ARFO=@Fournisseur
	and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))
	group by ARFO,ARFAM,ARCODE
end


insert into #Stock
select Fournisseur_Bed,Famille_Bed,Article_Bed,0,0,0,0
from #Bed
where not exists (select * from #Stock where Article_ST=#Bed.Article_Bed)


update #Stock
set Qte_Demo=Qte_Bed
from #Bed
where Article_Bed=Article_ST

drop table #Bed


if (@Fournisseur is null)
begin
	insert into #Bel
	select ARFO,ARFAM,ARCODE,sum(BELQTE)
	from FAR,FBEL,FRBE
	where ARCODE=RBEARTICLE
	and BELSEQ=RBESEQ
	and RBEDEMO=0
	and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))
	group by ARFO,ARFAM,ARCODE
end
else
begin
	insert into #Bel
	select ARFO,ARFAM,ARCODE,sum(BELQTE)
	from FAR,FBEL,FRBE
	where ARCODE=RBEARTICLE
	and BELSEQ=RBESEQ
	and RBEDEMO=0
	and ARFO=@Fournisseur
	and (@ent is null or (RBEENT=@ent and BELENT=RBEENT))
	group by ARFO,ARFAM,ARCODE
end

insert into #Stock
select Fournisseur_Bel,Famille_Bel,Article_Bel,0,0,0,0
from #Bel
where not exists (select * from #Stock where Article_ST=#Bel.Article_Bel)


update #Stock
set Qte_Be=Qte_Bel
from #Bel
where Article_Bel=Article_ST

drop table #Bel


update #Stock
set Qte_Totale=Qte_ST+Qte_Demo+Qte_Be


select Fournisseur_ST,Famille_ST,Article_ST,ARLIB,Qte_ST,Qte_Demo,Qte_Be,Qte_Totale 
from #Stock,FAR
where ARCODE=Article_ST
order by Fournisseur_ST,Famille_ST,Article_ST
compute sum(Qte_ST),sum(Qte_Demo),sum(Qte_Be),sum(Qte_Totale) by Fournisseur_ST,Famille_ST
compute sum(Qte_ST),sum(Qte_Demo),sum(Qte_Be),sum(Qte_Totale) by Fournisseur_ST
compute sum(Qte_ST),sum(Qte_Demo),sum(Qte_Be),sum(Qte_Totale)


drop table #Stock

end



go

