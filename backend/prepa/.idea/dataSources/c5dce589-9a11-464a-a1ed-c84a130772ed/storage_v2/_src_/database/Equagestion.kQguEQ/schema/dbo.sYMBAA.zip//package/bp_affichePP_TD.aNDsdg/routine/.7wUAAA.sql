/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_affichePP_TD
grant execute  on bp_affichePP_TD to public
*/

CREATE PROCEDURE dbo.bp_affichePP_TD (@depot char(4),@article char(15),@empl varchar(25))


as
begin

select ARTICLE,ARLIB,QTE_RESTANTE,LOT,DEPOT,EMP,'','',0,CLIENT,FACTURE from VIEW_FACTURATION_RESERVE
inner join VIEW_FAR on ARCODE=ARTICLE
where (@article='' or @article=null or ARTICLE=@article)
and (@depot='' or @depot=null or DEPOT=@depot)
and (@empl='' or @empl=null or EMP=@empl)

order by DEPOT,EMP,ARTICLE,ARLIB
end
go

