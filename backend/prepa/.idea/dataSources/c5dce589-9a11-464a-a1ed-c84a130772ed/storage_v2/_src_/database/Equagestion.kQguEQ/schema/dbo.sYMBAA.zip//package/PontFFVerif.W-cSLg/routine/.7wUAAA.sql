


create procedure PontFFVerif(	@ent			char(5) = null,
								@LaDate1		datetime = null,
					  		 	@LaDate2		datetime = null,
							 	@NumFact1		char(10) = null,
							 	@NumFact2		char(10) = null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @Annee		varchar(4),
		@Mois		varchar(2),
		@Jour		varchar(2),
		@DateFact	varchar(8),
		@DateEch	varchar(8),
		@Journal	varchar(4),
		@Num		int,
		@totdebit	numeric(14,2),
		@totcredit	numeric(14,2),
		@debit		numeric(14,2),
		@credit		numeric(14,2),
		@debcre		tinyint,
		@compte		char(12),
		@lib		varchar(40),
		@lejournal	varchar(4),
		@totech		numeric(14,2),
		@foclasse	varchar(10)

select	@Num=0

					/*************** Table des differences **********/
					
create table #Dif
(
code	char(10)	not null,
lib		varchar(40)		null,
differe	numeric(14,2)		not null
)

					/*************** Table test ************/

create table #Sortie
(
journal		char(4)		null,
numcompta	char(12)	null,
date		varchar(9)	null,
num			int			null,
piece		varchar(15)	null,
lib			varchar(40)	null,
dateech		varchar(9)	null,
debit		numeric(14,2)		null,
credit		numeric(14,2)		null,
trmode		tinyint		null,
devise		char(4)		null,
mtdev		numeric(14,2)		null
)

					/************** Tables de travail *********/

create table #Factures
(
code		char(10)			not null,
coursdev	real				not null,
nom			varchar(35)				null,
date		datetime			not null,
sanstva		tinyint				not null,
totdev		numeric(14,2)		not null,
totfr		numeric(14,2)		not null,
tottvadev	numeric(14,2)		not null,
tottvafr	numeric(14,2)		not null,
netdev		numeric(14,2)		not null,
netfr		numeric(14,2)		not null,
fournis		char(12)			not null,
numcompta	char(12)			not null,
factfo		varchar(12)			not null,
devise		varchar(4)			not null,
fraisfr		numeric(14,2)		not null,
fraisdev	numeric(14,2)		not null,
tafrais		char(4)				not null,
douanesfr	numeric(14,2)		not null,
douanesdev	numeric(14,2)		not null,
tadouanes	char(4)				not null,
transfr		numeric(14,2)		not null,
transdev	numeric(14,2)		not null,
tatrans		char(4)				not null,
tvafr		numeric(14,2)		not null,
tvadev		numeric(14,2)		not null,
tatva		char(4)				not null,
foclasse	varchar(10)				null
)


create table #Lignes
(
totalhtfr		numeric(14,2)		null,
totalhtdev		numeric(14,2)		null,
comptachat		char(12)			null,
taux			real				null,
comptetva		char(12)			null
)

create table #Taxes(
comptetva	 	char(12)			null,
taux			real				null,
taxefr			numeric(14,2)		null,
taxedev			numeric(14,2)		null
)

create table #LesTaxes(
comptetva	 	char(12)			null,
totalfr			numeric(14,2)		null,
totaldev		numeric(14,2)		null
)
					/******************* Selection des factures concernees ********************/

if (@NumFact1 is null) and (@LaDate1 is not null)
begin
  insert into #Factures (code,coursdev,nom,date,sanstva,totdev,totfr,tottvadev,tottvafr,netdev,
  netfr,fournis,numcompta,factfo,devise,fraisfr,fraisdev,tafrais,douanesfr,douanesdev,tadouanes,
  transfr,transdev,tatrans,tvafr,tvadev,tatva,foclasse)
  select FFCODE,FFCDEV,FFNOM,FFDATE,FFSANSTVA,FFTOTDEV,FFTOTFR,FFTOTTVADEV,FFTOTTVAFR,
  			FFNETDEV,FFNETFR,FFFO,FONUMCOMPTABLE,FFFACTFO,FFDEVISE,FFFRAISFR,FFFRAISDEV,
			FFTAFRAIS,FFDOUAFR,FFDOUADEV,FFTADOUA,FFTRANSFR,FFTRANSDEV,FFTATRANS,
			FFTVAFR,FFTVADEV,FFTATVA,FOCLASSE
  from FFF,FFO
  where FOCODE=FFFO
  and FFDATE between @LaDate1 and @LaDate2
  and FFNETFR != 0
  and (@ent is null or FFENT=@ent)
  order by FFCODE
end
else if (@NumFact1 is not null)
begin
  insert into #Factures (code,coursdev,nom,date,sanstva,totdev,totfr,tottvadev,tottvafr,netdev,
  netfr,fournis,numcompta,factfo,devise,fraisfr,fraisdev,tafrais,douanesfr,douanesdev,tadouanes,
  transfr,transdev,tatrans,tvafr,tvadev,tatva,foclasse)
  select FFCODE,FFCDEV,FFNOM,FFDATE,FFSANSTVA,FFTOTDEV,FFTOTFR,FFTOTTVADEV,FFTOTTVAFR,
  			FFNETDEV,FFNETFR,FFFO,FONUMCOMPTABLE,FFFACTFO,FFDEVISE,FFFRAISFR,FFFRAISDEV,
			FFTAFRAIS,FFDOUAFR,FFDOUADEV,FFTADOUA,FFTRANSFR,FFTRANSDEV,FFTATRANS,
			FFTVAFR,FFTVADEV,FFTATVA,FOCLASSE
  from FFF,FFO
  where FOCODE=FFFO
  and FFCODE between @NumFact1 and @NumFact2
  and FFNETFR != 0
  and (@ent is null or FFENT=@ent)
  order by FFCODE
end
  
					/******************* Declaration des curseurs ********************/

declare facture cursor
for select code,coursdev,nom,date,sanstva,totdev,totfr,tottvadev,tottvafr,
		netdev,netfr,fournis,numcompta,factfo,devise,fraisfr,fraisdev,tafrais,
		douanesfr,douanesdev,tadouanes,transfr,transdev,tatrans,tvafr,tvadev,tatva,foclasse
from #Factures
order by code
for read only


declare @code			char(10),
		@coursdev		real,
		@nom			varchar(35),
		@date			datetime,
		@sanstva		tinyint,
		@totdev			numeric(14,2),
		@totfr			numeric(14,2),
		@tottvadev		numeric(14,2),
		@tottvafr		numeric(14,2),
		@netdev			numeric(14,2),
		@netfr			numeric(14,2),
		@fournis		char(12),
		@numcompta		char(12),
		@factfo			varchar(12),
		@devise			varchar(4),
		@fraisfr		numeric(14,2),
		@fraisdev		numeric(14,2),
		@tafrais		char(4),
		@douanesfr		numeric(14,2),
		@douanesdev		numeric(14,2),
		@tadouanes		char(4),
		@transfr		numeric(14,2),
		@transdev		numeric(14,2),
		@tatrans		char(4),
		@tvafr			numeric(14,2),
		@tvadev			numeric(14,2),
		@tatva			char(4)


declare echeances cursor
for select EFDATEECH,EFECHFR,EFMODEREG,EFECHDEV
from FEF
where EFCODE=@code
and (@ent is null or EFENT=@ent)
for read only

declare @dateech	datetime,
		@echfr		numeric(14,2),
		@modereg	tinyint,
		@echdev		numeric(14,2)


					/***************** Traitement des factures *****************/

open facture

fetch facture
into @code,@coursdev,@nom,@date,@sanstva,@totdev,@totfr,@tottvadev,
		@tottvafr,@netdev,@netfr,@fournis,@numcompta,@factfo,@devise,
		@fraisfr,@fraisdev,@tafrais,@douanesfr,@douanesdev,@tadouanes,
		@transfr,@transdev,@tatrans,@tvafr,@tvadev,@tatva,@foclasse

while (@@sqlstatus = 0)
begin
	select @Num=@Num+1
	
	select 	@Annee=convert(varchar(4),datepart(yy,@date)),
			@Mois=convert(varchar(2),datepart(mm,@date)),
			@Jour=convert(varchar(2),datepart(dd,@date))

	
	select @Journal=@lejournal
	
	if datalength(@Mois)=1
		select @Mois='0'+@Mois
	if datalength(@Jour)=1
		select @Jour='0'+@Jour
		
	select @DateFact=@Annee+@Mois+@Jour
	
						/************************ Ligne d''ecriture du compte fournisseur ******************/
	
	if @coursdev=1.00
	begin
		select 	@devise = null,
				@netdev = null
	end
	
	if @netfr>0
	begin
	  insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
	  select @Journal,@numcompta,@DateFact,@Num,@code,
			 convert(varchar(40),(@factfo+" "+@fournis+" "+@devise+" "+convert(varchar(13),@netdev))),
			 null,null,@netfr,null,@devise,@netdev
	end
	else if @netfr<0
	begin
	  insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
	  select @Journal,@numcompta,@DateFact,@Num,@code,
			 convert(varchar(40),(@factfo+" "+@fournis+" "+@devise+" "+convert(varchar(13),@netdev))),
			 null,abs(@netfr),null,null,@devise,abs(@netdev)
	end
	
						/************************ Echeances ******************/
	select @totech=0
	
	open echeances
	
	fetch echeances
	into @dateech,@echfr,@modereg,@echdev
		
	while (@@sqlstatus = 0)
	begin
		
		if (@dateech="" or @dateech is null)
		begin
			insert into #Dif (code,lib,differe)
			values (@code," date d'echeance manquante. valeur =>",@echfr)
		end
		
		select @totech = @totech + @echfr
	
		if @devise = null
			select 	@echdev = null

		
		select 	@Annee=convert(varchar(4),datepart(yy,@dateech)),
				@Mois=convert(varchar(2),datepart(mm,@dateech)),
				@Jour=convert(varchar(2),datepart(dd,@dateech))

	
		if datalength(@Mois)=1
			select @Mois='0'+@Mois
		if datalength(@Jour)=1
			select @Jour='0'+@Jour
			
		select @DateEch=@Annee+@Mois+@Jour
		
		if @echfr>0
		begin
		  insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
		  select null,null,null,null,null,null,@DateEch,null,@echfr,@modereg,@devise,@echdev
		end
		else if @echfr<0
		begin
		  insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
		  select null,null,null,null,null,null,@DateEch,abs(@echfr),null,@modereg,@devise,abs(@echdev)
		end
		
		fetch echeances
		into @dateech,@echfr,@modereg,@echdev
		
	end
		
	close echeances
	
	if @totech != @netfr
	begin
		insert into #Dif (code,lib,differe)
		values (@code," total echeances - net a payer",@totech-@netfr)
	end
		
						/**************** Lignes de la facture ***************/
		
	truncate table #Lignes
	
	insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
		select FFLTOTHT,FFLTOTDEV,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
		from FFF,FFFL,FFO, FTVL
		where FFCODE=FFLCODE and FFFO=FOCODE and TVLCODE=FFLTYPEVE and TVLCLASSE=FOCLASSE		
		and FFLTOTHT != 0
		and FFLCODE=@code
		and (@ent is null or (FFENT=@ent and FFLENT=@ent and TVLENT=@ent))
	
	if (@tafrais != "" and @fraisfr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @fraisfr,@fraisdev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tafrais
			and (@ent is null or TVLENT=@ent)

	
	if (@tadouanes != "" and @douanesfr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @douanesfr,@douanesdev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tadouanes
			and (@ent is null or TVLENT=@ent)
	
	if (@tatrans != "" and @transfr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @transfr,@transdev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tatrans
			and (@ent is null or TVLENT=@ent)
	
	if (@tatva != "" and @tvafr != 0)
		insert into #Lignes (totalhtfr,totalhtdev,comptachat,taux,comptetva)
			select @tvafr,@tvadev,TVLCPT,TVLTAUXTVA,TVLCOMPTETVA
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tatva	
			and (@ent is null or TVLENT=@ent)

					/**********   Traitement des Taxes   ****************/
	
   if @sanstva=0
	begin
 
	  truncate table #Taxes
	  
	  insert into #Taxes (comptetva,taux,taxefr,taxedev)
	  select comptetva,taux,
			  round(sum(totalhtfr)*(taux/100),2),
			  round(sum(totalhtdev)*(taux/100),2)
	  from #Lignes
	  group by comptetva,taux
	  
	  truncate table #LesTaxes
	  
	  if @devise = null
	   begin
		insert into #LesTaxes (comptetva,totalfr,totaldev)
		select comptetva,round(sum(taxefr),2),null
		from #Taxes
		group by comptetva
	   end
	  else
	   begin
		insert into #LesTaxes (comptetva,totalfr,totaldev)
		select comptetva,round(sum(taxefr),2),round(sum(taxedev),2)
		from #Taxes
		group by comptetva
	   end
	  
	  insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
	  select @Journal,comptetva,@DateFact,@Num,@code,
			  convert(varchar(40),(@factfo+" "+@fournis+" "+@devise+" "+convert(varchar(13),@netdev))),
			  null,totalfr,null,null,null,null
	  from #LesTaxes
	  where totalfr>0
	  
	  insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
	  select @Journal,comptetva,@DateFact,@Num,@code,
			  convert(varchar(40),(@factfo+" "+@fournis+" "+@devise+" "+convert(varchar(13),@netdev))),
			  null,null,abs(totalfr),null,null,null
	  from #LesTaxes
	  where totalfr<0
	  
   end

	
	/********* Lignes d''ecritures de contrepartie  ***********/
	
	
	insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
	select @Journal,comptachat,@DateFact,@Num,@code,
			 convert(varchar(40),(@factfo+" "+@fournis+" "+@devise+" "+convert(varchar(13),@netdev))),
			 null,sum(totalhtfr),null,null,null,null
	from #Lignes
	group by comptachat
	having sum(totalhtfr)>0
	
	insert into #Sortie (journal,numcompta,date,num,piece,lib,dateech,debit,credit,trmode,devise,mtdev)
	select @Journal,comptachat,@DateFact,@Num,@code,
			 convert(varchar(40),(@factfo+" "+@fournis+" "+@devise+" "+convert(varchar(13),@netdev))),
			 null,null,abs(sum(totalhtfr)),null,null,null
	from #Lignes
	group by comptachat
	having sum(totalhtfr)<0
	
	 
	 				/***************** Traitement des differences de centimes */
	 
	 select @totdebit = 0, @totcredit = 0
	 
	 select @totdebit=sum(debit),@totcredit=sum(credit)
	 from #Sortie
	 where piece=@code
	 
	 /******************  debit ou credit *******/
	 
	 select @debit=debit, @lib=lib
	 from #Sortie
	 where piece=@code
	 and numcompta=@numcompta
	 
	 if @debit > 0 select @debcre=1 else select @debcre=0
	 
	 /****************** mise a jour d''une ligne de compte 6 si erreur de centimes < 0,50 *******/
	 
	 if (@totdebit != @totcredit)
	 begin
	 	if (abs(@totdebit - @totcredit) < 0.50)
	 	begin
			set rowcount 1
			
			select @compte=numcompta
			from #Sortie
			where piece=@code
			and numcompta like '6%'
			
			if (@debcre=0)
			begin
			  update #Sortie
			  set credit=credit+(@totdebit - @totcredit)
			  where numcompta=@compte
			  and piece=@code
			end
			else if (@debcre=1)
			begin
			  update #Sortie
			  set debit=debit+(@totcredit - @totdebit)
			  where numcompta=@compte
			  and piece=@code
			end
			
			set rowcount 0
		end
		else
		begin
			insert into #Dif (code,lib,differe)
			values (@code,@lib,(abs(@totdebit - @totcredit)))
		end
	 end
	 
		 				/***************** Facture suivante ***********/
	
	fetch facture
	into @code,@coursdev,@nom,@date,@sanstva,@totdev,@totfr,@tottvadev,
		@tottvafr,@netdev,@netfr,@fournis,@numcompta,@factfo,@devise,
		@fraisfr,@fraisdev,@tafrais,@douanesfr,@douanesdev,@tadouanes,
		@transfr,@transdev,@tatrans,@tvafr,@tvadev,@tatva,@foclasse
			
  end
  
  	close facture
	deallocate cursor echeances
	deallocate cursor facture
	
	drop table #Factures
	drop table #Lignes
	drop table #Taxes
	drop table #LesTaxes
	drop table #Sortie
	
	select code,lib,differe
	from #Dif
	
	drop table #Dif
	
end



go

