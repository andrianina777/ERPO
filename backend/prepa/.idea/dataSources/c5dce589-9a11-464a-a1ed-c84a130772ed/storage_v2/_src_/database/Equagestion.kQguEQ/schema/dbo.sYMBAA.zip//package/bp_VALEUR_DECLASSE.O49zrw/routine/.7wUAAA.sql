/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_VALEUR_DECLASSE

*/

CREATE PROCEDURE dbo.bp_VALEUR_DECLASSE
with recompile
AS
begin
	create table #MAJ_LOT(
		VALEUR numeric(18,3),
		DATE datetime
	)
	
	create table #PERC(
		VALEUR numeric(18,3),
		DATE datetime
	)
 	
 	--insert into #MAJ_LOT select RJLQTE*RJLPAHT,convert(date,RJLDATE) from FRJL where RJLDATE>'2019-01-01' and upper(RJLCOMMENT) like upper('%INVENTAIRE%') and RJLQTE>0 and RJLDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)
 	
 	insert into #MAJ_LOT select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2018-01-01' and SILDEPOT='PROM' 

 	insert into #PERC select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2018-01-01' and upper(SIL_MOTIF) like upper('%PERC%') and SILDEPOT='ECH'
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) as VALEUR_PROM from #MAJ_LOT where MONTH(DATE)<7 group by YEAR(DATE),MONTH(DATE)
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) as VALEUR_ECH from #PERC where MONTH(DATE)<7 group by YEAR(DATE),MONTH(DATE) 
 	
 	drop table #MAJ_LOT
 	drop table #PERC
end
go

