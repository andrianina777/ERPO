



/* Procedure utilisee par le module """"Articles a Commander"""" pour l''''Edition */

create procedure TableauPO
(
@ent			char(5)	= null,
@Date 			datetime,			/* On prend en compte les commandes jusquau */
@Datetrav		datetime	= null,	/* on se positionne a une date pour voir le detail */
@AvecDA			tinyint	= 1,
@AvecDC			tinyint	= 1,
@AvecCF			tinyint	= 1,
@Article 		char(15) 	= null,
@Fournisseur 	char(12) 	= null,
@Famille 		char(8) 	= null,
@categorie		char(8) 	= null,
@depart			char(8) 	= null,
@marque	 		char(12) 	= null,
@chefproduit	char(8)	= null,
@grille			char(10)	= null,
@matiere		varchar(14)	= null,
@couleur		char(8)	= null
)

with recompile
as
begin

declare @mois1		int,
		@mois2		int,
		@mois3		int,
		@mois4		int ,
		@mois5		int ,
		@mois6		int 
 

if @Datetrav is null  	select @Datetrav=getdate()
if @Date < @Datetrav	select @Datetrav=@Date


select @mois1=datepart(mm,@Datetrav)+1 
if @mois1>12 select @mois1=1 
select @mois2=@mois1+1 
if @mois2>12 select @mois2=1 
select @mois3=@mois2+1 
if @mois3>12 select @mois3=1 
select @mois4=@mois3+1 
if @mois4>12 select @mois4=1 
select @mois5=@mois4+1 
if @mois5>12 select @mois5=1 
select @mois6=@mois5+1 
if @mois6>12 select @mois6=1 



create table #Tab
(
Article		char(15)	not	null,
past_DA		int				null,
past_DC		int				null,
past_CF		int				null,
eom_DA		int				null,
eom_DC		int				null,
eom_CF		int				null,
m1_DA		int				null,
m1_DC		int				null,
m1_CF		int				null,
m2_DA		int				null,
m2_DC		int				null,
m2_CF		int				null,
m3_DA		int				null,
m3_DC		int				null,
m3_CF		int				null,
m4_DA		int				null, 
m4_DC		int				null, 
m4_CF		int				null, 
m5_DA		int				null, 
m5_DC		int				null, 
m5_CF		int				null, 
m6_DA		int				null, 
m6_DC		int				null, 
m6_CF		int				null, 
ma_DA		int				null,
ma_DC		int				null,
ma_CF		int				null
)

/* Selection des articles concernes */
if @Fournisseur is null
begin
	insert into #Tab 
	select ARCODE,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 from FAR
	where AROLD=0
	and (@Famille is null or ARFAM=@Famille)
	and (@Article is null or ARCODE=@Article)
	and (@categorie is null or ARGRFAM=@categorie)
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@chefproduit is null or ARCHEFP=@chefproduit)
	and (@grille is null or ARGRILLE=@grille)
	and (@matiere is null or ARMATIERE=@matiere)
	and (@couleur is null or ARCOULEUR=@couleur)
end
else
begin
	insert into #Tab 
	select ARCODE,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	from FAR,FARF
	where ARFCODE=ARCODE
	and ARFFO=@Fournisseur
	and AROLD=0
	and (@Famille is null or ARFAM=@Famille)
	and (@Article is null or ARCODE=@Article) 
	and (@categorie is null or ARGRFAM=@categorie)
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@chefproduit is null or ARCHEFP=@chefproduit)
	and (@grille is null or ARGRILLE=@grille)
	and (@matiere is null or ARMATIERE=@matiere)
	and (@couleur is null or ARCOULEUR=@couleur)
end
create unique index art	on #Tab (Article)

/* ************************************************* */
/* Selection des demandes et commandes  Fournisseurs */
/* ************************************************* */

if @AvecDA=1
begin
	update #Tab set past_DA=
		(
		select isnull(sum(isnull(RDAQTE,0)),0)
		from FRDA,FDA,FDAL
		where 
		#Tab.Article=RDAARTICLE 
		and DALSEQ=RDASEQ and DACODE=DALCODE
		and (RDADATE<=@Date or RDADATE is null) 
		and (RDADATE<@Datetrav)
		and (@ent is null or RDAENT=@ent)
		and isnull(DASTATUS,0)=0
		group by RDAARTICLE
		)
	
	update #Tab set eom_DA=
		(
		select isnull(sum(isnull(RDAQTE,0)),0)
		from FRDA,FDA,FDAL
		where 
		#Tab.Article=RDAARTICLE and DALSEQ=RDASEQ and DACODE=DALCODE
		and (RDADATE<=@Date or RDADATE is null) 
		and (RDADATE>=@Datetrav and RDADATE<=dateadd(dd,datepart(dd,dateadd(mm,1,@Datetrav))*-1,dateadd(mm,1,@Datetrav)) )
		and (@ent is null or RDAENT=@ent)
		and isnull(DASTATUS,0)=0
		group by RDAARTICLE
		)
end

if @AvecDC=1
begin
	update #Tab set past_DC=
		(
		select isnull(sum(isnull(RDAQTE,0)),0)
		from FRDA,FDA,FDAL
		where 
		#Tab.Article=RDAARTICLE 
		and DALSEQ=RDASEQ and DACODE=DALCODE
		and (RDADATE<=@Date or RDADATE is null) 
		and (RDADATE<@Datetrav)
		and (@ent is null or RDAENT=@ent)
		and isnull(DASTATUS,0)=1
		group by RDAARTICLE
		)
		
	update #Tab set eom_DC=
		(
		select isnull(sum(isnull(RDAQTE,0)),0)
		from FRDA,FDA,FDAL
		where 
		#Tab.Article=RDAARTICLE and DALSEQ=RDASEQ and DACODE=DALCODE
		and (RDADATE<=@Date or RDADATE is null) 
		and (RDADATE>=@Datetrav and RDADATE<=dateadd(dd,datepart(dd,dateadd(mm,1,@Datetrav))*-1,dateadd(mm,1,@Datetrav)) )
		and (@ent is null or RDAENT=@ent)
		and isnull(DASTATUS,0)=1
		group by RDAARTICLE
		)
end

if @AvecCF=1
begin

	update #Tab set past_CF=
		(
		select isnull(sum(isnull(RCFQTE,0)),0)
		from FRCF,FCF,FCFL
		where 
		#Tab.Article=RCFARTICLE 
		and CFLSEQ=RCFSEQ and CFCODE=CFLCODE
		and (RCFDATE<=@Date or RCFDATE is null) 
		and (RCFDATE<@Datetrav)
		and (@ent is null or RCFENT=@ent)
		and isnull(CFVALIDE,0)=0
		group by RCFARTICLE
		)

	update #Tab set eom_CF=
		(
		select isnull(sum(isnull(RCFQTE,0)),0)
		from FRCF,FCF,FCFL
		where 
		#Tab.Article=RCFARTICLE and CFLSEQ=RCFSEQ and CFCODE=CFLCODE
		and (RCFDATE<=@Date or RCFDATE is null) 
		and (RCFDATE>=@Datetrav and RCFDATE<=dateadd(dd,datepart(dd,dateadd(mm,1,@Datetrav))*-1,dateadd(mm,1,@Datetrav)) )
		and (@ent is null or RCFENT=@ent)
		and isnull(CFVALIDE,0)=0
		group by RCFARTICLE
		)
end

/* future da & dc & cf */
/* ******************* */

declare @ar	char(15),
	@type	tinyint,
	@an	int,
	@mois	int,
	@qte	int

declare @rub	varchar(5)
declare @string varchar(255)
	
declare future cursor for 
		select TYPE=(case when isnull(DASTATUS,0)=0 then 0 else 1 end),RDAARTICLE,datepart(yy,RDADATE),datepart(mm,RDADATE),sum(RDAQTE)
		from #Tab,FRDA,FDA,FDAL
		where Article=RDAARTICLE and DALSEQ=RDASEQ and DACODE=DALCODE
		and (RDADATE<=@Date or RDADATE is null) 
		and (RDADATE>dateadd(dd,datepart(dd,dateadd(mm,1,@Datetrav))*-1,dateadd(mm,1,@Datetrav)) )
		and (@ent is null or RDAENT=@ent)
		group by (case when isnull(DASTATUS,0)=0 then 0 else 1 end),RDAARTICLE,datepart(yy,RDADATE),datepart(mm,RDADATE)
	union all
		select TYPE=2,RCFARTICLE,datepart(yy,RCFDATE),datepart(mm,RCFDATE),sum(RCFQTE)
		from #Tab,FRCF,FCF,FCFL
		where Article=RCFARTICLE and CFLSEQ=RCFSEQ and CFCODE=CFLCODE
		and (RCFDATE<=@Date or RCFDATE is null) 
		and (RCFDATE>dateadd(dd,datepart(dd,dateadd(mm,1,@Datetrav))* -1,dateadd(mm,1,@Datetrav)) )
		and (@ent is null or RCFENT=@ent)
		group by RCFARTICLE,datepart(yy,RCFDATE),datepart(mm,RCFDATE)
	order by datepart(yy,RDADATE),datepart(mm,RDADATE),1
for read only

open future

fetch future into @type,@ar,@an,@mois,@qte
 
while (@@sqlstatus = 0)
begin
	/* determiner la rub a mettre a jour */
	if   @mois1=@mois	select @rub="m1_" 
	else if @mois2=@mois	select @rub="m2_" 
	else if @mois3=@mois	select @rub="m3_" 
	else if @mois4=@mois	select @rub="m4_" 
	else if @mois5=@mois	select @rub="m5_" 
	else if @mois6=@mois	select @rub="m6_" 
	else			select @rub="ma_" 

	if @type=0		select @rub=@rub+"DA"
	else if @type=1	select @rub=@rub+"DC"
	else if @type=2	select @rub=@rub+"CF"
	
	select @string="update #Tab set "+@rub+"="+@rub+"+"+convert(char(12),@qte)+"where Article='"+@ar+"'"

	if (@AvecDA=1 and @type=0) or (@AvecDC=1 and @type=1) or (@AvecCF=1 and @type=2)  
	begin
		execute (@string)
	end
		
	fetch future into @type,@ar,@an,@mois,@qte
end

close future
deallocate cursor future

if @Fournisseur is null
begin
select Article,SKU=ARREFFOUR,LIB=ARLIB,DEPARTMENT=ARDEPART,SUPPLIER=ARFO,
FAMILY=ARFAM,CATEGORY=GFCODE+'/'+GFNOM,COLLECTION=ARGRILLE,CPN=ARCHEFP,
isnull(past_DA,0),isnull(past_DC,0) ,isnull(past_CF,0),
isnull(eom_DA,0) ,isnull(eom_DC,0) ,isnull(eom_CF,0) ,
m1_DA,m1_DC, m1_CF,
m2_DA,m2_DC, m2_CF,
m3_DA,m3_DC, m3_CF,
m4_DA,m4_DC, m4_CF, 
m5_DA,m5_DC, m5_CF, 
m6_DA,m6_DC, m6_CF,
ma_DA,ma_DC, ma_CF,
to_DA=isnull(past_DA,0) +isnull(eom_DA,0) +m1_DA+m2_DA+m3_DA+m4_DA+m5_DA+m6_DA+ma_DA,
to_DC=isnull(past_DC,0) +isnull(eom_DC,0) +m1_DC+m2_DC+m3_DC+m4_DC+m5_DC+m6_DC+ma_DC,
to_CF=isnull(past_CF,0) +isnull(eom_CF,0) +m1_CF+m2_CF+m3_CF+m4_CF+m5_CF+m6_CF+ma_CF
from #Tab,FAR,FGF
where ARCODE=Article and ARGRFAM*=GFCODE
order by ARFAM,Article
end
else
begin
select Article,SKU=ARREFFOUR,LIB=ARLIB,DEPARTMENT=ARDEPART,SUPPLIER=@Fournisseur,
FAMILY=ARFAM,CATEGORY=GFCODE+'/'+GFNOM,COLLECTION=ARGRILLE,CPN=ARCHEFP,
isnull(past_DA,0),isnull(past_DC,0) ,isnull(past_CF,0),
isnull(eom_DA,0) ,isnull(eom_DC,0) ,isnull(eom_CF,0) ,
m1_DA,m1_DC, m1_CF,
m2_DA,m2_DC, m2_CF,
m3_DA,m3_DC, m3_CF,
m4_DA,m4_DC, m4_CF, 
m5_DA,m5_DC, m5_CF, 
m6_DA,m6_DC, m6_CF,
ma_DA,ma_DC, ma_CF,
to_DA=isnull(past_DA,0) +isnull(eom_DA,0) +m1_DA+m2_DA+m3_DA+m4_DA+m5_DA+m6_DA+ma_DA,
to_DC=isnull(past_DC,0) +isnull(eom_DC,0) +m1_DC+m2_DC+m3_DC+m4_DC+m5_DC+m6_DC+ma_DC,
to_CF=isnull(past_CF,0) +isnull(eom_CF,0) +m1_CF+m2_CF+m3_CF+m4_CF+m5_CF+m6_CF+ma_CF
from #Tab,FAR,FGF
where ARCODE=Article and ARGRFAM*=GFCODE
order by ARFAM,Article
end


drop table 	#Tab

end                                                    



go

