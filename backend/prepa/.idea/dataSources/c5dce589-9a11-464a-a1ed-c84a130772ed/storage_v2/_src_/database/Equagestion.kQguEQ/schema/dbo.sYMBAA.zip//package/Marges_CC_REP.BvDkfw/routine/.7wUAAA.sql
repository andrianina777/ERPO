


/* Procedure renvoyant les lignes de CC avec la marge par postes de saisie et REP sedentaire */

create procedure Marges_CC_REP (@ent	char(5) 	  = null,
							 	@an		smallint	  = null
						    	)
with recompile
as
begin

set arithabort numeric_truncation off

declare	@mois	tinyint,
		@date1	smalldatetime,
		@date2	smalldatetime
		
if @an is null
	select  @an = datepart(yy,getdate()),
			@mois = datepart(mm,getdate())
else
	select  @mois = datepart(mm,getdate())

		
select @date1=convert(smalldatetime,"01/01/"+convert(varchar,@an))
select @date2=convert(smalldatetime,"12/31/"+convert(varchar,@an))


create table #CC
(
uid				int				not null,
Rep				char(10)		not null,
Date			smalldatetime	not null,
Article			char(15)		not null,
Quantite		int				not null,
Valeur_Vente	numeric(14,2)	not null,
Marge_Val		numeric(14,2)	not null,
ID				numeric(14,0)	identity
)


insert into #CC (uid,Rep,Date,Article,Quantite,Valeur_Vente,Marge_Val)
select CCLUSERCRE,CLREP,dateadd(hh,19,CCDATECOM),CCLARTICLE,CCLQTE,isnull(CCLTOTALHT,0),0
from FCCL,FAR,FCL,FCC
where ARCODE=CCLARTICLE
and CLCODE=CCLCL
and CCCODE=CCLCODE
and CCDATECOM between @date1 and @date2
and ARTYPE=0
and (@ent is null or (CCLENT=@ent and CLENT=@ent))


declare commandes cursor 
for select ID,Date,Article,Quantite,Valeur_Vente
from #CC
for update of Marge_Val

declare @seq			numeric(14,0),
		@date			smalldatetime,
		@article		char(15),
		@qte			int,
		@totalht		numeric(14,2),
		@PrixRevient	numeric(14,4)

open commandes

fetch commandes
into @seq,@date,@article,@qte,@totalht

while (@@sqlstatus = 0)
	begin
	
	select @PrixRevient=isnull(PUMP,0)
	from FPUM
	where PUMAR = @article
	and PUMDATE <= @date
	having PUMAR = @article
	and PUMDATE <= @date
	and PUMDATE = max(PUMDATE)
	
	if @PrixRevient is null
		select @PrixRevient=0
	
	if @totalht = 0
	begin
		update #CC set Marge_Val=-(@PrixRevient*@qte)
		where current of commandes	
	end
	else if @PrixRevient != 0
	begin
		update #CC set Marge_Val=@totalht-(@PrixRevient*@qte)
		where current of commandes	
	end
	else
	begin
		update #CC set Marge_Val=@totalht
		where current of commandes
	end
	
	
	fetch commandes
	into @seq,@date,@article,@qte,@totalht
	
end

close commandes
deallocate cursor commandes

select Utilisateur=uid,Rep=Rep,
		Qte_Mois=sum(case when datepart(mm,Date)=@mois then Quantite else 0 end),
		Vente_Mois=sum(case when datepart(mm,Date)=@mois then Valeur_Vente else 0 end),
		Marge_Valeur_Mois=sum(case when datepart(mm,Date)=@mois then Marge_Val else 0 end),
		Marge_PC_Mois=convert(numeric(14,2),0),
		Qte_An=sum(Quantite),
		Vente_An=sum(Valeur_Vente),
		Marge_Valeur_An=sum(Marge_Val),
		Marge_PC_An=convert(numeric(14,2),0)
into #Finale
from #CC
group by uid,Rep

drop table #CC


update #Finale
set Marge_PC_Mois=(case when Vente_Mois != 0 then convert(numeric(14,2),Marge_Valeur_Mois/Vente_Mois*100)
				   	    when Vente_Mois = 0 then 0 end),
	Marge_PC_An=(case when Vente_An != 0 then convert(numeric(14,2),Marge_Valeur_An/Vente_An*100)
				      when Vente_An = 0 then 0 end)

select Utilisateur=name,char(9),Rep=Rep,char(9),Nom=RENOM,char(9),Qte_Mois=Qte_Mois,char(9),
		Vente_Mois=Vente_Mois,char(9),Marge_Valeur_Mois=Marge_Valeur_Mois,char(9),
		Marge_PC_Mois=Marge_PC_Mois,char(9),Qte_An=Qte_An,char(9),Vente_An=Vente_An,char(9),
		Marge_Valeur_An=Marge_Valeur_An,char(9),Marge_PC_An=Marge_PC_An
from #Finale,FREP,sysusers
where RECODE=Rep
and Utilisateur=uid
order by name,Rep

drop table #Finale


end



go

