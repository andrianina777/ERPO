



/* Procedure renvoyant les chiffres d''affaires, marges, objectifs 
pour les annees N-1, annee et mois en cours pour un Representant
	utilisee par module OMNIS CA par VRP */

create procedure CA_RepImp (@ent	char(5) = null,
							@rep	char(8),
							@rfa	tinyint,
							@division char(8),
							@modevalo tinyint
							)
with recompile
as
begin

	set arithabort numeric_truncation off


	create table #Final
	(
	CA_mois_0		numeric(14,2)	null,
	CA_mois_1		numeric(14,2)	null,
	Marge_mois_0	numeric(14,2)	null,
	CA_an_0			numeric(14,2)	null,
	CA_an_1			numeric(14,2)	null,
	Marge_an_0		numeric(14,2)	null,
	Obj_mois_0		numeric(14,2)	null,
	Obj_an_0		numeric(14,2)	null
	)

	
	declare @mois	int,
			@an		int,
			@type	tinyint
			
	select @mois = datepart(mm,getdate()),
		   @an   = datepart(yy,getdate())
	
	select  @type=RETYPE
	from FREP
	where RECODE=@rep

	
	insert into #Final (CA_an_1,CA_an_0,Marge_an_0)
	select   sum(isnull(STCAFA,0)*(1-sign(abs(STAN-@an+1)))),
			 sum(isnull(STCAFA,0)*(1-sign(abs(STAN-@an)))),
			 sum(isnull(STCAFA,0)*(1-sign(abs(STAN-@an))))-sum(isnull(
			 (case when @modevalo=0 then (STPR)when @modevalo=1 then (STPRM) when @modevalo=2 then (STPUM) else (STPUM)end)
			 ,0)*(1-sign(abs(STAN-@an))))
	from FST,FAR
	where ARCODE=START
	and (@ent is null or STENT=@ent)
	and (@type = 2 or STREP=@rep)
	and (@type != 2 or STREPDIV=@rep)
	and (@rfa=0 or ARTYPE<>6)
	and (@division='' or ARDEPART=@division)

	insert into #Final (CA_mois_0,Marge_mois_0)
	select   sum(isnull(STCAFA,0)),sum(isnull(STCAFA,0))-sum(isnull(
	(case when @modevalo=0 then (STPR)when @modevalo=1 then (STPRM) when @modevalo=2 then (STPUM) else (STPUM)end)
	,0))
	from FST,FAR
	where ARCODE=START
	and STMOIS = @mois
	and STAN = @an
	and (@type = 2 or STREP=@rep)
	and (@type != 2 or STREPDIV=@rep)	
	and (@ent is null or STENT=@ent)
	and (@rfa=0 or ARTYPE<>6)
	and (@division='' or ARDEPART=@division)
	
	insert into #Final (CA_mois_1)
	select   sum(isnull(STCAFA,0))
	from FST,FAR
	where ARCODE=START
	and STMOIS = @mois
	and STAN = @an-1
	and (@type = 2 or STREP=@rep)
	and (@type != 2 or STREPDIV=@rep)
	and (@ent is null or STENT=@ent)
	and (@rfa=0 or ARTYPE<>6)
	and (@division='' or ARDEPART=@division)
	
	insert into #Final (Obj_mois_0)
	select isnull(OBRCA,0)
	from FOBR
	where OBRCODE = @rep
	and OBRMOIS = @mois
	and OBRAN = @an
	and (@ent is null or OBRENT=@ent)
	
	insert into #Final (Obj_an_0)
	select sum(isnull(OBRCA,0))
	from FOBR
	where OBRCODE = @rep
	and OBRAN = @an
	and (@ent is null or OBRENT=@ent)


	select  @rep,sum(isnull(CA_mois_0,0)),sum(isnull(CA_mois_1,0)),sum(isnull(Marge_mois_0,0)),
			sum(isnull(CA_an_0,0)),sum(isnull(CA_an_1,0)),sum(isnull(Marge_an_0,0)),
			sum(Obj_mois_0),(sum(isnull(CA_mois_0,0))/(sum(Obj_mois_0)+1))*100,sum(Obj_an_0),
			(sum(isnull(CA_an_0,0))/(sum(Obj_an_0)+1))*100
	from #Final
	
	drop table #Final

end



go

