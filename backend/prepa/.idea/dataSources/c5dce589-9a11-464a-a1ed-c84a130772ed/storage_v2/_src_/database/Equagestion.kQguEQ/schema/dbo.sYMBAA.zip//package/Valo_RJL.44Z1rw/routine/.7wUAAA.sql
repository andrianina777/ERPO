


create procedure Valo_RJL (@date1		smalldatetime,
						   @date2		smalldatetime,
						   @detail 		tinyint,   	 		/* 0 = pas de detail, 1 = avec detail */
						   @chefprod	char(8) = null,
						   @depot		char(4) = null,
						   @code		char(10)= null,
						   @code_art	char(15)= null
						   )
with recompile
as
begin

declare @modevalo 			tinyint,
		@date 				datetime,
		@article			char(15),
		@articleprecedent	char(15),
		@qte				int,
		@PrixRevient		numeric(14,4),
		@PrixRevientLigne	numeric(14,2),
		@seq				int


select @modevalo=PMODEVALO from KParam
select @articleprecedent = ""

create table #Final
(
RJLARTICLE	char(15)		not null,
ANNEE		int					null,
ARLIB		varchar(80)			null,
RJLDEPOT	char(4) 		not null,
RJLQTE		int					null,
VALEURFINAL	numeric(14,2)		null,
RJLCOMMENT	varchar(255)		null,
RJLDATE		smalldatetime	not null,
ARREFFOUR	char(20)			null,
STNUMARM1	char(12)			null,
STNUMARM2	char(12)			null,
RJLCODE		char(10)		not null,
Seq			numeric(14,0)	identity
)


declare st_curs cursor 
for select RJLARTICLE,RJLQTE,RJLDATE,Seq
from #Final
order by Seq
for read only


if @modevalo=0
	insert into #Final (RJLARTICLE,ANNEE,ARLIB,RJLDEPOT,RJLQTE,
      	VALEURFINAL,RJLCOMMENT,RJLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,RJLCODE)
	select RJLARTICLE,datepart(yy,RJLDATE),ARLIB,RJLDEPOT,RJLQTE,
	(RJLPAHT+RJLFRAIS)/CVLOT*RJLQTE,RJLCOMMENT,RJLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,RJLCODE
	from FRJL,FAR,FCV,FSTOCK 
	where ARCODE=RJLARTICLE 
	and CVUNIF=ARUNITACHAT 
	and STAR=RJLARTICLE 
	and STLETTRE=RJLLETTRE
	and (@chefprod is null or ARCHEFP = @chefprod)
	and (@depot is null or RJLDEPOT=@depot)
	and (@code_art is null or RJLARTICLE=@code_art)
	and (@code is null or RJLCODE like @code+"%")
	and RJLDATE between @date1 and @date2
	order by RJLCODE,RJLARTICLE,datepart(yy,RJLDATE),ARLIB,RJLDEPOT
	
else if @modevalo=1
	insert into #Final (RJLARTICLE,ANNEE,ARLIB,RJLDEPOT,RJLQTE,
      	VALEURFINAL,RJLCOMMENT,RJLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,RJLCODE)
	select RJLARTICLE,datepart(yy,RJLDATE),ARLIB,RJLDEPOT,RJLQTE,
	isnull(ARPRM,0)*RJLQTE,RJLCOMMENT,RJLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,RJLCODE
	from FRJL,FAR,FSTOCK 
	where ARCODE=RJLARTICLE 
	and STAR=RJLARTICLE 
	and STLETTRE=RJLLETTRE
	and (@chefprod is null or ARCHEFP = @chefprod)
	and (@depot is null or RJLDEPOT=@depot)
	and (@code_art is null or RJLARTICLE=@code_art)
	and (@code is null or RJLCODE like @code+"%")
	and RJLDATE between @date1 and @date2
	order by RJLCODE,RJLARTICLE,datepart(yy,RJLDATE),ARLIB,RJLDEPOT


else
        begin
             insert into #Final (RJLARTICLE,ANNEE,ARLIB,RJLDEPOT,RJLQTE,
      	     VALEURFINAL,RJLCOMMENT,RJLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,RJLCODE)
             select RJLARTICLE,datepart(yy,RJLDATE),ARLIB,RJLDEPOT,RJLQTE,0,RJLCOMMENT,
             RJLDATE,ARREFFOUR,STNUMARM1,STNUMARM2,RJLCODE
             from FRJL,FAR,FSTOCK 
             where ARCODE=RJLARTICLE 
             and STAR=RJLARTICLE 
             and STLETTRE=RJLLETTRE
             and (@chefprod is null or ARCHEFP = @chefprod)
             and (@depot is null or RJLDEPOT=@depot)
             and (@code_art is null or RJLARTICLE=@code_art)
             and (@code is null or RJLCODE like @code+"%")
             and RJLDATE between @date1 and @date2
            
            	              	
               	create unique index seq on #Final (Seq)
		
		open st_curs
		
		fetch st_curs
		into @article,@qte,@date,@seq
               	
               	
		while (@@sqlstatus = 0)
			begin
			
		  if @articleprecedent != @article
		  begin
			select 	@PrixRevient = 0
			
			if @modevalo = 2			/*--------------------- PUMP */
			begin
			  select @PrixRevient=isnull(PUMP,0)
			  from FPUM
			  where PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, @date)
			  having PUMAR = @article
			  and PUMDATE <= convert (smalldatetime, @date)
			  and PUMDATE = max(PUMDATE)
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
			  
			end
			
			else if @modevalo = 3			/*--------------------- PRM Mensuel */
			
			begin
			  set rowcount 1
			  
			  select @PrixRevient=isnull(PRM,0)
			  from FPRM
			  where PRMAR = @article
			  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
			  and PRMAR = @article
			  order by PRMAN desc,PRMMOIS desc
			  
			  set rowcount 0
			  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
			
			else  if @modevalo = 4 			/*--------------------- DPA unitaire */
			
			begin
			  set rowcount 1			
			
			  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
			  from FBLL,FCV
			  where BLLAR=@article
			  and CVUNIF=BLLUA
			  having BLLAR=@article
			  and CVUNIF=BLLUA
			  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
			
			  if isnull(@PrixRevient,0)=0
			  begin
				select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
				from FSIL,FAR,FCV
				where SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				having SILARTICLE=@article
				and ARCODE = SILARTICLE
				and ARUNITACHAT = CVUNIF
				and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
			  end
			  
			  set rowcount 0
			  
			  if @PrixRevient is null
				select @PrixRevient = 0
	  
			  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
			end
		  end
		  else if @articleprecedent = @article
		  begin
			select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		  end


			update #Final set VALEURFINAL=@PrixRevientLigne
			where Seq = @seq
		
			select  @articleprecedent = @article
			
			fetch st_curs
			into @article,@qte,@date,@seq
			
		end
                	
                close st_curs
                           
            	
	end

/*--- renvoi les lignes --*/

if @detail=1
   select RJLARTICLE,ANNEE,ARLIB,RJLDEPOT,RJLQTE,VALEURFINAL,RJLCOMMENT,RJLDATE,ARREFFOUR,
   STNUMARM1,STNUMARM2,RJLCODE from #Final
   order by RJLCODE,RJLARTICLE,ANNEE,ARLIB,RJLDEPOT
else
   select RJLARTICLE,ANNEE,ARLIB,RJLDEPOT,sum(RJLQTE),sum(VALEURFINAL),RJLCOMMENT,RJLDATE,ARREFFOUR,'','','' from #Final
   group by RJLARTICLE,ANNEE,ARLIB,RJLDEPOT,RJLCOMMENT,RJLDATE,ARREFFOUR
   order by RJLARTICLE,ANNEE,ARLIB,RJLDEPOT
   

drop table #Final	

end	



go

