



create procedure Suivi_Rep (@ent		char(5)	= null,
							@rep		char(8) = null,
							@marque		char(12) = null
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @labase		varchar(30),
		@lignes		int,
		@an			smallint,
		@mois		tinyint
		
select  @labase = db_name()
select 	@lignes = 0
select	@an = datepart(yy,getdate())
select	@mois = datepart(mm,getdate())


dump tran @labase with truncate_only

create table #Finale
(
seq			numeric(14,0)		identity,
rep			char(8)				not null,
marque		char(12)			not null,
CA_annee_1	numeric(14,2)			null,
CA_annee	numeric(14,2)			null,
BE_encours	numeric(14,2)			null,
CC_encours	numeric(14,2)			null
)

declare @type	tinyint
select  @type=RETYPE from FREP where RECODE=@rep

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos

if @type != 2
begin
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select CLREP,ARFO,
		  isnull(sum(case	when STAN=@an-1 then STCAFA else 0 end),0),
		  isnull(sum(case	when STAN=@an then STCAFA else 0 end),0),
		  0,0
  from FST,FAR,FCL
  where START=ARCODE
  and STAN between @an-1 and @an
  and STMOIS between 1 and @mois
  and ARCODE=START
  and CLCODE=STCL
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (STENT=@ent and CLENT=STENT))
  group by CLREP,ARFO


  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLREP,ARFO,0,0,isnull(sum(BELTOTALHT),0),0
  from FRBE,FBEL,FAR,FCL
  where BELSEQ=RBESEQ
  and CLCODE=RBECL
  and ARCODE=RBEARTICLE
  and RBEDEMO=0
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RBEENT=@ent and BELENT=RBEENT and CLENT=RBEENT))
  group by CLREP,ARFO
  
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLREP,ARFO,0,0,0,isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0)
  from FRCC,FCCL,FAR,FCL,FCC
  where CCLSEQ=RCCSEQ
  and CLCODE=RCCCL
  and ARCODE=RCCARTICLE
  and CCCODE=CCLCODE
  and (@rep is null or CLREP=@rep)
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
  group by CLREP,ARFO
end 
else if @type = 2
begin
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select CLRREPDIV,ARFO,
		  isnull(sum(case	when STAN=@an-1 then STCAFA else 0 end),0),
		  isnull(sum(case	when STAN=@an then STCAFA else 0 end),0),
		  0,0
  from FST,FAR,FCL,FCLR
  where START=ARCODE
  and STAN between @an-1 and @an
  and STMOIS between 1 and @mois
  and ARCODE=START
  and CLCODE=STCL
  and CLRCL=CLCODE
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (STENT=@ent and CLENT=STENT))
  group by CLRREPDIV,ARFO
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLRREPDIV,ARFO,0,0,isnull(sum(BELTOTALHT),0),0
  from FRBE,FBEL,FAR,FCL,FCLR
  where BELSEQ=RBESEQ
  and CLCODE=RBECL
  and ARCODE=RBEARTICLE
  and RBEDEMO=0
  and CLRCL=CLCODE
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RBEENT=@ent and BELENT=RBEENT and CLENT=RBEENT))
  group by CLRREPDIV,ARFO
  
  
  
  insert into #Finale (rep,marque,CA_annee_1,CA_annee,BE_encours,CC_encours)
  select	CLRREPDIV,ARFO,0,0,0,isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0)
  from FRCC,FCCL,FAR,FCL,FCC,FCLR
  where CCLSEQ=RCCSEQ
  and CLCODE=RCCCL
  and ARCODE=RCCARTICLE
  and CCCODE=CCLCODE
  and CLRCL=CLCODE
  and CLRREPDIV=@rep
  and CLRDIV=ARDEPART
  and (@marque is null or ARFO=@marque)
  and (@multient=0 or @ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT and CLENT=RCCENT))
  group by CLRREPDIV,ARFO
end



select 	VRP=rep,Marque=marque,
		CA_ANNEE_1=convert(numeric(15,0),isnull(sum(CA_annee_1),0)),
		CA_ANNEE=convert(numeric(15,0),isnull(sum(CA_annee),0)),
		Difference=convert(numeric(15,0),isnull(sum(CA_annee),0)) - convert(numeric(15,0),isnull(sum(CA_annee_1),0)),
		BE_encours=convert(numeric(15,0),isnull(sum(BE_encours),0)),
		Cdes_encours=convert(numeric(15,0),isnull(sum(CC_encours),0))
from #Finale
group by rep,marque
having 	convert(numeric(15,0),isnull(sum(CA_annee_1),0)) != 0 or
		convert(numeric(15,0),isnull(sum(CA_annee),0)) != 0 or
		convert(numeric(15,0),isnull(sum(BE_encours),0)) != 0 or
		convert(numeric(15,0),isnull(sum(CC_encours),0)) != 0
order by rep,marque

drop table #Finale


end



go

