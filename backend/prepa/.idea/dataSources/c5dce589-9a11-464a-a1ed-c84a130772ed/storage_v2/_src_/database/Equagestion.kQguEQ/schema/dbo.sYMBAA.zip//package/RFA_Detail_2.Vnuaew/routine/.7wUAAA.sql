


/* Renvoie le detail (ou la RFA due totale) de la RFA pour un client - TBCL */

create procedure RFA_Detail_2 (	@ent			char(5) 	= null,
								@client			char(12),
						 	 	@an				smallint,
								@destination	tinyint,				/* 0 = liste, 1 = total RFA due, 2 = vers #table pour RFA_TBGL */
								@RFAdue			numeric(14,2) output,
								@rep			char(8)		= null,
								@repdiv			char(8)		= null,
								@depart			char(8)		= null,
								@chef			char(8) 	= null,
								@contrat		char(10) 	= null
						 	)
with recompile
as
begin

set arithabort numeric_truncation off




declare @CAtotal		numeric(14,2),			/* CA total pour calcul droit */
		@CAsansRFA		numeric(14,2),			/* CA des articles sans RFA */
		@CARFAct		numeric(14,2),			/* CA des articles avec RFA contrats */
		@CARFAHct		numeric(14,2),			/* CA des articles avec RFA hors contrats */
		@droitRFA		numeric(8,4),			/* % du droit a RFA */
		@RFAct			numeric(14,2),			/* total de la RFA contrat */
		@RFAremCL		numeric(14,2),			/* total de la RFA sans contrat (RFA fiche remises) */
		@RFAremCL_pot	numeric(14,2),			/* total de la RFA potentielle sans contrat (RFA fiche remises) */
		@rfa_ca			numeric(14,2),			/* total de la RFA CA */
		@rfa_pot		numeric(14,2),			/* total de la RFA CA potentielle */
		@droit_pot		numeric(8,4),			/* % du droit potentiel */
		@groupement		char(12),				/* code du groupement d''achat du client */
		@rfact			numeric(14,2),			/* RFA d''une ligne de statistiques */
		@testRFA		tinyint					/* variable renvoyee par RFACT indiquant si une ligne de RFA a ete trouvee */
		

select @groupement = CLCODEGROUPE from FCL
where CLCODE=@client
and CLTYPECLI=2
and (@ent is null or CLENT=@ent)


create table #Finale_Detail
(
contrat		char(10)		not null,
depart		char(8)			not null,
marque		char(12)		not null,
famille		char(8)			not null,
categorie	char(8)			not null,
article		char(15)		not null,
tarif		char(8)			not null,
qte_ct		int					null,
atteint_qte	int					null,
val_ct		int					null,
atteint_val	numeric(14,2)		null,
rfa_due		numeric(14,2)		null,
rfa_pot		numeric(14,2)		null,
rfa_pc		numeric(8,4)		null,
seq			numeric(14,0)	identity
)



			/* Calcul du CA total */

select @CAtotal=isnull(sum(STCAFA),0)
from FST,FAR
where STAN=@an
and STCL=@client
and (@rep is null or STREP=@rep)
and (@repdiv is null or STREPDIV=@repdiv)
and (@depart is null or ARDEPART=@depart)
and (@chef is null or ARCHEFP=@chef)
and ARCODE=START
and ARTYPE in (0,1)
and (@ent is null or STENT=@ent)


select @droitRFA=isnull(DRFADROIT,0)
from FDRFA
where DRFAVAL = (select max(DRFAVAL) from FDRFA where DRFAVAL <= @CAtotal and (@ent is null or DRFAENT=@ent))

if @droitRFA != 0
begin
	select @droit_pot=@droitRFA
end
else
begin
	select  @droit_pot=isnull(DRFADROIT,0)
	from FDRFA
	where DRFADROIT = (select min(DRFADROIT) from FDRFA where DRFADROIT > 0 and (@ent is null or DRFAENT=@ent))
end


/*-------------- Calcul du CA ne donnant pas droit a RFA - calcule apres car le % de base tient compte de cette valeur */

select @CAsansRFA=isnull(sum(STCAFA),0)
from FST,FAR
where STAN=@an
and STCL=@client
and (@rep is null or STREP=@rep)
and (@repdiv is null or STREPDIV=@repdiv)
and (@depart is null or ARDEPART=@depart)
and (@chef is null or ARCHEFP=@chef)
and ARCODE=START
and ARSANSRFA=1 
and ARTYPE in (0,1)
and (@ent is null or STENT=@ent)


/*-------------- Calcul du CA donnant droit a la RFA contrat */

create table #RFA
(
RFA_contrat		char(10)		not null,
RFA_depart		char(8)			not null,
RFA_marque		char(12)		not null,
RFA_famille		char(8)			not null,
RFA_categorie	char(8)			not null,
RFA_article		char(15)		not null,
RFA_tarif		char(8)			not null,
RFA_qtect		int					null,
RFA_atteint_qte	int					null,
RFA_valct		numeric(14,2)		null,
RFA_atteint_val	numeric(14,2)		null,
RFA_rfa_due		numeric(14,2)		null,
RFA_rfa_pot		numeric(14,2)		null,
RFA_pc			numeric(8,4)		null
)


create table #RFA1
(
RFA_contrat		char(10)		not null,
RFA_depart		char(8)			not null,
RFA_marque		char(12)		not null,
RFA_famille		char(8)			not null,
RFA_categorie	char(8)			not null,
RFA_article		char(15)		not null,
RFA_tarif		char(8)			not null,
RFA_qtect		int					null,
RFA_atteint_qte	int					null,
RFA_valct		numeric(14,2)		null,
RFA_atteint_val	numeric(14,2)		null,
RFA_rfa_due		numeric(14,2)		null,
RFA_rfa_pot		numeric(14,2)		null,
RFA_pc			numeric(8,4)		null
)


declare	@contrat_out	char(10),
		@depart_out		char(8),
		@fo_out			char(12),
		@fam_out		char(8),
		@categ_out		char(8),
		@article_out	char(15),
		@tarif_out		char(8),
		@qtect_out		int,
		@valct_out		numeric(14,0),
		@rcrfa_out		numeric(8,4)


declare ventes cursor 
for select isnull(START,''),isnull(STQTEFA,0),isnull(STCAFA,0)
from FST,FAR,FCL
where ARCODE=START
and ARSANSRFA=0 
and ARTYPE in (0,1)
and STAN=@an
and STCL=@client
and (@rep is null or STREP=@rep)
and (@repdiv is null or STREPDIV=@repdiv)
and (@depart is null or ARDEPART=@depart)
and (@chef is null or ARCHEFP=@chef)
and CLCODE=STCL
for read only


declare @article_curs	char(15),
		@qte_curs		int,
		@ca_curs		numeric(14,2)

open ventes

fetch ventes
into @article_curs,@qte_curs,@ca_curs

while (@@sqlstatus = 0)
  begin
	
	select @testRFA = 0
	
	exec @testRFA = RFACT null,@client,@an,@article_curs,@contrat,@contrat_out output,
			@depart_out output,@fo_out output,@fam_out output,@categ_out output,
			@article_out output,@tarif_out output,@qtect_out output,@valct_out output,
			@rcrfa_out output
 
	if @testRFA = 0
	begin
	  select @rfact=round((@ca_curs*@rcrfa_out),2)
	  
	  if @contrat_out = ""
	  	select @contrat_out = "RFAHorsCTR",@depart_out = "",@fo_out = "",@fam_out = "",
				@categ_out = "",@article_out = "",@tarif_out = ""
	
	  insert into #RFA1 (RFA_contrat,RFA_depart,RFA_marque,RFA_famille,RFA_categorie,RFA_article,RFA_tarif,
						  RFA_qtect,RFA_atteint_qte,
						  RFA_valct,RFA_atteint_val,RFA_rfa_due,RFA_rfa_pot,RFA_pc)
	  values(@contrat_out,@depart_out,@fo_out,@fam_out,@categ_out,@article_out,@tarif_out,
			  @qtect_out,@qte_curs,
			  @valct_out,@ca_curs,@rfact,@rfact,@rcrfa_out)
	end
 
	fetch ventes
	into @article_curs,@qte_curs,@ca_curs
	
  end

close ventes
deallocate cursor ventes


insert into #RFA (RFA_contrat,RFA_depart,RFA_marque,RFA_famille,RFA_categorie,RFA_article,RFA_tarif,RFA_qtect,RFA_atteint_qte,
				RFA_valct,RFA_atteint_val,RFA_rfa_due,RFA_rfa_pot,RFA_pc)
select RFA_contrat,RFA_depart,RFA_marque,RFA_famille,RFA_categorie,RFA_article,RFA_tarif,
		RFA_qtect,sum(RFA_atteint_qte),RFA_valct,sum(RFA_atteint_val),sum(RFA_rfa_due),sum(RFA_rfa_pot),RFA_pc
from #RFA1
group by RFA_contrat,RFA_depart,RFA_marque,RFA_famille,RFA_categorie,RFA_article,RFA_tarif,RFA_qtect,RFA_valct,RFA_pc


drop table #RFA1

if @contrat is null
begin

  /*--------------- Calcul du CA donnant droit a la RFA contrat */
  
  select @CARFAct=sum(RFA_atteint_val)
  from #RFA
  where RFA_contrat != "RFAHorsCTR"
  
  
  /*--------------- Calcul du CA donnant droit a la RFA hors contrats */
  
  
  select @CARFAHct=sum(RFA_atteint_val)
  from #RFA
  where RFA_contrat = "RFAHorsCTR"
  
  
  /*--------------- Ajout des lignes de contrats sans ventes correspondantes */

end

create table #contrats
(
contrat		char(10)		not null,
depart		char(8)			not null,
marque		char(12)		not null,
famille		char(8)			not null,
categorie	char(8)			not null,
article		char(15)		not null,
tarif		char(8)			not null,
qtect		int				not null,
valct		numeric(14,2)	not null,
rfa_pc		numeric(8,4)	not null
)

insert into #contrats (contrat,depart,marque,famille,categorie,article,tarif,qtect,valct,rfa_pc)
select isnull(RCCONTRAT,''),isnull(RCDEPART,''),isnull(RCFO,''),isnull(RCFAM,''),
	  isnull(RCCATEG,''),isnull(RCARTICLE,''),isnull(RCTARIF,''),isnull(RCQTE,0),
	  isnull(RCMONTANT,0),isnull(RCRFA,0)
from FRC
where RCAN=@an
and RCCL=@client
and RCCT=1
and (@contrat is null or RCCONTRAT=@contrat)
and (@ent is null or RCENT=@ent)
and (@rep is null or isnull(RCDEPART,'') not in (select CLRDIV from FCLR where CLRCL=@client and (@ent is null or CLRENT=@ent)))
and (@repdiv is null or RCDEPART = (select REDIV from FREP where RECODE = @repdiv))
and (@depart is null or RCDEPART = @depart)
and (@chef is null or RCARTICLE in (select ARCODE from FAR where ARCHEFP = @chef))


insert into #RFA (RFA_contrat,RFA_depart,RFA_marque,RFA_famille,RFA_categorie,RFA_article,RFA_tarif,RFA_qtect,RFA_atteint_qte,
			  RFA_valct,RFA_atteint_val,RFA_rfa_due,RFA_rfa_pot,RFA_pc)
select contrat,depart,marque,famille,categorie,article,tarif,qtect,0,valct,0,0.00,0.00,rfa_pc
from #contrats
where not exists (select * from #RFA where RFA_contrat=#contrats.contrat 
									  and RFA_depart=#contrats.depart
									  and RFA_marque=#contrats.marque
									  and RFA_famille=#contrats.famille
									  and RFA_categorie=#contrats.categorie
									  and RFA_article=#contrats.article
									  and RFA_tarif=#contrats.tarif)

drop table #contrats


update #RFA
set RFA_rfa_due=0
where RFA_atteint_qte < RFA_qtect
and RFA_qtect!=0

update #RFA
set RFA_rfa_due=0
where RFA_atteint_val < RFA_valct
and RFA_valct!=0


/*-------------------------------*/


select  @rfa_pot = round(((isnull(@CAtotal,0) - isnull(@CAsansRFA,0) - isnull(@CARFAct,0) - isnull(@CARFAHct,0)) * isnull(@droit_pot,0)),2)
select 	@rfa_ca  = round(((isnull(@CAtotal,0) - isnull(@CAsansRFA,0) - isnull(@CARFAct,0) - isnull(@CARFAHct,0)) * isnull(@droitRFA,0)),2)



if @CAtotal	!= 0 and @contrat is null	  
	insert into #Finale_Detail (contrat,depart,marque,famille,categorie,article,tarif,qte_ct,atteint_qte,val_ct,atteint_val,rfa_due,rfa_pot,rfa_pc)
	values(' CA','','','','','','',0,0,0,@CAtotal,@rfa_ca,(case when @rfa_pot >= 0 then @rfa_pot else 0 end),0)

/* Insertion des lignes de RFA */

insert into #Finale_Detail (contrat,depart,marque,famille,categorie,article,tarif,qte_ct,atteint_qte,val_ct,atteint_val,rfa_due,rfa_pot,rfa_pc)
select RFA_contrat,RFA_depart,RFA_marque,RFA_famille,RFA_categorie,RFA_article,RFA_tarif,RFA_qtect,RFA_atteint_qte,RFA_valct,RFA_atteint_val,RFA_rfa_due,RFA_rfa_pot,RFA_pc
from #RFA



if @destination = 0
begin
  select 	isnull(contrat,''),isnull(depart,''),isnull(marque,''),isnull(famille,''),isnull(categorie,''),isnull(article,''),
			  isnull(tarif,''),qte_ct,atteint_qte,val_ct,atteint_val,rfa_due,rfa_pot,getdate()
  from #Finale_Detail
  order by contrat,depart,marque,famille,categorie,article,tarif
end
else if @destination = 1
begin
  select @RFAdue=sum(rfa_due)
  from #Finale_Detail
  
  select @RFAdue
end
else if @destination = 2
begin
  delete from FRFATemp where SPID=@@spid

  insert into FRFATemp (ANNEE,CLIENT,CONTRAT,DEPART,MARQUE,FAMILLE,CATEGORIE,ARTICLE,TARIF,QTE_CT,ATTEINT_QTE,VAL_CT,ATTEINT_VAL,RFA_DUE,RFA_POT,RFA_PC,SPID)
  select 	@an,@client,isnull(contrat,''),isnull(depart,''),isnull(marque,''),isnull(famille,''),isnull(categorie,''),isnull(article,''),
			  isnull(tarif,''),qte_ct,atteint_qte,val_ct,atteint_val,rfa_due,rfa_pot,isnull(rfa_pc,0),@@spid
  from #Finale_Detail
  order by contrat,depart,marque,famille,categorie,article,tarif
end

drop table #RFA
drop table #Finale_Detail



end



go

