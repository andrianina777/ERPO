


/* Procedure comparant la valeur du stock de mois a mois donne pour n-2, n-1 et l''annee choisie
	a partir des lignes de mouvement de stock */


create procedure Stock_Compare  (	@an			int,
								 	@depart		char(8)	= null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @mois	int

create table #Finale
(	
annee		int				not null,
depart		char(8)			not null,	/* Departement produits */
mois		int				not null,	/* Mois de la ligne */
prdeb		numeric(20,8)		null,	/* Valeur du Stock en debut de mois */
prvendu		numeric(20,8)		null,	/* PR vendu au cours du mois */
prrecu		numeric(20,8)		null	/* Valeur recue au cours du mois */
)

create table #Far
(
ARCODE		char(15)	not null,
ARDEPART	char(8)		not null
)


create table #Stock
(
annee			int				not null,
depart			char(8)			not null,
mois			int				not null,
valstock		numeric(20,8)		null,
valventes		numeric(20,8)		null,
valrecu			numeric(20,8)		null
)


if (@depart is null)
	begin
		insert into #Far (ARCODE,ARDEPART)
		select ARCODE,ARDEPART
		from FAR
		where ARTYPE = 0
	end
else if (@depart is not null)
	begin
		insert into #Far  (ARCODE,ARDEPART)
		select ARCODE,ARDEPART
		from FAR
		where ARDEPART=@depart
		and ARTYPE = 0
	end	
	

/* creation de toutes les lignes de mois pour les articles choisis */

declare @lemois	int
select  @lemois = 1

while @lemois <= 12
begin

 insert into #Stock (annee,depart,mois,valstock,valventes,valrecu)
 select @an-2,ARDEPART,@lemois,0,0,0
 from #Far
 group by ARDEPART
 
 insert into #Stock (annee,depart,mois,valstock,valventes,valrecu)
 select @an-1,ARDEPART,@lemois,0,0,0
 from #Far
 group by ARDEPART
 
 insert into #Stock (annee,depart,mois,valstock,valventes,valrecu)
 select @an,ARDEPART,@lemois,0,0,0
 from #Far
 group by ARDEPART
 
 select @lemois = @lemois +1

end


/******** Stock au 31/12 de l''annee n-3 (cad en janvier de n-2) */

insert into #Stock (annee,depart,mois,valstock)
select @an-2,ARDEPART,1,sum(isnull(MOISTOTPR,0))
from FMOIS,#Far
where ARCODE=MOISARTICLE
and MOISANNEE=@an-3
and MOISMOIS=12
and MOISQTE != 0
group by ARDEPART

				/* Stock entre et sorti de janvier a decembre de n-2 */

insert into #Stock (annee,depart,mois,valventes,valrecu)
select @an-2,ARDEPART,MSMOIS, sum(case when MSTYPE = 'S' then isnull(MSTOTPR,0)
							  	  when MSTYPE != 'S' then 0 end),
						 sum(case when MSTYPE = 'S' then 0
							  	  when MSTYPE != 'S' then isnull(MSTOTPR,0) end)
from FMS,#Far
where ARCODE=MSARTICLE
and MSANNEE=@an-2
and MSMOIS between 1 and 12
and MSQTE != 0
group by ARDEPART,MSMOIS


/******** Stock au 31/12 de l''annee n-2 (cad en janvier de n-1) */

insert into #Stock (annee,depart,mois,valstock)
select @an-1,ARDEPART,1,sum(isnull(MOISTOTPR,0))
from FMOIS,#Far
where ARCODE=MOISARTICLE
and MOISANNEE=@an-2
and MOISMOIS=12
and MOISQTE != 0
group by ARDEPART

				/* Stock entre et sorti de janvier a decembre de n-1 */

insert into #Stock (annee,depart,mois,valventes,valrecu)
select @an-1,ARDEPART,MSMOIS, sum(case when MSTYPE = 'S' then isnull(MSTOTPR,0)
							  	  when MSTYPE != 'S' then 0 end),
						 sum(case when MSTYPE = 'S' then 0
							  	  when MSTYPE != 'S' then isnull(MSTOTPR,0) end)
from FMS,#Far
where ARCODE=MSARTICLE
and MSANNEE=@an-1
and MSMOIS between 1 and 12
and MSQTE != 0
group by ARDEPART,MSMOIS


/******** Stock au 31/12 de l''annee en cours (cad en janvier de l''annee en cours) */

insert into #Stock (annee,depart,mois,valstock)
select @an,ARDEPART,1,sum(isnull(MOISTOTPR,0))
from FMOIS,#Far
where ARCODE=MOISARTICLE
and MOISANNEE=@an-1
and MOISMOIS=12
and MOISQTE != 0
group by ARDEPART

				/* Stock entre et sorti de janvier a decembre de l''annee en cours */

insert into #Stock (annee,depart,mois,valventes,valrecu)
select @an,ARDEPART,MSMOIS, sum(case when MSTYPE = 'S' then isnull(MSTOTPR,0)
							  	  when MSTYPE != 'S' then 0 end),
						 sum(case when MSTYPE = 'S' then 0
							  	  when MSTYPE != 'S' then isnull(MSTOTPR,0) end)
from FMS,#Far
where ARCODE=MSARTICLE
and MSANNEE=@an
and MSMOIS between 1 and 12
and MSQTE != 0
group by ARDEPART,MSMOIS


/* tableau recapitulatif */

insert into #Finale (annee,depart,mois,prdeb,prvendu,prrecu)
select annee,depart,mois,
		  sum(isnull(valstock,0)),
		  sum(isnull(valventes,0)),
		  sum(isnull(valrecu,0))
from #Stock
group by annee,depart,mois

delete from #Stock

create table #temp
(
t_depart		char(8)			not null,
t_annee			int				not null,
t_valdeb		numeric(14,2)		null,
t_valventes		numeric(14,2)		null,
t_valrecu		numeric(14,2)		null
)

select  @lemois = 2

while @lemois <= 12
begin

  insert into #temp (t_annee,t_depart,t_valdeb,t_valventes,t_valrecu)
  select annee,depart,prdeb,prvendu,prrecu
  from #Finale
  where mois = @lemois - 1
  
  
  update #Finale
  set prdeb = t_valdeb + t_valrecu - t_valventes
  from #temp
  where depart = t_depart
  and mois = @lemois
  and annee = t_annee
  
  delete from #temp
   
  select @lemois = @lemois +1

end


/***** select final *****/

/*			--------- Selection par mois ---------

select 	depart,mois,sum(case when annee=@an-2 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when annee=@an-1 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when annee=@an then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end)
from #Finale
group by depart, mois
order by depart, mois

*/


select depart,annee,sum(case when mois=1 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=2 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=3 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=4 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=5 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=6 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=7 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=8 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=9 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=10 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=11 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end),
					sum(case when mois=12 then (isnull(prdeb,0)-isnull(prvendu,0)+isnull(prrecu,0)) else 0 end)
from #Finale
group by depart, annee
order by depart, annee


drop table #Stock
drop table #Far
drop table #temp
drop table #Finale

end



go

