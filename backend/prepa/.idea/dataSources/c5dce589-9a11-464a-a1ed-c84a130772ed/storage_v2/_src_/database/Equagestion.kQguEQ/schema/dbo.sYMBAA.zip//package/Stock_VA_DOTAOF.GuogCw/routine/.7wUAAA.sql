



/* Procedure calculant la valeur des ventes de janvier au mois donne pour l''annee choisie
	a partir des lignes de  Produits Offerts et Dotations */


create procedure Stock_VA_DOTAOF	(	@ent		char(5) = null,
										@an			int,
							 		 	@mois		int,
									 	@compare	int = 0,
									 	@depart		char(8) = null,
										@produits	smallint = 0,
										@prodnsto	smallint = 1,
									 	@services	smallint = 2,
									 	@ports		smallint = 3,
									 	@comments	smallint = 4,
									 	@remises	smallint = 5,
									 	@rfa		smallint = 6,
									 	@assur		smallint = 7,
									 	@sansval	tinyint = 0,
									 	@marque		char(12) = null,
									 	@famille	char(8) = null
									 )
with recompile
as
begin

set arithabort numeric_truncation off

declare @modevalo	int
select  @modevalo = PMODEVALO from KParam


if (@mois<1 or @mois>12) 
select @mois=12


create table #Stock
(
depart			char(8)			not null,
marque			char(12)		not null,
famille			char(8)			not null,
valstock		numeric(14,2)	not null,
valventes		numeric(14,2)	not null,
valmarge		numeric(14,2)	not null,
valachat		numeric(14,2)	not null,
valstock_1		numeric(14,2)	not null,
valventes_1		numeric(14,2)	not null,
valmarge_1		numeric(14,2)	not null,
valachat_1		numeric(14,2)	not null,
offert_dota		tinyint			not null
)

create table #Stock2
(
article			char(15)		not null,
qte				int				not null,
date			smalldatetime	not null,
valstock		numeric(14,2)	not null,
valventes		numeric(14,2)	not null,
valmarge		numeric(14,2)	not null,
valachat		numeric(14,2)	not null,
valstock_1		numeric(14,2)	not null,
valventes_1		numeric(14,2)	not null,
valmarge_1		numeric(14,2)	not null,
valachat_1		numeric(14,2)	not null,
offert_dota		tinyint			not null,
annee			int				not null,
seq				numeric(14,0)	identity
)


if @modevalo = 0
begin

set forceplan on

insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,offert_dota)
select ARDEPART,ARFO,ARFAM,sum(isnull(ODTOTPR,0)),sum(isnull(ODTOTHT,0)),sum(isnull(ODTOTHT,0))-sum(isnull(ODTOTPR,0)),0,0,0,0,0,ODTYPE
from FOD(index periode),FAR
where (@ent is null or ODENT=@ent)
and ARCODE=ODAR
and ODAN=@an
and ODMOIS between 1 and @mois
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ARDEPART,ARFO,ARFAM,ODTYPE



if @compare=1
  begin
  
   insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,offert_dota)
   select ARDEPART,ARFO,ARFAM,sum(isnull(ODTOTPR,0)),sum(isnull(ODTOTHT,0)),sum(isnull(ODTOTHT,0))-sum(isnull(ODTOTPR,0)),0,0,0,0,0,ODTYPE
   from FOD(index periode),FAR
   where (@ent is null or ODENT=@ent)
   and ARCODE=ODAR
   and ODAN=@an-1
   and ODMOIS between 1 and @mois
   and (@depart is null or ARDEPART=@depart)
   and (@marque is null or ARFO=@marque)
   and (@famille is null or ARFAM=@famille)
   and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
   group by ARDEPART,ARFO,ARFAM,ODTYPE
	
  end

set forceplan off

end
else if @modevalo in (1,2,3,4)
begin

insert into #Stock2 (article,qte,date,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,offert_dota,annee)
select ODAR,sum(ODQTE),dateadd(hh,19,ODDATEFA),0,sum(isnull(ODTOTHT,0)),0,0,0,0,0,0,ODTYPE,1
from FOD(index periode),FAR
where (@ent is null or ODENT=@ent)
and ARCODE=ODAR
and ODAN=@an
and ODMOIS between 1 and @mois
and (@depart is null or ARDEPART=@depart)
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
group by ODAR,dateadd(hh,19,ODDATEFA),ODTYPE

	declare stock cursor 
	for select article,qte,date,seq
	from #Stock2
	order by seq
	for read only

	declare @article			char(15),
			@qte				int,
			@date				smalldatetime,
			@seq				numeric(14,0),
			@PrixRevient		numeric(14,4),
			@PrixRevientLigne 	numeric(14,2)

	
	open stock
	
	fetch stock
	into @article,@qte,@date,@seq
	
	while (@@sqlstatus = 0)
		begin
		
		select 	@PrixRevient = 0,
				@PrixRevientLigne = 0
		
		if @modevalo = 1								/*--------------------- PRM Annuel */
		begin
		  
		  select @PrixRevient=isnull(ARPRM,0)
		  from FAR
		  where ARCODE = @article
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
		end
		else if @modevalo = 2									/*--------------------- PUMP */
		begin
		  select @PrixRevient=isnull(PUMP,0)
		  from FPUM
		  where PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @date)
		  having PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @date)
		  and PUMDATE = max(PUMDATE)
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		end
		else if @modevalo = 3								/*--------------------- PRM Mensuel */
		begin
		  set rowcount 1
		  
		  select @PrixRevient=isnull(PRM,0)
		  from FPRM
		  where PRMAR = @article
		  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  and PRMAR = @article
		  order by PRMAN desc,PRMMOIS desc
		  
		  set rowcount 0
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
		end
		else  if @modevalo = 4								/*--------------------- DPA unitaire */
		begin
		  set rowcount 1			
		
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
		  from FBLL,FCV
		  where BLLAR=@article
		  and CVUNIF=BLLUA
		  having BLLAR=@article
		  and CVUNIF=BLLUA
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		
		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
			from FSIL,FAR,FCV
			where SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			having SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end
		  
		  set rowcount 0
		  
		  if @PrixRevient is null
			select @PrixRevient = 0
  
		  	select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)		  
		end

		update #Stock2 set valstock = @PrixRevientLigne, valmarge = valventes - @PrixRevientLigne where seq = @seq

		
		fetch stock
		into @article,@qte,@date,@seq
		
	end

	close stock
	deallocate cursor stock


if @compare=1
  begin
  
   insert into #Stock2 (article,qte,date,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,offert_dota,annee)
   select ODAR,sum(ODQTE),dateadd(hh,19,ODDATEFA),0,0,0,0,0,sum(isnull(ODTOTHT,0)),0,0,ODTYPE,-1
   from FOD(index periode),FAR
   where (@ent is null or ODENT=@ent)
   and ARCODE=ODAR
   and ODAN=@an-1
   and ODMOIS between 1 and @mois
   and (@depart is null or ARDEPART=@depart)
   and (@marque is null or ARFO=@marque)
   and (@famille is null or ARFAM=@famille)
   and ARTYPE in (@produits,@prodnsto,@services,@ports,@comments,@remises,@rfa,@assur)
   group by ODAR,dateadd(hh,19,ODDATEFA),ODTYPE
   
   	declare stock cursor 
	for select article,qte,date,seq
	from #Stock2
	where annee = -1
	order by seq
	for read only

	
	open stock
	
	fetch stock
	into @article,@qte,@date,@seq
	
	while (@@sqlstatus = 0)
		begin
		
		select 	@PrixRevient = 0,
				@PrixRevientLigne = 0
		
		if @modevalo = 1								/*--------------------- PRM Annuel */
		begin
		  
		  select @PrixRevient=isnull(ARPRM,0)
		  from FAR
		  where ARCODE = @article
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
		end
		else if @modevalo = 2									/*--------------------- PUMP */
		begin
		  select @PrixRevient=isnull(PUMP,0)
		  from FPUM
		  where PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @date)
		  having PUMAR = @article
		  and PUMDATE <= convert (smalldatetime, @date)
		  and PUMDATE = max(PUMDATE)
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)
		end
		else if @modevalo = 3								/*--------------------- PRM Mensuel */
		begin
		  set rowcount 1
		  
		  select @PrixRevient=isnull(PRM,0)
		  from FPRM
		  where PRMAR = @article
		  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  and PRMAR = @article
		  order by PRMAN desc,PRMMOIS desc
		  
		  set rowcount 0
		  
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)			
		end
		else  if @modevalo = 4								/*--------------------- DPA unitaire */
		begin
		  set rowcount 1			
		
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/CVLOT,4)
		  from FBLL,FCV
		  where BLLAR=@article
		  and CVUNIF=BLLUA
		  having BLLAR=@article
		  and CVUNIF=BLLUA
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))
		
		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/CVLOT,4)
			from FSIL,FAR,FCV
			where SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			having SILARTICLE=@article
			and ARCODE = SILARTICLE
			and ARUNITACHAT = CVUNIF
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end
		  
		  set rowcount 0
		  
		  if @PrixRevient is null
			select @PrixRevient = 0
  
		  	select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte)		  
		end

		update #Stock2 set valstock_1 = @PrixRevientLigne, valmarge_1 = valventes_1 - @PrixRevientLigne where seq = @seq

		
		fetch stock
		into @article,@qte,@date,@seq
		
	end

	close stock
	deallocate cursor stock
	
  end
  
    insert into #Stock (depart,marque,famille,valstock,valventes,valmarge,valachat,valstock_1,valventes_1,valmarge_1,valachat_1,offert_dota)
	select ARDEPART,ARFO,ARFAM,sum(valstock),sum(valventes),sum(valmarge),sum(valachat),
							   sum(valstock_1),sum(valventes_1),sum(valmarge_1),sum(valachat_1),offert_dota
  from #Stock2,FAR
  where ARCODE=article
  group by ARDEPART,ARFO,ARFAM,offert_dota

  drop table #Stock2

end


if @sansval = 0
	begin
	  select depart,marque,famille,FPLIB,sum(valstock),sum(valventes),sum(valmarge),sum(valachat),
								   sum(valstock_1),sum(valventes_1),sum(valmarge_1),offert_dota
	  from #Stock,FFP
	  where FPCODE=famille
	  group by depart,marque,famille,offert_dota,FPLIB
	  order by depart,marque,famille,offert_dota,FPLIB
	end
else if @sansval = 1
	begin
	  select depart,marque,famille,FPLIB,sum(valstock),sum(valventes),sum(valmarge),sum(valachat),
								   sum(valstock_1),sum(valventes_1),sum(valmarge_1),offert_dota
	  from #Stock,FFP
	  where FPCODE=famille
	  group by depart,marque,famille,offert_dota,FPLIB
	  having sum(valstock) != 0
	  	or  sum(valventes) != 0
		or  sum(valachat) != 0
		or  sum(valstock_1) != 0
		or  sum(valventes_1) != 0
		or  sum(valachat_1) != 0
	  order by depart,marque,famille,offert_dota,FPLIB
	end


drop table #Stock

end



go

