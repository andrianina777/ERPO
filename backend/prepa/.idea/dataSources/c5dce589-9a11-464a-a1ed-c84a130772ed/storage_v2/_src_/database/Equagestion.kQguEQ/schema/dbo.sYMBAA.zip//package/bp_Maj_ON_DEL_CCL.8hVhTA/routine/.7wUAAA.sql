/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_Maj_ON_DEL_CCL
grant execute on bp_Maj_ON_DEL_CCL to public
*/

CREATE PROCEDURE dbo.bp_Maj_ON_DEL_CCL(@code char(10))

AS
begin
		declare @prepspecif int,@bpcode char(10),@debut_prep datetime,@fin_prep datetime,@debut_ctrl datetime,@fin_ctrl datetime,@nb_colis char(5)
		
      if((select count(*) from FCCL where CCLCODE=@code and (isnull(CCLRESTE,0)-isnull(CCLQTEPREP,0))>0)=0 and (select count(*) from FFA where FACC=@code)=0)
      begin
      	 -- select top 1 @bpcode=BPCODE,@prepspecif=BPPREPSPECIF,@debut_prep=BPDATECRE,@fin_prep=BP_FIN_PREPA from FBP where BPCC=@code order by BPPREPSPECIF,BP_FIN_PREPA desc,BPDATECRE desc
      	  
      	  select @prepspecif=min(BPPREPSPECIF) from FBP where BPCC=@code
      	  select @debut_prep=min(BPDATECRE) from FBP where BPCC=@code
      	  select @fin_prep=max(BP_FIN_PREPA) from FBP where BPCC=@code
      	  
      	  if(@prepspecif<2)
      	  	begin
      	  		update FCC set CCSTADE_DET=4,CCPREPSPECIF=@prepspecif,CCDATE_4=@debut_prep,CCDATEECH2=@fin_prep where CCCODE=@code 
      	  	end
      	  else if(@prepspecif=2)
      	    begin
      	    	select @debut_ctrl=min(xDateCtrl) from xpCTRL_PLUS inner join FBP on BPCODE=xCode where BPCC=@code and xPrepSpecif=2 
      	    	update FCC set CCSTADE_DET=4,CCPREPSPECIF=@prepspecif,CCDATE_4=@debut_prep,CCDATEECH2=@fin_prep,CCDATEECH3=@debut_ctrl where CCCODE=@code 
      	    end
      	  else if(@prepspecif=3)
      	  	begin
      
      	  		
      	  		select @debut_ctrl=min(xDateCtrl) from xpCTRL_PLUS inner join FBP on BPCODE=xCode where BPCC=@code and xPrepSpecif=3 
      	  		
      	  		select @fin_ctrl=max(xDateFinCtrl) from xpCTRL_PLUS inner join FBP on BPCODE=xCode where BPCC=@code and xPrepSpecif=3 
      	  		
      	      	      	  		
      	  		update FCC set CCSTADE_DET=4,CCPREPSPECIF=@prepspecif,CCDATE_4=@debut_prep,CCDATEECH2=@fin_prep,CCDATEECH3=@debut_ctrl,CCDATEECH4=@fin_ctrl 
      	  		
      	  		where CCCODE=@code 
  
      	  	end
      end
      else if((select count(*)  from FBP where BPCC=@code)>0 and (select count(*) from FCCL where CCLCODE=@code and (isnull(CCLRESTE,0)-isnull(CCLQTEPREP,0))>0)>0 and (select count(*) from FFA where FACC=@code)=0)
      	begin
      		update FCC set CCSTADE_DET=3,CCPREPSPECIF=0 where CCCODE=@code
	  	end	    
  end
go

