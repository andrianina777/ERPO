
create procedure Tarifs_Duplication (
								    @ClientSource   char(12),   /* Code Client dont le tarif est a dupliquer */
								    @ClientDest	    char(12),   /* Code Client destinataire du nouveau tarif */
								    @Typetarif		char(10),	/* Code du type de tarif a dupliquer */
								    @Marche			char(12)	/* Code du type de marche a dupliquer */
								    )
with recompile
as
begin

set arithabort numeric_truncation off

create table #TarifsSource
(
SeqSource			numeric(14,0)	not null,
ArticleSource     	char(15)		not null,
MarcheSource		char(12)        not null,
TypeSource			char(10)		not null,
DevSource           char(3)			not null,
DebutSource         datetime        not null,
FinSource           datetime        not null,
QteSource           int				not null,
PrixSource          numeric(14,2)	not null
)

create table #TarifsDest
(
SeqDest			numeric(14,0)	not null,
ArticleDest     char(15)		not null,
MarcheDest		char(12)        not null,
TypeDest		char(10)		not null,
DevDest         char(3)			not null,
DebutDest       datetime        not null,
FinDest         datetime        not null,
QteDest         int				not null,
PrixDest        numeric(14,2)	not null
)

create table #Erreurs
(
Article         char(15)		not null,
Marche          char(12)        not null,
Types           char(10)		not null,
Dev             char(3)			not null,
ClientS         char(12)        not null,
DebutS          datetime        not null,
FinS            datetime        not null,
ClientD         char(12)        not null,
DebutD          datetime        not null,
FinD            datetime        not null
)

create table #Nouveaux
(
Sequentiel		numeric(14,0)	not null
)

declare @DateJour       datetime,
        @Ent            char(5),
        @LignesExiste   int,
        @NbErreurs      int,
        @NbResultats    int,
        @NewSeq         numeric(14,0),
        @Reservation    int,
        @User           int
        
declare @ArticleSource  char(15),
        @MarcheSource   char(12),
        @TypeSource	    char(10),
        @DevSource      char(3),
        @DebutSource    datetime,
        @FinSource      datetime,
        @QteSource      int,
        @PrixSource     numeric(14,2)
        
declare @ArticleDest  char(15),
        @MarcheDest   char(12),
        @TypeDest	  char(10),
        @DevDest      char(3),
        @DebutDest    datetime,
        @FinDest      datetime,
        @QteDest      int,
        @PrixDest     numeric(14,2)


select @DateJour=getdate()
select @Ent=isnull(CLENT,'') from FCL where CLCODE=@ClientDest
select @User=user_id()	

if @Typetarif='' select @Typetarif=null 
if @Marche='' 	 select @Marche=null 


insert into #TarifsSource
select  ARTCLSEQ,ARTCLAR,ARTCLMARCHE,ARTCLTYPE,ARTCLDEV,ARTCLDATEDEB,ARTCLDATEFIN,ARTCLQTE,ARTCLPVHT 
        from FARTCL 
        where ARTCLCL=@ClientSource and ARTCLDATEFIN>=@DateJour
        and (@Typetarif is null or ARTCLTYPE=@Typetarif)
        and (@Marche is null or ARTCLMARCHE=@Marche)

insert into #TarifsDest
select  ARTCLSEQ,ARTCLAR,ARTCLMARCHE,ARTCLTYPE,ARTCLDEV,ARTCLDATEDEB,ARTCLDATEFIN,ARTCLQTE,ARTCLPVHT
        from FARTCL 
        where ARTCLCL=@ClientDest and ARTCLDATEFIN>=@DateJour
        and (@Typetarif is null or ARTCLTYPE=@Typetarif)
        and (@Marche is null or ARTCLMARCHE=@Marche)       

select @NbResultats=count(*) from #TarifsDest

if @NbResultats=0 /* Le tarif destination etant vide, on copie tout le tarif source */
begin
    
    declare copie cursor 
    for select ArticleSource,MarcheSource,TypeSource,DevSource,DebutSource,FinSource,QteSource,PrixSource
    from #TarifsSource
    for read only
		
    open copie
  
    fetch copie
    into @ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource
  
    while (@@sqlstatus = 0)
	begin

        select @Reservation=1  			 						
        exec eq_GetSeq_proc 'FARTCL',@Reservation,@NewSeq output

        insert into FARTCL (ARTCLSEQ,ARTCLAR,ARTCLMARCHE,ARTCLTYPE,ARTCLDEV,ARTCLDATEDEB,ARTCLDATEFIN,ARTCLQTE,ARTCLPVHT,
                            ARTCLCL,ARTCLENT,ARTCLUSERCRE,ARTCLDATECRE,ARTCLUSERMDF,ARTCLDATEMDF)
        values (@NewSeq,@ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource,
                            @ClientDest,@Ent,@User,getdate(),@User,getdate())

        fetch copie
        into @ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource  
    end

    close copie
    deallocate cursor copie   
    
end

else

if @NbResultats>0 /* Le tarif destination n'est pas vide */
begin

    declare source cursor 
    for select ArticleSource,MarcheSource,TypeSource,DevSource,DebutSource,FinSource,QteSource,PrixSource
    from #TarifsSource
    for read only
		
    open source
  
    fetch source
    into @ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource
  
    while (@@sqlstatus = 0)
	begin
       
      
        select @LignesExiste=count(*) from #TarifsDest where    ArticleDest=@ArticleSource and 
                                                                MarcheDest=@MarcheSource and 
                                                                TypeDest=@TypeSource and 
                                                                DevDest=@DevSource  
                                                               
        if @LignesExiste=0  
        
        begin 
            
            /* cette ligne n'existe pas pour le client destination, on la cree */ 
               
                select @Reservation=1  			 						
                exec eq_GetSeq_proc 'FARTCL',@Reservation,@NewSeq output
                
                insert into #Nouveaux(Sequentiel) values (@NewSeq)

                insert into FARTCL (ARTCLSEQ,ARTCLAR,ARTCLMARCHE,ARTCLTYPE,ARTCLDEV,ARTCLDATEDEB,ARTCLDATEFIN,ARTCLQTE,ARTCLPVHT,
                            ARTCLCL,ARTCLENT,ARTCLUSERCRE,ARTCLDATECRE,ARTCLUSERMDF,ARTCLDATEMDF)
                values (@NewSeq,@ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource,
                            @ClientDest,@Ent,@User,getdate(),@User,getdate())   
        end
        
        else
      
        begin /* cette ligne existe pour le client destination, on la teste */
                   
            declare dest cursor 
            for select ArticleDest,MarcheDest,TypeDest,DevDest,DebutDest,FinDest,QteDest,PrixDest
            from #TarifsDest
            where   ArticleDest=@ArticleSource and 
                    MarcheDest=@MarcheSource and 
                    TypeDest=@TypeSource and 
                    DevDest=@DevSource
            for read only
		
            open dest
  
            fetch dest
            into @ArticleDest,@MarcheDest,@TypeDest,@DevDest,@DebutDest,@FinDest,@QteDest,@PrixDest
  
            while (@@sqlstatus = 0)
	        begin
                                    
                 /* verif lignes identiques */

                if (@DebutDest=@DebutSource and @FinDest=@FinSource and @QteDest=@QteSource and @PrixDest=@PrixSource)               
                    print ""
                    /* on ne fait rien si ligne identique existe */                                                              
                
                else

                /* comparaison */
                              
                if ((@DebutDest>@DebutSource and @DebutDest<@FinSource) or (@FinDest>@DebutSource and @FinDest<@FinSource))
                begin                   
                    /* erreur si une des deux dates origine est comprise dans les dates destination */
                
                    insert into #Erreurs (  Article,Marche,Types,Dev,
                                            ClientS,DebutS,FinS,ClientD,DebutD,FinD)	
                    values (@ArticleSource,@MarcheSource,@TypeSource,@DevSource,
                            @ClientSource,@DebutSource,@FinSource,@ClientDest,@DebutDest,@FinDest)                       
                end
                
                else
                
                begin                                       
                    /* On sup toutes les lignes identiques quelque soit la qte et prix et on les recree */
                    /* pour le cas ou les intervalles de qtes soient differents */
                    
                    delete from FARTCL where    ARTCLCL=@ClientDest and
                                                ARTCLAR=@ArticleDest and 
                                                ARTCLMARCHE=@MarcheDest and 
                                                ARTCLTYPE=@TypeDest and 
                                                ARTCLDEV=@DevDest and
                                                ARTCLDATEDEB=@DebutDest and
                                                ARTCLDATEFIN=@FinDest and
                                                ARTCLSEQ not in (select Sequentiel from #Nouveaux)
                                                              
                
                     select @Reservation=1  			 						
                     exec eq_GetSeq_proc 'FARTCL',@Reservation,@NewSeq output
                     
                     insert into #Nouveaux(Sequentiel) values (@NewSeq)
                     /* on met dans une table historique les lignes que l'on vient de creer pour ne pas les rÃ-effacer ! */

                     insert into FARTCL (ARTCLSEQ,ARTCLAR,ARTCLMARCHE,ARTCLTYPE,ARTCLDEV,ARTCLDATEDEB,ARTCLDATEFIN,ARTCLQTE,ARTCLPVHT,
                            ARTCLCL,ARTCLENT,ARTCLUSERCRE,ARTCLDATECRE,ARTCLUSERMDF,ARTCLDATEMDF)
                     values (@NewSeq,@ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource,
                            @ClientDest,@Ent,@User,getdate(),@User,getdate())
                end
                             
                fetch dest
                into @ArticleDest,@MarcheDest,@TypeDest,@DevDest,@DebutDest,@FinDest,@QteDest,@PrixDest 
    
    
            end
            close dest
            deallocate cursor dest 
        
        end 

        fetch source
        into @ArticleSource,@MarcheSource,@TypeSource,@DevSource,@DebutSource,@FinSource,@QteSource,@PrixSource          
    end

    close source
    deallocate cursor source   

end

/* Adaptive Server has expanded all '*' elements in the following statement */ select #Erreurs.Article, #Erreurs.Marche, #Erreurs.Types, #Erreurs.Dev, #Erreurs.ClientS, #Erreurs.DebutS, #Erreurs.FinS, #Erreurs.ClientD, #Erreurs.DebutD, #Erreurs.FinD from #Erreurs

drop table #TarifsSource
drop table #TarifsDest
drop table #Erreurs
drop table #Nouveaux

end	
go

