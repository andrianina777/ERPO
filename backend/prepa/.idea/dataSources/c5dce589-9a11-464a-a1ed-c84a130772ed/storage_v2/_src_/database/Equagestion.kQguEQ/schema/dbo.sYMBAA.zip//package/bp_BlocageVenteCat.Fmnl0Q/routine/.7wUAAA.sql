CREATE PROCEDURE dbo.bp_BlocageVenteCat(
		@codeClient char(25),
		@codeArticle char(30))
with recompile
AS
begin
	 declare
	 	@cat char(15),
	 	@count int
	 
	 	select @cat=CLSA from FCL where CLCODE=@codeClient

		select count(*)  from xBlocageVenteCat where ((bvcClient=@codeClient)     or (bvcCategorie=@cat and bvcClient='*')) and bvcArticle=@codeArticle 
		and convert (DATE,bvcDatedebut,103)<=convert(DATE,getDate(),103) and convert(DATE,bvcDatefin,103)>=convert(DATE,getDate(),103)
end
go

