


create procedure Suivi_Cdes (@ent				char(5)	= null,
							 @an				smallint,
							 @moisdeb			tinyint,
							 @moisfin			tinyint,
							 @chefprod			char(8) = null,
							 @depart			char(8) = null,
							 @marque			char(12) = null,
							 @famille			char(8) = null,
							 @categorie			char(8) = null,
							 @article			char(15) = null,
							 @client			char(12) = null,
							 @centrale			char(12) = null,
							 @repcentral		char(8) = null,
							 @repdivision		char(8) = null,
							 @produits			smallint = 0,
							 @prodnsto			smallint = 1,
							 @services			smallint = 2,
							 @ports				smallint = 3,
							 @comments			smallint = 4,
							 @remises			smallint = 5,
							 @rfa				smallint = 6,
							 @assur				smallint = 7,
							 @nostats			smallint = 8,	/* Ne devrait pas faire partie du traitement - pas ajoute dans le select */
							 @modevalo			tinyint = 0,	/* 0 = FIFO, 1 = PRM Global, 2 = PUMP, 3 = PRM Mensuel, 4 = DPA unitaire, 5 = PA unitaire HT	*/
							 @commande			char(10) = null,
							 @article_groupe	char(16) = null,
							 @matiere			char(14) = null,
							 @couleur			char(8) = null,
							 @grille			char(10) = null,
							 @calibre			char(14) = null,
							 @produit			char(15) = null,
							 @aremp				char(16) = null,
							 @arforeign1		char(12) = null,
							 @arforeign2		char(12) = null,
							 @activite			char(6) = null,
							 @classe			char(10) = null,
							 @departgeo			char(12) = null,
							 @groupe1			char(8) = null,
							 @groupe2			char(8) = null,
							 @groupe3			char(8) = null,
							 @fichier			tinyint	= 0			/* 0=cdes en cours(FRCC) 1=toutes les cdes(FCCL)*/
							)
with recompile
as
begin

set arithabort numeric_truncation off


declare	@date1			smalldatetime,
		@date2			smalldatetime

if @an != 0
begin
select @date1=convert(datetime,convert(char(2),@moisdeb)+"/01/"+convert(char(4),@an))
select @date2=convert(datetime,convert(char(2),@moisfin)+"/01/"+convert(char(4),@an))
select @date2=dateadd(mm,1,@date2)
select @date2=dateadd(dd,-1,@date2)
end

select @departgeo=@departgeo+"%"  

create table #Final
(
SEQ			int		not null
)

delete from FMGT where MGTSPID=@@spid

	
if @fichier=0													/*-------- Lignes de commandes avec code stock ------------*/
  insert into #Final (SEQ)
  select RCCSEQ
  from FRCC,FCCL,FCL,FAR
  where ARCODE=RCCARTICLE
  and RCCSEQ=CCLSEQ
  and CCLCL=CLCODE
  and (@an = 0 or RCCDATE between @date1 and @date2)
  and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)
  and (@chefprod is null or ARCHEFP = @chefprod)
  and (@depart is null or ARDEPART = @depart)
  and (@marque is null or ARFO = @marque)
  and (@famille is null or ARFAM = @famille)
  and (@categorie is null or ARGRFAM = @categorie)
  and (@article is null or ARCODE = @article)
  and (@client is null or RCCCL = @client)
  and (@centrale is null or CLCODEGROUPE = @centrale)
  and (@repcentral is null or CCLREP = @repcentral)
  and (@repdivision is null or CCLREPDIV = @repdivision)
  and (@ent is null or RCCENT=@ent)
  and (@commande is null or CCLCODE = @commande)
  and (@article_groupe is null or ARREGROUPE = @article_groupe)
	and (@matiere is null or ARMATIERE = @matiere)
	and (@couleur is null or ARCOULEUR = @couleur)
	and (@grille is null or ARGRILLE = @grille)
	and (@calibre is null or ARCALIBRE = @calibre)
	and (@produit is null or ARPRODUIT = @produit)
	and (@aremp is null or AREMP = @aremp)
	and (@arforeign1 is null or ARFOREIGN1 = @arforeign1)
	and (@arforeign2 is null or ARFOREIGN2 = @arforeign2)
	and (@activite is null or CLSA = @activite)
	and (@classe is null or CLCLASSE = @classe)
	and (@groupe1 is null or CLGROUPE1 = @groupe1)
	and (@groupe2 is null or CLGROUPE2 = @groupe2)
	and (@groupe3 is null or CLGROUPE3 = @groupe3)
  and (@departgeo is null or CLCP like @departgeo)  
else																		/*-------- Lignes de toutes les commandes ------------*/
	insert into #Final (SEQ)
  select CCLSEQ
  from FCCL,FCL,FAR
  where ARCODE=CCLARTICLE
  and CCLCL=CLCODE
  and (@an = 0 or CCLDATE between @date1 and @date2)
  and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)
  and (@chefprod is null or ARCHEFP = @chefprod)
  and (@depart is null or ARDEPART = @depart)
  and (@marque is null or ARFO = @marque)
  and (@famille is null or ARFAM = @famille)
  and (@categorie is null or ARGRFAM = @categorie)
  and (@article is null or ARCODE = @article)
  and (@client is null or CCLCL = @client)
  and (@centrale is null or CLCODEGROUPE = @centrale)
  and (@repcentral is null or CCLREP = @repcentral)
  and (@repdivision is null or CCLREPDIV = @repdivision)
  and (@ent is null or CCLENT=@ent)
  and (@commande is null or CCLCODE = @commande)
  and (@article_groupe is null or ARREGROUPE = @article_groupe)
	and (@matiere is null or ARMATIERE = @matiere)
	and (@couleur is null or ARCOULEUR = @couleur)
	and (@grille is null or ARGRILLE = @grille)
	and (@calibre is null or ARCALIBRE = @calibre)
	and (@produit is null or ARPRODUIT = @produit)
	and (@aremp is null or AREMP = @aremp)
	and (@arforeign1 is null or ARFOREIGN1 = @arforeign1)
	and (@arforeign2 is null or ARFOREIGN2 = @arforeign2)
	and (@activite is null or CLSA = @activite)
	and (@classe is null or CLCLASSE = @classe)
	and (@groupe1 is null or CLGROUPE1 = @groupe1)
	and (@groupe2 is null or CLGROUPE2 = @groupe2)
	and (@groupe3 is null or CLGROUPE3 = @groupe3)
  and (@departgeo is null or CLCP like @departgeo)  
							
  create unique index seq on #Final (SEQ)

  declare @date					smalldatetime,
		  @articlepr			char(15),
		  @qte					int,
		  @totalht				numeric(14,2),
		  @cvlot				int,
		  @PrixRevient			numeric(14,4),
		  @PrixRevientLigne		numeric(14,2),
		  @seq					int,
		  @lettre				char(4),
		  @arprm				numeric(14,4),
		  @cclfrais				numeric(14,2),
		  @cclpaht				numeric(14,2)

	if @fichier=0													/*-------- Lignes des commandes en cours ------------*/
  	declare factures cursor
 	 	for select SEQ,dateadd(hh,19,RCCDATE),RCCARTICLE,RCCQTE,CCLTOTALHT/CCLQTE*RCCQTE,CVLOT,isnull(ARPRM,0),isnull(CCLFRAIS,0),isnull(CCLPAHT,0)
  	from #Final,FRCC,FCCL,FAR,FCV
  	where RCCSEQ=SEQ
  	and RCCSEQ=CCLSEQ
  	and ARCODE=RCCARTICLE
  	and ARUNITACHAT=CVUNIF
  	order by SEQ
 	 	for read only
	else																	/*-------- Lignes de toutes les commandes ------------*/
		declare factures cursor
 	 	for select SEQ,dateadd(hh,19,CCLDATE),CCLARTICLE,CCLQTE,CCLTOTALHT,CVLOT,isnull(ARPRM,0),isnull(CCLFRAIS,0),isnull(CCLPAHT,0)
  	from #Final,FCCL,FAR,FCV
  	where CCLSEQ=SEQ
  	and ARCODE=CCLARTICLE
  	and ARUNITACHAT=CVUNIF
  	order by SEQ
 	 	for read only
	
	open factures

	fetch factures
	into @seq,@date,@articlepr,@qte,@totalht,@cvlot,@arprm,@cclfrais,@cclpaht

	while (@@sqlstatus = 0)
		begin
		select 	@PrixRevient = 0,
				@PrixRevientLigne = 0

		if @modevalo = 0										/*--------------------- FIFO calcule comme DPA pour les cdes clients */
		begin
		  set rowcount 1

		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/@cvlot,4)
		  from FBLL
		  where BLLAR=@articlepr
		  having BLLAR=@articlepr
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))

		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/@cvlot,4)
			from FSIL
			where SILARTICLE=@articlepr
			having SILARTICLE=@articlepr
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end

		  set rowcount 0

		  if @PrixRevient is null
		    select @PrixRevient = 0

		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @cclfrais
		end
		else if @modevalo = 1									/*--------------------- PRM */
		begin
		  select @PrixRevientLigne = convert(numeric(14,2),@arprm * @qte) + @cclfrais
		end
		else if @modevalo = 2									/*--------------------- PUMP */
		begin
		  select @PrixRevient=isnull(PUMP,0)
		  from FPUM
		  where PUMAR = @articlepr
		  and PUMDATE <= convert (smalldatetime, @date)
		  having PUMAR = @articlepr
		  and PUMDATE <= convert (smalldatetime, @date)
		  and PUMDATE = max(PUMDATE)

		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @cclfrais
		end
		else if @modevalo = 3								/*--------------------- PRM Mensuel */
		begin
		  set rowcount 1

		  select @PrixRevient=isnull(PRM,0)
		  from FPRM
		  where PRMAR = @articlepr
		  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))
		  and PRMAR = @articlepr
		  order by PRMAN desc,PRMMOIS desc

		  set rowcount 0

		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @cclfrais
		end
		else  if @modevalo = 4								/*--------------------- DPA unitaire */
		begin
		  set rowcount 1

		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/@cvlot,4)
		  from FBLL
		  where BLLAR=@articlepr
		  having BLLAR=@articlepr
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))

		  if isnull(@PrixRevient,0)=0
		  begin
			select @PrixRevient = round((SILPAHT+SILFRAIS)/@cvlot,4)
			from FSIL
			where SILARTICLE=@articlepr
			having SILARTICLE=@articlepr
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))
		  end

		  set rowcount 0

		  if @PrixRevient is null
		    select @PrixRevient = 0

		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @cclfrais
		end
		else if @modevalo = 5									/*--------------------- PA Unitaire HT */ 
		begin
			select @PrixRevient = @cclpaht   
		  select @PrixRevientLigne = convert(numeric(14,2),@cclpaht * @qte) 
		end   
	
		if @fichier=0												/*-------- Lignes des commandes en cours ------------*/
			insert into FMGT (MGTCHEFP,MGTDEPART,MGTMARQUE,MGTFAM,MGTARTICLE,MGTLIB,MGTCL,
						MGTREP,MGTREPDIV,MGTGROUPE,MGTQTE,MGTTOTALHT,MGTPR,MGTMARGE,MGTSPID
						,MGTCODE,MGTGRFAM,MGTSA,MGTREGION,MGTPAYS,MGTCLASSE,MGTCOMPTE,
						MGTPRODUIT,MGTAREMP,MGTARMATIERE,MGTARCOULEUR,MGTARGRILLE,MGTARCALIBRE,
						MGTARFOREIGN1,MGTARFOREIGN2,MGTCP,MGTCLGROUPE1,MGTCLGROUPE2,MGTCLGROUPE3)  
			select isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),
					isnull(RCCARTICLE,""),isnull(ARLIB,""),isnull(CCLCL,""),isnull(CCLREP,""),
					isnull(CCLREPDIV,""),isnull(CLCODEGROUPE,""),RCCQTE,isnull(@totalht,0),
					@PrixRevientLigne,isnull(@totalht,0) - @PrixRevientLigne,@@spid,CCLCODE,
					"",isnull(CLSA,""),"","",isnull(CLCLASSE,""),"",
					isnull(ARPRODUIT,""),isnull(AREMP,""),isnull(ARMATIERE,""),isnull(ARCOULEUR,""),
					isnull(ARGRILLE,""),isnull(ARCALIBRE,""),isnull(ARFOREIGN1,""),isnull(ARFOREIGN2,""),
					isnull(CLCP,""),isnull(CLGROUPE1,""),isnull(CLGROUPE2,""),isnull(CLGROUPE3,"")
			from FRCC,FCCL,FCL,FAR
			where RCCSEQ=@seq
			and RCCARTICLE=ARCODE
			and RCCCL=CLCODE
			and CCLSEQ=RCCSEQ
		else																/*-------- Lignes de toutes les commandes ------------*/
			insert into FMGT (MGTCHEFP,MGTDEPART,MGTMARQUE,MGTFAM,MGTARTICLE,MGTLIB,MGTCL,
						MGTREP,MGTREPDIV,MGTGROUPE,MGTQTE,MGTTOTALHT,MGTPR,MGTMARGE,MGTSPID
						,MGTCODE,MGTGRFAM,MGTSA,MGTREGION,MGTPAYS,MGTCLASSE,MGTCOMPTE,
						MGTPRODUIT,MGTAREMP,MGTARMATIERE,MGTARCOULEUR,MGTARGRILLE,MGTARCALIBRE,
						MGTARFOREIGN1,MGTARFOREIGN2,MGTCP,MGTCLGROUPE1,MGTCLGROUPE2,MGTCLGROUPE3)  
			select isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),
					isnull(CCLARTICLE,""),isnull(ARLIB,""),isnull(CCLCL,""),isnull(CCLREP,""),
					isnull(CCLREPDIV,""),isnull(CLCODEGROUPE,""),CCLQTE,isnull(@totalht,0),
					@PrixRevientLigne,isnull(@totalht,0) - @PrixRevientLigne,@@spid,CCLCODE,
					"",isnull(CLSA,""),"","",isnull(CLCLASSE,""),"",
					isnull(ARPRODUIT,""),isnull(AREMP,""),isnull(ARMATIERE,""),isnull(ARCOULEUR,""),
					isnull(ARGRILLE,""),isnull(ARCALIBRE,""),isnull(ARFOREIGN1,""),isnull(ARFOREIGN2,""),
					isnull(CLCP,""),isnull(CLGROUPE1,""),isnull(CLGROUPE2,""),isnull(CLGROUPE3,"")
			from FCCL,FCL,FAR
			where CCLSEQ=@seq
			and CCLARTICLE=ARCODE
			and CCLCL=CLCODE
		
		
		fetch factures
		into @seq,@date,@articlepr,@qte,@totalht,@cvlot,@arprm,@cclfrais,@cclpaht

	end

	close factures
	deallocate cursor factures

	drop table #Final

end



go

