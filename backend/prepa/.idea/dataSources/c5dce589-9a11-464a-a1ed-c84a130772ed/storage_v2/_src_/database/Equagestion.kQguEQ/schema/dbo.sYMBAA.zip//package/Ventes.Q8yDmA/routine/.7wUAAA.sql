


create procedure Ventes(@ent		char(5)	= null,
						@fourn		char(12),
						@fam		char(8),
						@date1		datetime,
						@date2		datetime)
with recompile
as
begin

create table #Far
(
ARCODE	char(15)	null,
ARLIB	varchar(80)	null,
ARFAM	char(8)		null
)

insert into #Far
select ARCODE,ARLIB,ARFAM
from FAR
where ARFO=@fourn
and ARFAM=@fam

create unique clustered index code on #Far(ARCODE)


select ARCODE,ARLIB,ARFAM,Quantite=sum(BELQTE)
from #Far,FBEL(4)
where ARCODE=BELARTICLE
and BELDATE between @date1 and @date2
and (@ent is null or BELENT=@ent)
group by ARFAM,ARCODE,ARLIB
order by ARFAM,ARCODE
compute sum(sum(BELQTE)) by ARFAM


drop table #Far

end



go

