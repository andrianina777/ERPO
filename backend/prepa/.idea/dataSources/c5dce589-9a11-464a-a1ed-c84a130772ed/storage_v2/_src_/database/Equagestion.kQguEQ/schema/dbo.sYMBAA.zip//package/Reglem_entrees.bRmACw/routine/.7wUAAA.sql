


create procedure Reglem_entrees (@ent	char(5)	= null,
						 		 @date1	smalldatetime,
						 		 @date2	smalldatetime)
			
with recompile
as
begin

	create table #Stock
	(
	Libelle		char(35)		not null,
	Article		char(15)		not null,
	Famille		char(8)			not null,
	Categorie	char(12)		not null,
	Modele		char(8)			not null,
	Calibre		char(14)		not null,
	Marque		char(12)		not null,
	Provenance	varchar(20)		not null,
	Quantite	int					null
	)

	declare @societe char(12),
			@coordsoc varchar(200)

	select @societe=PSOC from KParam
	

	/*----------------------------------------------------------------------------*/	
	/* Livraisons fournisseurs : Materiel sorti par BLL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Famille,Categorie,Modele,Calibre,Marque,Provenance,Quantite)
	select  'Livraisons fournisseurs',BLLAR,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),
	ARFO,BLLFO,sum(BLLQTE)
	from FBLL,FAR,FDP
	where BLLAR=ARCODE 
	and ARREGLE in (1,3)
	and BLLDATE between @date1 and @date2
	and DPCODE=BLLDEP and (@ent is null or (BLLENT=@ent and DPENT=@ent and DPCENTRAL=0))
	group by BLLAR,ARFAM,ARPRODUIT,ARGRFAM,ARCALIBRE,ARFO,BLLFO

	
	/*----------------------------------------------------------------------------*/	
	/* Entree depuis douane : Materiel entre par DOL entre les dates indiquees */
	
	insert into #Stock (Libelle,Article,Famille,Categorie,Modele,Calibre,Marque,Provenance,Quantite)
	select  'Entrees depuis douanes',DOLAR,ARFAM,isnull(ARPRODUIT,""),ARGRFAM,isnull(ARCALIBRE,""),
	ARFO,@societe,sum(DOLQTE)
	from FDOL,FAR,FDP
	where ARCODE=DOLAR 
	and ARREGLE in (1,3)
	and DOLDATE between @date1 and @date2
	and DOLQTE > 0
	and DPCODE=DOLDEP and (@ent is null or (DOLENT=@ent and DPENT=@ent and DPCENTRAL=0))
	group by DOLAR,ARFAM,ARPRODUIT,ARGRFAM,ARCALIBRE,ARFO
		
	
	/* Liste finale */
	
	select Mouvements=Libelle,Article=Article,Famille=Famille,Categorie=Categorie,Modele=Modele,
	Calibre=Calibre,Marque=Marque,Provenance=Provenance,Quantite=Quantite
	from #Stock
	
	drop table #Stock
	
end



go

