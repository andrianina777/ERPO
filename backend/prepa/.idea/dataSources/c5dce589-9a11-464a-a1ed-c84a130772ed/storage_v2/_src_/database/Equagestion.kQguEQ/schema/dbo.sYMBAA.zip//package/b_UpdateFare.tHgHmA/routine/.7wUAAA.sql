create procedure dbo.b_UpdateFare 

AS
begin
        declare @seq int

        
        declare liste cursor for
                select ARESEQ
                from FARE_BAK where AREVALID=0
                
        open liste 
        fetch liste into @seq
        while (@@sqlstatus=0)
        begin
        		 update FARE set AREVALID=0 where ARESEQ=@seq 
	             fetch liste into @seq
        end        
		close liste
		deallocate cursor liste
end

go

