


create procedure BEBP_Repart (@Depot            char(4),
                              @Livrables        tinyint         = 1,    /* lignes entierement livrables uniquement = VVS4    */
                              @EtatStock        tinyint         = 1,    /* lignes stock depot = VVS7    */
                              @vaexpedition     tinyint         = 0,    /* = 0 si Resa/Prepa/Exped. = 1 si Traitement Cdes Clients    */
                              @completionmini   tinyint         = null, /* taux de completion mini des CC non expediees */
                              @encours          numeric(14,2)   = null, /* encours si CC partiellement expediee */
                              @nonfranco        tinyint         = 0,    /* CC non franco uniquement */
                              @MauvaisPayeur    tinyint         = 0,
                              @ent              char(5)         = null
                             )
with recompile
as
begin

set arithabort numeric_truncation off


create table #Stock
(
ArticleST    char(15)    not null,
StockDepot    int                null,
StockRes    int                null
)

create table #StockTemp
(
ArticleST    char(15)    not null,
StockDepot    int                null,
StockRes    int                null
)


create table #Reservations
(
ArticleRes    char(15)    not null,
TotalRes    int                null
)

create table #Art
(
CCLARTICLE        char(15)    not null
)



/*            base et VGSPID  et  VGSITE                                        */
/* ************************************************************************ */

declare @base             varchar(50)
select     @base = db_name()

/*    dump tran @base with truncate_only    */


declare @vgspid    int
select @vgspid = @@spid


declare @vgsite    int
select @vgsite = KISITE from KInfos

declare @pdureeres    int
select @pdureeres = isnull(PDUREERES,0) from KParam


/*    VPREFPREPCOMP = Traitements des composes composables                    */
/* ************************************************************************ */
/*  NON PRIS EN COMPTE POUR L INSTANT                                        */

declare @vprefprepcomp    int,
        @Autoris        int
        
execute eqGetAutorisations_out "EquaGestion","Prep_Exp","PREPCOMP",@Autoris = @Autoris output
select @vprefprepcomp = @Autoris
/*


update PREP_TEMP set    TEMP_VAQTE = TEMP_CCLRESTE,
                        TEMP_VAQTEARES = TEMP_CCLRESTE + TEMP_CCLQTEPREP,
                        TEMP_VATOTALARES = TEMP_VV0N7,
                        TEMP_VATEST = 0,
                        TEMP_VATEST2 = 0,
                        TEMP_VASTOCKDISPO = 0,
                        TEMP_cStockTotal = 0
where TEMP_ID = @vgspid
*/


/*    Clients        */

declare @OK            tinyint,
        @CT            tinyint,
        @MP            tinyint,
        @CI            tinyint

if @MauvaisPayeur = 0
  begin
      select     @OK = 0, @CT = 1, @MP = 0, @CI = 0
  end
else if @MauvaisPayeur = 1
  begin
      select     @OK = 0, @CT = 1, @MP = 2, @CI = 2
  end
else if @MauvaisPayeur = 2
  begin
      select     @OK = 2, @CT = 2, @MP = 2, @CI = 2
  end



/*        dispo sur depot de la preparation                                    */
/* ************************************************************************ */

declare @art        char(15),
        @qteres        int,
        @identity    numeric(14,0)

declare Dispo cursor
for select    TEMP_CCLARTICLE, TEMP_Identity
from PREP_TEMP
where TEMP_ID = @vgspid
for read only

open Dispo
fetch Dispo into @art,@identity

while (@@sqlstatus=0)
begin  
    
    select @qteres = 0
    
    select @qteres = sum(isnull(TEMP_CCLQTERES,0))
    from PREP_TEMP
    where TEMP_ID = @vgspid 
    and TEMP_CCLARTICLE = @art
    
    update PREP_TEMP set TEMP_VASTDEPDISPO = TEMP_VASTOCKDEPOT - TEMP_VARESDEPOT + @qteres
    where TEMP_Identity = @identity

    fetch Dispo into @art,@identity
end




/*    pour les reservations, Tout le stock du depot est pris en compte    */
/* ******************************************************************** */
/*  NON PRIS EN COMPTE POUR L INSTANT                                        */

/*

update PREP_TEMP set     TEMP_VATEST = 1
where TEMP_ID = @vgspid
and ((TEMP_ARTYPE<>0) or (TEMP_CCLQTERES>0) or (TEMP_VASTDEPDISPO>=TEMP_VATOTALARES))

*/

/*    pour les livraisons, seul le stock du depot est pris en compte            */
/* ************************************************************************ */
/*  NON PRIS EN COMPTE POUR L INSTANT                                        */

/*

update PREP_TEMP set     TEMP_VATEST2 = 1
where TEMP_ID = @vgspid
and TEMP_ARNUMEROTE=0 
and (TEMP_ARTYPE<>0 or (TEMP_VASTDEPDISPO>0 and TEMP_VASTDEPDISPO>=TEMP_VATOTALARES))

if @vgsite = 8
    update PREP_TEMP set TEMP_VATEST2 = 0 where TEMP_ID = @vgspid

*/

/*    dispo sur tous depots                                                    */
/* ************************************************************************ */

update PREP_TEMP set TEMP_VASTOCKDISPO = TEMP_VASTDEPOT + TEMP_VV0N2 - TEMP_VARESTOTAL
where TEMP_ID = @vgspid
and TEMP_VASTDEPOT + TEMP_VV0N2 - TEMP_VARESTOTAL > 0


update PREP_TEMP set TEMP_cStockTotal = TEMP_VV0N2 + TEMP_VASTDEPOT
where TEMP_ID = @vgspid

update PREP_TEMP set TEMP_CCLDATERESFIN = dateadd(dd,@pdureeres,TEMP_CCLDATE)
where TEMP_ID = @vgspid
and TEMP_CCLDATE >= getdate() and TEMP_CCLDATERESFIN is null

update PREP_TEMP set TEMP_CCLDATERESFIN = dateadd(dd,@pdureeres,getdate())
where TEMP_ID = @vgspid
and TEMP_CCLDATE < getdate() and TEMP_CCLDATERESFIN is null

/*    Remplace les retours charriot et tabulations                                */
/* ************************************************************************ */

update PREP_TEMP set TEMP_ARLIB = str_replace(TEMP_ARLIB,char(9)," ")
where TEMP_ID = @vgspid
and charindex(char(9),TEMP_ARLIB) <> 0

update PREP_TEMP set TEMP_ARLIB = str_replace(TEMP_ARLIB,char(10),char(13))
where TEMP_ID = @vgspid
and charindex(char(10),TEMP_ARLIB) <> 0

update PREP_TEMP set TEMP_ARLIB = str_replace(TEMP_ARLIB,char(13)+char(13),char(13))
where TEMP_ID = @vgspid
and charindex(char(13)+char(13),TEMP_ARLIB) <> 0

update PREP_TEMP set TEMP_ARLIB = str_replace(TEMP_ARLIB,char(13)," ")
where TEMP_ID = @vgspid
and charindex(char(13),TEMP_ARLIB) <> 0


update PREP_TEMP set TEMP_CCCOMMENTAIRES = str_replace(TEMP_CCCOMMENTAIRES,char(9)," ")
where TEMP_ID = @vgspid
and charindex(char(9),TEMP_CCCOMMENTAIRES) <> 0

update PREP_TEMP set TEMP_CCCOMMENTAIRES = str_replace(TEMP_CCCOMMENTAIRES,char(10),char(13))
where TEMP_ID = @vgspid
and charindex(char(10),TEMP_CCCOMMENTAIRES) <> 0

update PREP_TEMP set TEMP_CCCOMMENTAIRES = str_replace(TEMP_CCCOMMENTAIRES,char(13)+char(13),char(13))
where TEMP_ID = @vgspid
and charindex(char(13)+char(13),TEMP_CCCOMMENTAIRES) <> 0

update PREP_TEMP set TEMP_CCCOMMENTAIRES = str_replace(TEMP_CCCOMMENTAIRES,char(13)," ")
where TEMP_ID = @vgspid
and charindex(char(13),TEMP_CCCOMMENTAIRES) <> 0

update PREP_TEMP set TEMP_VATEST = 0
where TEMP_ID = @vgspid
and TEMP_VATEST is null

update PREP_TEMP set TEMP_VATEST2 = 0
where TEMP_ID = @vgspid
and TEMP_VATEST2 is null


/*************************************************************************************************************/
/*********** Boucle d allocation 1 ***************************************************************************/
/*** avec suppression des commandes non expediees avec taux de completion insuffisant et regles de franco ****/
/*************************************************************************************************************/


/****** Initialisation du stock a allouer ********/

insert into #Art (CCLARTICLE)
select TEMP_CCLARTICLE
from PREP_TEMP
where TEMP_ID = @vgspid
group by TEMP_CCLARTICLE


insert into #StockTemp (ArticleST,StockDepot,StockRes)
select STEMPAR,sum(STEMPQTE),0       
from FSTEMP,#Art
where STEMPAR = CCLARTICLE
and STEMPDEPOT = @Depot
group by STEMPAR

insert into #StockTemp (ArticleST,StockDepot,StockRes)
select RCCARTICLE, 0, sum(isnull(RCCQTERES,0))
from FRCC,#Art,FCL
where RCCARTICLE=CCLARTICLE
and RCCCL=CLCODE
and CLPAYEUR in (@OK,@CT,@MP,@CI)
and (@ent is null or (RCCENT=@ent and CLENT=@ent))
group by RCCARTICLE



insert into #Stock (ArticleST,StockDepot,StockRes)
select ArticleST,sum(StockDepot),sum(StockRes)
from #StockTemp
group by ArticleST

create unique index article on #Stock (ArticleST)



/****** declarations variables et curseurs ********/

declare @larticle        char(15),
        @oldarticle        char(15),
        @cccode            char(10),
        @varesdepot        int,
        @stockdepot        int,
        @vatest2        numeric(14,2),
        @vaqte            int,
        @vaqteares        int,
        @cclreste0        int,
        @cclqteres        int,
        @ccsatisfaite    tinyint,
        @qteAdd             int,
        @ValAdd             numeric(14,2),
        @franco            tinyint,
        @completion     numeric(12,2),
        @seq            int,
        @artype            tinyint,
        @datecre        smalldatetime,
        @cclqteprep        int

declare @lStockDispo    int                /* = stock du depot - total reserve sur ce depot */

declare Cde_DateCrea cursor
for 
    select TEMP_CCLCODE, TEMP_CCSATISFAITE, isnull(TEMP_CCFRANCO,0) + isnull(TEMP_CCFRANCOBE,0),TEMP_CCDATECRE
    from PREP_TEMP
    where TEMP_ID = @vgspid
    group by TEMP_CCLCODE, TEMP_CCSATISFAITE, TEMP_CCFRANCO, TEMP_CCFRANCOBE, TEMP_CCDATECRE
    order by TEMP_CCDATECRE,TEMP_CCLCODE    /* tri par date de commande et commandes */
for read only

declare Cde_DateCrea_ligne cursor
for 
    select    TEMP_CCLSEQ, TEMP_CCLARTICLE, isnull(TEMP_CCLRESTE,0), isnull(TEMP_CCLQTERES,0), ARTYPE, isnull(TEMP_CCLQTEPREP,0)
    from PREP_TEMP,FAR
    where TEMP_ID = @vgspid
        and TEMP_CCLCODE = @cccode
        and ARCODE = TEMP_CCLARTICLE
    order by TEMP_CCLNUM    
for read only


declare Cde_Client cursor
for
select TEMP_CCLCL, TEMP_CCLCODE, TEMP_CCLARTICLE, isnull(TEMP_VAQTE,0), isnull(TEMP_CCLQTERES,0), TEMP_Identity
from PREP_TEMP
where TEMP_CCLCODE = @cccode
for read only

declare @clientsup1        char(12),
        @cdesup1        char(10),
        @articlesup1    char(15),
        @vaqtesup1        int,
        @cclqteressup1    int,
        @identity1        numeric(14,0)


/****** boucle sur les commandes ********/
            
open Cde_DateCrea

fetch Cde_DateCrea into @cccode, @ccsatisfaite, @franco, @datecre

while (@@sqlstatus=0)
begin 

    /*********** boucle sur les lignes *************/

    open Cde_DateCrea_ligne
    
    fetch Cde_DateCrea_ligne into @seq, @larticle, @cclreste0, @cclqteres, @artype, @cclqteprep

    while (@@sqlstatus=0)
    begin 

    if @artype = 0
    begin
        select @lStockDispo = StockDepot - StockRes from #Stock where ArticleST = @larticle
    
    
        if @cclreste0 - @cclqteres + @cclqteprep <= @lStockDispo
            select @vaqte = @cclreste0
        else
            select @vaqte = @lStockDispo + @cclqteres - @cclqteprep
            
        If @vaqte>0
        begin
            update PREP_TEMP set 
                TEMP_VAQTE = @vaqte, TEMP_VAQTEARES = @vaqte, TEMP_VATEST = 1, TEMP_VATEST2 = 1  
            where TEMP_ID = @vgspid and TEMP_CCLSEQ = @seq
        
            update #Stock set 
                StockDepot = StockDepot - @vaqte,
                StockRes = StockRes - (case when @cclqteres > @cclqteprep then @cclqteres - @cclqteprep else 0 end)
            where ArticleST = @larticle
        end
        else
        begin
            update PREP_TEMP set 
                TEMP_VAQTE = 0, TEMP_VAQTEARES = 0, TEMP_VATEST = 0, TEMP_VATEST2 = 0  
            where TEMP_ID = @vgspid and TEMP_CCLSEQ = @seq
        end
    end
    else
    begin
            update PREP_TEMP set 
                TEMP_VAQTE = @cclreste0, TEMP_VAQTEARES = @cclreste0, TEMP_VATEST = 1, TEMP_VATEST2 = 1  
            where TEMP_ID = @vgspid and TEMP_CCLSEQ = @seq
    end
    
        fetch Cde_DateCrea_ligne into @seq, @larticle, @cclreste0, @cclqteres, @artype, @cclqteprep
    end
    
    close Cde_DateCrea_ligne


    /*********** Traitement fin de Commande *************/
        
    
    /* select taux de completion */
    select     @qteAdd = 0, @ValAdd = 0
    
    select     @qteAdd=isnull(sum(TEMP_VAQTE),0),
            	/*@ValAdd=round(isnull(sum(TEMP_VAQTE*TEMP_CCLTOTALHT/TEMP_CCLQTE),0),2) */
            	@ValAdd=round(isnull(sum(TEMP_CCLTOTALHT),0),2)
            
    from PREP_TEMP    
    where TEMP_CCLCODE=@cccode and TEMP_ID = @vgspid
    
    exec GetCompletionOutput @cccode,@qteAdd,@ValAdd,@completion output


    /* si commande non expediee, completion insuffisante et regles franco */        
    if @ccsatisfaite = 0 
            and (@completionmini is not null and @completion < @completionmini)
            and (@nonfranco = 0 or (@nonfranco = 1 and @franco > 0))
    begin
    
        open Cde_Client
        fetch Cde_Client into @clientsup1,@cdesup1,@articlesup1,@vaqtesup1,@cclqteressup1,@identity1
        
        while (@@sqlstatus=0)
        begin

            update #Stock
            set StockDepot = StockDepot + @vaqtesup1,
                StockRes = StockRes + @cclqteressup1
            from PREP_TEMP
            where TEMP_CCLCODE = @cccode
            and TEMP_CCLARTICLE = @articlesup1
            and ArticleST = @articlesup1
            and TEMP_ID = @vgspid
            and TEMP_Identity = @identity1
                        
            fetch Cde_Client into @clientsup1,@cdesup1,@articlesup1,@vaqtesup1,@cclqteressup1,@identity1
        end
        
        update PREP_TEMP set TEMP_cDELETE = 1
        where TEMP_CCLCODE = @cccode and TEMP_ID = @vgspid
        
        close Cde_Client
            
    end
    else
        update PREP_TEMP set TEMP_COMPLETION=@completion where TEMP_CCLCODE=@cccode and TEMP_ID = @vgspid

    fetch Cde_DateCrea into @cccode, @ccsatisfaite, @franco, @datecre
end

close Cde_DateCrea 
deallocate cursor Cde_DateCrea
deallocate cursor Cde_DateCrea_ligne


delete from PREP_TEMP where TEMP_ID = @vgspid and TEMP_cDELETE = 1


/***************************************************************************************************************/
/*** suppression des commandes partiellement expediees avec total a expedier < 100 euros et regles de franco ***/
/*** pour les clients sans commandes non expediees *************************************************************/
/***************************************************************************************************************/


declare Cde_CliPartExped cursor
for
    select TEMP_CCLCL, TEMP_CCNOM, round(isnull(sum(TEMP_VAQTE*TEMP_CCLTOTALHTORG/TEMP_CCLQTE),0),2)
    from PREP_TEMP prep
    where TEMP_ID = @vgspid
        and (@nonfranco = 0 or (@nonfranco = 1 and (TEMP_CCFRANCO = 1 or TEMP_CCFRANCOBE = 1)))
        and not exists (select * from PREP_TEMP where TEMP_CCLCL=prep.TEMP_CCLCL and TEMP_CCNOM=prep.TEMP_CCNOM and TEMP_CCSATISFAITE=0 and TEMP_ID = @vgspid)
    group by TEMP_CCLCL,TEMP_CCNOM
for read only


declare @cccl        char(12),
                @ccnom            varchar(35),
        @totalht    numeric(14,2)
        
declare Cdes_Client cursor
for
select TEMP_CCLCL, TEMP_CCNOM, TEMP_CCLCODE, TEMP_CCLARTICLE, TEMP_VAQTE, isnull(TEMP_CCLQTERES,0), TEMP_Identity
from PREP_TEMP
where TEMP_CCLCL = @cccl
for read only

declare @clientsup        char(12),
                @nomsup                            varchar(35),
        @cdesup            char(10),
        @articlesup        char(15),
        @vaqtesup        int,
        @cclqteressup    int
        

open Cde_CliPartExped

fetch Cde_CliPartExped into @cccl, @ccnom, @totalht

while (@@sqlstatus=0)
begin

    if @totalht < @encours
    begin
    
        open Cdes_Client
        fetch Cdes_Client into @clientsup,@nomsup,@cdesup,@articlesup,@vaqtesup,@cclqteressup,@identity
        
        while (@@sqlstatus=0)
        begin
            update #Stock
            set StockDepot = StockDepot + @vaqtesup,
                StockRes = StockRes + @cclqteressup
            from PREP_TEMP
            where TEMP_CCLCL = @clientsup
            and TEMP_CCNOM = @nomsup
            and TEMP_CCLARTICLE = @articlesup
            and ArticleST = @articlesup
            and TEMP_ID = @vgspid
            and TEMP_Identity = @identity
            
            fetch Cdes_Client into @clientsup,@nomsup,@cdesup,@articlesup,@vaqtesup,@cclqteressup,@identity
        end
            
        close Cdes_Client
        
        update PREP_TEMP set TEMP_cDELETE = 1
        where TEMP_CCLCL = @cccl and TEMP_CCNOM=@ccnom
        and TEMP_ID = @vgspid    
    end

    fetch Cde_CliPartExped into @cccl, @ccnom,@totalht

end

close Cde_CliPartExped
deallocate cursor Cde_CliPartExped
deallocate cursor Cdes_Client


delete from PREP_TEMP where TEMP_ID = @vgspid and TEMP_cDELETE = 1


/*********************************************************************/
/*********** Boucle d allocation 2 ***********************************/
/*** allocation des commandes partiellement expediees non allouees ***/
/*** pour les clients avec commandes non expediees *******************/
/*********************************************************************/


declare Cde_PartExped cursor
for
    select TEMP_CCLCODE
    from PREP_TEMP prep
    where exists (select * from PREP_TEMP where TEMP_CCLCL=prep.TEMP_CCLCL and TEMP_CCNOM=prep.TEMP_CCNOM and TEMP_CCSATISFAITE=0 and TEMP_ID = @vgspid)
    and TEMP_ID = @vgspid
    group by TEMP_CCLCODE
    having sum(TEMP_VAQTE) = 0                         /* < sum(TEMP_CCLRESTE) */
for read only

declare Cde_PartExped_ligne cursor
for
    select TEMP_CCLSEQ, TEMP_CCLARTICLE, TEMP_CCLRESTE, isnull(TEMP_CCLQTERES,0), ARTYPE, isnull(TEMP_CCLQTEPREP,0)
    from PREP_TEMP, FAR
    where TEMP_ID = @vgspid 
        and TEMP_CCLCODE = @cccode
        and TEMP_VAQTE = 0                                /* < TEMP_CCLRESTE */
        and ARCODE = TEMP_CCLARTICLE
for read only


declare @vaqte_suppl    int


/****** boucle sur les commandes ********/
            
open Cde_PartExped

fetch Cde_PartExped into @cccode

while (@@sqlstatus=0)
begin 

    /*********** boucle sur les lignes *************/

    open Cde_PartExped_ligne
    
    fetch Cde_PartExped_ligne into @seq, @larticle, @cclreste0, @cclqteres, @artype, @cclqteprep

    while (@@sqlstatus=0)
    begin 
    if @artype = 0
    begin
        select @lStockDispo = StockDepot - StockRes from #Stock where ArticleST = @larticle
    
    
        if @cclreste0 - @cclqteres + @cclqteprep <= @lStockDispo
            select @vaqte = @cclreste0
        else
            select @vaqte = @lStockDispo + @cclqteres - @cclqteprep

            
        If @vaqte>0
        begin
            update PREP_TEMP set 
                TEMP_VAQTE = @vaqte, TEMP_VAQTEARES = @vaqte, TEMP_VATEST = 1, TEMP_VATEST2 = 1  
            where TEMP_ID = @vgspid and TEMP_CCLSEQ = @seq
        
            update #Stock set 
                StockDepot = StockDepot - @vaqte,
                StockRes = StockRes - (case when @cclqteres > @cclqteprep then @cclqteres - @cclqteprep else 0 end)
            where ArticleST = @larticle
        end
        else
        begin
            update PREP_TEMP set 
                TEMP_VAQTE = 0, TEMP_VAQTEARES = 0, TEMP_VATEST = 0, TEMP_VATEST2 = 0  
            where TEMP_ID = @vgspid and TEMP_CCLSEQ = @seq
        end
    end
    else
    begin
            update PREP_TEMP set 
                TEMP_VAQTE = @cclreste0, TEMP_VAQTEARES = @cclreste0, TEMP_VATEST = 1, TEMP_VATEST2 = 1  
            where TEMP_ID = @vgspid and TEMP_CCLSEQ = @seq
    end

        fetch Cde_PartExped_ligne into @seq, @larticle, @cclreste0, @cclqteres, @artype, @cclqteprep
    end
    
    close Cde_PartExped_ligne
    

    /*********** Traitement fin de Commande *************/
        
    
    /* select taux de completion */
    select     @qteAdd = 0, @ValAdd = 0
    
    select     @qteAdd=isnull(sum(TEMP_VAQTE),0),
            @ValAdd=round(isnull(sum(TEMP_VAQTE*TEMP_CCLTOTALHT/TEMP_CCLQTE),0),2)
    from PREP_TEMP    
    where TEMP_CCLCODE=@cccode and TEMP_ID = @vgspid
    
    exec GetCompletionOutput @cccode,@qteAdd,@ValAdd,@completion output


    update PREP_TEMP set TEMP_COMPLETION=@completion where TEMP_CCLCODE=@cccode and TEMP_ID = @vgspid
    

    fetch Cde_PartExped into @cccode
end

close Cde_PartExped
deallocate cursor Cde_PartExped
deallocate cursor Cde_PartExped_ligne


/*    Le blocage a l expe est plus fort que les autres conditions    */
if @vgsite = 8
        update PREP_TEMP set TEMP_VATEST2 = 0 where TEMP_ID = @vgspid


/*    Traitement TEMP_VASTOCKDISPO                                            */
/* ************************************************************************ */

declare @cclarticle        char(15),
        @vastockdispo    int,
        @vastockdepot    int,
        @cdelete        tinyint,
        @arcomp            tinyint,
        @cclreste        int

declare @lComposables    int

declare Article cursor
for select    TEMP_CCLARTICLE, TEMP_VASTOCKDISPO, TEMP_VASTOCKDEPOT, TEMP_cDELETE,
            TEMP_ARCOMP, TEMP_CCLRESTE, TEMP_Identity
from PREP_TEMP
where TEMP_ID = @vgspid
and TEMP_ARCOMP = 2
for read only

open Article
fetch Article into @cclarticle, @vastockdispo, @vastockdepot, @cdelete, @arcomp, @cclreste, @identity

while (@@sqlstatus=0)
begin

    if @vprefprepcomp = 1
    begin
        select @lComposables = 0
        select @lComposables = min(convert(int,(isnull(sum(STEMPQTE),0)/ARCQTE)))
        from FSTEMP,FARC,FDP,FARE,FAR
        where ARCCODE = @cclarticle
        and AREAR=ARCODE and ARTYPE=0 and AREAR=ARCCOMP and AREDEPOT=DPCODE
        and AREAR*=STEMPAR and AREDEPOT*=STEMPDEPOT and AREEMP*=STEMPEMP
        and AREDEPOT = @Depot        /* avec depot    */
        group by AREAR,ARCQTE
    
        select @vastockdepot = @vastockdepot + @lComposables
        
        select @lComposables = 0
        select @lComposables = min(convert(int,(isnull(sum(STEMPQTE),0)/ARCQTE)))
        from FSTEMP,FARC,FDP,FARE,FAR
        where ARCCODE = @cclarticle
        and AREAR=ARCODE and ARTYPE=0 and AREAR=ARCCOMP and AREDEPOT=DPCODE
        and AREAR*=STEMPAR and AREDEPOT*=STEMPDEPOT and AREEMP*=STEMPEMP
        and DPLOC = 1            /* sans depot        */
        group by AREAR,ARCQTE
    
        select @vastockdispo = @vastockdispo + @lComposables
        
        update PREP_TEMP set TEMP_VASTOCKDISPO = @vastockdispo, TEMP_VASTOCKDEPOT = @vastockdepot
        where TEMP_Identity = @identity
    end
        
    select @cdelete = 1

    if     (@Livrables=1 and @vastockdepot < @cclreste) or (@EtatStock=1 and @vastockdepot = 0) or
        (@EtatStock=2 and @vastockdepot > 0) or (@EtatStock=3 and @vastockdepot >= @cclreste)
    begin        

        update PREP_TEMP set TEMP_cDELETE = @cdelete
        where TEMP_Identity = @identity
    end    
            
  fetch Article into @cclarticle, @vastockdispo, @vastockdepot, @cdelete, @arcomp, @cclreste, @identity
  
end

delete from PREP_TEMP
where TEMP_ID = @vgspid and TEMP_cDELETE = 1

update PREP_TEMP set TEMP_VATEST2 = 0
where TEMP_ID = @vgspid
and TEMP_CCBEBLOQUE=1


/*    Si Traitements Commandes Client                                            */
/* ************************************************************************ */

if @vaexpedition = 1
    update PREP_TEMP set TEMP_VATEST = 0, TEMP_VATEST2 = 0
    where TEMP_ID = @vgspid


end



go

