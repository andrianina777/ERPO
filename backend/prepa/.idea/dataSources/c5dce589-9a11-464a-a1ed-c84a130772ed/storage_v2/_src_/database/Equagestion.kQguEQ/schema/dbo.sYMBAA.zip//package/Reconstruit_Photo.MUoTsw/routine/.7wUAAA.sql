



create procedure Reconstruit_Photo	(@date_photo_avant	smalldatetime,
							 		 @code_photo_avant	char(16),
							 		 @datedeb			smalldatetime,
							 		 @datefin			smalldatetime
							 		)
with recompile
as
begin

set arithabort numeric_truncation off

declare @lettre 		char(4),
		@article		char(15),
		@date			smalldatetime,
		@fournis		char(12),
		@qte			int,
		@narm1			char(12),
		@narm2			char(12),
		@dep			char(4),
		@paht			numeric(14,2),
		@frais			numeric(14,2),
		@padev			numeric(14,2),
		@devise			char(3),
		@lot			int,
		@count			int,
		@cvlot			int


select @count = count(*) from FPS
where PSDATE = convert(datetime,@date_photo_avant)
and PSCODE = @code_photo_avant

if @count = 0
	return 1



create table #FPS						/* Table temporaire de photographies du stock */
(
PSAR		char(15)		not null,	/* Code article */
PSLETTRE	char(4)			not null,	/* Code stock */
PSQTE		int				not null,	/* Quantite */
PSSERIE1	varchar(12)			null,	/* NÃÂ° de serie 1 */
PSSERIE2	varchar(12)			null,	/* NÃÂ° de serie 2 */
PSDATEENT	datetime		not null,	/* Date d''entree en stock */
PSDEPOT		char(4)			not null,	/* Code du depot */
PSPAHT		numeric(14,2)	not null,	/* Prix d''achat hors taxes en monnaie de reference */
PSFRAIS		numeric(14,2)	not null,	/* Frais en monnaie de reference */
PSPADEV		numeric(14,2)	not null,	/* Prix d''achat hors taxes en devises */
PSDEV		char(3)			not null,	/* Code de la devise */
PSDATE		datetime		not null,	/* Date pour recherche de la photographie du stock */
PSDATEIN	datetime		not null,	/* Date et heure de la photographie du stock */
PSUSERID	int				not null,	/* Code de l''utilisateur qui a fait la photo */
PSFO		char(12)			null,	/* Code du Fournisseur */
PSCODE		char(16)			null,	/* Code associe a la date photo pour identification */
ORIGINE		char(10)			null	/* Origine de la ligne */
)


insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
select PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,@datefin,getdate(),user_id(),PSFO,"RECONSTIT","PHOTO"
from FPS
where PSDATE=convert(datetime,@date_photo_avant)
and PSCODE=@code_photo_avant


/*------------------------ Mouvements sur FBLL -----------------------*/ 
 	
	declare pointeur cursor
	for select BLLLET,BLLAR,BLLDATE,BLLFO,BLLQTE,
			   BLLNARM1,BLLNARM2,BLLDEP,BLLPAHT,BLLFRAIS,
			   BLLPADEV,BLLDEV
	from FBLL,FAR
	where ARCODE = BLLAR and ARTYPE = 0
	and BLLQTE != 0
	and BLLDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE+@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock  */
					
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,@qte,@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","BLL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur


/*------------------------ Mouvements sur FSIL -----------------------*/ 
 	
	declare pointeur cursor
	for select SILLETTRE,SILARTICLE,SILDATE,SILFO,SILQTE,
			   SILNUMARM1,SILNUMARM2,SILDEPOT,SILPAHT,SILFRAIS,
			   SILPADEV,SILDEVISE
	from FSIL,FAR
	where ARCODE = SILARTICLE and ARTYPE = 0
	and SILQTE != 0
	and SILDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE+@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock  */
					
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,@qte,@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","SIL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur

/*------------------------ Mouvements sur FDOL -----------------------*/ 
 	
	declare pointeur cursor
	for select DOLLET,DOLAR,DOLDATE,DOLFO,DOLQTE,
			   DOLNARM1,DOLNARM2,DOLDEP,DOLPRHT-DOLFRAIS,DOLFRAIS,
			   DOLPADEV,DOLDEV
	from FDOL,FAR
	where ARCODE = DOLAR and ARTYPE = 0
	and DOLQTE != 0
	and DOLDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE+@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock  */
					
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,@qte,@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","DOL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur


/*------------------------ Mouvements sur FRFL -----------------------*/ 
 	
	declare pointeur cursor
	for select RFLLETTRE,RFLARTICLE,RFLDATE,STFO,RFLQTE,
			   STNUMARM1,STNUMARM2,STDEPOT,STPAHT,STFRAIS,
			   STPADEV,STDEVISE
	from FRFL,FAR, FSTOCK
	where ARCODE = RFLARTICLE and ARTYPE = 0
	and STAR = RFLARTICLE and STLETTRE = RFLLETTRE
	and RFLQTE != 0
	and RFLDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE-@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock - en principe inutile */
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,-(@qte),@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","RFL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur

/*------------------------ Mouvements sur FRJL -----------------------*/ 
 	
	declare pointeur cursor
	for select RJLLETTRE,RJLARTICLE,RJLDATE,STFO,RJLQTE,
			   STNUMARM1,STNUMARM2,STDEPOT,STPAHT,STFRAIS,
			   STPADEV,STDEVISE
	from FRJL,FAR,FSTOCK
	where ARCODE = RJLARTICLE and ARTYPE = 0
	and STAR = RJLARTICLE and STLETTRE = RJLLETTRE
	and RJLQTE != 0
	and RJLDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE+@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock - en principe inutile  */
					
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,@qte,@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","RJL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur

/*------------------------ Mouvements sur FLCL -----------------------*/ 
 	
	declare pointeur cursor
	for select LCLLETTRE,LCLARTICLE,LCLDATE,LCLFO,LCLQTE,
			   LCLNUMARM1,LCLNUMARM2,LCLDEPOT,LCLPAHT,LCLFRAIS,
			   LCLPADEV,LCLDEVISE
	from FLCL,FAR
	where ARCODE = LCLARTICLE and ARTYPE = 0
	and LCLQTE != 0
	and LCLDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE+@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock - en principe inutile */
					
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,@qte,@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","LCL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur

/*------------------------ Mouvements sur FASL -----------------------*/
 	
	declare pointeur cursor
	for select ASLLETTRE,ASLARTICLE,ASLDATE,ASLFO,ASLQTE,
			   ASLNUMARM1,ASLNUMARM2,ASLDEPOT,ASLPAHT,ASLFRAIS,
			   ASLPADEV,ASLDEVISE,CVLOT
	from FASL,FAR,FCV
	where ARCODE = ASLARTICLE and ARTYPE = 0
	and ARUNITACHAT = CVUNIF
	and ASLQTE != 0
	and ASLDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise,@cvlot
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE+@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock */
										
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,@qte,@narm1,@narm2,@date,@dep,@paht*@cvlot,
						@frais*@cvlot,@padev*@cvlot,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","ASL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise,@cvlot
			
		end		

	close pointeur
	deallocate cursor pointeur

/*------------------------ Mouvements sur FBEL -----------------------*/ 
 	
	declare pointeur cursor
	for select BELLETTRE,BELARTICLE,BELDATE,STFO,BELQTE,
			   STNUMARM1,STNUMARM2,STDEPOT,STPAHT,STFRAIS,
			   STPADEV,STDEVISE
	from FBEL,FAR,FSTOCK
	where ARCODE = BELARTICLE and ARTYPE = 0
	and STAR = BELARTICLE and STLETTRE = BELLETTRE
	and BELQTE != 0
	and BELDATE between @datedeb and @datefin
	for read only
	
	open pointeur
	
	fetch pointeur
	into @lettre,@article,@date,@fournis,@qte,
		 @narm1,@narm2,@dep,@paht,@frais,
		 @padev,@devise
	
	while (@@sqlstatus = 0)
		begin
			select @count = 0
		
			select @count = count(*)
			from #FPS
			where  PSAR=@article 
			and PSLETTRE=@lettre
				 
			if @count>0
				begin
							/* Maj des lignes de stock existantes */
							
					update #FPS 
					set PSQTE=PSQTE-@qte
					where PSLETTRE=@lettre
					and PSAR=@article
					
				end
			else
				begin
							/* Creation des lignes de stock - en principe inutile  */
					
					
					insert into #FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,ORIGINE)
					values (@article,@lettre,-(@qte),@narm1,@narm2,@date,@dep,@paht,
						@frais,@padev,@devise,@datefin,getdate(),user_id(),@fournis,"RECONSTIT","BEL")
				end
			
			
			fetch pointeur
			into @lettre,@article,@date,@fournis,@qte,
				 @narm1,@narm2,@dep,@paht,@frais,
				 @padev,@devise
			
		end		

	close pointeur
	deallocate cursor pointeur
	
/*-------------- select final ----------------*/

select PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,
					PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,
					Valorisation_FIFO=(PSPAHT+PSFRAIS)/CVLOT*PSQTE,ORIGINE
from #FPS,FAR,FCV
where ARCODE=PSAR
and ARUNITACHAT=CVUNIF
and PSQTE <> 0
order by PSAR,PSLETTRE

drop table #FPS

return 0
	
end



go

