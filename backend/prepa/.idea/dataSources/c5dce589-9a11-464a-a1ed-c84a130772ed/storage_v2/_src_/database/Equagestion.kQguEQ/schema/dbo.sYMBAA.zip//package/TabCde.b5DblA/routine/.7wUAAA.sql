


create procedure TabCde (@ent	char(5) = null,
						 @fourn	char(12),
						 @an	smallint)
with recompile
as
begin

	create table #liste
	(
		codeart 	char(15) not null,
		janvier 	int 		null,
		fevrier 	int 		null,
		mars 		int 		null,
		avril 		int 		null,
		mai 		int 		null,
		juin 		int 		null,
		juillet 	int 		null,
		aout 		int 		null,
		septembre 	int 		null,
		octobre 	int 		null,
		novembre 	int 		null,
		decembre 	int 		null,
		total		int			null
	)	

	create index article on #liste(codeart)
	
	create table #Cde
	(
	Article 	char(15) not null,
	Qte			int			null,
	Date		datetime	null,
	DateCde		datetime	null
	)
	
	/* Commandes */
	
	insert into #Cde
	select CFLARTICLE,CFLQTE,CFLDATEP,CFLDATE
	from FCFL,FRCF
	where CFLSEQ=RCFSEQ
	and RCFFO=@fourn
	and datepart(yy,RCFDATE)=@an
	and (@ent is null or (RCFENT=@ent and CFLENT=RCFENT))
	
	update #Cde
	set Date=DateCde
	where Date is null
	
	insert into #liste (codeart)
	select distinct Article
	from #Cde
	
	
		update #liste
		set janvier= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=1
					 group by Article)
					 
		update #liste
		set fevrier= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=2
					 group by Article)
		
		update #liste
		set mars= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=3
					 group by Article)
					 
		update #liste
		set avril= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=4
					 group by Article)
					 
		update #liste
		set mai= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=5
					 group by Article)
					 
		update #liste
		set juin= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=6
					 group by Article)
					 
		update #liste
		set juillet= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=7
					 group by Article)
					 
		update #liste
		set aout= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=8
					 group by Article)
					 
		update #liste
		set septembre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=9
					 group by Article)
					 
		update #liste
		set octobre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=10
					 group by Article)
					 
		update #liste
		set novembre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=11
					 group by Article)
					 
		update #liste
		set decembre= (select sum(Qte)
					 from #Cde
					 where #Cde.Article=#liste.codeart
					 and datepart(mm,#Cde.Date)=12
					 group by Article)
					 
		drop table #Cde


		update #liste
		set total=isnull(janvier,0)+isnull(fevrier,0)+isnull(mars,0)
		+isnull(avril,0)+isnull(mai,0)+isnull(juin,0)
		+isnull(juillet,0)+isnull(aout,0)+isnull(septembre,0)
		+isnull(octobre,0)+isnull(novembre,0)+isnull(decembre,0)

			select 'Commandes '+convert(char(4),@an), @fourn
			
			select 'REF','DESIGNATION',
			'JANV','FEVR','MARS',
			'AVRIL','MAI','JUIN',
			'JUIL','AOUT','SEPT',
			'OCTO','NOV','DEC','TOTAL'

			select codeart,ARLIB,
			janvier,fevrier,mars,avril,mai,juin,
			juillet,aout,septembre,octobre,novembre,decembre,total
			from #liste,FAR
			where ARCODE=codeart
			order by codeart
			compute sum(janvier),sum(fevrier),sum(mars),
					sum(avril),sum(mai),sum(juin),
					sum(juillet),sum(aout),sum(septembre),
					sum(octobre),sum(novembre),sum(decembre),
					sum(total)
					
		drop table #liste
	
end	



go

