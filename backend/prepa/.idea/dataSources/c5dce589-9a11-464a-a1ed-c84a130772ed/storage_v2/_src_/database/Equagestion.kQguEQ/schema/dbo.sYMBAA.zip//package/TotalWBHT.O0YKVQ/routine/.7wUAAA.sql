


create procedure TotalWBHT(	@ent	char(5) = null,
							@code 	char(10))
as
begin

	set arithabort numeric_truncation off


	declare @Total numeric(14,2),
			@TotalDev numeric(14,2)
			
	select @Total=sum(WBLTOTALHT), @TotalDev=round(sum(WBLTOTALHT)*WBCOURSDEV,2)
	from FWBL,FWB
	where WBLCODE=@code
	and WBLCODE=WBCODE
	and WBLQTE!=0
	and (@ent is null or WBLENT=@ent)
	
	
	update FWB
	set WBTOTALHT=@Total,WBTOTALHTDEV=@TotalDev
	where WBCODE=@code and (@ent is null or WBENT=@ent)
	
	
end



go

