


/* Procedure utilisee par le module ""Preparation des factures"" 	*/
/* Modifee le 040204 --> ajout des lignes atelier		*/

create procedure AFacturerBE(	@ent	char(5) = null,
								@NumBE 			char(10),
								@stade			tinyint	 = 5,
								@offerts		tinyint	 = 0,
								@dotations		tinyint	 = 0
							)
with recompile
as
begin

if substring(@NumBE,1,2)="WB"  /* Atelier */
begin
	select 	LigneBE=WBLNUM,Article=WBLARTICLE,Libelle=WBLARDES,Commentaire=WBLOBS,Qte=WBLQTE,
		Montant=WBLTOTALHT,Lien_Code=WBLFICHE,Lien_Num=WBLNUM
	from FWBL,FAR,FRWB
	where RWBSEQ=WBLSEQ
	and ARCODE=WBLARTICLE
	and WBLCODE=@NumBE
	and (@ent is null or (WBLENT=@ent and RWBENT=@ent))
	order by WBLNUM
end
else if substring(@NumBE,1,2)="BE"
begin
	select 	LigneBE=BELNUM,Article=BELARTICLE,Libelle=ARLIB,Commentaire=BELLIBRE,Qte=BELQTE,
		Montant=BELTOTALHT,Lien_Code=BELLIENCODE,Lien_Num=BELLIENNUM
	from FBEL,FAR,FRBE
	where RBESEQ=BELSEQ
	and ARCODE=BELARTICLE
	and BELDEMO=0
	and BELCODE=@NumBE
	and (@stade = 5 or (@stade = 4 and RBESTADE >= 2) or (@stade < 4 and RBESTADE = @stade))
	and (@offerts = 1 or isnull(BELOFFERT,0) = 0)
	and (@dotations = 1 or isnull(BELDOTATION,0) = 0)
	and (@ent is null or (BELENT=@ent and RBEENT=@ent))
	order by BELNUM
end

end



go

