/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_Liste_Voitrure

*/

CREATE PROCEDURE bp_Liste_Voitrure
with recompile
AS
begin

	 declare @count int
	 
 	 select @count=count(*) from EquaPRO..KGroupes_Membres where upper(KGMGPEID) in (upper('OPH_ASTDIR')) and KGMUSRID=suser_name()
 	 if(@count>0)
 	 begin
 	  select rtrim(xCHAUFF)+'--'+rtrim(xNUM_VOIT),xNUM_VOIT,xCHAUFF from xVOIT_CH left join xVOITURE on xNUM=xNUM_VOIT where xDISPO =0 and xCode<>'11111' and isnull(xType_Service,'')='ADMIN'
 	 end
 	 else
 	 begin
 	 	select rtrim(xCHAUFF)+'--'+rtrim(xNUM_VOIT),xNUM_VOIT,xCHAUFF from xVOIT_CH left join xVOITURE on xNUM=xNUM_VOIT where xDISPO =0 and xCode<>'11111'
 	 end
 	 
 		  
end
go

