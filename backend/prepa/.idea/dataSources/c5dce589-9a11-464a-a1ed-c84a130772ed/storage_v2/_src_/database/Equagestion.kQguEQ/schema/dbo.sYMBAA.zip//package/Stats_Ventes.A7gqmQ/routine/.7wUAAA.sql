


create procedure Stats_Ventes ( @ent		char(5)	= null,
								@date1		smalldatetime,
					 			@date2		smalldatetime,
					 			@cli		char(12) = '%',
					 			@arti		char(15) = '%'
							  )

with recompile
as
begin

set arithabort numeric_truncation off


create table #finale
(
CLCODE			char(12)		null,
CLNOM1			varchar(35)		null,
CLREP			char(8)			null,
CLSA			char(6)			null,
CLPY			char(8)			null,
CLTARIF			char(8)			null,
ARCODE			char(15)		null,
ARREFFOUR		char(20)		null,
ARFO			char(12)		null,
ARLIB			varchar(80)		null,
CPFALQTE		int				null,
CPFALTOTALHT	numeric(14,2)	null,
CPPRM			numeric(14,2)	null,
CPMARGE			numeric(14,2)	null,
PPFALQTE		int				null,
PPFALTOTALHT	numeric(14,2)	null,
PPPRM			numeric(14,2)	null,
PPMARGE			numeric(14,2)	null,
CYFALQTE		int				null,
CYFALTOTALHT	numeric(14,2)	null,
CYPRM			numeric(14,2)	null,
CYMARGE			numeric(14,2)	null,
PYFALQTE		int				null,
PYFALTOTALHT	numeric(14,2)	null,
PYPRM			numeric(14,2)	null,
PYMARGE			numeric(14,2)	null
)

create table #client
(
CLCODE		char(12)		null,
CLNOM1		varchar(35)		null,
CLREP		char(8)			null,
CLSA		char(6)			null,
CLPY		char(8)			null,
CLTARIF		char(8)			null
)

create table #article
(
ARCODE		char(15)			null,
ARREFFOUR	char(20)		null,
ARFO		char(12)			null,
ARLIB		varchar(80)		null
)

create table #valeurs
(
FALCL		char(12)	null,
FALARTICLE	char(15)	null,
FALQTE		int			null,
FALTOTALHT	numeric(14,2)	null,
PRM			numeric(14,2)	null,
TOTALPRM	numeric(14,2)	null,
MARGE		numeric(14,2)	null
)

declare	@cl		char(12),
		@art	char(15)
		
select @cli = isnull(@cli,'%')
select @arti = isnull(@arti,'%')

declare ligne cursor
for
select FALCL,FALARTICLE
from FFAL
where FALCL like @cli
and FALARTICLE like @arti
and		(((datepart(yy,FALDATE) = datepart(yy,@date1))
		and 	
		(FALDATE <= @date2)) 
	or
		((datepart(yy,FALDATE) = datepart(yy,dateadd(yy,-1,@date1)))
		and 	
		(FALDATE <= dateadd(yy,-1,@date2))))
and (@ent is null or FALENT=@ent)
group by FALCL,FALARTICLE
for read only

open ligne
fetch ligne into @cl,@art

while (@@sqlstatus = 0)
begin

	insert into #client(CLCODE,CLNOM1,CLREP,CLSA,CLPY,CLTARIF)
	select CLCODE,CLNOM1,CLREP,CLSA,CLPY,CLTARIF
	from FCL
	where CLCODE = @cl
	and (@ent is null or CLENT=@ent)

	insert into #article(ARCODE,ARREFFOUR,ARFO,ARLIB)
	select ARCODE,ARREFFOUR,ARFO,ARLIB
	from FAR
	where ARCODE = @art

	insert into #valeurs(FALCL,FALARTICLE,FALQTE,FALTOTALHT)
	select 	FALCL,FALARTICLE,
			sum(isnull(FALQTE,0)),
			sum(isnull(FALTOTALHT,0))
	from FFAL,FAR
	where ARCODE = FALARTICLE
	and FALCL = @cl
	and FALARTICLE = @art
	and FALDATE >= @date1
	and FALDATE <= @date2
	and (@ent is null or FALENT=@ent)
	group by FALCL,FALARTICLE

	update #valeurs
	set TOTALPRM = (FALQTE * PRM)

	update #valeurs
	set MARGE = (FALTOTALHT - TOTALPRM)

	if ((select count(*) from #valeurs) = 0)
	begin
		insert into #valeurs(FALQTE,FALTOTALHT,PRM,TOTALPRM,MARGE)
		select 0,0,0,0,0
	end

	insert into #finale(CLCODE,CLNOM1,CLREP,CLSA,CLPY,CLTARIF,ARCODE,
		ARREFFOUR,ARFO,ARLIB,CPFALQTE,CPFALTOTALHT,CPPRM,CPMARGE)
	select CLCODE,CLNOM1,CLREP,CLSA,CLPY,CLTARIF,
		ARCODE,ARREFFOUR,ARFO,ARLIB,
		FALQTE,FALTOTALHT,TOTALPRM,MARGE
	from #client,#article,#valeurs

	delete from #valeurs

	insert into #valeurs(FALQTE,FALTOTALHT,PRM)
	select 	sum(isnull(FALQTE,0)),
			sum(isnull(FALTOTALHT,0)),
			ARPRM
	from FFAL,FAR
	where ARCODE = FALARTICLE
	and FALCL = @cl
	and FALARTICLE = @art
	and FALDATE >= dateadd(yy,-1,@date1)
	and FALDATE <= dateadd(yy,-1,@date2)
	and (@ent is null or FALENT=@ent)
	group by FALCL,FALARTICLE,ARPRM

	update #valeurs
	set TOTALPRM = (FALQTE * PRM)

	update #valeurs
	set MARGE = (FALTOTALHT - TOTALPRM)

	if ((select count(*) from #valeurs) = 0)
	begin
		insert into #valeurs(FALQTE,FALTOTALHT,PRM,TOTALPRM,MARGE)
		select 0,0,0,0,0
	end

	update #finale
	set 	PPFALQTE = (select FALQTE from #valeurs),
		PPFALTOTALHT = (select FALTOTALHT from #valeurs), 
		PPPRM	= (select TOTALPRM from #valeurs), 
		PPMARGE = (select MARGE from #valeurs) 
	where CLCODE = @cl and ARCODE = @art

	delete from #valeurs

	insert into #valeurs(FALQTE,FALTOTALHT,PRM)
	select 	sum(isnull(FALQTE,0)),
			sum(isnull(FALTOTALHT,0)),
			ARPRM
	from FFAL,FAR
	where ARCODE = FALARTICLE
	and FALCL = @cl
	and FALARTICLE = @art
	and datepart(yy,FALDATE) = datepart(yy,@date1)
	and FALDATE <= @date2
	and (@ent is null or FALENT=@ent)
	group by FALCL,FALARTICLE,ARPRM

	update #valeurs
	set TOTALPRM = (FALQTE * PRM)

	update #valeurs
	set MARGE = (FALTOTALHT - TOTALPRM)

	if ((select count(*) from #valeurs) = 0)
	begin
		insert into #valeurs(FALQTE,FALTOTALHT,PRM,TOTALPRM,MARGE)
		select 0,0,0,0,0
	end

	update #finale
	set 	CYFALQTE = (select FALQTE from #valeurs),
		CYFALTOTALHT = (select FALTOTALHT from #valeurs), 
		CYPRM	= (select TOTALPRM from #valeurs), 
		CYMARGE = (select MARGE from #valeurs) 
	where CLCODE = @cl and ARCODE = @art

	delete from #valeurs

	insert into #valeurs(FALQTE,FALTOTALHT,PRM)
	select 	sum(isnull(FALQTE,0)),
			sum(isnull(FALTOTALHT,0)),
			ARPRM
	from FFAL,FAR
	where ARCODE = FALARTICLE
	and FALCL = @cl
	and FALARTICLE = @art
	and datepart(yy,FALDATE) = datepart(yy,dateadd(yy,-1,@date1))
	and FALDATE <= dateadd(yy,-1,@date2)
	and (@ent is null or FALENT=@ent)
	group by FALCL,FALARTICLE,ARPRM

	update #valeurs
	set TOTALPRM = (FALQTE * PRM)

	update #valeurs
	set MARGE = (FALTOTALHT - TOTALPRM)

	if ((select count(*) from #valeurs) = 0)
	begin
		insert into #valeurs(FALQTE,FALTOTALHT,PRM,TOTALPRM,MARGE)
		select 0,0,0,0,0
	end

	update #finale
	set 	PYFALQTE = (select FALQTE from #valeurs),
		PYFALTOTALHT = (select FALTOTALHT from #valeurs), 
		PYPRM	= (select TOTALPRM from #valeurs), 
		PYMARGE = (select MARGE from #valeurs) 
	where CLCODE = @cl and ARCODE = @art

	delete from #valeurs
	delete from #article
	delete from #client

	fetch ligne into @cl,@art
end

close ligne
deallocate cursor ligne

select 
CLCODE as 'Code',
CLNOM1 as 'Client',
CLREP	as 'Repres',
CLSA as 'Activite',
CLPY as 'Pays',
CLTARIF as 'Tarif',
ARCODE as 'Article',
ARREFFOUR as 'SKU',
ARFO	as 'Marque',
ARLIB	as 'Designation',
CPFALQTE as 'CP-Qte',
CPFALTOTALHT as 'CP-Vente',
CPPRM	as 'CP-Cout',
CPMARGE as 'CP-Marge',
PPFALQTE as 'PP-Qte',
PPFALTOTALHT as 'PP-Vente',
PPPRM	as 'PP-Cout',
PPMARGE as 'PP-Marge',
CYFALQTE as 'CY-Qte',
CYFALTOTALHT as 'CY-Vente',
CYPRM	as 'CY-Cout',
CYMARGE as 'CY-Marge',
PYFALQTE as 'PY-Qte',
PYFALTOTALHT as 'PY-Vente',
PYPRM	as 'PY-Cout',
PYMARGE as 'PY-Marge'
from #finale 
order by CLCODE,ARCODE

drop table #valeurs
drop table #article
drop table #client
drop table #finale

end




go

