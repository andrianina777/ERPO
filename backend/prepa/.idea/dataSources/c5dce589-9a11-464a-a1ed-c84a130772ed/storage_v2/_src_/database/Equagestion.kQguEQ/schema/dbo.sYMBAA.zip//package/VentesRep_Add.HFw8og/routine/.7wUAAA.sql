


create procedure VentesRep_Add (@ent	char(5)	= null)
with recompile
as
begin

set arithabort numeric_truncation off


declare @date1		datetime
declare @date2		datetime
declare @an			smallint
declare @date		datetime

select @an=datepart(yy,getdate())


create table #temp
(
Client			char(12)		not null,
Qte_Annee1		int					null,
Qte_AnneeP		int					null,
Qte_Annee		int					null,
Qte_Cde			int					null,
CA_Annee1		numeric(14,2)		null,
CA_AnneeP		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null,
CA_Cde			numeric(14,2)		null
)

create table #Final
(
Client			char(12)			not null,
Qte_Annee1		int					null,
Qte_AnneeP		int					null,
Qte_Annee		int					null,
Qte_Cde			int					null,
CA_Annee1		numeric(14,2)		null,
CA_AnneeP		numeric(14,2)		null,
CA_Annee		numeric(14,2)		null,
CA_Cde			numeric(14,2)		null
)

create table #Far
(
Article		char(15)		not null
)

create table #Far2
(
Article		char(15)			null
)

/* Recuperation des articles souhaites */

insert into #Far
select ARCODE from FAR


insert into #Far2
select Article from #Far


/* Quantites et CA pour An-1 */


insert into #temp (Client,Qte_Annee1,CA_Annee1)
select STCL,sum(STQTEFA),sum(STCAFA)
from FST,#Far
where Article=START
and STAN=@an-1
and (@ent is null or STENT=@ent)
group by STCL


/* Quantites et CA pour An-1 du 1er Janvier a la date du jour */

select @date1=convert(datetime,'01/01/'+convert(varchar(4),@an-1))
select @date2=convert(datetime,convert(varchar(2),datepart(mm,getdate()))+"/"+
			convert(varchar(2),datepart(dd,getdate()))+"/"+convert(varchar(4),@an-1))


insert into #temp (Client,Qte_AnneeP,CA_AnneeP)
select FALCL,
	   isnull(sum(case	when (isnull(FALLETTRE,'') != '') then FALQTE else 0 end),0),
	   sum(FALTOTALHT)
from FFAL (index artdate),#Far2
where Article=FALARTICLE
and FALDATE between @date1 and @date2
and (@ent is null or FALENT=@ent)
group by FALCL

drop table #Far2

/* Quantites et CA pour Annee en cours */


insert into #temp (Client,Qte_Annee,CA_Annee)
select STCL,sum(STQTEFA),sum(STCAFA)
from FST,#Far
where Article=START
and STAN=@an
and (@ent is null or STENT=@ent)
group by STCL


/* Quantites et CA en commande client */

insert into #temp (Client,Qte_Cde,CA_Cde)
select RCCCL,sum(RCCQTE),sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE)
from FRCC,FCCL,#Far,FCC
where Article=RCCARTICLE
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and (@ent is null or (RCCENT=@ent and CCLENT=RCCENT and CCENT=RCCENT))		/* and isnull(CCVALIDE,0)=0 */
group by RCCCL

drop table #Far


insert into #Final(Client,Qte_Annee1,Qte_AnneeP,Qte_Annee,Qte_Cde,CA_Annee1,CA_AnneeP,CA_Annee,CA_Cde)
select Client,sum(Qte_Annee1),sum(Qte_AnneeP),sum(Qte_Annee),sum(Qte_Cde),sum(CA_Annee1),
			sum(CA_AnneeP),sum(CA_Annee),sum(CA_Cde)
from #temp
group by Client

drop table #temp

create unique clustered index client on #Final (Client)

select @date = getdate()

insert into FVENTES (VENREP,VENCP2,VENVILLE,VENCL,VENADR1,VENADR2,VENCP,VENTEL,
					VENFAX,VENCOMPTABLE,VENNOM,VENQTE_1,VENQTE_P,VENQTE,VENQTECC,
					VENCA_1,VENCA_P,VENCA,VENCACC,VENDATE,VENENT)	
select 	Rep=isnull(CLREP,"        "),
		Dep=isnull(substring(CLCP,1,2),"  "),
		Ville=isnull(CLVILLE,"        "),
		Client=isnull(Client,"        "),
		Adr1=isnull(CLADR1,"        "),
		Adr2=isnull(CLADR2,"        "),
		CP=isnull(CLCP,"        "),
		Tel=isnull(CLTEL1,"        "),
		Fax=isnull(CLTELECOP1,"        "),
		Numcomptable=isnull(CLNUMCOMPTABLE,"        "),
		Nom=isnull(CLNOM1,"        "),
		Qte_1=isnull(Qte_Annee1,0),
		Qte_P=isnull(Qte_AnneeP,0),
		Qte=isnull(Qte_Annee,0),
		Qte_Cde=isnull(Qte_Cde,0),
		CA_1=convert(int,isnull(CA_Annee1,0)),
		CA_P=convert(int,isnull(CA_AnneeP,0)),
		CA=convert(int,isnull(CA_Annee,0)),
		CA_Cde=convert(int,isnull(CA_Cde,0)),
		@date,isnull(@ent,"")
from #Final,FCL
where CLCODE=Client
order by CLREP,substring(CLCP,1,2),CLVILLE,Client


drop table #Final

end



go

