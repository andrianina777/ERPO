


/* Procedure donnant la marge par famille entre 2 dates */

create procedure MargesFam (@ent		char(5)	= null,
							@FromDate	datetime,
							@ToDate		datetime,
							@depart		char(8) = null,
							@Fam1		char(8) = null,
							@Fam2		char(8) = null)
with recompile
as
begin

set arithabort numeric_truncation off


if (@Fam2 is null)
select @Fam2 = @Fam1


create table #Far
(
ARDEPART		char(8)			null,
ARFAM			char(6)			null,
ARFO			char(8)			null,
ARCODE			char(8)			null,
CVLOT			int				null
)

create table #Fal
(
Depart	char(8)			null,
Fam		char(6)			null,
Four	char(8)			null,
Total	numeric(14,2)	null,
PR		numeric(14,2)	null
)



if (@Fam1 is null)
	begin
		insert into #Far (ARDEPART,ARFAM,ARFO,ARCODE,CVLOT)
		select ARDEPART,ARFAM,ARFO,ARCODE,CVLOT
		from FAR,FCV
		where ARUNITACHAT=CVUNIF
		and (@depart is null or ARDEPART=@depart)
	end
else
	begin
		insert into #Far (ARDEPART,ARFAM,ARFO,ARCODE,CVLOT)
		select ARDEPART,ARFAM,ARFO,ARCODE,CVLOT
		from FAR,FCV
		where ARFAM between @Fam1 and @Fam2
		and ARUNITACHAT=CVUNIF
		and (@depart is null or ARDEPART=@depart)
	end

create unique clustered index article on #Far(ARCODE)


insert into #Fal (Depart,Fam,Four,Total,PR)
select 	ARDEPART,ARFAM,ARFO,sum(FALTOTALHT),round(sum(((isnull(STPAHT,0)+isnull(STFRAIS,0))/CVLOT)*FALQTE),2)
from FFAL,#Far,FSTOCK,FDP
where ARCODE=FALARTICLE
and FALDATE between @FromDate and @ToDate
and STAR=FALARTICLE
and STLETTRE=FALLETTRE
and DPCODE=STDEPOT and (@ent is null or (FALENT=@ent and DPENT=@ent and DPCENTRAL=0))
group by ARDEPART,ARFAM,ARFO

drop table #Far

/* select final */


select Departement=Depart, Famille=Fam, Fournisseur=Four, CA_HT=Total, PAHT=PR,
		Marge_Valeur = Total-PR,
		Marge = round(((Total-PR)*abs(sign(Total)))/(Total+(1-abs(sign(Total)))),2)*100
from #Fal
order by Depart,Fam,Four
compute sum(Total),sum(PR),sum(Total-PR) by Depart,Fam
compute sum(Total),sum(PR),sum(Total-PR) by Depart
compute sum(Total),sum(PR),sum(Total-PR)

drop table #Fal

end



go

