/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_MailAuto_ClCa_bas20
grant execute on bp_MailAuto_ClCa_bas20 to public
*/

CREATE PROCEDURE dbo.bp_MailAuto_ClCa_bas20(@com int)

AS
begin

		/*1	MANO    
		2	IAINA   
		3	DIDIER  
		4	HAINGO  
		5	RICHARD 
		6	TIAHARY*/
		 
		declare @date_40 date,@date_30 date,@datej date,@commercial char(8)
		
		select @date_40=convert(date,DATEADD(day,-40,CURRENT_DATE()))
		select @date_30=convert(date,DATEADD(day,-30,CURRENT_DATE()))
		
		select @datej= convert(date,CURRENT_DATE())
		
		select @commercial=xNom from xCOM where xSeq=@com
		
		select CLIENT,NOM_FICHE,VILLE,CLSA as TYPE,TEL1||'    '||TEL2 as TEL,COM,TOTALHT,convert(date,DATE) as DATE 
		into #FFAL_TOUS 
		from VIEW_LIGNE_FACT where COM=@commercial 
		AND FACOMPTA<2 and convert(date,DATE) BETWEEN @date_40 AND @datej 

		 select CLIENT as CLIENT_30,convert(numeric(14,0),AVG(TOTALHT)) as CA_30 into #FFAL_CA_30 from #FFAL_TOUS where DATE<=@date_30 group by CLIENT
		
		 select CLIENT as CLIENT_10,convert(numeric(14,0),AVG(TOTALHT)) as CA_10 into #FFAL_CA_10 from #FFAL_TOUS where DATE>@date_30  group by CLIENT
		
		 select distinct CLIENT,NOM_FICHE,VILLE,TYPE,TEL,CA_30,isnull(CA_10,0) as CA_10 from #FFAL_TOUS 
		 left join #FFAL_CA_30 on CLIENT_30=CLIENT left join #FFAL_CA_10 on CLIENT_10=CLIENT
		 where (CA_30-(CA_30*0.2))>CA_10



		drop table #FFAL_TOUS 
		drop table #FFAL_CA_10
		drop table #FFAL_CA_30
      
end
go

