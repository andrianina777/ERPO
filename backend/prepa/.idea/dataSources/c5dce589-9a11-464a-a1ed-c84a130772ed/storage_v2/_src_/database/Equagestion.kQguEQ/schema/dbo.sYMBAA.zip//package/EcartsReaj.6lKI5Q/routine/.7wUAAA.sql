


create procedure EcartsReaj(@ent		char(5)     = null,
							@code_inv	char(8),
							@date_photo	datetime,
							@code_photo	char(16),
							@marque		char(12)    = null,
							@famille	char(8)     = null,
							@article	char(15)    = null,
							@depot		char(4)     = null,
							@emp        char(9)     = null
						   )
with recompile
as
begin

if isnull(@emp,'')<>'' select @emp=rtrim(@emp)+'%'

create table #ecarts
(
article		char(15)	not null,
lettre		char(4)		not null,
qte_inv		int			not null,
qte_stock	int			not null,
depot		char(4)		not null,
emp			char(8)		not null
)

create table #final
(
article		char(15)	not null,
lettre		char(4)		not null,
qte_inv		int			not null,
qte_stock	int			not null,
depot		char(4)		not null,
emp			char(8)		not null
)

insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp)
select INSAR,'',sum(INSQTE),0,isnull(INSDEPOT,''),isnull(INSEMP,'')
from FINS,FDP,FAR
where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and ARCODE=INSAR
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=0 and ARLOT=0
and INSCODE=@code_inv
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)
and (@depot is null or INSDEPOT=@depot)
and (@emp is null or INSEMP like @emp)
group by INSAR,INSDEPOT,INSEMP

insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp)
select PSEMPAR,'',0,sum(PSEMPQTE),PSEMPDEPOT,PSEMPEMP
from FPSEMP,FDP,FAR
where DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
and ARCODE=PSEMPAR
and AROLD=0
and ARTYPE=0
and ARNUMEROTE=0 and ARLOT=0
/*and PSEMPDATE=@date_photo*/
and PSEMPCODE=@code_photo
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)
and (@depot is null or PSEMPDEPOT=@depot)
and (@emp is null or PSEMPEMP like @emp)
group by PSEMPAR,PSEMPDEPOT,PSEMPEMP



insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp)
select INSAR,INSLETTRE,sum(INSQTE),0,isnull(INSDEPOT,''),isnull(INSEMP,'')
from FINS,FDP,FAR
where DPCODE=INSDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and ARCODE=INSAR
and AROLD=0
and ARTYPE=0
and (ARNUMEROTE=1 or ARLOT=1)
and INSCODE=@code_inv
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)
and (@depot is null or INSDEPOT=@depot)
and (@emp is null or INSEMP like @emp)
group by INSAR,INSLETTRE,INSDEPOT,INSEMP

insert into #ecarts (article,lettre,qte_inv,qte_stock,depot,emp)
select PSEMPAR,PSEMPLETTRE,0,sum(PSEMPQTE),PSEMPDEPOT,PSEMPEMP
from FPSEMP,FDP,FAR
where DPCODE=PSEMPDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
and ARCODE=PSEMPAR
and AROLD=0
and ARTYPE=0
and (ARNUMEROTE=1 or ARLOT=1)
and PSEMPDATE=@date_photo
and PSEMPCODE=@code_photo
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)
and (@depot is null or PSEMPDEPOT=@depot)
and (@emp is null or PSEMPEMP like @emp)
group by PSEMPAR,PSEMPLETTRE,PSEMPDEPOT,PSEMPEMP


insert into #final (article,lettre,qte_inv,qte_stock,depot,emp)
select article,lettre,sum(qte_inv),sum(qte_stock),depot,emp
from #ecarts
group by article,lettre,depot,emp

drop table #ecarts

/*
select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,ARNUMEROTE,STNUMARM1,STNUMARM2,ARLOT,NLOTCODE,NLOTDATEPER
from #final,FAR,FSTOCK,FNLOT
where ARCODE=article
and article*=STAR and depot*=STDEPOT and lettre*=STLETTRE
and article*=NLOTAR
and qte_inv != qte_stock
order by depot,ARFO,ARFAM,article,lettre,emp
*/

select ARFO,ARFAM,article,lettre,ARLIB,qte_inv,qte_stock,qte_inv-qte_stock,depot,emp,ARNUMEROTE,STNUMARM1,STNUMARM2,ARLOT,"",""
from #final,FAR,FSTOCK
where ARCODE=article
and article*=STAR and depot*=STDEPOT and lettre*=STLETTRE
and qte_inv != qte_stock
order by depot,ARFO,ARFAM,article,lettre,emp

drop table #final

end




go

