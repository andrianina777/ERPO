


create procedure Clients_sans_cdes (@nbjours int,
				    				@ca 	 int = 0,
									@rep	 char(8) = null)
							
with recompile
as
begin

declare @datetest smalldatetime,
		@nbre numeric(14,2)

select @datetest=dateadd(dd,-@nbjours,getdate())

create table #Final
(
codecl	char(12),
encde	numeric(14,2)
)

create table #CA
(
client	char(12),
ca		numeric(14,2)
)



declare clients cursor
for select CLCODE from FCL where CLSTATUS=0
and (@rep is null or CLREP=@rep)
for read only

declare @code	char(12)
		
open clients

fetch clients
into @code

while (@@sqlstatus = 0)
  begin
	select @nbre=0.00
	select @nbre=sum(CCLTOTALHT) from FCC,FCCL
			where CCLCODE=CCCODE 
			and CCCLIENT=@code
			and CCDATECOM<@datetest	
	
	if @nbre <= @ca
		insert into #Final (codecl,encde) values(@code,@nbre)

	fetch clients
	into @code
  end
	
close clients
deallocate cursor clients


insert into #CA (client,ca)
select STCL,sum(STCAFA)
from FST,#Final
where STAN=datepart(yy,getdate())-1
and STCL=codecl
group by STCL


select Rep=CLREP,Client=codecl,Nom=CLNOM1,Adresse=CLADR1,CP=CLCP,
		Ville=CLVILLE,Telephone=CLTEL1,En_Cde=isnull(encde,0),CA_1=isnull(ca,0)
from FCL,#Final,#CA
where CLCODE = codecl
and client =* codecl
order by CLREP,codecl

drop table #Final
drop table #CA

end



go

