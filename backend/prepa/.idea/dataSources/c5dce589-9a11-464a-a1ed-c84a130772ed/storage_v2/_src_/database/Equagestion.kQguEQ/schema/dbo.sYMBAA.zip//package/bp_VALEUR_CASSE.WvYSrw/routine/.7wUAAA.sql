CREATE PROCEDURE dbo.bp_VALEUR_CASSE
with recompile
AS
begin
	create table #MAJ_LOT(
		VALEUR numeric(18,3),
		DATE datetime
	)
 	
 	--insert into #MAJ_LOT select RJLQTE*RJLPAHT,convert(date,RJLDATE) from FRJL where RJLDATE>'2019-01-01' and upper(RJLCOMMENT) like upper('%INVENTAIRE%') and RJLQTE>0 and RJLDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)
 	
 	insert into #MAJ_LOT select LCLQTE*LCLPAHT,convert(date,LCLDATE) from FLCL where LCLDATE>'2018-01-01' and LCLDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)

 	--insert into #MAJ_LOT select SILQTE*SILPAHT,convert(date,SILDATESIMPLE) from FSIL where SILDATE>'2019-01-01' and upper(SILCOMMENT) like upper('%INVENTAIRE%') and SILQTE>0 and SILDEPOT in (select  DPCODE from FDP where DPCENTRAL=1)
 	
 	select YEAR(DATE) as ANNEE,MONTH(DATE) as MOIS,SUM(VALEUR) as VALEUR from #MAJ_LOT where  MONTH(DATE)< 7 group by YEAR(DATE),MONTH(DATE)
end
go

