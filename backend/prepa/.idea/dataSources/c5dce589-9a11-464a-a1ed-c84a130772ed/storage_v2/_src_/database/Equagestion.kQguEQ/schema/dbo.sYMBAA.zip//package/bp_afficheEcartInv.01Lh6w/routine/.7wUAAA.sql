/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_afficheEcartInv
grant execute on bp_afficheEcartInv to public
*/

CREATE PROCEDURE dbo.bp_afficheEcartInv (@code char(10),@depot char(8),@rayon char(8),@article char(15),@datedeb datetime,@datefin datetime )

AS
begin
	/*if(@depot='GROS') and (@rayon is not null or @rayon<>'')
		begin
		    select INVLCODE,convert(DATE,INVLDATECRE),INVLARCODE,INVLARLIB,INVLLABO,INVLDEPOT,INVLEMP,INVLSSEMP,INVLARLOT,INVLQTEEXACTE,INVLQTEPHYS,INVLECART,INVLANOMALIE1,INVLCAUSE1,INVLSEQ,
		    case when (isnull(INVLANOMALIE1,'')<>'' or isnull(INVLANOMALIE2,'')<>'' or isnull(INVLCAUSE1,'')<>'' or isnull(INVLCAUSE1,'')<>'' or  isnull(INVLCOMMENTAIRE,'')<>'' or isnull(INVLACTION,'')<>'') then 1 else 0 end,
		    INVLANOMALIE2,INVLCAUSE2,INVLCOMMENTAIRE,INVLACTION
		    from h_InvL where INVLECART<>0 and (@code ='' or @code =null or INVLCODE=@code) and (@depot ='' or @depot =null or INVLDEPOT=@depot) and 
		    (@rayon ='' or @rayon =null or INVLEMP in (select distinct rtrim(upper(xEmplSTEMP)) from xEMPL where xDepotl=@depot and xEmpl=@rayon and isnull(xArticlel,'')<>'' and isnull(xEmplSTEMP,'')<>''))
		    and (@article ='' or @article =null or INVLARCODE=@article) and convert(DATE,INVLDATECRE) between @datedeb and @datefin order by INVLCODE,INVLSSEMP,INVLEMP,INVLARCODE
    	end
    else
    	begin*/
    		select INVLCODE,convert(DATE,INVLDATECRE),INVLARCODE,INVLARLIB,INVLLABO,INVLDEPOT,INVLEMP,INVLSSEMP,INVLARLOT,INVLQTEEXACTE,INVLQTEPHYS,INVLECART,INVLANOMALIE1,INVLCAUSE1,INVLSEQ,
		    case when (isnull(INVLANOMALIE1,'')<>'' or isnull(INVLANOMALIE2,'')<>'' or isnull(INVLCAUSE1,'')<>'' or isnull(INVLCAUSE1,'')<>'' or  isnull(INVLCOMMENTAIRE,'')<>'' or isnull(INVLACTION,'')<>'') then 1 else 0 end,
		    INVLANOMALIE2,INVLCAUSE2,INVLCOMMENTAIRE,INVLACTION
		    from h_InvL where INVLECART<>0 and (@code ='' or @code =null or INVLCODE=@code) and (@depot ='' or @depot =null or INVLDEPOT=@depot) and (@rayon ='' or @rayon =null or INVLEMP=@rayon)
		    and (@article ='' or @article =null or INVLARCODE=@article) and convert(DATE,INVLDATECRE) between @datedeb and @datefin order by INVLCODE,INVLEMP,INVLSSEMP,INVLARCODE
    	--end
end
go

