



create procedure Change_Pays (@ent		char(5)	= null,
							  @oldpays	char(8),
							  @newpays	char(8)
							  )
with recompile
as
begin

  declare @nompays	varchar(20)
  
  select @nompays=PYNOM from FPY where PYCODE=@newpays


  update FCL
  set CLPY=@newpays, CLPAYS=@nompays
  where CLPY=@oldpays
  and (@ent is null or CLENT=@ent)
  
  update FFO
  set FOPY=@newpays, FOPAYS=@nompays
  where FOPY=@oldpays
  
  
  update FADR
  set ADRPY=@newpays, ADRPAYS=@nompays
  where ADRPY=@oldpays
  and (@ent is null or ADRCODELIENT=@ent)

end



go

