


create procedure Previsions_Rec	(	@ent			char(5) = null,
									@datedeb		datetime,
								 	@datefin		datetime,
								 	@article		char(15) = null,
								 	@depart			char(8) = null,
								 	@marque			char(12) = null,
								 	@famille		char(8) = null,
								 	@fournisseur	char(12) = null)
with recompile
as
begin

set arithabort numeric_truncation off

declare	@les_mois	int,
		@date_org	datetime

declare @an_prec	int,
		@an			int,
		@an_1		int,
		@an_2		int,
		@an_3		int,
		@an_4		int,
		@an_5		int,
		@an_6		int,
		@an_7		int,
		@an_8		int,
		@an_9		int,
		@an_10		int,
		@mois_prec	tinyint,
		@mois		tinyint,
		@mois_1		tinyint,
		@mois_2		tinyint,
		@mois_3		tinyint,
		@mois_4		tinyint,
		@mois_5		tinyint,
		@mois_6		tinyint,
		@mois_7		tinyint,
		@mois_8		tinyint,
		@mois_9		tinyint,
		@mois_10	tinyint

select 	@an = datepart(yy,@datedeb),
		@mois = datepart(mm,@datedeb)

select	@les_mois = (@an * 12) + @mois

/* calcul des mois - annees relatifs au mois en cours */

select @les_mois = @les_mois - 1
exec periode @les_mois, @an_prec output, @mois_prec output
select @les_mois = @les_mois + 2
exec periode @les_mois, @an_1 output, @mois_1 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_2 output, @mois_2 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_3 output, @mois_3 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_4 output, @mois_4 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_5 output, @mois_5 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_6 output, @mois_6 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_7 output, @mois_7 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_8 output, @mois_8 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_9 output, @mois_9 output
select @les_mois = @les_mois + 1
exec periode @les_mois, @an_10 output, @mois_10 output

select @date_org = convert(datetime,convert(varchar(4),@mois_prec)+'/01/'+convert(varchar(4),@an_prec))

create table #Final
(
article			char(15)		not null,
recep_prec		int				null,
valeur_prec		numeric(14,2)	null,
recep_mois		int				null,
valeur_mois		numeric(14,2)	null,
recep_mois_1	int				null,
valeur_mois_1	numeric(14,2)	null,
recep_mois_2	int				null,
valeur_mois_2	numeric(14,2)	null,
recep_mois_3	int				null,
valeur_mois_3	numeric(14,2)	null,
recep_mois_4	int				null,
valeur_mois_4	numeric(14,2)	null,
recep_mois_5	int				null,
valeur_mois_5	numeric(14,2)	null,
recep_mois_6	int				null,
valeur_mois_6	numeric(14,2)	null,
recep_mois_7	int				null,
valeur_mois_7	numeric(14,2)	null,
recep_mois_8	int				null,
valeur_mois_8	numeric(14,2)	null,
recep_mois_9	int				null,
valeur_mois_9	numeric(14,2)	null,
recep_mois_10	int				null,
valeur_mois_10	numeric(14,2)	null
)

create table #FinalClient
(
Carticle		char(15)		not null,
Crecep_prec		int				null,
Cvaleur_prec	numeric(14,2)	null,
Crecep_mois		int				null,
Cvaleur_mois	numeric(14,2)	null,
Crecep_mois_1	int				null,
Cvaleur_mois_1	numeric(14,2)	null,
Crecep_mois_2	int				null,
Cvaleur_mois_2	numeric(14,2)	null,
Crecep_mois_3	int				null,
Cvaleur_mois_3	numeric(14,2)	null,
Crecep_mois_4	int				null,
Cvaleur_mois_4	numeric(14,2)	null,
Crecep_mois_5	int				null,
Cvaleur_mois_5	numeric(14,2)	null,
Crecep_mois_6	int				null,
Cvaleur_mois_6	numeric(14,2)	null,
Crecep_mois_7	int				null,
Cvaleur_mois_7	numeric(14,2)	null,
Crecep_mois_8	int				null,
Cvaleur_mois_8	numeric(14,2)	null,
Crecep_mois_9	int				null,
Cvaleur_mois_9	numeric(14,2)	null,
Crecep_mois_10	int				null,
Cvaleur_mois_10	numeric(14,2)	null
)

/* Liste des articles repondant aux criteres */

create table #ListeArticle (


	ARCODE		char(15)	not null,
		ARLIB			char(80)	null,
		ARTYPE		tinyint		not null)
		
if @fournisseur is null
begin
	insert into #ListeArticle (ARCODE,ARLIB,ARTYPE)
	select ARCODE,ARLIB,ARTYPE
	from FAR
	where (@article is null or ARCODE=@article)
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
end
else
begin
	insert into #ListeArticle (ARCODE,ARLIB,ARTYPE)
	select ARCODE,ARLIB,ARTYPE
	from FAR,FARF
	where ARFCODE=ARCODE
	and (@article is null or ARCODE=@article)
	and (@depart is null or ARDEPART=@depart)
	and (@marque is null or ARFO=@marque)
	and (@famille is null or ARFAM=@famille)
	and (@fournisseur is null or ARFFO=@fournisseur)
end

/* Liste des articles en commandes Fournisseurs */

select ARCODE,ARLIB
into #FarFournisseur
from #ListeArticle,FRCF
where ARCODE=RCFARTICLE
and (@ent is null or RCFENT=@ent)
group by ARCODE,ARLIB

/* Liste des articles en commandes Clients */

select CODE = ARCODE
into #FarClient
from #ListeArticle,FRCC
where ARCODE=RCCARTICLE
and (@ent is null or RCCENT=@ent)
group by ARCODE

/* Liste des Commandes Clients */

select RCCARTICLE,qteCC=isnull(sum(RCCQTE),0),valeurCC=isnull(sum(round(RCCQTE*CCLTOTALHT/CCLQTE,2)),0)
into #Cdes
from FRCC,FCCL,FCL,#ListeArticle,FCC
where ARCODE=RCCARTICLE
and ARTYPE in (0,1)
and CLCODE=RCCCL
and CLPAYEUR in (0,1)
and CCLSEQ=RCCSEQ
and CCCODE=CCLCODE
and isnull(CCVALIDE,0)=0
and (@ent is null or (RCCENT=@ent and CCLENT=@ent and CLENT=@ent and CCENT=@ent))
group by RCCARTICLE
order by RCCARTICLE

/* Stock pour expeditions et sous douanes+autres des produits en commandes Fournisseurs */

select STAR,STQTE_LOC=isnull(sum(case when DPLOC=1 then STQTE else 0 end),0),
		STQTE_DOUA=isnull(sum(case when DPLOC != 1 then STQTE else 0 end),0)
into #Stock
from FSTOCK,#FarFournisseur,FDP
where STAR=ARCODE
and STQTE != 0
and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0))
group by STAR


/* Reliquats de commandes Fournisseurs (avant mois-1) */

select RCFARTICLE,RCFQTE_old=isnull(sum(RCFQTE),0),RCFVAL_old=isnull(sum(round(CFLTOTALHT/CFLQTE,2)*RCFQTE),0)
into #Recep_old
from FRCF,#FarFournisseur,FCFL
where RCFARTICLE=ARCODE
and RCFSEQ=CFLSEQ
and RCFDATE < @date_org
and (@ent is null or (RCFENT=@ent and CFLENT=@ent))
group by RCFARTICLE

/* Reliquats de commandes Clients (avant mois-1) */

select C_RCCARTICLE=RCCARTICLE,RCCQTE_old=isnull(sum(RCCQTE),0)
into #Recep_oldClient
from FRCC,#FarClient,FCCL
where RCCARTICLE=CODE
and RCCSEQ=CCLSEQ
and RCCDATE < @date_org
and (@ent is null or (RCCENT=@ent and CCLENT=@ent))
group by RCCARTICLE

/* Commandes Fournisseurs a partir de mois-1 */

select RCFARTICLE,RCFAN,RCFMOIS=datepart(mm,dateadd(dd,5,RCFDATE)),RCFQTE=isnull(sum(RCFQTE),0),
		RCFVAL=isnull(sum(round(CFLTOTALHT/CFLQTE,2)*RCFQTE),0)
into #Recep
from FRCF,#FarFournisseur,FCFL
where RCFARTICLE=ARCODE
and RCFSEQ=CFLSEQ
and RCFDATE between @date_org and @datefin
and (@ent is null or (RCFENT=@ent and CFLENT=@ent))
group by RCFARTICLE,RCFAN,datepart(mm,dateadd(dd,5,RCFDATE))
order by RCFARTICLE,RCFAN,datepart(mm,dateadd(dd,5,RCFDATE))

/* Commandes Clients a partir de mois-1 */

select RCCARTICLE,RCCAN,RCCMOIS=datepart(mm,dateadd(dd,5,RCCDATE)),RCCQTE=isnull(sum(RCCQTE),0),
		RCCVAL=isnull(sum(round(CCLTOTALHT/CCLQTE,2)*RCCQTE),0)
into #RecepClient
from FRCC,#FarClient,FCCL
where RCCARTICLE=CODE
and RCCSEQ=CCLSEQ
and RCCDATE between @date_org and @datefin
and (@ent is null or (RCCENT=@ent and CCLENT=@ent))
group by RCCARTICLE,RCCAN,datepart(mm,dateadd(dd,5,RCCDATE))
order by RCCARTICLE,RCCAN,datepart(mm,dateadd(dd,5,RCCDATE))

/* Mise en place des valeurs de commandes Fournisseurs sur la periode */

insert into #Final (article,
					recep_prec, valeur_prec,
					recep_mois, valeur_mois,
					recep_mois_1, valeur_mois_1,
					recep_mois_2, valeur_mois_2,
					recep_mois_3, valeur_mois_3,
					recep_mois_4, valeur_mois_4, 
					recep_mois_5, valeur_mois_5,
					recep_mois_6, valeur_mois_6,
					recep_mois_7, valeur_mois_7,
					recep_mois_8, valeur_mois_8,
					recep_mois_9, valeur_mois_9,
					recep_mois_10, valeur_mois_10)
select ARCODE,
		isnull(sum(case when RCFAN=@an_prec and RCFMOIS=@mois_prec then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_prec and RCFMOIS=@mois_prec then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an and RCFMOIS=@mois then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an and RCFMOIS=@mois then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_1 and RCFMOIS=@mois_1 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_1 and RCFMOIS=@mois_1 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_2 and RCFMOIS=@mois_2 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_2 and RCFMOIS=@mois_2 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_3 and RCFMOIS=@mois_3 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_3 and RCFMOIS=@mois_3 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_4 and RCFMOIS=@mois_4 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_4 and RCFMOIS=@mois_4 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_5 and RCFMOIS=@mois_5 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_5 and RCFMOIS=@mois_5 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_6 and RCFMOIS=@mois_6 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_6 and RCFMOIS=@mois_6 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_7 and RCFMOIS=@mois_7 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_7 and RCFMOIS=@mois_7 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_8 and RCFMOIS=@mois_8 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_8 and RCFMOIS=@mois_8 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_9 and RCFMOIS=@mois_9 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_9 and RCFMOIS=@mois_9 then RCFVAL else 0 end),0),
		isnull(sum(case when RCFAN=@an_10 and RCFMOIS=@mois_10 then RCFQTE else 0 end),0),
		isnull(sum(case when RCFAN=@an_10 and RCFMOIS=@mois_10 then RCFVAL else 0 end),0)
from #FarFournisseur,#Recep
where ARCODE=RCFARTICLE
group by ARCODE

/* Mise en place des valeurs de commandes Clients sur la periode */

insert into #FinalClient (Carticle,
					Crecep_prec, Cvaleur_prec,
					Crecep_mois, Cvaleur_mois,
					Crecep_mois_1, Cvaleur_mois_1,
					Crecep_mois_2, Cvaleur_mois_2,
					Crecep_mois_3, Cvaleur_mois_3,
					Crecep_mois_4, Cvaleur_mois_4, 
					Crecep_mois_5, Cvaleur_mois_5,
					Crecep_mois_6, Cvaleur_mois_6,
					Crecep_mois_7, Cvaleur_mois_7,
					Crecep_mois_8, Cvaleur_mois_8,
					Crecep_mois_9, Cvaleur_mois_9,
					Crecep_mois_10, Cvaleur_mois_10)
	select CODE,
		isnull(sum(case when RCCAN=@an_prec and RCCMOIS=@mois_prec then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_prec and RCCMOIS=@mois_prec then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an and RCCMOIS=@mois then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an and RCCMOIS=@mois then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_1 and RCCMOIS=@mois_1 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_1 and RCCMOIS=@mois_1 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_2 and RCCMOIS=@mois_2 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_2 and RCCMOIS=@mois_2 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_3 and RCCMOIS=@mois_3 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_3 and RCCMOIS=@mois_3 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_4 and RCCMOIS=@mois_4 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_4 and RCCMOIS=@mois_4 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_5 and RCCMOIS=@mois_5 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_5 and RCCMOIS=@mois_5 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_6 and RCCMOIS=@mois_6 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_6 and RCCMOIS=@mois_6 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_7 and RCCMOIS=@mois_7 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_7 and RCCMOIS=@mois_7 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_8 and RCCMOIS=@mois_8 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_8 and RCCMOIS=@mois_8 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_9 and RCCMOIS=@mois_9 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_9 and RCCMOIS=@mois_9 then RCCVAL else 0 end),0),
		isnull(sum(case when RCCAN=@an_10 and RCCMOIS=@mois_10 then RCCQTE else 0 end),0),
		isnull(sum(case when RCCAN=@an_10 and RCCMOIS=@mois_10 then RCCVAL else 0 end),0)
from #FarClient,#RecepClient
where CODE=RCCARTICLE
group by CODE

/* select final */


select ARCODE,ARLIB,isnull(STQTE_LOC,0),isnull(STQTE_DOUA,0),
		isnull(RCFQTE_old,0),isnull(RCFVAL_old,0),
		isnull(recep_prec,0),isnull(valeur_prec,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)),
		isnull(recep_mois,0),isnull(valeur_mois,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0)),
		isnull(recep_mois_1,0),isnull(valeur_mois_1,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0)),
		isnull(recep_mois_2,0),isnull(valeur_mois_2,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)),
		isnull(recep_mois_3,0),isnull(valeur_mois_3,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0)),
		isnull(recep_mois_4,0),isnull(valeur_mois_4,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0) + isnull(recep_mois_4,0)),
		isnull(recep_mois_5,0),isnull(valeur_mois_5,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0) + isnull(recep_mois_4,0) + isnull(recep_mois_5,0)),
		isnull(recep_mois_6,0),isnull(valeur_mois_6,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0) + isnull(recep_mois_4,0) + isnull(recep_mois_5,0)
									+ isnull(recep_mois_6,0)),
		isnull(recep_mois_7,0),isnull(valeur_mois_7,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0) + isnull(recep_mois_4,0) + isnull(recep_mois_5,0)
									+ isnull(recep_mois_6,0) + isnull(recep_mois_7,0)),
		isnull(recep_mois_8,0),isnull(valeur_mois_8,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0) + isnull(recep_mois_4,0) + isnull(recep_mois_5,0)
									+ isnull(recep_mois_6,0) + isnull(recep_mois_7,0) + isnull(recep_mois_8,0)),
		isnull(recep_mois_9,0),isnull(valeur_mois_9,0),isnull(STQTE_LOC,0) + isnull(RCFQTE_old,0) + (isnull(recep_prec,0)
									+ isnull(recep_mois,0) + isnull(recep_mois_1,0) + isnull(recep_mois_2,0)
									+ isnull(recep_mois_3,0) + isnull(recep_mois_4,0) + isnull(recep_mois_5,0)
									+ isnull(recep_mois_6,0) + isnull(recep_mois_7,0) + isnull(recep_mois_8,0)
									+ isnull(recep_mois_9,0)),
		isnull(recep_mois_10,0),isnull(valeur_mois_10,0),
		isnull(qteCC,0),isnull(valeurCC,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0)
									+ isnull(Crecep_mois_5,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0)
									+ isnull(Crecep_mois_5,0)
									+ isnull(Crecep_mois_6,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0)
									+ isnull(Crecep_mois_5,0)
									+ isnull(Crecep_mois_6,0)
									+ isnull(Crecep_mois_7,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0)
									+ isnull(Crecep_mois_5,0)
									+ isnull(Crecep_mois_6,0)
									+ isnull(Crecep_mois_7,0)
									+ isnull(recep_mois_8,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0)
									+ isnull(Crecep_mois_5,0)
									+ isnull(Crecep_mois_6,0)
									+ isnull(Crecep_mois_7,0)
									+ isnull(Crecep_mois_8,0)
									+ isnull(Crecep_mois_9,0),
		isnull(RCCQTE_old,0) + isnull(Crecep_prec,0) + isnull(Crecep_mois,0) + isnull(Crecep_mois_1,0) + isnull(Crecep_mois_2,0)
									+ isnull(Crecep_mois_3,0)
									+ isnull(Crecep_mois_4,0)
									+ isnull(Crecep_mois_5,0)
									+ isnull(Crecep_mois_6,0)
									+ isnull(Crecep_mois_7,0)
									+ isnull(Crecep_mois_8,0)
									+ isnull(Crecep_mois_9,0)
									+ isnull(Crecep_mois_10,0),
		isnull(RCCQTE_old,0)		
from #Final,#FarFournisseur,#Stock,#Recep_old,#Cdes,#FinalClient,#FarClient,#Recep_oldClient
where ARCODE *= article
and ARCODE *= STAR
and ARCODE *= RCFARTICLE
and ARCODE *= RCCARTICLE
and ARCODE *= Carticle
and ARCODE *= CODE
and ARCODE *= C_RCCARTICLE
order by ARCODE,ARLIB


drop table #FarFournisseur
drop table #Cdes
drop table #Stock
drop table #Recep
drop table #Recep_old
drop table #Recep_oldClient
drop table #Final
drop table #FarClient
drop table #RecepClient
drop table #FinalClient
drop table #ListeArticle

end

go

