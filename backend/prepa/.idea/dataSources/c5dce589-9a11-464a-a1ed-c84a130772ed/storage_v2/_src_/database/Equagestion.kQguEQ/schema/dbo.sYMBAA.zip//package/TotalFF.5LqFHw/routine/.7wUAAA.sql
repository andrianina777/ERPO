


create procedure TotalFF	(	@ent			char(5) = null,
								@code 			char(10),
							 	@fraisdev		numeric(14,2),
							 	@tafrais		char(4),
							 	@douanesdev		numeric(14,2),
							 	@tadouanes		char(4),
							 	@transdev		numeric(14,2),
							 	@tatrans		char(4),
							 	@tvadev			numeric(14,2),
							 	@tatva			char(4),
							 	@sanstva		tinyint,
							 	@spid			int,
							 	@foclasse		char(10)
							 )
with recompile
as
begin

set arithabort numeric_truncation off


/* cette procedure ne peut etre efficacement utilisee que depuis OMNIS 
	car elle utilise le contenu de la table FFTP */


create table #Lignes
(
TOTALHT			numeric(14,2)		null,
TAUX			real				null,
COMPTETVA		char(12)			null
)

	insert into #Lignes (TOTALHT,TAUX,COMPTETVA)
		 select TPTOTDEV,TVLTAUXTVA,TVLCPT
		 from FFTP, FTVL
		 where TVLCODE=TPTYPEVE and TVLCLASSE=@foclasse
		 and TPCODE=@code
		 and TPUSERID=@spid
		 and (@ent is null or (TPENT=@ent and TVLENT=@ent))
	
	if (@tafrais != "")
		insert into #Lignes
			select @fraisdev,TVLTAUXTVA,TVLCPT
			from FTVL 
			where TVLCLASSE=@foclasse and TVLCODE=@tafrais
			and (@ent is null or TVLENT=@ent)
	
	if (@tadouanes != "")
		insert into #Lignes
			select @douanesdev,TVLTAUXTVA,TVLCPT
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tadouanes
			and (@ent is null or TVLENT=@ent)
	
	if (@tatrans != "")
		insert into #Lignes
			select @transdev,TVLTAUXTVA,TVLCPT
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tatrans
			and (@ent is null or TVLENT=@ent)
	
	if (@tatva != "")
		insert into #Lignes
			select @tvadev,TVLTAUXTVA,TVLCPT
			from FTVL
			where TVLCLASSE=@foclasse and TVLCODE=@tatva
			and (@ent is null or TVLENT=@ent)
	
	
 /* faire tous les calculs avec	TOTALHT */
 
 	select COMPTETVA,TAUX,TotalLigneHT=round(sum(TOTALHT),3),Taxe=round(sum(TOTALHT)*(TAUX/100),3)
	into #Taxes
	from #Lignes
	group by COMPTETVA,TAUX
	
	
	select TAUX,TotalHT=round(sum(TotalLigneHT),3),TotalTaxe=round(sum(Taxe),3)
	into #LesTaxes
	from #Taxes
	group by TAUX
		
 	
 /* Calcul et repartition des taxes */	
	
	
	declare @taxe		numeric(14,2)			/* total de la taxe */
	declare @totalht	numeric(14,2)			/* total HT */
	declare @netapayer	numeric(14,2)			/* net a payer */
	
	
	if @sanstva=1
	  begin
			select @taxe=0
			select @totalht=round(sum(TotalHT),3) from #LesTaxes
			select @netapayer=isnull(@totalht,0)
	  end
	else
	  begin
		  
		  select @totalht=round(sum(TotalHT),3),@taxe=round(sum(TotalTaxe),3)
		  from #LesTaxes
		 		  
		  select @netapayer=isnull(@totalht,0)+isnull(@taxe,0)
		  
		  
	  end
	
 /* renvoi des resultats a la procedure appelante */
 
 	select totalht=isnull(@totalht,0),taxe=isnull(@taxe,0),netapayer=isnull(@netapayer,0)
			
drop table #Lignes
drop table #Taxes
drop table #LesTaxes
	 
end



go

