

/* Procedure permettant d'ouvrir un tableau de bord des achats par chef de produits existant*/
/* Modification le 061107 par SP */
/* Modification le 220508 par JG/SP : ajout retours fournisseurs */
	

create procedure TBA_maj (@code			char(10))
with recompile
as
begin

/* version du 220508 */

declare 		@chcode		char(8),
				@typevalo	tinyint,
				@annee		int,
				@pscode		char(16),
				@psdate		datetime											

select @chcode=TBAECH, @typevalo=TBAETYPEVAL, @annee=TBAEANNEE, @pscode=TBAEPS, @psdate=TBAEPSDATE
from FTBAE 
where TBAECODE=@code	

declare @daterefsup	smalldatetime,
		@daterefinf	smalldatetime,
		@datedebut	smalldatetime,
		@an 		char(4)
							
select @an=convert(char,@annee)

select @daterefsup=@an+"1231"
select @daterefinf=@an+"0101"

/* on ne veut pas les elements de commandes clients et fournisseurs de plus de 2 ans */
select @datedebut = dateadd(yy,-2,@daterefinf)

create table #tba
(
fo			char(12)		null,
fam			char(8)			null,
achats		numeric(14,0)	null,
ca			numeric(14,0)	null,
pr			numeric(14,0)	null,
cdefo		numeric(14,0)	null,
cdecl		numeric(14,0)	null
)

/* ---------- select marques et familles du chef de produits */
insert into #tba
select ARFO,ARFAM,0,0,0,0,0
from FAR
where ARCHEFP=@chcode
group by ARFO, ARFAM

/* ---------- select achats */

insert into #tba
select ARFO,ARFAM,convert(numeric(14,0),sum(isnull(BLLTOTHT,0))),0,0,0,0
from FAR,FBLL
where BLLAR=ARCODE
	and ARCHEFP=@chcode
	and BLLDATE>=@daterefinf and BLLDATE<=@daterefsup
group by ARFO,ARFAM


/* ---------- select retours fournisseurs */

insert into #tba
select ARFO,ARFAM,convert(numeric(14,0),-(sum(isnull(RFLTOTALHT,0)))),0,0,0,0
from FAR,FRFL
where RFLARTICLE=ARCODE
	and ARCHEFP=@chcode
	and RFLDATE>=@daterefinf and RFLDATE<=@daterefsup
group by ARFO,ARFAM


/* ---------- select chiffres d'affaire, marges */

insert into #tba
select ARFO,ARFAM,0,convert(numeric(14,0),sum(isnull(STCAFA,0))),
	(case	when @typevalo=0 
				then convert(numeric(14,0),isnull(sum(STPR),0))
			when @typevalo=1
				then convert(numeric(14,0),isnull(sum(STPRM),0))
			else
				convert(numeric(14,0),isnull(sum(STPUM),0))
	end),
	0,0
from FAR,FST
where START=ARCODE
	and ARCHEFP=@chcode 
	and (STAN=@annee)
group by ARFO,ARFAM


/* ---------- select cdes fournisseurs */

insert into #tba
select ARFO,ARFAM,0,0,0,
	convert(numeric(14,0),sum(case when CFLQTE=0 then 0 else isnull(CFLTOTALHT/CFLQTE*RCFQTE,0) end)),0
from FAR,FRCF,FCFL,FCF
where RCFARTICLE=ARCODE and CFLSEQ=RCFSEQ and CFCODE=CFLCODE 
	and ARCHEFP=@chcode
	and CFVALIDE=0
	and CFLDATEP between @datedebut and @daterefsup
group by ARFO, ARFAM

/* ---------- select cdes clients */
insert into #tba
select ARFO,ARFAM,0,0,0,0,
	convert(numeric(14,0),sum(case when CCLQTE=0 then 0 else isnull(CCLTOTALHT/CCLQTE*RCCQTE,0) end))
from FAR,FRCC,FCCL,FCC
where RCCARTICLE=ARCODE and CCLSEQ=RCCSEQ and CCCODE=CCLCODE
	and ARCHEFP=@chcode 
	and CCVALIDE=0
	and CCLDATE between @datedebut and @daterefsup
group by ARFO, ARFAM

/* ---------- select final : on recupere les nouveaux couples marque/famille seulement pour l'annee en cours */
if @annee >= datepart(yy,getdate())
begin
	select 	fo,fam,isnull(TBASTDEB,0),isnull(TBACA,0),isnull(TBAMARGE,0),0,isnull(TBASTFIN,0),isnull(TBAACHAT,0),
					sum(achats),sum(ca),convert(numeric(14,2),(case when sum(ca)=0 then 0 else 100*(sum(ca)-isnull(sum(pr),0))/sum(ca) end)),0,
					sum(cdefo),sum(cdecl),0,0,
					0,FODEVISE,
					@pscode,@psdate,@typevalo,@chcode,@annee,isnull(TBASEQ,0),@code,isnull(TBALIGNE,0)
	from #tba,FTBA,FFO
	where TBAFO=*fo and TBAFP=*fam
				and FOCODE=*fo
				and TBACODE=@code
	group by fo,fam,TBASTDEB,TBACA,TBAMARGE,TBASTFIN,TBAACHAT,FODEVISE,TBASEQ,TBALIGNE
	order by fo,fam,FODEVISE
end
else
begin
	select 	fo,fam,isnull(TBASTDEB,0),isnull(TBACA,0),isnull(TBAMARGE,0),0,isnull(TBASTFIN,0),isnull(TBAACHAT,0),
					sum(achats),sum(ca),convert(numeric(14,2),(case when sum(ca)=0 then 0 else 100*(sum(ca)-isnull(sum(pr),0))/sum(ca) end)),0,
					sum(cdefo),sum(cdecl),0,0,
					0,FODEVISE,
					@pscode,@psdate,@typevalo,@chcode,@annee,isnull(TBASEQ,0),@code,isnull(TBALIGNE,0)
	from #tba,FTBA,FFO
	where TBAFO=fo and TBAFP=fam
				and FOCODE=fo
				and TBACODE=@code
	group by fo,fam,TBASTDEB,TBACA,TBAMARGE,TBASTFIN,TBAACHAT,FODEVISE,TBASEQ,TBALIGNE
	order by fo,fam,FODEVISE
end

drop table #tba
end
go

