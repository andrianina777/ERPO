
create procedure StockPhoto (	@marque		char(12)	= null,
								@famille	char(8)		= null,
								@article	char(15)	= null,
								@depot		char(4)		= null,
								@emp1       char(8)     = null,
								@emp2       char(8)     = null,
								@code		char(16)	= null,			
								@arprm		tinyint		= null,
								@situation	tinyint	= null
							)
with recompile
as
begin

set arithabort numeric_truncation off

declare @date		datetime,
		@date_1		datetime,
		@userid		int
		
select @userid=(select user_id())
select @date_1=convert(datetime,"01/01/"+convert(char(4),datepart(yy,getdate())-1))
select @date=convert(datetime,convert(char(2),datepart(mm,getdate()))+"/"+convert(char(2),datepart(dd,getdate()))+"/"+convert(char(4),datepart(yy,getdate())))
select @code=isnull(@code,"MENSUELLE")

if @arprm!=1 select @arprm=null

insert into FPSEMP (PSEMPAR,PSEMPLETTRE,PSEMPDEPOT,PSEMPEMP,PSEMPQTE,PSEMPDATEENT,PSEMPLOT,PSEMPDATE,PSEMPDATEIN,PSEMPUSERID,PSEMPCODE)
select STEMPAR,STEMPLETTRE,STEMPDEPOT,STEMPEMP,STEMPQTE,isnull(STEMPDATE,getdate()),isnull(STEMPLOT,""),@date,getdate(),@userid,@code
from FSTEMP,FAR
where ARCODE=STEMPAR
and ARTYPE = 0
and (@marque is null or ARFO=@marque)
and (@famille is null or ARFAM=@famille)
and (@article is null or ARCODE=@article)
and (@depot is null or STEMPDEPOT=@depot)
and (@emp1 is null or STEMPEMP between @emp1 and @emp2)
and STEMPQTE != 0

delete from FIPS 
where IPSDATE = @date and IPSCODE = @code

insert into FIPS (IPSDATE,IPSMARQUE,IPSFAM,IPSAR,IPSDEPOT,IPSEMP,IPSEMP2,IPSCODE,IPSSITUATION)
values(@date,isnull(@marque,""),isnull(@famille,""),isnull(@article,""),isnull(@depot,""),isnull(@emp1,""),isnull(@emp2,""),@code,@situation)

if isnull(@emp1,"")="" /* ecriture FPS et FBP si emp vide seulement */
begin
    delete from FPS
    where PSDATE = @date and PSCODE = @code
   
    insert into FPS (PSAR,PSLETTRE,PSQTE,PSSERIE1,PSSERIE2,PSDATEENT,PSDEPOT,PSPAHT,PSFRAIS,PSPADEV,PSDEV,PSDATE,PSDATEIN,PSUSERID,PSFO,PSCODE,PSLOT)
    select STAR,STLETTRE,STQTE,STNUMARM1,STNUMARM2,STDATEENTR,STDEPOT,
		(case when @arprm is null then round(STPAHT,2) else round(isnull(ARPRM,0),2) end),
		(case when @arprm is null then round(STFRAIS,2) else 0 end),
		(case when @arprm is null then round(STPADEV,2) else round(isnull(ARPRM,0),2) end),
		isnull(STDEVISE,""),@date,getdate(),@userid,STFO,@code,STLOT
    from FSTOCK,FAR
    where ARCODE=STAR
    and ARTYPE = 0
    and (@marque is null or ARFO=@marque)
    and (@famille is null or ARFAM=@famille)
    and (@article is null or ARCODE=@article)
    and (@depot is null or STDEPOT=@depot)
    and STQTE != 0


    delete from FPB
    where PBDATE = @date and PBCODE = @code

    insert into FPB (PBAR,PBLETTRE,PBQTE,PBSERIE1,PBSERIE2,PBDATEENT,PBDEPOT,PBPAHT,PBFRAIS,PBPADEV,PBDEV,PBDATE,PBDATEIN,
				PBUSERID,PBFO,PBCODE,PBBE,PBNUM,PBDATEBE,PBDEMO,PBCL,PBNOM,PBENT,PBSTADE)
    select BELARTICLE,BELLETTRE,BELQTE,STNUMARM1,STNUMARM2,STDATEENTR,STDEPOT,round(STPAHT,2),round(STFRAIS,2),round(STPADEV,2),isnull(STDEVISE,""),@date,getdate(),
				@userid,STFO,@code,BELCODE,BELNUM,BEDATE,isnull(BELDEMO,0),BECL,isnull(BENOM,""),BELENT,BELSTADE
    from FBEL,FRBE,FBE,FAR,FSTOCK
    where BELSEQ=RBESEQ
    and BECODE=BELCODE
    and ARCODE=BELARTICLE
    and STAR=BELARTICLE
    and STLETTRE=BELLETTRE
    and ARTYPE = 0
    and (@marque is null or ARFO=@marque)
    and (@famille is null or ARFAM=@famille)
    and (@article is null or ARCODE=@article)
    and (@depot is null or STDEPOT=@depot)
    and BELQTE != 0
end

end
go

