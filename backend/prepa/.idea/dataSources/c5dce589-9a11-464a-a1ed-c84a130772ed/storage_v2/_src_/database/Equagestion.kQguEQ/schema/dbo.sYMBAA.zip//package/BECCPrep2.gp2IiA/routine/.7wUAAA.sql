/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.BECCPrep
grant execute on BECCPrep to public

*/


/*  Procedure utilisee par le module 'Expeditions et Bons de Preparation'.	 */
/*	Renvoie les commandes a expedier dont les articles ne sont pas numerotes */
/*	Renvoie le nombre de colis de la commande								 */

CREATE PROCEDURE dbo.BECCPrep2 (@ent		char(5) = null,
							@UntilDate 	datetime = null,
							@Client		char(12),
							@Commande 	char(10) = null,
							@Depot		char(4),
							@nom		varchar(35) = null,
							@adr1		varchar(50) = null,
							@adr2		varchar(50) = null,
							@cp			varchar(12) = null,
							@ville		varchar(30) = null,
							@py			char(8) = null,
							@devise		char(3) = null
						   )
with recompile					
as
begin

set arithabort numeric_truncation off

declare @restotal	int,
		@resligne	int,
		@stocktotal	int,
		@CC2AO int,
		@CC2SPEC int

        create table #ccl(
                CCLSEQ int,
                CCLCODE char(15) null,
                CCLARTICLE char(15) null,
                ARLIB char(80) null,
                ARLIBXENO char(50) null,
                ARFO char(30) null,
                CCLNUMARM1 char(50) null,
                CCLLOT char(12) null,
                CCLQTE int not null,
                AREEMP char(10) null,
                STRESQTE int null,
                NLOTDATEPER smalldatetime null,
                xORDRE int null,
                xCONTENT char(50) null,
                xSTKAUTRE int null,
                xCONTENT2 char(50) null,
                ARESSEMP char(10) null
        )
	create table #ccl2(
                CCLCODE char(15) null,
                CCLARTICLE char(15) null,
                ARLIB char(80) null,
                ARLIBXENO char(50) null,
                ARFO char(30) null,
                CCLQTE int not null,
                AREEMP char(10) null,
                STRESQTE int null,
                xORDRE int null,
                xCONTENT char(50) null,
                xSTKAUTRE int null,
                xCONTENT2 char(50) null,
                ARESSEMP char(10) null
	)	

		
        create table #Liste
        (
                Article 		char(15)	not null,
                Lettre			char(4)		not null,
                Designation		char(80)		null,
                LienCode		char(10)	not null,
                LienNum			int			not null,
                Qte				int				null,
                UnitFact		tinyint		not null,
                PrixHT			numeric(14,2)	null,
                ModeLiv			char(2)			null,
                LigneLibre		varchar(255)	null,
                TypeVente		char(4)		not null,
                Reglement		tinyint			null,
                Echeancesp		tinyint			null,
                Factman			tinyint			null,
                Offert			tinyint			null,
                Artype			tinyint			null,
                Devise			char(3)		not null,
                Coursdev		numeric(16,10)	null,
                PrixHTdev		numeric(14,2)	null,
                TotHTdev		numeric(14,2)	null,
                Rem1			real			null,
                Rem2			real			null,
                Rem3	 		real			null,
                TotPrixHT		numeric(14,2)	null,
                Emplacement		char(8)		not null,
                Attachement		char(10)		null,
                Lot				char(12)	not null,
                Arreffour		char(20)		null,
                cclmarche		char(12)		null,
                ccldate			datetime		null,
                cclcolis		numeric(14,2)	null,
                arqtecolis		int				null,
                cclpaht			numeric(14,2)	null,
                seqLib numeric (18,0) null,
                comment_mag		varchar(255)	null
        )

        create table #Prep
        (
                CCLSEQ			numeric(14,0)			not null,
                CCLCODE			char(10)	not null,
                CCLNUM			int				null,
                CCLDATE			datetime		null,
                CCLARTICLE		char(15)	not null,
                CCLRESTE		int				null,
                ARLIB			varchar(80)		null,
                ARUNITFACT		tinyint			null,
                CCLPHT			numeric(14,2)	null,
                MODELIV			char(2)			null,
                CCLLIBRE		varchar(255)	null,
                CCLTV			char(4)			null,
                ARREGLE			tinyint			null,
                CCLECHSPE		tinyint			null,
                CCLFACTMAN		tinyint			null,
                CCLOFFERT		tinyint			null,
                ARTYPE			tinyint			null,
                CCLDEV			char(3)			null,
                CCLCOURSDEV		numeric(16,10)	null,
                CCLPHTDEV		numeric(14,2)	null,
                CCLTOTALHTDEV	numeric(14,2)	null,
                CCLR1			real		 	null,
                CCLR2			real			null,
                CCLR3			real			null,
                CCLTOTALHT		numeric(14,2)	null,
                CCLQTERES		int				null,
                CCLDATERESFIN	smalldatetime	null,
                CCLDEPOTRES		char(4)			null,
                ARCOMP			tinyint			null,
                CCLQTEPREP		int				null,
                CCLATTACHE		char(10)		null,
                ARREFFOUR 		char(20)		null,
                CCLMARCHE		char(12)		null,
                CCLCOLIS		numeric(14,2)	null,
                ARQTECOLIS		int				null,
                CCLPAHT			numeric(14,2)	null,
                CCL_LIBSEQ numeric(18,0) null,
                CCL_COMMENT_MAG varchar(255)	null,
        )

        create table #Articles
        (
                CCLARTICLE	char(50)		not null,
                ARTYPE int null
        )

        create table #Stock
        (
                STEMPAR			char(15)		not null,
                STEMPLETTRE		char(4)			not null,
                QteLoc			int					null,
                STEMPDATE		datetime			null,
                STEMPEMP		char(8)			not null,
                STEMPLOT		char(12)		not null,
                STEMPDEPOT		char(4)			not null,
                SEQ				numeric(14,0)	identity
        )
        create table #Stocktmp
        (
                STEMPAR			char(15)	not null,
                STEMPLETTRE		char(4)		not null,
                QteLoc			int		null,
                STEMPDATE		datetime	null,
                STEMPEMP		char(8)		not null,
                STEMPLOT		char(12)	not null,
                STEMPDEPOT		char(4)		not null,
                SEQ			numeric(14,0)	identity
        )

 CREATE TABLE
    #FRCC
    (
        CCCODE varchar(10) null,
        RCCSEQ NUMERIC(14,0),
        RCCARTICLE CHAR(15),
        RCCDATE DATETIME,
        RCCMOIS TINYINT,
        RCCAN SMALLINT,
        RCCQTE INT,
        RCCCL CHAR(12),
        RCCECH TINYINT,
        RCCFACTMAN TINYINT NULL,
        RCCENT CHAR(5) NULL,
        RCCQTERES INT NULL,
        RCCDATERESFIN SMALLDATETIME NULL,
        RCCDEPOTRES CHAR(4) NULL,
        RCCQTEPREP INT NULL,
        RCCLOT CHAR(12) NULL,
        RCCARM1 CHAR(30) NULL,
        CCSTADE_DET int null,
        CC2AO int null,
        CC2SPEC int null
    )


create unique clustered index starlet on #Stock(STEMPAR,STEMPLETTRE,STEMPEMP)

/*FCCL*/
select CCLSEQ,CCLARTICLE,CCLQTE,CCLQTEPREP,CCL_COMMENT_MAG,CCL_LIBSEQ,CCLPAHT,CCLCOLIS,CCLMARCHE,CCLATTACHE,CCLDEPOTRES,CCLDATERESFIN,CCLQTERES,CCLTOTALHT,CCLR3,CCLR2,CCLR1,CCLTOTALHTDEV,CCLPHTDEV,
CCLCOURSDEV,CCLDEV,CCLOFFERT,CCLFACTMAN,CCLECHSPE,CCLTV,CCLLIBRE,CCLPHT,CCLRESTE,CCLDATE,CCLNUM,CCLCODE,CCLENT,CCLCL
into #FCCL
from FCCL 
where CCLCODE=@Commande




/*LISTE ARTICLE*/
select distinct CCLARTICLE
into #LISTE_ARTICLE
from #FCCL

/*FCC*/
select CCCODE,CCMODELIV,CCDEV,CCPY,CCVILLE,CCCP,CCADR2,CCADR1,CCNOM,CCENT,CCBEBLOQUE,CCVALIDE,CCCLIENT
into #FCC
from VIEW_FCC_FCC2 where CCCODE=@Commande



insert into #FRCC
select CCLCODE,RCCSEQ, RCCARTICLE, RCCDATE, RCCMOIS, RCCAN, RCCQTE, RCCCL, RCCECH, RCCFACTMAN, RCCENT, RCCQTERES, RCCDATERESFIN, RCCDEPOTRES, RCCQTEPREP, RCCLOT, RCCARM1 ,CCSTADE_DET,CC2AO, CC2SPEC
from VIEW_FRCC_BLOQUE
where RCCARTICLE in (select CCLARTICLE from #LISTE_ARTICLE)


/*eliminer les lignes de reservation dans les autres depot que DET*/
delete from #FRCC where isnull(RCCDEPOTRES,'')<>@Depot and isnull(RCCDEPOTRES,'')<>''

/*eliminer aussi les reservation pour des commande AO et SPEC pour les commande en attente prepa*/
delete from #FRCC where (CC2SPEC=1 or CC2AO=1) and CCSTADE_DET=3




/*FSTEMP*/
select STEMPAR, STEMPLETTRE, STEMPDEPOT, STEMPEMP, STEMPQTE, STEMPDATE, STEMPLOT, STEMPUSERCRE, STEMPDATECRE, STEMPUSERMDF, STEMPDATEMDF, STEMPID
into #FSTEMP
from VIEW_FSTEMP,FDP,#LISTE_ARTICLE
where STEMPAR=CCLARTICLE
and STEMPDEPOT=DPCODE
and DPCENTRAL=1

/*FSTOCK*/
select STAR, STDATEMDF, STLETTRE, STQTE, STDATEENTR, STCOMMENT, STPAHT, STPADEV, STNUMARM1, STNUMARM2, STDEPOT, STDEVISE, STFRAIS, STDERUSER, STDATECRE, STUSERCRE, STFO, STUNITE, STEMP, STID, STLOT, ST_UG, ST_QTE_RSRV
into #FSTOCK
from VIEW_FSTOCK,FDP,#LISTE_ARTICLE
where STAR=CCLARTICLE
and STDEPOT=DPCODE
and DPCENTRAL=1


declare @ar char(20),@detail int,@detailres int,@autreStk int ,@ccllot char(20),@cclseq int,@cclSerie char(25),@ssemp char(10),@emp char(10),@qte int,
@CCLQTE int

declare lesLignes cursor
for select CCLARTICLE,sum(CCLQTE) from #FCCL  group by CCLARTICLE 
open lesLignes
fetch lesLignes into @ar,@qte
while (@@sqlstatus=0)
begin
	/* on recherche le stock total du rayon detail */

        /* on recherche le stock total du rayon detail */
        select @detail=isnull(sum(STQTE ),0)-isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #FSTOCK   where STAR=@ar and STDEPOT=@Depot  
        
	 /* on recherche ensuite le stock reserve pour cet article precis lot/serie */

        select @detailres=0
        select @detailres=isnull(sum(isnull(RCCQTEPREP,0)),0) 
        from #FRCC
        where CCCODE<>@Commande and RCCARTICLE=@ar
        
        --select @detailres

        select @emp=max(STEMPEMP) from FSTEMP where STEMPDEPOT=@Depot and  STEMPQTE>0 and STEMPAR=@ar 
   
        select @autreStk=isnull(sum(STQTE ),0)-isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #FSTOCK
        where STAR=@ar and STDEPOT<>@Depot

	select @ssemp=ARESSEMP from VIEW_FARE where AREDEPOT=@Depot and AREEMP=@emp and AREAR=@ar 
	

        --select @CCLQTE=sum(CCLQTE-isnull(CCLQTEEXP,0)) from #FCCL where  CCLARTICLE=@ar
        
        select @CCLQTE=sum(CCLQTE-isnull(CCLQTEPREP,0)) from #FCCL where  CCLARTICLE=@ar
        
        
        insert into #ccl2
        select @Commande,@ar,ARLIB,ARLIBXENO,ARFO,@CCLQTE,@emp,@detail-@detailres, 0,'',@autreStk ,'',@ssemp
        from VIEW_FAR
        where ARCODE=@ar 
	
 
    fetch lesLignes into @ar,@qte
end
close lesLignes
deallocate cursor lesLignes 

	/* recherche stockl */


if (@UntilDate is null)
begin
	insert into #Prep
	select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
	substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
	ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
	isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
	isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,'')
	from #FCCL,FAR,#FCC,#FRCC
	where CCLSEQ=RCCSEQ
	and RCCCL=@Client
	and RCCARTICLE=ARCODE
	and #FCC.CCCODE=CCLCODE
	and (@Commande is null or CCLCODE=@Commande)
	and ARNUMEROTE=0
	and isnull(CCVALIDE,0)=0
	and isnull(CCBEBLOQUE,0)=0
	and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	and (isnull(@nom,'') = '' or CCNOM = @nom)
	and (isnull(@adr1,'') = '' or CCADR1 = @adr1)
	and (isnull(@adr2,'') = '' or CCADR2 = @adr2)
	and (isnull(@cp,'') = '' or CCCP = @cp)
	and (isnull(@ville,'') = '' or CCVILLE = @ville)
	and (isnull(@py,'') = '' or CCPY = @py)
	and (isnull(@devise,'') = '' or CCDEV = @devise)
	order by RCCDATE,RCCSEQ
end
else
begin
	insert into #Prep
	select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,ARUNITFACT,CCLPHT,
	substring(CCMODELIV,1,2),CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,isnull(CCLOFFERT,0),
	ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
	isnull(CCLQTERES,0),CCLDATERESFIN,isnull(CCLDEPOTRES,''),ARCOMP,isnull(CCLQTEPREP,0),
	isnull(CCLATTACHE,''),ARREFFOUR,CCLMARCHE,isnull(CCLCOLIS,0),isnull(ARQTECOLIS,0),isnull(CCLPAHT,0),CCL_LIBSEQ,isnull(CCL_COMMENT_MAG,'')
	from #FCCL,FAR,#FCC,#FRCC
	--from FCCL,FAR,FCC,FRCC
	where CCLSEQ=RCCSEQ
	and RCCCL=@Client
	/*and RCCDATE<=@UntilDate*/
	and RCCARTICLE=ARCODE
        and CCLCL=CCCLIENT
	and #FCC.CCCODE=CCLCODE
	and (@Commande is null or CCLCODE=@Commande)
	and ARNUMEROTE=0
	and isnull(CCVALIDE,0)=0
	and isnull(CCBEBLOQUE,0)=0
	and CCLRESTE-(isnull(CCLQTEPREP,0)) > 0
	and (@ent is null or (CCLENT=@ent and CCENT=@ent and RCCENT=@ent))
	and (isnull(@nom,'') = '' or CCNOM = @nom)
	and (isnull(@adr1,'') = '' or CCADR1 = @adr1)
	and (isnull(@adr2,'') = '' or CCADR2 = @adr2)
	and (isnull(@cp,'') = '' or CCCP = @cp)
	and (isnull(@ville,'') = '' or CCVILLE = @ville)
	and (isnull(@py,'') = '' or CCPY = @py)
	and (isnull(@devise,'') = '' or CCDEV = @devise)

	order by RCCDATE,RCCSEQ
end
insert into #Articles (CCLARTICLE,ARTYPE)
select distinct CCLARTICLE,ARTYPE from #Prep

create unique clustered index article on #Articles(CCLARTICLE)

declare		@CCLSEQ			int,
			@CCLCODE		char(10),
			@CCLNUM			int,
			@CCLDATE		datetime,
			@CCLARTICLE		char(15),
			@CCLRESTE		int,
			@ARLIB			varchar(80),
			@ARUNITFACT		tinyint,
			@PUHT			numeric(14,2),
			@MODELIV		char(2),
			@CCLLIBRE		varchar(255),
			@CCLTV			char(4),
			@ARREGLE		tinyint,
			@CCLECHSPE		tinyint,
			@CCLFACTMAN		tinyint,
			@CCLOFFERT		tinyint,
			@ARTYPE			tinyint,
			@CCLDEV			char(3),
			@CCLCOURSDEV	numeric(16,10),
			@CCLPHTDEV		numeric(14,2),
			@CCLTOTALHTDEV	numeric(14,2),
			@CCLR1			real,
			@CCLR2			real,
			@CCLR3			real,
			@CCLTOTALHT		numeric(14,2),
			@CCLQTERES		int,
			@CCLDATERESFIN	smalldatetime,
			@CCLDEPOTRES	char(4),
			@ARCOMP			tinyint,
			@CCLQTEPREP		int,
			@CCLATTACHE		char(10),
			@ARREFFOUR		char(20),
			@CCLMARCHE		char(12),
			@CCLCOLIS		numeric(14,2),
			@ARQTECOLIS		int,
			@CCLPAHT		numeric(14,2),
                        @CCL_LIBSEQ numeric(18,0),
                        @CCL_COMMENT_MAG varchar(255)

set forceplan on 

/*OPHAM POUR RASSURER QU IL nya pas de B qui bloque les Bon de Preparation*/ 

/*inserer dans la table #FRBP*/


/*select RBPARTICLE,RBPDEPOT,RBPLETTRE,RBPEMP,sum(RBPQTE) as RBPQTE
into #FRBP
from VIEW_FRBP_DEPOT_LETTRE
where RBPARTICLE in (select CCLARTICLE from #LISTE_ARTICLE) 
*/
select RBPARTICLE,RBPDEPOT,RBPLETTRE,sum(RBPQTE) as RBPQTE
into #FRBP
from FRBP
where RBPARTICLE in (select CCLARTICLE from #LISTE_ARTICLE) 
group by RBPARTICLE,RBPDEPOT,RBPLETTRE

--delete from #FRBP where RBPDEPOT<>@Depot


create table #StockTmp1(
        STEMPAR varchar(50) null,
        STEMPLETTRE varchar(4) null,
        QteLoc int null,
        STEMPDATE smalldatetime null,
        STEMPEMP varchar(10) null,
        STEMPLOT varchar(50) null,
        STEMPDEPOT varchar(20) null       
)


/*ARTICLE STOCKE*/
insert into  #StockTmp1
select STEMPAR,STLETTRE ,sum(STEMPQTE),NLOTDATEPER ,STEMPEMP,STLOT ,STEMPDEPOT
from VIEW_STOCK_LOT_EMPLACEMENT
where STEMPAR in (select CCLARTICLE from #Articles where ARTYPE=0 ) 
and STEMPDEPOT=@Depot
group by STEMPAR,STLETTRE,NLOTDATEPER,STEMPEMP,STLOT,STEMPDEPOT


/*supprimer les resrvation FRBP*/
 update #StockTmp1 set QteLoc=QteLoc-RBPQTE
 from #StockTmp1,#FRBP
 where STEMPAR=RBPARTICLE
 and STEMPDEPOT=RBPDEPOT
 and STEMPLETTRE=RBPLETTRE
 --and STEMPEMP=RBPEMP
 
 /*supprimer les ligne de stock avec qte<=0 suite à des diverse reservation*/
delete from #StockTmp1 where QteLoc<=0

/*ARTICLE NON STOCKE*/
insert into  #StockTmp1(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
select STEMPAR,STEMPLETTRE,STEMPQTE,null,STEMPEMP,'',STEMPDEPOT
from FSTEMP,#Articles
where STEMPAR=CCLARTICLE
and STEMPDEPOT= @Depot
and ARTYPE>0



insert into #Stocktmp (STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT)
select STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT from #StockTmp1
order by STEMPAR,STEMPDATE



/*enlever les stock dejà reservé dans la table FSTOCK pour cette article et lettre + depot*/

        declare 	@qteST 			int,
                        @articleST 		char(15),
                        @lettreST 		char(4),
                        @qtealivrer		int,
                        @emplacement	char(8),
                        @lot			char(12),
                        @depot			char(4),
                        @seq			numeric(14,0),
                        @resteapreparer	int,
                        @stockRSRV_FSTOCK int,@datePer datetime
                
        
        declare stockTmp cursor for select STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT from #Stocktmp order by SEQ 
        open stockTmp
        fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot
        while (@@sqlstatus=0)
        begin
                select @stockRSRV_FSTOCK=0
                select @stockRSRV_FSTOCK=isnull(sum(isnull(ST_QTE_RSRV,0) ),0) from #FSTOCK /*VIEW_FSTOCK*/ where STAR=@articleST and STDEPOT=@depot and STLETTRE= @lettreST
                select @qteST=@qteST-@stockRSRV_FSTOCK
                insert into #Stock(STEMPAR,STEMPLETTRE,QteLoc,STEMPDATE,STEMPEMP,STEMPLOT,STEMPDEPOT) values (@articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot)
                
                 fetch stockTmp into @articleST,@lettreST,@qteST,@datePer,@emplacement,@lot,@depot 
        end
        close stockTmp
        deallocate cursor stockTmp

        drop table #Stocktmp
        delete from #Prep where not exists (select * from #Stock where STEMPAR=#Prep.CCLARTICLE)
 
declare commandes cursor for
select CCLSEQ,CCLCODE,CCLNUM,CCLDATE,CCLARTICLE,CCLRESTE,ARLIB,
ARUNITFACT,CCLPHT,MODELIV,CCLLIBRE,CCLTV,ARREGLE,CCLECHSPE,CCLFACTMAN,CCLOFFERT,
ARTYPE,CCLDEV,CCLCOURSDEV,CCLPHTDEV,CCLTOTALHTDEV,CCLR1,CCLR2,CCLR3,CCLTOTALHT,
CCLQTERES,CCLDATERESFIN,CCLDEPOTRES,ARCOMP,CCLQTEPREP,CCLATTACHE,ARREFFOUR,CCLMARCHE,CCLCOLIS,ARQTECOLIS,CCLPAHT,CCL_LIBSEQ,CCL_COMMENT_MAG
from #Prep
order by CCLDATE,CCLSEQ
for read only

open commandes
fetch commandes
into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV ,
@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG


while (@@sqlstatus = 0)
begin
        
                        select @resteapreparer = @CCLRESTE-@CCLQTEPREP
                        select @stocktotal= isnull(sum(QteLoc),0) from #Stock where STEMPAR=@CCLARTICLE and STEMPDEPOT=@Depot
                
                        /*stocker dans une table tmp le stock*/
                        select #Stock.STEMPAR, #Stock.STEMPLETTRE, #Stock.QteLoc, #Stock.STEMPDATE, #Stock.STEMPEMP, #Stock.STEMPLOT, #Stock.STEMPDEPOT, #Stock.SEQ  into #stockTmp
                        from #Stock 

                        /*parcoourir la ligne de stock*/
                        declare ligneStock cursor for select STEMPAR,STEMPLETTRE,QteLoc,STEMPEMP,STEMPLOT,STEMPDEPOT,SEQ from #stockTmp where STEMPAR=@CCLARTICLE and STEMPDEPOT=@Depot order by SEQ
                        open ligneStock
                        fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                        while (@@sqlstatus=0)
                        begin
                                if(@ARTYPE<>0)
                                begin
                                        select @qtealivrer=@resteapreparer
                                        select @resteapreparer=0
                                end
                                else
                                begin
                                        if(@qteST>=@resteapreparer)/*QTE ligne de stock peut honorer la quantité a preparer*/
                                        begin
                                                select @qtealivrer=@resteapreparer
                                                update #Stock set QteLoc=QteLoc-@qtealivrer where SEQ = @seq
                                                select @resteapreparer=0
                                        end
                                        else 
                                        begin
                                                select @qtealivrer=@qteST/*quantité a lvrer = qte en stock*/
                                                update #Stock set QteLoc=0 where SEQ = @seq
                                                select @resteapreparer= @resteapreparer-@qtealivrer
        
                                        end
                                  end      
                                        
                                        insert into #Liste (Article,Lettre,Designation,LienCode,LienNum,Qte,
                                                                                  UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,
                                                                                  Reglement,Echeancesp,Factman,Offert,Artype,
                                                                                  Devise,Coursdev,PrixHTdev,TotHTdev,Rem1,Rem2,Rem3,
                                                                                  TotPrixHT,Emplacement,Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,seqLib,comment_mag)
                                        select @articleST,@lettreST,@ARLIB,@CCLCODE,@CCLNUM,@qtealivrer,
                                                                                  @ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,
                                                                                  @CCLTV,@ARREGLE,@CCLECHSPE,@CCLFACTMAN,@CCLOFFERT,@ARTYPE,
                                                                                  @CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,@CCLR1,@CCLR2,@CCLR3,
                                                                                  @CCLTOTALHT,@emplacement,@CCLATTACHE,@lot,@ARREFFOUR,@CCLMARCHE,@CCLDATE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG
                                
                                if @resteapreparer<=0 break
                                
                                fetch ligneStock into @articleST,@lettreST,@qteST,@emplacement,@lot,@depot,@seq
                        end
                        close ligneStock
                        deallocate cursor ligneStock
                    
        
        /*FIN NEW*/     --delete from #Stock where SEQ=@seq
                        drop table #stockTmp

	fetch commandes
	into @CCLSEQ,@CCLCODE,@CCLNUM,@CCLDATE,@CCLARTICLE,@CCLRESTE,@ARLIB,
	@ARUNITFACT,@PUHT,@MODELIV,@CCLLIBRE,@CCLTV,@ARREGLE,@CCLECHSPE,
	@CCLFACTMAN,@CCLOFFERT,@ARTYPE,@CCLDEV,@CCLCOURSDEV,@CCLPHTDEV,@CCLTOTALHTDEV,
	@CCLR1,@CCLR2,@CCLR3,@CCLTOTALHT,@CCLQTERES,@CCLDATERESFIN,@CCLDEPOTRES,@ARCOMP,
	@CCLQTEPREP,@CCLATTACHE,@ARREFFOUR,@CCLMARCHE,@CCLCOLIS,@ARQTECOLIS,@CCLPAHT,@CCL_LIBSEQ,@CCL_COMMENT_MAG
end

close commandes
deallocate cursor commandes

delete from #Liste
where Artype=4
and not exists (select * from #Liste as b where #Liste.LienCode=b.LienCode and b.Artype <> 4)
and not exists (select * from FCCL,FAR where CCLCODE=#Liste.LienCode and ARCODE=CCLARTICLE and CCLRESTE > 0 and (ARNUMEROTE=1 or ARCOMP=2))

/*LISTE PREPARATION*/
select Article,Lettre,rtrim(Designation) as Designation,LienCode,LienNum,Qte,
	   UnitFact,PrixHT,ModeLiv,LigneLibre,TypeVente,Reglement,
	   Echeancesp,abs(Qte),Factman,isnull(Offert,0),isnull(Artype,0),
	   isnull(Devise,''),isnull(Coursdev,0),isnull(PrixHTdev,0),
	   isnull(TotHTdev,0),Rem1,Rem2,Rem3,TotPrixHT,Emplacement,
	   Attachement,Lot,Arreffour,cclmarche,ccldate,cclcolis,arqtecolis,cclpaht,'',0,0,0,0,0,0,'','','',0,'','',0,'','','',0,0,0,seqLib,comment_mag
from #Liste
where Qte > 0
order by LienCode,LienNum


select Article,sum(Qte) as Qte
into #listeFinal
from #Liste
group by Article

select CCLARTICLE,sum(CCLRESTE-(isnull(CCLQTEPREP,0))) as CCLQTE
into #CCLInit
from FCCL
where CCLCODE=@Commande
group by CCLARTICLE


select CCLARTICLE,CCLQTE,Qte
into #reliquat
from #CCLInit,#listeFinal
where CCLARTICLE*=Article

delete from #reliquat where isnull(CCLQTE,0)=isnull(Qte,0)
/*POUR LE BESOIN D APPRO DETAIL*/

create table #Appro (LIB char(255) null,CCLQTE int null,STRESTE int null,STDEPOT char(10) null,STEMPEMP char(10) null, STEMPQTE int null, CCLSEQ int null)

create table #Appro2(
        ARTICLE varchar(50) null,
        LIB varchar(255) null,
        CCLQTE int null,
        STREQTE int null,
        STDEPOT varchar(20) null,
        STEMPQTE int null
        
)
insert into #Appro2
select STEMPAR,rtrim(ARLIB),
CCLQTE,STRESQTE,STDEPOT,'QTE'=sum(STEMPQTE)
from #ccl2,#FSTOCK,#FSTEMP--VIEW_FSTEMP
where STRESQTE<CCLQTE
and STEMPAR=CCLARTICLE
and STEMPAR=STAR
and STEMPLETTRE=STLETTRE
and STEMPDEPOT<>@Depot and  STDEPOT=STEMPDEPOT
--and DPCENTRAL=1 
group by STEMPAR,rtrim(ARLIB),CCLQTE,STRESQTE,STDEPOT

/*verifier si cette table possede des enregistrement */

declare @nombre int,@dateAttenteTransfert datetime, @xSeq int,@datejour datetime
select @nombre =count(*) from #Appro2
if(@nombre>0)
begin
        select @dateAttenteTransfert=CCATTETRANSFERT from FCC where CCCODE=@Commande
        if (@dateAttenteTransfert=null)
        begin
                update FCC set  CCATTETRANSFERT=getdate() where CCCODE=@Commande
                
                declare appro cursor for select CCLSEQ from FCCL where CCLARTICLE in (select distinct ARTICLE from #Appro2) and CCLCODE=@Commande
                open appro
                fetch  appro into  @xSeq
                while (@@sqlstatus=0)
                begin
                        insert into xFCCL (xSeq,xDateAtteTransfert) values (@xSeq,getdate()) 
                        fetch  appro into  @xSeq
                end
                close appro 
                deallocate cursor appro
        end

end
/*pour les article en attente de transfert*/
 select  #Appro2.LIB, #Appro2.CCLQTE, #Appro2.STREQTE, #Appro2.STDEPOT,AREEMP, #Appro2.STEMPQTE,0 
 from #Appro2,VIEW_FARE 
 where ARTICLE*=AREAR
 and STDEPOT*=AREDEPOT
 and AREPICK=1
 
 /*pour la gestion des reliquat*/
 select CCLARTICLE,ARLIB, CCLQTE, isnull(Qte,0) 
 from #reliquat,VIEW_FAR
 where ARCODE=CCLARTICLE
 
 
/*pour les articles qui n ont pas d emplacement*/
select   CCLARTICLE, VIEW_FAR.ARLIB,   AREEMP, ARESSEMP 
        from #ccl2,VIEW_FAR
        where ARCODE=CCLARTICLE
        and isnull(ARESSEMP,'')=''
        and ARTYPE=0

drop table #Prep
drop table #Articles
drop table #Stock
drop table #Liste

drop table #Appro
drop table #Appro2
drop table #ccl2
drop table #ccl
drop table #FCCL
drop table #LISTE_ARTICLE
drop table #FCC
drop table  #FRCC
drop table #FSTEMP
drop table #FSTOCK

drop table  #FRBP
drop table #StockTmp1
drop table  #reliquat



end
go

