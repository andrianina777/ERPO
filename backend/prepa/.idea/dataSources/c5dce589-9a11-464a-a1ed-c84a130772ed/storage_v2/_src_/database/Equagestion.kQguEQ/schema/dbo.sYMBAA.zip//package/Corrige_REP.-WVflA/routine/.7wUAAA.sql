



create procedure Corrige_REP (@ent		char(5)	= null,
							  @rep_old	char(8),
							  @rep_new	char(8)
							  )
with recompile
as
begin

declare @labase		varchar(30)
select  @labase = db_name()

dump tran @labase with truncate_only

select "Commandes FCC : "

update FCC
set CCREPRES=@rep_new
where CCREPRES=@rep_old
and (@ent is null or CCENT=@ent)

dump tran @labase with truncate_only

select "Lignes de Commandes FCCL : "

update FCCL
set CCLREP=@rep_new
where CCLREP=@rep_old
and (@ent is null or CCLENT=@ent)

dump tran @labase with truncate_only

select "Factures FFA : "

update FFA
set FAREP=@rep_new
where FAREP=@rep_old
and (@ent is null or FAENT=@ent)

dump tran @labase with truncate_only

select "Lignes Factures FFAL : "

update FFAL
set FALREP=@rep_new
where FALREP=@rep_old
and (@ent is null or FALENT=@ent)

dump tran @labase with truncate_only

select "Clients FCL : "

update FCL
set CLREP=@rep_new
where CLREP=@rep_old
and (@ent is null or CLENT=@ent)

dump tran @labase with truncate_only

end



go

