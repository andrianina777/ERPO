/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_BlocageHopito
grant execute on bp_BlocageHopito to public
*/

CREATE PROCEDURE dbo.bp_BlocageHopito(
		@codeClient char(25),
		@codeArticle char(30))
with recompile
AS
begin
	 declare @count int		 
 	 
 	 select @count=count(*) from VIEW_FAR where isnull(xARTP_STATSPEC,0)=3 and ARCODE=@codeArticle

 	 if(@count>0)
 		begin
 			select case when isnull(SA_HOPITO,0)=1 then 0 else 1 end  from FSA inner join FCL on CLSA=SACODE where  CLCODE=@codeClient
 		end
end
go

