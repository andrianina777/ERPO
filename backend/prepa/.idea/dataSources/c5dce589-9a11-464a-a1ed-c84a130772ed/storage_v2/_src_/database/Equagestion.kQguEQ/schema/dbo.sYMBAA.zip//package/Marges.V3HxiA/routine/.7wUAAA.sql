
create procedure Marges (@ent			char(5)		= null,   
						 @an			smallint,   
						 @moisdeb		tinyint,   
						 @moisfin		tinyint,   
						 @chefprod		char(8) 	= null,   
						 @depart		char(8) 	= null,   
						 @marque		char(12) 	= null,   
						 @famille		char(8) 	= null,   
						 @categorie		char(8) 	= null,   
						 @article		char(15) 	= null,   
						 @client		char(12) 	= null,   
						 @centrale		char(12) 	= null,   
						 @repcentral	char(8) 	= null,   
						 @repdivision	char(8) 	= null,   
						 @produits		smallint 	= 0,   
						 @prodnsto		smallint 	= 1,   
						 @services		smallint 	= 2,   
						 @ports			smallint 	= 3,   
						 @comments		smallint 	= 4,   
						 @remises		smallint 	= 5,   
						 @rfa			smallint 	= 6,   
						 @assur			smallint 	= 7,   
						 @nostats		smallint 	= 8,	/* Ne devrait pas faire partie du traitement - pas ajoute dans le select */   
						 @modevalo		tinyint  	= 0,	/* 0 = FIFO, 1 = PRM Global, 2 = PUMP, 3 = PRM Mensuel, 4 = DPA unitaire, 5 = PA unitaire HT	*/   
						 @facture		char(10) 	= null,   
						 @article_groupe	char(16) = null,  
						 @datedeb		smalldatetime = null,  
						 @datefin		smalldatetime = null,  
						 @clsa			char(6)	 	= null,  
						 @matiere		char(14)	= null,  
						 @couleur		char(8)		= null,  
						 @grille		char(10)	= null, 
						 @calibre		char(14)	= null,  
						 @foreign1		char(12)	= null,  
						 @foreign2		char(12)	= null, 
						 @offert		tinyint		= null, 
						 @clclasse		char(10) 	= null, 
						 @axe			char(12)	= null, 
						 @section		char(12)	= null,
						 @clgroupe1	char(8)	= null,
						 @clgroupe2	char(8)	= null,
						 @clgroupe3	char(8)	= null,						 
						 @departgeo		char(12) 	= null,
						 @arproduit		char(15)	= null,
						 @aremp			char(16) 	= null)					 
						 
						    
with recompile   
as   
begin   
  
/* --------- Version du 250408 ----------- */

set arithabort numeric_truncation off   
   
select @departgeo=@departgeo+"%"  
   
declare	@date1			smalldatetime,   
		@date2			smalldatetime   
  
  
if (@datedeb is null)  
begin  
	select @date1=convert(datetime,convert(char(2),@moisdeb)+"/01/"+convert(char(4),@an))   
	select @date2=convert(datetime,convert(char(2),@moisfin)+"/01/"+convert(char(4),@an))   
	select @date2=dateadd(mm,1,@date2)   
	select @date2=dateadd(dd,-1,@date2)  
end  
else  
begin  
	select @date1=@datedeb  
	select @date2=@datefin		  
end  
   
create table #Final   
(   
SEQ			int		not null   
)   
   
delete from FMGT where MGTSPID=@@spid   
   
     
			/*------------ Lignes de factures avec code stock ---------------------------------------------*/   
   
  insert into #Final (SEQ)   
  select FALSEQ   
  from FFAL,FAR,FCL,FFA 
  where ARCODE=FALARTICLE  
  and FACODE=FALCODE 
  and CLCODE=FACL  
  and FALDATE between @date1 and @date2   
  and isnull(FALLETTRE ,"") != ""   
  and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)   
  and (@chefprod is null or ARCHEFP = @chefprod)   
  and (@depart is null or ARDEPART = @depart)   
  and (@marque is null or ARFO = @marque)   
  and (@famille is null or ARFAM = @famille)   
  and (@categorie is null or ARGRFAM = @categorie)   
  and (@article is null or ARCODE = @article)   
  and (@client is null or FALCL = @client)   
  and (@centrale is null or FALGROUPE = @centrale)   
  and (@repcentral is null or FALREP = @repcentral)   
  and (@repdivision is null or FALREPDIV = @repdivision)   
  and (@ent is null or FALENT=@ent)   
  and (@facture is null or FALCODE = @facture)   
  and (@article_groupe is null or ARREGROUPE = @article_groupe) 
    
  and (@clsa is null or CLSA = @clsa) 
  and (@clclasse is null or CLCLASSE = @clclasse)
  and (@departgeo is null or CLCP like @departgeo) 
  and (@clgroupe1 is null or CLGROUPE1 = @clgroupe1) 
  and (@clgroupe2 is null or CLGROUPE2 = @clgroupe2) 
  and (@clgroupe3 is null or CLGROUPE3 = @clgroupe3) 
     
  and (@matiere is null or ARMATIERE = @matiere)  
  and (@couleur is null or ARCOULEUR = @couleur)  
  and (@grille is null or ARGRILLE = @grille)  
  and (@calibre is null or ARCALIBRE = @calibre)  
  and (@foreign1 is null or ARFOREIGN1 = @foreign1)  
  and (@foreign2 is null or ARFOREIGN2 = @foreign2) 
  and (@arproduit is null or ARPRODUIT = @arproduit)   
  and (@aremp is null or AREMP = @aremp)
  
  and (@offert is null or isnull(FALTOTALHT,0)!=0) 
   
  create unique index seq on #Final (SEQ)   
     
  declare  
  		@date				smalldatetime,   
		  @articlepr		char(15),   
		  @qte				int,   
		  @totalht			numeric(14,2),   
		  @cvlot			int,   
		  @PrixRevient		numeric(14,4),   
		  @PrixRevientLigne	numeric(14,2),   
		  @seq				int,   
		  @lettre			char(4),   
		  @arprm			numeric(14,4),   
		  @facode			char(10) ,
		  @falfrais			numeric(14,2),
		  @falpaht			numeric(14,2) 				 
   
     
  declare factures cursor    
  for select SEQ,dateadd(hh,19,FALDATE),FALARTICLE,FALQTE,FALTOTALHT,CVLOT,FALLETTRE,isnull(ARPRM,0),FALCODE,isnull(FALFRAIS,0),isnull(FALPAHT,0)   
  from #Final,FFAL,FAR,FCV   
  where FALSEQ=SEQ   
  and ARCODE=FALARTICLE   
  and ARUNITACHAT=CVUNIF   
  order by SEQ   
  for read only   
   
	   
	open factures   
	   
	fetch factures   
	into @seq,@date,@articlepr,@qte,@totalht,@cvlot,@lettre,@arprm,@facode,@falfrais,@falpaht
	   
	while (@@sqlstatus = 0)   
		begin   
		select 	@PrixRevient = 0,   
				@PrixRevientLigne = 0   
		   
		if @modevalo = 0										/*--------------------- FIFO */   
		begin   
		   
		  select @PrixRevient = round((STPAHT+STFRAIS)/@cvlot,4)   
		  from FSTOCK   
		  where STAR=@articlepr   
		  and STLETTRE=@lettre   
		   
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais
		end   
		else if @modevalo = 1									/*--------------------- PRM */   
		begin   
		  select @PrixRevientLigne = convert(numeric(14,2),@arprm * @qte) + @falfrais 
		end   
		else if @modevalo = 2									/*--------------------- PUMP */   
		begin   
		  select @PrixRevient=isnull(PUMP,0)   
		  from FPUM   
		  where PUMAR = @articlepr   
		  and PUMDATE <= convert (smalldatetime, @date)   
		  having PUMAR = @articlepr   
		  and PUMDATE <= convert (smalldatetime, @date)   
		  and PUMDATE = max(PUMDATE)   
		     
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais   
		end   
		else if @modevalo = 3								/*--------------------- PRM Mensuel */   
		begin   
		  set rowcount 1   
		     
		  select @PrixRevient=isnull(PRM,0)   
		  from FPRM   
		  where PRMAR = @articlepr   
		  and ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))   
		  having ((PRMAN = datepart(yy,@date) and PRMMOIS <= datepart(mm,@date)) or PRMAN < datepart(yy,@date))   
		  and PRMAR = @articlepr   
		  order by PRMAN desc,PRMMOIS desc   
		     
		  set rowcount 0   
		     
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais			   
		end   
		else  if @modevalo = 4								/*--------------------- DPA unitaire */   
		begin   
		  set rowcount 1   
		     
		  select @PrixRevient = round((BLLPAHT+BLLFRAIS)/@cvlot,4)   
		  from FBLL   
		  where BLLAR=@articlepr   
		  having BLLAR=@articlepr   
		  and BLLLET = ltrim(max(case when charindex(' ',BLLLET) <> 0 then (' '+BLLLET) else BLLLET end))   
		   
		  if isnull(@PrixRevient,0)=0   
		  begin   
			select @PrixRevient = round((SILPAHT+SILFRAIS)/@cvlot,4)   
			from FSIL   
			where SILARTICLE=@articlepr   
			having SILARTICLE=@articlepr   
			and SILLETTRE = ltrim(max(case when charindex(' ',SILLETTRE) <> 0 then (' '+SILLETTRE) else SILLETTRE end))   
		  end   
   
		  set rowcount 0   
		     
		  if @PrixRevient is null   
		    select @PrixRevient = 0   
   
		  select @PrixRevientLigne = convert(numeric(14,2),@PrixRevient * @qte) + @falfrais		   
		end   
		else if @modevalo = 5									/*--------------------- PA Unitaire HT */   
		begin
			select @PrixRevient = @falpaht   
		  select @PrixRevientLigne = convert(numeric(14,2),@falpaht * @qte) 
		end   
   
   
		insert into FMGT (MGTCHEFP,MGTDEPART,MGTMARQUE,MGTFAM,MGTARTICLE,MGTLIB,MGTCL,   
						MGTREP,MGTREPDIV,MGTGROUPE,MGTQTE,MGTTOTALHT,MGTPR,MGTMARGE,MGTSPID,MGTCODE, 
						MGTGRFAM,MGTSA,MGTREGION,MGTPAYS,MGTCLASSE,MGTCOMPTE,
						MGTPRODUIT,MGTAREMP,MGTARMATIERE,MGTARCOULEUR,
						MGTARGRILLE,MGTARCALIBRE,MGTARFOREIGN1,MGTARFOREIGN2,
						MGTCP,MGTCLGROUPE1,MGTCLGROUPE2,MGTCLGROUPE3)
		select isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),   
					isnull(FALARTICLE,""),isnull(ARLIB,""),isnull(FALCL,""),isnull(FALREP,""),   
					isnull(FALREPDIV,""),isnull(FALGROUPE,""),FALQTE,isnull(FALTOTALHT,0),   
					@PrixRevientLigne,isnull(FALTOTALHT,0) - @PrixRevientLigne,@@spid,@facode, 
					isnull(ARGRFAM,''),isnull(CLSA,''),isnull(CLREGION,''),isnull(CLPAYS,''),isnull(CLCLASSE,''),
					isnull((case when CLSANSTVA=0 then TVLCPT else TVLCPTSANSTVA end),''),
					isnull(ARPRODUIT,""),isnull(AREMP,""),isnull(ARMATIERE,""),isnull(ARCOULEUR,""),
					isnull(ARGRILLE,""),isnull(ARCALIBRE,""),isnull(ARFOREIGN1,""),isnull(ARFOREIGN2,""),
					"",isnull(CLGROUPE1,""),isnull(CLGROUPE2,""),isnull(CLGROUPE3,"")
		from FFAL,FAR,FFA,FCL,FTVL  
		where FALSEQ=@seq   
		and FALARTICLE=ARCODE   
		and FALCODE=FACODE 
		and FACLFACT=CLCODE 
		and FALTYPEVE=TVLCODE and CLCLASSE=TVLCLASSE 
		and (@section is null or exists (select * from FCLAX where FCL.CLCODE=CLAXCLE and (@ent is null or CLAXENT=@ent) and CLAXAX=@axe and CLAXSECTION=@section)) 
	   
	   
		fetch factures   
		into @seq,@date,@articlepr,@qte,@totalht,@cvlot,@lettre,@arprm,@facode,@falfrais,@falpaht
		   
	end   
   
	close factures   
	deallocate cursor factures   
   
   
			/*------------ Lignes de factures sans code stock ---------------------------------------------*/   
  			   
	insert into FMGT (MGTCHEFP,MGTDEPART,MGTMARQUE,MGTFAM,MGTARTICLE,MGTLIB,MGTCL,   
					MGTREP,MGTREPDIV,MGTGROUPE,MGTQTE,MGTTOTALHT,MGTPR,MGTMARGE,MGTSPID,MGTCODE, 
					MGTGRFAM,MGTSA,MGTREGION,MGTPAYS,MGTCLASSE,MGTCOMPTE,
						MGTPRODUIT,MGTAREMP,MGTARMATIERE,MGTARCOULEUR,
						MGTARGRILLE,MGTARCALIBRE,MGTARFOREIGN1,MGTARFOREIGN2,
						MGTCP,MGTCLGROUPE1,MGTCLGROUPE2,MGTCLGROUPE3)   
	select isnull(ARCHEFP,""),isnull(ARDEPART,""),isnull(ARFO,""),isnull(ARFAM,""),   
					isnull(FALARTICLE,""),isnull(ARLIB,""),isnull(FALCL,""),isnull(FALREP,""),   
					isnull(FALREPDIV,""),isnull(FALGROUPE,""),0,isnull(FALTOTALHT,0),0,   
					isnull(FALTOTALHT,0),@@spid,isnull(FALCODE,"")  , 
					isnull(ARGRFAM,''),isnull(CLSA,''),isnull(CLREGION,''),isnull(CLPAYS,''),isnull(CLCLASSE,''),
					isnull((case when CLSANSTVA=0 then TVLCPT else TVLCPTSANSTVA end),''),
					isnull(ARPRODUIT,""),isnull(AREMP,""),isnull(ARMATIERE,""),isnull(ARCOULEUR,""),
					isnull(ARGRILLE,""),isnull(ARCALIBRE,""),isnull(ARFOREIGN1,""),isnull(ARFOREIGN2,""),
					"",isnull(CLGROUPE1,""),isnull(CLGROUPE2,""),isnull(CLGROUPE3,"")
	from FFAL,FAR ,FFA,FCL,FTVL  
	where ARCODE=FALARTICLE  
  	and FALCODE=FACODE 
	and FACLFACT=CLCODE 
	and FALTYPEVE=TVLCODE and CLCLASSE=TVLCLASSE  
	and (@section is null or exists (select * from FCLAX where FCL.CLCODE=CLAXCLE and (@ent is null or CLAXENT=@ent) and CLAXAX=@axe and CLAXSECTION=@section)) 
	 
	and FALDATE between @date1 and @date2   
	and isnull(FALLETTRE,"") = ""   
	and ARTYPE in (@produits, @prodnsto, @services, @ports, @comments, @remises, @rfa, @assur)  
	  
	and (@chefprod is null or ARCHEFP = @chefprod)   
	and (@depart is null or ARDEPART = @depart)   
	and (@marque is null or ARFO = @marque)   
	and (@famille is null or ARFAM = @famille)   
	and (@categorie is null or ARGRFAM = @categorie)   
	and (@article is null or ARCODE = @article) 
	   
	and (@client is null or FALCL = @client)   
	and (@centrale is null or FALGROUPE = @centrale)   
	and (@repcentral is null or FALREP = @repcentral)   
	and (@repdivision is null or FALREPDIV = @repdivision)   
	and (@ent is null or FALENT=@ent)  
  and (@facture is null or FALCODE = @facture)   
  and (@article_groupe is null or ARREGROUPE = @article_groupe) 
    
 	and (@clsa is null or CLSA = @clsa)  
 	and (@clclasse is null or CLCLASSE = @clclasse)
 	and (@departgeo is null or CLCP like @departgeo)
 	and (@clgroupe1 is null or CLGROUPE1 = @clgroupe1) 
  and (@clgroupe2 is null or CLGROUPE2 = @clgroupe2) 
  and (@clgroupe3 is null or CLGROUPE3 = @clgroupe3)   
    
	and (@matiere is null or ARMATIERE = @matiere)  
	and (@couleur is null or ARCOULEUR = @couleur)  
	and (@grille is null or ARGRILLE = @grille)  
	and (@calibre is null or ARCALIBRE = @calibre)  
	and (@foreign1 is null or ARFOREIGN1 = @foreign1)  
	and (@foreign2 is null or ARFOREIGN2 = @foreign2)
	and (@arproduit is null or ARPRODUIT = @arproduit)   
  and (@aremp is null or AREMP = @aremp) 
	 
	and (@offert is null or isnull(FALTOTALHT,0)!=0) 
   
	drop table #Final  
   
end
go

