CREATE PROCEDURE dbo.b_charge_packaging (@article char(15),@depot char(4),@emp char(8))

AS
begin
	create table #result(
		ssemp char(8)
	)
	declare @m_count int
	
	if(@depot='GROS') and (isnull(@emp,'')<>'')
		begin
			insert into #result select distinct xEmplSTEMP from xEMPL where xDepotl=@depot and xEmpl=@emp and isnull(xEmplSTEMP,'')<>''
			order by xEmplSTEMP 
			
			select @m_count=count(*) from #result
			if(@m_count>0)
				begin
  					select ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,sum(STEMP_PACK_QTECOLIS),STEMPAR,STEMPID 
			  		from FSTEMP left join xSTEMP_PACKAGING on STEMP_PACK_STEMPID=STEMPID 
			  		left join FARE on (AREAR=STEMPAR and AREDEPOT=STEMPDEPOT)
			  		inner join VIEW_FAR on ARCODE=STEMPAR 
			  		where 
			  		 (@article='' or @article=null or STEMPAR=@article) 
			  		 and STEMPDEPOT=@depot
			  		 and STEMPQTE>0 
			  		 and AREPICK=1 and ARERECEP=1 and AREVALID=1
			  		 and STEMPEMP in (select ssemp from #result) 
			  		group by STEMPAR,ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,STEMPID  order by STEMPEMP,ARESSEMP
	  			end
  		end	
  	else if((@depot='DET') and (isnull(@emp,'')<>''))
  		begin
  			select ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,sum(STEMP_PACK_QTECOLIS),STEMPAR,STEMPID 
	  		from FSTEMP left join xSTEMP_PACKAGING on STEMP_PACK_STEMPID=STEMPID
	  		left join FARE on (AREAR=STEMPAR and AREDEPOT=STEMPDEPOT) 
	  		inner join VIEW_FAR on ARCODE=STEMPAR 
	  		where 
	  		 (@article='' or @article=null or STEMPAR=@article) 
	  		 and STEMPDEPOT=@depot
	  		 and STEMPQTE>0 
	  		 and STEMPEMP=@emp
	  		 and AREPICK=1 and ARERECEP=1 and AREVALID=1
	  		 group by STEMPAR,ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,STEMPID 
	  		 order by STEMPEMP,ARESSEMP
  		end
  	else if(isnull(@emp,'')='')  and (isnull(@article,'')<>'') and (isnull(@depot,'')<>'') 
  		begin
  			select ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,sum(STEMP_PACK_QTECOLIS),STEMPAR,STEMPID from 
  			FSTEMP left join xSTEMP_PACKAGING on 
  			STEMP_PACK_STEMPID=STEMPID 
  			left join FARE on (AREAR=STEMPAR and AREDEPOT=STEMPDEPOT)
  			inner join VIEW_FAR on ARCODE=STEMPAR 
  			where STEMPAR=@article and STEMPQTE>0 
  			and AREPICK=1 and ARERECEP=1 and AREVALID=1
  			and STEMPDEPOT=@depot
  			and STEMPDEPOT in (select DPCODE from FDP where DPCENTRAL=1) group by 
  			STEMPAR,ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,STEMPAR,STEMPID order by STEMPEMP,ARESSEMP
  		end  
  	else if(isnull(@emp,'')='') and (isnull(@depot,'')='') and (isnull(@article,'')<>'')
  		begin
  			select ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,sum(STEMP_PACK_QTECOLIS),STEMPAR,STEMPID from 
  			FSTEMP left join xSTEMP_PACKAGING on 
  			STEMP_PACK_STEMPID=STEMPID 
  			left join FARE on (AREAR=STEMPAR and AREDEPOT=STEMPDEPOT)
  			inner join VIEW_FAR on ARCODE=STEMPAR 
  			where STEMPAR=@article and STEMPQTE>0 
  			and AREPICK=1 and ARERECEP=1 and AREVALID=1
  			and STEMPDEPOT in (select DPCODE from FDP where DPCENTRAL=1) group by 
  			STEMPAR,ARLIB,STEMPLOT,STEMPLETTRE,STEMPDEPOT,STEMPEMP,ARESSEMP,STEMPQTE,STEMPID order by STEMPEMP,ARESSEMP
  		end  	
end
go

