


/* Procedure permettant de suivre les mouvements d''un article */

create procedure Suivi (@Article	char(15),
						@Lettre		char(4) = null)
with recompile
as
begin

declare @lot	smallint

select @lot=CVLOT
from FAR,FCV
where ARUNITACHAT=CVUNIF
and ARCODE=@Article

select Unite_achat_actuel=@lot


select 'Stock initial - Fluctuations - Fichier SIL'

select 'SIL ',Article=SILARTICLE,Lettre=SILLETTRE,Date=SILDATE,
Quantite=SILQTE,PrixRevient=round((SILPAHT+SILFRAIS)/@lot,2)*SILQTE,
Depot=SILDEPOT,NÃÂ°=SILNUMDEP
from FSIL
where SILARTICLE=@Article
and ((@Lettre is null) or (SILLETTRE=@Lettre))
order by SILDATE
compute sum(SILQTE),sum(round((SILPAHT+SILFRAIS)/@lot,2)*SILQTE)


select 'Reajustements - Fichier RJL'

select 'RJL',Article=RJLARTICLE,Lettre=RJLLETTRE,Date=RJLDATE,
Quantite=RJLQTE,PrixRevient=round((RJLPAHT+RJLFRAIS)/@lot,2)*RJLQTE,
Depot=RJLDEPOT,NÃÂ°=RJLNUMDEP
from FRJL
where RJLARTICLE=@Article
and ((@Lettre is null) or (RJLLETTRE=@Lettre))
order by RJLDATE
compute sum(RJLQTE),sum(round((RJLPAHT+RJLFRAIS)/@lot,2)*RJLQTE)


select 'Lignes de casse - Fichier LCL'

select 'LCL',Article=LCLARTICLE,Lettre=LCLLETTRE,Date=LCLDATE,
Quantite=LCLQTE,PrixRevient=round((LCLPAHT+LCLFRAIS)/@lot,2)*LCLQTE,
Depot=LCLDEPOT,NÃÂ°=LCLNUMDEP
from FLCL
where LCLARTICLE=@Article
and ((@Lettre is null) or (LCLLETTRE=@Lettre))
order by LCLDATE
compute sum(LCLQTE),sum(round((LCLPAHT+LCLFRAIS)/@lot,2)*LCLQTE)


select 'Assemblage Desassemblage - Fichier ASL'

select 'ASL',Article=ASLARTICLE,Lettre=ASLLETTRE,Date=ASLDATE,
Quantite=ASLQTE,PrixRevient=(ASLPAHT+ASLFRAIS)*ASLQTE,
Depot=ASLDEPOT,NÃÂ°=ASLNUMDEP
from FASL
where ASLARTICLE=@Article
and ((@Lettre is null) or (ASLLETTRE=@Lettre))
order by ASLDATE
compute sum(ASLQTE),sum((ASLPAHT+ASLFRAIS)*ASLQTE)


select 'Reajustements des mouvements uniquement - Fichier RM'

select 'RM ',Article=RMARTICLE,Lettre=RMLETTRE,Date=RMDATE,
Quantite=RMQTE,PrixRevient=round((RMPAHT+RMFRAIS)/@lot,2)*RMQTE,
Depot=RMDEPOT,NÃÂ°=RMNUMDEP
from FRM
where RMARTICLE=@Article
and ((@Lettre is null) or (RMLETTRE=@Lettre))
order by RMDATE
compute sum(RMQTE),sum(round((RMPAHT+RMFRAIS)/@lot,2)*RMQTE)


select 'Bordereaux de livraisons Fournisseurs - Fichier BLL'

select 'BLL',Article=BLLAR,Lettre=BLLLET,Date=BLLDATE,
Quantite=BLLQTE,PrixRevient=round(BLLPRHT/@lot,2)*BLLQTE,
Depot=BLLDEP,NÃÂ°=BLLNUMDEP,Code=BLLCODE,Ligne=BLLNUM
from FBLL
where BLLAR=@Article
and (@Lettre is null or BLLLET=@Lettre)
order by BLLDATE
compute sum(BLLQTE),sum(round((BLLPRHT)/@lot,2)*BLLQTE)


select 'Sorties de douanes & entrees magasin - Fichier DOL'

select 'DOL',Article=DOLAR,Lettre=DOLLET,Date=DOLDATE,
Quantite=DOLQTE,PrixRevient=round(DOLPRHT/@lot,2)*DOLQTE,
Depot=DOLDEP,NÃÂ°=DOLNUMDEP,Code=DOLCODE,Ligne=DOLNUM
from FDOL
where DOLAR=@Article
and (@Lettre is null or DOLLET=@Lettre)
order by DOLDATE
compute sum(DOLQTE),sum(round((DOLPRHT)/@lot,2)*DOLQTE)


select 'Retour des marchandises vers Fournisseurs - Fichier RFL'

select 'RFL',Article=RFLARTICLE,Lettre=RFLLETTRE,Date=RFLDATE,
Quantite=RFLQTE,PrixRevient=round(RFLPAHT/@lot,2)*RFLQTE,
Depot=RFLDEPOT,NÃÂ°=RFLNUMDEP,Code=RFLCODE,Ligne=RFLNUM
from FRFL
where RFLARTICLE=@Article
and (@Lettre is null or RFLLETTRE=@Lettre)
order by RFLDATE
compute sum(RFLQTE),sum(round((RFLPAHT)/@lot,2)*RFLQTE)


select 'Factures - Fichier FAL'
select count(*) from FFAL where FALARTICLE=@Article and (@Lettre is null or FALLETTRE=@Lettre)

select 'FAL',Article=FALARTICLE,Lettre=FALLETTRE,Date=FALDATE,
Quantite=FALQTE,PrixRevient=round((STPAHT+STFRAIS)/@lot,2)*FALQTE,
Depot='MAG',NÃÂ°='1',CodeFA=FALCODE,CodeBE=FALLIENCODE,LigneBE=FALLIENNUM
from FFAL,FSTOCK
where FALARTICLE*=STAR
and FALLETTRE*=STLETTRE
and FALARTICLE=@Article
and (@Lettre is null or FALLETTRE=@Lettre)
order by FALDATE
compute sum(FALQTE),sum(round((STPAHT+STFRAIS)/@lot,2)*FALQTE)


select 'Lignes de BE - Fichier FBEL'
select count(*) from FBEL where BELARTICLE=@Article and (@Lettre is null or BELLETTRE=@Lettre)

select 'BEL',Article=BELARTICLE,Lettre=BELLETTRE,Date=BELDATE,
Quantite=BELQTE,PrixRevient=round((STPAHT+STFRAIS)/@lot,2)*BELQTE,
Depot='MAG',NÃÂ°='1',Code=BELCODE,Ligne=BELNUM,BELRESTE
from FBEL,FSTOCK
where BELARTICLE*=STAR
and BELLETTRE*=STLETTRE
and BELARTICLE=@Article
and (@Lettre is null or BELLETTRE=@Lettre)
order by BELDATE
compute sum(BELQTE),sum(round((STPAHT+STFRAIS)/@lot,2)*BELQTE),sum(BELRESTE)


select "Lignes de RBE - Fichier FRBE"

select RBEARTICLE,RBEDATE,RBEQTE*sign(BELQTE),RBECL,RBEDEMO,RBEECH,RBEFACTMAN
from FRBE,FBEL
where BELSEQ=RBESEQ
and RBEARTICLE=@Article
order by RBEDATE
compute sum(RBEQTE*sign(BELQTE))


select 'Lignes de Stock en cours - Fichier FSTOCK'
select count(*) from FSTOCK where STAR=@Article and (@Lettre is null or STLETTRE=@Lettre)

select 'STOCK',Article=STAR,Lettre=STLETTRE,Date=STDATEENTR,
Quantite=STQTE,PrixRevient=round((STPAHT+STFRAIS)/@lot,2)*STQTE,
Depot=STDEPOT,NÃÂ°=DPLOC,Fournisseur=STFO
from FSTOCK,FDP
where STAR=@Article
and (@Lettre is null or STLETTRE=@Lettre)
and DPCODE=*STDEPOT
order by STDATEENTR
compute sum(STQTE),sum(round((STPAHT+STFRAIS)/@lot,2)*STQTE)


end



go

