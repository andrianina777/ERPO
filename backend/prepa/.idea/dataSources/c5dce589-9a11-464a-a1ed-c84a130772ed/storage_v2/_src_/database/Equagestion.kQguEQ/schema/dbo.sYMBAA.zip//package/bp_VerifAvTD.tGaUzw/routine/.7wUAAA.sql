/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_VerifAvTD
grant execute on bp_VerifAvTD to public
*/

CREATE PROCEDURE dbo.bp_VerifAvTD(@article char(15),@qte int,@depot char(4),@lettre char(4),@empl char(10))
with recompile
AS
begin
	declare @qteResv int,
			@qteStock int


	select @qteResv=sum(isnull(RBPQTE,0)) from FRBP where RBPARTICLE=@article  and RBPDEPOT=@depot and RBPLETTRE=@lettre  and RBPEMP=@empl group by RBPARTICLE,RBPDEPOT,RBPEMP,RBPLETTRE
	
	select @qteStock=sum(isnull(STEMPQTE,0)) from VIEW_STOCK_LOT_EMPLACEMENT where STEMPAR=@article and STEMPDEPOT=@depot and STLETTRE=@lettre and STEMPEMP=@empl group by STEMPAR,STEMPDEPOT,STLETTRE,STEMPEMP
	
	if(@qteStock-@qteResv-@qte<0)
		begin
	  		select 1  	
		end
	else
		select 0
end
go

