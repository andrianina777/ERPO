


/* Procedure utilisee pour le calcul du droit a la RFA d''un client	*/
/*   sur une ligne de facture a partir de la procedure RFA_Detail */
	
/* renvoie la liste la plus precise des rubriques d''une ligne de contrat */



create procedure RFACT (@ent			char(5)			= null,
						@client			char(12),
						@annee			smallint,
						@article		char(15),
						@contrat		char(10)		= null,
						@contrat_out	char(10)		output,
						@depart_out		char(8)			output,
						@fo_out			char(12)		output,
						@fam_out		char(8)			output,
						@categ_out		char(8)			output,
						@article_out	char(15)		output,
						@tarif_out		char(8)			output,
						@qtect_out		int				output,
						@valct_out		numeric(14,0)	output,
						@rcrfa_out		numeric(8,4)	output
					   )
with recompile
as
begin	

set arithabort numeric_truncation off
					
declare	@depart		char(8),
		@fo			char(12),
		@fam		char(8),
		@categ		char(8),
		@tarif		char(8),
		@qtect		int,
		@valct		numeric(14,0),
		@seq		int
		
select @seq = 0		

select 	@depart=ARDEPART, @fo=ARFO, @fam=ARFAM, @categ=ARGRFAM
from FAR
where ARCODE=@article

select @tarif=isnull(CLTARIF,"")
from FCL
where CLCODE=@client

create table #Seq
(
seq		int				not null,
prio	int				not null,
id		numeric(14,0)	identity
)

insert into #Seq (seq,prio)
select (case
	when RCARTICLE=@article and RCTARIF=@tarif then RCSEQ
	when RCARTICLE=@article and RCTARIF='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO='' and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART='' then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART=@depart then RCSEQ
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART='' then RCSEQ
	else 0 end),
	(case
	when RCARTICLE=@article and RCTARIF=@tarif then 1
	when RCARTICLE=@article and RCTARIF='' then 2
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then 3
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART='' then 4
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART=@depart then 5
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART='' then 6
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART=@depart then 7
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART='' then 8
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART=@depart then 9
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART='' then 10
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then 11
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART='' then 12
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO='' and RCDEPART=@depart then 13
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART='' then 14
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART=@depart then 15
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART='' then 16
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART=@depart then 17
	when RCARTICLE='' and RCTARIF=@tarif and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART='' then 18
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then 19
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO=@fo and RCDEPART='' then 20
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART=@depart then 21
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM=@fam and RCFO='' and RCDEPART='' then 22
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART=@depart then 23
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO=@fo and RCDEPART='' then 24
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART=@depart then 25
	when RCARTICLE='' and RCTARIF='' and RCCATEG=@categ and RCFAM='' and RCFO='' and RCDEPART='' then 26
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART=@depart then 27
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO=@fo and RCDEPART='' then 28
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO='' and RCDEPART=@depart then 29
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM=@fam and RCFO='' and RCDEPART='' then 30
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART=@depart then 31
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO=@fo and RCDEPART='' then 32
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART=@depart then 33
	when RCARTICLE='' and RCTARIF='' and RCCATEG='' and RCFAM='' and RCFO='' and RCDEPART='' then 34
	else 0 end)
	from FRC
	where RCCL=@client
	and RCAN=@annee
	and (@contrat is null or RCCONTRAT=@contrat)
	and (@ent is null or RCENT=@ent)


set rowcount 1

select @seq = seq
from #Seq
where seq != 0
order by prio

set rowcount 0

 
if @seq is null or @seq = 0
begin
select @depart_out = "", @fo_out = "", @fam_out = "",
	   @categ_out = "", @article_out = "", @tarif_out = "",
	   @qtect_out = 0, @valct_out = 0, @rcrfa_out = 0
return (1)
end
else
begin

select @contrat_out=isnull(RCCONTRAT,''),@depart_out=isnull(RCDEPART,''),@fo_out=isnull(RCFO,''),@fam_out=isnull(RCFAM,''),@categ_out=isnull(RCCATEG,''),
	   @article_out=isnull(RCARTICLE,''),@tarif_out=isnull(RCTARIF,''),@qtect_out=isnull(RCQTE,0),@valct_out=isnull(RCMONTANT,0),@rcrfa_out=isnull(RCRFA,0)
from FRC
where RCSEQ = @seq

return (0)
end

end



go

