CREATE PROCEDURE dbo.bp_BlocageVente(
		@codeClient char(25),
		@codeArticle char(30))
with recompile
AS
begin
	 declare
	 	@labo char(15),
	 	@count int
	 
	 	select @labo=ARFO from VIEW_FAR where ARCODE=@codeArticle

		select count(*)  from xBlocageVente where ((bvArticle=@codeArticle)     or (bvLabo=@labo and bvArticle='*')) and bvClient=@codeClient 
		and convert (DATE,bvDatedebut,103)<=convert(DATE,getDate(),103) and convert(DATE,bvDatefin,103)>=convert(DATE,getDate(),103)
end
go

