/*
Highlight and execute the following statement to drop the procedure
before executing the create statement.

DROP PROCEDURE dbo.bp_ImprimeTransfertResv
grant execute  on bp_ImprimeTransfertResv to public
*/

CREATE PROCEDURE dbo.bp_ImprimeTransfertResv (@codeTF char(10))




as
begin

select x_TR_CodeL,x_TR_DepotDepL,x_TR_EmpDepL,ARLIB,x_TR_LotL,NLOTDATEPER,sum(x_TR_QteL),x_TR_DepotDestL,x_TR_EmpDestL
from x_TransfertReservationL 
inner join VIEW_FAR on ARCODE=x_TR_ArticleL
inner join FNLOT on NLOTAR=x_TR_ArticleL and NLOTCODE=x_TR_LotL

where x_TR_CodeL=@codeTF
group by x_TR_CodeL,x_TR_DepotDepL,x_TR_EmpDepL,ARLIB,x_TR_LotL,NLOTDATEPER,x_TR_DepotDestL,x_TR_EmpDestL

end
go

