CREATE PROCEDURE dbo.bp_Promoflash (@CodeArticle char(30),@NewPrix numeric(18),@datedeb Smalldatetime ,@datefin smalldatetime)
AS
begin
	declare @oldPrix numeric(18)
	
	select @oldPrix=ARPVHT from FAR where ARCODE=@CodeArticle
	
	insert into xPromoflash(pArticle,pAncienPrix,pNewPrix,pDatedebut,pDatefin,pDatecre) values (@CodeArticle,@oldPrix,@NewPrix,@datedeb,@datefin,getDate())
	
	update FAR set ARPVHT=@NewPrix where ARCODE=@CodeArticle
	
	update FART set ARTPVHT=@NewPrix where ARTAR=@CodeArticle
end
go

