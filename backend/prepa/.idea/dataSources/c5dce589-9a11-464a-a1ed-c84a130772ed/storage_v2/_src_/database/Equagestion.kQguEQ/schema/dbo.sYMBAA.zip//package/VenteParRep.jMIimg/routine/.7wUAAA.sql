


create procedure VenteParRep (	@ent		char(5)	= null,
								@rep 		char(8),
								@FromDate 	smalldatetime,
								@ToDate 	smalldatetime)
with recompile
as
begin

declare @type	tinyint
select  @type=RETYPE from FREP where RECODE=@rep

declare @multient	tinyint
select @multient=KIMULTIENTITE from KInfos

if @type != 2
begin
  select BELCL,CLNOM1,CLVILLE,BELARTICLE,ARLIB,sum(BELQTE)
  from FBEL,FAR,FCL (index code)
  where BELDATE between @FromDate and @ToDate
  and CLCODE=BELCL
  and CLREP=@rep
  and ARCODE=BELARTICLE
  and (@multient=0 or @ent is null or (BELENT=@ent and CLENT=BELENT))
  group by BELCL,CLNOM1,CLVILLE,BELARTICLE,ARLIB
  order by BELCL,BELARTICLE
end
else if @type = 2
begin
  select BELCL,CLNOM1,CLVILLE,BELARTICLE,ARLIB,sum(BELQTE)
  from FBEL,FAR,FCL (index code),FCLR
  where BELDATE between @FromDate and @ToDate
  and CLCODE=BELCL
  and CLRCL=CLCODE
  and CLRDIV=ARDEPART
  and CLRREPDIV=@rep
  and ARCODE=BELARTICLE
  and (@multient=0 or @ent is null or (BELENT=@ent and CLENT=BELENT))
  group by BELCL,CLNOM1,CLVILLE,BELARTICLE,ARLIB
  order by BELCL,BELARTICLE
end



end



go

