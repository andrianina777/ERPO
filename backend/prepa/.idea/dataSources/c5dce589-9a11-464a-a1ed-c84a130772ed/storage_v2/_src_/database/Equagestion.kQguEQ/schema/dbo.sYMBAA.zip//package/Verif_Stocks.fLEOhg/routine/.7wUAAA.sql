


/* Procedure de verification entre le stock resultant et le stock par emplacements */

create procedure Verif_Stocks
as
begin

declare @count	int


create table #Result
(
Titre		varchar(80)	null,
Article		char(15)		null,
Lettre		char(4)			null,
QteST		int				null,
QteSTEMP	int				null,
Difference	int				null,
Depot		char(4)			null,
Emp			char(8)			null,
Stockmini	int				null
)


/****/

insert into #Result (Titre,Article,Lettre,QteST,QteSTEMP,Difference)
select Titre="Differences entre le stock resultant et le stock par emplacements",STAR,STLETTRE,
		FSTOCK_QTE=STQTE,
		FSTEMP_QTE=(select sum(STEMPQTE) from FSTEMP where STEMPAR=FSTOCK.STAR and STEMPLETTRE=FSTOCK.STLETTRE),
		Difference=STQTE-(select sum(STEMPQTE) from FSTEMP where STEMPAR=FSTOCK.STAR and STEMPLETTRE=FSTOCK.STLETTRE)
from FSTOCK,FAR
where STQTE != (select sum(STEMPQTE) from FSTEMP where STEMPAR=FSTOCK.STAR and STEMPLETTRE=FSTOCK.STLETTRE)
and ARCODE=STAR
and ARTYPE=0

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Lettre,QteST,QteSTEMP,Difference
	from #Result
	order by Article,Lettre
	
delete from #Result

/****/

insert into #Result (Titre,Article,Lettre,QteST)
select Titre="Stock resultant non represente en stock par emplacements",STAR,STLETTRE,FSTOCK_QTE=STQTE
from FSTOCK,FAR
where STQTE != 0
and not exists (select * from FSTEMP where STEMPAR=FSTOCK.STAR and STEMPLETTRE=FSTOCK.STLETTRE)
and ARCODE=STAR
and ARTYPE=0

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Lettre,QteST
	from #Result
	order by Article,Lettre
	
delete from #Result

/****/

insert into #Result (Titre,Article,Lettre,QteST)
select Titre="Differences entre le stock par emplacements et le stock resultant",STEMPAR,STEMPLETTRE,FSTEMP_QTE=sum(STEMPQTE)
from FSTEMP,FAR
where ARCODE=STEMPAR
and ARTYPE=0
group by STEMPAR,STEMPLETTRE
having sum(STEMPQTE) != (select sum(STQTE) from FSTOCK where FSTEMP.STEMPAR=FSTOCK.STAR and FSTEMP.STEMPLETTRE=FSTOCK.STLETTRE)

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Lettre,QteST
	from #Result
	order by Article,Lettre
	
delete from #Result

/****/

insert into #Result (Titre,Article,Lettre,QteST)
select Titre="Stock par emplacements non represente en stock resultant",STEMPAR,STEMPLETTRE,FSTEMP_QTE=STEMPQTE
from FSTEMP,FAR
where ARCODE=STEMPAR
and ARTYPE=0
and not exists (select * from FSTOCK where FSTEMP.STEMPAR=FSTOCK.STAR and FSTEMP.STEMPLETTRE=FSTOCK.STLETTRE)

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Lettre,QteST
	from #Result
	order by Article,Lettre
	
delete from #Result

/****/

insert into #Result (Titre,Article,Depot,Emp,QteSTEMP)
select Titre="Stock par emplacements non represente en fiche article",STEMPAR,STEMPDEPOT,STEMPEMP,FSTEMP_QTE=sum(STEMPQTE)
from FSTEMP,FAR
where ARCODE=STEMPAR
and ARTYPE=0
and not exists (select * from FARE where FSTEMP.STEMPAR=AREAR and FSTEMP.STEMPDEPOT=AREDEPOT and FSTEMP.STEMPEMP=AREEMP)
group by STEMPAR,STEMPDEPOT,STEMPEMP
order by STEMPAR,STEMPDEPOT,STEMPEMP

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Depot,Emp,QteSTEMP
	from #Result
	order by Article,Depot,Emp
	
delete from #Result

/****/

insert into #Result (Titre,Article,Lettre,QteST)
select Titre="Stock negatif sur Stock resultant",STAR,STLETTRE,FSTOCK_QTE=STQTE
from FSTOCK,FAR
where STQTE < 0
and ARCODE=STAR
and ARTYPE=0

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Lettre,QteST
	from #Result
	order by Article,Lettre
	
delete from #Result

/****/

insert into #Result (Titre,Article,Lettre,QteST)
select Titre="Stock negatif sur Stock par emplacements",STEMPAR,STEMPLETTRE,FSTEMP_QTE=STEMPQTE
from FSTEMP,FAR
where ARCODE=STEMPAR
and ARTYPE=0
and STEMPQTE < 0

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Lettre,QteST
	from #Result
	order by Article,Lettre
	
delete from #Result

/****/

insert into #Result (Titre,Article,Stockmini,QteST)
select Titre="Stock minimum depasse",STAR,Stock_mini=ARSTOCKMINI,FSTOCK_QTE=sum(STQTE)
from FSTOCK,FAR,FDP
where STQTE > 0
and ARCODE=STAR
and ARTYPE=0
and DPCODE=STDEPOT
and DPLOC in (0,1)
group by STAR
having sum(STQTE) < ARSTOCKMINI
and ARCODE=STAR
and ARTYPE=0
order by STAR

select @count = count(*) from #Result

if @count > 0
	select Titre,Article,Stockmini,QteST
	from #Result
	order by Article
	
delete from #Result


end



go

