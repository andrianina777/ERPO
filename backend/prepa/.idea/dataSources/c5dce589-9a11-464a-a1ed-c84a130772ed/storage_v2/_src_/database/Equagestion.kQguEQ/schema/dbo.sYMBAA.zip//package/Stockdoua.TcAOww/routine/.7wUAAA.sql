


create procedure Stockdoua (@ent		char(5) = null,
							@date		smalldatetime)
with recompile
as
begin
	
	create table #temp1
	(
	article varchar(15) not null,
	depot	char(4)		not null,
	qte 	int 			null
	)	
	
	select ARCODE,ARLIB,ARCODEDOUA,ARQTECOLIS,STDEPOT,stockqte=sum(STQTE)
	into #temp
	from FSTOCK,FAR,FDP
	where STAR=ARCODE
	and STDEPOT=DPCODE
	and DPLOC = 0
	and STQTE!=0
	and DPCODE=STDEPOT and (@ent is null or (DPENT=@ent and DPCENTRAL=0)) 
	group by ARCODE,ARLIB,ARCODEDOUA,ARQTECOLIS,STDEPOT
	
	insert #temp1 (article,depot,qte)
	select RJLARTICLE,RJLDEPOT,RJLQTE
	from FRJL
	where RJLNUMDEP = 0
	and RJLDATE between @date and getdate()
	
	insert #temp1 (article,depot,qte)
	select SILARTICLE,SILDEPOT,SILQTE
	from FSIL
	where SILNUMDEP = 0
	and SILDATE between @date and getdate()
	
	insert #temp1 (article,depot,qte)
	select BLLAR,BLLDEP,BLLQTE
	from FBLL
	where BLLNUMDEP = 0
	and BLLDATE between @date and getdate()
	
	
	insert #temp1 (article,depot,qte)
	select DOLAR,DOLDEP,DOLQTE
	from FDOL
	where DOLNUMDEP = 0
	and DOLDATE between @date and getdate()
	
		
	select ajoutart=article,ajoutdepot=depot,ajoutqte=sum(qte)
	into #ajout
	from #temp1
	group by article,depot
		
	/* select de retour */
	
	select ARCODE,ARLIB,ARCODEDOUA,ARQTECOLIS,STDEPOT,isnull(stockqte,0),isnull(ajoutqte,0)
	from #temp,#ajout
	where ARCODE*=ajoutart
	and STDEPOT*=ajoutdepot
	and (isnull(stockqte,0)-isnull(ajoutqte,0))>0
	order by ARCODE,STDEPOT
	
	drop table #temp
	drop table #temp1
	drop table #ajout
	
end	



go

